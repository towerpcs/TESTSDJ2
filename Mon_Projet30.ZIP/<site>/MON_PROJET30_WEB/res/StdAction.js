// StdAction.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS bSfr

function _Open (sURL, sNomBlank, sOptions)
{
	sNomBlank = (sNomBlank && (0 < sNomBlank.length)) ? sNomBlank.toUpperCase() : "_BLANK_" + Date.now();
	if (sOptions)
	{
		open(sURL, sNomBlank, sOptions);
	}
	else
	{
		open(sURL, sNomBlank);
	}
};

function _CFI(sURL)
{
	var i = sURL.indexOf("?");
	var j = sURL.lastIndexOf("?");

	while (j > i)
	{
		sURL = sURL.substring(0, j - 1) + "&" + sURL.substring(j + 1);
		j = sURL.lastIndexOf("?");
	}
	return sURL;
};
function _JCL(sURL, sTarget, sNomBlank, sOptions)
{
	sURL = _CFI(sURL);
	var clFrame;
	switch (sTarget)
	{
	case "_blank":
		_Open(sURL, sNomBlank, sOptions);
		return;
	case "_top":
		clFrame = top;
		break;
	case "_parent":
		clFrame = parent;
		break;
	case "_self":
		// GP 13/02/2018 : TB107200 : Ajout du cas "" (pour les tables qui en fait font une extraction de la target mais qui n'ont souvent pas l'informations.
	case "":
		clFrame = self;
		break;
	default:
		clFrame = _JOF(top, sTarget);
		if (clFrame.parent == self)
		{
			open(sURL, sTarget);
			return;
		}
		// Sinon tombe dans le cas par defaut
		break;
	}
	clFrame.document.location = sURL;
}
function _JRL(sURL, sTarget, sNomBlank, sOptions)
{
	sURL = _CFI(sURL);
	var clFrame;
	switch (sTarget)
	{
	case "_blank":
		_Open(sURL, sNomBlank, sOptions);
		return;
	case "_top":
		clFrame = top;
		break;
	case "_parent":
		clFrame = parent;
		break;
	case "_self":
		clFrame = self;
		break;
	default:
		clFrame = _JOF(top, sTarget);
		break;
	}
	clFrame.document.location.replace(sURL);
}
function _JSL(clFormulaire, sBouton, sTarget, sNomBlank, sOptions, sAction)
{
	// D�clare les variables pour la closure du setTimeout
	var clFormulaireLocal = clFormulaire;
	var sOldBtnClick = clFormulaire.WD_BUTTON_CLICK_.value;
	var sOldTarget = clFormulaire.target;

	sBouton = _CFI(sBouton);
	clFormulaire.WD_ACTION_.value = (sAction ? sAction : "");
	clFormulaire.WD_BUTTON_CLICK_.value = sBouton;
	var nTimeout = ((navigator.appName == "Microsoft Internet Explorer") && (navigator.platform.substr(0, 3) == "Mac")) ? 200 : 1;
	switch (sTarget)
	{
	case "_blank":
		if (sOptions)
		{
			sNomBlank = ((0 < sNomBlank.length) ? sNomBlank.toUpperCase() : "_BLANK_" + Math.abs((new Date()).getTime()));
			_Open("", sNomBlank, sOptions);
			sTarget = sNomBlank;
			nTimeout = 1000;
		}
		// Pas de break;
	case "_self":
	case "_top":
	case "_parent":
		clFormulaire.target = sTarget;
		break;
	default:
		clFormulaire.target = sTarget.toUpperCase();
		break;
	}
	// GP 24/10/2013 : QW236909 : Si on un onbeforeunload annule le submit, IE lance une erreur non specifi�e ici (SCRIPT16389)
	// Selon des r�ponses trouv� sur internet, il semble que le bug est dans IE. La seule solution est un Try/Catch
	try
	{
		// GP 11/07/2016 : TB99171 : Effet de bord de la correction de TB71740, il semble y avoir une interaction entre le onpageshow et submit si on est dans le onload de la page
		var pfOnpageshow = null;
		if (bSfr)
		{
			pfOnpageshow = window.onpageshow;
			if (pfOnpageshow)
			{
				window.onpageshow = null;
			}
		}
		clFormulaire.submit();
	}
	catch (e)
	{
		// 0x80004005
		if (-2147467259 != e.number)
		{
			throw e;
		}
	}
	setTimeout(function()
	{
		clFormulaireLocal.target = sOldTarget;
		clFormulaireLocal.WD_BUTTON_CLICK_.value = sOldBtnClick;
		if (pfOnpageshow)
		{
			window.onpageshow = pfOnpageshow;
		}
	}
	, nTimeout);
}
function _JOF(clFenetre, sNom)
{
	var tabFrames = clFenetre.frames;
	var clFrame;
	try
	{
		clFrame = tabFrames[sNom];
		if (clFrame)
		{
			return clFrame;
		}
	}
	catch(e)
	{
	}
	var i;
	var nLimiteI = tabFrames.length;
	var sNomMajuscule = sNom.toUpperCase();
	for (i = 0; i < nLimiteI; i++)
	{
		try
		{
			clFrame = tabFrames[i];
			if (clFrame.name.toUpperCase() == sNomMajuscule)
			{
				return clFrame;
			}
		}
		catch (e)
		{
		}
		// Recherche les sous frames
		clFrame = _JOF(clFrame, sNom);
		if (clFrame)
		{
			return clFrame;
		}
	}
	return null;
}
function __pfGetActionDouble (pfAction, sAlias)
{
	// Si l'alias commence par zrl_ :
	// - La forme de l'alis re�u est donc normalement de la forme zrl_<Indice zr>_<Alias champ>
	// - On teste un second alias de la forme : zrl_<Indice zr>_ATT_<Alias champ>_1 (= l'attribut automatique sur la propri�t� valeur de ce champ).
	if (sAlias.substr(0, 4) === "zrl_")
	{
		var nPositionSecondUnderscore = sAlias.indexOf("_", 4);
		if (-1 !== nPositionSecondUnderscore)
		{
			var sAliasAtt = sAlias.substr(0, nPositionSecondUnderscore + 1) + "ATT_" + sAlias.substr(nPositionSecondUnderscore + 1) + "_1";
			return function __oActionDouble(sPrefixe)
			{
				return pfAction(sPrefixe + sAlias) || pfAction(sPrefixe + sAliasAtt);
			};
		}
	}

	return function __oActionSimple(sPrefixe)
	{
		return pfAction(sPrefixe + sAlias);
	};
}

function _JGE(sAlias, clDocument, bExterieur, bAvecPrefixeUniquement)
{
	// GP 04/05/2016 : Les alias sans "_" ne sont plus g�n�r�s depuis la version 20
	// => On supprime la gestion. Dans le cas ou l'on avais pr�fixe + alias et pr�fixe + alias sans "_", on garde le premier des deux : c'est celui qui matchait dans le cas g�n�ral (alias cours donc sans _)
	// Ce qui fait l'ordre n'est plus sym�trique entre les deux code (voir "tz")

	var pfGetElementByIdDouble = __pfGetActionDouble(function (sId) { return clDocument.getElementById(sId); }, sAlias);
	var clElement;

	if (!bExterieur)
	{
		if (!bAvecPrefixeUniquement)
		{
			clElement = pfGetElementByIdDouble("");
			if (clElement)
			{
				return clElement;
			}
			clElement = clDocument.getElementById(sAlias + "_");
			if (clElement && (clDocument.getElementsByName(sAlias + "_AS").length > 0))
			{
				return clElement;
			}
		}
		// GP 09/01/2015 : QW253503 : Ajoute le cas + "_HTE" pour le ..class des champs avec conteneurs (Champ notation par exemple)
		// GP 02/03/2015 : "ztr" : Pour les champs dans une ZTR avec un habillage
		// GP 21/04/2015 : QW257439 : Il peut y avoir des dww + Alias (= avec underscore) <= indiqu� par GF dans la BAL
		clElement = pfGetElementByIdDouble("tz")
			|| clDocument.getElementById(sAlias + "_HTE")
			|| pfGetElementByIdDouble("bz")
			|| pfGetElementByIdDouble("dz")
			|| pfGetElementByIdDouble("dww")
			|| pfGetElementByIdDouble("ztr");
		if (clElement)
		{
			return clElement;
		}
	}
	else
	{
		// GP 04/03/2013 : TB81266 : Pour le champ upload en superposable, on rajoute un cas avec dwwuz
		// Je pense que ici c'est � la HTML de corriger : on a joute uz sur le bouton pour aviter les doublons
		// => Cela ne veux pas dire que le uz doit �tre sur le champ externe...
		// Dans le cas d'un champ upload on a un cz donc je place ce cas tout a l'ext�rieur
		// GP 02/03/2015 : "ztr" : Pour les champs dans une ZTR avec un habillage
		// GP 21/04/2015 : QW257439 : Il peut y avoir des dww + Alias (= avec underscore) <= indiqu� par GF dans la BAL
		// GP 02/05/2016 : TB97894 : GF indique que l'on a toujours dz > bz > tz  (en remplacement de bz > dz > tz)
		// GP 04/05/2016 : TB97677 : Ajout de la recherche de dzczcon-
		// GP 11/03/2018 : TB110251 : QW310365 : GF indique que que l'on a toujours dww > cz (et donc dzcz).
		// GP 06/04/2020 : TB115636 : Ajout de bzlz qui semble g�n�r� dans le cas d'une table avec libell�. Selon GF, cela arrive car on ajoute bz � l'ID calcul� qui contient le lz.
		// => On ne peut donc pas avoir de "bz" + "bzlz" => l'odre n'a donc pas d'importance.
		clElement = pfGetElementByIdDouble("ztr")
			|| pfGetElementByIdDouble("dwwuz")
			|| pfGetElementByIdDouble("dwwcz")
			|| pfGetElementByIdDouble("dzczcon-")
			|| pfGetElementByIdDouble("dww")
			|| pfGetElementByIdDouble("dzcz")
			|| pfGetElementByIdDouble("dzlz")
			|| pfGetElementByIdDouble("cz")
			|| pfGetElementByIdDouble("dz")
			|| pfGetElementByIdDouble("bzlz")
			|| pfGetElementByIdDouble("bz")
			|| pfGetElementByIdDouble("tz")
			|| pfGetElementByIdDouble("ctz")
			|| pfGetElementByIdDouble("con-")
			|| clDocument.getElementById(sAlias + "_HTE")
			|| pfGetElementByIdDouble("lz");
		if (clElement)
		{
			return clElement;
		}
		if (!bAvecPrefixeUniquement)
		{
			clElement = clDocument.getElementById(sAlias + '_');
			if (clElement && (clDocument.getElementsByName(sAlias + "_AS").length > 0))
			{
				return clElement;
			}
			clElement = pfGetElementByIdDouble("");
			if (clElement)
			{
				return clElement;
			}
		}
	}

	// GP 03/09/2012 : QW222216 : On ne retourne rien sinon les test si le champ existe echouent car on retourne un objet
	return undefined;
}

// JS_GetElementByIdName
function _JGEN(sAlias, clDocument, bExterieur, bAvecPrefixeUniquement, sProprieteSousElement, nSousElement)
{
	var pfGetElementsByNameDouble = __pfGetActionDouble(function (sName) { return clDocument.getElementsByName(sName)[0]; }, sAlias);

	// Recupere l'element en demandant l'element externe
	var clElementParID = _JGE(sAlias, clDocument, bExterieur, bAvecPrefixeUniquement);
	var clElementParName = pfGetElementsByNameDouble("");

	// Si on n'a pas un seul element, on prend le premier
	var clElement = clElementParID || clElementParName;
	// GP 30/03/2021 : TB119127 : Si on recherche depuis l'int�rieur et que l'on trouve un �l�ment par name (sans ID), il faut le privil�gier.
	// GP 30/04/2021 : QW337811 : La correction de TB119127 pose un probl�me, dans le cas du champ interrupteur/s�lecteur, l'�l�ment par name n'est pas celui que l'on veux trouver.
	// => Il faut filtrer le cas bAvecPrefixeUniquement. Si on demande int�rieur + avec pr�fixe uniquement, c'est que l'on ne veux pas vraiment l'int�rieur !
	if (!bExterieur && !bAvecPrefixeUniquement && clWDUtil.bEstFils(clElementParName, clElementParID))
	{
		clElement = clElementParName;
	}

	if (clElement && (sProprieteSousElement !== undefined) && (nSousElement !== undefined))
	{
		clElement = clElement[sProprieteSousElement][nSousElement];
	}
	return clElement;
}
