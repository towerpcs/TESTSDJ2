// WDAJAX.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - StdAction.js
///#GLOBALS _JCL _JSL _JGE
// - WDUtil.js
///#GLOBALS bIE nIE bIEQuirks bFF AppelMethode AppelMethodePtr WDErreur
// - WDChamp.js
///#GLOBALS WDChamp
// - WDCornage.js
///#GLOBALS WDCornage
// - WDGraphe.js
///#GLOBALS WDGraphe
// - WDTableZRCommun.js
///#GLOBALS clWDTableDefs
// - WDXML.js
///#GLOBALS XMLAjoutDoc
// - WD.js
///#GLOBALS NSPCS
// - Autres
///#GLOBALS Option $

// Classe representant une requete
function WDAJAXRequete(nId, clRequete, bPost, bSynchrone)
{
	// On initialise nos membres
	this.m_nId = nId;
	this.m_clRequete = clRequete;
	this.m_bPost = bPost;
	this.m_bSynchrone = bSynchrone;
	this.m_bValide = true;
	this.m_bJSONExterne = false;
};

// Les valeurs d'etat de requetes
WDAJAXRequete.prototype.readyStateUninitialized = 0;
WDAJAXRequete.prototype.readyStateLoading = 1;
WDAJAXRequete.prototype.readyStateLoaded = 2;
WDAJAXRequete.prototype.readyStateInteractive = 3;
WDAJAXRequete.prototype.readyStateComplete = 4;
// Headers
WDAJAXRequete.prototype.sHeaderErreur = "WebDevError";
WDAJAXRequete.prototype.sHeaderRedirPHP = "WebDevRedirPHP";
WDAJAXRequete.prototype.sHeaderXML = "WebDevXMLDoc";

// La callback en cas d'evenement asynchrone
WDAJAXRequete.prototype.OnReadyState = function OnReadyState(oPage)
{
	// Parfois on recoit deux readyStateComplete et on n'a alors plus de requete
	// Si c'est la notification de resultat pret
	if (this.m_clRequete && (this.m_clRequete.readyState == this.readyStateComplete))
	{
		// La callback en cas d'evenement asynchrone dans le cas de la gestion des tables
		var bRes = false;

		// On valide le resultat
		if (this.bValideResultat())
		{
			// Si on est dans une table AJAX
			if (this.m_oObjetRequeteTable)
			{
				// Si le resulat est valide on le renvoi
				switch (clWDAJAXMain.eReponseGenerique(this, oPage, this.m_oObjetRequeteTable, []))
				{
				case 0:	// 0 = Echec
					bRes = false;
					break;
				case 1:	// 1 = R�ussite
				case 2:	// 2 = Annulation (pour redirection)
					bRes = true;
					break;
				}
			}
			else if (this.m_fCallback)
			{
				// Si on valide le r�sultat et si la requ�te n'est pas annul�e (ce qui supprime this.m_fCallback)
				// On appelle la callback
				var pfCallback = this.m_fCallback;
				var sResultat = this.sGetResultat(oPage);
				// GP 29/06/2017 : QW288232 : On v�rifie le nombre de param�tre que l'on passe � la fonction, en effet le framework V2 v�rifie le nombre de param�tres transmis
				// GP 30/06/2017 : QW288704 : Pour le wrapper autour d'une fonction WL, utilise le membre ajout�
				// GP 16/10/2018 : QW304760 : La fonction peut avoir z�ro param�tres si la fonction serveur ne retourne pas de valeur.
				var nNbParametresPourWrapper = pfCallback.nNbParametres;
				var nNbParametres = (undefined !== nNbParametresPourWrapper) ? nNbParametresPourWrapper : pfCallback.length;
				switch (nNbParametres)
				{
				case 0:
					pfCallback();
					break;
				case 1:
					pfCallback(sResultat);
					break;
				default:
					pfCallback(sResultat, this.m_nId);
					break;
				}
			}
		}

		// GP 21/09/2012 : Pour les tables hi�rarchiques et les s�lections qui font un refresh : tente de supprimer dans tous les cas
		// GP 22/10/2012 : QW223063 : Sauf que selon le timing, ici this.m_oObjetRequeteTable a peut-�tre d�j� �t� supprim�
		if (this.m_oObjetRequeteTable)
		{
			this.m_oObjetRequeteTable.SupprimeRequete(!bRes);
		}

		// Libere la requete (dans tous les cas)
		this.Libere();
	}
};

// Indique si un header existe
WDAJAXRequete.prototype.__bHeaderHTTPExiste = function __bHeaderHTTPExiste(sHeader)
{
	// Blinde par une exception car certains navigateurs renvoient une exception si le header n'existe pas
	try
	{
		// On recupere la partie erreur de la requete
		var sValeur = this.m_clRequete.getResponseHeader(sHeader);
		// Renvoie true si il y a eu une erreur qui declenche une redirection
		return sValeur && (sValeur.length > 0);
	}
	catch (e)
	{
		// Pas de header, pas d'erreur
		return false;
	}
};

// Regarde si il y a une redirection vers une page d'erreur en PHP
WDAJAXRequete.prototype.bRedirectionPHP = function bRedirectionPHP()
{
	return this.__bHeaderHTTPExiste(this.sHeaderRedirPHP);
};

// Regarde si il y a une erreur serveur
WDAJAXRequete.prototype.bErreurServeur = function bErreurServeur()
{
	return this.__bHeaderHTTPExiste(this.sHeaderErreur);
};

// La methode d'invocation : appel en interne
WDAJAXRequete.prototype.xEnvoi = function xEnvoi(sRequete, sURL)
{
	// Calcul de l'URL si on est en mode GET (uniquement si la requete est non vide
	if (!this.m_bPost && (sRequete.length > 0))
	{
		// On ajoute un ? ou un &
		sURL += ((sURL.indexOf("?") == -1) ? "?" : "&") + sRequete;
	}

	// On passe en mode invalide => Notre reponse n'a pas de sens
	this.m_bValide = false;

	try
	{
		// Ouverture de la requete
		this.m_clRequete.open(this.m_bPost ? "POST" : "GET", sURL, !this.m_bSynchrone);

		// Ajoute l'encodage du POST
		this.m_clRequete.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

		// Puis envoie de la requete
		this.m_clRequete.send(this.m_bPost ? sRequete : "");
	}
	catch (e)
	{
		// GP 19/07/2013 : QW234126 : Transforme les erreurs natives en erreurs WL.
		throw new WDErreur(500, e.message);
	}
	// GP 29/08/2013 : IE ne lance pas une exception dans certains cas en cas d'erreur
	// D�tecte ce cas
	// GP 06/09/2013 : QW234820 : En cas de requ�te asynchrone, on ne test que si l'erreur n'est pas imm�diate.
	if (bIE && (this.readyStateComplete == this.m_clRequete.readyState) && (10000 < this.m_clRequete.status))
	{
		throw new WDErreur(500, this.m_clRequete.status);
	}
};

// Renvoi l'alphabet de la reponse si trouve
// Sinon renvoi l'alphabet du document
// Ne renvoie rien si le navigateur n'est pas IE
WDAJAXRequete.prototype.sGetDocRequeteAlphabet = function sGetDocRequeteAlphabet()
{
	// Par defaut on prend la valeur stocke dans le document
	var sAlphabet = document.charset;

	// Si pas IE => FIni
	if (!sAlphabet)
	{
		return undefined;
	}

	// On regarde si on a un type mine dans la requete
	try
	{
		var sHeader = this.m_clRequete.getResponseHeader("Content-type");

		// Si on trouve la marque du charset : on renvoie la suite
		if (sHeader && (0 < sHeader.indexOf("charset=")))
		{
			return sHeader.substring(sHeader.indexOf("charset=") + "charset=".length);
		}
		// Sinon on renvoie la valeur par defaut
	}
	catch(e)
	{
		// Pas de header, charset du document
	}
	return sAlphabet;
};

// verifie la validite du resultat d'une requete
// affiche l'erreur dans le navigateur
WDAJAXRequete.prototype.bValideResultat = function bValideResultat()
{
	this.m_bValide = false;

	// Le resultat n'est valide que si la requete a abouti
	if (this.m_clRequete.readyState !== this.readyStateComplete)
	{
		// La requ�te n'est pas encore finie
		return false;
	}

	// GP 02/04/2015 : TB87837 : Ajout du test pour le status 0 (la requ�te a �t� annul�e)
	var nStatus = this.m_clRequete.status;
	if (0 === nStatus)
	{
		return false;
	}

	// GP 12/01/2021 : Inverse la gestion des erreurs WEBDEV avec le test du status d'erreur.
	// Permet d'afficher l'erreur dans le cas de la fonction prologue qui refuse: retourne une erreur WEBDEV et un code 403.
	// Note : le cas redirection PHP ne pose pas de probl�me car alors le code n'est pas un code d'erreur.

	// Uniquement si on est pas dans un appel de JSONExecuteExterne :
	// - Le site est externe donc n'a potentiellement rien a voir.
	// - Et avec CORS on ne peut pas lire les ent�tes
	if (!this.m_bJSONExterne)
	{
		// Si il y a une redirection (Affichage d'une erreur PHP)
		if (this.bRedirectionPHP())
		{
			// On recupere la redirection
			var sRedirection = this.m_clRequete.responseText;
			// Execute la redirection
			// GP 21/05/2019 : QW312541 : unescape n'est pas bon (pas de gestion de l'UTF-8). C'est soit rien, soit decodeURI, soit decodeURIComponent.
			// decodeURI semble le bon code (on peut avoir une URL compl�te.
//			document.location.replace(unescape(sRedirection));
			document.location.replace(decodeURI(sRedirection));
			// Et r�sultat non valide
			return false;
		}

		// Si il y a une erreur WL du serveur
		if (this.bErreurServeur())
		{
			// Si il y a une erreur WL du serveur

			// Se libere soit meme
			var sAJAXNouvellePage = this.m_clRequete.responseText;

			// Si on est en internet exploreur il faut aussi injecter le charset sinon cela ne marche pas
			var sAlphabet = this.sGetDocRequeteAlphabet();
			this.Libere();
			// Marque l'AJAX comme plus disponible
			clWDAJAXMain.s_BloqueAJAX();

			var oDoc;
			// Methode qui ne marche pas en asynchrone : l'appel de open() arrete l'execution du script
			// Jamais de .open : cela ne marche pas dans certains navigateur
			if (bIE)
			{
				// On fait un cas particulier pour IE7
				if (nIE >= 7)
				{
					oDoc = document.open("text/html", "replace");
					if (sAlphabet)
					{
						oDoc.charset = sAlphabet;
					}
					oDoc.write(sAJAXNouvellePage);
					oDoc.close();
				}
				else
				{
					oDoc = document.open("text/html", "_self", "", true).document;
					if (sAlphabet)
					{
						oDoc.charset = sAlphabet;
					}
					clWDUtil.nSetTimeout(function() { oDoc.write(sAJAXNouvellePage); }, clWDUtil.ms_oTimeoutImmediat);
				}
			}
			else
			{
				oDoc = document;
				clWDUtil.nSetTimeout(function() { oDoc.write(sAJAXNouvellePage); if (sAlphabet) { oDoc.charset = sAlphabet; } document.close(); }, clWDUtil.ms_oTimeoutImmediat);
			}

			// On ne doit pas remplacer le document immediatement car sinon le reste du script en cours risque
			// de ne pas bien marcher (Erreur JS) dans certains navigateur (IE)
			return false;
		}
	}

	// Si on a eu une erreur HTTP, inutile d'aller plus loin
	if (400 <= nStatus)
	{
		return false;
	}

	// Valide le resultat
	this.m_bValide = true;
	return true;
};

// Recuperation du resultat en texte
WDAJAXRequete.prototype.sGetResultat = function sGetResultat(oPage)
{
	// Selon notre etat de validite
	if (this.m_bValide)
	{
		var sTexte = this.m_clRequete.responseText;
		var bAvecChamps = false;

		// Si on retourne du contenu AJAX
		if ((sTexte.substring(0, "<?xml".length) == "<?xml") && sTexte.match(clWDAJAXMain.XML_RACINERegExp))
		{
			var tabResultat = [];
			clWDAJAXMain.eReponseGenerique(this, oPage, null, tabResultat);
			bAvecChamps = true;
			sTexte = tabResultat[0];
		}

		// On blinde par une exception car certains navigateurs renvoient une exception si le header n'existe pas
		try
		{
			// On recupere l'entete d'information sur le nom XML de la requete
			var sNomXML = this.m_clRequete.getResponseHeader(this.sHeaderXML);
			// Si on a un nom alors on declare le document XML et on renvoi son nom
			if (sNomXML && sNomXML.length > 0)
			{
				// Ici declaration du document XML
				XMLAjoutDoc(sNomXML, bAvecChamps ? clWDAJAXMain.oGetXMLDepuisTexte(sTexte) : this.m_clRequete.responseXML);
				return sNomXML;
			}
		}
		catch (e)
		{
			// Pas de header, pas de reponse XML
		}

		// On renvoie la reponse bien encode pour le navigateur
		return sTexte;
	}
	else
	{
		return "";
	}
};

// La fonction d'initialisation : definie les callbacks
WDAJAXRequete.prototype.Init = function Init(oObjetRequeteTable)
{
	// On definie la fonction de changement d'etat uniquement si on est en mode asynchrone
	if (!this.m_bSynchrone)
	{
		// Memorise la table
		this.m_oObjetRequeteTable = oObjetRequeteTable;
		// Une reference sur nous meme
		var oThis = this;
		this.m_clRequete.onreadystatechange = function () { oThis.OnReadyState(window._PAGE_); };
	}
};

// Renvoie Vrai si la requete est en cours
WDAJAXRequete.prototype.bEnCours = function bEnCours()
{
	// On renvoie true si une callback est active
	return !!this.m_fCallback;
};

// Annule une requete asynchrone
WDAJAXRequete.prototype.Annule = function Annule()
{
	// On annule la callback
	delete this.m_fCallback;

	// IE 6 : Bloque le onreadystatechange (delete ne suffit pas) + Un = null ne fonctionne pas donc on met une fonction vide
	this.m_clRequete.onreadystatechange = clWDUtil.m_pfVide;

	// Et on se libere
	this.Libere();
};

// Fermeture de la requete : se libere du tableau global des requetes
WDAJAXRequete.prototype.Libere = function Libere()
{
	// Se libere du tableau
	clWDAJAXMain.SupprimeWDAJAXRequete(this.m_nId);

	// On libere nos membres par securite
	this.m_oObjetRequeteTable = null;
	delete this.m_oObjetRequeteTable;
	if (this.m_clRequete)
	{
		// Lance avant le abort pour ne pas recevoir l'evenement d'annulation
		delete this.m_clRequete.onreadystatechange;

		// Si le requete n'est pas terminee, l'annule (pour Firefox et le probleme des cancels qui abort l'appel suivant)
		if (bFF && (this.m_clRequete.readyState < this.readyStateComplete))
		{
			this.m_clRequete.abort();
		}
		delete this.m_clRequete;
	}

	// Actualise le temoin d'activite AJAX
	clWDAJAXMain.s_ReactualiseActivite(false);
};

// Classe de creation des requetes

var clWDAJAXMain = (function ()
{
	// Filtre les champs
	function __SurElementsAvecFiltre (tabElements, pfCallback, sFiltreNom)
	{
		clWDUtil.bForEach(tabElements, function (oElement)
		{
			// Toutes le requetes AJAX incluent WD_ACTION_ qui est deja specifie
			// On doit donc le filtrer, sinon cette valeur est deux fois dans la requete et le PHP renvoie uniquement la seconde valeur
			// On evite aussi les balises EMBED et autres qui n'ont pas de type et pas de valeur
			// On vire aussi les elements inutiles des treeview (les champs PTH_xxx)
			var sNomElement = oElement.name;
			if (	oElement.type
				&&	clWDAJAXMain.sCommandeWDAction !== sNomElement
				&&	"PTH_" !== sNomElement.substr(0, 4)
			// GP 21/01/2020 : Si sFiltre est undefined, l'utilisation de l'op�rateur !== fait que l'on ne filtre rien.
				&&	sFiltreNom !== sNomElement)
			{
				pfCallback(oElement);
			}

			return true;
		});
	}

	function __oAjouteValeurChamp(oChamp, oValeurs)
	{
		// GP 19/03/2014 : QW243909 : La g�n�ration HTML semble avoir chang�e et on a la table du calendrier avec comme ID l'alias du calendrier.
		// Sauf que getElementsByName retourne par ID en HTML4 vec IE.
		// Donc ici on a des �l�ments sans ID.
		if (oChamp.type)
		{
			// oValeur : chaine (cas g�n�ral) ou tableau (cas de la liste avec s�lection multiple)
			var oValeur;
			var bEncodeRC;
			// selon le type du champ
			switch (oChamp.type.toLowerCase())
			{
			case "textarea":
				// GP 02/05/2018 : TB101319 : Normalisation des RC. Voir https://dev.w3.org/html5/spec-preview/the-textarea-element.html
				// Pour faire simple : .value retourne des \n mais il faut retourner des \r\n dans le formulaire.
				bEncodeRC = true;
				// falls through
			case "text":
			case "hidden":
			case "password":
				// Champs qui retournent leur valeur
				oValeur = oChamp.value;
				// Ignore les champs avec indications
				if (oChamp.bIndication === true)
				{
					oValeur = "";
				}
				else if (bEncodeRC)
				{
					oValeur = oValeur.replace(ms_oRegExpC, "\r\n");
				}
				break;
			case "button":
				// Champ qui ne retournent rien
				break;
			case "checkbox":
			case "radio":
				// Check active
				if (oChamp.checked)
				{
					oValeur = oChamp.value;
				}
				// Sinon ne retourne rien
				break;
			case "select-one":
				if (oChamp.selectedIndex != -1)
				{
					oValeur = oChamp.options[oChamp.selectedIndex].value;
				}
				// Sinon ne retourne rien
				break;

			case "select-multiple":
				// GP 12/07/2018 : TB109561 : R�gression suite � la correction de TB107321 : En cas de multis�lection, on doit pouvoir sauver plusieurs valeurs.
				var tabSelectionMultiple = [];
				clWDUtil.bForEach(oChamp.options, function (oOption)
				{
					if (oOption.selected)
					{
						tabSelectionMultiple.push(oOption.value);
					}
					return true;
				});
				if (tabSelectionMultiple.length)
				{
					oValeur = tabSelectionMultiple;
				}
				break;
				// Autres champs mais moins frequents qui ne retournent rien
			case "file":
			case "reset":
			case "submit":
				break;
			default:
				oValeur = oChamp.value;
				break;
			}

			if (undefined !== oValeur)
			{
				oValeurs[oChamp.name] = oValeur;
			}
		}

		return oValeurs;
	}

	// Prochain ID de connection
	var ms_nNextID = 1;
	function __s_nGetNouvelID ()
	{
		return ms_nNextID++;
	}

	// Tableau des connexions
	var ms_tabConnexions = [];
	function __s_nCompareConnexion(oConnexion, nId)
	{
		return oConnexion.m_nId === nId;
	}

	var ms_nRequeteSynchrone = 0;

	function __TraiteAJAXExecuteEvenement ()
	{
		clWDAJAXMain.TraiteAJAXExecuteEvenement();
	}

	// S'il y a deux clics 'rapides' dans un bouton AJAX d'une zone repetee. Comme _JAEE est non bloquant (utilise un SetTimeout)
	// Alors il peut y avoir deux appels ) _JAZR + _JAEE qui s'empilent
	// Mais au lieu de s'executer dans l'ordre _JAZR, _JAEE, _JAEE_Interne, _JAZR, _JAEE, _JAEE_Interne
	// l'ordre est _JAZR, _JAEE, _JAZR, _JAEE, _JAEE_Interne, _JAEE_Interne. Comme un appel supprime la valeur surcharge par _JAZR
	// alors le second ne recoit rien et manipule la premiere ligne
	var ms_bBloque = false;
	// Drapeau qui indique si on peu encore utiliser les fonctions AJAX
	var ms_bValide = true;

	// T�moin d'activit� AJAX
	var ms_oActiviteChamp = null;
	var ms_bActivite = false;
	var ms_nActiviteOption = 0;
	// Met a jour le temoin d'activite AJAX
	function __ReactualiseActivite()
	{
		// Uniquement avec un t�moin d'activite AJAX
		if (ms_oActiviteChamp)
		{
			// Appel de la fonction clWDUtil.DeplaceElement pour le deplacement
			// GP 09/11/2012 : Placement en fixed
			clWDUtil.DeplaceElement(ms_oActiviteChamp, document, ms_nActiviteOption, undefined, undefined, true);
			// Et l'affiche
			ms_oActiviteChamp.style.visibility = ms_bActivite ? "inherit" : "hidden";
		}
	}

	// Patch le onclick d'un element
	var ms_oOnClick = {};
	function __PatchOnClick (oElement, sAliasChamp, rRegExp, fRemplace)
	{
		if (oElement.onclick)
		{
			// Pour le premier patch on doit manipuler le noeud mais ensuite on n'a une fonction et cela ne fonctionne pas
			var sOnClick = ms_oOnClick[sAliasChamp] || oElement.getAttributeNode("onclick").value;
			if (rRegExp.test(sOnClick))
			{
				sOnClick = sOnClick.replace(rRegExp, fRemplace);
				oElement.onclick = new Function("", sOnClick);
				ms_oOnClick[sAliasChamp] = sOnClick;
			}
		}
	}

	// GP 02/10/2014 : \s inclus d�j� \r et \n (mais pas \b). Sauf que \b est backspace pas la tabulation (\t) et que \t est inclus dans \s
//	var ms_oRegExpRCTabEspaces = new RegExp("[\\s\\r\\n\\b]", "g");
	var ms_oRegExpRCTabEspaces = new RegExp("[\\s]", "g");
	var ms_oRegExpRCTab = new RegExp("[\\r\\n\\t]", "g");
	var ms_oRegExpRC = new RegExp("[\\r\\n]", "g");
	var ms_oRegExpC = /\n/g;
	var ms_oRegExpEspacesMutliples = new RegExp("\\s(\\s)+", "g");
	var ms_oRegExpURLInput = new RegExp("\\(\\'([^\\']*)\\'", "");

	return {
	// Tableau des evenements AJAX a traiter
	m_tabRequetes: [],
	// Memorise si on est en mode AWP
	m_bPageAWP: (document.location.pathname.substr(document.location.pathname.length - 4, 4).toLowerCase() == ".awp"),

	// Les commandes disponibles
	sCommandeAjax_Execute: "WD_ACTION_=AJAXEXECUTE",
	sCommandeAjax_Champ: "WD_ACTION_=AJAXCHAMP",
	sCommandeAjax_Page: "WD_ACTION_=AJAXPAGE",
	sCommandeAjax_Erreur: "WD_ACTION_=AJAXERREUR",
	sCommandeWDAction: "WD_ACTION_",
	sCommandeAjax_ExecuteProc: "EXECUTEPROC",
	sCommandeAjax_ExecuteProcSChamps: "CHAMPS",
	sCommandeAjax_ExecuteProcSNonExclusif: "_NE",
	sCommandeAjax_Evenement: "EXECUTE",
	sCommandeAjax_Reglette: "SCROLLTABLE",
	sCommandeAjax_ClicTable: "CLICTABLE",
	sCommandeAjax_ActionChamp: "ACTIONCHAMP",
	sCommandeAjax_SaisieAssistee: "SAISIEASSISTEE",
	sCommandeAjax_PlanDiffere: "PLANDIFFERE",
	sCommandeAjax_ImageInformations: "IMAGEINFORMATIONS",
	sCommandeAjax_Contexte: "WD_CONTEXTE_",
	sCommandeAjax_SynchroniseVariables: "WD_VARIABLES_",

	ms_oRegExpRC:ms_oRegExpRC,

	// Options de AJAXExecuteSynchrone, AJAXExecuteAsynchrone et associ�es
	ms_nAJAXExecuteDefaut: 0x00000000,
	ms_nAJAXExecuteChamps: 0x00000001,
	ms_nAJAXExecuteNonExclusif: 0x00000002,
	ms_nAJAXExecuteSynchroniseVariables: 0x00000004,
	// Non dispo en WL
	ms_nAJAXExecuteJSONExterne: 0x40000000,

	XML_RACINE: "WAJAX",
	XML_RACINERegExp: new RegExp("<WAJAX>"),
	XML_JS: "JS",
	XML_REDIR: "REDIR",
//	XML_REDIR_HISTORIQUE: "HISTORIQUE",
	XML_CHAMP: "CHAMP",
	XML_LISTE: "LISTE",
	XML_RESULTAT: "RESULTAT",
	XML_TRACE: "TRACE",
	XML_TRACE_ID: "WDAJAX_TRACE",
	XML_LIENSOCIAL: "LIENSOCIAL",
	XML_LIENSOCIAL_FACEBOOK: 1,
	XML_LIENSOCIAL_TWEETER: 2,
	// GP 15/04/2019 : Plus de Google+.
//	XML_LIENSOCIAL_GOOGLEPLUS: 4,
	XML_LIENSOCIAL_LINKEDIN: 8,
	XML_VARSYNC: "VARSYNC",
	XML_GALERIESIDS: "GALERIESIDS",
	XML_CHAMP_ATT_ALIAS: "ALIAS",
	XML_CHAMP_ATT_TYPE: "TYPE",
	XML_CHAMP_TYPE_PAGEPRINCIPALE: 1,
//	XML_CHAMP_TYPE_SAISIE: 2, D�plac� dans WDChamp.prototype : ms_nIDObjetSaisie
//	XML_CHAMP_TYPE_LIBELLE: 3, D�plac� dans WDChamp.prototype : ms_nIDObjetLibelle
//	XML_CHAMP_TYPE_BOUTON: 4, D�plac� dans WDChamp.prototype : ms_nIDObjetBouton
//	XML_CHAMP_TYPE_INTERRUPTEUR: 5, D�plac� dans WDChamp.prototype : ms_nIDObjetInterrupteur
	XML_CHAMP_TYPE_SELECTEUR: 6,
	XML_CHAMP_TYPE_LISTE: 7,
//	XML_CHAMP_TYPE_IMAGE: 8, D�plac� dans WDChamp.prototype : ms_nIDObjetImage
	XML_CHAMP_TYPE_TABLE: 9,
	XML_CHAMP_TYPE_CHAMPFORMATE: 10,
	XML_CHAMP_TYPE_ZONEREPETEE: 11,
	XML_CHAMP_TYPE_HTML: 12,
//	XML_CHAMP_TYPE_COMBO: 14, D�plac� dans WDChamp.prototype : ms_nIDObjetCombo
	XML_CHAMP_TYPE_LIEN: 16,
	XML_CHAMP_TYPE_LIBELLEHTML: 17,
	XML_CHAMP_TYPE_WEBCAM: 20,
	XML_CHAMP_TYPE_REGLETTE: 21,
	XML_CHAMP_TYPE_MAPAREA: 22,
	XML_CHAMP_TYPE_CHEMINNAV: 23,
	XML_CHAMP_TYPE_TREEVIEW: 25,
	XML_CHAMP_TYPE_VIGNETTE: 26,
	XML_CHAMP_TYPE_IFRAME: 27,
	XML_CHAMP_TYPE_IFRAME_DEST: 31,
	XML_CHAMP_TYPE_IFRAME_SOURCE: 32,
	XML_CHAMP_TYPE_GRAPHE: 33,
	XML_CHAMP_TYPE_TIROIR: 34,
	XML_CHAMP_TYPE_TABLEHIERARCHIQUE: 35,
//	XML_CHAMP_TYPE_CELLULE: 39, D�plac� dans WDChamp.prototype : ms_nIDObjetCellule
	XML_CHAMP_TYPE_SUPERCHAMP: 40,
	XML_CHAMP_TYPE_MODELEDECHAMP_SOURCE: 42,
	XML_CHAMP_TYPE_MODELEDECHAMP_DEST: 43,
	XML_CHAMP_TYPE_ONGLET: 44,
	XML_CHAMP_TYPE_PLANSITE: 45,
	XML_CHAMP_TYPE_CALENDRIER: 47,
	XML_CHAMP_TYPE_VOLETONGLET: 49,
	XML_CHAMP_TYPE_SOUSMENU: 55,
	XML_CHAMP_TYPE_COLONNETABLE: 56,
	XML_CHAMP_TYPE_OPTIONMENU: 57,
	XML_CHAMP_TYPE_COLONNETABLEH: 68,
	XML_CHAMP_TYPE_RANGESLIDER: 72,
	XML_CHAMP_TYPE_AGENDA: 76,
	XML_CHAMP_TYPE_ZONEREPETEEHORIZONTALE: 77,
	XML_CHAMP_TYPE_VIDEO: 78,
	XML_CHAMP_TYPE_PAGECORNEE: 79,
	XML_CHAMP_TYPE_PLANNING: 80,
	XML_CHAMP_TYPE_CAPTCHA: 82,
	XML_CHAMP_TYPE_JAUGE: 83,
	XML_CHAMP_TYPE_CELLULEMISEENPAGE: 84,
	XML_CHAMP_TYPE_RATING: 85,
	XML_CHAMP_TYPE_POPUP: 90,
	XML_CHAMP_TYPE_CARTE: 92,
	XML_CHAMP_TYPE_POTENTIOMETRE: 100,
	XML_CHAMP_TYPE_LIENSOCIAL: 103,
	XML_CHAMP_TYPE_MENUPOPUP: 105,
	XML_CHAMP_TYPE_ZONETEXTE: 109,
	XML_CHAMP_TYPE_TABLEAUDEBORD: 111,
	XML_CHAMP_TYPE_BARRENAVIGATION_CELL: 115,
	XML_CHAMP_TYPE_BARRENAVIGATION: 117,
	XML_CHAMP_TYPE_BANDEAU_DEFILANT: 122,
	XML_CHAMP_TYPE_EDITEUR_IMAGE: 124,
//	XML_CHAMP_TYPE_DISPOSITION: 126,		// Pas encore r�f�renc� dans le code
	XML_CHAMP_TYPE_DISPOSITION_CELLULE: 127,
	XML_CHAMP_TYPE_EDITEUR_DIAGRAMME: 130,
//	XML_CHAMP_TYPE_INTERRUPTEUR_BASCULE: 132, D�plac� dans WDChamp.prototype : ms_nIDObjetInterrupteurABascule
//	XML_CHAMP_TYPE_OPTION_INTERRUPTEUR_BASCULE: 133, // Pas encore r�f�renc� dans le code
	// @@@ Ici nouveau champ si besoin
	XML_CHAMP_ETAT_ETAT: "ETAT",
	XML_CHAMP_JS: "JS",
	XML_CHAMP_LIGNES: "LIGNES",
	XML_CHAMP_LIGNES_COLONNES: "COLONNES",
	XML_CHAMP_LIGNES_DATA: "DATA",
	XML_CHAMP_LIGNES_DEBUT: "DEBUT",
	XML_CHAMP_LIGNES_LIGNE: "LIGNE",
	XML_CHAMP_LIGNES_LIGNE_CORPS: "CORPS",
	XML_CHAMP_LIGNES_LIGNE_DEBUT: "DEBUT",
	XML_CHAMP_LIGNES_LIGNE_FIN: "FIN",
	XML_CHAMP_LIGNES_LIGNE_INDICE: "INDICE",
	XML_CHAMP_LIGNES_LIGNE_INVISIBLE: "INVISIBLE",
	XML_CHAMP_LIGNES_LIGNE_REPLIEE: "REPLIEE",
	XML_CHAMP_LIGNES_LIGNE_STYLE: "STYLE",
	XML_CHAMP_LIGNES_NBREPLIEES: "NBREPLIEES",
	XML_CHAMP_LIGNES_NOMBRE: "NOMBRE",
	XML_CHAMP_LIGNES_RUPTURES: "RUPTURES",
	XML_CHAMP_LIGNES_SELECTION: "SELECTION",
	XML_CHAMP_LIGNES_STYLE: "STYLE",
	XML_CHAMP_OPTIONS: "OPTIONS",
	XML_CHAMP_OPTIONS_OPTION: "OPTION",
	XML_CHAMP_OPTIONS_OPTION_COCHE: "COCHE",
	XML_CHAMP_OPTIONS_OPTION_HTML: "HTML",
	XML_CHAMP_PROP: "PROP",
	XML_CHAMP_PROP_ATT_NUM: "NUM",
	XML_CHAMP_PROP_NUM_LIBELLE_TABLE_AJAX: "TABLE_AJAX",
	XML_CHAMP_PROP_NUM_VISIBLE_PARENTRELATIF: "PARENTRELATIF",
	XML_CHAMP_PROP_NUM_VISIBLE_PARENTFLUX: "PARENTFLUX",
	XML_CHAMP_RECHARGE: "RECHARGE",
	XML_CHAMP_RECHARGE_PARAM: "PARAM",
	XML_CHAMP_REFRESH: "REFRESH",
	XML_CHAMP_REFRESH_DATA: "DATA",
	XML_CHAMP_REFRESH_DEBUT: "DEBUT",
	XML_CHAMP_REFRESH_NOMBRE: "NOMBRE",
	XML_CHAMP_REFRESH_RESETTABLE: "RESETTABLE",
	// GP 09/04/2019 : TB112974 : Il faut transmettre la colonne de tri si elle a chang�e (sinon on perd la modification sur le serveur puisque le navigateur va redemander cette colonne).
	XML_CHAMP_REFRESH_TRI: "TRI",
	XML_CHAMP_REFRESH_SENS: "SENS",
	XML_CHAMP_SAISIEA: "SAISIEA",
	XML_CHAMP_SAISIEA_FILTRE: "FILTRE",
	XML_CHAMP_SAISIEA_OUVERTUREAUTO: "OUVERTUREAUTO",
	XML_CHAMP_SAISIEA_TAILLEMIN: "TAILLEMIN",
	XML_CHAMP_SAISIEA_DELAI: "DELAI",
	XML_CHAMP_SAISIEA_SANSCASSE: "SANSCASSE",
	XML_CHAMP_SAISIEA_OPTION: "OPTION",
	XML_CHAMP_SAISIEA_SANSOPTION: "SANSOPTION",
	XML_CHAMP_SAISIEAJETON: "SAISIEAJETON",
	XML_CHAMP_SATURATION: "SATURATION",
	XML_CHAMP_TREEVIEW: "TREEVIEW",
	XML_CHAMP_TREEVIEW_DEROULE: "DEROULE",
	XML_CHAMP_TREEVIEW_DEROULETAB: "DEROULETAB",
	XML_CHAMP_TREEVIEW_NOEUDS: "NOEUDS",
	XML_CHAMP_TREEVIEW_SELECT: "SELECT",

	XML_WBTRACE_ID: "WB_TRACE",

	// Indique si le mode AJAX est temporairement bloque
	bWDAJAXMainValide: function bWDAJAXMainValide()
	{
		// Si on est dans le onunload de IE et que une autre page est affichee, l'etat recu est "loading"
		// Mais l'AJAX est encore completement disponible
		// Donc on utilise une variable qui indique que l'on a reussi une fois et que c'est bon
		if (!this.m_bChargementTermine)
		{
			// Bloque si le document n'est pas completement charge
			// Ca tombe bien on n'a le probleme que sous IE et document.readyState n'existe que sous IE
			if (document.readyState)
			{
				if ((document.readyState != "interactive") && (document.readyState != "complete"))
				{
					// Le chargement n'est pas termine
					return false;
				}
			}
			// On considere que le document est charge
			this.m_bChargementTermine = true;

			// C'est la premiere fois que l'on trouve le document charge
			// On se branche sur le beforeunload dans le cas de Firefox
			// En effet dans le cas d'une page qui execute de l'AJAX automatiquement (une table AJAX par exemple)
			// et que le code de onload fait un submit via un bouton, Firefox cancel les appels AJAX mais aussi l'affichage de la
			// page suivante ce qui donne une page blanche
			// Donc on bloque l'AJAX avant le dechargement
			if (bFF)
			{
				// GP 28/03/2014 : Diverses fiches : le comportement ne semble plus se reproduire avec les Firefox r�cents
				// => D�sactive ce comportement sur les version r�centes de Firefox.
				var oRes = (new RegExp("Fire[Ff]ox/\\s*(\\d+)\\.*(\\d+)")).exec(navigator.userAgent);
				if (!oRes || !oRes[1] || (parseInt(oRes[1], 10) < 27))
				{
					clWDUtil.AttacheDetacheEvent(true, window, "beforeunload", this.s_BloqueAJAX, true);
				}
			}
		}

		// Renvoie la variable globale
		// Ce n'est pas la peine de tester this.m_bChargementTermine car si on arrive ici c'est que this.m_bChargementTermine == true
		return ms_bValide;
	},

	// Bloque le mode AJAX : remplacement de la page courante
	s_BloqueAJAX: function s_BloqueAJAX()
	{
		// Supprime le temoin d'activite
		ms_oActiviteChamp = null;
		ms_bActivite = false;

		// Met le flag a faux
		ms_bValide = false;

		// Et supprime toutes les requetes asynchrones en cours
		while (0 < ms_tabConnexions.length)
		{
			ms_tabConnexions[0].Libere();
		}
	},

	// CRee un objet XMLHttpRequest
	clCreeXMLHttpRequest: function clCreeXMLHttpRequest()
	{
		// On teste l'objet natif
		if (window.XMLHttpRequest)
		{
			try
			{
				return new XMLHttpRequest();
			}
			catch (e)
			{
			}
		}
		// On teste l'objet ActiveX pour IE/Windows
		if (window.ActiveXObject)
		{
			try
			{
				return new ActiveXObject("Msxml2.XMLHTTP");
			}
			catch (e)
			{
			}
			try
			{
				return new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch (e)
			{
			}
		}
		// Echec
		return null;
	},

	// Creation d'un objet WDAJAXRequete
	// Mettre bSansInit pour faire une initialisation personnalise
	clCreeWDAJAXRequete: function clCreeWDAJAXRequete(bPost, bSynchrone, oObjetRequeteTable)
	{
		// Pseudo parametres par defaut
		if (bPost == null)
		{
			bPost = true;
		}
		if (bSynchrone == null)
		{
			bSynchrone = false;
		}

		// On commence par cree la requete
		var clRequete = this.clCreeXMLHttpRequest();
		// Si pas de requete (AJAX pas disponible => Fin)
		if (!clRequete)
		{
			return null;
		}
		// Puis on cree l'objet
		var clWDAJAXRequete = new WDAJAXRequete(__s_nGetNouvelID(), clRequete, bPost, bSynchrone);
		// Et on l'init
		clWDAJAXRequete.Init(oObjetRequeteTable);

		// On l'enregistre dans le tableau des connections si c'est une connexion asynchrone
		if (!bSynchrone)
		{
			ms_tabConnexions.push(clWDAJAXRequete);
		}

		// Puis on retourne l'objet
		return clWDAJAXRequete;
	},

	// Recherche un objet WDAJAXRequete
	GetWDAJAXRequete: function GetWDAJAXRequete(nId)
	{
		return clWDUtil.oDansTableauFct(ms_tabConnexions, __s_nCompareConnexion, nId, null);
	},

	// Supprime une requ�te du tableau
	SupprimeWDAJAXRequete: function SupprimeWDAJAXRequete(nId)
	{
		clWDUtil.SupprimeDansTableauFct(ms_tabConnexions, __s_nCompareConnexion, nId);
	},

	// Traite un requete
	eReponseGenerique: function eReponseGenerique(oRequete, oPage, oObjetRequeteTable, tabResultat)
	{
		// Si le resulat est valide
		if (oRequete.bValideResultat())
		{
			return this.__eReponseGenerique(oRequete, oPage, oObjetRequeteTable, oRequete.m_clRequete.responseText, oRequete.m_clRequete.responseXML, oRequete.sGetDocRequeteAlphabet(), tabResultat);
		}
		else
		{
			return 0;	// 0 == Echec
		}
	},

	// R�cup�re un XML depuis du texte
	oGetXMLDepuisTexte: function oGetXMLDepuisTexte(sTexte)
	{
		if (sTexte && sTexte.length)
		{
			if (window.DOMParser)
			{
				var oParser = new DOMParser();
				if (oParser)
				{
					return oParser.parseFromString(sTexte, "text/xml");
				}
			}
			else if (window.ActiveXObject)
			{
				var oXML = new ActiveXObject("Microsoft.XMLDOM");
				if (oXML)
				{
					oXML.loadXML(sTexte);
					// GP 09/09/2014 : QW247520 : Il y a eu une mauvaise inversion du test :
					//	!((oXML.parseError != null) && (oXML.parseError.errorCode != 0))
					// =>
					//	((!oXML.parseError) || (0 == oXML.parseError.errorCode))
					// et pas
					//	((!oXML.parseError) && (0 == oXML.parseError.errorCode))
//					if ((!oXML.parseError) && (0 == oXML.parseError.errorCode))
					if ((!oXML.parseError) || (0 == oXML.parseError.errorCode))
					{
						return oXML;
					}
				}
			}
		}

		return null;
	},

	// Traite un requete depuis du texte
	eReponseGeneriqueDepuisTexte: function eReponseGeneriqueDepuisTexte(sTexte, oPage, tabResultat)
	{
		var oXML = this.oGetXMLDepuisTexte(sTexte);
		if (oXML)
		{
			return this.__eReponseGenerique(null, oPage, null, sTexte, oXML, document.charset, tabResultat);
		}
		else
		{
			return 0;	// 0 = Echec
		}

	},

	// Effectue l'analyse d'une requete (factorisation avec le code de l'upload AJAX)
	bValideEtTraiteErreur : function bValideEtTraiteErreur (clRequete, sTexte, sAlphabet)
	{
		// Si on n'a pas en reponse XML a nous (Par exemple avec l'utilisation de PageAffiche)
		if ((sTexte.substring(0, "<?xml".length) != "<?xml") || !sTexte.match(this.XML_RACINERegExp))
		{
			var sNouvellePage = sTexte;

			// Se libere soit meme
			if (clRequete)
			{
				clRequete.Libere();
				clRequete = null;
			}
			// Marque l'AJAX comme plus disponible
			this.s_BloqueAJAX();

			// Et ecrit le document
			// Jamais de .open : cela ne marche pas dans certains navigateur
			if (bIE)
			{
				var oDoc = document.open("text/html", "replace");
				if (sAlphabet)
				{
					// En IE on doit redefinir le charset sinon on a un probleme
					oDoc.charset = sAlphabet;
				}
				oDoc.write(sNouvellePage);
				if (nIE >= 7)
				{
					oDoc.close();
				}
			}
			else
			{
				oDoc = document;
				clWDUtil.nSetTimeout(function() { oDoc.write(sNouvellePage); if (sAlphabet) { oDoc.charset = sAlphabet; } oDoc.close(); }, clWDUtil.ms_oTimeoutImmediat);
			}

			// Invalide
			return false;
		}
		else
		{
			// Valide
			return true;
		}
	},

	// Traite un requete
	__eReponseGenerique: function __eReponseGenerique(clRequete, oPage, oObjetRequeteTable, sTexte, oXML, sAlphabet, tabResultat)
	{
		// Si on n'a pas en reponse XML a nous (Par exemple avec l'utilisation de PageAffiche)
		if (this.bValideEtTraiteErreur(clRequete, sTexte, sAlphabet))
		{
			// On traite le resultat de la requete
			return this.eActionXML(oPage, oObjetRequeteTable, oXML, tabResultat);
		}
		else
		{
			// Requete invalide mais on retourne true (c'est le code historique)
			return 1;	// 1 = R�ussite
		}
	},

	// Construit la valeur du champ
	sConstruitValeurChampNom: function sConstruitValeurChampNom(oPage, sChamp)
	{	// on cherche le champ
		var oChamp = this.__oChercheChamp(oPage, sChamp);
		// on construit la valeur du champ
		return oChamp ? this.sConstruitValeurChamp(oChamp) : "";
	},

	// Construit la valeur du champ avec un separateur pour la concatenation
	sConstruitValeurChampNomSep: function sConstruitValeurChampNomSep(oPage, sChamp)
	{
		// Rebond sur la methode simple
		var sValeur = this.sConstruitValeurChampNom(oPage, sChamp);
		// Complete si besoin
		return (sValeur.length > 0) ? ("&" + sValeur) : sValeur;
	},

	sConstruitValeursChamps : function sConstruitValeursChamps (oValeurs)
	{
		var tabResultat = [];
		clWDUtil.bForEachIn(oValeurs, function (sNom, oValeur)
		{
			function __EncodeUneValeur(oUneValeur)
			{
				// On encode si possible les caractere UNICODEs
				tabResultat.push(encodeURIComponent(sNom) + "=" + encodeURIComponent(oUneValeur));
				return true;
			}

			// GP 12/07/2018 : TB109561 : R�gression suite � la correction de TB107321 : En cas de multis�lection, on doit pouvoir sauver plusieurs valeurs.
			// oValeur : chaine (cas g�n�ral) ou tableau (cas de la liste avec s�lection multiple)
			if (oValeur instanceof Array)
			{
				clWDUtil.bForEach(oValeur, __EncodeUneValeur);
			}
			else
			{
				__EncodeUneValeur(oValeur);
			}
			return true;
		});
		return tabResultat.join("&");
	},

	// Construit la valeur du champ
	sConstruitValeurChamp: function sConstruitValeurChamp(oChamp)
	{
		return this.sConstruitValeursChamps(__oAjouteValeurChamp(oChamp, {}));
	},

	// construit les valeurs de tous les champs de la page
	sConstruitValeurPage: function sConstruitValeurPage(tabElements, sFiltreNom /*= undefined*/)
	{
		// On parcours les champs de la page pour construire la requete
		var tabResultat = [];
		__SurElementsAvecFiltre(tabElements, function (oElement)
		{
			// On rajoute le separateur si le dernier caratere n'en est pas deja un &
			// Et on contruit la valeur du champ avec
			var sValeur = clWDAJAXMain.sConstruitValeurChamp(oElement);
			// Supprime les & en fin (d�j� fait avant => mais quelle est l'utilit�e)
			while ("&" === sValeur.charAt(sValeur.length - 1))
			{
				sValeur = sValeur.substr(0, sValeur.length - 1);
			}
			if (sValeur.length)
			{
				tabResultat.push(sValeur);
			}
		}, sFiltreNom);
		return tabResultat.join("&");
	},
	oCompleteValeurPage: function oCompleteValeurPage(tabElements, oValeurs, sFiltreNom /*= undefined*/)
	{
		// On parcours les champs de la page pour construire la requete
		__SurElementsAvecFiltre(tabElements, function(oElement)
		{
			__oAjouteValeurChamp(oElement, oValeurs);
		}, sFiltreNom);
		return oValeurs;
	},

	// construit l'URL pour appeler une procedure AJAX
	sConstruitURL: function sConstruitURL(sURL)
	{	// on renvoie l'URL
		return sURL;
	},

	// Construit la requete pour appeler une procedure AJAX
	sConstuitRequeteProcedure: function sConstuitRequeteProcedure(sProcedure, sContexte, nOptions)
	{
		var sCommandeAJAX = this.sCommandeAjax_ExecuteProc;
		if (0 != (nOptions & this.ms_nAJAXExecuteChamps))
		{
			sCommandeAJAX += this.sCommandeAjax_ExecuteProcSChamps;
		}
		if (0 != (nOptions & this.ms_nAJAXExecuteNonExclusif))
		{
			sCommandeAJAX += this.sCommandeAjax_ExecuteProcSNonExclusif;
		}

		// construction de la requete AJAX
		//	- action AJAX (non specifique)
		var sRequete = this.sCommandeAjax_Execute;
		//	- commande AJAX (non specifique)
		sRequete += "&" + sCommandeAJAX + "=" + encodeURIComponent(sProcedure);
		//	- contexte d'execution (specifique)
		sRequete += "&" + this.sCommandeAjax_Contexte + "=" + encodeURIComponent(sContexte);
		//	- Synchronisation des variables (sp�cifique)
		if ((0 != (nOptions & this.ms_nAJAXExecuteSynchroniseVariables)) && window.NSPCS)
		{
			var sReporteVariableServeur = NSPCS.NSChamps.ms_oSynchronisationServeur.sGetReporteVariableServeur();
			if (sReporteVariableServeur)
			{
				sRequete += "&" + this.sCommandeAjax_SynchroniseVariables + "=" + encodeURIComponent(sReporteVariableServeur);
			}
		}
		// on renvoie la requete creee
		return sRequete;
	},

	// Construit la requete pour la recherche dans une table
	sConstuitRequeteTable: function(sRequeteTable)
	{	// Construction de la requete AJAX
		//	- Action AJAX (non specifique)
		var sRequete = this.sCommandeAjax_Execute;
		//	- Commande AJAX (non specifique)
		if (sRequeteTable.length > 0)
		{
			sRequete += "&" + sRequeteTable;
		}
		// On renvoie la requete creee
		return sRequete;
	},

	// Construit la requete pour appeler l'etat d'une jauge => tout est dans l'URL
	sConstuitURLRequeteJauge: function sConstuitURLRequeteJauge(sAliasJauge)
	{
		// La requete n'est pas une requete AJAX classique.
		// La requete passe par AJAX mais ca n'en est pas une
		return this.sConstruitURL(clWDUtil.sGetPageAction()) + "/JAUGE/" + document.forms[0].name + "." + sAliasJauge;
	},

	// Defini le nom du champ du formulaire dont on doit transmettre la valeur en plus lors d'un envoi sans submit
	SetZRChamp: function(sZRChamp, sValeur)
	{
		if (this.m_sZRChamp)
		{
			// Bloque l'appel de AJAXExecuteEvenement qui suit immediatement
			ms_bBloque = true;
			return;
		}

		this._SetZRChamp(sZRChamp, sValeur);
	},
	SetZRChampEnrouleDeroule: function(oPage, sZRChamp, nLigne, nRupture)
	{
		if (this.m_sZRChamp || this.m_nRupture)
		{
			return;
		}

		this._SetZRChamp(sZRChamp, "" + nLigne);
		this.m_nRupture = nRupture;
		this.AJAXExecuteEvenement(oPage, sZRChamp, 'ENDETABLE', 10);
	},
	_SetZRChamp: function(sZRChamp, sValeur)
	{
		this.m_sZRChamp = sZRChamp;
		this.m_sZRChampValeur = sValeur;
	},
	// construit la requete pour appeler un evenement AJAX
	sConstuitRequeteEvenement: function(oPage, sChamp, nEvenement, nOption)
	{	// construction de la requete AJAX selon les options
		var tabRequete = [];
		var sValeur = "";
		// Si sChamp est deux alias (cas du clic des colonnes ou l'on a ALIASCOLONNE;ALIASTABLE
		var sChampSecondaire = sChamp;
		if ((undefined !== sChamp) && sChamp.length && (0 < sChamp.indexOf(";")))
		{
			var tabAliasChamp = sChamp.split(";");
			if ((1 < tabAliasChamp.length) && (tabAliasChamp[0].length) && (tabAliasChamp[1].length))
			{
				sChamp = tabAliasChamp[0];
				sChampSecondaire = tabAliasChamp[1];
			}
		}
		switch (nOption)
		{
		// on envoie la valeur du champ courant
		case 1:
			// action AJAX
			tabRequete.push(this.sCommandeAjax_Champ);
			// evenement
			tabRequete.push(this.sCommandeAjax_Evenement + "=" + nEvenement);
			// champ
			tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
			// Valeur du champ
			sValeur = this.sConstruitValeurChampNom(oPage, sChamp);
			// Si on a indique (via _JAZR) de transmettre en plus l'occurrence courante de la ZR du champ : on la transmet
			if (this.m_sZRChamp)
			{
				tabRequete.push(encodeURIComponent(this.m_sZRChamp) + "=" + encodeURIComponent(this.m_sZRChampValeur));
			}
			break;

		// on envoie la valeur de tous les champs de la page
		case 2:
			// action AJAX
			tabRequete.push(this.sCommandeAjax_Page);
			// evenement
			tabRequete.push(this.sCommandeAjax_Evenement + "=" + nEvenement);
			// champ
			tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
			// GP 21/01/2020 : Probl�me de AA : Si on a indique (via _JAZR) de transmettre en plus l'occurrence courante de la ZR du champ : on la transmet.
			// En effet, selon les cas, la g�n�ration HTML n'a pas mis la s�lection de la ligne courante dans l'action.
			// Note : la bonne correction serait de TOUJOURS s�lectionner la ligne courante de ZR en cas d'action utilisateur.
			// Mais ce n'est pas encore ce que fait WDxxxHtml et la correction est complexe.
			if (this.m_sZRChamp)
			{
				tabRequete.push(encodeURIComponent(this.m_sZRChamp) + "=" + encodeURIComponent(this.m_sZRChampValeur));
			}
			// Valeurs des champs de la page
			sValeur = this.sConstruitValeurPage(oPage.elements, this.m_sZRChamp);
			break;

		// Clic sur une reglette mais sans submit
		case 3:
			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Execute);
			// Evenement
			tabRequete.push(this.sCommandeAjax_Reglette + "=" + sChamp);
			// Champ reglette
			tabRequete.push(sChamp + "=" + nEvenement);
			break;

		// Clic sur une reglette avec submit
		case 4:
			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Page);
			// Evenement
			tabRequete.push(this.sCommandeAjax_Reglette + "=" + sChamp);
			// Champ reglette. A priori cette valeur est en double car deja dans le submit de la page donc on ne la me pas
			var oChampReglette = oPage[sChamp];
			if (oChampReglette)
			{
				oChampReglette.value = nEvenement;
			}
			// valeurs des champs de la page
			sValeur = this.sConstruitValeurPage(oPage.elements);
			break;

		// Selection d'une ligne de table
		case 5:
			// sChamp est de la forme ALIASCOLONNE;ALIASTABLE

			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Page);
			// Evenement
			tabRequete.push(this.sCommandeAjax_ClicTable + "=" + sChamp);
			// Valeurs des champs de la page
			sValeur = this.sConstruitValeurPage(oPage.elements);
			break;

		// Selection d'une ligne de table sans submit
		case 6:
			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Champ);
			// Evenement
			tabRequete.push(this.sCommandeAjax_ClicTable + "=" + sChamp);
			// Valeur du champ
			// Utilisation de sChampSecondaire qui a le nom de la table.
			sValeur = this.sConstruitValeurChampNom(oPage, sChampSecondaire);
			break;

        // Ex commande d'initialisation des gadgets vista
//		case 7:

		// Action sur un champ calendrier
		case 8:
			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Champ);
			// Evenement
			tabRequete.push(this.sCommandeAjax_ActionChamp + "=" + (nEvenement ? nEvenement : ""));
			// Champ
			tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
			// Valeur du champ
			sValeur = this.sConstruitValeurChampNom(oPage, sChamp);
			var oVarChamp = oGetObjetChamp(sChamp);
			tabRequete.push(this.sConstruitValeurChamp(oVarChamp.oGetElementHTMLValeur()));
			tabRequete.push(this.sConstruitValeurChamp(oVarChamp.oGetElementHTMLMois()));
			// Si le champ est dans une ZR, declenche la selection de la ligne de ZR
			if (oVarChamp.bGestionTableZR_SansPopup())
			{
				tabRequete.push(this.sConstruitValeurChampNom(oPage, oVarChamp.m_sAliasTableZRParent));
			}
			break;

		// Action sur un champ agenda ou planning
		case 9:
			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Champ);
			// Evenement
			tabRequete.push(this.sCommandeAjax_ActionChamp + "=" + (nEvenement ? nEvenement : ""));
			// Champ
			tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
			// Valeur du champ
			sValeur = this.sConstruitValeurChamp(oGetObjetChamp(sChamp).m_oChampFormulaire);
			break;

		// Enroule/Deroule de ligne de ZR AJAX
		case 10:
			if (undefined != this.m_nRupture)
			{
				// Action AJAX
				tabRequete.push(this.sCommandeAjax_Champ);
				// Evenement
				tabRequete.push(this.sCommandeAjax_ActionChamp + "=" + (nEvenement ? nEvenement : ""));
				// Champ
				tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
				// Parametre (rupture enroulee)
				// Temporaire : passe par une variable globale
				tabRequete.push("WD_PARAM_=" + this.m_nRupture);
				// Valeur du champ
				tabRequete.push(encodeURIComponent(this.m_sZRChamp) + "=" + encodeURIComponent(this.m_sZRChampValeur));
				// Valeur du champ
				var sChampData = this.sConstruitValeurChampNom(oPage, this.m_sZRChamp + "_DATA");
				if (sChampData.length)
				{
					tabRequete.push(sChampData);
				}
			}
			else
			{
				return "";
			}
			break;

		case 11:
			// Saisie assist�e
			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Champ);
			// Evenement
			tabRequete.push(this.sCommandeAjax_SaisieAssistee + "=" + sChamp);
			// Valeur du champ
			sValeur = this.sConstruitValeurChampNom(oPage, sChamp);
			break;

		case 12:
			// Changement de plan
			if (window["NSPCS"])
			{
				NSPCS.NSChamps.ms_oSynchronisationServeur.OnSubmit();
				// Action AJAX
				tabRequete.push(this.sCommandeAjax_Champ);
				// Evenement
				tabRequete.push(this.sCommandeAjax_ActionChamp + "=" + nEvenement);
				// Champ
				tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
				// Valeur du champ
				sValeur = this.sConstruitValeurChampNom(oPage, NSPCS.NSChamps.ms_oSynchronisationServeur.m_oChamp.name);
			}
			break;

		case 13:
			// Changement de plan dans un champ bandeau d�filant (ce n'est pas un vrai changement de plan mais un changement de valeur)
			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Champ);
			// Evenement
			tabRequete.push(this.sCommandeAjax_ActionChamp + "=" + nEvenement);
			// Champ
			tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
			// Valeur du champ
			sValeur = this.sConstruitValeurChampNom(oPage, sChamp);
			break;

		case 14:
			// Changement de plan
			if (window["NSPCS"])
			{
				NSPCS.NSChamps.ms_oSynchronisationServeur.OnSubmit();
				// Changement de plan en diff�r�
				// Action AJAX
				tabRequete.push(this.sCommandeAjax_Page);
				// Evenement
				tabRequete.push(this.sCommandeAjax_PlanDiffere + "=" + nEvenement);
				// Champ
				tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
				// Valeurs des champs de la page
				sValeur = this.sConstruitValeurPage(oPage.elements);
			}
			break;

		case 15:
			// Informe le serveur d'informations a mettre en cache pour les images d'une galerie
			if (window["NSPCS"])
			{
				// Action AJAX : pas de submit
				tabRequete.push(this.sCommandeAjax_Execute);
				// Evenement
				tabRequete.push(this.sCommandeAjax_ImageInformations + "=");
				// Pas de contexe
//				tabRequete.push(ms_sCommandeContexte + "=" + sAlias);
				// Les valeurs sont l'ensemble des couples "Cl�+Valeur"
//				sValeur = "";
				clWDUtil.bForEachIn(nEvenement, function(sID, oInformations)
				{
					// Le pr�fixe II_ est pour faciliter le filtrage des autres param�tres param�tres.
					tabRequete.push("II_" + sID + "=" + encodeURIComponent(JSON.stringify(oInformations)));
					return true;
				});
			}
				break;

		case 16:
			// Pour :
			// - Ajout d'�l�ments suppl�mentaires dans une table/zone r�p�t�e infinie.
			// - Clic d'ent�te de colonne de table.
			if (window["NSPCS"])
			{
				NSPCS.NSChamps.ms_oSynchronisationServeur.OnSubmit();
			}
			// Action AJAX
			tabRequete.push(this.sCommandeAjax_Page);
			// Evenement
			tabRequete.push(this.sCommandeAjax_ActionChamp + "=" + nEvenement);
			// Champ
			tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
			// Valeurs des champs de la page
			sValeur = this.sConstruitValeurPage(oPage.elements);
			break;

		// on ne renvoie aucune valeur
		default:
			{
				// Si on a indique (via _JAZR) de transmettre en plus l'occurrence courante de la ZR du champ : on la transmet
				if (this.m_sZRChamp)
				{
					sValeur = encodeURIComponent(this.m_sZRChamp) + "=" + encodeURIComponent(this.m_sZRChampValeur);
				}
				// Action AJAX
				tabRequete.push((sValeur != "") ? this.sCommandeAjax_Champ : this.sCommandeAjax_Execute);
				// evenement
				tabRequete.push(this.sCommandeAjax_Evenement + "=" + nEvenement);
				// champ
				tabRequete.push(this.sCommandeAjax_Contexte + "=" + sChamp);
				break;
			}
		}
		// Si on a une valeur : l'ajoute
		if ((sValeur !== undefined) && (sValeur.length > 0))
		{
			tabRequete.push(sValeur);
		}

		// Dans tous les cas (Que la valeur soit traite ou non) on supprime la reference a la ZR a transmettre en plus
		delete this.m_sZRChamp;
		delete this.m_sZRChampValeur;
		delete this.m_nRupture;

		// Si la fonction existe dans la page : effectue les operations apres submit AJAX
		if (typeof window.FinSubmitAJAX == "function")
		{
			FinSubmitAJAX();
		}

		// Renvoie la requete
		return tabRequete.join("&");
	},

	// AJAXDisponible
	// renvoie TRUE si AJAX est disponible sur ce navigateur
	AJAXDisponible: function()
	{
		// Si pas encore teste
		if (this.m_bAJAXDisponible === undefined)
		{
			// On essaie de creer une requete
			var clRequete = this.clCreeXMLHttpRequest();
			// AJAX est disponible si on a pu creer la requete
			this.m_bAJAXDisponible = (clRequete != null);
			clRequete = null;
		}
		// On retourne la valeur calcule
		return this.m_bAJAXDisponible;
	},

	// renvoie la valeur d'un noeud XML
	sXMLGetValeur: function(XMLNoeud)
	{	// Renvoie la valeur du noeud
		// Sauf que s'il y a trop de texte, FireFox (et IE ?) decoupent en plusieurs fils de type texte
		var sValeur;

		if (XMLNoeud)
		{
			// Recupere les nodes
			var tabNodes = XMLNoeud.childNodes;
			var nLimiteI = tabNodes.length;

			// Selon le nombre de noeud
			// 1 : le retourne simplement
			if (nLimiteI == 1)
			{
				// Si la valeur est vide la valeur retourne null
				sValeur = tabNodes[0].nodeValue;
				return sValeur || "";
			}
			else if (nLimiteI > 1)
			{
				// > 1 : concatene les fils via un tableau que l'on join
				var tabValeur = new Array(nLimiteI);
				// On parcours les fils
				var i;
				for (i = 0; i < nLimiteI; i++)
				{
					// Met la valeur de la node dans le tableau
					sValeur = tabNodes[i].nodeValue;
					// Si la valeur est vide la node retourne null
					tabValeur[i] = (sValeur !== null) ? sValeur : "";
				}

				// Renvoie la valeur calcule
				return tabValeur.join("");
			}
		}

		// => 0 fils ou node vide : chaine vide
		return "";
	},

	// Renvoie la valeur en entier
	nXMLGetValeur: function nXMLGetValeur(XMLNoeud)
	{
		return parseInt(this.sXMLGetValeur(XMLNoeud), 10);
	},

	// Renvoie la valeur en booleen
	bXMLGetValeur: function bXMLGetValeur(XMLNoeud)
	{
		return "0" !== this.sXMLGetValeur(XMLNoeud);
	},

	// Renvoie le tableau avec les valeurs des nodes filles d'un certains type
	tabXMLGetTableauValeur: function tabXMLGetTableauValeur(oXMLRacine, sTag)
	{
		// Recupere le tableaux des noeuds qui matchent
		var tabValeur = [];
		clWDUtil.bForEach(oXMLRacine.getElementsByTagName(sTag), function(oNode)
		{
			tabValeur.push(clWDAJAXMain.sXMLGetValeur(oNode));
			return true;
		});

		// Si on a bien des noeuds fils de ce type (sinon pas de tableau)
		return (0 < tabValeur.length) ? tabValeur : null;
	},

	// Indique si un attribut existe
	bXMLAttributExiste: function(XMLNoeud, sAttribut)
	{
		// Renvoie vrai si l'attribut existe
		return !!XMLNoeud.attributes.getNamedItem(sAttribut);
	},

	// renvoie la valeur d'un attribut de noeud XML
	sXMLGetAttribut: function sXMLGetAttribut(XMLNoeud, sAttribut)
	{
		// Renvoie la valeur du noeud
		return clWDUtil.sGetAttributValeur(XMLNoeud.attributes.getNamedItem(sAttribut));
	},

	// Renvoie la valeur d'un attribut de noeud XML ou sDefaut si le neoud n'existe pas
	sXMLGetAttributSafe: function(XMLNoeud, sAttribut, sDefaut)
	{
		// Renvoie la valeur de l'attribut si possible
		var oAtt = XMLNoeud.attributes.getNamedItem(sAttribut);
		return oAtt ? clWDUtil.sGetAttributValeur(oAtt) : sDefaut;
	},

	// Renvoie la valeur d'un attribut de noeud XML sous forme d'un booleen (faux si le noeud n'existe pas (ou contient une valeur != "1"))
	bXMLGetAttributSafe: function(XMLNoeud, sAttribut)
	{
		return "1" === this.sXMLGetAttributSafe(XMLNoeud, sAttribut, "0");
	},

	// Renvoie la valeur d'un attribut de noeud XML sous forme d'un booleen (vrai si le noeud n'existe pas (ou contient une valeur != "0"))
	bXMLGetAttributSafe_Vrai: function bXMLGetAttributSafe_Vrai(XMLNoeud, sAttribut)
	{
		return "0" === this.sXMLGetAttributSafe(XMLNoeud, sAttribut, "1");
	},

	// Renvoie la valeur d'un attribut de noeud XML sous forme d'entier
	nXMLGetAttribut: function nXMLGetAttribut(XMLNoeud, sAttribut)
	{
		return parseInt(this.sXMLGetAttribut(XMLNoeud, sAttribut), 10);
	},

	// Renvoie la valeur d'un attribut de noeud XML sous forme d'entier ou nDefaut si le neoud n'existe pas
	nXMLGetAttributSafe: function(XMLNoeud, sAttribut, nDefaut)
	{
		// On prend vide comme valeur par d�faut comme cela on d�tecte simplement le cas avec le test de la valeur vide
		var sValeur = this.sXMLGetAttributSafe(XMLNoeud, sAttribut, "");
		// Renvoie la valeur de l'attribut si possible. La valeur doit etre :
		// - Non vide
		// - Representer un entier valide
		if (sValeur.length > 0)
		{
			var nValeur = parseInt(sValeur, 10);
			if (!isNaN(nValeur))
			{
				return nValeur;
			}
		}
		return nDefaut;
	},

	// Enleve a la demande les espaces, RC, tabulations d'une chaine donne
	__sTrim: function __sTrim(sValeur, bEspaces, bTabulations)
	{
		var szValeur = new String(sValeur);
		var cChar;

		// Element du debut
		var nDebutChaine = 0;
		while (nDebutChaine < szValeur.length)
		{
			cChar = szValeur.charAt(nDebutChaine);

			// Un espace ?
			if (bEspaces && (cChar == " "))
			{	// Oui on le saute
				nDebutChaine++;
				// Traite le caratere suivant
				continue;
			}
			// Une tabulation ?
			// GP 02/10/2014 : \b est un backspace pas une tabulation
//			if (bTabulations && (cChar == "\b"))
			if (bTabulations && (cChar == "\t"))
			{	// Oui on le saute
				nDebutChaine++;
				// Traite le caratere suivant
				continue;
			}
			// Un rc?
			if (bEspaces && ((cChar == "\r") || (cChar == "\n")))
			{	// Oui on le saute
				nDebutChaine++;
				// Traite le caratere suivant
				continue;
			}
			// Pas un caratere interdit : fin du parcours
			break;
		}

		// Element de la fin
		var nFinChaine = szValeur.length;
		while (nFinChaine > nDebutChaine)
		{
			cChar = szValeur.charAt(nFinChaine - 1);
			// Un espace ?
			if (bEspaces && (cChar == " "))
			{	// Oui on le saute
				nFinChaine--;
				// Traite le caratere suivant
				continue;
			}
			// Une tabulation ?
			// GP 02/10/2014 : \b est un backspace pas une tabulation
//			if (bTabulations && (cChar == "\b"))
			if (bTabulations && (cChar == "\t"))
			{	// Oui on le saute
				nFinChaine++;
				// Traite le caratere suivant
				continue;
			}
			// Un rc?
			if (bEspaces && ((cChar == "\r") || (cChar == "\n")))
			{	// Oui on le saute
				nFinChaine++;
				// Traite le caratere suivant
				continue;
			}
			// Pas un caratere interdit : fin du parcours
			break;
		}
		// on renvoie la chaine resultat
		return szValeur.substring(nDebutChaine, nFinChaine);
	},

	// Enleve a la demande TOUS les RC, tabulations et doubles espaces d'une chaine donne
	sSupprimeEspacements: function sSupprimeEspacements(sValeur)
	{
		// Les RC et les tabulations, puis les espaces multiples
		return sValeur.replace(ms_oRegExpRCTab, "").replace(ms_oRegExpEspacesMutliples, " ");
	},

	// Recherche un champ par son alias
	__oChercheChamp: function __oChercheChamp(oPage, sNomChamp, nTypeChamp, bExterieur, bForceExterieur, bRelatifOuFlux)
	{
		var oElement;

		// GP 26/06/2014 : TB88024 : L'alias effectif de l'IFrame est maintenant pr�fix� par l'alias de la page
		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_PAGEPRINCIPALE:
			// GP 26/11/2015 : TB93302 : Quand on manipule la page, on ne doit pas retourner l'�l�ment "nomm�" avec l'alias de la page (= le formulaire) mais le body.
			return document.body;
		case this.XML_CHAMP_TYPE_WEBCAM:
		case this.XML_CHAMP_TYPE_IFRAME:
			oElement = this.__oChercheChampInterne(oPage, oPage.name + "_" + sNomChamp, nTypeChamp, bExterieur, bForceExterieur, bRelatifOuFlux);
			if (oElement)
			{
				return oElement;
			}
			break;
		}
		return this.__oChercheChampInterne(oPage, sNomChamp, nTypeChamp, bExterieur, bForceExterieur, bRelatifOuFlux);
	},
	__oChercheChampInterne: function __oChercheChampInterne(oPage, sNomChamp, nTypeChamp, bExterieur, bForceExterieur, bRelatifOuFlux)
	{
		var oElement;
		// Recherche pour la visibilite
		if (bExterieur)
		{
			switch (nTypeChamp)
			{
			case this.XML_CHAMP_TYPE_TABLE:
			case this.XML_CHAMP_TYPE_ZONEREPETEE:
			case this.XML_CHAMP_TYPE_TABLEHIERARCHIQUE:
				oElement = this.__oGetConteneurParent(sNomChamp, nTypeChamp, false, bRelatifOuFlux);
				break;
			case WDChamp.prototype.ms_nIDObjetInterrupteur:
				// GP 18/02/2015 : QW255007 : On recoit ALIAS[] comme alias du champ interrupteur en PHP
				if (sNomChamp.substr(sNomChamp.length - 2, 2) == "[]")
				{
					oElement = _JGE(sNomChamp.substr(0, sNomChamp.length - 2), document, bExterieur);
				}
				break;
			case this.XML_CHAMP_TYPE_CALENDRIER:
				// Pour le contenu du champ calendrier, on a besoin du champ exterieur/interieur
				if (!bForceExterieur)
				{
					oElement = _JGE(sNomChamp, document, false, true);
				}
				break;
			}
			if (!oElement)
			{
				oElement = _JGE(sNomChamp, document, bExterieur);
			}
		}
		else
		{
			// Recherche normale
			switch (nTypeChamp)
			{
			// Pour les conteneur aussi en mode non quirks
			case this.XML_CHAMP_TYPE_IFRAME_DEST:
			case this.XML_CHAMP_TYPE_IFRAME_SOURCE:
			case WDChamp.prototype.ms_nIDObjetCellule:
			case this.XML_CHAMP_TYPE_SUPERCHAMP:
			case this.XML_CHAMP_TYPE_MODELEDECHAMP_SOURCE:
			case this.XML_CHAMP_TYPE_MODELEDECHAMP_DEST:
			case this.XML_CHAMP_TYPE_CELLULEMISEENPAGE: // GP 15/03/2016 : TB97083 : Ajout du cas ID_CELLULEMISEENPAGE
				// Donc filtre le mode quirks
				if (bIEQuirks)
				{
					break;
				}
				// falls through
			case WDChamp.prototype.ms_nIDObjetLibelle:		// Pour les libelle il faut utiliser getElementById
			case this.XML_CHAMP_TYPE_CHAMPFORMATE:
			case this.XML_CHAMP_TYPE_LIBELLEHTML:
			case this.XML_CHAMP_TYPE_ZONETEXTE:
			case this.XML_CHAMP_TYPE_REGLETTE:
			case this.XML_CHAMP_TYPE_CHEMINNAV:
			case this.XML_CHAMP_TYPE_PLANSITE:
				// falls through
			case this.XML_CHAMP_TYPE_SOUSMENU:				// De meme pour les options de menu
			case this.XML_CHAMP_TYPE_OPTIONMENU:
			case this.XML_CHAMP_TYPE_MENUPOPUP:
				oElement = _JGE(sNomChamp, document, false);
				break;
			// Pour les arbres il faut rechercher en priorite le champ avec un suffixe
			case this.XML_CHAMP_TYPE_TREEVIEW:
				oElement = _JGE(sNomChamp + "_", document, false);
				break;
			case this.XML_CHAMP_TYPE_LIEN:
			case WDChamp.prototype.ms_nIDObjetBouton:
			case this.XML_CHAMP_TYPE_VOLETONGLET:
			case this.XML_CHAMP_TYPE_PAGECORNEE:
			case WDChamp.prototype.ms_nIDObjetImage:
			case this.XML_CHAMP_TYPE_MAPAREA:
				// GP 03/12/2012 : QW227327 : Il n'y a plus de name sur les liens. On ne trouve donc plus les �l�ments par getElementsByName
				// => Ajout des boutons, volets, page corn�es et images. On ne traite pas les option de menus (d�j� trait� au dessus).
				// Il faut rechercher les liens par ID car getElementsByName ne retourne les elements par ID que dans IE
				oElement = document.getElementById(sNomChamp);
				// GP 30/10/2018 : TB110655 : Pour le cas des images navigateur, ici on tombe sur le i autour de l'image.
				if (clWDUtil.bBaliseEstTag(oElement, "i"))
				{
					// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
					// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
					// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
					oElement = oElement.children[0];
				}
				break;
			default:
				// Que la methode commune
				break;
			}
		}

		// Methodes commune en cas d'echec
		if (!oElement)
		{
			oElement = oPage[sNomChamp];
		}
		// Derniere chance pour les champ hors du formulaire
		if (!oElement)
		{
			oElement = document.getElementsByName(sNomChamp);
			if (oElement)
			{
				switch (nTypeChamp)
				{
				case this.XML_CHAMP_TYPE_SELECTEUR:
					// Sauf pour les interrupteur : on prend le premier champ
					break;

				// GP 03/12/2012 : Inutile : d�j� fait au dessus maintenant
//				case this.XML_CHAMP_TYPE_VOLETONGLET:
//					// Correction pour les volets d'onglets
//					// Sous IE en mode quirks, getElementsByName retourne aussi les elements par ID
//					// Et le code envoye par le serveur en tient compte
//					// Sauf que on ne peut pas modifier le code serveur car alors les sites des anciennes versions ne fonctionnerai plus forcement
//					// avec un nouveau moteur.
//					if (!bIEQuirks)
//					{
//						oElement = document.getElementById(sNomChamp);
//						break;
//					}
//
//					// falls through
				default:
					// Sauf pour les interrupteur : on prend le premier champ
					oElement = oElement[0];
					break;
				}
			}

		}
		return oElement;
	},

	// Recupere le champ conteneur d'une ZR/Table
	__oGetConteneurParent: function __oGetConteneurParent(sNomChamp, nTypeChamp, bInternePourZRHorizontale, bRelatifOuFlux)
	{
		// Choisi l'ID
		var bZRHorizontale = (nTypeChamp == this.XML_CHAMP_TYPE_ZONEREPETEEHORIZONTALE) && bInternePourZRHorizontale;
		var sId = bZRHorizontale ? sNomChamp + "_POS" : "con-" + sNomChamp;
		var oConteneurParent;
		if (bRelatifOuFlux)
		{
			oConteneurParent = document.getElementById("dww" + sId);
		}
		if (!oConteneurParent)
		{
			oConteneurParent = document.getElementById(sId);
			if (bZRHorizontale)
			{
				oConteneurParent = oConteneurParent.getElementsByTagName("table")[0];
			}
		}
		if (!oConteneurParent)
		{
			oConteneurParent = document.getElementById("ctz" + sNomChamp);
		}
		return oConteneurParent;
	},

	// Recupere la balise TBODY d'une balise TABLE
	__oGetConteneurTBODY: function __oGetConteneurTBODY(oConteneurParent, nTypeChamp)
	{
		var oConteneurTBody = oConteneurParent;
		// Si le parent de la table/ZR est une balise de type table : on risque d'avoir un probleme avec la pseudo balise TBODY
		if ((oConteneurTBody) && clWDUtil.bBaliseEstTag(oConteneurTBody, "table"))
		{
			// Recherche le TBODY
			var i;
			var tabChildNodes = oConteneurTBody.childNodes;
			var nLimiteI = tabChildNodes.length;
			for (i = 0; i < nLimiteI; i++)
			{
				// clWDUtil.bBaliseEstTag teste tabChildNodes[i].tagName
				if (clWDUtil.bBaliseEstTag(tabChildNodes[i], "tbody"))
				{
					oConteneurTBody = tabChildNodes[i];
					// GP 01/02/2013 : TB80896 : ZR horizontale ?
					// Le code ne fonctionne absolument pas : je change tout
					// Tous les appels sont dans le contexte de bInternePourZRHorizontale : pas de param�tre et non test�
					if (nTypeChamp == this.XML_CHAMP_TYPE_ZONEREPETEEHORIZONTALE)
					{
						tabChildNodes = oConteneurTBody.childNodes;
						nLimiteI = tabChildNodes.length;
						for (i = 0; i < nLimiteI; i++)
						{
							// clWDUtil.bBaliseEstTag teste tabChildNodes[i].tagName
							if (clWDUtil.bBaliseEstTag(tabChildNodes[i], "tr"))
							{
								oConteneurTBody = tabChildNodes[i];
								break;
							}
						}
					}
					break;
				}
			}
		}
		return oConteneurTBody;
	},

	// Recupere une ligne d'un champ d'une ZR/Table
	__oGetConteneurLigne: function __oGetConteneurLigne(sNomChamp, nIndiceActuel, oConteneurTBody)
	{
		return this.__oGetRemonteFilsUnique(sNomChamp + "_" + nIndiceActuel, oConteneurTBody);
	},

	__bEstTexteInactif: function __bEstTexteInactif(oElement)
	{
		if (oElement.nodeName !== "#text")
		{
			return false;
		}
		else
		{
			return 0 === oElement.nodeValue.replace(ms_oRegExpRCTabEspaces, "").length;
		}
	},

	// Indique si une balsie n'a qu'un seul fils "actif" (ignore les balises texte avec uniquement des espaces/rc)
	__bAvecFilsActifUnique: function __bAvecFilsActifUnique(oParent)
	{
		var bUnFilsActif = false;
		var i;
		var nLimiteI = oParent.childNodes.length;
		for (i = 0; i < nLimiteI; i++)
		{
			if (!this.__bEstTexteInactif(oParent.childNodes[i]))
			{
				if (bUnFilsActif)
				{
					return false;
				}
				bUnFilsActif = true;
			}
		}
		return true;
	},

	// Remonte les parent tant que l'element est unique d'un autre
	__oGetRemonteFilsUnique: function __oGetRemonteFilsUnique(sNom, oConteneurTBody)
	{
		var oElement = document.getElementById(sNom);
		// Uniquement si l'element est valide et si on est dans une vraie table
		if (oElement && oConteneurTBody)
		{
			// On remonte les noeuds tant que l'on est le seul fils
			var oParent = oElement.parentNode;
			while (oParent && oParent != oConteneurTBody && this.__bAvecFilsActifUnique(oParent))
			{
				oElement = oParent;
				oParent = oElement.parentNode;
			}
		}
		return oElement;
	},


	// Supprime la ligne donnee
	__bSupprimeLigne: function __bSupprimeLigne(sNomChamp, nTypeChamp, nIndiceLigne, nNbRuptures, oConteneurParent, oConteneurTBody)
	{
		// On commence par recuperer la ligne
		var oLigneSuppr = this.__oGetConteneurLigne(sNomChamp, nIndiceLigne, oConteneurTBody);

		// Si pas de ligne => Fini
		if (!oLigneSuppr)
		{
			return false;
		}

		// On supprime les ruptures de la ligne si besoin
		// GP 08/11/2014 : QW251233 : Les tables aussi ont des ruptures
		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_TABLE:
		case this.XML_CHAMP_TYPE_ZONEREPETEE:
			this.__SupprimeRuptures(sNomChamp, nIndiceLigne, nNbRuptures, oConteneurTBody);
			break;
		}

		// Si on est dans une vrai table
		if (oConteneurTBody)
		{
			clWDUtil.oSupprimeElement(oLigneSuppr);
		}
		else
		{
			// On supprime le noeud
			oConteneurParent.removeChild(oLigneSuppr);
		}

		// On supprime maintenant les styles qui sont group�s dans une balise style par ligne
		this.__SupprimeStyleLigne(sNomChamp, nIndiceLigne);

		return true;
	},

	// Supprime la balise de style pour une ligne
	__SupprimeStyleLigne: function __SupprimeStyleLigne(sNomChamp, nIndiceLigne)
	{
		// On supprime maintenant les styles qui sont group�s dans une balise style par ligne
//		// On ne supprime pas les styles car on n'a pas leurs noms
//		// Mais de toutes facons comme il n'y a pas de ligne pour les appliquer pas de problemes
//		// Et si un jour on rajoute de nouveau une ligne, elle sera avec son style donc celui-ci remplacera le style non detruit
		var oBaliseStyle = document.getElementById("rgs-" + sNomChamp + "-" + nIndiceLigne);
		if (oBaliseStyle && oBaliseStyle.parentNode)
		{
			oBaliseStyle.parentNode.removeChild(oBaliseStyle);
		}
	},

	// Trouve une rupture
	__oTrouveUneRupture: function __oTrouveUneRupture(sNomChamp, bHaut, nIndiceRupture, nIndiceLigne, oConteneurTBody)
	{
		return this.__oGetRemonteFilsUnique(sNomChamp + "-" + (bHaut ? "H" : "B") + "-" + nIndiceRupture + "-" + nIndiceLigne, oConteneurTBody);
	},

	// Trouve la rupture la plus externe de la ligne (premiere en haut et derniere en bas)
	__oTrouveRuptureExterne: function __oTrouveRuptureExterne(sNomChamp, bHaut, nIndiceLigne, nNbRuptures, oConteneurTBody)
	{
		// On parcours les niveaux de ruptures
		var i;
		for (i = 0; i < nNbRuptures; i++)
		{
			var oRupture = this.__oTrouveUneRupture(sNomChamp, bHaut, i, nIndiceLigne, oConteneurTBody);
			if (oRupture)
			{
				return oRupture;
			}
		}
		return null;
	},

	// Supprime une rupture
	__SupprimeUneRupture: function __SupprimeUneRupture(sNomChamp, bHaut, nIndiceRupture, nIndiceLigne, oConteneurTBody)
	{
		// Trouve et supprime la rupture
		clWDUtil.oSupprimeElement(this.__oTrouveUneRupture(sNomChamp, bHaut, nIndiceRupture, nIndiceLigne, oConteneurTBody));
	},

	// Supprime les ruptures d'une ligne donne
	__SupprimeRuptures: function __SupprimeRuptures(sNomChamp, nIndiceLigne, nNbRuptures, oConteneurTBody)
	{
		// On parcours les niveaux de ruptures
		var i;
		for (i = 0; i < nNbRuptures; i++)
		{
			// D'abord le haut de la rupture
			this.__SupprimeUneRupture(sNomChamp, true, i, nIndiceLigne, oConteneurTBody);
			// Puis le bas
			this.__SupprimeUneRupture(sNomChamp, false, i, nIndiceLigne, oConteneurTBody);
		}
	},

	// Remplace un element dans une table (pour tous sauf IE)
	__RemplaceElementDansTable: function __RemplaceElementDansTable(oElement, sHTML)
	{
		oElement.parentNode.replaceChild(clWDUtil.oCreateContextualFragmentSelonElement(oElement, sHTML), oElement);
	},
	__InsereElementDansTable: function __InsereElementDansTable(oElementSuivant, sHTML)
	{
		if (0 < sHTML.length)
		{
			oElementSuivant.parentNode.insertBefore(clWDUtil.oCreateContextualFragmentSelonElement(oElementSuivant, sHTML), oElementSuivant);
		}
	},
	__AjouteElementDansTable: function __AjouteElementDansTable(oPosition, sHTML)
	{
		if (0 < sHTML.length)
		{
			var oRange = document.createRange();
			oRange.setStart(oPosition, 0);
			var oFragment = clWDUtil.oCreateContextualFragment(oRange, sHTML).childNodes;
			while (oFragment.length > 0)
			{
				oPosition.appendChild(oFragment[0]);
			}
		}
	},

	// Insere/remplace un double element dans la table
	__InsereRemplaceTrTdDansTable: function __InsereRemplaceTrTdDansTable(oElement, sHTML, bDebut, oElementRemplace)
	{
		// La ligne est un tr partiel : on cree un tr total
		if (bDebut)
		{
			sHTML = sHTML + "</tr>";
		}
		else
		{
			sHTML = "<tr>" + sHTML;
		}
		var oFragment = clWDUtil.oCreateContextualFragmentSelonElement(oElement, sHTML).childNodes;
		// Si on a deux elements, on les replace les deux
		if (oFragment.length > 1)
		{
			if (bDebut)
			{
				oElement.parentNode.insertBefore(oFragment[0], oElement);
			}
			else
			{
				oElement.parentNode.insertBefore(oFragment[1], oElement.nextSibling);
			}
		}
		if (!oElementRemplace)
		{
			if (bDebut)
			{
				oElement.parentNode.insertBefore(oFragment[0], oElement);
			}
			else
			{
				oElement.previousSibling.appendChild(oFragment[0])
			}
		}
		else
		{
			oElement.replaceChild(oFragment[0].firstChild, oElementRemplace);
		}
	},

	__bHTMLDebutTR: function __bHTMLDebutTR(sHTML)
	{
		var sDebut = sHTML.substr(0, 4).toLowerCase();
		return ("<tr>" === sDebut) || ("<tr " === sDebut);
	},
	__bHTMLDebutTD: function __bHTMLDebutTD(sHTML)
	{
		var sDebut = sHTML.substr(0, 4).toLowerCase();
		return ("<td>" === sDebut) || ("<td " === sDebut);
	},

	// Certains champ on a un niveau de table tr td supplementaire ce qui gene la manipulation de ..Valeur et ..Libelle
	__oSauteTableCadrage: function __oSauteTableCadrage(oChamp)
	{
		if (oChamp && clWDUtil.bBaliseEstTag(oChamp, "table"))
		{
			while (oChamp && !clWDUtil.bBaliseEstTag(oChamp, "td"))
			{
				// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
				// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
				// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
				oChamp = oChamp.children[0];
			}
		}
		return oChamp;
	},

	// execute les actions pour une propriete
	ActionProprieteValeur: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		var sValeur = this.sXMLGetValeur(XMLAction);

		// Il n'y a pas encore eu de validation de l'existance de oChamp, donc on le fait ici si besoin

		// selon le type du champ
		switch (nTypeChamp)
		{
		// Le cas n'existe plus la propriete ..Valeur est transforme en ..Libelle sur le serveur
		case WDChamp.prototype.ms_nIDObjetImage:
		case this.XML_CHAMP_TYPE_MAPAREA:
		case this.XML_CHAMP_TYPE_VIGNETTE:
		case this.XML_CHAMP_TYPE_GRAPHE:
		case this.XML_CHAMP_TYPE_CAPTCHA:
		case this.XML_CHAMP_TYPE_IFRAME: // On change la source des IFrames par un ..src
			if (oChamp)
			{
				oChamp.src = sValeur;
			}
			break;
		case this.XML_CHAMP_TYPE_LISTE:
			if (oChamp)
			{
				oChamp.selectedIndex = parseInt(sValeur, 10);
			}
			break;
		case this.XML_CHAMP_TYPE_SELECTEUR:
			// Pour les selecteur : le code serveur a deja fait l'enventuelle transposition et le -1 requis
			var nOptionSel = parseInt(sValeur, 10);

			// Si on a une valeur negative => Ne selectionne rien
			if (nOptionSel < 0)
			{
				// Si on n'a plus d'une option
				if (oChamp && oChamp.length)
				{	// Les deselectionnes toutes
					var i;
					var nLimiteI = oChamp.length;
					for (i = 0; i < nLimiteI; i++)
					{
						oChamp[i].checked = false;
					}
				}
				else if (oChamp)
				{
					// Une seule option
					//assert(nOptionSel==0);
					oChamp.checked = false;
				}
			}
			else
			{
				if (oChamp)
				{
					if (oChamp.length)
					{
						// Si on n'a plus d'une option
						if (nOptionSel <= oChamp.length)
						{
							oChamp[nOptionSel].checked = true;
						}
					}
					else
					{
						// Une seule option
						oChamp.checked = true;
					}
				}
			}
			break;
		case WDChamp.prototype.ms_nIDObjetInterrupteur:
			if (oChamp)
			{
				oChamp.checked = parseInt(sValeur, 10);
			}
			break;
		case WDChamp.prototype.ms_nIDObjetLibelle:
		case this.XML_CHAMP_TYPE_CHAMPFORMATE:
			// Dans certains cas une table est ajoute et l'ID est sur la table au lieu de la cellule : retrouve la cellule
			oChamp = this.__oSauteTableCadrage(oChamp);

			// Affectation de la valeur avec rajout des balises HTML
			if (oChamp)
			{
				oChamp.innerHTML = clWDUtil.sEncodeInnerHTML(sValeur, true);
			}
			break;
		case WDChamp.prototype.ms_nIDObjetSaisie:
			// Champ de saisie
			if (oChamp)
			{
				// On transforme pour gerer les caratere interdit en ISO-8859-1 si besoin
				oChamp.value = sValeur;
				// Si le champ a une variable associee (champ avec indication ou champ de saisie riche)
				// appele la methode d'ecriture de la valeur
				clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetValeur, [null, sValeur, oChamp]);
			}
			break;
		case this.XML_CHAMP_TYPE_HTML:
		case this.XML_CHAMP_TYPE_LIBELLEHTML:
		case this.XML_CHAMP_TYPE_ZONETEXTE:
			// Pour les champs HTML superposable : on prend le champ exterieur si on n'a pas le champ interieur
			if (!oChamp && oChampExt)
			{
				oChamp = oChampExt;
			}
			// GP 04/12/2012 : QW227380 : On ne doit pas passer dans le cas reglette. Pour faire simple je duplique le code
			// Dans certains cas une table est ajoute et l'ID est sur la table au lieu de la cellule : retrouve la cellule
			oChamp = this.__oSauteTableCadrage(oChamp);

			// Affectation de la valeur sans rajout des balises HTML
			if (oChamp)
			{
				// GP 28/08/2017 : Suppression des NSUtil.sEncodeInnerHTML(Chaine, false, true) qui ne font rien (sauf la conversion en chaine qui est inutile)
				oChamp.innerHTML = sValeur;
			}
			break;
		case this.XML_CHAMP_TYPE_REGLETTE:
			// GP 21/11/2012 : QW226371 : En 18, il faut trouver le OL
			oChamp = oChamp.getElementsByTagName("ol")[0];
			// this.__oSauteTableCadrage ne fait rien car on n'est pas sur une table.
			// falls through
		case this.XML_CHAMP_TYPE_CHEMINNAV:
		case this.XML_CHAMP_TYPE_PLANSITE:
			// Dans certains cas une table est ajoute et l'ID est sur la table au lieu de la cellule : retrouve la cellule
			oChamp = this.__oSauteTableCadrage(oChamp);

			// Affectation de la valeur sans rajout des balises HTML
			if (oChamp)
			{
				// GP 28/08/2017 : Suppression des NSUtil.sEncodeInnerHTML(Chaine, false, true) qui ne font rien (sauf la conversion en chaine qui est inutile)
				oChamp.innerHTML = sValeur;
			}
			break;

		case this.XML_CHAMP_TYPE_IFRAME_DEST:
		case this.XML_CHAMP_TYPE_IFRAME_SOURCE:
		case WDChamp.prototype.ms_nIDObjetCellule:
		case this.XML_CHAMP_TYPE_SUPERCHAMP:
		case this.XML_CHAMP_TYPE_MODELEDECHAMP_SOURCE:
		case this.XML_CHAMP_TYPE_MODELEDECHAMP_DEST:
		case this.XML_CHAMP_TYPE_CELLULEMISEENPAGE: // GP 15/03/2016 : TB97083 : Ajout du cas ID_CELLULEMISEENPAGE
			//assert(false);
			break;

		case this.XML_CHAMP_TYPE_ONGLET:
		case this.XML_CHAMP_TYPE_RANGESLIDER:
		case this.XML_CHAMP_TYPE_RATING:
		case this.XML_CHAMP_TYPE_POTENTIOMETRE:
		case this.XML_CHAMP_TYPE_BANDEAU_DEFILANT:
			// On force la selection car la valeur renvoie par le serveur est forcement valide et
			// que la commande sur le ..Etat des volets peut ne pas encore etre execute
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetValeur, [null, sValeur, null]);
			break;

		case this.XML_CHAMP_TYPE_TIROIR:
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetValeur, [null, (parseInt(sValeur, 10) != 0), null]);
			break;

		case this.XML_CHAMP_TYPE_LIENSOCIAL:
			if (oChamp && oChamp.attributes)
			{
				switch (clWDUtil.sGetTagName(oChamp))
				{
				case "a":
					// Twitter
					// Ecrit le href qu'il soit vide ou pas vide
					oChamp.setAttribute("href", sValeur, 0);
					break;
				case "div":
					// Facebook/Google+
					// Ajoute/Modifie/Supprime le data-href selon que sValeur est vide ou pas
					if (sValeur.length)
					{
						oChamp.setAttribute("data-href", sValeur, 0);
					}
					else if (oChamp.attributes.getNamedItem("data-href"))
					{
						oChamp.removeAttribute("data-href", 0);
					}
					break;
				}
			}
			break;

		case this.XML_CHAMP_TYPE_EDITEUR_IMAGE:
			if (oChamp)
			{
				oChamp.value = sValeur;
				$(oChamp).trigger("change");
			}
			break;

		// @@@ Ici nouveau champ si besoin

		default: 	// Autres cas
			if (oChamp)
			{
				oChamp.value = sValeur;
			}
			break;
		}
	},

	// Libelle
	ActionProprieteLibelle: function(oChamp, nTypeChamp, XMLAction, sAliasChamp, bLibelleHTML)
	{
		var sValeur = this.sXMLGetValeur(XMLAction);
		// Selon le type du champ
		switch (nTypeChamp)
		{
		// Cas de la page
		case this.XML_CHAMP_TYPE_PAGEPRINCIPALE:
			document.title = sValeur;
			return;

		// On traite le champ bouton specialement : Si c'est un champ image on fait comme les images
		case WDChamp.prototype.ms_nIDObjetBouton:
			// Si c'est un bouton image => On doit prendre le div interne
			// 17 : tous commencent par z_ pour etre dans la norme
			var oChampPourInnerHTML;
			var oChampImg = _JGE("z_" + sAliasChamp + "_IMG", document, false);
			if (oChampImg && !clWDUtil.bBaliseEstTag(oChampImg, "img"))
			{
				// Pour l'alignement vertical, on a un second span interne (normalement toujours pr�sent = m�me sans alignement vertical)
				// Mais par s�curit� on le test
				var tabSpanFils = oChampImg.getElementsByTagName("span");
				if (tabSpanFils && tabSpanFils.length)
				{
					oChampImg = tabSpanFils[0];
				}
				oChampPourInnerHTML = oChampImg;
			}
			else if (oChamp)
			{
				// Si on a le champ c'est que c'est un champ de type input => bouton "normal"
				// GP 15/01/2014 : TB85629 : Sauf pour les bouton de type button
				if (clWDUtil.bBaliseEstTag(oChamp, "button"))
				{
					oChampPourInnerHTML = oChamp;
				}
			}

			if (oChampPourInnerHTML)
			{
				// Si la valeur est :
				// - Texte : on veux true, false => !bLibelleHTML, bLibelleHTML
				// - HTML : on veux false, true => !bLibelleHTML, bLibelleHTML
				oChampPourInnerHTML.innerHTML = clWDUtil.sEncodeInnerHTML(sValeur, !bLibelleHTML, bLibelleHTML);
			}
			else if (oChamp)
			{
				oChamp.value = sValeur;
			}
			return;
		case WDChamp.prototype.ms_nIDObjetLibelle:
			// Dans certains cas une table est ajoute et l'ID est sur la table au lieu de la cellule : retrouve la cellule
			oChamp = this.__oSauteTableCadrage(oChamp);
			break;
		case this.XML_CHAMP_TYPE_LIBELLEHTML:
		case this.XML_CHAMP_TYPE_ZONETEXTE:
			// Dans certains cas une table est ajoute et l'ID est sur la table au lieu de la cellule : retrouve la cellule
			oChamp = this.__oSauteTableCadrage(oChamp);
			// Affectation de la valeur sans rajout des balises HTML
			if (oChamp)
			{
				// La valeur est normalement toujours pour le libell� HTML
				clWDUtil.WDDebug.assert(bLibelleHTML, "Seule ..Libell�HTML est autoris� sur les ZTRs");
				// GP 28/08/2017 : Suppression des NSUtil.sEncodeInnerHTML(Chaine, false, true) qui ne font rien (sauf la conversion en chaine qui est inutile)
				oChamp.innerHTML = sValeur;
			}
			return;
		case this.XML_CHAMP_TYPE_LIEN:
			// On ne cherche pas le champ lui meme mais le champ autour pour avoir la balise a
			// GP 23/01/2017 : QW283149 : Il n'y a pas de champ autour dans le cas d'un lien dans une ZTR (le champ autour est un td de positionnement qui n'est pas dans les ZTRs)
			oChamp = _JGE(sAliasChamp, document, false, true) || (clWDUtil.bBaliseEstTag(oChamp, "a") && oChamp);
			if (oChamp)
			{
				// Soit on est directement sur le a ou sur le TD autour
				while (oChamp && !clWDUtil.bBaliseEstTag(oChamp, "a"))
				{
					// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
					// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
					// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
					oChamp = oChamp.children[0];
				}
				if (oChamp)
				{
					oChamp.innerHTML = sValeur;
				}
			}
			return;
		case this.XML_CHAMP_TYPE_TABLE:
		case this.XML_CHAMP_TYPE_TABLEHIERARCHIQUE:
			// On cherche un id special pour les tables et colonne de table
			oChamp = document.getElementById("lz" + sAliasChamp);
			if (!oChamp)
			{
				oChamp = _JGE(sAliasChamp, document, false, true);
			}
			break;

		case this.XML_CHAMP_TYPE_COLONNETABLE:
		case this.XML_CHAMP_TYPE_COLONNETABLEH:
			// Si c'est une table AJAX : on doit rechercher la cellule interne
			var sTableAjax = new String(this.sXMLGetAttributSafe(XMLAction, this.XML_CHAMP_PROP_NUM_LIBELLE_TABLE_AJAX, ""));
			if (sTableAjax.length > 0)
			{
				var nSeparateur = sTableAjax.indexOf(";");
				var oVarTable = oGetObjetChamp(sTableAjax.substring(0, nSeparateur));
				oChamp = oVarTable.oGetIDElement(clWDTableDefs.ID_TITRE, parseInt(sTableAjax.substring(nSeparateur + 1), 10));
				// Notifie le champ du changement de titre ?
				// (Ou alors il y de toutes fa�ons une notification de rechangement de la table ?)
			}
			// On cherche un id special pour les tables et colonne de table
			if (!oChamp)
			{
				// GP 23/09/2015 : QW261675 : Ce code est manifestement faux :
				// - On est dans le cas XML_CHAMP_TYPE_COLONNETABLE ou XML_CHAMP_TYPE_COLONNETABLEH donc nTypeChamp ne peut pas �tre XML_CHAMP_TYPE_ZONEREPETEE.
				// - On n'a pas de colonne dans les zone r�p�t�es
				// - Le pr�fixe pour les colonne est bien "tt".
//				oChamp = document.getElementById((nTypeChamp != this.XML_CHAMP_TYPE_ZONEREPETEE ? "lz" : "tt") + sAliasChamp);
				oChamp = document.getElementById("tt" + sAliasChamp);
				if (!oChamp)
				{
					oChamp = _JGE(sAliasChamp, document, false, true);
				}
			}
			break;

		case this.XML_CHAMP_TYPE_VOLETONGLET:
			// GP 14/05/2013 : TB81779 : Cas special pour les volets d'onglets, on fait manipuler le lien
			if (oChamp)
			{
				var tabBalisesA = oChamp.getElementsByTagName("a");
				if (tabBalisesA.length)
				{
					oChamp = tabBalisesA[0];
				}
			}
			break;

		case this.XML_CHAMP_TYPE_SOUSMENU:
		case this.XML_CHAMP_TYPE_OPTIONMENU:
		case this.XML_CHAMP_TYPE_MENUPOPUP:
			break;

		default:		// Autres cas
			// Force le lzXxx (pour ne pas ecraser le contenu)
			oChamp = document.getElementById("lz" + sAliasChamp);
			break;
		}
		if (oChamp)
		{
			// Si la valeur est :
			// - Texte : on veux true, false => !bLibelleHTML, bLibelleHTML
			// - HTML : on veux false, true => !bLibelleHTML, bLibelleHTML
			oChamp.innerHTML = clWDUtil.sEncodeInnerHTML(sValeur, !bLibelleHTML, bLibelleHTML);
		}
	},

	// Note
	ActionProprieteNote: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		if (!this.__bActionProprieteV2(nTypeChamp, sAliasChamp, 39 /*NSPCS.NSProprietes.EJS.Note*/, this.sXMLGetValeur(XMLAction), undefined))
		{
			// Si pas de framework V2, on ne peut rien faire
		}
	},
	// TitreNote
	ActionProprieteTitreNote: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		if (!this.__bActionProprieteV2(nTypeChamp, sAliasChamp, 40 /*NSPCS.NSProprietes.EJS.TitreNote*/, this.sXMLGetValeur(XMLAction), undefined))
		{
			// Si pas de framework V2, on ne peut rien faire
		}
	},

	// Hauteur
	ActionProprieteHauteur: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.__ActionProprieteLargeurHauteur(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp, "height", WDChamp.prototype.XML_CHAMP_PROP_NUM_HAUTEUR);
	},

	// Largeur
	ActionProprieteLargeur: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.__ActionProprieteLargeurHauteur(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp, "width", WDChamp.prototype.XML_CHAMP_PROP_NUM_LARGEUR);
	},

	// ..Hauteur/..Largeur
	__ActionProprieteLargeurHauteur: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp, sPropriete, nPropriete)
	{
		// Uniquement avec un champ
		if (oChamp)
		{
			var nValeur = this.nXMLGetValeur(XMLAction);
			if (nValeur >= 0)
			{
				var sValeurPx = nValeur + "px";
				switch (nTypeChamp)
				{
				case this.XML_CHAMP_TYPE_TIROIR:
					break;

				case this.XML_CHAMP_TYPE_JAUGE:
					clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [nPropriete, null, nValeur, null, null]);
					oChamp = _JGE(sAliasChamp, document, true);
					// Il faut modifier la cellule interne
					oChamp.getElementsByTagName("td")[0][sPropriete] = nValeur;
					// La cellule
					this.ActionProprieteStyleGenerique(oChamp, oChampExt, nTypeChamp, sAliasChamp, sPropriete, sValeurPx, false);
					break;

				// Cas particulier pour les conteneurs (Cellules, Superchamps, modeles de champs)
				case WDChamp.prototype.ms_nIDObjetCellule:
				case this.XML_CHAMP_TYPE_SUPERCHAMP:
//				case this.XML_CHAMP_TYPE_MODELEDECHAMP_SOURCE:
					// falls through
				case this.XML_CHAMP_TYPE_MODELEDECHAMP_DEST:
					// Il faut modifier la cellule interne
					// GP 24/02/2015 : TB91449 : Si la propri�t� est dans le style : manipule le style
					var oCelluleInterne = oChamp.getElementsByTagName("td")[0];
					if ("" != oCelluleInterne.style[sPropriete])
					{
						oCelluleInterne.style[sPropriete] = sValeurPx;
					}
					else
					{
						oCelluleInterne[sPropriete] = nValeur;
					}
					// La cellule
					this.ActionProprieteStyleGenerique(oChamp, oChampExt, nTypeChamp, sAliasChamp, sPropriete, sValeurPx, false);
					// Et la cellule externe
					oChamp = oChamp.parentNode;
					while (oChamp && (oChamp != document.body))
					{
						switch (clWDUtil.sGetTagName(oChamp))
						{
						case "table":
							oChamp[sPropriete] = nValeur;
							// falls through
						default:
							oChamp = oChamp.parentNode;
							break;
						case "div":
							this.ActionProprieteStyleGenerique(oChamp, oChampExt, nTypeChamp, sAliasChamp, sPropriete, sValeurPx, false);
							oChamp = null;
						}
					}
					break;
				// Cas particuliers des interrupteurs et des selecteurs => Il faut manipuler chaque instance de l'interrupteur
				case WDChamp.prototype.ms_nIDObjetInterrupteur:
				case this.XML_CHAMP_TYPE_SELECTEUR:
					// Modifie la taille globale
					this.ActionProprieteStyleGenerique(oChampExt, null, nTypeChamp, sAliasChamp, sPropriete, sValeurPx, false);

					// Puis modifier la hauteur de chaque interrupteurs => Ce n'est pas ce que fait le code serveur traditionnel
					break;

				// Cas des onglets : on manipule les conteneurs des onglets
				case this.XML_CHAMP_TYPE_ONGLET:
					this.ActionProprieteStyleGenerique(oChampExt, null, nTypeChamp, sAliasChamp, sPropriete, sValeurPx, false);
					this.ActionProprieteStyleGenerique(document.getElementById("con-" + sAliasChamp), null, nTypeChamp, sPropriete, sValeurPx, false);
					break;

				case WDChamp.prototype.ms_nIDObjetLibelle:
					// GP 31/10/2014 : QW246699 : cas des lib�ll�s : utilise le bz en priorit� si on est en superposable
					this.ActionProprieteStyleGenerique(((oChamp != oChampExt) && document.getElementById("bz" + sAliasChamp)) || oChamp, null, nTypeChamp, sAliasChamp, sPropriete, sValeurPx, false);
					break;

				case this.XML_CHAMP_TYPE_GRAPHE:
					// GP 14/11/2014 : QW250069 : Recherche le cas interactif
					this.ActionProprieteStyleGenerique(document.getElementById(sAliasChamp) || oChamp, null, nTypeChamp, sAliasChamp, sPropriete, sValeurPx, false);
					break;

				default:
					this.ActionProprieteStyleGenerique(oChamp, oChampExt, nTypeChamp, sAliasChamp, sPropriete, nValeur + "px", false);
					break;
				}
			}
		}
	},

	// X
	ActionProprieteX: function ActionProprieteX(oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		// On ne filtre pas les positions , les positions negatives sont valides
		this.ActionProprieteStyleGenerique(oChampExt, null, nTypeChamp, sAliasChamp, clWDUtil.bRTL ? "right" : "left", this.sXMLGetValeur(XMLAction) + "px", false);
	},

	// Y
	ActionProprieteY: function ActionProprieteY(oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		// On ne filtre pas les positions , les positions negatives sont valides
		this.ActionProprieteStyleGenerique(oChampExt, null, nTypeChamp, sAliasChamp, "top", this.sXMLGetValeur(XMLAction) + "px", false);
	},

	// Couleur
	ActionProprieteCouleur: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		// On ne recupere la couleur qu'une fois
		var sCouleur = this.sXMLGetValeur(XMLAction);
		var bSousElements = false;

		// Puis selon le type de champ on fait des actions differentes
		switch (nTypeChamp)
		{
		case WDChamp.prototype.ms_nIDObjetInterrupteur:
		case this.XML_CHAMP_TYPE_SELECTEUR:
			// Les interrupteurs et les selecteurs sont particulier
			// GP 20/11/2015 : TB94694 : R�activation : On demande d'activer le cas particulier des sous elements
			// GP 07/04/2015 : TB88198 : Factoris� dans ActionProprieteStyleGenerique
			bSousElements = true;
//			oChamp = _JGE(sAliasChamp, document, false, true);
			// Ajoute le comportement par defaut
			break;

		case this.XML_CHAMP_TYPE_CHEMINNAV:
		case this.XML_CHAMP_TYPE_PLANSITE:
		case this.XML_CHAMP_TYPE_REGLETTE:
		case this.XML_CHAMP_TYPE_TREEVIEW:
			// Pour les champs de type reglette, le style est sur le conteneur de la reglette (Pas de problemes)
			// mais il y a une surcharge du style pour toutes les balises A dans la ligne (car sinon les balises n'heritent pas du style)
			bSousElements = true;
			// Ajoute le comportement par defaut
			break;

		case this.XML_CHAMP_TYPE_COLONNETABLE:
		case this.XML_CHAMP_TYPE_COLONNETABLEH:
		case this.XML_CHAMP_TYPE_JAUGE:
			// Rebond sur la methode de la police car on manipule le texte
			this.ActionProprieteStylePolice(oChamp, null, nTypeChamp, sAliasChamp, "color", sCouleur, false);
			// Sans le comportement par defaut
			return;

		case WDChamp.prototype.ms_nIDObjetSaisie:
			// Sur les champs de saisie riche (et sur les champs de saisie avec indication)
			// Mais dans ce cas l'appel ne fait rien et c'est l'affectation sur le champ formulaire qui effectue le travail
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEUR, null, sCouleur, oChamp, null]);
			// Ajoute le comportement par defaut
			break;

		case this.XML_CHAMP_TYPE_LIEN:
			oChamp = _JGE(sAliasChamp, document, false, false);
			// Ajoute le comportement par defaut
			break;

		// Mais pas de problemes avec les autres champs
		default:
			// Ajoute le comportement par defaut
			break;
		}
		// Comportement par defaut
		this.ActionProprieteStyleGenerique(oChamp, oChampExt, nTypeChamp, sAliasChamp, "color", sCouleur, bSousElements);
	},

	// Couleur de fond
	ActionProprieteCouleurFond: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		// On ne recupere la couleur qu'une fois
		var sCouleur = this.sXMLGetValeur(XMLAction);
		var bSousElements = false;

		// Puis selon le type de champ on fait des actions differentes
		switch (nTypeChamp)
		{
		// GP 26/11/2015 : TB93302 : Cas particulier inutile car maintenant g�rer par le cas g�n�ral
//		case this.XML_CHAMP_TYPE_PAGEPRINCIPALE:
//			// GP 18/09/2012 : QW222430 : Il faut vraiment pass� par le style maintenant
//			document.body.style.backgroundColor = sCouleur;
//			// Sans le comportement par defaut
//			return;

		case WDChamp.prototype.ms_nIDObjetInterrupteur:
		case this.XML_CHAMP_TYPE_SELECTEUR:
			// Les interrupteurs et les selecteurs sont particulier
			// GP 20/11/2015 : TB94694 : R�activation : On demande d'activer le cas particulier des sous elements
			// GP 07/04/2015 : TB88198 : Factoris� dans ActionProprieteStyleGenerique
			bSousElements = true;
//			oChamp = _JGE(sAliasChamp, document, false, true);
			// Ajoute le comportement par defaut
			break;

		case this.XML_CHAMP_TYPE_IFRAME_DEST:
		case this.XML_CHAMP_TYPE_IFRAME_SOURCE:
		case WDChamp.prototype.ms_nIDObjetCellule:
		case this.XML_CHAMP_TYPE_SUPERCHAMP:
		case this.XML_CHAMP_TYPE_MODELEDECHAMP_SOURCE:
		case this.XML_CHAMP_TYPE_MODELEDECHAMP_DEST:
		case this.XML_CHAMP_TYPE_CELLULEMISEENPAGE: // GP 15/03/2016 : TB97083 : Ajout du cas ID_CELLULEMISEENPAGE
			// On cherche le champ cellule
			oChamp = _JGE(sAliasChamp, document, false);
			// Ajoute le comportement par defaut
			break;
		case this.XML_CHAMP_TYPE_TIROIR:
			// Recherche le champ conteneur des deux parties
			oChamp = _JGE(sAliasChamp, document, true);
			// GP 27/01/2015 : Qui est normalement oChampExt (ne change pas pour ne pas prendre de risque)
			clWDUtil.WDDebug.assert(oChamp === oChampExt, "oChamp != oChampExt !!!");
			break;

		case this.XML_CHAMP_TYPE_LIEN:
			// Pour QW46375 : Les champs liens on le style sur la balise tz (Sur la cellule conteneur) et sur le champ lien
			// On cherche la cellule de table
			var oChamp2 = _JGE(sAliasChamp, document, true);
			// Et on lui applique le style
			if (oChamp2 && oChamp2.style)
			{
				oChamp2.style.backgroundColor = sCouleur;
			}
			// Ajoute le comportement par defaut
			break;

		case this.XML_CHAMP_TYPE_REGLETTE:
			// Pour les champs de type reglette, le style est sur le conteneur de la reglette (Pas de problemes)
			// mais il y a une surcharge du style pour toutes les balises A dans la ligne (car sinon les balises n'heritent pas du style)
			bSousElements = true;
			// Ajoute le comportement par defaut
			break;

		case WDChamp.prototype.ms_nIDObjetSaisie:
			// Sur les champs de saisie riche (et sur les champs de saisie avec indication)
			// Mais dans ce cas l'appel ne fait rien et c'est l'affectation sur le champ formulaire qui effectue le travail
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURFOND, null, sCouleur, oChamp, null]);
			// Ajoute le comportement par defaut
			break;

		case this.XML_CHAMP_TYPE_JAUGE:
		case this.XML_CHAMP_TYPE_GRAPHE:
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURFOND, null, sCouleur, oChamp, null]);
			// Sans le comportement par defaut
			return;

		case this.XML_CHAMP_TYPE_TABLEAUDEBORD:
			// Prend depuis l'ext�rieur dans le cas de ce champ
			oChamp = _JGE(sAliasChamp, document, false, true);
			break;

		// Mais pas de problemes avec les autres champs
		default:
			// Ajoute le comportement par defaut
			break;
		}
		// Comportement par defaut
		this.ActionProprieteStyleGenerique(oChamp, oChampExt, nTypeChamp, sAliasChamp, "backgroundColor", sCouleur, bSousElements);
	},

	// Etat d'un champ
	ActionProprieteEtat: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		// Recupere l'etat final
		var nEtat = this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_ETAT_ETAT);

		// Selon le type de champ
		switch (nTypeChamp)
		{
		case WDChamp.prototype.ms_nIDObjetSaisie:	// Gestion de l'etat dans les champs de saisie riche
		case this.XML_CHAMP_TYPE_GRAPHE:	
			// GP 14/11/2014 : QW251303 : Ajout du type graphe
			// Pour les champs de saisie riche : il faut detecter la modification de letat
			// Pour les champs de saisie avec un bouton calendrier : il faut modifier letat du bouton calendrier
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_ETAT, null, nEtat, oChamp, XMLAction]);
			break;
		// Champ qui genere des liens
		case WDChamp.prototype.ms_nIDObjetBouton:
		case this.XML_CHAMP_TYPE_LIEN:
		case this.XML_CHAMP_TYPE_MAPAREA:
		case this.XML_CHAMP_TYPE_SOUSMENU:			// Et aussi sur les options de menu
		case this.XML_CHAMP_TYPE_OPTIONMENU:
		case this.XML_CHAMP_TYPE_MENUPOPUP:
			// GP 04/01/2018 : TB106352 : Ne marche sur les volets d'onglets :
			// - La balise a n'est pas au niveau de oChamp
			// - On ne recoit pas les attributs dans XMLAction (puisque ce n'est pas un vrai lien...).
//		case this.XML_CHAMP_TYPE_VOLETONGLET:
			// Essai de trouver la collection des attributs de la balise A
			var oBaliseA = null;
			if (clWDUtil.bBaliseEstTag(oChamp, "a"))
			{
				oBaliseA = oChamp;
			}
			else if (clWDUtil.bBaliseEstTag(oChamp.parentNode, "a"))
			{
				oBaliseA = oChamp.parentNode;
			}
			else
			{
				// GP 27/04/2015 : TB92434 : Ce n'est pas "return" mais "break" => pour passer dans le code qui applique la classe wbgrise.
				break;
			}

			// Et la balise avec les attributs
			this._AppliqueAttributEtat(XMLAction, oBaliseA, nEtat, false);
			break;
		default:
			break;
		}

		function __bAppliqueGrise (oElement)
		{
			clWDUtil.ActiveDesactiveClassName(oElement, "wbgrise", 4 == nEtat);
			return true;
		};

		// GP 11/03/2014 : TB86493, Dans tous les cas, place les bons styles
		clWDUtil.bForEach(clWDUtil.tabGetElementsByClass(oChampExt, "wbstyle"), __bAppliqueGrise);
		// GP 23/11/2015 : TB94182 : Il faut aussi l'appliquer sur l'�l�ment lui m�me
		if (clWDUtil.bAvecClasse(oChampExt, "wbstyle"))
		{
			__bAppliqueGrise(oChampExt);
		}

		// GP 13/07/2020 : QW327381 : Transmet la valeur au framework V2.
		this.__bActionProprieteV2(nTypeChamp, sAliasChamp, 26 /*NSPCS.NSProprietes.EJS.Etat*/, nEtat, undefined);
	},

	// Applique les attribut d'une balise sur une autre
	_AppliqueAttributEtat: function(oXMLAction, oBaliseA, nEtat, bPourObjetChamp)
	{
		// GP 24/04/2018 : TB108301 : On peut ne pas avoir oXMLAction dans le cas d'un appel de ..Etat avec le framework V2 (Arrive dans le cas d'un champ de saisie avec bouton calendrier).
		if (oXMLAction)
		{
			// Et la balise avec les attributs
			var oBalise = oXMLAction.firstChild;

			// GP 30/05/2014 : TB87567 : Si la balise _DYN n'est pas dans le HTML on ne recoit rien comme oBalise
			if (oBalise)
			{
				// Parcours les attributs de oBalise pour les ajouter ou les supprimer du champ
				var tabAttributs = oBalise.attributes;
				var i;
				var nLimiteI = tabAttributs.length;
				for (i = 0; i < nLimiteI; i++)
				{
					var clAttribut = tabAttributs.item(i);
					var sNomAttribut = clWDUtil.sGetAttributNom(clAttribut);
					var sNomAttributMinuscule = sNomAttribut.toLowerCase();
					var sAttributValeur = clWDUtil.sGetAttributValeur(clAttribut);

					if (nEtat != 0)
					{
						// Si on desactive => Supprime l'attribut

						switch (sNomAttributMinuscule)
						{
						case "onmouseout":
						case "onmouseover":
						case "onclick":
							oBaliseA[sNomAttribut] = null;
							break;
						default:
							oBaliseA.removeAttribute(sNomAttribut, 0);
							break;
						}
					}
					else
					{
						// Ajoute/modifie l'attribut
						switch (sNomAttributMinuscule)
						{
						case "onmouseout":
						case "onmouseover":
							oBaliseA[sNomAttribut] = new Function("", "document." + sAttributValeur);
							break;
						case "onclick":
							if (bPourObjetChamp)
							{
								var sParametre = "";
								if (bFF && (-1 != (sAttributValeur + "").indexOf("event")))
								{
									sParametre = "event";
								}
								oBaliseA[sNomAttribut] = new Function(sParametre, sAttributValeur);
								break;
							}
							// falls through
						default:
							oBaliseA.setAttribute(sNomAttribut, sAttributValeur, 0);
							break;
						}
					}
				}
			}
		}
		else
		{
			// On fait le minimum pour tenter de d�sactiver ou de r�activer le bouton.
			if (nEtat != 0)
			{
				oBaliseA.setAttribute("disabled", "disabled");
				oBaliseA.sOldOnClick = oBaliseA.onclick;
				oBaliseA.onclick = null;
				oBaliseA.removeAttribute("onclick");
			}
			else
			{
				oBaliseA.removeAttribute("disabled");
				if (oBaliseA.sOldOnClick)
				{
					oBaliseA.onclick = oBaliseA.sOldOnClick;
					oBaliseA.removeAttribute("sOldOnClick");
				}
			}
		}
	},

	// Couleur de fond
	ActionProprieteVisible: function(oChamp, oPage, nTypeChamp, XMLAction, sAliasChamp)
	{
		// GP 02/03/2015 : Gestion du display:none dans les champs en mode flux.
		var bRelatifOuFlux = this.bXMLGetAttributSafe(XMLAction, this.XML_CHAMP_PROP_NUM_VISIBLE_PARENTRELATIF) || this.bXMLGetAttributSafe(XMLAction, this.XML_CHAMP_PROP_NUM_VISIBLE_PARENTFLUX);
		var bDisplay = false;
		var bVideSiAffiche = false;
		// GP 30/03/2015 : QW256727 : Prend le 'vrai' champ exterieur
		var bVisible = this.bXMLGetValeur(XMLAction);
		var oCible = this.__oChercheChamp(oPage, sAliasChamp, nTypeChamp, true, true, bRelatifOuFlux);

		// Selon le type du champ
		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_COLONNETABLE:
		case this.XML_CHAMP_TYPE_COLONNETABLEH:
			// Si c'est une table AJAX : on doit rechercher la cellule interne
			oCible = document.getElementById("tt" + sAliasChamp);
			bDisplay = true;
			// GP 30/03/2016 : Mettre aussi bVideSiAffiche a vrai ?
			break;
		case this.XML_CHAMP_TYPE_VOLETONGLET:
			// Cas des volets. Plus besoin de faire un cas particulier, clWDUtil.SetDisplay gere le cas du mode "table", "table-row", etc pour FF et IE en mode IE8
			// GP 11/12/2012 : TB78671 : Il faut utiliser le champ interne car sinon la recherche se trompe
			// L'ID des volets est de la forme : ALIAS_X, par exemple A2_1
			// Or la recherche du champ externe fait une recherche sans _. Donc si dans la page on a un champ A21, on risque de le trouver
			oCible = oChamp;
			// falls through
		case this.XML_CHAMP_TYPE_SOUSMENU:
		case this.XML_CHAMP_TYPE_OPTIONMENU:
		case this.XML_CHAMP_TYPE_MENUPOPUP:
			// Cas des elements de menu : on fait un display:none/block
			bDisplay = true;
			bVideSiAffiche = true;
			if (oCible)
			{
				// GP 25/02/2015 : TB88332 : Et si on a un visibility:hidden en plus on le supprime
				if (bVisible && ("hidden" == oCible.style.visibility))
				{
					oCible.style.visibility = "";
				}
			}
			else
			{
				// GP 11/02/2016 : TB96419/TB96541 : Si c'est un s�parateur de menu, oCible n'existe pas et il faut traiter les deux parties du s�parateur
				clWDUtil.bForEach(["H", "B"], function (sPrefixe)
				{
					clWDUtil.SetDisplay(document.getElementById(sPrefixe + "-" + sAliasChamp), bVisible);
					return true;
				});
			}
			break;

		case this.XML_CHAMP_TYPE_DISPOSITION_CELLULE:
			// GP 04/01/2018 : TB106601 : Il faut bien manipuler le bon �l�ment
			bDisplay = true;
			bVideSiAffiche = true;
			// GP 11/05/2018 : TB108636 : C'est pas clair. Soit l'ID a chang� de balise, soit il y a plusieurs cas.
			if (oCible)
			{
				if (!clWDUtil.bBaliseEstTag(oCible, "li"))
				{
					oCible = oCible.parentElement;
					clWDUtil.WDDebug.assert(clWDUtil.bBaliseEstTag(oCible, "li"), "Li non trouv�");
				}
			}
			break;

		default:
			// Si le parent est en positionnement relatif : .display
			// GP 02/03/2015 : Gestion du display:none dans les champs en mode flux.
			bDisplay = bRelatifOuFlux;
			bVideSiAffiche = bRelatifOuFlux;
			break;
		}
		if (bDisplay)
		{
			clWDUtil.SetDisplay(oCible, bVisible, bVideSiAffiche);
		}
		else if (oCible && oCible.style)
		{
			// Sinon .visibility
			// oCible est normalement le conteneur externe du champ
			oCible.style.visibility = bVisible ? "inherit" : "hidden";
		}
		// Notifie du changement de visibilite
		if (oCible)
		{
			AppelMethode(WDChamp.prototype.ms_sOnDisplay, [oCible, bVisible]);
		}
	},

	// ..Groupe
	ActionProprieteGroupe: function ActionProprieteImage(oChamp, nTypeChamp, XMLAction/*, sAliasChamp*/)
	{
		if (window.NSPCS)
		{
			try
			{
				NSPCS.NSChamps.DeclareGroupes(NSPCS.NSUtil.xoEvalJSON(this.sXMLGetValeur(XMLAction), false));
			}
			catch (e)
			{
			}
		}
	},

	// Image
	ActionProprieteImage: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		if (oChamp)
		{
			var sImage = this.sXMLGetValeur(XMLAction);
			// Selon le type du champ
			switch (nTypeChamp)
			{
			case this.XML_CHAMP_TYPE_PAGECORNEE:
				// Cas du champ page cornee, il faut manipuler le background-image
				oChamp.style.backgroundImage = clWDUtil.sGetURICSS(sImage);
				// Notifie le champ du changement de taille
				clWDUtil.oAppelFonctionChamp(sAliasChamp, WDCornage.prototype.ms_sInitTailleImage, [sImage]);
				break;
			default:
				oChamp.src = sImage;
				break;
			}
		}
	},

	// URL
	ActionProprieteURL: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		var oChampCpy = oChamp;
		// Selon le type du champ
		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_MAPAREA:
			// Sur les champs image clicable simple l'id est sur le IMG et la A autour n'en a pas
			if (oChamp && clWDUtil.bBaliseEstTag(oChamp, "img") && clWDUtil.bBaliseEstTag(oChamp.parentNode, "a"))
			{
				oChamp = oChamp.parentNode;
			}
			break;
		default:
			// On ne cherche pas le champ lui meme mais le champ autour pour avoir la balise a
			oChamp = _JGE(sAliasChamp, document, false, true);
			// Sauf que on ne trouve rien dans le cas des lien simples
			if (!oChamp)
			{
				oChamp = oChampCpy;
			}
			break;
		}
		// Soit on est directement sur le a ou sur le TB autour
		if (oChamp && clWDUtil.bBaliseEstTag(oChamp, "td"))
		{
			// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
			// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
			// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
			oChamp = oChamp.children[0];
		}
		if (oChamp)
		{
			var sURL = this.sXMLGetValeur(XMLAction);
			// Si le champ est un bouton, il faut faire autrement
			if (clWDUtil.bBaliseEstTag(oChamp, "input"))
			{
				// Normalement son action commence par javascript:_JCL('xxx');
				// Remplacer le premier parametre
				__PatchOnClick(oChamp, sAliasChamp, ms_oRegExpURLInput, function() { return "('" + sURL + "'"; });
			}
			else
			{
				oChamp.href = sURL;
			}
		}
	},

	// Bulle
	ActionProprieteBulle: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		// Fonction pour les bForEach
		function SetTitle (oElement)
		{
			oElement.title = sValeur;
			return true;
		};
		var sValeur = this.sXMLGetValeur(XMLAction);
		// selon le type du champ
		switch (nTypeChamp)
		{
		case WDChamp.prototype.ms_nIDObjetInterrupteur:
		case this.XML_CHAMP_TYPE_SELECTEUR:
			// Pour les interrupteurs/selecteurs : on a un tableau d'elements
			clWDUtil.bForEach(document.getElementsByName(sAliasChamp), SetTitle);
			// On ne fait pas le cas par defaut => sort direct
			return;

			// Cas special des table ou le champ trouve par defaut est le champ cache et pas la racine de la table
		case this.XML_CHAMP_TYPE_TABLE:
		case this.XML_CHAMP_TYPE_TABLEHIERARCHIQUE:
			oChamp = this.__oGetConteneurParent(sAliasChamp, nTypeChamp, false);
			break;

		// Cas special pour les volets d'onglets, on fait manipuler le lien en plus du champ
		case this.XML_CHAMP_TYPE_VOLETONGLET:
			if (oChamp)
			{
				clWDUtil.bForEach(oChamp.getElementsByTagName("a"), SetTitle);
			}
			break;

		// Cas special pour les jauge : on met la bulle sur le conteneur externe pour l'avoir sur toute la jauge
		case this.XML_CHAMP_TYPE_JAUGE:
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_BULLE, null, sValeur, null, null]);
			return;

		// On traite le champ bouton specialement : Si c'est un champ image on fait comme les images
		case WDChamp.prototype.ms_nIDObjetBouton:
			// On doit aussi manipuler le champ fils si disponible
			// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
			// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
			// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
			if (oChamp.children[0])
			{
				oChamp.children[0].title = sValeur;
			}
			break;
		}

		if (oChamp)
		{
			oChamp.title = sValeur;
		}
	},

	// CurseurSouris
	ActionProprieteCurseurSouris: function(oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.ActionProprieteStyleGenerique(oChampExt, null, nTypeChamp, sAliasChamp, "cursor", this.sXMLGetValeur(XMLAction), true);
	},

	// PoliceGras
	ActionProprietePoliceGras: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.ActionProprieteStylePolice(oChamp, oChampExt, nTypeChamp, sAliasChamp, "fontWeight", this.nXMLGetValeur(XMLAction), true);
	},

	// PoliceItalique
	ActionProprietePoliceItalique: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.ActionProprieteStylePolice(oChamp, oChampExt, nTypeChamp, sAliasChamp, "fontStyle", this.bXMLGetValeur(XMLAction) ? "italic" : "normal", true);
	},

	// PoliceNom
	ActionProprietePoliceNom: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.ActionProprieteStylePolice(oChamp, oChampExt, nTypeChamp, sAliasChamp, "fontFamily", this.sXMLGetValeur(XMLAction), true);
	},

	// PoliceSoulignee
	ActionProprietePoliceSoulignee: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.ActionProprieteStylePolice(oChamp, oChampExt, nTypeChamp, sAliasChamp, "textDecoration", this.bXMLGetValeur(XMLAction) ? "underline" : "none", true);
	},

	// PoliceTaille
	ActionProprietePoliceTaille: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.ActionProprieteStylePolice(oChamp, oChampExt, nTypeChamp, sAliasChamp, "fontSize", this.sXMLGetValeur(XMLAction), true);
	},

	// Opacite
	ActionProprieteOpacite: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		var nOpacite = this.nXMLGetValeur(XMLAction);
		if (isNaN(nOpacite))
		{
			nOpacite = 100;
		}
		else if (nOpacite < 0)
		{
			nOpacite = 0;
		}
		else if (nOpacite > 100)
		{
			nOpacite = 100;
		}

		// selon le type du champ
		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_GRAPHE:
			// GP 14/11/2014 : QW251686 :
			// - Graphe non int�ractif : cela change le dessin, il faut un grDessine
			// - Graphe int�ractif : change la valeur dans le champ
			// => Donc dans tous les cas il faut l'appel du champ (qui echoue dans le cas non int�ractif)
			// falls through
		case this.XML_CHAMP_TYPE_JAUGE:
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_OPACITE, null, nOpacite, oChamp, null]);
			return;
		case this.XML_CHAMP_TYPE_PAGECORNEE:
			// Prend le champ interieur
			break;
		default:
			// Prend le champ exterieur
			oChamp = oChampExt;
			break;
		}
		// GP 21/11/2012 : QW226469 : Appel de clWDUtil.nSetOpacite
		clWDUtil.nSetOpacite(nOpacite, oChamp);
	},

	// Cadrage horizontal
	ActionProprieteCadrageH: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.ActionProprieteStylePolice(oChamp, oChampExt, nTypeChamp, sAliasChamp, "textAlign", this.sXMLGetValeur(XMLAction), true);
	},

	// Cadrage vertical
	ActionProprieteCadrageV: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		this.ActionProprieteStylePolice(oChamp, oChampExt, nTypeChamp, sAliasChamp, "verticalAlign", this.sXMLGetValeur(XMLAction), true);
	},

	// Selectionnee
	ActionProprieteSelectionnee: function ActionProprieteSelectionnee(oChamp, oChampExt, nTypeChamp, XMLAction/*, sAliasChamp*/)
	{
		var bSelectionnee = this.bXMLGetValeur(XMLAction);

		// Seulement sur les options de menus.
		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_SOUSMENU:
		case this.XML_CHAMP_TYPE_OPTIONMENU:
		case this.XML_CHAMP_TYPE_MENUPOPUP:
			// Construit le tableau de remplacement des classes :
			// WDOngletOption <=> WDOngletOptionSelect
			// WDOngletOptionHover <=> WDOngletOptionHoverSelect
			// WDMenuOption <=> WDMenuOptionSelect
			// WDMenuOptionHover <=> WDMenuOptionHoverSelect
			var sSuffixeSelectOld = bSelectionnee ? "" : "Select";
			var sSuffixeSelectNew = bSelectionnee ? "Select" : "";
			clWDUtil.bForEach(["WDOngletOption", "WDMenuOption"], function (sClasse)
			{
				clWDUtil.bForEach(["", "Hover"], function (sSuffixe)
				{
					clWDUtil.RemplaceClassNameSiExiste(oChampExt, sClasse + sSuffixeSelectOld + sSuffixe, sClasse + sSuffixeSelectNew + sSuffixe);
					return true;
				});
				return true;
			});
			// GP 10/02/2017 : QW283806 : On active/d�sactive aussi la classe wbActif sur la balise a (pour les menus CSS)
			// Pas besoin de tester la validit� de getElementsByTagName : retourne toujours un tableau et [0] retourne undefined si l'�l�ment n'existe pas
			var oA = oChampExt.getElementsByTagName("a")[0];
			if (oA)
			{
				clWDUtil.ActiveDesactiveClassName(oA, "wbActif", bSelectionnee);
			}
			break;
		default:
			break;
		}
	},

	// Indication
	ActionProprieteIndication: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		// L'indication ne concerne que le champ de saisie
		// Celui-ci n'a pas de PCode serveur AJAX. Il n'a donc pas le focus actuellement (puisqu'un autre champ a declenche l'evenement)

		// Trouve l'objet
		clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_INDICATION, null, this.sXMLGetValeur(XMLAction), oChamp, null]);
	},

	// Bouton calendrier
	ActionProprieteBoutonCalendrier: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		// Trouve l'objet
		clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_BOUTONCALENDRIER, null, this.bXMLGetValeur(XMLAction), oChamp, null]);
	},

	// Pseudo contenu
	ActionProprieteContenu: function(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp)
	{
		switch (nTypeChamp)
		{
		case WDChamp.prototype.ms_nIDObjetImage:
		case this.XML_CHAMP_TYPE_MAPAREA:
		case this.XML_CHAMP_TYPE_VIGNETTE:
		case this.XML_CHAMP_TYPE_GRAPHE:
		case this.XML_CHAMP_TYPE_RANGESLIDER:
		case this.XML_CHAMP_TYPE_AGENDA:
		case this.XML_CHAMP_TYPE_VIDEO:
		case this.XML_CHAMP_TYPE_PLANNING:
		case this.XML_CHAMP_TYPE_JAUGE:
		case this.XML_CHAMP_TYPE_CARTE:
		case this.XML_CHAMP_TYPE_POTENTIOMETRE:
		case this.XML_CHAMP_TYPE_BANDEAU_DEFILANT:
			// La valeur recue est la description JSON du champ sous la forme d'un tableau [Parametres, Donnees]
			clWDUtil.oAppelFonctionChampPtr(sAliasChamp, WDChamp.prototype.DeduitParam, [this.sXMLGetValeur(XMLAction)]);
			break;
		case this.XML_CHAMP_TYPE_EDITEUR_DIAGRAMME:			
			var tabParametresDonnees = clWDUtil.oEvalJSON(this.sXMLGetValeur(XMLAction));
			oChamp.wbSetParametreDonnees(tabParametresDonnees[0],tabParametresDonnees[1]);
			break;

		default:
			// Appele la methode pre affectation pour liberer les evenements associees car les garbages
			// collector de IE n'arrivent pas a detecter les references circulaires (entre l'objet DOM et
			// l'objet JS) dans ce cas precis. Et au final l'objet n'est pas libere.
			// True : depuis une modification AJAX
			clWDUtil.oAppelFonctionChampPtr(sAliasChamp, WDChamp.prototype.PreAffecteHTML, [true]);

			// GP 28/08/2017 : Suppression des NSUtil.sEncodeInnerHTML(Chaine, false, true) qui ne font rien (sauf la conversion en chaine qui est inutile)
			oChampExt.innerHTML = this.sXMLGetValeur(XMLAction);

			// Restaure les evenements
			// True : depuis une modification AJAX
			clWDUtil.oAppelFonctionChampPtr(sAliasChamp, WDChamp.prototype.PostAffecteHTML, [true]);
		}
	},

	// Bouton calendrier
	ActionProprieteValeurSuperieure: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		// Trouve l'objet
		clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEURSUPERIEURE, null, this.sXMLGetValeur(XMLAction), oChamp, null]);
	},

	// Classe
	ActionProprieteClasseHTML: function(oChamp, oChampExt, nTypeChamp, XMLAction/*, sAliasChamp*/)
	{
		// TODO modification de la partie classe perso uniquement dans le seul class= du champ qui poss�de les classes persos
		// GP 11/02/2015 : QW254698 : Ajout de oChampExt
		// GP 11/02/2015 : QW254699 : Ajout du test sur HTMLCollection
		// GP 23/02/2015 : QW254699 : Ajout du test sur RadioNodeList (ce qui semble �tre retourn� par Firefox et Chrome)
		// GP 23/02/2015 : QW254699 : RadioNodeList ne semble pas disponible sous Chrome 40 (semble disponible sous Chrome 41 (en b�ta le 23/02/2015)
		// => On ne peut pas tester NodeList car il n'est pas d�fini dans Firefox (!!!)
		// GP 20/03/2015 : TB91624 : instanceof ne fonctionne pas en mode quirks (aucune des classes internes ne sont publiques)
		// => Utilise un autre test qui se base uniquement sur le contenu (1 < length car si il n'y a que un seul champ on ne recoit pas une collection)
		if (	(!oChamp)
			||	(	(!bIEQuirks)
				&&	(	(oChamp instanceof HTMLCollection)
					||	(window["RadioNodeList"] && (oChamp instanceof RadioNodeList))
					||	(window["NodeList"] && (oChamp instanceof NodeList))
					)
				)
			||	(	bIEQuirks
				&&	(1 < oChamp.length)
				&&	oChamp[0]
				&&	oChamp[0].tagName
				)
			)
		{
			oChamp = oChampExt;
		}
		oChamp.className = clWDUtil.sSetClasseHTML(this.sXMLGetValeur(XMLAction), oChamp);
	},

	// TexteAlternatif
	ActionProprieteTexteAlternatif: function(oChamp, nTypeChamp, XMLAction)
	{
		var sValeur = this.sXMLGetValeur(XMLAction);

		switch (nTypeChamp)
		{
		case WDChamp.prototype.ms_nIDObjetImage:
		case this.XML_CHAMP_TYPE_MAPAREA:
		case this.XML_CHAMP_TYPE_VIGNETTE:
		case this.XML_CHAMP_TYPE_GRAPHE:
		case this.XML_CHAMP_TYPE_CAPTCHA:
		case WDChamp.prototype.ms_nIDObjetCodeBarre:
			// Modifie le texte alternatif de l'image
			if (oChamp)
			{
				oChamp.alt = sValeur;
			}
			break;
		}
	},

	// Plan
	ActionProprietePlan: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{

		//la valeur est le contenu
		var nNumPlan;
		var sContenuHTML;
		var sChampsDisponibles;
		if (this.bXMLAttributExiste(XMLAction, "PLAN"))
		{
			nNumPlan = this.nXMLGetAttribut(XMLAction, "PLAN");
			sContenuHTML = this.sXMLGetValeur(XMLAction);
			sChampsDisponibles = this.sXMLGetAttribut(XMLAction, "FILS");
		}
		else
		{
			nNumPlan = this.nXMLGetValeur(XMLAction);
			//assert !isNaN(nNumPlan)
		}

		if (!this.__bActionProprieteV2(nTypeChamp, sAliasChamp, 31 /*NSPCS.NSProprietes.EJS.Plan*/, nNumPlan, { sContenuHTML: sContenuHTML }))
		{
			// Si pas de framework V2, c'est que ..Plan n'est pas manipul� en code navigateur donc pas besoin de faire la MAJ du champ cach�
			if (this.XML_CHAMP_TYPE_PAGEPRINCIPALE == nTypeChamp)
			{
				sAliasChamp = "MaPage";
			}
			$(".wbPlanDe" + sAliasChamp).wbPlanSet(nNumPlan, { sContenuHTML : sContenuHTML });
		}

		// D�clare tous les fils affich�s
		if (sChampsDisponibles && sChampsDisponibles.length)
		{
			// Notifie les champs nouvellement pr�sent
			clWDUtil.DeclareChampPlanDiffere(sChampsDisponibles.split(";"));
		}
	},

	// ImageFond
	ActionProprieteImageFond: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		if (!this.__bActionProprieteV2(nTypeChamp, sAliasChamp, 34 /*NSPCS.NSProprietes.EJS.ImageFond*/, this.sXMLGetValeur(XMLAction), undefined))
		{
			// Si pas de framework V2, on ne peut rien faire
		}
	},

	// CouleurJauge
	ActionProprieteCouleurJauge: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
			// On ne recupere la couleur qu'une fois
		var sCouleur = this.sXMLGetValeur(XMLAction);
		// Puis selon le type de champ on fait des actions differentes
		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_JAUGE:
			clWDUtil.oAppelFonctionChamp(sAliasChamp, WDChamp.prototype.ms_sSetProp, [WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURJAUGE, null, sCouleur, oChamp, null]);
			return;
		}
	},

	// BulleTitre
	ActionProprieteBulleTitre: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		if (!this.__bActionProprieteV2(nTypeChamp, sAliasChamp, 56 /*NSPCS.NSProprietes.EJS.BulleTitre*/, this.sXMLGetValeur(XMLAction), undefined))
		{
			// Si pas de framework V2, on ne peut rien faire
		}
		},

	// Aplique une propriete (liee a la police) du style sur un champ
	ActionProprieteStylePolice: function(oChamp, oChampExt, nTypeChamp, sAliasChamp, sNomStyle, sValeurProp, bSousElements)
	{
		var oCible = oChampExt;

		// selon le type du champ
		switch (nTypeChamp)
		{
		// Certains elements du formulaire son impermeable a la police de l'element du dessus (La police est dans le style)
		// Il faut donc appliquer la propriete au champ
		case WDChamp.prototype.ms_nIDObjetSaisie:
		case WDChamp.prototype.ms_nIDObjetBouton:
		case this.XML_CHAMP_TYPE_LISTE:
		case this.XML_CHAMP_TYPE_CHAMPFORMATE:
		case WDChamp.prototype.ms_nIDObjetCombo:
		case this.XML_CHAMP_TYPE_LIEN:
		case this.XML_CHAMP_TYPE_TREEVIEW:				// D'autres comme le treeview : il ne faut manipuler un id tres speficique (nom avec un _)
		case WDChamp.prototype.ms_nIDObjetLibelle:
			oCible = oChamp;
			break;

		case this.XML_CHAMP_TYPE_COLONNETABLE:
		case this.XML_CHAMP_TYPE_COLONNETABLEH:
			// Va modifier le style dans l'entete de la page
			this.ActionProprieteCouleurFeuilleStyle("#c-" + sAliasChamp, sNomStyle, sValeurProp);
			return;

		case this.XML_CHAMP_TYPE_JAUGE:
			oCible = oGetObjetChamp(sAliasChamp).m_oLibelleInterne;
			break;

		// GP 07/04/2015 : TB88198 : Factoris� dans ActionProprieteStyleGenerique
//		case WDChamp.prototype.ms_nIDObjetInterrupteur:
//		case this.XML_CHAMP_TYPE_SELECTEUR:
//			// Les interrupteurs et les selecteurs sont particulier
//			// GP 07/04/2015 : oChamp[0].name ? Ce n'est pas simplement sAliasChamp ?
//			oCible = _JGE(oChamp[0].name, document, false, true);
//			break;

		default:
			// Garde la cible par defaut (oChampExt)
			break;
		}
		this.ActionProprieteStyleGenerique(oCible, oChampExt, nTypeChamp, sAliasChamp, sNomStyle, sValeurProp, bSousElements);
	},

	// Aplique une propriete du style sur un champ
	ActionProprieteStyleGenerique: function(oChamp, oChampExt, nTypeChamp, sAliasChamp, sNomStyle, sValeurProp, bSousElements)
	{
		// Uniquement avec un champ
		if (oChamp)
		{
			// Si on demande de traiter les sous �l�ments
			if (bSousElements)
			{
				// selon le type du champ
				switch (nTypeChamp)
				{
				case WDChamp.prototype.ms_nIDObjetInterrupteur:
				case this.XML_CHAMP_TYPE_SELECTEUR:
					// GP 07/04/2015 : TB88198 : Les interrupteurs et les selecteurs sont particulier
					if (	(	(!bIEQuirks)
							&&	(	(oChamp instanceof HTMLCollection)
								||	(window["RadioNodeList"] && (oChamp instanceof RadioNodeList))
								||	(window["NodeList"] && (oChamp instanceof NodeList))
								)
							)
						||	(	bIEQuirks
							&&	(1 < oChamp.length)
							&&	oChamp[0]
							&&	oChamp[0].tagName
							)
						)
					{
						clWDUtil.bForEach(oChamp, function(oElement)
						{
							var oParentNode = oElement.parentNode;
							if (oParentNode && clWDUtil.bBaliseEstTag(oParentNode, "label"))
							{
								oElement = oParentNode;
							}
							oElement.style[sNomStyle] = sValeurProp;
							return true;
						});
					}
					// GP 19/05/2015 : QW257070 : Non sinon on n'a pas le m�me comportement que ..CouleurFond en serveur et en navigateur
					// GP 18/02/2015 : QW255007 : On recoit ALIAS[] comme alias du champ interrupteur en PHP
					oChamp = _JGE((sAliasChamp.substr(sAliasChamp.length - 2, 2) == "[]") ? sAliasChamp.substr(0, sAliasChamp.length - 2) : sAliasChamp, document, false, true);
//					// Garde l'ancien code pour avoir la couleur sur le fond
//					if (oChampExt)
//					{
//						oChamp = oChampExt;
//					}
					break;

				case this.XML_CHAMP_TYPE_CHEMINNAV:
				case this.XML_CHAMP_TYPE_PLANSITE:
				case this.XML_CHAMP_TYPE_REGLETTE:
				case this.XML_CHAMP_TYPE_TREEVIEW:
					// Il faut faire de meme pour les liens du chemin de navigation
					// Applique une propriete du style sur les liens d'une reglette
					clWDUtil.bForEach(oChamp.getElementsByTagName("a"), function(oLienA)
					{
						oLienA.style[sNomStyle] = sValeurProp;
						return true;
					});
					break;
				default:
					break;
				}
			}
			if (oChamp.style)
			{
				oChamp.style[sNomStyle] = sValeurProp;
			}
		}
	},

	// Modifie la couleur ou la couleur de fond dans les styles present dans les feuilles de style
	ActionProprieteCouleurFeuilleStyle: function(sSelecteur, sStyle, sValeur)
	{
		// On modifie le style a la racine
		var tabStyles = document.getElementsByTagName("style");
		var i;
		var nLimiteI = tabStyles.length;
		for (i = 0; i < nLimiteI; i++)
		{
			// GP 14/11/2013 : Utilise le code commun.
			// Un seul inconv�nient, il ne trouve que la premi�re r�gle dans cette feuille avec ce nom (mais il n'y en a que une normalement)
			var oRule = clWDUtil.oStyleTrouveDansBalise(tabStyles[i], sSelecteur);
			if (oRule)
			{
				oRule.style[sStyle] = sValeur;
			}
		}
	},

	// Modifie une propri�t� dans le framework V2
	__bActionProprieteV2 : function (nTypeChamp, sAliasChamp, eProprieteJS, oValeur, oParametresSpecifiquesOuUndefined)
	{
		if (window["NSPCS"])
		{
			// Utile ? On ne re�oit pas d�j� l'alias de la page ?
			var iPageOuChamp;
			if (1 /*NSPCS.NSChamps.EIDObjet.PagePrincipale*/ == nTypeChamp)
			{
				iPageOuChamp = NSPCS.NSChamps.oGetPageCourante();
			}
			else
			{
				iPageOuChamp = NSPCS.NSChamps.oGetChamp(sAliasChamp, nTypeChamp);
			}
			if (iPageOuChamp)
			{
				iPageOuChamp.viGetPropriete(1 /*NSPCS.NSProprietes.EFamille.JS*/, eProprieteJS).vSetValeur(oValeur, 0 /*NSPCS.NSOperations.EAffectation.Directe*/, { m_oParametresSpecifiques: oParametresSpecifiquesOuUndefined });
			}
			return true;
		}

		return false;
	},

	// Execute un code JS sur l'objet
	ActionChampJS: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		var sAction = this.sXMLGetValeur(XMLAction);
		if (!oChamp)
		{
			// Essai avec un getElementById
			oChamp = _JGE(sAliasChamp, document);
		}

		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_VOLETONGLET:
			// GP 14/05/2013 : TB106352 : Cas special pour les volets d'onglets, on fait manipuler le lien
			// Sauf que du code de compatibilit� dans WDxxxPage ajoute le .getElementsByTagName("a") (pour TB64014 mais c'est dans le cas gris�).
			// => C'est vraiment pas clair. Prend la correction la plus simple : teste ici le cas
			if (oChamp && (-1 === sAction.indexOf("getElementsByTagName")))
			{
				var tabBalisesA = oChamp.getElementsByTagName("a");
				if (tabBalisesA.length)
				{
					oChamp = tabBalisesA[0];
				}
			}
			break;
		}

		// Note : en mode strict oChamp n'est pas un alias de arguments[0] donc on passe pas une fonction anonyme
		if (oChamp)
		{
			(function ()
			{
				// GP 30/08/2012 : QW222074 : En release, le code est minifi�. Donc oChamp est renomm�. On utilise maintenant arguments[0] qui est aussi valide
				eval("arguments[0]" + sAction);
			})(oChamp);
		}
	},

	// Ajoute des options au champ
	ActionChampOptions: function ActionChampOptions(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		// Uniquement avec un champ
		if (oChamp)
		{
			// On parcourt les options du champ
			var XMLOption = XMLAction.firstChild;
			var nIndiceOption = 1;
			while (XMLOption)
			{
				// ID de l'option dans le cas des interrupteurs
				var sIDOption = sAliasChamp + "_" + nIndiceOption;
				// Selon l'option transmise
				switch (XMLOption.nodeName)
				{
				// Option simple
				default:
				case this.XML_CHAMP_OPTIONS_OPTION:
					switch (nTypeChamp)
					{
					case WDChamp.prototype.ms_nIDObjetInterrupteur:
						// GP 24/02/2016 : TB84927 : Gestion du libell� des interrupteurs
						var oOption = document.getElementById(sIDOption);
						switch (this.nXMLGetAttributSafe(XMLOption, this.XML_CHAMP_OPTIONS_OPTION_COCHE, 0))
						{
						default:
							clWDUtil.WDDebug.assert(false, "Valeur de coche invalide");
							break;
						case 1:
							// Coch� = 1
							oOption.checked = true;
							break;
						case 2:
							// D�coch� = 2
							oOption.checked = false;
							break;
						case 3:
							// Non d�fini = 3
							break;
						}
							this.__OptionParLabelFor(XMLOption, sIDOption, 1);
						break;

					case this.XML_CHAMP_TYPE_SELECTEUR:
						// GP 24/02/2016 : TB84927 : Gestion du libell� des interrupteurs
							this.__OptionParLabelFor(XMLOption, sIDOption, 1);
						break;

					case WDChamp.prototype.ms_nIDObjetInterrupteurABascule:
						// GP 03/04/2019 : TB112924 : Gestion du libell� des interrupteurs � bascule en code AJAX avec deux niveaux de spans.
						// Vu avec GF : il y a deux niveaux de spans, le niveau internet est pour le centrage vertical. Il est normalement TOUJOURS pr�sent.
							this.__OptionParLabelFor(XMLOption, sIDOption, 2);
						break;

					default:
						// On ajoute l'option
						oChamp.options[oChamp.options.length] = new Option(this.sXMLGetValeur(XMLOption), oChamp.options.length + 1);
						// GP 28/08/2017 : Vu avec TB104810 : L'appel de sEncodeInnerHTML(xxx, false, true) est compl�tement inutile.
						// Il ne fait aucune transformation sauf de forcer la valeur en chaine, mais on sait que ce que l'on recoit est d�j� une chaine
//						// Il y a un problemes avec les carteres > 127
//						oChamp.options[oChamp.options.length - 1].innerHTML = clWDUtil.sEncodeInnerHTML(oChamp.options[oChamp.options.length - 1].innerHTML, false, true);
						break;
					}
					nIndiceOption++;
					break;
				// Liste sature
				case this.XML_CHAMP_SATURATION:
					//assert(oChamp.options.length == 0);
					//assert(!XMLOption.nextSibling);
					// On ajoute l'option
					oChamp.options[oChamp.options.length] = new Option(this.sXMLGetValeur(XMLOption), -1);
					break;
				}
				// Option suivante
				XMLOption = XMLOption.nextSibling;
			}
		}
	},
	__OptionParLabelFor: function __OptionParLabelFor(XMLOption, sIDOption, nNbNiveauxDeSpans)
	{
		// GP 04/04/2016 : QW271624 : Uniquement si document.querySelector est disponible (non disponible en mode quirks)
		if (document.querySelector)
		{
			var oLabel = document.querySelector("label[for='" + sIDOption + "']");
			if (oLabel)
			{
				var oElement = oLabel;
				for (var nNiveauDeSpan = 0; nNiveauDeSpan < nNbNiveauxDeSpans && oElement; nNiveauDeSpan++)
				{
					var tabSpans = oElement.getElementsByTagName("span");
					oElement = tabSpans && tabSpans[0];
				}
				if (oElement)
				{
					// GP 07/04/2017 : TB102360 : Indique si le libell� est riche (HTML)
					var bLibelleRiche = this.bXMLGetAttributSafe(XMLOption, this.XML_CHAMP_OPTIONS_OPTION_HTML);
					oElement.innerHTML = clWDUtil.sEncodeInnerHTML(this.sXMLGetValeur(XMLOption), !bLibelleRiche, bLibelleRiche);
				}
			}
		}
	},

	// Modifie les lignes d'une table/d'un zone repetee
	ActionChampLignes: function ActionChampLignes(oChamp, nTypeChamp, XMLAction, sAliasChamp, oPage)
	{
		var oObjetChamp = oGetObjetChamp(sAliasChamp);
		// GP 01/02/2013 : Sauf si c'est une ZR horizontale (ou navigateur (ici normalement non concern�) ou autre) (qui n'a pas la m�thode)
		if (oObjetChamp && oObjetChamp.bActionListeDepuisAJAX)
		{
			// C'est une table ou une ZR AJAX
			oObjetChamp.bActionListeDepuisAJAX(XMLAction, -1);
		}
		else if (oChamp)
		{
			this.ActionChampLignesInterne(oChamp, nTypeChamp, XMLAction, sAliasChamp, oPage);
		}
	},

	// Modifie les lignes d'une table/d'un zone repetee
	ActionChampLignesInterne: function ActionChampLignesInterne(oChamp, nTypeChamp, XMLAction, sNomChamp, oPage)
	{
		// On recupere les attributs de la ZR/Table
		// Indice du premier element
		var nDebut = this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_LIGNES_DEBUT);
		// Nombre d'element
		var nNombre = this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_LIGNES_NOMBRE);
		// Ligne selectionne
		var nSelection = this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_LIGNES_SELECTION);
		//asert(nNombre<=nLimite);
		var nNbRuptures = this.nXMLGetAttributSafe(XMLAction, this.XML_CHAMP_LIGNES_RUPTURES, 0);
		// Multicolonnes ?
		var nMultiColonnes = this.nXMLGetAttributSafe(XMLAction, this.XML_CHAMP_LIGNES_COLONNES, 1);
		var bMultiColonnes = (1 < nMultiColonnes);

		// Zone de donnees
		var oChampData = oPage[sNomChamp + "_DATA"];
		if (oChampData)
		{
			oChampData.value = this.sXMLGetAttributSafe(XMLAction, this.XML_CHAMP_LIGNES_DATA, "");
		}

		// On recupere le debut actuel
		// GP 07/01/2016 : TB93214 : Probl�me avec "_DEB" : Ici on est toujours le contexte d'une table classique ou la valeur �tait correcte.
		var nDebutActuel = parseInt(oPage[sNomChamp + "_DEB"].value, 10);
		var nIndiceActuel;

		// On trouve le conteneur des lignes de la table
		// On a deux conteneur : le conteneur parent logique (Souvent une balise TABLE) et le conteneur physique reel
		// qui dans le cas d'une table est une balise TBODY ajoute (+/- automatiquement par le navigateur)
		var oConteneurParent = this.__oGetConteneurParent(sNomChamp, nTypeChamp, true);
		var oConteneurTBody = this.__oGetConteneurTBODY(oConteneurParent, nTypeChamp);

		// Pour les lignes existantes
		// On a trois cas :
		// - IE + Champ table : on remplace le contenu de la ligne de table par celui renvoye par le moteur
		// - IE + ZR : on remplace l'interieur de la ligne (Exterieur du DIV) de table par celle renvoye par le moteur
		// - Autres : on fait un remplace avec les methodes du DOM

		// Supprime les lignes en trop au debut
		while ((nDebutActuel < nDebut) && this.__bSupprimeLigne(sNomChamp, nTypeChamp, nDebutActuel, nNbRuptures, oConteneurParent, oConteneurTBody))
		{
			nDebutActuel++;
		}

		// Ou les lignes en trop apres la fin
		if (nDebutActuel >= nDebut + nNombre)
		{
			while (this.__bSupprimeLigne(sNomChamp, nTypeChamp, nDebutActuel, nNbRuptures, oConteneurParent, oConteneurTBody))
			{
				nDebutActuel++;
			}
		}

		// Si on est dans une ZR supprime les ruptures AVANT de lire le HTML de la table
		// GP 08/11/2014 : QW251233 : Les tables aussi ont des ruptures
		// GP 28/11/2014 : OPTIM : Inutile de fait le code si on n'a pas de ruptures
		if (0 < nNbRuptures)
		{
			switch (nTypeChamp)
			{
			case this.XML_CHAMP_TYPE_TABLE:
			case this.XML_CHAMP_TYPE_ZONEREPETEE:
				var XMLLigneLoc = XMLAction.firstChild;
				while (XMLLigneLoc)
				{
					// Recupere le numero de la ligne modifiee
					nIndiceActuel = this.nXMLGetAttribut(XMLLigneLoc, this.XML_CHAMP_LIGNES_LIGNE_INDICE);

					// On supprime les ruptures de la ligne car sCorps les contient et cree plusieurs balises paralleles
					this.__SupprimeRuptures(sNomChamp, nIndiceActuel, nNbRuptures, oConteneurTBody);
					// Ligne suivante
					XMLLigneLoc = XMLLigneLoc.nextSibling;
				}
				break;
			}
		}

		var oFils;

		// Si on a une reaffichage complet : supprime toutes les lignes en une seule fois
		// Cela facilite ensuite la MAJ
		if (1 == this.nXMLGetAttributSafe(XMLAction, this.XML_CHAMP_REFRESH_RESETTABLE, 0))
		{
			// GP 28/11/2014 : QW252593 : Il ne faut pas supprimer :
			// - La ligne avec le libell� de la table
			// - La ligne de titre
			// - La ligne sous le titre qui fait la largeur des colonnes sont a des colonnes fusionn�es
			// => On trouve la ligne de titre et on se base sur elle pour savoir ce qu'il faut supprimer
			var sIDLigneTitre = "tt" + sNomChamp;
			var oLigneTitre = document.getElementById(sIDLigneTitre);
			// V�rification suppl�mentaire : v�rifie que la ligne de titre est bien dans la table
			if (oLigneTitre && !clWDUtil.bEstFils(oLigneTitre, oConteneurTBody))
			{
				oLigneTitre = null;
			}

			var tabChildNodes = oConteneurTBody.childNodes;
			// Supprime d'abord les balises texte qui g�nent le parcours : suppression inverse car tabChildNodes est modifi� en direct avec les suppressions
			clWDUtil.bForEachInverse(tabChildNodes, function (oFils)
			{
				if (oFils.nodeName == "#text")
				{
					oConteneurTBody.removeChild(oFils);
				}
				return true;
			});
			var nLigne = 0;
			while (nLigne < tabChildNodes.length)
			{
				oFils = tabChildNodes[nLigne];
				if (!oLigneTitre)
				{
					// Cas g�n�ral : on n'a pas/plus la ligne ligne de titre : supprime la ligne
					oConteneurTBody.removeChild(oFils);
				}
				else
				{
					// Si on a encore la ligne de titre, c'est que l'on ne l'a encore pas crois�e.
					// Si ce n'est pas (encore) la ligne de titre : l'ignore
					// Si c'est la ligne de titre : v�rifie la ligne suivant (ligne de largeur des colonnes)
					if (oFils == oLigneTitre)
					{
						// V�rifie si la ligne suivante n'est pas la ligne qui fait la largeur des colonnes
						if (((nLigne + 1) < tabChildNodes.length) && (tabChildNodes[nLigne + 1].offsetHeight <= 1))
						{
							nLigne++
						}
						// Il faut maintenant supprimer les lignes qui suivent
						oLigneTitre = null;
					}
					// Dans tous les cas ignore la ligne
					nLigne++;
				}
			}

			// On supprime aussi tous les styles li�es � la table
			var sPrefixeStyleTable = "rgs-" + sNomChamp + "-";
			// GP 12/03/2015 : Le tableau est modifi� en direct avec la suppression des styles : on fait une boucle inverse
			clWDUtil.bForEachInverse(document.getElementsByTagName("style"), function (oBaliseStyle)
			{
				var oId = oBaliseStyle.id;
				if (oId && (sPrefixeStyleTable == oId.substr(0, sPrefixeStyleTable.length)))
				{
					oBaliseStyle.parentNode.removeChild(oBaliseStyle);
				}
				return true;
			});
		}

		// Pour le premier cas on lit d'une fois le outerHTML de la table pour que le traitement soit plus rapide
		// Recupere le contenu du conteneur actuel (Sans espaces ni RC superflus)
		var sContenuActuelTable;
		if (bIE)
		{
			// Pas de scope en JS donc sContenuActuelTable existe meme a la sortie du block
			// Dans le cas des ZR extensible en largeur ici on est dans le TD parent
			if (clWDUtil.bBaliseEstTag(oConteneurParent, "td"))
			{
				sContenuActuelTable = oConteneurParent.innerHTML;
			}
			else
			{
				sContenuActuelTable = oConteneurParent.outerHTML;
			}

			sContenuActuelTable = this.sSupprimeEspacements(sContenuActuelTable);
		}

		// GP 02/04/2013 : TB81834 : Optim : mise en cache des valeurs
		var nPosTBody;
		var nPosTR;

		// On parcourt les lignes du champ
		var XMLLigne;
		// OPTIM : Lors de la recherche de la rupture de ligne suivante on a une recherche en n^2 possible
		// Par exemple si la seule ligne pr�sente est la ligne "n"
		// => Si on a joute "n" lignes (entre 1 et "n") alors pour la ligne 1, on recherche de 2 a n.
		// Pour la la ligne 2 de 2 a n etc.
		// Comme nIndiceActuel va en croissant on note la valeur la plus grande trouvee
		var nLigneSuivante = -1;
		var bAvecStyle = this.bXMLAttributExiste(XMLAction, this.XML_CHAMP_LIGNES_STYLE);
		for (XMLLigne = XMLAction.firstChild; XMLLigne; XMLLigne = XMLLigne.nextSibling)
		{
			//assert(XMLLigne.nodeName == this.XML_CHAMP_LIGNES_LIGNE);

			// Recupere le numero de la ligne modifiee
			nIndiceActuel = this.nXMLGetAttribut(XMLLigne, this.XML_CHAMP_LIGNES_LIGNE_INDICE);

			// On trouve la ligne actuelle avec l'ID actuel
			var oLigne = this.__oGetConteneurLigne(sNomChamp, nIndiceActuel, oConteneurTBody);

			// Recupere les trois partie de la ligne
			// Optimisation : dans certains cas, si debut et fin sont vide, seule la balise corps est transmise
			var bCorpsSeul = XMLLigne.childNodes.length == 1;
			// GP 28/08/2017 : Suppression des NSUtil.sEncodeInnerHTML(Chaine, false, true) qui ne font rien (sauf la conversion en chaine qui est inutile)
			//assert(XMLLigne.childNodes[0].nodeName==this.XML_CHAMP_LIGNES_LIGNE_DEBUT);
			var sDebut = bCorpsSeul ? "" : clWDUtil.sSupprimeEspacesDebutFin(this.sXMLGetValeur(XMLLigne.childNodes[0]));
			//assert(XMLLigne.childNodes[1].nodeName==this.XML_CHAMP_LIGNES_LIGNE_CORPS);
			var sCorps = clWDUtil.sSupprimeEspacesDebutFin(this.sXMLGetValeur(XMLLigne.childNodes[bCorpsSeul ? 0 : 1]));
			//assert(XMLLigne.childNodes[2].nodeName==this.XML_CHAMP_LIGNES_LIGNE_FIN);
			var sFin = bCorpsSeul ? "" : clWDUtil.sSupprimeEspacesDebutFin(this.sXMLGetValeur(XMLLigne.childNodes[2]));

			var bInvisible = this.bXMLGetAttributSafe(XMLLigne, this.XML_CHAMP_LIGNES_LIGNE_INVISIBLE);
			var bRepliee = this.bXMLGetAttributSafe(XMLLigne, this.XML_CHAMP_LIGNES_LIGNE_REPLIEE);

			var sContenu = sDebut + sCorps + sFin;
			var sDebutContenu;

			// Change le(s) style(s) des lignes si on doit aussi gerer les styles
			if (bAvecStyle)
			{
				// Si on a une quatrieme node fille c'est que l'on a un style a modifie pour la ligne
				//assert((!bStyle) || (XMLLigne.childNodes.length >= 4));
				//assert((!bStyle) || (XMLLigne.childNodes[3].nodeName==this.XML_CHAMP_LIGNES_LIGNE_STYLE));
				this.ActionLigneStyle(sNomChamp, nIndiceActuel, this.sXMLGetValeur(XMLLigne.childNodes[3]));
			}

			if (!bInvisible && !oLigne)
			{
				// Si la ligne n'est pas masque mais que elle n'existe pas et est inseree au millieu
				var oLigneSuivante = null;
				var nLimiteLigneSuivante = nDebut + nNombre;
				for (nLigneSuivante = Math.max(nLigneSuivante - 1, nIndiceActuel + 1); (nLigneSuivante < nLimiteLigneSuivante) && (!oLigneSuivante); nLigneSuivante++)
				{
					// Tente en premier avec les ruptures de la ligne
					oLigneSuivante = this.__oTrouveRuptureExterne(sNomChamp, true, nLigneSuivante, nNbRuptures, oConteneurTBody);
					if (!oLigneSuivante)
					{
						oLigneSuivante = this.__oGetConteneurLigne(sNomChamp, nLigneSuivante, oConteneurTBody);
					}
				}
				if (oLigneSuivante)
				{
					if (0 < sContenu.length)
					{
						// Une ligne existe, il faut ajouter le html avant cette ligne
						if (bIE)
						{
							// Si on peux utiliser outerHTML
							var sContenuLigneSuivante = oLigneSuivante.outerHTML;
							sContenuLigneSuivante = this.sSupprimeEspacements(sContenuLigneSuivante);

							// Et la position de la ligne suivante dans cette table
							// Cela fonctionne car on a vire les espaces et RC que les navigateur ajoutes
							var nPositionLigneSuivante1 = sContenuActuelTable.indexOf(sContenuLigneSuivante);
							var nPositionLigneSuivante2 = nPositionLigneSuivante1;
							// Si on est en multicolonne et que l'on commence une ligne
							sDebutContenu = sContenu.substr(0, 4).toLowerCase();
							if ((sDebutContenu = "<tr>") && (sDebutContenu == sContenuActuelTable.substr(nPositionLigneSuivante1 - 4, 4).toLowerCase()))
							{
								nPositionLigneSuivante1 -= 4;
							}
							sContenuActuelTable = sContenuActuelTable.substring(0, nPositionLigneSuivante1) + sContenu + sContenuActuelTable.substring(nPositionLigneSuivante2);
							nPosTR = nPosTBody = undefined;
						}
						else
						{
							// Si la ligne est un <tr> complet
							if (this.__bHTMLDebutTR(sContenu))
							{
								if (clWDUtil.bBaliseEstTag(oLigneSuivante, "td"))
								{
									oLigneSuivante = oLigneSuivante.parentNode;
								}
								// !bRepliee : Si la ligne ne contient que un haut de rupture, on ne doit pas supprimer la ligne complete
								if (!bRepliee && (sContenu.substr(sContenu.length - 5, 5).toLowerCase() != "</tr>"))
								{
									this.__InsereRemplaceTrTdDansTable(oLigneSuivante, sContenu, true, null);
								}
								else
								{
									this.__InsereElementDansTable(oLigneSuivante, sContenu);
								}
							}
							else if (sContenu.substr(sContenu.length - 5, 5).toLowerCase() == "</tr>")
							{
								if (clWDUtil.bBaliseEstTag(oLigneSuivante, "td"))
								{
									oLigneSuivante = oLigneSuivante.parentNode;
								}
								this.__InsereRemplaceTrTdDansTable(oLigneSuivante, sContenu, false, null);
							}
							else
							{
								// Il faut ajouter la ligne avant
								// On est forcement dans la ligne precedente
								// (Sauf si on a une ligne invisible
								this.__AjouteElementDansTable(oLigneSuivante.parentNode.previousElementSibling, sContenu);
							}
						}
					}
					// Et ne plus faire la suite du traitement
					continue;
				}
			}

			// Si on trouve la ligne : on change uniquement son HTML
			if (oLigne)
			{
				// Si on peux utiliser outerHTML
				if (bIE)
				{
					if (bInvisible)
					{
						sContenu = "";
					}

					// Pour IE
					// Et de la ligne actuelle (Sans espaces ni RC superflus)
					var sContenuActuelLigne = oLigne.outerHTML;
					sContenuActuelLigne = this.sSupprimeEspacements(sContenuActuelLigne);

					// Et la position de la ligne actuelle dans cette table
					// Cela fonctionne car on a vire les espaces et RC que les navigateur ajoutes
					var nPositionActuelleLigne = sContenuActuelTable.indexOf(sContenuActuelLigne);
					var nTailleActuelleLigne = sContenuActuelLigne.length;
					// Si on est dans le cas d'un multicolonne et que l'on va doubler les balise de debut et de fin : les supprimes
					var bDebutContenuTR = this.__bHTMLDebutTR(sContenu);
					var bDebutContenuTD = this.__bHTMLDebutTD(sContenu);
					var bAvantLigneTR = ("<tr>" == sContenuActuelTable.substr(nPositionActuelleLigne - 4, 4).toLowerCase());
					if (bDebutContenuTR && bAvantLigneTR)
					{
						nPositionActuelleLigne -= 4;
						nTailleActuelleLigne += 4;
					}
					sDebutContenu = sContenu.substr(0, 9).toLowerCase();
					if ((sDebutContenu == "</tr><tr>") && (sDebutContenu == sContenuActuelTable.substr(nPositionActuelleLigne - 9, 9).toLowerCase()))
					{
						nPositionActuelleLigne -= 9;
						nTailleActuelleLigne += 9;
					}
					if (bMultiColonnes)
					{
						var sFinContenu = sContenu.substr(sContenu.length - 5, 5).toLowerCase();
						// Si on a une ZR multicolonne avec des lignes repliees, ce test ne marche pas forcement
						// car on aura bien </tr></TR> mais on ne l'a pas encore car les autres colonnes qui ne sont plus visibles
						// ne sont pas encore masquees
						// On a actuellement (<nouvelle version avec </tr>)(<Ligne dans la cellule suivante avec <td> et </td>)*</tr>
						// Le cas est gerer a la fin en supprimant les doubles </tr></TR>
						if ((sFinContenu == "</tr>") && (sFinContenu == sContenuActuelTable.substr(nPositionActuelleLigne + nTailleActuelleLigne, 5).toLowerCase()))
						{
							nTailleActuelleLigne += 5;
						}
						else
						{
							if (sContenuActuelLigne.substr(nTailleActuelleLigne - 5, 5).toLowerCase() == "</tr>")
							{
								// Ne supprime pas le dernier </tr> (cest que l'on est sur la derniere ligne). On en a besoin pour fermer la table)
								nTailleActuelleLigne -= 5;
							}
							if (bDebutContenuTR && (sContenuActuelTable.substr(nPositionActuelleLigne + nTailleActuelleLigne, 5).toLowerCase() == "</tr>"))
							{
								// Si la nouvelle ligne ne termine pas la ligne (elle ne contient donc pas un </tr>) mais que la ligne actuelle oui (mais apres la ligne)
								// Alors il faut decaler la fin de la ligne
								sContenu = "</tr>" + sContenu;
								nTailleActuelleLigne += 5;
							}
							if (bDebutContenuTD && bAvantLigneTR)
							{
								// On est plus en debut de ligne
								// Comme la ligne a ete modifie, normalement la ligne precedente a ete modifie aussi
								nPositionActuelleLigne -= 4;
								nTailleActuelleLigne += 4;
							}
						}
					}

					// Et remplace cette ligne
					sContenuActuelTable = sContenuActuelTable.substring(0, nPositionActuelleLigne) + sContenu + sContenuActuelTable.substring(nPositionActuelleLigne + nTailleActuelleLigne);
					nPosTR = nPosTBody = undefined;
				}
				else
				{	// Pour les autres navigateur

					// On ne va ecrire que le corps
					oLigne = document.getElementById(sNomChamp + "_" + nIndiceActuel);


					// On supprime les ruptures de la ligne car sContenu les contient et cree plusieurs balises paralleles
					if (nTypeChamp == this.XML_CHAMP_TYPE_ZONEREPETEE)
					{
						this.__SupprimeRuptures(sNomChamp, nIndiceActuel, nNbRuptures, oConteneurTBody);
					}

					// Si on demande la suppression de la ligne
					if (bInvisible)
					{
						if (clWDUtil.bBaliseEstTag(oLigne, "div") && clWDUtil.bBaliseEstTag(oLigne.parentNode, "td") && this.__bAvecFilsActifUnique(oLigne.parentNode))
						{
							oLigne = oLigne.parentNode;
							if (clWDUtil.bBaliseEstTag(oLigne.parentNode, "tr") && this.__bAvecFilsActifUnique(oLigne.parentNode))
							{
								oLigne = oLigne.parentNode;
							}
						}
						clWDUtil.oSupprimeElement(oLigne);
					}
					else
					{
						if (clWDUtil.bBaliseEstTag(oLigne, "div") && clWDUtil.bBaliseEstTag(oLigne.parentNode, "td"))
						{
							oLigne = oLigne.parentNode;
						}
						// Si la ligne est un <tr> complet
						if (this.__bHTMLDebutTR(sCorps))
						{
							var oLigneTD = oLigne;
							if (clWDUtil.bBaliseEstTag(oLigne, "td"))
							{
								oLigne = oLigne.parentNode;
							}
							// Si la ligne ne contient que un haut de rupture, on ne doit pas supprimer la ligne complete
							if (bRepliee)
							{
								this.__InsereElementDansTable(oLigne, sCorps);
								// On supprime donc le td (dans oLigneOld) sauf si on est le seul fils
								oLigne = this.__bAvecFilsActifUnique(oLigne) ? oLigne : oLigneTD;
								clWDUtil.oSupprimeElement(oLigne);
							}
							else if (sCorps.substr(sCorps.length - 5, 5).toLowerCase() != "</tr>")
							{
								// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
								// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
								// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
								this.__InsereRemplaceTrTdDansTable(oLigne, sCorps, true, oLigne.children[0]);
							}
							else
							{
								this.__RemplaceElementDansTable(oLigne, sCorps);
							}
						}
						else if (sCorps.substr(sCorps.length - 5, 5).toLowerCase() == "</tr>")
						{
							var oLigneConteneur;
							var oLigneRemplace;

							if (clWDUtil.bBaliseEstTag(oLigne, "td"))
							{
								oLigneConteneur = oLigne.parentNode;
								oLigneRemplace = oLigne;
							}
							else
							{
								oLigneConteneur = oLigne;
								oLigneRemplace = oLigne.lastElementChild;
							}
							this.__InsereRemplaceTrTdDansTable(oLigneConteneur, sCorps, false, oLigneRemplace);
						}
						else
						{
							this.__RemplaceElementDansTable(oLigne, sCorps);
						}
					}
					// Recupere le TBODY nouvellement cree si besoin
					if (oConteneurParent == oConteneurTBody)
					{
						oConteneurParent = this.__oGetConteneurParent(sNomChamp, nTypeChamp, true);
						oConteneurTBody = this.__oGetConteneurTBODY(oConteneurParent, nTypeChamp);
					}
				}
			}
			else if (sContenu.length > 0)
			{
				var oPosition;

				// OPTIM : Si on ne trouve pas la ligne et que la ligne est vide, il n'y a aucune action a faire
				// On ne trouve pas la ligne : on doit donc la creer
				// On ajoute un voisin a la derniere ligne
				if (bIE)
				{	// Pour IE

					// insertAdjacentHTML ne marche pas sur les balises <TABLE> et <TBODY>
					// GP 27/08/2013 : TB83684 : Si la table est completement vide, oConteneurTBody == oConteneurParent == balise table
					// Il faut donc filtrer aussi ce cas car alors insertAdjacentHTML ne fonctionne pas non plus
					if (oConteneurTBody && ((oConteneurTBody != oConteneurParent) || clWDUtil.bBaliseEstTag(oConteneurTBody, "table")))
					{
						// Si on n'a pas encore sContenuActuelTable on le recupere
						// Possible car on passe aussi ici pour les ZRs
						if (!sContenuActuelTable)
						{
							sContenuActuelTable = oConteneurParent.outerHTML;
							sContenuActuelTable = this.sSupprimeEspacements(sContenuActuelTable);
							nPosTR = nPosTBody = undefined;
						}

						// Normalement la zone ce fini par </table>
						if (sContenuActuelTable.substr(sContenuActuelTable.length - "</table>".length).toLowerCase() == "</table>")
						{
							// Si on est multicolonne => Utile <td>
							if (bMultiColonnes)
							{
								if (undefined === nPosTR)
								{
									nPosTR = sContenuActuelTable.toLowerCase().lastIndexOf("</tr>");
								}
								// Si on ne trouve pas de TR : il n'y a pas de ligne dans la ZR
								if (nPosTR == -1)
								{
									if (undefined === nPosTBody)
									{
										nPosTBody = sContenuActuelTable.toLowerCase().lastIndexOf("</tbody>");
									}
									// GP 27/08/2013 : TB83684 : Si on n'a pas encore de tbody (table vide) on recherche </table>
									if (-1 == nPosTBody)
									{
										nPosTBody = sContenuActuelTable.toLowerCase().lastIndexOf("</table>");
									}

									// Supprime le </TD> en trop au debut de la ligne
									var bModifie = false;
									if (sDebut.toLowerCase().indexOf("</tr>") === 0)
									{
										bModifie = true;
										sDebut = sDebut.substring("</tr>".length);
									}
									else if (sCorps.toLowerCase().indexOf("</tr>") === 0)
									{
										bModifie = true;
										sCorps = sCorps.substring("</tr>".length);
									}
									if ((sFin.toLowerCase().lastIndexOf("</tr>") !== (sFin.length - "</tr>".length)) && (sCorps.toLowerCase().lastIndexOf("</tr>") !== (sCorps.length - "</tr>".length)))
									{
										bModifie = true;
										sFin += "</tr>";
									}
									// GP 21/05/2013 : QW232108 : Ce n'est pas vrai si on a modifi�e sDebut, sCorps ou sFin
//									// GP 02/04/2013 : Inutile, c'est d�j� la valeur de sContenu
									if (bModifie)
									{
										sContenu = sDebut + sCorps + sFin;
									}
									sContenuActuelTable = sContenuActuelTable.substring(0, nPosTBody) + sContenu + sContenuActuelTable.substring(nPosTBody);
									nPosTR = undefined;
									nPosTBody += sContenu.length;
								}
								else
								{
									sContenuActuelTable = sContenuActuelTable.substring(0, nPosTR) + sContenu + sContenuActuelTable.substring(nPosTR);
									nPosTR += sContenu.length;
									nPosTBody = undefined;
								}
							}
							else
							{
								if (undefined === nPosTBody)
								{
									nPosTBody = sContenuActuelTable.toLowerCase().lastIndexOf("</tbody>");
								}
								// GP 27/08/2013 : TB83684 : Si on n'a pas encore de tbody (table vide) on recherche </table>
								if (-1 === nPosTBody)
								{
									nPosTBody = sContenuActuelTable.toLowerCase().lastIndexOf("</table>");
								}

								// Si on est dans une ZR horizontale, on est dans le parent de la ZR (la zone avec l'asceneur)
								if (nTypeChamp === this.XML_CHAMP_TYPE_ZONEREPETEEHORIZONTALE)
								{
									nPosTBody = sContenuActuelTable.toLowerCase().substr(0, nPosTBody).lastIndexOf("</tr>");
								}
								sContenuActuelTable = sContenuActuelTable.slice(0, nPosTBody) + sContenu + sContenuActuelTable.substring(nPosTBody);
								nPosTR = undefined;
								nPosTBody += sContenu.length;
							}
						}
						else
						{
							sContenuActuelTable += sContenu + oConteneurParent.tagName;
							nPosTR = nPosTBody = undefined;
						}
					}
					else
					{
						// GP 02/11/2013 : TB84520 : On a modifi� directement le HTML, ne plus utiliser sContenuActuelTable
						// ??? Est-il possible d'avoir des lignes qui sont modifi�e par sContenuActuelTable et d'autre ici ???
						// Si oui il faudrait replacer sContenuActuelTable ici.
						sContenuActuelTable = undefined;

						oPosition = oConteneurTBody;
						// GP 01/02/2013 : TB80896 : D�j� fait dans __oGetConteneurTBODY
//						// Si on est dans une ZR horizontale, on est dans le parent de la ZR (la zone avec l'asceneur)
//						if (nTypeChamp == this.XML_CHAMP_TYPE_ZONEREPETEEHORIZONTALE)
//						{
//							// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
//							// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
//							// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
//							oPosition = oConteneurTBody.children[0];
//						}
						oPosition.insertAdjacentHTML("beforeend", sContenu);
						// Met a jour le conteneur parent
						oConteneurParent = this.__oGetConteneurParent(sNomChamp, nTypeChamp, true);
						oConteneurTBody = this.__oGetConteneurTBODY(oConteneurParent, nTypeChamp);
					}
				}
				else
				{	// Pour les autres navigateur
					oPosition = oConteneurTBody;
					// GP 01/02/2013 : TB80896 : D�j� fait dans __oGetConteneurTBODY
//					if (nTypeChamp == this.XML_CHAMP_TYPE_ZONEREPETEEHORIZONTALE)
//					{
//						// Si on est dans une ZR horizontale, on est dans le parent de la ZR (la zone avec l'asceneur)
//						// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
//						// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
//						// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
//						oPosition = oConteneurTBody.children[0];
//					}

					// Si la ligne est un <tr> complet
					if (this.__bHTMLDebutTR(sContenu))
					{
						if (sContenu.substr(sCorps.length - 5, 5).toLowerCase() != "</tr>")
						{
							sContenu = sContenu + "</tr>";
						}
					}
					else if (sCorps.substr(sCorps.length - 5, 5).toLowerCase() == "</tr>")
					{
						if (bMultiColonnes)
						{
							// Si on arrive ici c'est que la ligne est les derniere de sa colonne (teste par le serveur)
							// Ajoute dans le tr et lieu du tbody et supprime le </tr>
							// Possible probleme si on a une rupture en bas ?
							oPosition = oConteneurTBody.lastElementChild;
							sContenu = sContenu.substr(0, sCorps.length - 5);
						}
						else
						{
							sContenu = "<tr>" + sContenu;
						}
					}
					else if (bMultiColonnes && this.__bHTMLDebutTD(sContenu))
					{
						// Si on arrive ici c'est que la ligne est au milieu de sa colonne (teste par le serveur)
						// Ajoute dans le tr et lieu du tbody
						oPosition = oConteneurTBody.lastElementChild;
					}
					this.__AjouteElementDansTable(oPosition, sContenu);
					// Si la table etait completement vide, on n'avais pas encore de TBODY
					if (oConteneurParent === oConteneurTBody)
					{
						oConteneurParent = this.__oGetConteneurParent(sNomChamp, nTypeChamp, true);
						oConteneurTBody = this.__oGetConteneurTBODY(oConteneurParent, nTypeChamp);
					}
				}
			}
		}

		// Met a jour le conteneur parent si besoin
		if (sContenuActuelTable)
		{
			// Si on a une ZR multicolonne avec des lignes repliees, on a de possibles </tr></tr> ou <tr><tr>
			sContenuActuelTable = sContenuActuelTable.replace(/\<\/tr\>\<\/tr\>/ig, "</tr>");
			sContenuActuelTable = sContenuActuelTable.replace(/\<tr\>\<tr\>/ig, "<tr>");
			// Out des <tr></tr>
			sContenuActuelTable = sContenuActuelTable.replace(/\<tr[^\>]*\>\s*\<\/tr\>/ig, "");
			sContenuActuelTable = sContenuActuelTable.replace(/\<tr[^\>]*\>\s*\<tr/ig, "<tr");


			// Dans le cas des ZR extensible en largeur ici on est dans le TD parent
			if (clWDUtil.bBaliseEstTag(oConteneurParent, "td"))
			{
				oConteneurParent.innerHTML = sContenuActuelTable;
			}
			else
			{
				oConteneurParent.outerHTML = sContenuActuelTable;
			}
			oConteneurParent = this.__oGetConteneurParent(sNomChamp, nTypeChamp, true);
			oConteneurTBody = this.__oGetConteneurTBODY(oConteneurParent, nTypeChamp);
		}
		else
		{
			if (clWDUtil.bBaliseEstTag(oConteneurTBody, "tbody"))
			{
				// Supprime d'abord les balises texte qui g�nent le parcours : suppression inverse car tabChildNodes est modifi� en direct avec les suppressions
				clWDUtil.bForEachInverse(oConteneurTBody.childNodes, function(oFils)
				{
					if (0 === oFils.childNodes.length)
					{
						oConteneurTBody.removeChild(oFils);
					}
					return true;
				});
			}
		}

		// Supprime les lignes en trop a la fin pour le cas ou les deux plages d'incides se recoupaient
		nIndiceActuel = nDebut + nNombre;
		var nResteColonnes = nMultiColonnes;
		while (true)
		{
			if (this.__bSupprimeLigne(sNomChamp, nTypeChamp, nIndiceActuel, nNbRuptures, oConteneurParent, oConteneurTBody))
			{
				nIndiceActuel++;
				nResteColonnes = nMultiColonnes;
			}
			else if (nResteColonnes > 1)
			{
				// Si on est en multicolonnes, on peut ne pas avoir d'element sur la derniere ligne et des elements sur la ligne suivante
				nIndiceActuel++;
				nResteColonnes--;
			}
			else
			{
				break;
			}
		}

		// Il y a des problemes si on vide tout dans firefox et co et que l'on vide la table
		if ((!bIE) && (nNombre === 0) && (oConteneurTBody !== oConteneurParent) && (oConteneurTBody.childNodes.length === 0))
		{
			clWDUtil.SupprimeFils(oConteneurParent);
		}

		// Met les valeurs dans les champs cache
		// GP 07/01/2016 : TB93214 : Probl�me avec "_DEB" : Ici on est toujours le contexte d'une table classique ou la valeur �tait correcte.
		oPage[sNomChamp + "_DEB"].value = nDebut;
		var oChampOccurrence = oPage["_" + sNomChamp + "_OCC"];
		// Pour les ZR horizontale tente sans le "_"
		if (oChampOccurrence === undefined)
		{
			oChampOccurrence = oPage[sNomChamp + "_OCC"];
		}

		oChampOccurrence.value = nNombre;
		if (nSelection >= 0)
		{
			oChamp.value = nSelection;
		}

		// Force le redessin selon le type de champs
		switch (nTypeChamp)
		{
		case this.XML_CHAMP_TYPE_TABLE:
		case this.XML_CHAMP_TYPE_TABLEHIERARCHIQUE:
		case this.XML_CHAMP_TYPE_ZONEREPETEE:
		case this.XML_CHAMP_TYPE_ZONEREPETEEHORIZONTALE:
			AppelMethodePtr(WDChamp.prototype.OnTableZRAfficheAJAX, [sNomChamp]);
			break;
		}

		// Notifie aussi de la modification du HTML de la page
		clWDUtil.m_oNotificationsAjoutHTML.LanceNotifications(this, oConteneurParent);
	},

	// Recoit un bout de CSS et l'ajoute dans la page
	// Pour optimiser les choses : si un style est vide on le degage
	ActionLigneStyle: function ActionLigneStyle(sNomChamp, nIndiceLigne, sStyle)
	{
		// Maintenant on re�oit tous les style sous forme d'une balise : sTyle est de la forme
		// <style ... id="rgs-ALIASTABLE-LIGNE">
		//	#ID1, #ID2, ...	{ style1 }
		//	#ID3, ...		{ style2 }
		//	etc
		// </style>
		// Il peut y avoir des {} vide au milieu

		// On garde l'ancien cas pour les pages internes 20 F+1 et - dans une page 20 F+2 et +
		if ("<style " === sStyle.substr(0, "<style ".length))
		{
			// Supprime la balise pr�c�dente
			this.__SupprimeStyleLigne(sNomChamp, nIndiceLigne);
			var oHead = document.getElementsByTagName("head")[0];
			if (!bIE || (10 <= nIE))
			{
				// Ajoute le HTML � la fin de la balise head
				oHead.insertAdjacentHTML("beforeend", sStyle);
			}
			else
			{
				// GP 14/02/2017 : QW281360 : Plante avec IE8- (IE9- ?) quand il y a trop de styles
				try
				{
					// insertAdjacentHTML de style dans le head ne fonctionne pas en IE9-
					var oStyle = clWDUtil.oCreeFeuilleStyle();
					oStyle.owningElement.id = "rgs-" + sNomChamp + "-" + nIndiceLigne;
					oStyle.cssText = sStyle.substring(sStyle.indexOf(">") + 1, sStyle.lastIndexOf("<"));
//					clWDUtil.oCreeFeuilleStyle().owningElement.outerHTML = sStyle;
				}
				catch (e)
				{
				}
			}
		}
		else
		{
			// Donc pour le parsing on decoupe d'abord selon les }
			var tabNouveauxStyles = sStyle.split("}");
			// tabNouveauxStyles contient un tableau de lignes de la forme
			// #ID1, #ID2, ...	{ style1			<= split a fait partir le } final

			// On va maintenant traiter les lignes individuelles
			var i;
			var nLimiteI = tabNouveauxStyles.length;
			for (i = 0; i < nLimiteI; i++)
			{
				this._ActionLigneStyleLigne(tabNouveauxStyles[i]);
			}
		}
	},

	// Recoit une ligne de CSS et l'ajoute dans la page
	// Pour optimiser les choses : si un style est vide on le degage
	_ActionLigneStyleLigne: function(sLigneStyle)
	{
		var nDebutTexteStyle = sLigneStyle.indexOf("{");
		//assert(nDebutTexteStyle <= 0);
		// Par securite si pas de style (-1) ou pas de nom de style (0) on boucle
		if (nDebutTexteStyle <= 0)
		{
			return;
		}

		// On decoupe le nom des styles et le contenu du style
		var sNomsStyle = sLigneStyle.substring(0, nDebutTexteStyle);
		var sTexteStyle = sLigneStyle.substring(nDebutTexteStyle + 1);

		// On vire les espaces/tabulations/RC du debut et de la fin du style comme ca si on decouvre que le style est vide on va
		// optimiser en n'en creant pas un autres
		sTexteStyle = this.__sTrim(sTexteStyle, true, true);

		// La feuille de style par defaut pour l'ajout
		var oStyleSheetDefaut = clWDUtil.oGetFeuilleStyle(document.getElementsByTagName("style")[0]);

		// Puis on decoupe les noms de styles selon le separateur ","
		var tabNomsStyle = sNomsStyle.split(",");

		// Et on les traites
		var i;
		var nLimiteI = tabNomsStyle.length;
		for (i = 0; i < nLimiteI; i++)
		{
			var sNomStyle = this.__sTrim(tabNomsStyle[i]);
			sNomStyle = sNomStyle.replace(ms_oRegExpRC, "");
			// Si le nom du style est vide ou sans nom : on ignore ce nom de style
			if ((sNomStyle.length === 0) || (sNomStyle === "#"))
			{
				//assert(false);
				continue;
			}

			// Puis on modifie le style
			// Supprime l'ancien style
			// Les autres navigateurs sont sensibles a la casse et placent les styles en minuscules
			var oStyleSheet = this._oActionSupprimeStyle(bIE ? sNomStyle : sNomStyle.toLowerCase());
			// Et recree le nouveau si le texte du style est non vide
			if (sTexteStyle.length > 0)
			{	// On recre si possible le style dans la feuille de style ou on l'a supprimer
				clWDUtil.CreeStyle(oStyleSheet ? oStyleSheet : oStyleSheetDefaut, sNomStyle, sTexteStyle);
			}
		}
	},

	// Supprime l'ancien style portant le nom et le recree si besoin
	_oActionSupprimeStyle: function(sNomStyle)
	{
		// Recherche et supprime le style existant si besoin
		var tabStyles = document.getElementsByTagName("style");
		var i;
		var nLimiteI = tabStyles.length;
		for (i = 0; i < nLimiteI; i++)
		{
			var oFeuilleStyle = clWDUtil.oGetFeuilleStyle(tabStyles[i]);
			var tabRules = clWDUtil.tabGetStyleReglesAvecImportConst(oFeuilleStyle);

			// On parcours les sous styles
			var j;
			var nLimiteJ = tabRules.length;
			for (j = 0; j < nLimiteJ; j++)
			{
				var sSelecteur = tabRules[j].selectorText;
				if (!clWDUtil.m_bStyleNorme)
				{
					// Pour internet explorer
					if (sSelecteur === sNomStyle)
					{
						clWDUtil.StyleSupprime(oFeuilleStyle, j);
						return;
					}
				}
				else
				{
					// Pour FireFox et autres

					// On recupere la liste des styles pour voir si notre style y est
					// Comme les styles sont groupes par le moteur selon des styles qui doivent reste identique il sufit de trouver notre style une fois
					// Ici les styles sont groupe donc il faut faire un parsing
					// selectorText n'existe pas dans les CSSMediaRule
					if (sSelecteur)
					{
						var tabStylesNom = sSelecteur.split(",");
						var k;
						var nLimiteK = tabStylesNom.length;
						for (k = 0; k < nLimiteK; k++)
						{
							// Enleve les espaces abusif
							tabStylesNom[k] = clWDUtil.sSupprimeEspaces(tabStylesNom[k]);
							if (tabStylesNom[k].toLowerCase() === sNomStyle)
							{
								tabStylesNom.splice(k, 1);
								var sCSSTexte = tabRules[j].style.cssText;
								// Supprime la regle
								clWDUtil.StyleSupprime(oFeuilleStyle, j);
								// Et ajoute la regle modifie si besoin
								if (0 < tabStylesNom.length)
								{
									clWDUtil.CreeStyle(oFeuilleStyle, tabStylesNom.join(","), sCSSTexte);
								}
								return;
							}
						}
					}
				}
			}
		}
	},

	// Contenu d'un TV
	ActionChampTreeview: function(oChamp, XMLAction, sAliasChamp)
	{
		// Recupere les sous parties

		// Selection en cours
		//assert(XMLAction.childNodes[0].nodeName == this.XML_CHAMP_TREEVIEW_SELECT);
		document.getElementsByName(sAliasChamp + "_AS")[0].value = this.sXMLGetValeur(XMLAction.childNodes[0]);

		// Noeuds deroules
		//assert(XMLAction.childNodes[1].nodeName == this.XML_CHAMP_TREEVIEW_DEROULE);
		document.getElementsByName(sAliasChamp)[0].value = this.sXMLGetValeur(XMLAction.childNodes[1]);
		//assert(XMLAction.childNodes[2].nodeName == this.XML_CHAMP_TREEVIEW_DEROULETAB);
		var sNex = this.sXMLGetValeur(XMLAction.childNodes[2]);
		document.getElementsByName("NEX_" + sAliasChamp)[0].value = sNex;
		// Il faut aussi mettre a jour la variable globale avec les elements deroules
		window["oItems_" + sAliasChamp] = sNex.split(",");

		// Contenu des noeuds
		//assert(XMLAction.childNodes[3].nodeName == this.XML_CHAMP_TREEVIEW_NOEUDS);
		var oContenu = document.getElementById(sAliasChamp + "_");
		// GP 28/08/2017 : Suppression des NSUtil.sEncodeInnerHTML(Chaine, false, true) qui ne font rien (sauf la conversion en chaine qui est inutile)
		oContenu.innerHTML = this.sXMLGetValeur(XMLAction.childNodes[3]);
	},

	// Rechargement d'une image dynamique
	ActionChampRecharge: function(oChamp, nTypeChamp, XMLAction, sAliasChamp)
	{
		// Uniquement avec un champ
		if (oChamp)
		{
			// GP 17/10/2014 : En HTML5, le champ n'a pas de name et on a d�j� l'alias du champ
//			var sAlias = oChamp.name || oChamp.id || sAliasChamp;

			// Si on recoit un parametre de commande : l'ecrit dans la classe
			if (this.bXMLAttributExiste(XMLAction, this.XML_CHAMP_RECHARGE_PARAM))
			{
				var pMethode;
				// GP 09/07/2014 : N'existe normalement que pour le graphe : c'est les anciens param�tres du graphe (pour la barre d'outils)
				switch (nTypeChamp)
				{
				case this.XML_CHAMP_TYPE_GRAPHE:
					pMethode = WDGraphe.prototype.DeduitParamBarre;
					break;
				default:
					// Ancien code : normalement on ne passe jamais ici, on ne trouve cet attribut que dans le cas du champ graphe
					pMethode = WDChamp.prototype.DeduitParam;
					break;
				}
				clWDUtil.oAppelFonctionChampPtr(sAliasChamp, pMethode, [this.sXMLGetAttribut(XMLAction, this.XML_CHAMP_RECHARGE_PARAM)]);
			}

			// Recherche le parametre anticache du champ image
			var rNoCache = new RegExp("(" + sAliasChamp + "\\=)(\\d+)", "i");
			var sUrlImage = oChamp.src;
			if (rNoCache.test(sUrlImage))
			{
				oChamp.src = sUrlImage.replace(rNoCache, function(sExp, s1, s2) { return s1 + (parseInt(s2, 10) + 1); });
			}
			else
			{
				// Recherche un parametre sans option
				var rNoCacheVide = new RegExp("(" + sAliasChamp + "\\=)([^\\d]|$)", "i");
				if (rNoCacheVide.test(sUrlImage))
				{
					oChamp.src = sUrlImage.replace(rNoCacheVide, function(sExp, s1, s2) { return s1 + (new Date()).getTime() + s2; });
				}
			}

			// Si on est dans un champ vignette, il faut aussi patcher le lien
			var oParent = oChamp.parentNode;
			if (clWDUtil.bBaliseEstTag(oParent, "a"))
			{
				__PatchOnClick(oParent, sAliasChamp, rNoCache, function(sExp, s1, s2) { return s1 + (parseInt(s2, 10) + 1); });
			}
		}
	},

	// Rechargement d'une table AJAX
	ActionChampRefresh: function(sAliasChamp, XMLAction, oObjetRequeteTable)
	{
		var nReset = this.nXMLGetAttributSafe(XMLAction, this.XML_CHAMP_REFRESH_RESETTABLE, 0);
		var sNouveauDebut = this.sXMLGetAttributSafe(XMLAction, this.XML_CHAMP_REFRESH_DEBUT, "");
		var nNouveauDebut = -1;
		var sCleNouveauDebut;
		if ((sNouveauDebut !== "") && (!isNaN(parseInt(sNouveauDebut, 10))))
		{
			nNouveauDebut = parseInt(sNouveauDebut, 10);
			if (sNouveauDebut.indexOf(";") > -1)
			{
				sCleNouveauDebut = sNouveauDebut.substring(sNouveauDebut.indexOf(";") + 1);
			}
		}
		// GP 18/03/2013 : QW231024 : Transmet le nouveau nombre de lignes
		var nNbLignes = this.nXMLGetAttributSafe(XMLAction, this.XML_CHAMP_REFRESH_NOMBRE, undefined);

		// Correspond au contenu ALIAS_DATA du champ
		var sData = this.sXMLGetAttributSafe(XMLAction, this.XML_CHAMP_REFRESH_DATA, undefined);

		// GP 09/04/2019 : TB112974 : Il faut transmettre la colonne de tri si elle a chang�e (sinon on perd la modification sur le serveur puisque le navigateur va redemander cette colonne).
		var nTri = this.nXMLGetAttributSafe(XMLAction, this.XML_CHAMP_REFRESH_TRI, -1);
		var bSens = this.bXMLGetAttributSafe(XMLAction, this.XML_CHAMP_REFRESH_SENS, false);

		// GP 09/01/2013 : TB80368/TB80411 : Uniquement si cela concerne la table courante
		// => Si c'est pour une autre table on ne fait rien
		// Puis demande au cache de nous supprimer en sauvant notre pointeur sur la table car celui-ci va etre mis a null
		if (oObjetRequeteTable && (oObjetRequeteTable.m_oChampTable.m_sAliasChamp === sAliasChamp))
		{
			oObjetRequeteTable.SupprimeRequete(false);
		}

		clWDUtil.oAppelFonctionChampPtr(sAliasChamp, WDChamp.prototype.Refresh, [nReset, nNouveauDebut, sCleNouveauDebut, sData, nNbLignes, XMLAction.firstChild, nTri, bSens]);
	},

	// Saisie assist�e d'un champ de saisie
	ActionChampSaisieAssistee: function(sAliasChamp, XMLAction)
	{
		if (window["$"])
		{
			var oJSQuerySelonAlias = $("." + sAliasChamp);
			var oJSQuery = oJSQuerySelonAlias.add(oJSQuerySelonAlias.find("input")).last();
			if (this.bXMLAttributExiste(XMLAction, this.XML_CHAMP_SAISIEA_FILTRE))
			{
				oJSQuery.data("saisieassistee-filtre", this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_SAISIEA_FILTRE));
			}
			if (this.bXMLAttributExiste(XMLAction, this.XML_CHAMP_SAISIEA_OUVERTUREAUTO))
			{
				oJSQuery.data("saisieassistee-ouvertureauto", this.bXMLGetAttributSafe(XMLAction, this.XML_CHAMP_SAISIEA_OUVERTUREAUTO));
			}
			if (this.bXMLAttributExiste(XMLAction, this.XML_CHAMP_SAISIEA_TAILLEMIN))
			{
				oJSQuery.data("saisieassistee-taillemin", this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_SAISIEA_TAILLEMIN));
			}
			if (this.bXMLAttributExiste(XMLAction, this.XML_CHAMP_SAISIEA_DELAI))
			{
				oJSQuery.data("saisieassistee-delai", this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_SAISIEA_DELAI));
			}
			if (this.bXMLAttributExiste(XMLAction, this.XML_CHAMP_SAISIEA_SANSCASSE))
			{
				oJSQuery.data("saisieassistee-sanscasse", this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_SAISIEA_SANSCASSE));
			}
			// On parcourt les options du champ
			var XMLOption = XMLAction.firstChild;
			if (XMLOption)
			{
				oJSQuery.autocomplete("wbRazAutocompleteProg");
				// GP 20/01/2014 : Construit un tableau et fait l'appel en une fois (�vite les calculs de jQuery pour trouver la fonctionnalit�)
				var tabOptions = [];
				while (XMLOption)
				{
					// Selon l'option transmise
					switch (XMLOption.nodeName)
					{
					case this.XML_CHAMP_SAISIEA_OPTION:
						// Option simple : On ajoute l'option
						// GP 20/01/2014 : Construit un tableau et fait l'appel en une fois (�vite les calculs de jQuery pour trouver la fonctionnalit�)
//						oJSQuery.autocomplete("wbAddAutocompleteProg", this.sXMLGetValeur(XMLOption));
						tabOptions.push(this.sXMLGetValeur(XMLOption));
						break;
					case this.XML_CHAMP_SAISIEA_SANSOPTION:
						// GP 03/03/2014 : TB86272 : Place juste une balise pour avoir du contenu et vider la completion
						break;
					}
					// Option suivante
					XMLOption = XMLOption.nextSibling;
				}
				oJSQuery.autocomplete("wbConcatAutocompleteProg", tabOptions);
			}
		}
	},

	// Donn�es de saisie � jeton
	ActionChampSaisieAJeton: function(sAliasChamp, XMLAction)
	{
		var oChamp = document.getElementsByName(sAliasChamp)[0];
		var oChampData = document.getElementsByName(sAliasChamp + "_DATA")[0];
		if (oChamp && oChampData)
		{
			oChampData.value = this.sXMLGetValeur(XMLAction);
			oChamp.wbJetonChargeDepuisChampCache();
		}
	},

	// execute les actions sur les champs
	ActionChamp: function(oPage, XMLChamp, oObjetRequeteTable)
	{
		// on recupere l'alias du champ
		var sAliasChamp = this.sXMLGetAttribut(XMLChamp, this.XML_CHAMP_ATT_ALIAS);
		// on recupere le type du champ
		var nTypeChamp = this.nXMLGetAttribut(XMLChamp, this.XML_CHAMP_ATT_TYPE);
		// on cherche le champ
		var oChamp = this.__oChercheChamp(oPage, sAliasChamp, nTypeChamp);
		var oChampExt = this.__oChercheChamp(oPage, sAliasChamp, nTypeChamp, true, false);
		var XMLAction = XMLChamp.firstChild;
		while (XMLAction)
		{	// selon le type d'action
			switch (XMLAction.nodeName)
			{	// propriete
				case this.XML_CHAMP_PROP:
					{	// selon la propriete
						switch (this.nXMLGetAttribut(XMLAction, this.XML_CHAMP_PROP_ATT_NUM))
						{
							// Valeur affiche => Valeur
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEURAFFICHEE:
							// Valeur, Valeur inf�rieure (normalement d�j� transform�e sur le serveur
//							case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEURINFERIEURE:
								// falls through
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR: this.ActionProprieteValeur(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Libelle
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLE: this.ActionProprieteLibelle(oChamp, nTypeChamp, XMLAction, sAliasChamp, false); break;
							// Note
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_NOTE: this.ActionProprieteNote(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// LibelleHTML
							// GP 23/02/2017 : TB102138 : Il faut tenir compte que la valeur pour ..Libell�HTML est en HTML
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLEHTML: this.ActionProprieteLibelle(oChamp, nTypeChamp, XMLAction, sAliasChamp, true); break;
							// Hauteur
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_HAUTEUR: this.ActionProprieteHauteur(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Largeur
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_LARGEUR: this.ActionProprieteLargeur(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Couleur
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEUR: this.ActionProprieteCouleur(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Couleur de fond. Comme on peu manipuler la couleur de fond de la page
							// le test d'existantce de oChamp est deporte dans ActionProprieteCouleurFond
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURFOND: this.ActionProprieteCouleurFond(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Etat d'un champ
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_ETAT: this.ActionProprieteEtat(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Visibilite : manipule la partie externe du champ
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_VISIBLE: this.ActionProprieteVisible(oChamp, oPage, nTypeChamp, XMLAction, sAliasChamp); break;
							// TitreNote
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_TITRENOTE: this.ActionProprieteTitreNote(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// ..Groupe
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_GROUPE: this.ActionProprieteGroupe(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// Image
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_IMAGE: this.ActionProprieteImage(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// URL. pas de test de l'existence du champ car on va recherche la balise autour du champ
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_URL: this.ActionProprieteURL(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// Bulle
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_BULLE: this.ActionProprieteBulle(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// X
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_X:
								// Prend le 'vrai' champ exterieur
								oChampExt = this.__oChercheChamp(oPage, sAliasChamp, nTypeChamp, true, true);
								this.ActionProprieteX(oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Y
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_Y:
								// Prend le 'vrai' champ exterieur
								oChampExt = this.__oChercheChamp(oPage, sAliasChamp, nTypeChamp, true, true);
								this.ActionProprieteY(oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// CurseurSouris
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_CURSEURSOURIS: this.ActionProprieteCurseurSouris(oChampExt, nTypeChamp, XMLAction); break;
							// PoliceGras
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEGRAS: this.ActionProprietePoliceGras(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// PoliceItalique
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEITALIQUE: this.ActionProprietePoliceItalique(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// PoliceNom
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICENOM: this.ActionProprietePoliceNom(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// PoliceSoulignee
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICESOULIGNE: this.ActionProprietePoliceSoulignee(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// PoliceTaille
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICETAILLE: this.ActionProprietePoliceTaille(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Opacite
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_OPACITE: this.ActionProprieteOpacite(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Cadrage horizontal
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_CADRAGEH: this.ActionProprieteCadrageH(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Cadrage vertical
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_CADRAGEV: this.ActionProprieteCadrageV(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Selectionnee
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_SELECTIONNEE: this.ActionProprieteSelectionnee(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// Indication
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_INDICATION: this.ActionProprieteIndication(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// Bouton calendrier
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_BOUTONCALENDRIER: this.ActionProprieteBoutonCalendrier(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// Pseudo contenu
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_CONTENU: this.ActionProprieteContenu(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// ValeurSuperieure (ValeurInf�rieure est �quivalent a Valeur)
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEURSUPERIEURE: this.ActionProprieteValeurSuperieure(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// ClasseHTML
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_CLASSEHTML: this.ActionProprieteClasseHTML(oChamp, oChampExt, nTypeChamp, XMLAction, sAliasChamp); break;
							// TexteAlternatif
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_TEXTEALTERNATIF: this.ActionProprieteTexteAlternatif(oChamp, nTypeChamp, XMLAction); break;
							// Plan
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_PLAN: this.ActionProprietePlan(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// ImageFond
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_IMAGEFOND: this.ActionProprieteImageFond(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// CouleurJauge
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURJAUGE: this.ActionProprieteCouleurJauge(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
							// BulleTitre
							case WDChamp.prototype.XML_CHAMP_PROP_NUM_BULLETITRE: this.ActionProprieteBulleTitre(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;

							// @@@@ Ici nouvelle propri�t� WebDev (Si besoin)
						}
						break;
					}
					// Code JS a executer sur l'objet
				case this.XML_CHAMP_JS: this.ActionChampJS(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
				// Lignes d'une table/ZR
				case this.XML_CHAMP_LIGNES:
					this.ActionChampLignes(oChamp, nTypeChamp, XMLAction, sAliasChamp, oPage);
					// Avec IE, on manipule la propriete outerHTML donc l'objet DOM change et oChamp et oChampExt deviennent invalides
					oChamp = this.__oChercheChamp(oPage, sAliasChamp, nTypeChamp);
					oChampExt = this.__oChercheChamp(oPage, sAliasChamp, nTypeChamp, true);
					break;
				// Options a ajouter a l'objet
				case this.XML_CHAMP_OPTIONS: this.ActionChampOptions(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
				// Rechargement d'une image dynamique
				case this.XML_CHAMP_RECHARGE: this.ActionChampRecharge(oChamp, nTypeChamp, XMLAction, sAliasChamp); break;
				// Rafraichisement d'une table AJAX
				case this.XML_CHAMP_REFRESH: this.ActionChampRefresh(sAliasChamp, XMLAction, oObjetRequeteTable); break;
				// Saisie assist�e d'un champ de saisie
				case this.XML_CHAMP_SAISIEA: this.ActionChampSaisieAssistee(sAliasChamp, XMLAction); break;
				// Donn�es de saisie � jeton
				case this.XML_CHAMP_SAISIEAJETON: this.ActionChampSaisieAJeton(sAliasChamp, XMLAction); break;
				// Contenu d'un TV
				case this.XML_CHAMP_TREEVIEW: this.ActionChampTreeview(oChamp, XMLAction, sAliasChamp); break;
			}
			// on passe a l'action suivante
			XMLAction = XMLAction.nextSibling;
		}
	},

	// execute les actions JS simple
	ActionJS: function(oPage, XMLAction)
	{	// On recupere le code JS a executer
		var sCodeJS = unescape(this.sXMLGetValeur(XMLAction));
		// Execute le code JS
		// Si on est en encodage latin-1 (Donc pas en UTF-8) : On encode les caracteres > 127
		// Pas besoin de le faire en UTF-8 car il on deja ete encode pour avoir au final la bonne valeur unicode
		eval(sCodeJS);
	},

	// Execute une redirection
	bActionRedirection: function(oPage, XMLAction)
	{
		// On recupere la redirection
		// GP 21/05/2019 : QW312541 : unescape n'est pas bon (pas de gestion de l'UTF-8). C'est soit rien, soit decodeURI, soit decodeURIComponent.
		// decodeURI semble le bon code (on peut avoir une URL compl�te
//		var sRedirection = unescape(this.sXMLGetValeur(XMLAction));
		var sRedirection = decodeURI(this.sXMLGetValeur(XMLAction));
		// GP 09/11/2018 : QW304127 : Vu avec FR : Il n'y a pas de cas ou l'on ne veux pas d'entr�e dans l'historique.
//		// GP 09/11/2018 : QW304127 : Maintenant, on peut demander � avoir une redirection qui fait une entr�e dans l'historique.
//		var bAvecEntreeDansLHistorique = this.bXMLGetAttributSafe(XMLAction, this.XML_REDIR_HISTORIQUE);
//
//		// Execute la redirection
//		if (bAvecEntreeDansLHistorique)
//		{
			document.location.assign(sRedirection);
//		}
//		else
//		{
//			document.location.replace(sRedirection);
//		}
		// Le document ne change pas pour certains protocoles
		return "tel:" !== sRedirection.substring(0, 4) && "email:" !== sRedirection.substring(0, 4);
	},

	// Affiche une trace
	ActionTrace: function(oPage, XMLAction, bAjout)
	{
		// Recherche la zone de trace dans la page
		var oDivTrace = _JGE(this.XML_TRACE_ID, document);

		// Recupere la valeur de la trace
		var sTrace = this.sXMLGetValeur(XMLAction);

		// Si besoin calcule la trace precedente pour faire une concatenation
		var tabTraces = [];
		function AjouteTracesPrecedentes (oElement)
		{
			// Ajoute le texte a la trace precedente si besoin
			if (oElement)
			{
				tabTraces.push(clWDUtil.sGetInnerText(oElement));
			}
		};

		// Supprime les traces du premier affichage
		var oOldTrace;
		while ((oOldTrace = _JGE(this.XML_WBTRACE_ID, document)))
		{
			// Ajoute le texte a la trace precedente si besoin
			if (bAjout)
			{
				AjouteTracesPrecedentes(oOldTrace);
			}
			// Supprime la zone de trace
			clWDUtil.oSupprimeElement(oOldTrace);
		}

		// Si besoin ajoute aussi le contenu courante de la trace
		if (bAjout)
		{
			AjouteTracesPrecedentes(oDivTrace);
			if (0 < sTrace.length)
			{
				tabTraces.push(sTrace);
			}
			sTrace = tabTraces.join("\r\n");
		}

		// Si la trace est vide : on supprime la zone de trace si besoin
		if (0 === sTrace.length)
		{
			// Si la zone existe => La supprime
			clWDUtil.oSupprimeElement(oDivTrace);
			// Fin du traitement
			return;
		}

		// Si la zone n'existe pas : la cree
		if (!oDivTrace)
		{
			// Cree dynamiquement un formulaire dans la cellule
			oDivTrace = document.createElement("div");
			oDivTrace.id = this.XML_TRACE_ID;
			oDivTrace.style.width = "1024px";
			// GP 17/11/2017 : La nouvelle couleur de trace doit aussi �tre utilis� pour les traces PHP en AJAX.
			oDivTrace.style.backgroundColor = "#ffd264";
			oDivTrace.style.color = "#000000";
			oDivTrace.style.fontFamily = "Courier New,Courier,mono";
			oDivTrace.style.fontSize = "small";
			oDivTrace.style.textAlign = "left";

			// Ajoute la zone a la page
			// GP 30/09/2020 : QW329642 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte (les tabulations)
			// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
			// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
			var oPremier = document.body.children[0];
			if (oPremier)
			{
				oDivTrace = document.body.insertBefore(oDivTrace, oPremier);
			}
			else
			{
				oDivTrace = document.body.insertBefore(oDivTrace);
			}
		}
		// Affecte le texte dans la zone en effectuant la conversion
		oDivTrace.innerHTML = clWDUtil.sEncodeInnerHTML(sTrace, true);
	},

	// MAJ des liens sociaux si demande
	ActionMAJLienSociaux: function ActionMAJLienSociaux(nMAJLienSociaux)
	{
		this.__ActionMAJLienSocial(nMAJLienSociaux, this.XML_LIENSOCIAL_FACEBOOK, ["FB", "XFBML"], "parse");
		this.__ActionMAJLienSocial(nMAJLienSociaux, this.XML_LIENSOCIAL_TWEETER, ["twttr", "widgets"], "load");
		// GP 15/04/2019 : Plus de Google+.
//		this.__ActionMAJLienSocial(nMAJLienSociaux, this.XML_LIENSOCIAL_GOOGLEPLUS, ["gapi", "plusone"], "go");
		this.__ActionMAJLienSocial(nMAJLienSociaux, this.XML_LIENSOCIAL_LINKEDIN, ["IN"], "init");
	},
	__ActionMAJLienSocial: function __ActionMAJLienSocial(nMAJLienSociaux, nLienSocial, tabMembres, sFonction)
	{
		if (nLienSocial === (nMAJLienSociaux & nLienSocial))
		{
			var oObjet = window;
			var nMembre;
			var nLimiteMembre = tabMembres.length;
			for (nMembre = 0; nMembre < nLimiteMembre; nMembre++)
			{
				oObjet = oObjet[tabMembres[nMembre]];
				if (!oObjet)
				{
					return;
				}
			}
			if (oObjet[sFonction])
			{
				oObjet[sFonction]();
			}
		}
	},

	// MAJ d'une variable synchronis�
	__ActionVarSync : function __ActionVarSync(oXMLAction)
	{
		// GP 08/09/2017 : NSPCS existe forc�ment car le serveur ne retourne que les variables d�clar�es et la d�claration dans le HTML est un appel d'une m�thode du framework V2.
//		if (window.NSPCS)
//		{
			var sParentNom = this.sXMLGetAttributSafe(oXMLAction, "parentnom", "");
			var nParenType = this.nXMLGetAttributSafe(oXMLAction, "parenttype", 0);
			var sNom = this.sXMLGetAttributSafe(oXMLAction, "nom", "");
			var sValeurJSON = this.sXMLGetValeur(oXMLAction);
			if (sNom && sValeurJSON)
			{
				var iVariable = NSPCS.NSValues.xiGetVariable(sNom, sParentNom, nParenType);
				if (iVariable)
				{
					NSPCS.NSOperations.Deserialise(iVariable, sValeurJSON, 0x400 /*NSOperations.EPsd.FormatJSON*/);
				}
			}
//		}
	},

	// MAJ des informations sur les IDs des champs galeries
	__ActionGaleriesIDs: function __ActionGaleriesIDs(oXMLAction)
	{
		var sValeurJSON = this.sXMLGetValeur(oXMLAction);
		if (sValeurJSON)
		{
			clWDUtil.oGetImageInformations(clWDUtil.oEvalJSON(sValeurJSON, {}));
		}
	},

	// Execute les actions : version interne pour donner une fonction a clWDUtil.bDetecteMutation
	__eActionXML: function __eActionXML(oPage, oObjetRequeteTable, oXMLRacine, tabResultat)
	{
		var eResultatTraitementReponseAJAX = 1; // 1 = R�ussite

		// Lance le parcours des actions a effectuer
		var oXMLAction = oXMLRacine.firstChild;
		// Si on est dans la MAJ d'une table => ajout a la trace precedente
		var bMAJTable = false;
		var oXMLTrace;
		var nMAJLienSociaux;
		while (oXMLAction)
		{
			// Selon le type d'action
			switch (oXMLAction.nodeName)
			{
			// Champ
			case this.XML_CHAMP: this.ActionChamp(oPage, oXMLAction, oObjetRequeteTable); break;
			// Code js pur
			case this.XML_JS: this.ActionJS(oPage, oXMLAction); break;
			// Redirection
			case this.XML_REDIR:
				// Le document ne change pas pour certains protocoles
				// 0 = Echec		// => En fait on veux continuer le traitement si on a un champ table associ�e.
				// 2 = Annulation	// => On a rencontr� une redirection, le traitement AJAX est annul�
				eResultatTraitementReponseAJAX = this.bActionRedirection(oPage, oXMLAction) ? 2 : 0;
				break;
			// Gestion du cache des tables
			case this.XML_LISTE:
				oObjetRequeteTable.ActionListe(oXMLAction);
				bMAJTable = true;
				break;
			case this.XML_RESULTAT:
				tabResultat.push(this.sXMLGetValeur(oXMLAction));
				break;
			case this.XML_TRACE:
				// Affichage de traces
				oXMLTrace = oXMLAction;
				break;
			case this.XML_LIENSOCIAL:
				// MAJ des liens sociaux
				nMAJLienSociaux = this.nXMLGetValeur(oXMLAction);
				break;
			case this.XML_VARSYNC:
				// MAJ d'une variable synchronis�
				this.__ActionVarSync(oXMLAction);
				break;
			case this.XML_GALERIESIDS:
				// MAJ des informations sur les IDs des champs galeries
				this.__ActionGaleriesIDs(oXMLAction);
				break;
			}
			// Passe au fils suivant
			oXMLAction = oXMLAction.nextSibling;
		}

		// Si on a une trace l'affiche
		if (oXMLTrace)
		{
			this.ActionTrace(oPage, oXMLTrace, bMAJTable);
		}
		// MAJ des liens sociaux si demande
		// 0 si aucune MAJ des liens sociaux
		if (nMAJLienSociaux)
		{
			this.ActionMAJLienSociaux(nMAJLienSociaux);
		}

		return eResultatTraitementReponseAJAX;
	},

	// Execute les actions
	// oObjetRequeteTable : Selon la requete => objet formulaire, objet table (Ou objet cache de la table)
	eActionXML: function(oPage, oObjetRequeteTable, oXML, tabResultat)
	{
		// on recupere la racine
		var oXMLListeRacine = oXML.getElementsByTagName(this.XML_RACINE);
		if (oXMLListeRacine)
		{
			var eResultatTraitementReponseAJAX = 1;	// 1 = R�ussite

			var oXMLRacine = oXMLListeRacine ? oXMLListeRacine[0] : null;
			if (oXMLRacine)
			{
				var oThis = this;
				if (clWDUtil.bDetecteMutation(document.body, function ()
				{
					eResultatTraitementReponseAJAX = oThis.__eActionXML.apply(oThis, [oPage, oObjetRequeteTable, oXMLRacine, tabResultat]);
				}, (function()
				{
					var tabTables = [];
					// Si on est fils d'une table/ZR, on est filtr�
					WDChamp.prototype.ms_tabTablesZRs.bPourTousChamps(function(sAliasChamp/*, oChamp*/)
					{
						// GP 07/01/2016 : TB93214 : Probl�me avec "_DEB" : Ici on ne manipule pas la valeur.
						var oDebut = oPage[/*oChamp.m_sAliasChamp*/sAliasChamp + "_DEB"];
						if (oDebut && oDebut.parentNode)
						{
							tabTables.push(oDebut.parentNode);
						}
						return true;
					});

					// Observe les modifications du DOM pendant tout le traitement avec IE11- (pour les ancrages HTML5)
					var oBody = document.body;
					return function(oMutation)
					{
						var oTarget = oMutation.target;
						// Ignore les input hidden
						if (clWDUtil.bBaliseEstTag(oTarget, "input") && ("hidden" === oTarget.type))
						{
							return false;
						}
						// Ignore les elements qui ne sont pas dans le document : comme on re�oit les modifications group�es, les �l�ments modifi�s puis supprim�s sont re�ut pour la modification.
						for (var oTargetRemonte = oTarget; oTargetRemonte !== oBody; oTargetRemonte = oTargetRemonte.parentNode)
						{
							if (!oTargetRemonte)
							{
								return false;
							}
						}
						// Si on est fils d'une table/ZR, on est filtr�
						return clWDUtil.bForEach(tabTables, function(oTable)
						{
							return !clWDUtil.bEstFils(oTarget, oTable);
						});
					};
				})(), bIE && (nIE <= 11), true))
				{
					// GP 17/06/2016 : TB98644 : Si le contenu est juste une MAJ du contenu de la table, ne lance pas la notification, ce qui ne d�clenchera pas le code des ancrages pour IE.
					var tabChilNodes = oXMLRacine.childNodes;
					if (tabChilNodes)
					{
						var nNbFils = tabChilNodes.length;
						if ((2 <= nNbFils) || ((1 === nNbFils) && (tabChilNodes[0].nodeName !== this.XML_LISTE)))
						{
							clWDUtil.m_oNotificationsFinAJAX.LanceNotifications();
						}
					}
				}

				return eResultatTraitementReponseAJAX;
			}
		}
		return 0;	// 0 = Echec
	},

	ErreurAJAX: function()
	{
		// Ici requete au serveur qui indique que le navigateur ne supporte pas les appels AJAX

		// L'action sans les parametres
		var sAction = clWDUtil.sGetPageAction(null, true);
		// Ajout de la commande d'erreur
		sAction += "?" + this.sCommandeAjax_Erreur;
		// Et remplacement de la page courante
		document.location = sAction;
	},

	// Execute le code serveur d'un champ
	AJAXExecuteEvenement: function AJAXExecuteEvenement(oPage, sChamp, nEvenement, nOption, nTraitementApresAjax)
	{
		if (ms_bBloque)
		{
			// Si on a ete bloque par un l'appel de _JAZR qui precede immediatement
			ms_bBloque = false;
			return;
		}

		// Si plus d'AJAX on sort
		if (!this.bWDAJAXMainValide())
		{
			return;
		}

		// Si l'AJAX n'est pas disponible
		if (!this.AJAXDisponible())
		{
			// On utilise la methode normale
			this.NormalExecuteEvenement(oPage, sChamp, nEvenement, nOption, nTraitementApresAjax);
			return;
		}

		// Empile la requete
		// Assert(this.m_tabRequetes.length == 0);
		var stRequete = {};
		stRequete.oPage = oPage;
		stRequete.sChamp = sChamp;
		stRequete.nEvenement = nEvenement;
		stRequete.nOption = nOption;
		stRequete.m_nTraitementApresAjax = nTraitementApresAjax;
		this.m_tabRequetes.push(stRequete);

		// Force le reaffichage de l'activite AJAX
		this.s_ReactualiseActivite(true);

		if (window["WDAnimSurPopup"])
		{
			WDAnimSurPopup.prototype.s_Pause();
		}

		// Et demande le traitement de l'evenement
		// Permet de ne pas bloquer l'affichage (Fermeture des combos)
		this.__SetTimeoutTraiteAJAXExecuteEvenement();
	},

	// Appel de TraiteAJAXExecuteEvenement
	__SetTimeoutTraiteAJAXExecuteEvenement: function ()
	{
		// GP 06/11/2012 : Mode sp�cial pour PBO : Fait l'appel directement sans timeout
		if (this.m_bForceAppelSynchrone)
		{
			this.TraiteAJAXExecuteEvenement();
			// Et c'est uniquement pour un appel
			delete this.m_bForceAppelSynchrone
		}
		else if (undefined === this.m_nSetTimeout_AJAX)
		{
			// Et demande le traitement de l'evenement
			// Permet de ne pas bloquer l'affichage (Fermeture des combos)
			this.m_nSetTimeout_AJAX = clWDUtil.nSetTimeout(__TraiteAJAXExecuteEvenement, clWDUtil.ms_oTimeoutImmediat);
		}
	},

	// Traite les evenements AJAX en attente
	TraiteAJAXExecuteEvenement: function TraiteAJAXExecuteEvenement()
	{
		delete this.m_nSetTimeout_AJAX;

		// Supprime le reaffichage de l'activite AJAX
		this.s_ReactualiseActivite(false);

		// Assert(this.m_tabRequetes.length == 1);
		// Tant que l'on a des requetes
		while (this.m_tabRequetes.length > 0)
		{
			// Recupere la requete (et la supprime de la liste)
			var stRequete = this.m_tabRequetes.shift();
			// Traite la requete
			var bRes = this.bAJAXExecuteEvenementInterne(stRequete.oPage, stRequete.sChamp, stRequete.nEvenement, stRequete.nOption, stRequete.m_nTraitementApresAjax);

			// Et sort direct si on est en erreur
			if (!bRes)
			{
				this.m_tabRequetes.length = 0;
			}
			// Mode special pour le SILO, les requetes sont 'synchrones'
			if (this.m_bInvokeAndWait)
			{
				if (this.m_tabRequetes.length > 0)
				{
					this.__SetTimeoutTraiteAJAXExecuteEvenement();
					break;
				}
			}
		}
	},

	// Execute le code serveur d'un champ. Version interne : celle appele via un timer
	bAJAXExecuteEvenementInterne: function bAJAXExecuteEvenementInterne(oPage, sChamp, nEvenement, nOption, nTraitementApresAjax)
	{
		// Si plus d'AJAX on sort
		if (!this.bWDAJAXMainValide())
		{
			return;
		}

		try
		{
			// on prepare la requete
			var sRequete = this.sConstuitRequeteEvenement(oPage, sChamp, nEvenement, nOption);
			if ("" === sRequete)
			{
				return true;
			}

			// on prepare l'URL
			var sURL = this.sConstruitURL(clWDUtil.sGetPageAction(oPage));
			// on cree la requete
			var clRequete = this.clCreeWDAJAXRequete(true, true);

			// Si la creation n'a pas echoue (AJAX possible)
			if (clRequete)
			{
				// On execute la requete
				this.__xEnvoi(clRequete, sRequete, sURL);
				// Si le resulat est valide on le renvoi
				var bRes;
				switch (this.eReponseGenerique(clRequete, oPage, null, []))
				{
				case 0:	// 0 = Echec
					bRes = false;
//					// @@@ Filtre sur le r�sultat
////				oTraitementApresAjax = null;
					break;
				case 1:	// 1 = R�ussite
					bRes = true;
					// Si on a un traitement apr�s AJAX : on l'ex�cute
					break;
				case 2:	// 2 = Annulation (pour redirection)
					bRes = true;
					// GP 16/07/2018 : QW300337 : Pas de traitement apr�s AJAX.
					nTraitementApresAjax = null;
					break;
					}
				// Si on a un traitement apr�s AJAX : on l'ex�cute
				switch (typeof nTraitementApresAjax)
				{
				case "function":
					// Attention : si on m�lange deux versions du produit (page avec un composant en version 20-), nTraitementApresAjax peut �tre un pointeur de fonction
					nTraitementApresAjax();
					break;
				case "number":
					clWDUtil.pfGetTraitement(sChamp, nTraitementApresAjax)();
					break;
				}
				return bRes;
			}
			else
			{
				// Cas AJAX impossible
				this.ErreurAJAX();
				return false;
			}
		}
		finally
		{
			if (window["WDAnimSurPopup"])
			{
				WDAnimSurPopup.prototype.s_Continue();
			}
		}
	},

	// Encoie une requ�te
	__xEnvoi: function __xEnvoi(oRequete, sRequete, sURL)
	{
		var bSynchrone = oRequete.m_bSynchrone;
		try
		{
			// On actualise le compteur de requete synchrone en cours si besoin
			if (bSynchrone)
			{
				ms_nRequeteSynchrone++;
			}
			// Et on affiche le temoin d'activite AJAX (Dans tous les cas : synchrone et asynchrone)
			this.s_ReactualiseActivite(false);

			// On execute la requete
			oRequete.xEnvoi(sRequete, sURL);
		}
		finally
		{
			// On actualise le compteur de requete synchrone en cours si besoin
			if (bSynchrone)
			{
				ms_nRequeteSynchrone--;
				// Et on affiche le temoin d'activite AJAX (Uniquement dans le cas synchrone)
				this.s_ReactualiseActivite(false);
			}
		}
	},

	// Appel normal dans le cas ou AJAX n'est pas disponible
	// Ignore nTraitementApresAjax car on ne fait pas l'appel AJAX !!!
	NormalExecuteEvenement: function(oPage, sChamp, nEvenement, nOption/*, nTraitementApresAjax*/)
	{
		switch (nOption)
		{
		// Envoie la valeur du champ courant. Renvoie la valeur de tous les champs car on ne sait pas faire moins
		case 1:
			// Envoie la valeur de tous les champs de la page
			// falls through
		case 2:
			// Construction d'un _JSL
			_JSL(oPage, sChamp, "_self", "", "");
			break;

		case 3:
			// Clic sur une reglette mais sans submit
			// Resultat de la forme "/WD110AWP/WD110AWP.EXE?WD_ACTION=SCROLLTABLE&TABLE1=4"
			// Construction d'un _JCL ?
			break;

		case 4:
			// Clic sur une reglette avec submit
			// Appel de _RXXX
			window["_R" + sChamp](nEvenement);
			break;

		// Ne renvoie aucune valeur
		default:
			// Construction d'un _JCL
			_JCL(oPage.action + "?" + sChamp, "_self", "", "");
			break;
		}
	},

	// Creation d'une requete AJAX avec une URL et des donnees
	// Commun a AJAXExecute et JSONExecute
	sRequeteSynchroneTexte: function sRequeteSynchroneTexte(bPOST, sRequete, sURL, oPage)
	{
		// on cree la requete
		var clRequete = this.clCreeWDAJAXRequete(bPOST, true);
		// Si la creation n'a pas echoue (AJAX possible)
		if (clRequete)
		{
			// on execute la requete
			this.__xEnvoi(clRequete, sRequete, sURL);
			// On verifie la validite du resultat et on le renvoie si il est valide
			var sRes = clRequete.bValideResultat() ? clRequete.sGetResultat(oPage) : "";
			// Libere la requete
			clRequete.Libere();
			clRequete = null;
			// Renvoi le resultat
			return sRes;
		}
		else
		{
			// Cas AJAX impossible
			this.ErreurAJAX();
			return "";
		}
	},
	// nOptions est une combinaison de ms_nAJAXExecuteXxx
	sRequeteAsynchroneTexte: function sRequeteAsynchroneTexte(bPOST, sRequete, sURL, fCallback, nOptions)
	{
		// on cree la requete
		var clRequete = this.clCreeWDAJAXRequete(bPOST, false);
		// Si la creation n'a pas echoue (AJAX possible)
		if (clRequete)
		{
			// on recupere son identifiant pour manipulations ulterieure (annulation, recuperation du resultat)
			var nIdRequete = clRequete.m_nId;
			// GP 25/11/2014 : Vu par GF : si on n'a pas de callback, le placement de la valeur des champs n'est pas faite
			if ((!fCallback) && (nOptions & this.ms_nAJAXExecuteChamps))
			{
				fCallback = clWDUtil.m_pfVide;
			}
			clRequete.m_bJSONExterne = !!(nOptions & this.ms_nAJAXExecuteJSONExterne);
			// On renseigne la callback pour la validation du resultat
			clRequete.m_fCallback = fCallback;
			// on execute la requete
			this.__xEnvoi(clRequete, sRequete, sURL);
			// on renvoie l'identifiant de la requete
			return nIdRequete;
		}
		else
		{
			// Cas AJAX impossible
			this.ErreurAJAX();
			return "";
		}
	},


	// Par compatibilit� avec les pages 21-
	// Declenche un appel bloquant sur un URL autorise (normalement sur le meme serveur)
	JSONExecute: function(sURL)
	{
		// Execute l'appel serveur le resultat de l'appel serveur
		var sRes = this.sRequeteSynchroneTexte(false, "", sURL, window._PAGE_);

		// Traite le resultat SANS validation
		return clWDUtil.oEvalJSON(sRes, {});
	},

	// GP 30/05/2014 : QW245509 : Si la page inclus une collection navigateur export�e par un composant qui a �t� g�n�r� en 19 ou moins,
	// cette collection appel avec l'ancienne syntaxe : on conserve les deux syntaxes
	// Declenche l'execution synchrone d'une procedure AJAX sur le serveur
	// ATTENTION : le nombre de parametres est variable
	AJAXExecuteSynchrone: function AJAXExecuteSynchrone(sProcedure, sAliasContexte)
	{
		return this.__AJAXExecute(sProcedure, false, null, sAliasContexte, this.ms_nAJAXExecuteDefaut, 2, arguments);
	},

	// Declenche l'execution synchrone d'une procedure AJAX sur le serveur
	// ATTENTION : le nombre de parametres est variable
	AJAXExecuteSynchrone20: function AJAXExecuteSynchrone20(sProcedure, sAliasContexte, nOptions)
	{
		return this.__AJAXExecute(sProcedure, false, null, sAliasContexte, nOptions, 3, arguments);
	},

	// GP 30/05/2014 : QW245509 : Si la page inclus une collection navigateur export�e par un composant qui a �t� g�n�r� en 19 ou moins,
	// cette collection appel avec l'ancienne syntaxe : on conserve les deux syntaxes
	// Declenche l'execution asynchrone d'une procedure AJAX sur le serveur
	// ATTENTION : Le nombres de parametres est variable
	AJAXExecuteAsynchrone: function AJAXExecuteAsynchrone(sProcedure, fCallback, sAliasContexte)
	{
		return this.__AJAXExecute(sProcedure, true, fCallback, sAliasContexte, this.ms_nAJAXExecuteDefaut, 3, arguments);
	},

	// Declenche l'execution asynchrone d'une procedure AJAX sur le serveur
	// ATTENTION : Le nombres de parametres est variable
	AJAXExecuteAsynchrone20: function AJAXExecuteAsynchrone20(sProcedure, fCallback, sAliasContexte, nOptions)
	{
		return this.__AJAXExecute(sProcedure, true, fCallback, sAliasContexte, nOptions, 4, arguments);
	},
	// Declenche l'execution asynchrone d'une procedure AJAX sur le serveur
	// ATTENTION : Le nombres de parametres est variable
	__AJAXExecute: function __AJAXExecute(sProcedure, bAsynchrone, fCallback, sAliasContexte, nOptions, nNbParamIgnore, tabParamsOriginaux)
	{
		// Si plus d'AJAX on sort
		if (!this.bWDAJAXMainValide())
		{
			return "";
		}

		// on prepare la requete
		var sRequete = this.sConstuitRequeteProcedure(sProcedure, sAliasContexte, nOptions);
		// on ajoute les parametres de la procedure
		sRequete += clWDUtil.sConstuitProcedureParams(nNbParamIgnore, tabParamsOriginaux);
		// on prepare l'URL
		var sURL = this.sConstruitURL(clWDUtil.sGetPageAction());

		// Traite la requete
		if (bAsynchrone)
		{
			return this.sRequeteAsynchroneTexte(true, sRequete, sURL, fCallback, nOptions);
		}
		else
		{
			// Traite la requete
			return this.sRequeteSynchroneTexte(true, sRequete, sURL, window._PAGE_);
		}
	},

	// renvoie l'etat d'une requete asynchrone
	AJAXAppelAsynchroneEnCours: function(nId)
	{
		// Si plus d'AJAX on sort
		if (!this.bWDAJAXMainValide())
		{
			return false;
		}

		// on commence par rechercher la requete
		var oRequete = this.GetWDAJAXRequete(nId);
		// Si on trouve la requete, c'est qu'elle est en cours
		// GP 02/11/2018 : QW305466 : force une r�ponse de type bool�en. Sinon la conversion du WL en type bool�en risque de mal convertir la valeur null.
		return oRequete ? oRequete.bEnCours() : false;
	},

	// Annule une requete asynchrone
	AJAXAnnuleAppelAsynchrone: function(nId)
	{
		// Si plus d'AJAX on sort
		if (!this.bWDAJAXMainValide())
		{
			return false;
		}

		// on commence par rechercher la requete
		var clRequete = this.GetWDAJAXRequete(nId);
		// si on trouve la requete, on l'annule
		if (clRequete)
		{
			clRequete.Annule();
		}
	},

	// Version interne de AJAXRecupereLignesTable et AJAXRecupereLignesTableSelection
	__nAJAXRecupereLignesTable: function __nAJAXRecupereLignesTable(oObjetRequeteTable, sRequete)
	{
		// Uniquement si on a encore de l'AJAX
		if (this.bWDAJAXMainValide())
		{
			// Prepare l'URL
			var sURL = this.sConstruitURL(clWDUtil.sGetPageAction());
			// Cree la requete et demande l'initialisation pour les tables
			var clRequete = this.clCreeWDAJAXRequete(true, false, oObjetRequeteTable);

			// Si la creation n'a pas echoue (AJAX possible)
			if (clRequete)
			{
				// Recupere son identifiant pour manipulations ulterieure (annulation, recuperation du resultat)
				var nIdRequete = clRequete.m_nId;
				// Execute la requete
				this.__xEnvoi(clRequete, sRequete, sURL);
				// Renvoie l'identifiant de la requete
				return nIdRequete;
			}
			else
			{
				// Cas AJAX impossible
				this.ErreurAJAX();
				return false;
			}
		}
		else
		{
			return false;
		}
	},


	// Demande les lignes donnees de la table donnee au serveur
	nAJAXRecupereLignesTable: function nAJAXRecupereLignesTable(oObjetRequeteTable, sRequeteTable)
	{
		// Prepare la requete
		var sRequete = this.sConstuitRequeteTable(sRequeteTable);
		return this.__nAJAXRecupereLignesTable(oObjetRequeteTable, sRequete);
	},

	// Demande les lignes donnees de la table donnee au serveur
	nAJAXRecupereLignesTableSelection: function nAJAXRecupereLignesTableSelection(oObjetRequeteTable, sRequeteTable, bSubmit)
	{
		// Prepare la requete
		var sRequete = this.sConstuitRequeteEvenement(window._PAGE_, oObjetRequeteTable.m_oChampTable.m_sAliasChamp, 0, bSubmit ? 5 : 6) + "&" + sRequeteTable;
		return this.__nAJAXRecupereLignesTable(oObjetRequeteTable, sRequete);
	},

	// Notifie du enroul�/d�roule
	nAJAXRecupereLignesTableEnrouleDeroule: function nAJAXRecupereLignesTableEnrouleDeroule(oObjetRequeteTable, nLigne, sRequeteTable)
	{
		// Prepare la requete
		this.SetZRChampEnrouleDeroule(window._PAGE_, oObjetRequeteTable.m_oChampTable.m_sAliasChamp, nLigne, -1);
		var sRequete = this.sConstuitRequeteEvenement(window._PAGE_, oObjetRequeteTable.m_oChampTable.m_sAliasChamp, 'ENDETABLE', 10);
		if (sRequeteTable.length > 0)
		{
			sRequete += sRequeteTable;
		}
		return this.__nAJAXRecupereLignesTable(oObjetRequeteTable, sRequete);
	},


	// Recupere une jauge
	oAJAXRecupereJauge: function oAJAXRecupereJauge(sAliasJauge)
	{
		// Resultat invalide ou AJAX non disponible
		// 0 = pas de requete
		var oResultat = { m_eJauge: 0 };

		// Uniquement si l'AJAX est valide
		if (this.bWDAJAXMainValide())
		{
			// Prepare l'URL/requete (la requete est dans l'URL)
			var sURL = this.sConstuitURLRequeteJauge(sAliasJauge);
			// Execute l'appel serveur le resultat de l'appel serveur
			var sResultat = this.sRequeteSynchroneTexte(false, "", sURL, window._PAGE_);

			// Si le resultat est valide, retourne un objet
			oResultat = clWDUtil.oEvalJSON(sResultat, oResultat);
		}

		return oResultat;
	},

	// Sauve le temoin d'activite AJAX
	InitActivite: function(sActiviteChamp, nActiviteOption)
	{
		// Recupere directement le champ
		ms_oActiviteChamp = _JGE(sActiviteChamp, document, true);
		// Et sauve l'option
		ms_nActiviteOption = nActiviteOption;

		// Initialise les callback de redimensionnement/defilement du navigateur
		clWDUtil.AttacheOnScrollResize(__ReactualiseActivite);

		// Et met a jour le temoin
		// S'il n'a pas encore ete defini : valeur par defaut
		// S'il est deja defini : utilise sa valeur pour afficher le temoin
		__ReactualiseActivite();
	},

		// Met a jour le temoin d'activite AJAX si besoin
		s_ReactualiseActivite: function s_ReactualiseActivite(bForce)
		{
			// Calcule le nouvel etat
			var bActivite = (0 < ms_tabConnexions.length) || (0 < ms_nRequeteSynchrone) || bForce;
			// Si l'etat change : effectue les modifications
			if (ms_bActivite !== bActivite)
			{
				// Sauve le nouvel etat
				ms_bActivite = bActivite;
				__ReactualiseActivite();
			}
		}
	};
})();

// Relance le calcul des champs dispositions (pour le cas ou un champ est dans le volet)
// Pas de test de $ a l'ext�rieur, jQuery n'est pas encore charg� au moment du chargement de ce fichier.
clWDUtil.m_oNotificationsFinAJAX.AddNotification(function()
{
	if (window.$)
	{
		$(window).trigger("trigger.wb.disposition.visible.maj");
	}
});

// Fonction d'appel
function _JAEE(oPage, sChamp, nEvenement, nOption, nTraitementApresAjax)
{
	clWDAJAXMain.AJAXExecuteEvenement(oPage, sChamp, nEvenement, nOption, nTraitementApresAjax);
};
function _JAZR(sZRChamp, sValeur)
{
	clWDAJAXMain.SetZRChamp(sZRChamp, sValeur);
};
function _JAZREDE(oPage, sZRChamp, nLigne, nRupture)
{
	clWDAJAXMain.SetZRChampEnrouleDeroule(oPage, sZRChamp, nLigne, nRupture);
};
