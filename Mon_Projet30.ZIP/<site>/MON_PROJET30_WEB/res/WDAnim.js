// WDAnim.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - StdAction.js
///#GLOBALS _JGE _JGEN
// - WDUtil.js
///#GLOBALS bIEQuirks9Max bSfr WDAnim AppelMethode
// - WDChamp.js
///#GLOBALS WDChamp

var WDAnimSurImage = (function()
{
	var ms_nTypeMin = 1;
	var ms_nTypeFondu = 1;
	var ms_nTypeBalayageBas = 2;
	var ms_nTypeBalayageHaut = 3;
	var ms_nTypeBalayageDroite = 4;
	var ms_nTypeBalayageGauche = 5;
	var ms_nTypeRecouvrementHaut = 6;
	var ms_nTypeRecouvrementBas = 7;
	var ms_nTypeRecouvrementGauche = 8;
	var ms_nTypeRecouvrementDroite = 9;
	var ms_nTypeRecouvrement = 10;
	var ms_nTypeRecouvrementZoom = 11;
	var ms_nTypeDecouvrement = 12;
	var ms_nTypeDecouvrementZoom = 13;
	var ms_nTypeAleatoire = 14;
	var ms_nTypeDezoomDeplacement = 15;
	var ms_nTypeDecouvrementHautGauche = 16;
	var ms_nTypeDecouvrementHautDroite = 17;
	var ms_nTypeDecouvrementBasGauche = 18;
	var ms_nTypeDecouvrementBasDroite = 19;
	var ms_nTypeBoiteFondu = 20;
	var ms_nTypeBoiteMin = ms_nTypeBoiteFondu;
	var ms_nTypeBoiteFonduBasDroite = 21;
	var ms_nTypeBoiteFonduDeplacement = 22;
	var ms_nTypeBoiteFonduDeplacementHautGauche = 23;
	var ms_nTypeBoiteFonduDeplacementHautDroite = 24;
	var ms_nTypeBoiteFonduDeplacementBasGauche = 25;
	var ms_nTypeBoiteFonduDeplacementBasDroite = 26;
	var ms_nTypeBoiteFonduCroiseHorizontal = 27;
	var ms_nTypeBoiteFonduCroiseVertical = 28;
	var ms_nTypeBoiteFonduHorizontal = 29;
	var ms_nTypeBoiteFonduVertical = 30;
	var ms_nTypeBoiteReduction = 31;
	var ms_nTypeBoiteRotation = 32;
	var ms_nTypeBoiteRideauHorizontal = 33;
	var ms_nTypeBoiteRideauVertical = 34;
	var ms_nTypeBoiteMax = ms_nTypeBoiteRideauVertical;
	var ms_nTypeDeplacementGauche = 130;
	var ms_nTypeDeplacementDroite = 131;
	var ms_nTypeDeplacementHaut = 132;
	var ms_nTypeDeplacementBas = 133;
	var ms_nTypeDeplacementHautGauche = 134;
	var ms_nTypeDeplacementHautDroite = 135;
	var ms_nTypeDeplacementBasGauche = 136;
	var ms_nTypeDeplacementBasDroite = 137;
	var ms_nTypeDeplacementDezoomGauche = 138;
	var ms_nTypeDeplacementDezoomDroite = 139;
	var ms_nTypeDeplacementDezoomHaut = 140;
	var ms_nTypeDeplacementDezoomBas = 141;
	var ms_nTypeDeplacementDezoomHautGauche = 142;
	var ms_nTypeDeplacementDezoomHautDroite = 143;
	var ms_nTypeDeplacementDezoomBasGauche = 144;
	var ms_nTypeDeplacementDezoomBasDroite = 145;
	var ms_nTypeDeplacementDezoom = 146;
	var ms_nTypeDezoomGauche = 147;
	var ms_nTypeDezoomDroite = 148;
	var ms_nTypeDezoomHaut = 149;
	var ms_nTypeDezoomBas = 150;
	var ms_nTypeDezoomHautGauche = 151;
	var ms_nTypeDezoomHautDroite = 152;
	var ms_nTypeDezoomBasGauche = 153;
	var ms_nTypeDezoomBasDroite = 154;
	var ms_nTypeDezoomCentre = 155;
	var ms_nTypeDezoom = 156;
	var ms_nTypeDezoomPanoramique = 157;
	var ms_nTypeDeplacement = 158;
	var ms_nTypeFin = 158;
	var ms_nTypeMax = 34;
	__WDAnimSurImage.prototype.ms_nTypeMouvementAutomatique = ms_nTypeDezoomDeplacement;

	var ms_nAvancementMax = 1000;
	var ms_nZoom = 1;

	var ms_oDiapos = {};

	function __WDAnimSurImage(oBaliseImg, sImageDebut, nOpaciteDebut, nType, nCourbe, nDuree, sImageFin, sAliasChamp, bPremAffich)
	{
		//Image ?
		if (oBaliseImg === undefined)
		{
			//Non => rien � faire
			return;
		}
		while (nType == ms_nTypeAleatoire)
		{
			nType = __s_nHasardMinMax(ms_nTypeMin, ms_nTypeMax);
		}
		if (nType == ms_nTypeDeplacementDezoom)
		{
			nType = __s_nHasardMinMax(ms_nTypeDeplacementDezoomGauche, ms_nTypeDeplacementDezoomBasDroite);
		}
		else if (nType == ms_nTypeDeplacement)
		{
			nType = __s_nHasardMinMax(ms_nTypeDeplacementGauche, ms_nTypeDeplacementBasDroite);
		}
		else if (nType == ms_nTypeDezoom)
		{
			nType = __s_nHasardMinMax(ms_nTypeDezoomGauche, ms_nTypeDezoomCentre);
		}
		this.m_oBaliseImg = oBaliseImg;
		this.m_nOpaciteDebut = nOpaciteDebut;
		this.m_bPremierAffichage = bPremAffich;
		this.m_nX = this.GetX(oBaliseImg);
		this.m_nY = this.GetY(oBaliseImg);
		// GP 01/03/2016 : TB96885 : On tient compte du padding (copi� plus bas)
		var oStyleBaliseImg = clWDUtil.oGetCurrentStyle(oBaliseImg);
		this.m_nLargeur = this.GetLargeur(oBaliseImg) - (parseFloat(oStyleBaliseImg.paddingLeft) - parseFloat(oStyleBaliseImg.paddingRight));
		this.m_nHauteur = this.GetHauteur(oBaliseImg) - (parseFloat(oStyleBaliseImg.paddingTop) + parseFloat(oStyleBaliseImg.paddingBottom));

		this.m_nCourbe = nCourbe;
		this.m_nDuree = nDuree;
		this.m_nType = nType;
		this.m_sTransition = __s_sGetTransition(oBaliseImg);
		this.m_sAliasChamp = sAliasChamp;
		var oBaliseImgParent = oBaliseImg.parentNode;
		this.m_nLargeurVisible = this.GetLargeur(oBaliseImgParent);
		this.m_nHauteurVisible = this.GetHauteur(oBaliseImgParent);
		var bDeuxImages = __s_bDeuxImages(nType);
		var oDiapo = ms_oDiapos[sAliasChamp];
		var bGarderImageFin = __s_bGarderImageFin(nType);
		if (bGarderImageFin && (!oDiapo))
		{
			oDiapo = ms_oDiapos[sAliasChamp] = new WDDiapo();
		}
		this.m_oDiapo = oDiapo;
		if (oDiapo && oDiapo.m_oDiv)
		{
			this.m_oDiv = oDiapo.m_oDiv;
		}
		else
		{
			// GP/GF 04/01/2018 : TB106543 : Si le parent est en position:static, l'overflow ne fonctionne pas. Le moins pire est le forcer en relative.
			// L'inconv�nient est que cela change le z-index de cet �l�ment.
			if (clWDUtil.oGetCurrentStyle(oBaliseImgParent).position === "static")
			{
				oBaliseImgParent.style.position = "relative";
				// GP/GF 03/11/2021 : QW445133 : relative n'aurait jamais du fonctionner, il faut un �l�ment "block". Place le minimum possible : "inline-block".
				oBaliseImgParent.style.display = "inline-block";
			}

			this.m_oDiv = document.createElement("div");
			this.SetSuperposable(this.m_oDiv);
			this.m_oDiv.style.overflow = "hidden";
			this.AjoutFrere(this.m_oDiv);
			if (oDiapo)
			{
				oDiapo.m_oDiv = this.m_oDiv;
			}
		}
		this.SetX(this.m_oDiv, this.m_nX);
		this.SetY(this.m_oDiv, this.m_nY);
		this.SetLargeur(this.m_oDiv, this.m_nLargeur);
		this.SetHauteur(this.m_oDiv, this.m_nHauteur);
		this.m_oDiv.style.padding = oStyleBaliseImg.padding;
		//Image temporaire si pas animation de type boite
		var bImageTemp = !this.bTypeBoite(nType);
		//Image temporaire ?
		if (bImageTemp)
		{
			//Oui => cr�ation image temporaire
			this.m_oBaliseImgTemp = this.oAjoutImageTemp(oBaliseImg, sImageDebut, nOpaciteDebut, nType, this.bImageTempFrere(nType));
		}
		else
		{
			//Non => init nombre lignes et colonnes en fonction du type d'animation boite
			switch (this.m_nType)
			{
			case ms_nTypeBoiteRideauHorizontal:
				this.m_nNbLigne = 1;
				this.m_nNbColonne = 2;
				break;
			case ms_nTypeBoiteRideauVertical:
				this.m_nNbLigne = 2;
				this.m_nNbColonne = 1;
				break;
			case ms_nTypeBoiteFonduCroiseHorizontal:
			case ms_nTypeBoiteFonduHorizontal:
				this.m_nNbLigne = 5;
				this.m_nNbColonne = 1;
				break;
			case ms_nTypeBoiteFonduCroiseVertical:
			case ms_nTypeBoiteFonduVertical:
				this.m_nNbLigne = 1;
				this.m_nNbColonne = 5;
				break;
			case ms_nTypeBoiteRotation:
				this.m_nNbLigne = 1;
				this.m_nNbColonne = 1;
				break;
			default:
				this.m_nNbLigne = 5;
				this.m_nNbColonne = 5;
				break;
			}
			//Initialisation nombre boites
			this.m_nNbBoite = this.m_nNbLigne * this.m_nNbColonne;
			//Initialisation largeur boite
			this.m_nLargeurBoite = this.m_nLargeur / this.m_nNbColonne;
			//Initialisation hauteur boite
			this.m_nHauteurBoite = this.m_nHauteur / this.m_nNbLigne;
			//Parent boites
			var oParentBoite = this.m_oDiv;
			//Abscisse parent boites
			var nXParentBoite = this.GetX(oParentBoite);
			//Ordonn�e parent boites
			var nYParentBoite = this.GetY(oParentBoite);
			//Initialisation table des boites
			this.m_tabBoite = [];
			//Cr�ation des boites
			for (var nLigne = 0; nLigne < this.m_nNbLigne; nLigne++)
			{
				for (var nColonne = 0; nColonne < this.m_nNbColonne; nColonne++)
				{
					//Cr�ation boite
					var oBoite = oCreerDivSuperposable(oParentBoite, false, false, true);
					//Ajout de la boite � la table des boites
					this.m_tabBoite.push(oBoite);
					//Abscisse relative boite par rapport � son parent
					var nXDiff = nColonne * this.m_nLargeurBoite;
					//Abscisse boite
					var nXBoite = nXParentBoite + nXDiff;
					//Initialisation abscisse boite
					this.SetX(oBoite, nXBoite);
					//Ordonn�e relative boite par rapport � son parent
					var nYDiff = nLigne * this.m_nHauteurBoite;
					//Ordonn�e boite
					var nYBoite = nYParentBoite + nYDiff;
					//Initialisation ordonn�e boite
					this.SetY(oBoite, nYBoite);
					//Initialisation largeur boite
					this.SetLargeur(oBoite, this.m_nLargeurBoite);
					//Initialisation hauteur boite
					this.SetHauteur(oBoite, this.m_nHauteurBoite);
					//On met l'image en image de fond de la boite
					//On met l'image en image de fond de la boite
					try
					{
						oBoite.style.backgroundImage = "url(" + this.m_oBaliseImg.src + ")";
						oBoite.style.backgroundSize = this.m_nLargeur + "px " + this.m_nHauteur + "px";
					}
					catch (e)
					{
						//erreur 
					}
					//Positionnement de l'image de fond de la boite
					oBoite.style.backgroundPosition = -nXDiff + "px " + -nYDiff + "px";
					//Initialisation opacit� boite avec celle de l'image au d�part
					this.SetOpacite(oBoite, this.m_nOpaciteDebut);
				}
			}
		}
		//On utilise les transitions si support�es sauf pour l'effet Ken Burns (moins fluide avec transitions), et pour certains effets sous Safari qui ne marchent pas avec les transitions
		var bTransition = (nType != ms_nTypeDezoomDeplacement) && ((!bSfr) || (nType == ms_nTypeFondu) || (nType > ms_nTypeDecouvrement)) && (__s_sGetTransition(bImageTemp ? this.m_oBaliseImgTemp : this.m_oDiv) != null);
		this.m_nDistance = nDuree / 4;
		// GP 21/11/2012 : QW226469 : Que en quirks avec IE9- : utilise bIEQuirks9Max
//		this.m_bFiltre = navigator.userAgent.toLowerCase().indexOf("msie") >= 0;
		var i = (oDiapo && oDiapo.m_oImgTempFin);
		if (i)
		{
			this.SetX(this.m_oBaliseImgTemp, this.GetX(oDiapo.m_oImgTempFin));
			this.SetY(this.m_oBaliseImgTemp, this.GetY(oDiapo.m_oImgTempFin));
			this.SetLargeur(this.m_oBaliseImgTemp, this.GetLargeur(oDiapo.m_oImgTempFin));
			this.SetHauteur(this.m_oBaliseImgTemp, this.GetHauteur(oDiapo.m_oImgTempFin));
			if (bIEQuirks9Max)
			{
				this.m_oBaliseImgTemp.style.filter = oDiapo.m_oImgTempFin.style.filter;
			}
		}
		this.m_oBaliseImgTempFin = null;
		if (bDeuxImages)
		{
			this.m_oBaliseImgTempFin = this.oAjoutImageTemp(oBaliseImg, sImageFin, nOpaciteDebut, nType);
		}
		if (oDiapo)
		{
			if (i)
			{
				oDiapo.m_oDiv.removeChild(oDiapo.m_oImgTempFin);
				delete oDiapo.m_oImgTempFin;
				if (oDiapo.m_oCanva != null)
				{
					oDiapo.m_oDiv.removeChild(oDiapo.m_oCanva);
					delete oDiapo.m_oCanva;
				}
			}
			if (bGarderImageFin)
			{
				oDiapo.m_oImgTempFin = this.m_oBaliseImgTempFin;
			}
			else
			{
				delete oDiapo;
				delete ms_oDiapos[sAliasChamp];
				this.m_oDiapo = null;
			}
		}
		//Image temporaire ?
		if (bImageTemp)
		{
			//Oui => on la rend visible
			SetVisible(this.m_oBaliseImgTemp, true);
		}
		var l = true;
		this.m_sVisibilite = null; 
		if (bDeuxImages)
		{
			this.m_sVisibilite = this.GetVisibilite(oBaliseImg);
			this.SetVisibilite(oBaliseImg, "hidden");
			switch (nType)
			{
			case ms_nTypeDeplacementBas:
			case ms_nTypeDeplacementHaut:
				this.SetX(this.m_oBaliseImgTempFin, this.m_nX - Math.max(0, (this.m_nLargeur - this.m_nLargeurVisible) / 2));
				break;
			case ms_nTypeDeplacementGauche:
			case ms_nTypeDeplacementDroite:
				this.SetY(this.m_oBaliseImgTempFin, this.m_nY - Math.max(0, (this.m_nHauteur - this.m_nHauteurVisible) / 2));
				break;
			case ms_nTypeDezoomPanoramique:
				this.InitZone();
				break;
			case ms_nTypeDezoomDeplacement:
				//Pas besoin de canva si on utilise les transitions
				if (!bTransition)
				{
					this.m_oCanva = document.createElement("canvas");
					// GP 06/01/2016 : TB89870 : Copie les attributs title et alt de l'image source.
					if (oBaliseImg.title)
					{
						this.m_oCanva.title = oBaliseImg.title;
					}
					if ((this.m_oCanva != null) && (this.m_oCanva.getContext != null))
					{
						this.m_oDC = this.m_oCanva.getContext("2d");
					}
					if (this.m_oDC)
					{
						this.SetSuperposable(this.m_oCanva);
						this.m_oDiv.appendChild(this.m_oCanva);
						if (oDiapo)
						{
							oDiapo.m_oCanva = this.m_oCanva;
						}
						this.SetOpacite(this.m_oCanva, nOpaciteDebut);
						this.SetX(this.m_oCanva, this.m_nX);
						this.SetY(this.m_oCanva, this.m_nY);
						SetVisible(this.m_oBaliseImgTempFin, false);
					}
				}
				if (this.bImageCharge(this.m_oBaliseImgTempFin))
				{
					this.InitDimImageTempFin();
				}
				else
				{
					var c = nCourbe;
					var oThis = this;
					this.m_oBaliseImgTempFin.onload = function()
					{
						oThis.m_oBaliseImgTempFin.onload = null;
						oThis.InitDimImageTempFin();
						//Transitions dispos
						if (bTransition)
						{
							//Oui => init transitions
							oThis.InitTransition();
						}
						else
						{
							//Non => appel de la classe de base (lance l'animation)
							WDAnim.prototype.constructor.apply(oThis, [oThis._fGetAnimFonction(oThis.m_nType), 0, ms_nAvancementMax, oThis.m_nType, c, oThis.m_nDuree, oThis.m_sAliasChamp]);
						}
					};
					l = false;
				}
				break;
			default:
				break;
			}
			if (l)
			{
				SetVisible(this.m_oBaliseImgTempFin, true);
			}
		}
		if (ms_nTypeFondu == nType)
		{
			this.SetOpacite(oBaliseImg, 0);
		}

		if (l)
		{
			//Transitions dispos
			if (bTransition)
			{
				//Oui => init transitions
				this.InitTransition();
			}
			else
			{
				//Non => appel de la classe de base (lance l'animation)
				WDAnim.prototype.constructor.apply(this, [this._fGetAnimFonction(nType), 0, ms_nAvancementMax, nType, nCourbe, nDuree, sAliasChamp]);
			}
		}
	};

	__WDAnimSurImage.prototype = new WDAnim();
	__WDAnimSurImage.prototype.constructor = __WDAnimSurImage;

	__WDAnimSurImage.prototype.ms_oAnimations = {};

	__WDAnimSurImage.prototype.InitDimImageTempFin = function InitDimImageTempFin()
	{
		if ((!this.m_oDC) && bIEQuirks9Max)
		{
			this.m_oBaliseImgTempFin.style.filter = "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
		}
		else
		{
			this.SetOpacite(this.m_oBaliseImgTempFin, 0);
		}
		SetVisible(this.m_oBaliseImgTempFin, true);
		//this.SetLargeur(this.m_oBaliseImgTempFin,this.GetLargeur(this.m_oBaliseImgTempFin));
		//SetVisible(this.m_oBaliseImgTemp,false);
		if (this.bImageCharge(this.m_oBaliseImgTempFin))
		{
			this.m_nLargeur = this.GetLargeur(this.m_oBaliseImgTempFin);
			this.m_nHauteur = this.GetHauteur(this.m_oBaliseImgTempFin);
		}
		this.SetLargeur(this.m_oDiv, this.m_nLargeur);
		this.SetHauteur(this.m_oDiv, this.m_nHauteur);
		this.InitZone();
		this.InitZone(true);
		if (this.m_oDC)
		{
			//Modif dimensions canva pour Internet Explorer (sauf en HTML 5)
			this.SetLargeur(this.m_oCanva, this.m_nLargeur);
			this.SetHauteur(this.m_oCanva, this.m_nHauteur);
			//Modif dimensions canva pour autres navigateurs et Internet Explorer en HTML 5
			this.m_oCanva.width = this.m_nLargeur;
			this.m_oCanva.height = this.m_nHauteur;
			try { this.m_oDC.drawImage(this.m_oBaliseImgTempFin, this.GetX(this.m_oBaliseImgTempFin) - this.m_nX, this.GetY(this.m_oBaliseImgTempFin) - this.m_nY, this.GetLargeur(this.m_oBaliseImgTempFin), this.GetHauteur(this.m_oBaliseImgTempFin)/*,this.m_nLargeur,this.m_nHauteur,0,0,this.m_nLargeur,this.m_nHauteur*/); } catch (e) { };
		}
	};

	function __s_nHasardMinMax (fMin, fMax, bReel)
	{
		var fHasard = fMin + (Math.random() * (fMax - fMin));
		return bReel ? fHasard : Math.round(fHasard);
	};


	__WDAnimSurImage.prototype.nInitZoneCoord = function nInitZoneCoord(d, g, f, i)
	{
		return __s_nHasardMinMax((i != null) ? i : 0, d * g) * f;
	};

	__WDAnimSurImage.prototype.InitZone1 = function InitZone1(b)
	{
		var z = __s_nHasardMinMax(0.8, 0.9, true);
		var g = 1 - z;
		var f = 1 / z;
		var h = f - 1;
		if (b)
		{
			this.m_nZoomFin = h;
		}
		else
		{
			this.m_nZoom = h;
		}
		var x = this.nInitZoneCoord(this.m_nLargeur, g, f);
		if (b)
		{
			this.m_nXFin = x;
		}
		else
		{
			this.m_nXDepart = x;
		}
		var i = 0;
		if (b)
		{
			var r = (0.05 * Math.min(this.m_nLargeur, this.m_nHauteur)) - Math.abs(this.m_nZoom - this.m_nZoomFin) * (this.m_nLargeur + this.m_nHauteur) - Math.abs(this.m_nXDepart - this.m_nXFin);
			if (r > 0)
			{
				var a = this.m_nYDepart / (1 + this.m_nZoom);
				var m = a - r;
				var l = g * this.m_nHauteur;
				var n = l - a - r;
				if (m > n)
				{
					g = m / this.m_nHauteur;
				}
				else
				{
					i = (a + r) / this.m_nHauteur;
				}
			}
			//var trc="zd:"+this.m_nZoom+";zf:"+this.m_nZoomFin+";xd:"+this.m_nXDepart+";xf:"+this.m_nXFin+";l:"+this.m_nLargeur+";h:"+this.m_nHauteur+";min:"+0.05*Math.min(this.m_nLargeur,this.m_nHauteur)+";r:"+r+";yd:"+this.m_nYDepart;
		}
		var y = this.nInitZoneCoord(this.m_nHauteur, g, f, i);
		if (b)
		{
			this.m_nYFin = y;
		}
		else
		{
			this.m_nYDepart = y;
		}
	};

	__WDAnimSurImage.prototype.InitZone2 = function InitZone2(b)
	{
		var z = __s_nHasardMinMax(0.8, 0.9, true);
		var g = 1 - z;
		var f = 1 / z;
		var h = f - 1;
		if (b)
		{
			this.m_nZoomFin = h;
		}
		else
		{
			this.m_nZoom = h;
		}
		var x = this.nInitZoneCoord(this.m_nLargeur, g, f);
		if (b)
		{
			this.m_nXFin = x;
		}
		else
		{
			this.m_nXDepart = x;
		}
		if (b)
		{
			var r = this.m_nDistance - Math.abs(((this.m_nZoomFin - this.m_nZoom) * (this.m_nLargeur + this.m_nHauteur) / 2) + (this.m_nXDepart - this.m_nXFin));
			var l = g * this.m_nHauteur;
			if (r > 0)
			{
				var a = this.m_nYDepart / (1 + this.m_nZoom);
				var m = a - r;
				var n = l - a - r;
				if (m > n)
				{
					this.m_nYFin = Math.max(m, 0);
				}
				else
				{
					this.m_nYFin = Math.min(this.m_nYDepart + r, l);
				}
			}
			else
			{
				this.m_nYFin = Math.min(this.m_nYDepart, l * f);
			}
		}
		else
		{
			this.m_nYDepart = this.nInitZoneCoord(this.m_nHauteur, g, f);
		}
	};

	__WDAnimSurImage.prototype.InitZone3 = function InitZone3(b)
	{
		var l = 0.9;
		if (b)
		{
			var m = Math.sqrt(Math.pow(this.m_nLargeur, 2) + Math.pow(this.m_nHauteur, 2));
			l = Math.min(l, (this.m_nDistance + m) / m);
		}
		var z = __s_nHasardMinMax(l - 0.1, l, true);
		var g = 1 - z;
		var f = 1 / z;
		var h = f - 1;
		if (b)
		{
			this.m_nZoomFin = h;
			var r = this.m_nDistance;
			var c = Math.acos(Math.max(Math.min(this.m_nXDepart / r, 1), -1));
			var d = Math.acos(Math.max(Math.min((this.m_nXDepart - (g * f * this.m_nLargeur)) / r, 1), -1));
			var e = Math.min(c, d);
			var i = Math.max(c, d);
			c = Math.asin(Math.max(Math.min(-this.m_nYDepart / r, 1), -1));
			d = Math.asin(Math.max(Math.min(((g * f * this.m_nHauteur) - this.m_nYDepart) / r, 1), -1));
			var j = Math.min(c, d);
			var k = Math.max(c, d);
			c = Math.max(e, j);
			d = Math.min(i, k);
			var a = 0;
			if (c > d)
			{
				this.m_nXFin = 0;
				this.m_nYFin = 0;
			}
			else
			{
				a = __s_nHasardMinMax(c, d, true);
				this.m_nXFin = this.m_nXDepart - (r * Math.cos(a));
				this.m_nYFin = this.m_nYDepart + (r * Math.sin(a));
			}
		}
		else
		{
			this.m_nZoom = h;
			this.m_nXDepart = this.nInitZoneCoord(this.m_nLargeur, g, f);
			this.m_nYDepart = this.nInitZoneCoord(this.m_nHauteur, g, f);
		}
	};

	__WDAnimSurImage.prototype.InitZone4 = function InitZone4(b)
	{
		var z = __s_nHasardMinMax(0.8, 0.9, true);
		var g = 1 - z;
		var f = 1 / z;
		var h = f - 1;
		if (b)
		{
			this.m_nZoomFin = h;
		}
		else
		{
			this.m_nZoom = h;
		}
		var i = 0;
		var l = g;
		if (b && (this.m_nZoomFin != this.m_nZoom))
		{
			if (this.m_nZoomFin > this.m_nZoom)
			{
				l = Math.min(g, this.m_nXDepart / f / this.m_nLargeur);
			}
			else
			{
				i = Math.min(g * this.m_nLargeur * f, this.m_nXDepart) / f;
			}
		}
		var x = this.nInitZoneCoord(this.m_nLargeur, l, f, i);
		if (b)
		{
			this.m_nXFin = x;
		}
		else
		{
			this.m_nXDepart = x;
		}
		if (b && (this.m_nZoomFin != this.m_nZoom))
		{
			if (this.m_nZoomFin > this.m_nZoom)
			{
				l = Math.min(g, this.m_nYDepart / f / this.m_nHauteur);
			}
			else
			{
				i = Math.min(g * this.m_nHauteur * f, this.m_nYDepart) / f;
			}
		}
		else
		{
			i = 0;
			l = g;
		}
		var y = this.nInitZoneCoord(this.m_nHauteur, l, f, i);
		if (b)
		{
			this.m_nYFin = y;
		}
		else
		{
			this.m_nYDepart = y;
		}
	};

	__WDAnimSurImage.prototype.InitZone = function InitZone(b)
	{
		var z = __s_nHasardMinMax(0.8, 0.9, true);
		var g = 1 - z;
		var f = 1 / z;
		var h = f - 1;
		if (b)
		{
			this.m_nZoomFin = h;
		}
		else
		{
			this.m_nZoom = h;
		}
		var x = this.nInitZoneCoord(this.m_nLargeur, g, f);
		if (b)
		{
			this.m_nXFin = x;
		}
		else
		{
			this.m_nXDepart = x;
		}
		var y = this.nInitZoneCoord(this.m_nHauteur, g, f);
		if (b)
		{
			this.m_nYFin = y;
		}
		else
		{
			this.m_nYDepart = y;
		}
	};

	__WDAnimSurImage.prototype.InitZone5 = function InitZone5(b)
	{
		if (b)
		{
			this.m_nZoomFin = 0.24223918141145928;
			this.m_nXFin = 27.329261991052103;
			this.m_nYFin = 1.2422391814114593;
		}
		else
		{
			this.m_nZoom = 0.23311965686232106;
			this.m_nXDepart = 28.361752107833386;
			this.m_nYDepart = 19.729914509797137;
		}
	};

	// Init Transition
	__WDAnimSurImage.prototype.InitTransition = function InitTransition()
	{
		switch (this.m_nType)
		{
		case ms_nTypeFondu:
			this.SetOpacite(this.m_oBaliseImgTemp, this.m_nOpaciteDebut);
			this.SetOpacite(this.m_oBaliseImg, 0);
			break;
		case ms_nTypeBalayageHaut:
			this.SetY(this.m_oBaliseImgTemp, this.m_nY);
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY + this.m_nHauteur);
			break;
		case ms_nTypeBalayageBas:
			this.SetY(this.m_oBaliseImgTemp, this.m_nY);
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY - this.m_nHauteur);
			break;
		case ms_nTypeRecouvrementHaut:
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY - this.m_nHauteur);
			break;
		case ms_nTypeRecouvrementBas:
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY + this.m_nHauteur);
			break;
		case ms_nTypeBalayageGauche:
			this.SetX(this.m_oBaliseImgTemp, this.m_nX);
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX + this.m_nLargeur);
			break;
		case ms_nTypeBalayageDroite:
			this.SetX(this.m_oBaliseImgTemp, this.m_nX);
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX - this.m_nLargeur);
			break;
		case ms_nTypeRecouvrementGauche:
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX - this.m_nLargeur);
			break;
		case ms_nTypeRecouvrementDroite:
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX + this.m_nLargeur);
			break;
		case ms_nTypeRecouvrement:
			this.SetX(this.m_oDiv, this.m_nX + (this.m_nLargeur / 2));
			this.SetY(this.m_oDiv, this.m_nY + (this.m_nHauteur / 2));
			this.SetLargeur(this.m_oDiv, 0);
			this.SetHauteur(this.m_oDiv, 0);
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX);
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY);
			break;
		case ms_nTypeRecouvrementZoom:
			this.SetLargeur(this.m_oBaliseImgTempFin, 0);
			this.SetHauteur(this.m_oBaliseImgTempFin, 0);
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX + (this.m_nLargeur / 2));
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY + (this.m_nHauteur / 2));
			break;
		case ms_nTypeDecouvrement:
			this.SetX(this.m_oDiv, this.m_nX);
			this.SetY(this.m_oDiv, this.m_nY);
			this.SetLargeur(this.m_oDiv, this.m_nLargeur);
			this.SetHauteur(this.m_oDiv, this.m_nHauteur);
			this.SetX(this.m_oBaliseImgTemp, this.m_nX);
			this.SetY(this.m_oBaliseImgTemp, this.m_nY);
			break;
		case ms_nTypeDecouvrementZoom:
			this.SetX(this.m_oBaliseImgTemp, this.m_nX);
			this.SetY(this.m_oBaliseImgTemp, this.m_nY);
			this.SetLargeur(this.m_oBaliseImgTemp, this.m_nLargeur);
			this.SetHauteur(this.m_oBaliseImgTemp, this.m_nHauteur);
			break;
		case ms_nTypeDecouvrementHautGauche:
		case ms_nTypeDecouvrementHautDroite:
		case ms_nTypeDecouvrementBasGauche:
		case ms_nTypeDecouvrementBasDroite:
			this.SetX(this.m_oBaliseImgTemp, this.m_nX);
			this.SetY(this.m_oBaliseImgTemp, this.m_nY);
			break;
		case ms_nTypeDezoomDeplacement:
			this.SetLargeur(this.m_oBaliseImgTempFin, this.m_nLargeur * (1 + this.m_nZoom));
			this.SetHauteur(this.m_oBaliseImgTempFin, this.m_nHauteur * (1 + this.m_nZoom));
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX - this.m_nXDepart);
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY - this.m_nYDepart);
			break;
		default:
			//Animation de type boite ?
			if (this.bTypeBoite(this.m_nType))
			{
				//Oui => initialisation indice boite trait�e
				var nBoite = 0;
				//Initialisation transition boites
				for (var nLigne = 0; nLigne < this.m_nNbLigne; nLigne++)
				{
					for (var nColonne = 0; nColonne < this.m_nNbColonne; nColonne++)
					{
						//R�cup�ration boite � traiter
						var oBoite = this.m_tabBoite[nBoite];
						//R�cup�ration abscisse boite
						var nXBoite = this.GetX(oBoite);
						//R�cup�ration ordonn�e boite
						var nYBoite = this.GetY(oBoite);
						//Initialisation transition et modifications propri�t�s de la boite en fonction du type d'animation
						switch (this.m_nType)
						{
						case ms_nTypeBoiteFondu:
							this.SetTransition(oBoite, null, -1);
							this.SetOpacite(oBoite, 0);
							break;
						case ms_nTypeBoiteFonduDeplacement:
							this.SetTransition(oBoite, null, -1);
							this.SetOpacite(oBoite, 0);
							this.SetX(oBoite, nXBoite + (this.m_nLargeurBoite * ((__s_nHasardMinMax(0, 1) > 0) ? 1 : -1)));
							this.SetY(oBoite, nYBoite + (this.m_nHauteurBoite * ((__s_nHasardMinMax(0, 1) > 0) ? 1 : -1)));
							break;
						case ms_nTypeBoiteFonduDeplacementHautGauche:
							this.SetTransition(oBoite, null, -1);
							this.SetOpacite(oBoite, 0);
							this.SetX(oBoite, nXBoite - this.m_nLargeurBoite);
							this.SetY(oBoite, nYBoite - this.m_nHauteurBoite);
							break;
						case ms_nTypeBoiteFonduDeplacementHautDroite:
							this.SetTransition(oBoite, null, -1);
							this.SetOpacite(oBoite, 0);
							this.SetX(oBoite, nXBoite + this.m_nLargeurBoite);
							this.SetY(oBoite, nYBoite - this.m_nHauteurBoite);
							break;
						case ms_nTypeBoiteFonduDeplacementBasGauche:
							this.SetTransition(oBoite, null, -1);
							this.SetOpacite(oBoite, 0);
							this.SetX(oBoite, nXBoite - this.m_nLargeurBoite);
							this.SetY(oBoite, nYBoite + this.m_nHauteurBoite);
							break;
						case ms_nTypeBoiteFonduDeplacementBasDroite:
							this.SetTransition(oBoite, null, -1);
							this.SetOpacite(oBoite, 0);
							this.SetX(oBoite, nXBoite + this.m_nLargeurBoite);
							this.SetY(oBoite, nYBoite + this.m_nHauteurBoite);
							break;
						case ms_nTypeBoiteFonduBasDroite:
							this.SetTransition(oBoite, null, (nBoite / this.m_nNbBoite) * this.m_nDuree);
							this.SetOpacite(oBoite, 0);
							break;
						case ms_nTypeBoiteFonduCroiseHorizontal:
							this.SetTransition(oBoite);
							this.SetOpacite(oBoite, 0);
							this.SetX(oBoite, nXBoite + ((((nLigne % 2) == 0) ? 1 : -1) * this.m_nLargeurBoite));
							break;
						case ms_nTypeBoiteFonduCroiseVertical:
							this.SetTransition(oBoite);
							this.SetOpacite(oBoite, 0);
							this.SetY(oBoite, nYBoite + ((((nColonne % 2) == 0) ? 1 : -1) * this.m_nHauteurBoite));
							break;
						case ms_nTypeBoiteFonduHorizontal:
							this.SetTransition(oBoite, null, (nBoite / this.m_nNbBoite) * this.m_nDuree);
							this.SetOpacite(oBoite, 0);
							break;
						case ms_nTypeBoiteFonduVertical:
							this.SetTransition(oBoite, null, (nBoite / this.m_nNbBoite) * this.m_nDuree);
							this.SetOpacite(oBoite, 0);
							break;
						case ms_nTypeBoiteRideauHorizontal:
							this.SetTransition(oBoite);
							this.SetX(oBoite, nXBoite + (((nColonne > 0) ? 1 : -1) * this.m_nLargeurBoite));
							break;
						case ms_nTypeBoiteRideauVertical:
							this.SetTransition(oBoite);
							this.SetY(oBoite, nYBoite + (((nLigne > 0) ? 1 : -1) * this.m_nHauteurBoite));
							break;
						default:
							this.SetTransition(oBoite);
							break;
						}
						//Boite suivante
						nBoite++;
					}
				}
				//Traitement des types d'animation n�cessitant que les modifications de propri�t�s soient diff�r�es dans un timer (sinon l'effet de transition ne marche pas)
				switch (this.m_nType)
				{
				case ms_nTypeBoiteReduction:
				case ms_nTypeBoiteRotation:
					//Initialisation variable objet
					var oThis = this;
					//Modification propri�t�s boites diff�r�e
					setTimeout(function()
					{
						//Modification propri�t�s boites
						for (var nBoite = 0; nBoite < oThis.m_tabBoite.length; nBoite++)
						{
							//R�cup�ration boite � traiter
							var oBoite = oThis.m_tabBoite[nBoite];
							//Modification propri�t�s boite en fonction du type d'animation
							switch (oThis.m_nType)
							{
							case ms_nTypeBoiteReduction:
								oThis.SetLargeur(oBoite, 0);
								oThis.SetHauteur(oBoite, 0);
								break;
							case ms_nTypeBoiteRotation:
								oThis.SetTransform(oBoite, "rotate(360deg)");
								oThis.SetLargeur(oBoite, 0);
								oThis.SetHauteur(oBoite, 0);
								break;
							default:
								break;
							}
						}
					}, 1);
					break;
				default:
					break;
				}
			}
			break;
		}
		this.SetTransition(this.m_oBaliseImg);
		this.SetTransition(this.m_oBaliseImgTemp);
		this.SetTransition(this.m_oBaliseImgTempFin);
		this.SetTransition(this.m_oDiv);
		switch (this.m_nType)
		{
		case ms_nTypeFondu:
			this.SetOpacite(this.m_oBaliseImgTemp, 0);
			this.SetOpacite(this.m_oBaliseImg, this.m_nOpaciteDebut);
			break;
		case ms_nTypeBalayageHaut:
			this.SetY(this.m_oBaliseImgTemp, this.m_nY - this.m_nHauteur);
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY);
			break;
		case ms_nTypeBalayageBas:
			this.SetY(this.m_oBaliseImgTemp, this.m_nY + this.m_nHauteur);
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY);
			break;
		case ms_nTypeRecouvrementHaut:
		case ms_nTypeRecouvrementBas:
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY);
			break;
		case ms_nTypeBalayageGauche:
			this.SetX(this.m_oBaliseImgTemp, this.m_nX - this.m_nLargeur);
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX);
			break;
		case ms_nTypeBalayageDroite:
			this.SetX(this.m_oBaliseImgTemp, this.m_nX + this.m_nLargeur);
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX);
			break;
		case ms_nTypeRecouvrementGauche:
		case ms_nTypeRecouvrementDroite:
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX);
			break;
		case ms_nTypeRecouvrement:
			this.SetX(this.m_oDiv, this.m_nX);
			this.SetY(this.m_oDiv, this.m_nY);
			this.SetLargeur(this.m_oDiv, this.m_nLargeur);
			this.SetHauteur(this.m_oDiv, this.m_nHauteur);
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX + (this.m_nLargeur / 2));
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY + (this.m_nHauteur / 2));
			break;
		case ms_nTypeRecouvrementZoom:
			this.SetLargeur(this.m_oBaliseImgTempFin, this.m_nLargeur);
			this.SetHauteur(this.m_oBaliseImgTempFin, this.m_nHauteur);
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX);
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY);
			break;
		case ms_nTypeDecouvrement:
			this.SetX(this.m_oDiv, this.m_nX + (this.m_nLargeur / 2));
			this.SetY(this.m_oDiv, this.m_nY + (this.m_nHauteur / 2));
			this.SetLargeur(this.m_oDiv, 0);
			this.SetHauteur(this.m_oDiv, 0);
			this.SetX(this.m_oBaliseImgTemp, this.m_nX - (this.m_nLargeur / 2));
			this.SetY(this.m_oBaliseImgTemp, this.m_nY - (this.m_nHauteur / 2));
			break;
		case ms_nTypeDecouvrementZoom:
			this.SetX(this.m_oBaliseImgTemp, this.m_nX + (this.m_nLargeur / 2));
			this.SetY(this.m_oBaliseImgTemp, this.m_nY + (this.m_nHauteur / 2));
			this.SetLargeur(this.m_oBaliseImgTemp, 0);
			this.SetHauteur(this.m_oBaliseImgTemp, 0);
			break;
		case ms_nTypeDecouvrementHautGauche:
			this.SetLargeur(this.m_oDiv, 0);
			this.SetHauteur(this.m_oDiv, 0);
			break;
		case ms_nTypeDecouvrementHautDroite:
			this.SetX(this.m_oDiv, this.m_nX + this.m_nLargeur);
			this.SetX(this.m_oBaliseImgTemp, this.m_nX - this.m_nLargeur);
			this.SetLargeur(this.m_oDiv, 0);
			this.SetHauteur(this.m_oDiv, 0);
			break;
		case ms_nTypeDecouvrementBasGauche:
			this.SetY(this.m_oDiv, this.m_nY + this.m_nHauteur);
			this.SetY(this.m_oBaliseImgTemp, this.m_nY - this.m_nHauteur);
			this.SetLargeur(this.m_oDiv, 0);
			this.SetHauteur(this.m_oDiv, 0);
			break;
		case ms_nTypeDecouvrementBasDroite:
			this.SetX(this.m_oDiv, this.m_nX + this.m_nLargeur);
			this.SetX(this.m_oBaliseImgTemp, this.m_nX - this.m_nLargeur);
			this.SetY(this.m_oDiv, this.m_nY + this.m_nHauteur);
			this.SetY(this.m_oBaliseImgTemp, this.m_nY - this.m_nHauteur);
			this.SetLargeur(this.m_oDiv, 0);
			this.SetHauteur(this.m_oDiv, 0);
			break;
		case ms_nTypeDezoomDeplacement:
			this.SetTransition(this.m_oBaliseImgTempFin, __s_sGetTransition(this.m_oBaliseImgTempFin) + ",opacity " + (this.m_nDuree / 300) + "s");
			this.SetLargeur(this.m_oBaliseImgTempFin, this.m_nLargeur * (1 + this.m_nZoomFin));
			this.SetHauteur(this.m_oBaliseImgTempFin, this.m_nHauteur * (1 + this.m_nZoomFin));
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX - this.m_nXFin);
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY - this.m_nYFin);
			this.SetOpacite(this.m_oBaliseImgTempFin, this.m_nOpaciteDebut);
			break;
		default:
			break;
		}
		var oThis = this;
		this.m_nTimeout = clWDUtil.nSetTimeout(function() { oThis.vFin() }, this.m_nDuree * 10);
	};

	// Les fonctions d'animation

	__WDAnimSurImage.prototype._fGetAnimFonction = function _fGetAnimFonction(nType)
	{
		// Note : on ne fait pas une closure, on manipulera donc la fonction actuelle (et pas la fonction de meme nom au moment de l'appel)
		// mais normalement elles ne changent pas
		switch (nType)
		{
		case ms_nTypeFondu:
			return this._AnimFondu;
		case ms_nTypeBalayageHaut:
			return this._AnimBalayageHaut;
		case ms_nTypeBalayageBas:
			return this._AnimBalayageBas;
		case ms_nTypeRecouvrementHaut:
			return this._AnimRecouvrementHaut;
		case ms_nTypeRecouvrementBas:
			return this._AnimRecouvrementBas;
		case ms_nTypeBalayageGauche:
			return this._AnimBalayageGauche;
		case ms_nTypeBalayageDroite:
			return this._AnimBalayageDroite;
		case ms_nTypeRecouvrementGauche:
			return this._AnimRecouvrementGauche;
		case ms_nTypeRecouvrementDroite:
			return this._AnimRecouvrementDroite;
		case ms_nTypeRecouvrement:
			return this._AnimRecouvrement;
		case ms_nTypeRecouvrementZoom:
			return this._AnimRecouvrementZoom;
		case ms_nTypeDecouvrement:
			return this._AnimDecouvrement;
		case ms_nTypeDecouvrementZoom:
			return this._AnimDecouvrementZoom;
		case ms_nTypeDecouvrementHautGauche:
			return this._AnimDecouvrementHautGauche;
		case ms_nTypeDecouvrementHautDroite:
			return this._AnimDecouvrementHautDroite;
		case ms_nTypeDecouvrementBasGauche:
			return this._AnimDecouvrementBasGauche;
		case ms_nTypeDecouvrementBasDroite:
			return this._AnimDecouvrementBasDroite;
		case ms_nTypeDezoomDroite:
		case ms_nTypeDeplacementHaut:
			return this._AnimDeplacementHaut;
		case ms_nTypeDeplacementBas:
			return this._AnimDeplacementBas;
		case ms_nTypeDeplacementGauche:
			return this._AnimDeplacementGauche;
		case ms_nTypeDeplacementDroite:
			return this._AnimDeplacementDroite;
		case ms_nTypeDeplacementHautGauche:
			return this._AnimDeplacementHautGauche;
		case ms_nTypeDeplacementHautDroite:
			return this._AnimDeplacementHautDroite;
		case ms_nTypeDeplacementBasGauche:
			return this._AnimDeplacementBasGauche;
		case ms_nTypeDeplacementBasDroite:
			return this._AnimDeplacementBasDroite;
		case ms_nTypeDezoomDroite:
			return this._AnimDezoomDroite;
		case ms_nTypeDezoomGauche:
			return this._AnimDezoomGauche;
		case ms_nTypeDezoomBas:
			return this._AnimDezoomBas;
		case ms_nTypeDezoomHaut:
			return this._AnimDezoomHaut;
		case ms_nTypeDezoomBasDroite:
			return this._AnimDezoomBasDroite;
		case ms_nTypeDezoomHautGauche:
			return this._AnimDezoomHautGauche;
		case ms_nTypeDezoomBasGauche:
			return this._AnimDezoomBasGauche;
		case ms_nTypeDezoomHautDroite:
			return this._AnimDezoomHautDroite;
		case ms_nTypeDezoomCentre:
			return this._AnimDezoomCentre;
		case ms_nTypeDeplacementDezoomGauche:
			return this._AnimDeplacementDezoomGauche;
		case ms_nTypeDeplacementDezoomDroite:
			return this._AnimDeplacementDezoomDroite;
		case ms_nTypeDeplacementDezoomHaut:
			return this._AnimDeplacementDezoomHaut;
		case ms_nTypeDeplacementDezoomBas:
			return this._AnimDeplacementDezoomBas;
		case ms_nTypeDeplacementDezoomHautGauche:
			return this._AnimDeplacementDezoomHautGauche;
		case ms_nTypeDeplacementDezoomHautDroite:
			return this._AnimDeplacementDezoomHautDroite;
		case ms_nTypeDeplacementDezoomBasGauche:
			return this._AnimDeplacementDezoomBasGauche;
		case ms_nTypeDeplacementDezoomBasDroite:
			return this._AnimDeplacementDezoomBasDroite;
		case ms_nTypeDezoomPanoramique:
			return this._AnimDezoomPanoramique;
		case ms_nTypeDezoomDeplacement:
			return this._AnimDezoomDeplacement;
		default:
			//Animation de type boite ?
			if (this.bTypeBoite(nType))
			{
				//Oui => on utilisera la fonction d'animation de type boite
				return this.__AnimBoite;
			}
			return undefined;
		}
	};

	__WDAnimSurImage.prototype._AnimFondu = function _AnimFondu(nAvancement)
	{
		this.SetOpacite(this.m_oBaliseImg, __s_nAvancement(nAvancement, this.m_nOpaciteDebut));
		this.SetOpacite(this.m_oBaliseImgTemp, __s_nAvancementInverse(nAvancement, this.m_nOpaciteDebut));
	};

	__WDAnimSurImage.prototype._AnimBalayageHaut = function _AnimBalayageHaut(nAvancement)
	{
		this.__AnimBalayageVertical(nAvancement, false);
	};

	__WDAnimSurImage.prototype._AnimBalayageBas = function _AnimBalayageBas(nAvancement)
	{
		this.__AnimBalayageVertical(nAvancement, true);
	};

	__WDAnimSurImage.prototype.__AnimBalayageVertical = function __AnimBalayageVertical(nAvancement, bBas)
	{
		this.SetY(this.m_oBaliseImgTemp, this.m_nY + __s_nAvancement(nAvancement, this.m_nHauteur) * (bBas ? 1 : -1));
		this.__AnimRecouvrementVertical(nAvancement, !bBas);
	};

	__WDAnimSurImage.prototype._AnimRecouvrementHaut = function _AnimRecouvrementHaut(nAvancement)
	{
		this.__AnimRecouvrementVertical(nAvancement, false);
	};

	__WDAnimSurImage.prototype._AnimRecouvrementBas = function _AnimRecouvrementBas(nAvancement)
	{
		this.__AnimRecouvrementVertical(nAvancement, true);
	};

	__WDAnimSurImage.prototype.__AnimRecouvrementVertical = function __AnimRecouvrementVertical(nAvancement, bBas)
	{
		this.SetY(this.m_oBaliseImgTempFin, this.m_nY + __s_nAvancementInverse(nAvancement, this.m_nHauteur) * (bBas ? 1 : -1));
	};

	__WDAnimSurImage.prototype._AnimBalayageGauche = function _AnimBalayageGauche(nAvancement)
	{
		this.__AnimBalayageHorizontal(nAvancement, false);
	};

	__WDAnimSurImage.prototype._AnimBalayageDroite = function _AnimBalayageDroite(nAvancement)
	{
		this.__AnimBalayageHorizontal(nAvancement, true);
	};

	__WDAnimSurImage.prototype.__AnimBalayageHorizontal = function __AnimBalayageHorizontal(nAvancement, bDroite)
	{
		this.SetX(this.m_oBaliseImgTemp, this.m_nX + __s_nAvancement(nAvancement, this.m_nLargeur) * (bDroite ? 1 : -1));
		this.__AnimRecouvrementHorizontal(nAvancement, !bDroite);
	};

	__WDAnimSurImage.prototype._AnimRecouvrementGauche = function _AnimRecouvrementGauche(nAvancement)
	{
		this.__AnimRecouvrementHorizontal(nAvancement, false);
	};

	__WDAnimSurImage.prototype._AnimRecouvrementDroite = function _AnimRecouvrementDroite(nAvancement)
	{
		this.__AnimRecouvrementHorizontal(nAvancement, true);
	};

	__WDAnimSurImage.prototype.__AnimRecouvrementHorizontal = function __AnimRecouvrementHorizontal(nAvancement, bDroite)
	{
		this.SetX(this.m_oBaliseImgTempFin, this.m_nX + __s_nAvancementInverse(nAvancement, this.m_nLargeur) * (bDroite ? 1 : -1));
	};

	__WDAnimSurImage.prototype._AnimRecouvrement = function _AnimRecouvrement(nAvancement)
	{
		this.__AnimXXcouvrementInterne(__s_nAvancementInverseVal(nAvancement), this.m_oDiv);
		this.SetX(this.m_oBaliseImgTempFin, this.m_nX);
		this.SetY(this.m_oBaliseImgTempFin, this.m_nY);
	};

	__WDAnimSurImage.prototype._AnimRecouvrementZoom = function _AnimRecouvrementZoom(nAvancement)
	{
		this.__AnimXXcouvrementInterne(__s_nAvancementInverseVal(nAvancement), this.m_oBaliseImgTempFin);
	};

	__WDAnimSurImage.prototype._AnimDecouvrement = function _AnimDecouvrement(nAvancement)
	{
		this.__AnimXXcouvrementInterne(nAvancement, this.m_oDiv);
		this.SetX(this.m_oBaliseImgTemp, this.m_nX);
		this.SetY(this.m_oBaliseImgTemp, this.m_nY);
	};

	__WDAnimSurImage.prototype._AnimDecouvrementZoom = function _AnimDecouvrementZoom(nAvancement)
	{
		this.__AnimXXcouvrementInterne(nAvancement, this.m_oBaliseImgTemp);
	};

	__WDAnimSurImage.prototype._AnimDecouvrementHautGauche = function _AnimDecouvrementHautGauche(nAvancement)
	{
		this.SetLargeur(this.m_oDiv, __s_nAvancementInverse(nAvancement, this.m_nLargeur));
		this.SetHauteur(this.m_oDiv, __s_nAvancementInverse(nAvancement, this.m_nHauteur));
		this.SetX(this.m_oBaliseImgTemp, this.m_nX);
		this.SetY(this.m_oBaliseImgTemp, this.m_nY);
	};

	__WDAnimSurImage.prototype._AnimDecouvrementHautDroite = function _AnimDecouvrementHautDroite(nAvancement)
	{
		this.SetX(this.m_oDiv, this.m_nX + __s_nAvancement(nAvancement, this.m_nLargeur));
		this.SetLargeur(this.m_oDiv, __s_nAvancementInverse(nAvancement, this.m_nLargeur));
		this.SetHauteur(this.m_oDiv, __s_nAvancementInverse(nAvancement, this.m_nHauteur));
		this.SetX(this.m_oBaliseImgTemp, this.m_nX);
		this.SetY(this.m_oBaliseImgTemp, this.m_nY);
	};

	__WDAnimSurImage.prototype._AnimDecouvrementBasGauche = function _AnimDecouvrementBasGauche(nAvancement)
	{
		this.SetY(this.m_oDiv, this.m_nY + __s_nAvancement(nAvancement, this.m_nHauteur));
		this.SetLargeur(this.m_oDiv, __s_nAvancementInverse(nAvancement, this.m_nLargeur));
		this.SetHauteur(this.m_oDiv, __s_nAvancementInverse(nAvancement, this.m_nHauteur));
		this.SetX(this.m_oBaliseImgTemp, this.m_nX);
		this.SetY(this.m_oBaliseImgTemp, this.m_nY);
	};

	__WDAnimSurImage.prototype._AnimDecouvrementBasDroite = function _AnimDecouvrementBasDroite(nAvancement)
	{
		this.SetX(this.m_oDiv, this.m_nX + __s_nAvancement(nAvancement, this.m_nLargeur));
		this.SetY(this.m_oDiv, this.m_nY + __s_nAvancement(nAvancement, this.m_nHauteur));
		this.SetLargeur(this.m_oDiv, __s_nAvancementInverse(nAvancement, this.m_nLargeur));
		this.SetHauteur(this.m_oDiv, __s_nAvancementInverse(nAvancement, this.m_nHauteur));
		this.SetX(this.m_oBaliseImgTemp, this.m_nX);
		this.SetY(this.m_oBaliseImgTemp, this.m_nY);
	};

	__WDAnimSurImage.prototype._AnimDeplacementOpacite = function _AnimDeplacementOpacite(nAvancement)
	{
		this.SetOpacite(this.m_oBaliseImgTempFin, __s_nAvancement(Math.min(3 * nAvancement, ms_nAvancementMax), this.m_nOpaciteDebut));
	};

	__WDAnimSurImage.prototype._AnimDeplacementHaut = function _AnimDeplacementHaut(nAvancement)
	{
		this._AnimDeplacementOpacite(nAvancement);
		if (this.m_nHauteur > this.m_nHauteurVisible)
		{
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY - __s_nAvancementInverse(nAvancement, this.m_nHauteur - this.m_nHauteurVisible));
		}
	};

	__WDAnimSurImage.prototype._AnimDeplacementBas = function _AnimDeplacementBas(nAvancement)
	{
		this._AnimDeplacementOpacite(nAvancement);
		if (this.m_nHauteur > this.m_nHauteurVisible)
		{
			this.SetY(this.m_oBaliseImgTempFin, this.m_nY - __s_nAvancement(nAvancement, this.m_nHauteur - this.m_nHauteurVisible));
		}
	};

	__WDAnimSurImage.prototype._AnimDeplacementGaucheX = function _AnimDeplacementGaucheX(nAvancement)
	{
		if (this.m_nLargeur > this.m_nLargeurVisible)
		{
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX - __s_nAvancementInverse(nAvancement, this.m_nLargeur - this.m_nLargeurVisible));
		}
	};

	__WDAnimSurImage.prototype._AnimDeplacementGauche = function _AnimDeplacementGauche(nAvancement)
	{
		this._AnimDeplacementOpacite(nAvancement);
		this._AnimDeplacementGaucheX(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDroiteX = function _AnimDeplacementDroiteX(nAvancement)
	{
		if (this.m_nLargeur > this.m_nLargeurVisible)
		{
			this.SetX(this.m_oBaliseImgTempFin, this.m_nX - __s_nAvancement(nAvancement, this.m_nLargeur - this.m_nLargeurVisible));
		}
	};

	__WDAnimSurImage.prototype._AnimDeplacementDroite = function _AnimDeplacementDroite(nAvancement)
	{
		this._AnimDeplacementOpacite(nAvancement);
		this._AnimDeplacementDroiteX(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementHautGauche = function _AnimDeplacementHautGauche(nAvancement)
	{
		this._AnimDeplacementHaut(nAvancement);
		this._AnimDeplacementGaucheX(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementHautDroite = function _AnimDeplacementHautDroite(nAvancement)
	{
		this._AnimDeplacementHaut(nAvancement);
		this._AnimDeplacementDroiteX(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementBasGauche = function _AnimDeplacementBasGauche(nAvancement)
	{
		this._AnimDeplacementBas(nAvancement);
		this._AnimDeplacementGaucheX(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementBasDroite = function _AnimDeplacementBasDroite(nAvancement)
	{
		this._AnimDeplacementBas(nAvancement);
		this._AnimDeplacementDroiteX(nAvancement);
	};

	__WDAnimSurImage.prototype._nAnimDezoomDimension = function _nAnimDezoomDimension(nAvancement, nDimension)
	{
		return __s_nAvancementInverse(nAvancement, nDimension * ms_nZoom);
	};

	__WDAnimSurImage.prototype._nAnimDezoomLargeur = function _nAnimDezoomLargeur(nAvancement)
	{
		return this._nAnimDezoomDimension(nAvancement, this.m_nLargeur);
	};

	__WDAnimSurImage.prototype._nAnimDezoomHauteur = function _nAnimDezoomHauteur(nAvancement)
	{
		return this._nAnimDezoomDimension(nAvancement, this.m_nHauteur);
	};

	__WDAnimSurImage.prototype._AnimDezoomBasDroite = function _AnimDezoomBasDroite(nAvancement)
	{
		this._AnimDeplacementOpacite(nAvancement);
		this.SetLargeur(this.m_oBaliseImgTempFin, this.m_nLargeur + this._nAnimDezoomLargeur(nAvancement));
		this.SetHauteur(this.m_oBaliseImgTempFin, this.m_nHauteur + this._nAnimDezoomHauteur(nAvancement));
	};

	__WDAnimSurImage.prototype._AnimDezoomGaucheX = function _AnimDezoomGaucheX(nAvancement)
	{
		this.SetX(this.m_oBaliseImgTempFin, this.m_nX - this._nAnimDezoomLargeur(nAvancement));
	};

	__WDAnimSurImage.prototype._AnimDezoomVertical = function _AnimDezoomVertical(nAvancement)
	{
		this.SetY(this.m_oBaliseImgTempFin, this.m_nY - (this._nAnimDezoomHauteur(nAvancement) / 2));
	};

	__WDAnimSurImage.prototype._AnimDezoomGauche = function _AnimDezoomGauche(nAvancement)
	{
		this._AnimDezoomGaucheX(nAvancement);
		this._AnimDezoomVertical(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDezoomDroite = function _AnimDezoomDroite(nAvancement)
	{
		this._AnimDezoomVertical(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDezoomHautY = function _AnimDezoomHautY(nAvancement)
	{
		this.SetY(this.m_oBaliseImgTempFin, this.m_nY - this._nAnimDezoomHauteur(nAvancement));
	};

	__WDAnimSurImage.prototype._AnimDezoomHorizontal = function _AnimDezoomHorizontal(nAvancement)
	{
		this.SetX(this.m_oBaliseImgTempFin, this.m_nX - (this._nAnimDezoomLargeur(nAvancement) / 2));
	};

	__WDAnimSurImage.prototype._AnimDezoomHaut = function _AnimDezoomHaut(nAvancement)
	{
		this._AnimDezoomHorizontal(nAvancement);
		this._AnimDezoomHautY(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDezoomBas = function _AnimDezoomBas(nAvancement)
	{
		this._AnimDezoomHorizontal(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDezoomHautGauche = function _AnimDezoomHautGauche(nAvancement)
	{
		this._AnimDezoomGaucheX(nAvancement);
		this._AnimDezoomHautY(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDezoomBasGauche = function _AnimDezoomBasGauche(nAvancement)
	{
		this._AnimDezoomGaucheX(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDezoomHautDroite = function _AnimDezoomHautDroite(nAvancement)
	{
		this._AnimDezoomHautY(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDezoomCentre = function _AnimDezoomCentre(nAvancement)
	{
		this._AnimDezoomHorizontal(nAvancement);
		this._AnimDezoomVertical(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomY = function _AnimDeplacementDezoomY(nAvancement)
	{
		this.SetY(this.m_oBaliseImgTempFin, this.m_nY - __s_nAvancementInverse(nAvancement, this.m_nHauteur * ms_nZoom / 2));
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomX = function _AnimDeplacementDezoomX(nAvancement)
	{
		this.SetX(this.m_oBaliseImgTempFin, this.m_nX - __s_nAvancementInverse(nAvancement, this.m_nLargeur * ms_nZoom / 2));
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._nAnimDeplacementDezoomAngle = function _nAnimDeplacementDezoomAngle(nAvancement)
	{
		return (Math.PI / 2) * (nAvancement / ms_nAvancementMax);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomGaucheX = function _AnimDeplacementDezoomGaucheX(nAvancement)
	{
		this.SetX(this.m_oBaliseImgTempFin, this.m_nX - (this._nAnimDezoomLargeur(nAvancement) * Math.sin(this._nAnimDeplacementDezoomAngle(nAvancement))));
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomGauche = function _AnimDeplacementDezoomGauche(nAvancement)
	{
		this._AnimDeplacementDezoomGaucheX(nAvancement);
		this._AnimDeplacementDezoomY(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomDroiteX = function _AnimDeplacementDezoomDroiteX(nAvancement)
	{
		this.SetX(this.m_oBaliseImgTempFin, this.m_nX - (this._nAnimDezoomLargeur(nAvancement) * Math.cos(this._nAnimDeplacementDezoomAngle(nAvancement))));
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomDroite = function _AnimDeplacementDezoomDroite(nAvancement)
	{
		this._AnimDeplacementDezoomDroiteX(nAvancement);
		this._AnimDeplacementDezoomY(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomHautY = function _AnimDeplacementDezoomHautY(nAvancement)
	{
		this.SetY(this.m_oBaliseImgTempFin, this.m_nY - (this._nAnimDezoomHauteur(nAvancement) * Math.sin(this._nAnimDeplacementDezoomAngle(nAvancement))));
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomHaut = function _AnimDeplacementDezoomHaut(nAvancement)
	{
		this._AnimDeplacementDezoomX(nAvancement);
		this._AnimDeplacementDezoomHautY(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomBasY = function _AnimDeplacementDezoomBasY(nAvancement)
	{
		this.SetY(this.m_oBaliseImgTempFin, this.m_nY - (this._nAnimDezoomHauteur(nAvancement) * Math.cos(this._nAnimDeplacementDezoomAngle(nAvancement))));
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomBas = function _AnimDeplacementDezoomBas(nAvancement)
	{
		this._AnimDeplacementDezoomX(nAvancement);
		this._AnimDeplacementDezoomBasY(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomHautGauche = function _AnimDeplacementDezoomHautGauche(nAvancement)
	{
		this._AnimDeplacementDezoomGaucheX(nAvancement);
		this._AnimDeplacementDezoomHautY(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomHautDroite = function _AnimDeplacementDezoomHautDroite(nAvancement)
	{
		this._AnimDeplacementDezoomDroiteX(nAvancement);
		this._AnimDeplacementDezoomHautY(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomBasGauche = function _AnimDeplacementDezoomBasGauche(nAvancement)
	{
		this._AnimDeplacementDezoomGaucheX(nAvancement);
		this._AnimDeplacementDezoomBasY(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype._AnimDeplacementDezoomBasDroite = function _AnimDeplacementDezoomBasDroite(nAvancement)
	{
		this._AnimDeplacementDezoomDroiteX(nAvancement);
		this._AnimDeplacementDezoomBasY(nAvancement);
		this._AnimDezoomBasDroite(nAvancement);
	};

	__WDAnimSurImage.prototype.nAnimDezoomPanoramiqueCoord = function nAnimDezoomPanoramiqueCoord(nAvancement, c, d)
	{
		return c - __s_nAvancementInverse(nAvancement, d);
	};

	__WDAnimSurImage.prototype.nAnimDezoomPanoramiqueDimension = function nAnimDezoomPanoramiqueDimension(nAvancement, d)
	{
		return d + __s_nAvancementInverse(nAvancement, d * this.m_nZoom);
	};

	__WDAnimSurImage.prototype._AnimDezoomPanoramique = function _AnimDezoomPanoramique(nAvancement)
	{
		this.SetX(this.m_oBaliseImgTempFin, this.nAnimDezoomPanoramiqueCoord(nAvancement, this.m_nX, this.m_nXDepart));
		this.SetY(this.m_oBaliseImgTempFin, this.nAnimDezoomPanoramiqueCoord(nAvancement, this.m_nY, this.m_nYDepart));
		this.SetLargeur(this.m_oBaliseImgTempFin, this.nAnimDezoomPanoramiqueDimension(nAvancement, this.m_nLargeur));
		this.SetHauteur(this.m_oBaliseImgTempFin, this.nAnimDezoomPanoramiqueDimension(nAvancement, this.m_nHauteur));
	};

	__WDAnimSurImage.prototype.nAnimDezoomDeplacementCoord = function nAnimDezoomDeplacementCoord(nAvancement, c, d, f)
	{
		return c - f - __s_nAvancementInverse(nAvancement, d - f);
	};

	__WDAnimSurImage.prototype.nAnimDezoomDeplacementDimension = function nAnimDezoomDeplacementDimension(nAvancement, d)
	{
		return (d * (1 + this.m_nZoomFin)) + __s_nAvancementInverse(nAvancement, d * (this.m_nZoom - this.m_nZoomFin));
	};

	__WDAnimSurImage.prototype._AnimDezoomDeplacement = function _AnimDezoomDeplacement(nAvancement)
	{
		if (this.m_bPremierAffichage)
		{
			this.SetOpacite(this.m_oBaliseImgTempFin, this.m_nOpaciteDebut);
			this.SetOpacite(this.m_oBaliseImg, this.m_nOpaciteDebut);
		}
		else
		{
			this._AnimDeplacementOpacite(nAvancement);
		}
		var x = this.nAnimDezoomDeplacementCoord(nAvancement, this.m_nX, this.m_nXDepart, this.m_nXFin);
		var y = this.nAnimDezoomDeplacementCoord(nAvancement, this.m_nY, this.m_nYDepart, this.m_nYFin);
		var l = this.nAnimDezoomDeplacementDimension(nAvancement, this.m_nLargeur);
		var h = this.nAnimDezoomDeplacementDimension(nAvancement, this.m_nHauteur);
		if (this.m_oDC || (!bIEQuirks9Max))
		{
			this.SetX(this.m_oBaliseImgTempFin, x);
			this.SetY(this.m_oBaliseImgTempFin, y);
			this.SetLargeur(this.m_oBaliseImgTempFin, l);
			this.SetHauteur(this.m_oBaliseImgTempFin, h);
			if (this.m_oDC)
			{
				this.SetOpacite(this.m_oCanva, __s_nAvancement(Math.min(3 * nAvancement, ms_nAvancementMax), this.m_nOpaciteDebut));
				try { this.m_oDC.drawImage(this.m_oBaliseImgTempFin, x - this.m_nX, y - this.m_nY, l, h/*,this.m_nLargeur,this.m_nHauteur,0,0,this.m_nLargeur,this.m_nHauteur*/); } catch (e) { };
			}
		}
		else
		{
			this.m_oBaliseImgTempFin.style.filter = "progid:DXImageTransform.Microsoft.Alpha(Opacity=" + this.GetOpacite(this.m_oBaliseImgTempFin) + ') progid:DXImageTransform.Microsoft.Matrix(FilterType="bilinear",M11=' + (l / this.m_nLargeur) + ",M12=0,M21=0,M22=" + (h / this.m_nHauteur) + ",Dx=" + (x - this.m_nX) + ",Dy=" + (y - this.m_nY) + ")";
			//this.m_oBaliseImgTempFin.style.zIndex=1000;
			//SetVisible(this.m_oBaliseImgTempFin,true);
			//this.SetLargeur(this.m_oBaliseImgTempFin,this.GetLargeur(this.m_oBaliseImgTempFin));
		}
	};

	// Code interne pour le Recouvrement/Decouvrement
	// Donner Max-Avancement pour le recouvrement
	__WDAnimSurImage.prototype.__AnimXXcouvrementInterne = function __AnimXXcouvrementInterne(nAvancement, oCible)
	{
		this.SetX(oCible, this.m_nX + __s_nAvancement(nAvancement, this.m_nLargeur) / 2);
		this.SetY(oCible, this.m_nY + __s_nAvancement(nAvancement, this.m_nHauteur) / 2);
		this.SetLargeur(oCible, __s_nAvancementInverse(nAvancement, this.m_nLargeur));
		this.SetHauteur(oCible, __s_nAvancementInverse(nAvancement, this.m_nHauteur));
	};

	//Animation de type boite
	//Entr�e :	nAvancement	Avancement de l'animation
	__WDAnimSurImage.prototype.__AnimBoite = function __AnimBoite(nAvancement)
	{
		//Indice boite trait�e
		var nBoite = 0;
		//Modification des propri�t�s des boites
		for (var nLigne = 0; nLigne < this.m_nNbLigne; nLigne++)
		{
			for (var nColonne = 0; nColonne < this.m_nNbColonne; nColonne++)
			{
				//R�cup�ration boite � traiter
				var oBoite = this.m_tabBoite[nBoite];
				//R�cup�ration parent boite
				var oParentBoite = oBoite.parentNode;
				//R�cup�ration abscisse de d�part de la boite
				var nXBoite = this.GetX(oParentBoite) + (nColonne * this.m_nLargeurBoite);
				//R�cup�ration ordonn�e de d�part de la boite
				var nYBoite = this.GetY(oParentBoite) + (nLigne * this.m_nHauteurBoite);
				//Modification propri�t�s boite selon type animation
				switch (this.m_nType)
				{
				case ms_nTypeBoiteFondu:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (1 + (nBoite % 2)), this.m_nOpaciteDebut));
					break;
				case ms_nTypeBoiteFonduDeplacement:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (1 + (nBoite % 2)), this.m_nOpaciteDebut));
					this.SetX(oBoite, nXBoite + ((((nBoite % 4) > 1) ? 1 : -1) * __s_nAvancement(nAvancement, this.m_nLargeurBoite)));
					this.SetY(oBoite, nYBoite + ((((nBoite % 2) > 0) ? 1 : -1) * __s_nAvancement(nAvancement, this.m_nHauteurBoite)));
					break;
				case ms_nTypeBoiteFonduDeplacementHautGauche:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (1 + (nBoite % 2)), this.m_nOpaciteDebut));
					this.SetX(oBoite, nXBoite - __s_nAvancement(nAvancement, this.m_nLargeurBoite));
					this.SetY(oBoite, nYBoite - __s_nAvancement(nAvancement, this.m_nHauteurBoite));
					break;
				case ms_nTypeBoiteFonduDeplacementHautDroite:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (1 + (nBoite % 2)), this.m_nOpaciteDebut));
					this.SetX(oBoite, nXBoite + __s_nAvancement(nAvancement, this.m_nLargeurBoite));
					this.SetY(oBoite, nYBoite - __s_nAvancement(nAvancement, this.m_nHauteurBoite));
					break;
				case ms_nTypeBoiteFonduDeplacementBasGauche:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (1 + (nBoite % 2)), this.m_nOpaciteDebut));
					this.SetX(oBoite, nXBoite - __s_nAvancement(nAvancement, this.m_nLargeurBoite));
					this.SetY(oBoite, nYBoite + __s_nAvancement(nAvancement, this.m_nHauteurBoite));
					break;
				case ms_nTypeBoiteFonduDeplacementBasDroite:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (1 + (nBoite % 2)), this.m_nOpaciteDebut));
					this.SetX(oBoite, nXBoite + __s_nAvancement(nAvancement, this.m_nLargeurBoite));
					this.SetY(oBoite, nYBoite + __s_nAvancement(nAvancement, this.m_nHauteurBoite));
					break;
				case ms_nTypeBoiteFonduBasDroite:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (nBoite / this.m_nNbBoite), this.m_nOpaciteDebut));
					break;
				case ms_nTypeBoiteFonduCroiseHorizontal:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement, this.m_nOpaciteDebut));
					this.SetX(oBoite, nXBoite + __s_nAvancement(nAvancement, ((((nLigne % 2) == 0) ? 1 : -1) * this.m_nLargeurBoite)));
					break;
				case ms_nTypeBoiteFonduCroiseVertical:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement, this.m_nOpaciteDebut));
					this.SetY(oBoite, nYBoite + __s_nAvancement(nAvancement, ((((nColonne % 2) == 0) ? 1 : -1) * this.m_nHauteurBoite)));
					break;
				case ms_nTypeBoiteFonduHorizontal:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (nLigne / this.m_nNbLigne), this.m_nOpaciteDebut));
					break;
				case ms_nTypeBoiteFonduVertical:
					this.SetOpacite(oBoite, __s_nAvancementInverse(nAvancement * (nColonne / this.m_nNbColonne), this.m_nOpaciteDebut));
					break;
				case ms_nTypeBoiteReduction:
					this.SetLargeur(oBoite, __s_nAvancementInverse(nAvancement, this.m_nLargeurBoite));
					this.SetHauteur(oBoite, __s_nAvancementInverse(nAvancement, this.m_nHauteurBoite));
					break;
				case ms_nTypeBoiteRotation:
					this.SetLargeur(oBoite, __s_nAvancementInverse(nAvancement, this.m_nLargeurBoite));
					this.SetHauteur(oBoite, __s_nAvancementInverse(nAvancement, this.m_nHauteurBoite));
					break;
				case ms_nTypeBoiteRideauHorizontal:
					this.SetX(oBoite, nXBoite + __s_nAvancement(nAvancement, (((nColonne > 0) ? 1 : -1) * this.m_nLargeurBoite)));
					break;
				case ms_nTypeBoiteRideauVertical:
					this.SetY(oBoite, nYBoite + __s_nAvancement(nAvancement, (((nLigne > 0) ? 1 : -1) * this.m_nHauteurBoite)));
					break;
				default:
					break;
				}
				//Boite suivante
				nBoite++;
			}
		}
	};

	function __s_nAvancement(nAvancement, nValeur)
	{
		return (nValeur * nAvancement / ms_nAvancementMax);
	};

	function __s_nAvancementInverse(nAvancement, nValeur)
	{
		return __s_nAvancement(__s_nAvancementInverseVal(nAvancement), nValeur);
	};

	function __s_nAvancementInverseVal(nAvancement)
	{
		return (ms_nAvancementMax - nAvancement);
	};

	// Les fonctions de manipulation des proprietes

	// Opacite
	__WDAnimSurImage.prototype.GetOpacite = function GetOpacite(oBaliseImg)
	{
		return clWDUtil.nGetOpacite(oBaliseImg.style.opacity, oBaliseImg);
	};
	__WDAnimSurImage.prototype.SetOpacite = function SetOpacite(oBaliseImg, nVal)
	{
		// GP 12/11/2012 : En fait il n'y a pas besoin d'affecter la valeur dans le style.opacity c'est fait par la fonction en interne
//		oBaliseImg.style.opacity = clWDUtil.nSetOpacite(nVal, oBaliseImg);
		clWDUtil.nSetOpacite(nVal, oBaliseImg)
	};

	// X
	__WDAnimSurImage.prototype.GetX = function GetX(oBaliseImg)
	{
		return clWDUtil.nGetBoundingClientRectLeft(oBaliseImg, false, true);
	};
	__WDAnimSurImage.prototype.SetX = function SetX(oBaliseImg, nVal)
	{
		var nOffsetBordure = clWDUtil.nGetBordurePage();
		var oOffsetParent = oBaliseImg.offsetParent;
		var bParentEstBody = (oOffsetParent == oBaliseImg.ownerDocument.body);
		var nBoundingClientRectLeft = clWDUtil.nGetBoundingClientRectLeft(oOffsetParent, bParentEstBody, true) + nOffsetBordure;
		nVal -= nBoundingClientRectLeft;
		clWDUtil.SetStyleLeft(oBaliseImg.style, nVal, 0);
	};

	// Y
	__WDAnimSurImage.prototype.GetY = function GetY(oBaliseImg)
	{
		return clWDUtil.nGetBoundingClientRectTop(oBaliseImg, false, true);
	};
	__WDAnimSurImage.prototype.SetY = function SetY(oBaliseImg, nVal)
	{
		var nOffsetBordure = clWDUtil.nGetBordurePage();
		var oOffsetParent = oBaliseImg.offsetParent;
		var bParentEstBody = (oOffsetParent == oBaliseImg.ownerDocument.body);
		var nBoundingClientRectTop = clWDUtil.nGetBoundingClientRectTop(oOffsetParent, bParentEstBody, true) + nOffsetBordure;
		nVal -= nBoundingClientRectTop;
		oBaliseImg.style.top = nVal + "px";
	};

	// Largeur
	__WDAnimSurImage.prototype.GetLargeur = function GetLargeur(oBaliseImg)
	{
		return oBaliseImg.offsetWidth;
	};
	__WDAnimSurImage.prototype.SetLargeur = function SetLargeur(oBaliseImg, nVal)
	{
		oBaliseImg.style.width = nVal + "px";
	};

	// Hauteur
	__WDAnimSurImage.prototype.GetHauteur = function GetHauteur(oBaliseImg)
	{
		return oBaliseImg.offsetHeight;
	};

	__WDAnimSurImage.prototype.SetHauteur = function SetHauteur(oBaliseImg, nVal)
	{
		oBaliseImg.style.height = nVal + "px";
	};

	// Visibilite
	__WDAnimSurImage.prototype.GetVisibilite = function GetVisibilite(oBaliseImg)
	{
		return oBaliseImg.style.visibility;
	};
	__WDAnimSurImage.prototype.SetVisibilite = function SetVisibilite(oBaliseImg, sVal)
	{
		oBaliseImg.style.visibility = sVal;
	};

	// Superposable
	__WDAnimSurImage.prototype.SetSuperposable = function SetSuperposable(oBalise)
	{
		oBalise.style.position = "absolute";
	};

	// Transition
	function __s_sGetTransition (oBalise)
	{
		// Balise OK ?
		if (oBalise)
		{
			//R�cup�ration style
			var oStyle = oBalise.style;
			// Style OK ?
			if (oStyle)
			{
				// R�cup�ration transition
				return oStyle.transition || oStyle.msTransition || oStyle.webkitTransition || oStyle.mozTransition || oStyle.oTransition || null;
			}
		}
		// Cas d'erreur : pas de transition
		return null;
	};

	// Transition
	__WDAnimSurImage.prototype.SetTransition = function SetTransition(clObj, sTransition, nDelai)
	{
		//R�cup�ration transition
		var clTransition = __s_sGetTransition(clObj);
		//Transition OK ?
		if (clTransition == null)
		{
			//Non => rien � faire
			return;
		}
		//R�cup�ration style objet
		var clStyle = clObj.style;
		//Transition fournie ?
		if (sTransition == null)
		{
			//Non => calcul dur�e
			var fDuree = this.m_nDuree / 100;
			//D�lai avant d�but transition
			var fDelai = 0;
			//D�lai au hasard ?
			if (nDelai < 0)
			{
				//Oui => calcul d�lai
				fDelai = __s_nHasardMinMax(0, fDuree, true);
			}
			//Non => d�lai fix� ?
			else if (nDelai > 0)
			{
				//Oui => calcul d�lai
				fDelai = nDelai / 100;
			}
			//On enl�ve le d�lai � la dur�e de transition pour garder la m�me dur�e totale d'animation
			fDuree -= fDelai;
			//Dur�e transition
			var sParamTransition = " " + fDuree + "s ";
			//Fonction vitesse transition
			switch (this.m_nCourbe)
			{
			case this.ms_nCourbeLineaire:
				sParamTransition += "linear";
				break;
			case this.ms_nCourbeEase:
				sParamTransition += "ease";
				break;
			case this.ms_nCourbeAccelere:
				sParamTransition += "ease-in";
				break;
			default:
			case this.ms_nCourbeDecelere:
				sParamTransition += "ease-out";
				break;
			case this.ms_nCourbeEaseInOut:
				sParamTransition += "ease-in-out";
				break;
			}
			//D�lai ?
			if (fDelai > 0)
			{
				//Oui => initialisation d�lai
				sParamTransition += " " + fDelai + "s";
			}
			//Propri�t� transition
			switch (this.m_nType)
			{
			case ms_nTypeFondu:
			case ms_nTypeBoiteFondu:
			case ms_nTypeBoiteFonduBasDroite:
			case ms_nTypeBoiteFonduHorizontal:
			case ms_nTypeBoiteFonduVertical:
				sTransition = "opacity";
				break;
			case ms_nTypeBoiteFonduDeplacement:
			case ms_nTypeBoiteFonduDeplacementHautGauche:
			case ms_nTypeBoiteFonduDeplacementHautDroite:
			case ms_nTypeBoiteFonduDeplacementBasGauche:
			case ms_nTypeBoiteFonduDeplacementBasDroite:
				sTransition = "opacity" + sParamTransition + ",left" + sParamTransition + ",top";
				break;
			case ms_nTypeBoiteFonduCroiseHorizontal:
				sTransition = "opacity" + sParamTransition + ",left";
				break;
			case ms_nTypeBoiteFonduCroiseVertical:
				sTransition = "opacity" + sParamTransition + ",top";
				break;
			case ms_nTypeBoiteReduction:
				sTransition = "width" + sParamTransition + ",height";
				break;
			case ms_nTypeBoiteRotation:
				sTransition = "width" + sParamTransition + ",height" + sParamTransition + "," + ((clStyle.transform != null) ? "transform" : ((clStyle.msTransform != null) ? "-ms-transform" : ((clStyle.webkitTransform != null) ? "-webkit-transform" : ((clStyle.mozTransform != null) ? "-moz-transform" : "-o-transform"))));
				break;
			case ms_nTypeBoiteRideauHorizontal:
				sTransition = "left";
				break;
			case ms_nTypeBoiteRideauVertical:
				sTransition = "top";
				break;
			default:
				sTransition = "all";
				break;
			}
			sTransition += sParamTransition;
		}
		//Affectation transition
		clStyle.transition = clStyle.msTransition = clStyle.webkitTransition = clStyle.mozTransition = clStyle.oTransition = sTransition;
	};

	//Transformation
	__WDAnimSurImage.prototype.SetTransform = function SetTransform(oObjet, sTransform)
	{
		//Objet ?
		if (oObjet == null)
		{
			//Non => rien � faire
			return;
		}
		//Oui => r�cup�ration style objet
		var oStyle = oObjet.style;
		//Transformation
		oStyle.transform = oStyle.msTransform = oStyle.mozTransform = oStyle.oTransform = oStyle.webkitTransform = sTransform;
	};

	__WDAnimSurImage.prototype.bClip = function bClip(o)
	{
		return (o != null) && (clWDUtil.oGetCurrentStyle(o).overflow == "hidden");
	};

	//Affiche ou cache un objet
	//Entr�e :	clObjet		Objet � afficher ou cacher
	//			bAffiche	Indique si on affiche l'objet (le cache si faux)
	__WDAnimSurImage.prototype.Affiche = function Affiche(clObjet, bAffiche)
	{
		//Affiche ou cache l'objet
		clObjet.style.display = bAffiche ? "block" : "none";
	};

	__WDAnimSurImage.prototype.bImageCharge = function bImageCharge(i)
	{
		if (i.readyState != null)
		{
			return i.readyState == "complete";
		}
		//On teste aussi la largeur car Internet Explorer dit que image charg�e alors qu'elle ne l'est pas (largeur nulle)
		return (i.complete) && (i.width > 0);
	};

	__WDAnimSurImage.prototype.sBalise = function sBalise(n)
	{
		return ((n == null) || (n.nodeName == null)) ? "" : n.nodeName.toLowerCase();
	};

	function __s_bDeuxImages(nType)
	{
		return ((nType > ms_nTypeFondu) && (nType < ms_nTypeDecouvrement)) || (nType == ms_nTypeDezoomDeplacement) || ((nType > ms_nTypeMax) && (nType <= ms_nTypeFin));
	};

	function __s_bDeplacement(nType)
	{
		return (nType >= ms_nTypeDeplacementGauche) && (nType <= ms_nTypeDeplacementBasDroite);
	};

	function __s_bGarderImageFin(nType)
	{
		return __s_bDeplacement(nType) || (nType == ms_nTypeDezoomDeplacement);
	};

	__WDAnimSurImage.prototype.bImageTempFrere = function bImageTempFrere(nType)
	{
		return (nType == ms_nTypeRecouvrement);
	};

	//Indique si type animation de type boite
	//Entr�e :	nType	Type animation
	//Sortie :	true si type animation de type boite, false sinon
	__WDAnimSurImage.prototype.bTypeBoite = function bTypeBoite(nType)
	{
		//Type animation boite si compris entre types min et max animation boite
		return (nType >= ms_nTypeBoiteMin) && (nType <= ms_nTypeBoiteMax);
	};

	__WDAnimSurImage.prototype.AjoutFrere = function AjoutFrere(oBalise)
	{
		if (this.m_oBaliseImg.nextElementSibling)
		{
			this.m_oBaliseImg.parentNode.insertBefore(oBalise, this.m_oBaliseImg.nextElementSibling);
		}
		else
		{
			this.m_oBaliseImg.parentNode.appendChild(oBalise);
		}
	};

	//Copie de la protection contre la copie directe par menu contextuel d'une image
	//Entr�e :	oImageRef	Image de r�f�rence
	//			oImage		Image � prot�ger contre la copie si l'image de r�f�rence l'est
	__WDAnimSurImage.prototype.CopieProtectionCopie = function CopieProtectionCopie(oImageRef, oImage)
	{
		//Image de r�f�rence prot�g�e contre la copie ?
		if (oImageRef.oncontextmenu)
		{
			//Oui => on prot�ge l'image contre la copie
			oImage.oncontextmenu = clWDUtil.bStopPropagation;
		}

		// GP 06/01/2016 : TB89870 : Copie les attributs title et alt de l'image source.
		if ("" != oImageRef.title)
		{
			oImage.title = oImageRef.title;
		}
		if ("" != oImageRef.alt)
		{
			oImage.alt = oImageRef.alt;
		}
	};

	__WDAnimSurImage.prototype.oAjoutImageTemp = function oAjoutImageTemp(oBaliseImg, sImage, nOpacite, nType, bFrere)
	{
		var oBaliseImgTemp = new Image();
		this.SetSuperposable(oBaliseImgTemp);
		//On ne rend pas l'image temporaire invisible pour effet fondu car inutile et provoque effet d'affichage sous Chrome avec les transitions
		if (nType != ms_nTypeFondu)
		{
			SetVisible(oBaliseImgTemp, false);
		}
		if (bFrere)
		{
			this.AjoutFrere(oBaliseImgTemp);
			this.SetX(oBaliseImgTemp, this.m_nX);
			this.SetY(oBaliseImgTemp, this.m_nY);
		}
		else
		{
			this.m_oDiv.appendChild(oBaliseImgTemp);
		}
		oBaliseImgTemp.src = sImage;
		oBaliseImgTemp.style.border = "0";
		var l = this.GetLargeur(oBaliseImgTemp);
		var h = this.GetHauteur(oBaliseImgTemp);
		if ((nType != ms_nTypeDezoomDeplacement) || ((this.m_oBaliseImg.outerHTML != null) ? (this.m_oBaliseImg.outerHTML.indexOf("width=") >= 0) : ((this.m_oBaliseImg.attributes != null) && (this.m_oBaliseImg.attributes["width"] != null))))
		{
			this.SetLargeur(oBaliseImgTemp, this.m_nLargeur);
			this.SetHauteur(oBaliseImgTemp, this.m_nHauteur);
		}
		if ((nOpacite < 100) && (nType != ms_nTypeDecouvrement))
		{
			this.SetOpacite(oBaliseImgTemp, nOpacite);
		}
		if (__s_bDeplacement(nType) && (this.m_oBaliseImgTemp != null))
		{
			var z = 1.2;
			var f = Math.max((this.m_nLargeurVisible * z) / l, (this.m_nHauteurVisible * z) / h);
			this.m_nLargeur = l * f;
			this.m_nHauteur = h * f;
			this.SetLargeur(oBaliseImgTemp, this.m_nLargeur);
			this.SetHauteur(oBaliseImgTemp, this.m_nHauteur);
		}

		// Copie si besoin le handler de menu contextuel (pour l'option qui protege contre la sauvegarde directe de l'image)
		this.CopieProtectionCopie(oBaliseImg, oBaliseImgTemp);

		return oBaliseImgTemp;
	};

	__WDAnimSurImage.prototype.vFin = function vFin()
	{
		// Restitution transition
		this.SetTransition(this.m_oBaliseImg, this.m_sTransition);

		if (null != this.m_sVisibilite)
		{
			this.SetVisibilite(this.m_oBaliseImg, this.m_sVisibilite);
		}
		// Supprime l'image temporaire du document
		if (this.m_oBaliseImgTemp != null)
		{
			(this.bImageTempFrere(this.m_nType) ? this.m_oBaliseImg.parentNode : this.m_oDiv).removeChild(this.m_oBaliseImgTemp);
			delete this.m_oBaliseImgTemp;
		}
		if (this.m_oDiapo == null)
		{
			//Boites ?
			if (this.m_tabBoite != null)
			{
				//Oui => destruction boites
				for (var nBoite = 0; nBoite < this.m_tabBoite.length; nBoite++)
				{
					//R�cup�ration boite � d�truire
					var oBoite = this.m_tabBoite[nBoite];
					//On supprime la boite de la liste des fils de son parent
					oBoite.parentNode.removeChild(oBoite);
					//Destruction boite
					delete oBoite;
				}
				//On vide le tableau des boites
				this.m_tabBoite = [];
			}
			this.m_oDiv.parentNode.removeChild(this.m_oDiv);
			delete this.m_oDiv;
			if (this.m_oBaliseImgTempFin != null)
			{
				delete this.m_oBaliseImgTempFin;
			}
			if (this.m_oCanva != null)
			{
				delete this.m_oCanva;
			}
		}

		// Supprime l'animation du tableau
		delete this.ms_oAnimations[this.m_sAliasChamp];

		// Appel de la classe de base
		WDAnim.prototype.vFin.apply(this, arguments);
	};

	//Valeur
	//Entr�e :	nVal	Valeur
	//Sortie : Valuer si d�finie, 0 sinon
	__WDAnimSurImage.prototype.nValeur = function nValeur(nVal)
	{
		//Valeur si d�finie, 0 sinon
		return (nVal != undefined) ? nVal : 0;
	};

	return __WDAnimSurImage;
})();

var sAnimationJoueSurImage = (function()
{
	"use strict";

	var tabAntiReentrance = [];
	return function(sValeur, oImage, sImageDebut, nOpaciteDebut, nType, nCourbe, nDuree, sAliasChamp, bPremAffich)
	{
		// Dans le cas des images avec transition et defilement automatique, il y a un probleme de reentrance s'il y a deja une animation
		// sAnimationJoueSurImage => _vAnnule => vFin (qui se supprime du tableau) => vFin => AnimationFin => _vAnimationFin => __AfficheImage => fonction de set => sAnimationJoueSurImage
		// On bloque donc via une marque dans la fonction
		if (true === tabAntiReentrance[sAliasChamp])
		{
			//GF 28/11/2014 il faut toujours retourner une valeur car la g�n�ration JS �crit:  _JGEN("A3", document, false, false).src = sAnimationJoueSurImage(..)
			return oImage.src;
		}
		// La marque est place dans un try avec finally pour etre sur de bien supprimer la marque en cas d'erreur
		try
		{
			tabAntiReentrance[sAliasChamp] = true;

			// Si on a deja une animation sur l'image, la termine
			var oAnimationOld = WDAnimSurImage.prototype.ms_oAnimations[sAliasChamp];
			if (oAnimationOld)
			{
				nOpaciteDebut = oAnimationOld.m_nOpaciteDebut;
				//Animation par timer ?
				if (oAnimationOld.m_nTimeout != null)
				{
					//Oui => force un dernier dessin puis annule
					if (nType != WDAnimSurImage.prototype.ms_nTypeMouvementAutomatique)
					{
						oAnimationOld._Maj(1);
					}
					oAnimationOld.vAnnule();
				}
			}
			// Lance l'animation
			WDAnimSurImage.prototype.ms_oAnimations[sAliasChamp] = new WDAnimSurImage(oImage, sImageDebut, nOpaciteDebut, nType, nCourbe, nDuree, sValeur, sAliasChamp, bPremAffich);
			// Et retourne la valeur (pour le .src)
			return sValeur;
		}
		finally
		{
			tabAntiReentrance[sAliasChamp] = false;
		}
	};

})();

function SetVisible(o, v)
{
	WDAnimSurImage.prototype.SetVisibilite(o, v ? "visible" : "hidden");
}

//Cr�ation div superposable
//Entr�e :	p					Parent du div � cr�er
//			o					Indique si d�bordement cach�
//			i					Indique si invisible
//			bPositionDedfaut	Indique si position par d�faut
//Sortie :	div cr��
function oCreerDivSuperposable(p, o, i, bPositionDefaut)
{
	var oDiv = document.createElement("div");
	WDAnimSurImage.prototype.SetSuperposable(oDiv);
	if (o)
	{
		oDiv.style.overflow = "hidden";
	}
	if (i)
	{
		SetVisible(oDiv, false);
	}
	p.appendChild(oDiv);
	//Position par d�faut ?
	if (!bPositionDefaut)
	{
		//Non => on positionne en haut � gauche
		WDAnimSurImage.prototype.SetX(oDiv, 0);
		WDAnimSurImage.prototype.SetY(oDiv, 0);
	}
	return oDiv;
}

function WDDiapo()
{
	this.m_oDiv = null;
	this.m_oImgTempFin = null;
	this.m_oCanva = null;
}

function WDImageAnim(a, d)
{
	this.m_oImg = _JGEN(a, document, false);
	this.m_nOpaciteDebut = WDAnimSurImage.prototype.GetOpacite(this.m_oImg);
	WDAnimSurImage.prototype.SetOpacite(this.m_oImg, 0);
	this.m_nDuree = d;
	this.m_sAlias = a;
	//Indique si c'est le premier affichage
	this.m_bPremierAffichage = true;
	var oImgAnim = this;
	this.m_pfCallBack = function() { oImgAnim.Maj(); };
	this.Maj();
};

WDImageAnim.prototype.Maj = function Maj()
{
	var t = 100;
	if (!WDAnimSurImage.prototype.ms_oAnimations[this.m_sAlias])
	{
		sAnimationJoueSurImage(this.m_oImg.src, this.m_oImg, this.m_oImg.src, this.m_nOpaciteDebut, WDAnimSurImage.prototype.ms_nTypeMouvementAutomatique, 0, this.m_nDuree, this.m_sAlias, this.m_bPremierAffichage);
		//Ce n'est plus le premier affichage
		this.m_bPremierAffichage = false;
		t = this.m_nDuree * 10;
	}
	clWDUtil.nSetTimeout(this.m_pfCallBack, t);
};

WDImageZoom.prototype.ms_nPositionGauche = 0;
WDImageZoom.prototype.ms_nPositionDroite = 1;
WDImageZoom.prototype.ms_nPositionHaut = 2;
WDImageZoom.prototype.ms_nPositionBas = 3;
WDImageZoom.prototype.ms_nNbPosition = 4;

function WDImageZoom(a, z, i, j, v, h, d, b, x)
{
	this.m_oObjet = document.getElementById(a);
	if (this.m_oObjet == null)
	{
		this.m_oObjet = document.getElementsByName(a)[0];
	}
	this.m_sSourceImageVignette = h;
	this.m_bVignette = (this.m_sSourceImageVignette != null) && (this.m_sSourceImageVignette != "");
	this.m_oParentImage = this.oParentImage();
	this.m_oLimite = oCreerDivSuperposable(this.m_oParentImage, true);
	WDAnimSurImage.prototype.SetOpacite(this.m_oLimite, 50);
	this.m_oPopup = (d != null) ? _JGEN(d, document, true) : null;
	if (this.m_oPopup != null)
	{
		WDAnimSurImage.prototype.SetX(this.m_oPopup, 0);
		WDAnimSurImage.prototype.SetY(this.m_oPopup, 0);
		if (this.m_oPopup.style.display == "none")
		{
			this.m_oPopup.style.display = "block";
		}
		this.m_oPopup.className = this.m_oPopup.className;
	}
	this.m_oImagePopup = null;
	this.m_bPopupPersoOK = this.m_oPopup != null;
	if (this.m_bPopupPersoOK)
	{
		this.m_oImagePopup = document.getElementById(b);
		this.m_bPopupPersoOK = this.m_oImagePopup != null;
	}
	if (this.m_bPopupPersoOK)
	{
		SetVisible(this.m_oImagePopup, false);
	}
	this.m_bPopupPerso = x && this.m_bPopupPersoOK;
	this.m_oParentImagePopup = this.m_bPopupPersoOK ? this.oParentImage(this.m_oImagePopup, true) : null;
	if ((this.m_oParentImagePopup != null) && (WDAnimSurImage.prototype.sBalise(this.m_oParentImagePopup) == "div") && (this.m_oParentImagePopup.parentNode != null) && (WDAnimSurImage.prototype.sBalise(this.m_oParentImagePopup.parentNode) == "div"))
	{
		this.m_oParentImagePopup = this.m_oParentImagePopup.parentNode;
	}
	this.m_nParamLargeurZoom = i;
	this.m_nParamHauteurZoom = j;
	this.m_bPopupNonPerso = this.m_bPopupPersoOK && (!this.m_bPopupPerso);
	if (this.m_bPopupNonPerso)
	{
		this.m_oParentImage.parentNode.appendChild(this.m_oPopup.parentNode.removeChild(this.m_oPopup));
	}
	this.m_oZoom = oCreerDivSuperposable(this.m_bPopupPersoOK ? this.m_oImagePopup.parentNode : document.body, true, !this.m_bPopupPersoOK);
	if (!this.m_bPopupPersoOK)
	{
		this.m_oPopup = this.m_oZoom;
		this.m_oZoom.style.border = "solid 1px";
		WDAnimSurImage.prototype.SetLargeur(this.m_oZoom, 0);
		WDAnimSurImage.prototype.SetHauteur(this.m_oZoom, 0);
	}
	this.m_oLoupe = oCreerDivSuperposable(this.m_oLimite, true, true);
	//this.m_oLoupe.style.border="solid 1px black";
	this.m_oImageLoupe = new Image();
	//Copie protection copie image sur image loupe
	WDAnimSurImage.prototype.CopieProtectionCopie(this.m_oObjet, this.m_oImageLoupe);
	this.m_oLoupe.appendChild(this.m_oImageLoupe);
	//Vignette ?
	if (this.m_bVignette)
	{
		//Oui => Recherche de l'ancre contenant l'objet
		var oAncre = this.m_oObjet;
		var bAncre = false;
		while ((oAncre != null) && (oAncre != this.m_oParentImage) && (!bAncre))
		{
			if (WDAnimSurImage.prototype.sBalise(oAncre) != "a")
			{
				bAncre = true;
			}
			else
			{
				oAncre = oAncre.parentNode;
			}
		}
		//Ancre trouv�e ?
		if (bAncre)
		{
			//Oui => lors du clic sur l'image de la loupe, on force le clic sur l'ancre
			this.m_oImageLoupe.onclick = function()
			{
				if (oAncre.click != null)
				{
					oAncre.click()
				}
				else if (document.createEvent != null)
				{
					var oClic = document.createEvent("MouseEvents");
					oClic.initEvent("click", true, true);
					oAncre.dispatchEvent(oClic);
				}
			}
		}
	}
	WDAnimSurImage.prototype.SetSuperposable(this.m_oImageLoupe);
	this.m_nZoom = z;
	this.m_sSourceImage = "";
	this.InitImage();
	this.m_nPosition = v;
	this.m_bAffiche = false;
	this.m_nTimer = null;
	var oThis = this;
	this.m_pfCallTimer = function() { oThis.TimerAffiche(); };
	this.m_pfCallMouseMove = function(oEvent) { oThis.OnMouseMove(oEvent || event); };
	this.m_pfCallMouseOut = function(oEvent) { oThis.OnMouseOut(oEvent || event); };
	this.m_pfCallMouseWheel = function(oEvent) { oThis.OnMouseWheel(oEvent || event); };
	this.m_oTabObjetSouris = [this.m_oObjet, this.m_oLimite, this.m_oLoupe, this.m_oImageLoupe];
	var o = 0;
	for (o = 0; o < this.m_oTabObjetSouris.length; o++)
	{
		this.m_oTabObjetSouris[o].onmousemove = this.m_pfCallMouseMove;
		this.m_oTabObjetSouris[o].onmouseout = this.m_pfCallMouseOut;
		if ((this.m_oTabObjetSouris[o].onmousewheel === undefined) && (this.m_oTabObjetSouris[o].addEventListener != null))
		{
			this.m_oTabObjetSouris[o].addEventListener("DOMMouseScroll", this.m_pfCallMouseWheel, false);
		}
		else
		{
			this.m_oTabObjetSouris[o].onmousewheel = this.m_pfCallMouseWheel;
		}
	}
	//On laisse passer les clics sur l'objet superposable servant � afficher les limites de la zone zoom�e
	if ((this.m_oLimite != null) && (this.m_oLimite.style != null) && (this.m_oLimite.style.pointerEvents != null))
	{
		this.m_oLimite.style.pointerEvents = "none";
	}
	//On fait comme si on sortait de l'image pour cacher le zoom
	this.OnMouseOut();
};

WDImageZoom.prototype.InitImage = function InitImage()
{
	//permet le r� init si l'image a chang� de taille (cas d'homoth�tie navigateur)
	var o = WDAnimSurImage.prototype.bClip(this.m_oParentImage) ? this.m_oParentImage : this.m_oObjet;
	if ((this.m_sSourceImage == this.m_oObjet.src) && (this.m_nLargeur==WDAnimSurImage.prototype.GetLargeur(o)) && (WDAnimSurImage.prototype.GetHauteur(o) == this.m_nHauteur) )
	{
		return;
	}
	var bSecondeInit = (this.m_sSourceImage.length > 0);
	this.m_sSourceImage = this.m_oObjet.src;
	this.m_nLargeur = WDAnimSurImage.prototype.GetLargeur(o);
	WDAnimSurImage.prototype.SetLargeur(this.m_oLimite, this.m_nLargeur);
	this.m_nHauteur = WDAnimSurImage.prototype.GetHauteur(o);
	WDAnimSurImage.prototype.SetHauteur(this.m_oLimite, this.m_nHauteur);
	this.m_nLargeurImageZoom = this.nDimensionInitImageZoom(this.m_nParamLargeurZoom, this.m_nLargeur);
	this.m_nHauteurImageZoom = this.nDimensionInitImageZoom(this.m_nParamHauteurZoom, this.m_nHauteur);
	if (this.m_bPopupPerso)
	{
		this.m_nLargeurImageZoom = this.nDimensionInitImageZoomPopup(WDAnimSurImage.prototype.GetLargeur(this.m_oParentImagePopup), this.m_nParamLargeurZoom, this.m_nLargeurImageZoom);
		this.m_nHauteurImageZoom = this.nDimensionInitImageZoomPopup(WDAnimSurImage.prototype.GetHauteur(this.m_oParentImagePopup), this.m_nParamHauteurZoom, this.m_nHauteurImageZoom);
	}
	if (this.m_bPopupNonPerso)
	{
		WDAnimSurImage.prototype.SetLargeur(this.m_oImagePopup, this.m_nLargeurImageZoom);
		WDAnimSurImage.prototype.SetHauteur(this.m_oImagePopup, this.m_nHauteurImageZoom);
	}
	this.m_nLargeurZoom = this.m_bPopupPersoOK ? WDAnimSurImage.prototype.GetLargeur(this.m_oParentImagePopup) : this.m_nLargeurImageZoom;
	this.m_nHauteurZoom = this.m_bPopupPersoOK ? WDAnimSurImage.prototype.GetHauteur(this.m_oParentImagePopup) : this.m_nHauteurImageZoom;
	WDAnimSurImage.prototype.SetLargeur(this.m_oZoom, this.m_nLargeurImageZoom);
	WDAnimSurImage.prototype.SetHauteur(this.m_oZoom, this.m_nHauteurImageZoom);
	this.m_oImageLoupe.src = this.m_oObjet.src;
	WDAnimSurImage.prototype.SetLargeur(this.m_oImageLoupe, this.m_nLargeur);
	WDAnimSurImage.prototype.SetHauteur(this.m_oImageLoupe, this.m_nHauteur);
	if (this.m_oImageZoom != null)
	{
		this.m_oZoom.removeChild(this.m_oImageZoom);
		delete this.m_oImageZoom;
	}
	this.m_oImageZoom = new Image();
	this.m_oZoom.appendChild(this.m_oImageZoom);
	WDAnimSurImage.prototype.SetSuperposable(this.m_oImageZoom);
	var oThis = this;
	this.m_oImageZoom.onload = function() { oThis.InitDimensionImage(); };
	this.m_bInitImage = false;
	// GP 06/01/2014 : Si c'est une image g�n�r�e dans une vignette dans une seconde initialisation, on patch la grande image (qui est dans this.m_sSourceImageVignette)
	if (this.m_bVignette && bSecondeInit)
	{
		var rNoCache = new RegExp("(" + this.m_oObjet.id + "\\=)(\\d+)", "i");
		if (this.m_oObjet.id.length && rNoCache.test(this.m_sSourceImageVignette))
		{
			this.m_sSourceImageVignette = this.m_sSourceImageVignette.replace(rNoCache, function(sExp, s1, s2) { return s1 + (parseInt(s2, 10) + 1); });
			bSecondeInit = false;
		}
	}
	this.m_oImageZoom.src = (this.m_bVignette && (!bSecondeInit)) ? this.m_sSourceImageVignette : this.m_oObjet.src;
	this.InitDimensionImage(true);
};

WDImageZoom.prototype.InitDimensionImage = function InitDimensionImage(i)
{
	if (this.m_bInitImage)
	{
		return;
	}
	this.m_nFacteurImageLargeur = this.nFacteurImageDimension(WDAnimSurImage.prototype.GetLargeur(this.m_oImageZoom), this.m_nLargeur);
	this.m_nFacteurImageHauteur = this.nFacteurImageDimension(WDAnimSurImage.prototype.GetHauteur(this.m_oImageZoom), this.m_nHauteur);
	this.InitZoom(this.m_nZoom, i);
	if (!i)
	{
		this.m_bInitImage = true;
	}
};

WDImageZoom.prototype.InitZoom = function InitZoom(z, i)
{
	this.m_nZoom = (z != null) ? Math.max(z, 1) : 2;
	this.m_nLargeurLoupe = this.nDimensionLoupe(this.m_nLargeurImageZoom, this.m_nFacteurImageLargeur);
	WDAnimSurImage.prototype.SetLargeur(this.m_oLoupe, this.m_nLargeurLoupe);
	this.m_nHauteurLoupe = this.nDimensionLoupe(this.m_nHauteurImageZoom, this.m_nFacteurImageHauteur);
	WDAnimSurImage.prototype.SetHauteur(this.m_oLoupe, this.m_nHauteurLoupe);
	if (!i)
	{
		WDAnimSurImage.prototype.SetLargeur(this.m_oImageZoom, this.nDimensionImageZoom(this.m_nLargeur, this.m_nFacteurImageLargeur));
		WDAnimSurImage.prototype.SetHauteur(this.m_oImageZoom, this.nDimensionImageZoom(this.m_nHauteur, this.m_nFacteurImageHauteur));
	}
};

WDImageZoom.prototype.oParentImage = function oParentImage(i, s)
{
	var p = ((i != null) ? i : this.m_oObjet).parentNode;
	if ((!s) && (this.m_bVignette || (p.href != null)))
	{
		p = p.parentNode;
	}
	//dans une table interne pour le cadre de l'image ? (le d�bordement et le cadre sont invers�s pour l'image)
	if (p.tagName.toLowerCase() == 'td')
	{
		// La colonne de table contenant l'image est bien la premi�re de la premi�re ligne de la de la table ?
		if (p.parentNode && p.parentNode.parentNode && p.parentNode.parentNode.firstElementChild && (p.parentNode.parentNode.firstElementChild.firstElementChild != p))
		{
			// Non => la table n'est pas une table encadrant l'image mais une table de positionnement et l'image n'est pas dans la premi�re case de cette table => le td est le parent
			return p;
		}
		//remonte � la table 
		while (p.tagName.toLowerCase() != 'table')//permet de g�rer le cas tbdoy implicite
		{
			p = p.parentNode;
		}
	}
	var g = p.parentNode/*dzSpan*/;
	return (WDAnimSurImage.prototype.bClip(g) && (g.parentNode != null)) ? g : p;
};

WDImageZoom.prototype.nDimensionInitImageZoom = function nDimensionInitImageZoom(i, j)
{
	return (i != null) ? i : j;
};

WDImageZoom.prototype.nDimensionInitImageZoomPopup = function nDimensionInitImageZoomPopup(p, z, i)
{
	return (z === null) ? p : Math.min(p, i);
};


WDImageZoom.prototype.nFacteurImageDimension = function nFacteurImageDimension(i, d)
{
	return (d != 0) ? (d / i) : 1;
};

WDImageZoom.prototype.nDimensionLoupe = function nDimensionLoupe(z, f)
{
	return (z / this.m_nZoom) * f;
};

WDImageZoom.prototype.nDimensionImageZoom = function nDimensionImageZoom(d, f)
{
	return d * this.m_nZoom / f;
};

WDImageZoom.prototype.nTestPosition = function nTestPosition(p, f)
{
	//source: http://stackoverflow.com/questions/1248081/get-the-browser-viewport-dimensions-with-javascript
	var l = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
	var h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);

	var x = 0;
	var y = 0;
	var d = false;
	var e = false;
	var m = 5;
	var n = m;
	var o = m;
	switch (p)
	{
	case this.ms_nPositionBas:
		x = this.m_nX;
		y = this.m_nY + this.m_nHauteur;
		n = 0;
		break;
	case this.ms_nPositionGauche:
		x = this.m_nX - this.m_nLargeurZoom;
		d = true;
		y = this.m_nY;
		o = 0;
		break;
	case this.ms_nPositionHaut:
		x = this.m_nX;
		y = this.m_nY - this.m_nHauteurZoom;
		e = true;
		n = 0;
		break;
	default:
		x = this.m_nX + this.m_nLargeur;
		y = this.m_nY;
		o = 0;
		break;
	}
	var s = d ? -x : x + this.m_nLargeurZoom - l;
	var t = e ? -y : y + this.m_nHauteurZoom - h;
	var r = Math.max(s, t);
	if (f || (r <= 0))
	{
		this.m_nXZoom = x + (d ? -1 : 1) * Math.min(n, -Math.min(s, 0));
		WDAnimSurImage.prototype.SetX(this.m_oPopup, this.m_nXZoom);
		this.m_nYZoom = y + (e ? -1 : 1) * Math.min(o, -Math.min(t, 0));
		WDAnimSurImage.prototype.SetY(this.m_oPopup, this.m_nYZoom);
	}
	return r;
};

WDImageZoom.prototype.nCoordCoinLoupe = function nCoordCoinLoupe(c, d, o, m)
{
	return Math.min(Math.max(c - (d / 2), o), o + m - d);
};

WDImageZoom.prototype.nCoordImageZoom = function nCoordImageZoom(z, c, o, f)
{
	return z - ((c - o) * this.m_nZoom / f);
};

WDImageZoom.prototype.TimerAffiche = function TimerAffiche()
{
	this.m_nTimer = null;
	this.m_bAffiche = true;
	this.OnMouseMove();
};

WDImageZoom.prototype.AnnuleTimerAffiche = function AnnuleTimerAffiche()
{
	if (this.m_nTimer != null)
	{
		clWDUtil.ClearTimeout(this.m_nTimer);
		this.m_nTimer = null;
	}
};

WDImageZoom.prototype.sObj = function sObj(o)
{
	if (o == null)
	{
		return "";
	}
	var s = o.nodeName + " ";
	switch (o)
	{
	case this.m_oImagePopup:
		s += "image popup";
		break;
	case this.m_oImageZoom:
		s += "image zoomee";
		break;
	case this.m_oLimite:
		s += "limite";
		break;
	case this.m_oLoupe:
		s += "loupe";
		break;
	case this.m_oObjet:
		s += "image affichee";
		break;
	case this.m_oZoom:
		s += "div zoom";
		break;
	case this.m_oPopup:
		s += "popup";
		break;
	}
	s += "(x:" + WDAnimSurImage.prototype.GetX(o) + ",y:" + WDAnimSurImage.prototype.GetY(o) + ",l:" + WDAnimSurImage.prototype.GetLargeur(o) + ",h:" + WDAnimSurImage.prototype.GetHauteur(o) + ")";
	return s;
};

//Affiche ou cache le div de limitation de l'image
//Entr�e :	bAffiche	Indique si on affiche le div de limitation de l'image (le cache si faux)
WDImageZoom.prototype.AfficheLimiteImage = function AfficheLimiteImage(bAffiche)
{
	//Affiche ou cache le div de limitation de l'image
	WDAnimSurImage.prototype.Affiche(this.m_oLimite, bAffiche);
};

//Met le zoom en arri�re ou avant plan
//Entr�e :	bAvantPlan	Indique si on met le zoom en avant-plan (met le zoom en arri�re-plan si faux)
WDImageZoom.prototype.PlanZoom = function PlanZoom(bAvantPlan)
{
	//Met le plan en arri�re ou avant plan
	this.m_oZoom.style.zIndex = bAvantPlan ? 100 : 0;
};

WDImageZoom.prototype.OnMouseMove = function OnMouseMove(oEvent)
{
	this.InitImage();
	if (oEvent != null)
	{
		this.m_nXSouris = oEvent.clientX + document.body.scrollLeft;
		this.m_nYSouris = oEvent.clientY + document.body.scrollTop;
	}
	if (!this.m_bAffiche)
	{
		this.AnnuleTimerAffiche();
		this.m_nTimer = clWDUtil.nSetTimeout(this.m_pfCallTimer, clWDUtil.ms_nTimeoutNonImmediat100);
		return;
	}
	//On affiche le div de limitation de l'image
	this.AfficheLimiteImage(true);
	this.m_oLimite.style.backgroundColor = "white";
	var a = this.oParentImage();
	this.m_nX = WDAnimSurImage.prototype.GetX(a);
	WDAnimSurImage.prototype.SetX(this.m_oLimite, this.m_nX);
	this.m_nY = WDAnimSurImage.prototype.GetY(a);
	WDAnimSurImage.prototype.SetY(this.m_oLimite, this.m_nY);
	var m = 0;
	var p = 0;
	var i = 0;
	for (i = 0; i < this.ms_nNbPosition; i++)
	{
		var q = (this.m_nPosition + i) % this.ms_nNbPosition;
		var r = this.nTestPosition(q);
		if (r <= 0)
		{
			break;
		}
		if ((i == 0) || (r < m))
		{
			m = r;
			p = q;
		}
	}
	if (i == this.ms_nNbPosition)
	{
		this.nTestPosition(p, true);
	}
	//m_nXSouris tient compte du window scroll mais pas m_nX
	var x = this.nCoordCoinLoupe(this.m_nXSouris- document.body.scrollLeft, this.m_nLargeurLoupe, this.m_nX, this.m_nLargeur);
	WDAnimSurImage.prototype.SetX(this.m_oLoupe, x);
	WDAnimSurImage.prototype.SetX(this.m_oImageLoupe, this.m_nX);
	//m_nYSouris tient compte du window scroll mais pas m_nY
	var y = this.nCoordCoinLoupe(this.m_nYSouris- document.body.scrollTop, this.m_nHauteurLoupe, this.m_nY,  this.m_nHauteur);
	WDAnimSurImage.prototype.SetY(this.m_oLoupe, y);
	WDAnimSurImage.prototype.SetY(this.m_oImageLoupe, this.m_nY);
	SetVisible(this.m_oLoupe, true);
	var b = this.m_oImagePopup != null;
	//m_oImagePopup �tant invisible son X Y est � 0 du coup on prend m_oParentImagePopup pour connaitre X Y
	var c = b ? WDAnimSurImage.prototype.GetX(this.m_oParentImagePopup) : this.m_nXZoom;
	var d = b ? WDAnimSurImage.prototype.GetY(this.m_oParentImagePopup) : this.m_nYZoom;
	if (b)
	{
		WDAnimSurImage.prototype.SetX(this.m_oZoom, c);
		WDAnimSurImage.prototype.SetY(this.m_oZoom, d);
	}
	WDAnimSurImage.prototype.SetX(this.m_oImageZoom, this.nCoordImageZoom(c, x, this.m_nX, this.m_nFacteurImageLargeur));
	WDAnimSurImage.prototype.SetY(this.m_oImageZoom, this.nCoordImageZoom(d, y, this.m_nY, this.m_nFacteurImageHauteur));
	SetVisible(this.m_oPopup, true);
	//On met le zoom en avant-plan
	this.PlanZoom(true);
};

WDImageZoom.prototype.OnMouseOut = function OnMouseOut(oEvent)
{
	var t = (oEvent != null) ? (oEvent.toElement ? oEvent.toElement : oEvent.relatedTarget) : null;
	if (clWDUtil.bDansTableau(this.m_oTabObjetSouris, t))
	{
		return;
	}
	this.m_oLimite.style.backgroundColor = "";
	this.AnnuleTimerAffiche();
	this.m_bAffiche = false;
	SetVisible(this.m_oLoupe, false);
	SetVisible(this.m_oPopup, false);
	//On met le zoom en arri�re plan
	this.PlanZoom();
	//On cache le div de limitation de l'image
	this.AfficheLimiteImage();
};

WDImageZoom.prototype.OnMouseWheel = function OnMouseWheel(oEvent)
{
	var w = oEvent.wheelDelta;
	var d = (w != null) ? w : -oEvent.detail;
	this.InitZoom(this.m_nZoom + ((d / Math.abs(d)) * 0.1));
	this.OnMouseMove();
	clWDUtil.bStopPropagation(oEvent);
};

// GP 18/06/2015 : Mis de cot�, jamais activ�
//if (window["WDImage"])
//{

//	function WDImageDiaporama(a)
//	{
//		if (!a)
//		{
//			return;
//		}
//		WDImage.prototype.constructor.apply(this, arguments);
//	};

//	WDImageDiaporama.prototype = new WDImage();
//	WDImageDiaporama.prototype.constructor = WDImageDiaporama;

//	WDImageDiaporama.prototype.Init = function Init()
//	{
//		WDImage.prototype.Init.apply(this, arguments);
//		var p = this.m_oImage.parentNode;
//		this.m_oBarre = oCreerDivSuperposable(p, false, true);
//		this.AjoutBouton("|&lt;", this.OnPremier);
//		this.AjoutBouton("&lt;", this.OnPrecedent);
//		this.m_oBoutonJouePause = this.AjoutBouton("||", this.OnJouePause);
//		this.AjoutBouton(">", this.OnSuivant);
//		this.AjoutBouton(">|", this.OnDernier);
//		this.SetX(this.m_oBarre, Math.max(this.GetX(this.m_oImage) + ((this.GetLargeur(this.m_oImage) - this.GetLargeur(this.m_oBarre)) / 2), 0));
//		this.SetY(this.m_oBarre, this.GetY(this.m_oImage) + this.GetHauteur(this.m_oImage) - this.GetHauteur(this.m_oBarre));
//		var oThis = this;
//		p.onmouseover = function(oEvent) { oThis.OnMouseOver(oEvent || event); };
//		p.onmouseout = function(oEvent) { oThis.OnMouseOut(oEvent || event); };
//	};

//	WDImageDiaporama.prototype.AjoutBouton = function AjoutBouton(l, f)
//	{
//		var oBouton = document.createElement("button");
//		oBouton.value = l;
//		oBouton.style.backgroundColor = "black";
//		oBouton.style.color = "white";
//		oBouton.style.fontSize = "20px";
//		oBouton.style.fontWeight = "bold";
//		oBouton.style.width = "30px";
//		oBouton.style.border = "none";
//		oBouton.onmouseover = function() { WDAnimSurImage.prototype.SetOpacite(this, 100); };
//		oBouton.onmouseout = function() { WDAnimSurImage.prototype.SetOpacite(this, 50); };
//		oBouton.onmouseout();
//		var t = this;
//		oBouton.onclick = function() { f.apply(t); };
//		this.m_oBarre.appendChild(oBouton);
//		return oBouton;
//	};

//	WDImageDiaporama.prototype.OnMouseOver = function OnMouseOver(/*oEvent*/)
//	{
//		SetVisible(this.m_oBarre, true);
//	};

//	WDImageDiaporama.prototype.OnMouseOut = function OnMouseOut(/*oEvent*/)
//	{
//		SetVisible(this.m_oBarre, false);
//	};

//	WDImageDiaporama.prototype.OnPremier = function OnPremier()
//	{
//		this.AffichePremier();
//	};

//	WDImageDiaporama.prototype.OnPrecedent = function OnPrecedent()
//	{
//		this.AffichePrecedent();
//	};

//	WDImageDiaporama.prototype.OnJouePause = function OnJouePause()
//	{
//		var b = this.bGetDefilement();
//		if (b)
//		{
//			this.ArreteDefilement();
//		}
//		else
//		{
//			this.LanceDefilement();
//		}
//		this.m_oBoutonJouePause.value = b ? "|>" : "||";
//	};

//	WDImageDiaporama.prototype.OnSuivant = function OnSuivant()
//	{
//		this.AfficheSuivant();
//	};

//	WDImageDiaporama.prototype.OnDernier = function OnDernier()
//	{
//		this.AfficheDernier();
//	};
//}

// Animation des popups
function WDAnimSurPopup(oPopup, oCible, oCibleExterne, sAliasCible, nHauteurCible, oPopupPrecedente, oDocument, nAnimation, nDuree)
{
	if (oPopup)
	{
		// Sauve les membres
		this.m_oCibleExterne = oCibleExterne;
		this.m_oCible = oCible;
		this.m_oPopup = oPopup;
		this.m_oPopupPrecedente = oPopupPrecedente;
		this.m_oDocument = oDocument;
		this.m_sAliasCible = sAliasCible;

		this.m_sCibleExterneHeight = oCibleExterne.style.height;
		this.m_sCibleExterneOverflowY = oCibleExterne.style.overflowY;
		this.m_sCiblePosition = oCible.style.position;
		this.m_sPopupPosition = oPopup.style.position;
		this.m_sPopupZIndex = oPopup.style.zIndex;

		// Initialise la position des elements
		oCibleExterne.style.height = nHauteurCible + "px";
		oCibleExterne.style.overflowY = "hidden";
		oCible.style.position = "relative";
		oPopupPrecedente.style.position = "absolute";
		oPopupPrecedente.style.zIndex = this.__nGetZIndex(nAnimation, true);
		oPopup.style.position = "absolute";
		oPopup.style.zIndex = this.__nGetZIndex(nAnimation, false);
		oPopupPrecedente.style.visibility = "inherit";
		oPopup.style.visibility = "inherit";
		clWDUtil.SetDisplay(oPopupPrecedente, true);
		clWDUtil.SetDisplay(oPopup, true);
		// Les positions des deux popups sont initialises par le premier appel de la fonction d'avancement lors de la construction

		WDAnim.prototype.constructor.apply(this, [this.__pfGetAvancement(nAnimation), 0, this.__nGetDeplacement(nAnimation, oCibleExterne), 0, this.ms_nCourbeLineaire, nDuree, sAliasCible]);

		this.ms_tabAnimSurPopup.push(this);
	}
};

WDAnimSurPopup.prototype = new WDAnim();
WDAnimSurPopup.prototype.constructor = WDAnimSurPopup;

// Constantes
WDAnimSurPopup.prototype.ms_nAnimDefilementDroite = 2;
WDAnimSurPopup.prototype.ms_nAnimDefilementGauche = 3;
WDAnimSurPopup.prototype.ms_nAnimRecouvrementHaut = 8;
WDAnimSurPopup.prototype.ms_nAnimDevoilementHaut = 17;

// Globales
WDAnimSurPopup.prototype.ms_tabCibles = [];
WDAnimSurPopup.prototype.ms_tabAnimSurPopup = [];
WDAnimSurPopup.prototype.ms_nNbPauses = 0;

// Marque la fin de l'animation
WDAnimSurPopup.prototype.vMaj = function vMaj(bForceNonFini, nTime, bPause)
{
	bPause = bPause || (0 < WDAnimSurPopup.prototype.ms_nNbPauses);
	WDAnim.prototype.vMaj.apply(this, arguments);
};
WDAnimSurPopup.prototype.vFin = function vFin()
{
	clWDUtil.SupprimeDansTableau(this.ms_tabAnimSurPopup, this);

	this.m_oCibleExterne.style.overflowY = this.m_sCibleExterneOverflowY;
	this.m_oCibleExterne.style.height = this.m_sCibleExterneHeight;
	this.m_oCible.style.position = this.m_sCiblePosition;

	this.s_FinAffiche(this.m_oPopup, this.m_oCible, this.m_oDocument, this.m_sAliasCible, this.m_sPopupPosition, this.m_sPopupZIndex);

	// Liberation
	this.m_oPopup = null;
	delete this.m_oPopup;
	this.m_oCible = null;
	delete this.m_oCible;
	this.m_oCibleExterne = null;
	delete this.m_oCibleExterne;
	this.m_oPopupPrecedente = null;
	delete this.m_oPopupPrecedente;
	this.m_oDocument = null;
	delete this.m_oDocument;

	WDAnim.prototype.vFin.apply(this, arguments);
};

// Trouve le zIndex des elements
WDAnimSurPopup.prototype.__nGetZIndex = function __nGetZIndex(nAnimation, bPrecedente)
{
	switch (nAnimation)
	{
	case this.ms_nAnimDefilementDroite:
	case this.ms_nAnimDevoilementHaut:
		return bPrecedente ? "2" : "1";
	default:
	case this.ms_nAnimDefilementGauche:
	case this.ms_nAnimRecouvrementHaut:
		return bPrecedente ? "1" : "2";
	}
};
// Calcule la fonction d'avancement
WDAnimSurPopup.prototype.__pfGetAvancement = function __pfGetAvancement(nAnimation)
{
	switch (nAnimation)
	{
	case this.ms_nAnimDefilementDroite:
		return this.__OnDefilementDroite;
	default:
	case this.ms_nAnimDefilementGauche:
		return this.__OnDefilementGauche;
	case this.ms_nAnimRecouvrementHaut:
		return this.__OnRecouvrementHaut;
	case this.ms_nAnimDevoilementHaut:
		return this.__OnDevoilementHaut;
	}
};
// Calcule le deplacement maximal
WDAnimSurPopup.prototype.__nGetDeplacement = function __nGetDeplacement(nAnimation, oCibleExterne)
{
	switch (nAnimation)
	{
	default:
	case this.ms_nAnimDefilementDroite:
	case this.ms_nAnimDefilementGauche:
		return oCibleExterne.offsetWidth;
	case this.ms_nAnimRecouvrementHaut:
	case this.ms_nAnimDevoilementHaut:
		return Math.min(this.m_oDocument.body.offsetHeight + Math.min(0, clWDUtil.nGetBoundingClientRectTop(this.m_oCible, false, true)), oCibleExterne.offsetHeight);
	}
};

// Fonctions d'avancement
WDAnimSurPopup.prototype.__OnDefilementGauche = function __OnDefilementGauche(nAvancement)
{
	this.__OnDefilementDroiteGauche(nAvancement, true);
};
WDAnimSurPopup.prototype.__OnDefilementDroite = function __OnDefilementDroite(nAvancement)
{
	this.__OnDefilementDroiteGauche(nAvancement, false);
};
WDAnimSurPopup.prototype.__OnDefilementDroiteGauche = function __OnDefilementDroiteGauche(nAvancement, bGauche)
{
	var nInverse = bGauche ? -1 : 1;
	if (0 == nAvancement)
	{
		// Sur le premier appel place correctement les elements
		this.m_oPopupPrecedente.style.top = "0px";
		this.m_oPopup.style.top = this.__nGetPositionVerticalFinal() + "px";
	}
	// Place les elements en largeur
	this.m_oPopupPrecedente.style.left = (nInverse * nAvancement) + "px";
	this.m_oPopup.style.left = (nInverse * (nAvancement - this.m_nValDelta)) + "px";

	// Force le reflow avec IE
	this.m_oPopup.className += "";
};
WDAnimSurPopup.prototype.__OnRecouvrementHaut = function __OnRecouvrementHaut(nAvancement)
{
	this.__OnRecouvrementDevoilementHaut(nAvancement, true);
};
WDAnimSurPopup.prototype.__OnDevoilementHaut = function __OnDevoilementHaut(nAvancement)
{
	this.__OnRecouvrementDevoilementHaut(nAvancement, false);
};
WDAnimSurPopup.prototype.__OnRecouvrementDevoilementHaut = function __OnRecouvrementDevoilementHaut(nAvancement, bRecouvrement)
{
	var oPopupDessous = bRecouvrement ? this.m_oPopupPrecedente : this.m_oPopup;
	var oPopupDessus = bRecouvrement ? this.m_oPopup : this.m_oPopupPrecedente;
	if (0 == nAvancement)
	{
		// Sur le premier appel place correctement les elements
		oPopupDessous.style.left = "0px";
		oPopupDessous.style.top = "0px";
		oPopupDessus.style.left = "0px";
	}
	// Place la popup en hauteur
	oPopupDessus.style.top = (this.__nGetPositionVerticalFinal() + (bRecouvrement ? this.m_nValDelta - nAvancement : nAvancement)) + "px";

	// Force le reflow avec IE
	this.m_oPopup.className += "";
};
WDAnimSurPopup.prototype.__nGetPositionVerticalFinal = function __nGetPositionVerticalFinal()
{
	// GP 12/03/2014 : TB86489 : Code mal migr� vers nGetBoundingClientRectTop, on veux "-" ici.
	// Le but :
	// - Si la cible est enti�rement visible, le d�filement est align� sur le haut de la cible => On veux z�ro
	//	Comme la cible est visible, nGetBoundingClientRectTop sans d�filement donne une valeur positive, donc -nGetBoundingClientRectTop donne
	//	une valeur n�gative et le max donne au final 0.
	// - Si la cible a son haut de masqu�, le d�filement est align� sur le haut de la vue => on veux une valeur positive (pour �tre en dessous du haut
	// de la cible qui est hors �cran)
	//	Comme la cibles est partiellement masqu�, nGetBoundingClientRectTop sans d�filement donne une valeur n�gative, donc -nGetBoundingClientRectTop
	//	donne une valeur positive et le max donne cette valeur
	return Math.max(0, -clWDUtil.nGetBoundingClientRectTop(this.m_oCible, false, true));
};

// Fin de l'affichage
WDAnimSurPopup.prototype.s_FinAffiche = function s_FinAffiche(oPopup, oCible, oDocument, sAliasCible, sPopupPosition, sPopupZIndex)
{
	// Si on a une popup precedente : replace ses parametres et la masque
	var oDescriptionCible = this.ms_tabCibles[sAliasCible];
	if (oDescriptionCible)
	{
		clWDUtil.SetDisplay(oDescriptionCible.m_oPopup, false);
		// Notifie les champs que la popup n'est plus affich�e
		AppelMethode(WDChamp.prototype.ms_sOnDisplay, [oPopup, false]);


		oDescriptionCible.m_oPopup.style.position = oDescriptionCible.m_sPosition;
		oDescriptionCible.m_oPopup.style.zIndex = oDescriptionCible.m_sZIndex;
		oDescriptionCible.m_oPopup.style.visibility = "hidden";
		oDescriptionCible.m_oPopup = null;
		oDescriptionCible = null;
		this.ms_tabCibles[sAliasCible] = null;
		delete this.ms_tabCibles[sAliasCible];
	}

	// Modifie la popup
	oPopup.style.position = "static";
	oPopup.style.height = "100%";
	oPopup.style.zIndex = "auto";
	oPopup.style.visibility = "inherit";
	if ("none" == clWDUtil.oGetCurrentStyle(oPopup).display)
	{
		clWDUtil.SetDisplay(oPopup, true);
	}
	var nScroll = clWDUtil.nGetBoundingClientRectTop(oCible, true, true);
	if (nScroll < oDocument.body.scrollTop)
	{
		oDocument.body.scrollTop = nScroll;
	}

	// Et ajoute la nouvelle description
	this.ms_tabCibles[sAliasCible] = {
		m_oPopup: oPopup,
		m_sPosition: sPopupPosition,
		m_sZIndex: sPopupZIndex
	};

	// Notifie les champs de l'affichage de la popup
	// Force la MAJ des champs (saisie riche, upload)
	AppelMethode(WDChamp.prototype.ms_sOnDisplay, [oPopup, true]);
};

// Interface avec le WL
WDAnimSurPopup.prototype.s_PopupAnime = function s_PopupAnime(sAliasPopup, sAliasCible, oDocument, nAnimation, nDuree)
{
	// Trouve la popup
	var oPopup = _JGE(sAliasPopup, oDocument, true, false);
	// Trouve la cible
	var oCible = _JGE(sAliasCible, oDocument, false);
	// Si on trouve l'exterieur d'une table de positionnement
	if (oCible && clWDUtil.bBaliseEstTag(oCible, "table"))
	{
		oCible = oCible.getElementsByTagName("td")[0];
	}

	if (oPopup && oCible)
	{
		// Trouve si on a deja une popup (pas de var : on fait une variable globale)
		var oDescriptionCible = this.ms_tabCibles[sAliasCible];
		var nHauteurCible;
		var oCibleExterne;
		if (!oDescriptionCible)
		{
			// Il n'y a pas encore de popup dans la cible : affiche simplement la popup
			clWDUtil.SupprimeFils(oCible);
		}
		else if (oDescriptionCible.m_oPopup == oPopup)
		{
			// Ne change pas de popup : ne fait rien
			return;
		}
		else
		{
			// Lance l'animation
			oCibleExterne = _JGE(sAliasCible, oDocument, true, false);
			nHauteurCible = oCibleExterne.offsetHeight;
		}

		// Deplace la popup
		oPopup = clWDUtil.oCelluleDeplace(oCible, oPopup);
		// Lance l'animation ou affiche directement
		if (oDescriptionCible)
		{
			oCibleExterne = _JGE(sAliasCible, oDocument, true, false);
			new WDAnimSurPopup(oPopup, oCible, oCibleExterne, sAliasCible, nHauteurCible, oDescriptionCible.m_oPopup, oDocument, nAnimation, nDuree)
		}
		else
		{
			WDAnimSurPopup.prototype.s_FinAffiche(oPopup, oCible, oDocument, sAliasCible, oPopup.style.position, oPopup.style.zIndex);
		}
	}
};

// Pause/Continue les animations
WDAnimSurPopup.prototype.s_Pause = function s_Pause()
{
	if (0 == WDAnimSurPopup.prototype.ms_nNbPauses++)
	{
		WDAnimSurPopup.prototype.ms_nDebutPause = (new Date()).getTime();
	}

};
WDAnimSurPopup.prototype.s_Continue = function s_Continue()
{
	clWDUtil.nSetTimeout(WDAnimSurPopup.prototype.__s_Continue, clWDUtil.ms_oTimeoutImmediat);
};
WDAnimSurPopup.prototype.__s_Continue = function _s_Continue()
{
	if (0 == --WDAnimSurPopup.prototype.ms_nNbPauses)
	{
		var nDecalage = (new Date()).getTime() - WDAnimSurPopup.prototype.ms_nDebutPause;
		var tabAnimSurPopup = WDAnimSurPopup.prototype.ms_tabAnimSurPopup;
		var i;
		var nLimiteI = tabAnimSurPopup.length;
		for (i = 0; i < nLimiteI; i++)
		{
			tabAnimSurPopup[i].m_nDebut += nDecalage;
		}
		delete WDAnimSurPopup.prototype.ms_nDebutPause;
	}
};

(function(window, undefined)
{
	'use strict';

	/**
	* Evenement gesture
	* use this to create instances
	* @param   {HTMLElement}   element
	* @param   {Object}        options
	* @returns {WDGestureEvenement.Instance}
	* @constructor
	*/
	var WDGestureEvenement = function(element, options)
	{
		return new WDGestureEvenement.Instance(element, options || {});
	};

	// default settings
	WDGestureEvenement.defaults = {
		// add styles and attributes to the element to prevent the browser from doing
		// its native behavior. this doesnt prevent the scrolling, but cancels
		// the contextmenu, tap highlighting etc
		// set to false to disable this
		stop_browser_behavior: {
			// this also triggers onselectstart=false for IE
			userSelect: 'none',
			// this makes the element blocking in IE10 >, you could experiment with the value
			touchAction: 'none',
			touchCallout: 'none',
			contentZooming: 'none',
			userDrag: 'none',
			tapHighlightColor: 'rgba(0,0,0,0)'
		}

		//
		// more settings are defined per gesture at gestures.js
		//
	};

	// detect touchevents
	WDGestureEvenement.HAS_POINTEREVENTS = window.navigator.pointerEnabled || window.navigator.msPointerEnabled;
	WDGestureEvenement.HAS_TOUCHEVENTS = ('ontouchstart' in window);

	// dont use mouseevents on mobile devices
	WDGestureEvenement.MOBILE_REGEX = /mobile|tablet|ip(ad|hone|od)|android|silk/i;
	WDGestureEvenement.NO_MOUSEEVENTS = WDGestureEvenement.HAS_TOUCHEVENTS && window.navigator.userAgent.match(WDGestureEvenement.MOBILE_REGEX);

	// eventtypes per touchevent (start, move, end)
	// are filled by WDGestureEvenement.event.determineEventTypes on setup
	WDGestureEvenement.EVENT_TYPES = {};

	// direction defines
	WDGestureEvenement.DIRECTION_DOWN = 'down';
	WDGestureEvenement.DIRECTION_LEFT = 'left';
	WDGestureEvenement.DIRECTION_UP = 'up';
	WDGestureEvenement.DIRECTION_RIGHT = 'right';

	// pointer type
	WDGestureEvenement.POINTER_MOUSE = 'mouse';
	WDGestureEvenement.POINTER_TOUCH = 'touch';
	WDGestureEvenement.POINTER_PEN = 'pen';

	// touch event defines
	WDGestureEvenement.EVENT_START = 'start';
	WDGestureEvenement.EVENT_MOVE = 'move';
	WDGestureEvenement.EVENT_END = 'end';

	// WDGestureEvenement document where the base events are added at
	WDGestureEvenement.DOCUMENT = window.document;

	// plugins and gestures namespaces
	WDGestureEvenement.plugins = WDGestureEvenement.plugins || {};
	WDGestureEvenement.gestures = WDGestureEvenement.gestures || {};

	// if the window events are set...
	WDGestureEvenement.READY = false;

	/**
	* setup events to detect gestures on the document
	*/
	function setup()
	{
		if (WDGestureEvenement.READY)
		{
			return;
		}

		// find what eventtypes we add listeners to
		WDGestureEvenement.event.determineEventTypes();

		// Register all gestures inside WDGestureEvenement.gestures
		WDGestureEvenement.utils.each(WDGestureEvenement.gestures, function(gesture)
		{
			WDGestureEvenement.detection.register(gesture);
		});

		// Add touch events on the document
		WDGestureEvenement.event.onTouch(WDGestureEvenement.DOCUMENT, WDGestureEvenement.EVENT_MOVE, WDGestureEvenement.detection.detect);
		WDGestureEvenement.event.onTouch(WDGestureEvenement.DOCUMENT, WDGestureEvenement.EVENT_END, WDGestureEvenement.detection.detect);

		// WDGestureEvenement is ready...!
		WDGestureEvenement.READY = true;
	}

	WDGestureEvenement.utils = {
		/**
		* extend method,
		* also used for cloning when dest is an empty object
		* @param   {Object}    dest
		* @param   {Object}    src
		* @parm  {Boolean}  merge    do a merge
		* @returns {Object}    dest
		*/
		extend: function extend(dest, src, merge)
		{
			for (var key in src)
			{
				if (dest[key] !== undefined && merge)
				{
					continue;
				}
				dest[key] = src[key];
			}
			return dest;
		},


		/**
		* for each
		* @param obj
		* @param iterator
		*/
		each: function(obj, iterator, context)
		{
			var i, length;
			// native forEach on arrays
			if ('forEach' in obj)
			{
				obj.forEach(iterator, context);
			}
			// arrays
			else if (obj.length !== undefined)
			{
				for (i = 0, length = obj.length; i < length; i++)
				{
					if (iterator.call(context, obj[i], i, obj) === false)
					{
						return;
					}
				}
			}
			// objects
			else
			{
				for (i in obj)
				{
					if (obj.hasOwnProperty(i) && iterator.call(context, obj[i], i, obj) === false)
					{
						return;
					}
				}
			}
		},

		/**
		* find if a node is in the given parent
		* used for event delegation tricks
		* @param   {HTMLElement}   node
		* @param   {HTMLElement}   parent
		* @returns {boolean}       has_parent
		*/
		hasParent: function(node, parent)
		{
			while (node)
			{
				if (node == parent)
				{
					return true;
				}
				node = node.parentNode;
			}
			return false;
		},


		/**
		* get the center of all the touches
		* @param   {Array}     touches
		* @returns {Object}    center
		*/
		getCenter: function getCenter(touches)
		{
			var valuesX = [], valuesY = [];

			WDGestureEvenement.utils.each(touches, function(touch)
			{
				// I prefer clientX because it ignore the scrolling position
				valuesX.push(typeof touch.clientX !== 'undefined' ? touch.clientX : touch.pageX);
				valuesY.push(typeof touch.clientY !== 'undefined' ? touch.clientY : touch.pageY);
			});

			return {
				pageX: ((Math.min.apply(Math, valuesX) + Math.max.apply(Math, valuesX)) / 2),
				pageY: ((Math.min.apply(Math, valuesY) + Math.max.apply(Math, valuesY)) / 2)
			};
		},


		/**
		* calculate the velocity between two points
		* @param   {Number}    delta_time
		* @param   {Number}    delta_x
		* @param   {Number}    delta_y
		* @returns {Object}    velocity
		*/
		getVelocity: function getVelocity(delta_time, delta_x, delta_y)
		{
			return {
				x: Math.abs(delta_x / delta_time) || 0,
				y: Math.abs(delta_y / delta_time) || 0
			};
		},


		/**
		* calculate the angle between two coordinates
		* @param   {Touch}     touch1
		* @param   {Touch}     touch2
		* @returns {Number}    angle
		*/
		getAngle: function getAngle(touch1, touch2)
		{
			var y = touch2.pageY - touch1.pageY,
      x = touch2.pageX - touch1.pageX;
			return Math.atan2(y, x) * 180 / Math.PI;
		},


		/**
		* angle to direction define
		* @param   {Touch}     touch1
		* @param   {Touch}     touch2
		* @returns {String}    direction constant, like WDGestureEvenement.DIRECTION_LEFT
		*/
		getDirection: function getDirection(touch1, touch2)
		{
			var x = Math.abs(touch1.pageX - touch2.pageX),
      y = Math.abs(touch1.pageY - touch2.pageY);

			if (x >= y)
			{
				return touch1.pageX - touch2.pageX > 0 ? WDGestureEvenement.DIRECTION_LEFT : WDGestureEvenement.DIRECTION_RIGHT;
			}
			else
			{
				return touch1.pageY - touch2.pageY > 0 ? WDGestureEvenement.DIRECTION_UP : WDGestureEvenement.DIRECTION_DOWN;
			}
		},


		/**
		* calculate the distance between two touches
		* @param   {Touch}     touch1
		* @param   {Touch}     touch2
		* @returns {Number}    distance
		*/
		getDistance: function getDistance(touch1, touch2)
		{
			var x = touch2.pageX - touch1.pageX,
      y = touch2.pageY - touch1.pageY;
			return Math.sqrt((x * x) + (y * y));
		},


		/**
		* calculate the scale factor between two touchLists (fingers)
		* no scale is 1, and goes down to 0 when pinched together, and bigger when pinched out
		* @param   {Array}     start
		* @param   {Array}     end
		* @returns {Number}    scale
		*/
		getScale: function getScale(start, end)
		{
			// need two fingers...
			if (start.length >= 2 && end.length >= 2)
			{
				return this.getDistance(end[0], end[1]) /
        this.getDistance(start[0], start[1]);
			}
			return 1;
		},


		/**
		* calculate the rotation degrees between two touchLists (fingers)
		* @param   {Array}     start
		* @param   {Array}     end
		* @returns {Number}    rotation
		*/
		getRotation: function getRotation(start, end)
		{
			// need two fingers
			if (start.length >= 2 && end.length >= 2)
			{
				return this.getAngle(end[1], end[0]) -
        this.getAngle(start[1], start[0]);
			}
			return 0;
		},


		/**
		* boolean if the direction is vertical
		* @param    {String}    direction
		* @returns  {Boolean}   is_vertical
		*/
		isVertical: function isVertical(direction)
		{
			return (direction == WDGestureEvenement.DIRECTION_UP || direction == WDGestureEvenement.DIRECTION_DOWN);
		},


		/**
		* stop browser default behavior with css props
		* @param   {HtmlElement}   element
		* @param   {Object}        css_props
		*/
		stopDefaultBrowserBehavior: function stopDefaultBrowserBehavior(element, css_props)
		{
			if (!css_props || !element || !element.style)
			{
				return;
			}

			// with css properties for modern browsers
			WDGestureEvenement.utils.each(['webkit', 'khtml', 'moz', 'Moz', 'ms', 'o', ''], function(vendor)
			{
				WDGestureEvenement.utils.each(css_props, function(prop)
				{
					// vender prefix at the property
					if (vendor)
					{
						prop = vendor + prop.substring(0, 1).toUpperCase() + prop.substring(1);
					}
					// set the style
					if (prop in element.style)
					{
						element.style[prop] = prop;
					}
				});
			});

			// also the disable onselectstart
			if (css_props.userSelect == 'none')
			{
				element.onselectstart = function()
				{
					return false;
				};
			}

			// and disable ondragstart
			if (css_props.userDrag == 'none')
			{
				element.ondragstart = function()
				{
					return false;
				};
			}
		}
	};


	/**
	* create new WDGestureEvenement instance
	* all methods should return the instance itself, so it is chainable.
	* @param   {HTMLElement}       element
	* @param   {Object}            [options={}]
	* @returns {WDGestureEvenement.Instance}
	* @constructor
	*/
	WDGestureEvenement.Instance = function(element, options)
	{
		var self = this;

		// setup WDGestureEvenement window events and register all gestures
		// this also sets up the default options
		setup();

		this.element = element;

		// start/stop detection option
		this.enabled = true;

		// merge options
		this.options = WDGestureEvenement.utils.extend(
    WDGestureEvenement.utils.extend({}, WDGestureEvenement.defaults),
    options || {});

		// add some css to the element to prevent the browser from doing its native behavoir
		if (this.options.stop_browser_behavior)
		{
			WDGestureEvenement.utils.stopDefaultBrowserBehavior(this.element, this.options.stop_browser_behavior);
		}

		// start detection on touchstart
		WDGestureEvenement.event.onTouch(element, WDGestureEvenement.EVENT_START, function(ev)
		{
			if (self.enabled)
			{
				WDGestureEvenement.detection.startDetect(self, ev);
			}
		});

		// return instance
		return this;
	};


	WDGestureEvenement.Instance.prototype = {
		/**
		* bind events to the instance
		* @param   {String}      gesture
		* @param   {Function}    handler
		* @returns {WDGestureEvenement.Instance}
		*/
		on: function onEvent(gesture, handler)
		{
			var gestures = gesture.split(' ');
			WDGestureEvenement.utils.each(gestures, function(gesture)
			{
				this.element.addEventListener(gesture, handler, false);
			}, this);
			return this;
		},


		/**
		* unbind events to the instance
		* @param   {String}      gesture
		* @param   {Function}    handler
		* @returns {WDGestureEvenement.Instance}
		*/
		off: function offEvent(gesture, handler)
		{
			var gestures = gesture.split(' ');
			WDGestureEvenement.utils.each(gestures, function(gesture)
			{
				this.element.removeEventListener(gesture, handler, false);
			}, this);
			return this;
		},


		/**
		* trigger gesture event
		* @param   {String}      gesture
		* @param   {Object}      [eventData]
		* @returns {WDGestureEvenement.Instance}
		*/
		trigger: function triggerEvent(gesture, eventData)
		{
			// optional
			if (!eventData)
			{
				eventData = {};
			}

			// create DOM event
			var event = WDGestureEvenement.DOCUMENT.createEvent('Event');
			event.initEvent(gesture, true, true);
			event.gesture = eventData;

			// trigger on the target if it is in the instance element,
			// this is for event delegation tricks
			var element = this.element;
			if (WDGestureEvenement.utils.hasParent(eventData.target, element))
			{
				element = eventData.target;
			}

			element.dispatchEvent(event);
			return this;
		},


		/**
		* enable of disable WDGestureEvenement detection
		* @param   {Boolean}   state
		* @returns {WDGestureEvenement.Instance}
		*/
		enable: function enable(state)
		{
			this.enabled = state;
			return this;
		}
	};


	/**
	* this holds the last move event,
	* used to fix empty touchend issue
	* see the onTouch event for an explanation
	* @type {Object}
	*/
	var last_move_event = null;


	/**
	* when the mouse is hold down, this is true
	* @type {Boolean}
	*/
	var enable_detect = false;


	/**
	* when touch events have been fired, this is true
	* @type {Boolean}
	*/
	var touch_triggered = false;


	WDGestureEvenement.event = {
		/**
		* simple addEventListener
		* @param   {HTMLElement}   element
		* @param   {String}        type
		* @param   {Function}      handler
		*/
		bindDom: function(element, type, handler)
		{
			var types = type.split(' ');
			WDGestureEvenement.utils.each(types, function(type)
			{
				element.addEventListener(type, handler, false);
			});
		},


		/**
		* touch events with mouse fallback
		* @param   {HTMLElement}   element
		* @param   {String}        eventType        like WDGestureEvenement.EVENT_MOVE
		* @param   {Function}      handler
		*/
		onTouch: function onTouch(element, eventType, handler)
		{
			var self = this;

			this.bindDom(element, WDGestureEvenement.EVENT_TYPES[eventType], function bindDomOnTouch(ev)
			{
				var sourceEventType = ev.type.toLowerCase();

				// onmouseup, but when touchend has been fired we do nothing.
				// this is for touchdevices which also fire a mouseup on touchend
				if (sourceEventType.match(/mouse/) && touch_triggered)
				{
					return;
				}

				// mousebutton must be down or a touch event
				else if (sourceEventType.match(/touch/) ||   // touch events are always on screen
        sourceEventType.match(/pointerdown/) || // pointerevents touch
        (sourceEventType.match(/mouse/) && ev.which === 1)   // mouse is pressed
        )
				{
					enable_detect = true;
				}

				// mouse isn't pressed
				else if (sourceEventType.match(/mouse/) && !ev.which)
				{
					enable_detect = false;
				}


				// we are in a touch event, set the touch triggered bool to true,
				// this for the conflicts that may occur on ios and android
				if (sourceEventType.match(/touch|pointer/))
				{
					touch_triggered = true;
				}

				// count the total touches on the screen
				var count_touches = 0;

				// when touch has been triggered in this detection session
				// and we are now handling a mouse event, we stop that to prevent conflicts
				if (enable_detect)
				{
					// update pointerevent
					if (WDGestureEvenement.HAS_POINTEREVENTS && eventType != WDGestureEvenement.EVENT_END)
					{
						count_touches = WDGestureEvenement.PointerEvent.updatePointer(eventType, ev);
					}
					// touch
					else if (sourceEventType.match(/touch/))
					{
						count_touches = ev.touches.length;
					}
					// mouse
					else if (!touch_triggered)
					{
						count_touches = sourceEventType.match(/up/) ? 0 : 1;
					}

					// if we are in a end event, but when we remove one touch and
					// we still have enough, set eventType to move
					if (count_touches > 0 && eventType == WDGestureEvenement.EVENT_END)
					{
						eventType = WDGestureEvenement.EVENT_MOVE;
					}
					// no touches, force the end event
					else if (!count_touches)
					{
						eventType = WDGestureEvenement.EVENT_END;
					}

					// store the last move event
					if (count_touches || last_move_event === null)
					{
						last_move_event = ev;
					}

					// trigger the handler
					handler.call(WDGestureEvenement.detection, self.collectEventData(element, eventType, self.getTouchList(last_move_event, eventType), ev));

					// remove pointerevent from list
					if (WDGestureEvenement.HAS_POINTEREVENTS && eventType == WDGestureEvenement.EVENT_END)
					{
						count_touches = WDGestureEvenement.PointerEvent.updatePointer(eventType, ev);
					}
				}

				// on the end we reset everything
				if (!count_touches)
				{
					last_move_event = null;
					enable_detect = false;
					touch_triggered = false;
					WDGestureEvenement.PointerEvent.reset();
				}
			});
		},


		/**
		* we have different events for each device/browser
		* determine what we need and set them in the WDGestureEvenement.EVENT_TYPES constant
		*/
		determineEventTypes: function determineEventTypes()
		{
			// determine the eventtype we want to set
			var types;

			// pointerEvents magic
			if (WDGestureEvenement.HAS_POINTEREVENTS)
			{
				types = WDGestureEvenement.PointerEvent.getEvents();
			}
			// on Android, iOS, blackberry, windows mobile we dont want any mouseevents
			else if (WDGestureEvenement.NO_MOUSEEVENTS)
			{
				types = [
        'touchstart',
        'touchmove',
        'touchend touchcancel'];
			}
			// for non pointer events browsers and mixed browsers,
			// like chrome on windows8 touch laptop
			else
			{
				types = [
        'touchstart mousedown',
        'touchmove mousemove',
        'touchend touchcancel mouseup'];
			}

			WDGestureEvenement.EVENT_TYPES[WDGestureEvenement.EVENT_START] = types[0];
			WDGestureEvenement.EVENT_TYPES[WDGestureEvenement.EVENT_MOVE] = types[1];
			WDGestureEvenement.EVENT_TYPES[WDGestureEvenement.EVENT_END] = types[2];
		},


		/**
		* create touchlist depending on the event
		* @param   {Object}    ev
		* @param   {String}    eventType   used by the fakemultitouch plugin
		*/
		getTouchList: function getTouchList(ev/*, eventType*/)
		{
			// get the fake pointerEvent touchlist
			if (WDGestureEvenement.HAS_POINTEREVENTS)
			{
				return WDGestureEvenement.PointerEvent.getTouchList();
			}
			// get the touchlist
			else if (ev.touches)
			{
				return ev.touches;
			}
			// make fake touchlist from mouse position
			else
			{
				ev.identifier = 1;
				return [ev];
			}
		},


		/**
		* collect event data for WDGestureEvenement
		* @param   {HTMLElement}   element
		* @param   {String}        eventType        like WDGestureEvenement.EVENT_MOVE
		* @param   {Object}        eventData
		*/
		collectEventData: function collectEventData(element, eventType, touches, ev)
		{
			// find out pointerType
			var pointerType = WDGestureEvenement.POINTER_TOUCH;
			if (ev.type.match(/mouse/) || WDGestureEvenement.PointerEvent.matchType(WDGestureEvenement.POINTER_MOUSE, ev))
			{
				pointerType = WDGestureEvenement.POINTER_MOUSE;
			}

			return {
				center: WDGestureEvenement.utils.getCenter(touches),
				timeStamp: new Date().getTime(),
				target: ev.target,
				touches: touches,
				eventType: eventType,
				pointerType: pointerType,
				srcEvent: ev,

				/**
				* prevent the browser default actions
				* mostly used to disable scrolling of the browser
				*/
				preventDefault: function()
				{
					if (this.srcEvent.preventManipulation)
					{
						this.srcEvent.preventManipulation();
					}

					if (this.srcEvent.preventDefault)
					{
						this.srcEvent.preventDefault();
					}
				},

				/**
				* stop bubbling the event up to its parents
				*/
				stopPropagation: function()
				{
					this.srcEvent.stopPropagation();
				},

				/**
				* immediately stop gesture detection
				* might be useful after a swipe was detected
				* @return {*}
				*/
				stopDetect: function()
				{
					return WDGestureEvenement.detection.stopDetect();
				}
			};
		}
	};

	WDGestureEvenement.PointerEvent = {
		/**
		* holds all pointers
		* @type {Object}
		*/
		pointers: {},

		/**
		* get a list of pointers
		* @returns {Array}     touchlist
		*/
		getTouchList: function()
		{
			var self = this;
			var touchlist = [];

			// we can use forEach since pointerEvents only is in IE10
			WDGestureEvenement.utils.each(self.pointers, function(pointer)
			{
				touchlist.push(pointer);
			});

			return touchlist;
		},

		/**
		* update the position of a pointer
		* @param   {String}   type             WDGestureEvenement.EVENT_END
		* @param   {Object}   pointerEvent
		*/
		updatePointer: function(type, pointerEvent)
		{
			if (type == WDGestureEvenement.EVENT_END)
			{
				this.pointers = {};
			}
			else
			{
				pointerEvent.identifier = pointerEvent.pointerId;
				this.pointers[pointerEvent.pointerId] = pointerEvent;
			}

			return Object.keys(this.pointers).length;
		},

		/**
		* check if ev matches pointertype
		* @param   {String}        pointerType     WDGestureEvenement.POINTER_MOUSE
		* @param   {PointerEvent}  ev
		*/
		matchType: function(pointerType, ev)
		{
			if (!ev.pointerType)
			{
				return false;
			}

			var pt = ev.pointerType,
      types = {};
			types[WDGestureEvenement.POINTER_MOUSE] = (pt === ev.MSPOINTER_TYPE_MOUSE || pt === WDGestureEvenement.POINTER_MOUSE);
			types[WDGestureEvenement.POINTER_TOUCH] = (pt === ev.MSPOINTER_TYPE_TOUCH || pt === WDGestureEvenement.POINTER_TOUCH);
			types[WDGestureEvenement.POINTER_PEN] = (pt === ev.MSPOINTER_TYPE_PEN || pt === WDGestureEvenement.POINTER_PEN);
			return types[pointerType];
		},


		/**
		* get events
		*/
		getEvents: function()
		{
			return [
      'pointerdown MSPointerDown',
      'pointermove MSPointerMove',
      'pointerup pointercancel MSPointerUp MSPointerCancel'
    ];
		},

		/**
		* reset the list
		*/
		reset: function()
		{
			this.pointers = {};
		}
	};


	WDGestureEvenement.detection = {
		// contains all registred WDGestureEvenement.gestures in the correct order
		gestures: [],

		// data of the current WDGestureEvenement.gesture detection session
		current: null,

		// the previous WDGestureEvenement.gesture session data
		// is a full clone of the previous gesture.current object
		previous: null,

		// when this becomes true, no gestures are fired
		stopped: false,


		/**
		* start WDGestureEvenement.gesture detection
		* @param   {WDGestureEvenement.Instance}   inst
		* @param   {Object}            eventData
		*/
		startDetect: function startDetect(inst, eventData)
		{
			// already busy with a WDGestureEvenement.gesture detection on an element
			if (this.current)
			{
				return;
			}

			this.stopped = false;

			this.current = {
				inst: inst, // reference to WDGestureEvenementI nstance we're working for
				startEvent: WDGestureEvenement.utils.extend({}, eventData), // start eventData for distances, timing etc
				lastEvent: false, // last eventData
				name: '' // current gesture we're in/detected, can be 'tap', 'hold' etc
			};

			this.detect(eventData);
		},


		/**
		* WDGestureEvenement.gesture detection
		* @param   {Object}    eventData
		*/
		detect: function detect(eventData)
		{
			if (!this.current || this.stopped)
			{
				return;
			}

			// extend event data with calculations about scale, distance etc
			eventData = this.extendEventData(eventData);

			// instance options
			var inst_options = this.current.inst.options;

			// call WDGestureEvenement.gesture handlers
			WDGestureEvenement.utils.each(this.gestures, function(gesture)
			{
				// only when the instance options have enabled this gesture
				if (!this.stopped && inst_options[gesture.name] !== false)
				{
					// if a handler returns false, we stop with the detection
					if (gesture.handler.call(gesture, eventData, this.current.inst) === false)
					{
						this.stopDetect();
						return false;
					}
				}
			}, this);

			// store as previous event event
			if (this.current)
			{
				this.current.lastEvent = eventData;
			}

			// endevent, but not the last touch, so dont stop
			if (eventData.eventType == WDGestureEvenement.EVENT_END && !eventData.touches.length - 1)
			{
				this.stopDetect();
			}

			return eventData;
		},


		/**
		* clear the WDGestureEvenement.gesture vars
		* this is called on endDetect, but can also be used when a final WDGestureEvenement.gesture has been detected
		* to stop other WDGestureEvenement.gestures from being fired
		*/
		stopDetect: function stopDetect()
		{
			// clone current data to the store as the previous gesture
			// used for the double tap gesture, since this is an other gesture detect session
			this.previous = WDGestureEvenement.utils.extend({}, this.current);

			// reset the current
			this.current = null;

			// stopped!
			this.stopped = true;
		},


		/**
		* extend eventData for WDGestureEvenement.gestures
		* @param   {Object}   ev
		* @returns {Object}   ev
		*/
		extendEventData: function extendEventData(ev)
		{
			var startEv = this.current.startEvent;

			// if the touches change, set the new touches over the startEvent touches
			// this because touchevents don't have all the touches on touchstart, or the
			// user must place his fingers at the EXACT same time on the screen, which is not realistic
			// but, sometimes it happens that both fingers are touching at the EXACT same time
			if (startEv && (ev.touches.length != startEv.touches.length || ev.touches === startEv.touches))
			{
				// extend 1 level deep to get the touchlist with the touch objects
				startEv.touches = [];
				WDGestureEvenement.utils.each(ev.touches, function(touch)
				{
					startEv.touches.push(WDGestureEvenement.utils.extend({}, touch));
				});
			}

			var delta_time = ev.timeStamp - startEv.timeStamp
      , delta_x = ev.center.pageX - startEv.center.pageX
      , delta_y = ev.center.pageY - startEv.center.pageY
      , velocity = WDGestureEvenement.utils.getVelocity(delta_time, delta_x, delta_y)
      , interimAngle
      , interimDirection;

			// end events (e.g. dragend) don't have useful values for interimDirection & interimAngle
			// because the previous event has exactly the same coordinates
			// so for end events, take the previous values of interimDirection & interimAngle
			// instead of recalculating them and getting a spurious '0'
			if (ev.eventType === 'end')
			{
				interimAngle = this.current.lastEvent && this.current.lastEvent.interimAngle;
				interimDirection = this.current.lastEvent && this.current.lastEvent.interimDirection;
			}
			else
			{
				interimAngle = this.current.lastEvent && WDGestureEvenement.utils.getAngle(this.current.lastEvent.center, ev.center);
				interimDirection = this.current.lastEvent && WDGestureEvenement.utils.getDirection(this.current.lastEvent.center, ev.center);
			}

			WDGestureEvenement.utils.extend(ev, {
				deltaTime: delta_time,

				deltaX: delta_x,
				deltaY: delta_y,

				velocityX: velocity.x,
				velocityY: velocity.y,

				distance: WDGestureEvenement.utils.getDistance(startEv.center, ev.center),

				angle: WDGestureEvenement.utils.getAngle(startEv.center, ev.center),
				interimAngle: interimAngle,

				direction: WDGestureEvenement.utils.getDirection(startEv.center, ev.center),
				interimDirection: interimDirection,

				scale: WDGestureEvenement.utils.getScale(startEv.touches, ev.touches),
				rotation: WDGestureEvenement.utils.getRotation(startEv.touches, ev.touches),

				startEvent: startEv
			});

			return ev;
		},


		/**
		* register new gesture
		* @param   {Object}    gesture object, see gestures.js for documentation
		* @returns {Array}     gestures
		*/
		register: function register(gesture)
		{
			// add an enable gesture options if there is no given
			var options = gesture.defaults || {};
			if (options[gesture.name] === undefined)
			{
				options[gesture.name] = true;
			}

			// extend WDGestureEvenement default options with the WDGestureEvenement.gesture options
			WDGestureEvenement.utils.extend(WDGestureEvenement.defaults, options, true);

			// set its index
			gesture.index = gesture.index || 1000;

			// add WDGestureEvenement.gesture to the list
			this.gestures.push(gesture);

			// sort the list by index
			this.gestures.sort(function(a, b)
			{
				if (a.index < b.index) { return -1; }
				if (a.index > b.index) { return 1; }
				return 0;
			});

			return this.gestures;
		}
	};


	/**
	* Drag
	* Move with x fingers (default 1) around on the page. Blocking the scrolling when
	* moving left and right is a good practice. When all the drag events are blocking
	* you disable scrolling on that area.
	* @events  drag, drapleft, dragright, dragup, dragdown
	*/
	WDGestureEvenement.gestures.Drag = {
		name: 'drag',
		index: 50,
		defaults: {
			drag_min_distance: 10,

			// Set correct_for_drag_min_distance to true to make the starting point of the drag
			// be calculated from where the drag was triggered, not from where the touch started.
			// Useful to avoid a jerk-starting drag, which can make fine-adjustments
			// through dragging difficult, and be visually unappealing.
			correct_for_drag_min_distance: true,

			// set 0 for unlimited, but this can conflict with transform
			drag_max_touches: 1,

			// prevent default browser behavior when dragging occurs
			// be careful with it, it makes the element a blocking element
			// when you are using the drag gesture, it is a good practice to set this true
			drag_block_horizontal: false,
			drag_block_vertical: false,

			// drag_lock_to_axis keeps the drag gesture on the axis that it started on,
			// It disallows vertical directions if the initial direction was horizontal, and vice versa.
			drag_lock_to_axis: false,

			// drag lock only kicks in when distance > drag_lock_min_distance
			// This way, locking occurs only when the distance has become large enough to reliably determine the direction
			drag_lock_min_distance: 25
		},

		triggered: false,
		handler: function dragGesture(ev, inst)
		{
			// current gesture isnt drag, but dragged is true
			// this means an other gesture is busy. now call dragend
			if (WDGestureEvenement.detection.current.name != this.name && this.triggered)
			{
				inst.trigger(this.name + 'end', ev);
				this.triggered = false;
				return;
			}

			// max touches
			if (inst.options.drag_max_touches > 0 &&
      ev.touches.length > inst.options.drag_max_touches)
			{
				return;
			}

			switch (ev.eventType)
			{
			case WDGestureEvenement.EVENT_START:
				this.triggered = false;
				break;

			case WDGestureEvenement.EVENT_MOVE:
				// when the distance we moved is too small we skip this gesture
				// or we can be already in dragging
				if (ev.distance < inst.options.drag_min_distance && WDGestureEvenement.detection.current.name != this.name)
				{
					return;
				}

				// we are dragging!
				if (WDGestureEvenement.detection.current.name != this.name)
				{
					WDGestureEvenement.detection.current.name = this.name;
					if (inst.options.correct_for_drag_min_distance && ev.distance > 0)
					{
						// When a drag is triggered, set the event center to drag_min_distance pixels from the original event center.
						// Without this correction, the dragged distance would jumpstart at drag_min_distance pixels instead of at 0.
						// It might be useful to save the original start point somewhere
						var factor = Math.abs(inst.options.drag_min_distance / ev.distance);
						WDGestureEvenement.detection.current.startEvent.center.pageX += ev.deltaX * factor;
						WDGestureEvenement.detection.current.startEvent.center.pageY += ev.deltaY * factor;

						// recalculate event data using new start point
						ev = WDGestureEvenement.detection.extendEventData(ev);
					}
				}

				// lock drag to axis?
				if (WDGestureEvenement.detection.current.lastEvent.drag_locked_to_axis || (inst.options.drag_lock_to_axis && inst.options.drag_lock_min_distance <= ev.distance))
				{
					ev.drag_locked_to_axis = true;
				}
				var last_direction = WDGestureEvenement.detection.current.lastEvent.direction;
				if (ev.drag_locked_to_axis && last_direction !== ev.direction)
				{
					// keep direction on the axis that the drag gesture started on
					if (WDGestureEvenement.utils.isVertical(last_direction))
					{
						ev.direction = (ev.deltaY < 0) ? WDGestureEvenement.DIRECTION_UP : WDGestureEvenement.DIRECTION_DOWN;
					}
					else
					{
						ev.direction = (ev.deltaX < 0) ? WDGestureEvenement.DIRECTION_LEFT : WDGestureEvenement.DIRECTION_RIGHT;
					}
				}

				// first time, trigger dragstart event
				if (!this.triggered)
				{
					inst.trigger(this.name + 'start', ev);
					this.triggered = true;
				}

				// trigger normal event
				inst.trigger(this.name, ev);

				// direction event, like dragdown
				inst.trigger(this.name + ev.direction, ev);

				// block the browser events
				if ((inst.options.drag_block_vertical && WDGestureEvenement.utils.isVertical(ev.direction)) ||
      (inst.options.drag_block_horizontal && !WDGestureEvenement.utils.isVertical(ev.direction)))
				{
					ev.preventDefault();
				}
				break;

			case WDGestureEvenement.EVENT_END:
				// trigger dragend
				if (this.triggered)
				{
					inst.trigger(this.name + 'end', ev);
				}

				this.triggered = false;
				break;
			}
		}
	};

	/**
	* Hold
	* Touch stays at the same place for x time
	* @events  hold
	*/
	WDGestureEvenement.gestures.Hold = {
		name: 'hold',
		index: 10,
		defaults: {
			hold_timeout: 500,
			hold_threshold: 1
		},
		timer: null,
		handler: function holdGesture(ev, inst)
		{
			switch (ev.eventType)
			{
			case WDGestureEvenement.EVENT_START:
				// clear any running timers
				clearTimeout(this.timer);

				// set the gesture so we can check in the timeout if it still is
				WDGestureEvenement.detection.current.name = this.name;

				// set timer and if after the timeout it still is hold,
				// we trigger the hold event
				this.timer = setTimeout(function()
				{
					if (WDGestureEvenement.detection.current.name == 'hold')
					{
						inst.trigger('hold', ev);
					}
				}, inst.options.hold_timeout);
				break;

			// when you move or end we clear the timer   
			case WDGestureEvenement.EVENT_MOVE:
				if (ev.distance > inst.options.hold_threshold)
				{
					clearTimeout(this.timer);
				}
				break;

			case WDGestureEvenement.EVENT_END:
				clearTimeout(this.timer);
				break;
			}
		}
	};

	/**
	* Release
	* Called as last, tells the user has released the screen
	* @events  release
	*/
	WDGestureEvenement.gestures.Release = {
		name: 'release',
		index: Infinity,
		handler: function releaseGesture(ev, inst)
		{
			if (ev.eventType == WDGestureEvenement.EVENT_END)
			{
				inst.trigger(this.name, ev);
			}
		}
	};

	/**
	* Swipe
	* triggers swipe events when the end velocity is above the threshold
	* @events  swipe, swipeleft, swiperight, swipeup, swipedown
	*/
	WDGestureEvenement.gestures.Swipe = {
		name: 'swipe',
		index: 40,
		defaults: {
			// set 0 for unlimited, but this can conflict with transform
			swipe_min_touches: 1,
			swipe_max_touches: 1,
			swipe_velocity: 0.7
		},
		handler: function swipeGesture(ev, inst)
		{
			if (ev.eventType == WDGestureEvenement.EVENT_END)
			{
				// max touches
				if (inst.options.swipe_max_touches > 0 &&
        ev.touches.length < inst.options.swipe_min_touches &&
        ev.touches.length > inst.options.swipe_max_touches)
				{
					return;
				}

				// when the distance we moved is too small we skip this gesture
				// or we can be already in dragging
				if (ev.velocityX > inst.options.swipe_velocity ||
        ev.velocityY > inst.options.swipe_velocity)
				{
					// trigger swipe events
					inst.trigger(this.name, ev);
					inst.trigger(this.name + ev.direction, ev);
				}
			}
		}
	};

	/**
	* Tap/DoubleTap
	* Quick touch at a place or double at the same place
	* @events  tap, doubletap
	*/
	WDGestureEvenement.gestures.Tap = {
		name: 'tap',
		index: 100,
		defaults: {
			tap_max_touchtime: 250,
			tap_max_distance: 10,
			tap_always: true,
			doubletap_distance: 20,
			doubletap_interval: 300
		},
		handler: function tapGesture(ev, inst)
		{
			if (ev.eventType == WDGestureEvenement.EVENT_END && ev.srcEvent.type != 'touchcancel')
			{
				// previous gesture, for the double tap since these are two different gesture detections
				var prev = WDGestureEvenement.detection.previous,
        did_doubletap = false;

				// when the touchtime is higher then the max touch time
				// or when the moving distance is too much
				if (ev.deltaTime > inst.options.tap_max_touchtime ||
        ev.distance > inst.options.tap_max_distance)
				{
					return;
				}

				// check if double tap
				if (prev && prev.name == 'tap' &&
        (ev.timeStamp - prev.lastEvent.timeStamp) < inst.options.doubletap_interval &&
        ev.distance < inst.options.doubletap_distance)
				{
					inst.trigger('doubletap', ev);
					did_doubletap = true;
				}

				// do a single tap
				if (!did_doubletap || inst.options.tap_always)
				{
					WDGestureEvenement.detection.current.name = 'tap';
					inst.trigger(WDGestureEvenement.detection.current.name, ev);
				}
			}
		}
	};

	/**
	* Touch
	* Called as first, tells the user has touched the screen
	* @events  touch
	*/
	WDGestureEvenement.gestures.Touch = {
		name: 'touch',
		index: -Infinity,
		defaults: {
			// call preventDefault at touchstart, and makes the element blocking by
			// disabling the scrolling of the page, but it improves gestures like
			// transforming and dragging.
			// be careful with using this, it can be very annoying for users to be stuck
			// on the page
			prevent_default: false,

			// disable mouse events, so only touch (or pen!) input triggers events
			prevent_mouseevents: false
		},
		handler: function touchGesture(ev, inst)
		{
			if (inst.options.prevent_mouseevents && ev.pointerType == WDGestureEvenement.POINTER_MOUSE)
			{
				ev.stopDetect();
				return;
			}

			if (inst.options.prevent_default)
			{
				ev.preventDefault();
			}

			if (ev.eventType == WDGestureEvenement.EVENT_START)
			{
				inst.trigger(this.name, ev);
			}
		}
	};

	/**
	* Transform
	* User want to scale or rotate with 2 fingers
	* @events  transform, pinch, pinchin, pinchout, rotate
	*/
	WDGestureEvenement.gestures.Transform = {
		name: 'transform',
		index: 45,
		defaults: {
			// factor, no scale is 1, zoomin is to 0 and zoomout until higher then 1
			transform_min_scale: 0.01,
			// rotation in degrees
			transform_min_rotation: 1,
			// prevent default browser behavior when two touches are on the screen
			// but it makes the element a blocking element
			// when you are using the transform gesture, it is a good practice to set this true
			transform_always_block: false
		},
		triggered: false,
		handler: function transformGesture(ev, inst)
		{
			// current gesture isnt drag, but dragged is true
			// this means an other gesture is busy. now call dragend
			if (WDGestureEvenement.detection.current.name != this.name && this.triggered)
			{
				inst.trigger(this.name + 'end', ev);
				this.triggered = false;
				return;
			}

			// atleast multitouch
			if (ev.touches.length < 2)
			{
				return;
			}

			// prevent default when two fingers are on the screen
			if (inst.options.transform_always_block)
			{
				ev.preventDefault();
			}

			switch (ev.eventType)
			{
			case WDGestureEvenement.EVENT_START:
				this.triggered = false;
				break;

			case WDGestureEvenement.EVENT_MOVE:
				var scale_threshold = Math.abs(1 - ev.scale);
				var rotation_threshold = Math.abs(ev.rotation);

				// when the distance we moved is too small we skip this gesture
				// or we can be already in dragging
				if (scale_threshold < inst.options.transform_min_scale &&
      rotation_threshold < inst.options.transform_min_rotation)
				{
					return;
				}

				// we are transforming!
				WDGestureEvenement.detection.current.name = this.name;

				// first time, trigger dragstart event
				if (!this.triggered)
				{
					inst.trigger(this.name + 'start', ev);
					this.triggered = true;
				}

				inst.trigger(this.name, ev); // basic transform event

				// trigger rotate event
				if (rotation_threshold > inst.options.transform_min_rotation)
				{
					inst.trigger('rotate', ev);
				}

				// trigger pinch event
				if (scale_threshold > inst.options.transform_min_scale)
				{
					inst.trigger('pinch', ev);
					inst.trigger('pinch' + ((ev.scale < 1) ? 'in' : 'out'), ev);
				}
				break;

			case WDGestureEvenement.EVENT_END:
				// trigger dragend
				if (this.triggered)
				{
					inst.trigger(this.name + 'end', ev);
				}

				this.triggered = false;
				break;
			}
		}
	};

	// Based off Lo-Dash's excellent UMD wrapper (slightly modified) - https://github.com/bestiejs/lodash/blob/master/lodash.js#L5515-L5543
	// some AMD build optimizers, like r.js, check for specific condition patterns like the following:
	if (typeof define == 'function' && typeof define.amd == 'object' && define.amd)
	{
		// define as an anonymous module
		define(function()
		{
			return WDGestureEvenement;
		});
		// check for `exports` after `define` in case a build optimizer adds an `exports` object
	}
	else if (typeof module === 'object' && typeof module.exports === 'object')
	{
		module.exports = WDGestureEvenement;
	}
	else
	{
		window.WDGestureEvenement = WDGestureEvenement;
	}
})(this);

(function(WDGestureEvenement)
{
	/**
	* enable multitouch on the desktop by pressing the shiftkey
	* the other touch goes in the opposite direction so the center keeps at its place
	* it's recommended to enable WDGestureEvenement.debug.showTouches for this one
	*/
	WDGestureEvenement.plugins.fakeMultitouch = function()
	{
		// keeps the start position to keep it centered
		var start_pos = false;

		// test for msMaxTouchPoints to enable this for IE10 with only one pointer (a mouse in all/most cases)
		WDGestureEvenement.HAS_POINTEREVENTS = navigator.msPointerEnabled &&
      navigator.msMaxTouchPoints && navigator.msMaxTouchPoints >= 1;

		/**
		* overwrites WDGestureEvenement.event.getTouchList.
		* @param   {Event}     ev
		* @param   TOUCHTYPE   type
		* @return  {Array}     Touches
		*/
		WDGestureEvenement.event.getTouchList = function(ev, eventType)
		{
			// get the fake pointerEvent touchlist
			if (WDGestureEvenement.HAS_POINTEREVENTS)
			{
				return WDGestureEvenement.PointerEvent.getTouchList();
			}
			// get the touchlist
			else if (ev.touches)
			{
				return ev.touches;
			}

			// reset on start of a new touch
			if (eventType == WDGestureEvenement.EVENT_START)
			{
				start_pos = false;
			}

			// when the shift key is pressed, multitouch is possible on desktop
			// why shift? because ctrl and alt are taken by osx and linux
			if (ev.shiftKey)
			{
				// on touchstart we store the position of the mouse for multitouch
				if (!start_pos)
				{
					start_pos = {
						pageX: ev.pageX,
						pageY: ev.pageY
					};
				}

				var distance_x = start_pos.pageX - ev.pageX;
				var distance_y = start_pos.pageY - ev.pageY;

				// fake second touch in the opposite direction
				return [
          {
          	identifier: 1,
          	pageX: start_pos.pageX - distance_x - 50,
          	pageY: start_pos.pageY - distance_y - -50,
          	target: ev.target
          },
          {
          	identifier: 2,
          	pageX: start_pos.pageX + distance_x - -50,
          	pageY: start_pos.pageY + distance_y - 50,
          	target: ev.target
          }
        ];
			}
			// normal single touch
			else
			{
				start_pos = false;
				return [
          {
          	identifier: 1,
          	pageX: ev.pageX,
          	pageY: ev.pageY,
          	target: ev.target
          }
        ];
			}
		};
	};

})(window.WDGestureEvenement);

//Branchement simulation multi-touch avec souris et touche majuscule
WDGestureEvenement.plugins.fakeMultitouch();

//Constantes direction gesture
WDGesture.prototype.GaucheADroite = 1;
WDGesture.prototype.DroiteAGauche = 2;
WDGesture.prototype.BasEnHaut = 11;
WDGesture.prototype.HautEnBas = 12;

//Constantes rep�re position
WDGesture.prototype.gpPage = 0;
WDGesture.prototype.gpEcran = 1;
WDGesture.prototype.gpChamp = 2;
WDGesture.prototype.gpImage = 3;

//Gesture en cours
WDGesture.prototype.goGesture = null;

//Constructeur gesture
//Entr�e :	sAlias		Alias de l'objet de gesture
//			bZoom		Indique si on g�re le zoom
//			nZoomMax	Facteur de zoom maximum (100 pour 100% de la taille de l'image originale)
//			bDoubleTap	Indique si gestion double tap
//			fScroll		Fonction traitement de scroll
//			fBalayage	Fonction traitement de balayage
//			fZoom		Fonction traitement de zoom
function WDGesture(sAlias, bZoom, nZoomMax, bDoubleTap, fScroll, fBalayage, fZoom)
{
	//Objet sur lequel on applique la gesture
	this.m_oObjet = document.getElementById(sAlias);
	//Objet de gestion des �v�nements de gesture
	this.m_oGesture = WDGestureEvenement(this.m_oObjet, { drag_min_distance: 0, prevent_default: true, transform_always_block: true, swipe_velocity: 0.03 });
	//Zoom
	this.m_bZoom = bZoom;
	//Zoom maximum
	this.m_nZoomMax = -1;
	//Abscisse
	this.m_nX = 0;
	//Ordonn�e
	this.m_nY = 0;
	//Largeur
	this.m_nLargeur = WDAnimSurImage.prototype.GetLargeur(this.m_oObjet);
	//Hauteur
	this.m_nHauteur = WDAnimSurImage.prototype.GetHauteur(this.m_oObjet);
	//Echelle
	this.m_nEchelle = 1;
	//Direction
	this.m_nDirection = 0;
	//Distance
	this.m_nDistance = 0;
	//Vitesse
	this.m_nVitesse = 0;
	//Nombre de pointeurs
	this.m_nNbPointeur = 0;
	//Indice pointeur en cours
	this.m_nIndicePointeurEnCours = 0;
	//Abscisse relative � l'�cran
	this.m_nXEcran = 0;
	//Ordonn�e relative � l'�cran
	this.m_nYEcran = 0;
	//Abscisse relative � la zone client
	this.m_nXClient = 0;
	//Ordonn�e relative � la zone client
	this.m_nYClient = 0;
	//Abscisse relative � l'objet
	this.m_nXObjet = 0;
	//Ordonn�e relative � l'objet
	this.m_nYObjet = 0;
	//Abscisse relative � l'image
	this.m_nXImage = 0;
	//Ordonn�e relative � l'image
	this.m_nYImage = 0;
	//Pointeurs
	this.m_oTabPointeur = null;
	//Initialisation changement
	this.InitChangement();
	//Objet ?
	if (this.m_oObjet != null)
	{
		//Oui => r�cup�ration parent objet
		var oParent = this.m_oObjet.parentNode;
		//Le parent est un div de limitation d'affichage ?
		if (WDAnimSurImage.prototype.bClip(oParent))
		{
			//Oui => le parent sera le div pour limitation affichage
			this.m_oDivLimite = oParent;
		}
		else
		{
			//Non => cr�ation div pour limitation affichage
			this.m_oDivLimite = oCreerDivSuperposable(this.m_oObjet.parentNode, true, false, true);
			//L'objet de gesture est fils de ce div de limitation d'affichage
			this.m_oDivLimite.appendChild(this.m_oObjet);
			//M�mes dimensions que l'objet pour le div de limitation d'affichage
			WDAnimSurImage.prototype.SetLargeur(this.m_oDivLimite, this.m_nLargeur);
			WDAnimSurImage.prototype.SetHauteur(this.m_oDivLimite, this.m_nHauteur);
		}
	}
	//Largeur affichage
	this.m_nLargeurAffichage = WDAnimSurImage.prototype.GetLargeur(this.m_oDivLimite);
	//Hauteur affichage
	this.m_nHauteurAffichage = WDAnimSurImage.prototype.GetHauteur(this.m_oDivLimite);
	//Mise � jour gesture en cours
	WDGesture.prototype.goGesture = this;
	//Objet pour �v�nement
	var oThis = this;
	//Branchement scroll
	this.m_oGesture.on("drag", function(oEvenement)
	{
		//Appel callback scroll ?
		if (oThis.bExecuteCallbackSouris(oEvenement, fScroll))
		{
			//Oui => r�cup�ration gesture �v�nement
			var oGesture = oThis.oEvenementGesture(oEvenement);
			//Appel traitement scroll
			fScroll(oEvenement, oThis.nDeplacementEvenementVersDeplacementWL(oGesture.deltaX), oThis.nDeplacementEvenementVersDeplacementWL(oGesture.deltaY));
		}
	});
	//Branchement balayage
	this.m_oGesture.on("swipe", function(oEvenement)
	{
		//Appel callback balayage ?
		if (oThis.bExecuteCallbackSouris(oEvenement, fBalayage))
		{
			//Oui => r�cup�ration gesture �v�nement
			var oGesture = oThis.oEvenementGesture(oEvenement);
			//Appel traitement balayage
			fBalayage(oEvenement, oThis.nVitesseEvenementVersVitesseWL(oGesture.velocityX), oThis.nVitesseEvenementVersVitesseWL(oGesture.velocityY));
		}
	});
	//Branchement fin scroll
	this.m_oGesture.on("release", function(/*oEvenement*/)
	{
		//Initialisation changement
		oThis.InitChangement();
	});
	//Gestion zoom ?
	if (bZoom)
	{
		//Calcul zoom maximum
		var oImage = new Image();
		//Traitement chargement image
		oImage.onload = function()
		{
			//R�cup�ration largeur image
			var nLargeurImage = this.width;
			//Largeur r�cup�r�e ?
			if (nLargeurImage > 0)
			{
				//Oui => on calcule le zoom maximum
				oThis.m_nZoomMax = ((nLargeurImage * nZoomMax) / oThis.m_nLargeur);
			}
		};
		//Chargement image
		oImage.src = this.m_oObjet.src;
		//Oui => branchement zoom
		this.m_oGesture.on("transform", function(oEvenement)
		{
			//R�cup�ration gesture �v�nement
			var oGesture = oThis.oEvenementGesture(oEvenement);
			//Gesture ?
			if (oGesture == null)
			{
				//Non => rien � faire
				return;
			}
			//Oui => r�cup�ration �chelle �v�nement
			var nEchelleEv = oGesture.scale;
			//Oui => �chelle
			oThis.m_nEchelle = Math.max(1, oThis.m_nEchelle * nEchelleEv / oThis.m_nChangementEchelle);
			//Zoom maximum et zoom trop grand ?
			if ((oThis.m_nZoomMax > 0) && (oThis.m_nEchelle > oThis.m_nZoomMax))
			{
				//Oui => on limite le zoom � la valeur maximum
				oThis.m_nEchelle = oThis.m_nZoomMax;
			}
			//R�cup�ration changement �chelle
			oThis.m_nChangementEchelle = nEchelleEv;
			//Mise � jour d�placement
			oThis.MajDeplacement(oEvenement);
			//Traitement zoom ?
			if (fZoom != null)
			{
				//Oui => calcul distance entre pointeurs
				var nDistance = 0;
				var oTabTouche = oThis.m_oTabPointeur;
				if ((oTabTouche != null) && (oTabTouche.length > 1))
				{
					oThis.m_nDistance = Math.round(Math.sqrt(oThis.nCarreDiffCoord(oTabTouche[0].pageX, oTabTouche[1].pageX) + oThis.nCarreDiffCoord(oTabTouche[0].pageY, oTabTouche[1].pageY)));
				}
				//Appel traitement zoom
				fZoom(oEvenement, oThis.m_nDistance);
			}
		});
		//Gestion double tap ?
		if (bDoubleTap)
		{
			//Oui => branchement double tap
			this.m_oGesture.on("doubletap", function(oEvenement)
			{
				//Initialisation zoom
				oThis.m_nEchelle = (oThis.m_nEchelle > 1) ? 1 : ((oThis.m_nZoomMax > 0) ? oThis.m_nZoomMax : 2);
				//Mise � jour d�placement
				oThis.MajDeplacement(oEvenement);
			});
		}
	}
};

//Indique si on ex�cute une callback d'�v�nement souris
//Entr�e :	oEvenement	Ev�nement souris
//			fCallback	Callback
//Sortie :	true si appel callback, false sinon
WDGesture.prototype.bExecuteCallbackSouris = function bExecuteCallbackSouris(oEvenement, fCallback)
{
	//D�placement possible ?
	if ((this.m_nEchelle <= 1) && (this.m_nLargeur <= this.m_nLargeurAffichage) && (this.m_nHauteur <= this.m_nHauteurAffichage))
	{
		//Non => pas d'appel de callback
		return false;
	}
	//Oui => mise � jour d�placement
	this.MajDeplacement(oEvenement);
	//R�cup�ration gesture �v�nement
	var oGesture = this.oEvenementGesture(oEvenement);
	//Gesture ?
	if (oGesture != null)
	{
		//Oui => traitement scroll ?
		if (fCallback != null)
		{
			//Oui => appel callback
			return true;
		}
	}
	//Non pas d'appel de callback
	return false;
};

//Carr� de la diff�rence de coordonn�es
//Entr�e :	nCoord1	Premi�re coordonn�e
//			nCoord2	Deuxi�me coordonn�e
//Sortie :	Carr� de la diff�rence des coordonn�es
WDGesture.prototype.nCarreDiffCoord = function nCarreDiffCoord(nCoord1, nCoord2)
{
	return Math.pow(nCoord1 - nCoord2, 2);
};

//Initialisation changement
WDGesture.prototype.InitChangement = function InitChangement()
{
	//Initialisation d�placement horizontal
	this.m_nDeplacementX = 0;
	//Initialisation d�placement vertical
	this.m_nDeplacementY = 0;
	//Initialisation changement �chelle
	this.m_nChangementEchelle = 1;
};

//Variable gesture
//Entr�e :	nVariable	Indice variable d�sir�e
//Sortie :	Valeur variable d�sir�e
WDGesture.prototype.GetVariable = function GetVariable(nVariable)
{
	//R�cup�ration gesture en cours
	var oGesture = WDGesture.prototype.goGesture;
	//Gesture en cours ?
	if (oGesture == null)
	{
		//Non => rien � faire
		return 0;
	}
	//Oui => la propri�t� d�sir�e est
	switch (nVariable)
	{
	//Direction :      
	case 0:
		return oGesture.m_nDirection;
		//Distance :
	case 1:
		return oGesture.m_nDistance;
		//Vitesse :
	case 2:
		return oGesture.m_nVitesse;
	}
};

//Transformation
WDGesture.prototype.Transform = function Transform()
{
	//Oui => translation
	var sTransform = "translate3d(" + this.m_nX + "px," + this.m_nY + "px,0)";
	//Gestion zoom ?
	if (this.m_bZoom)
	{
		//Oui => zoom
		sTransform += " scale3d(" + this.m_nEchelle + "," + this.m_nEchelle + ",1)";
	}
	//Transformation
	WDAnimSurImage.prototype.SetTransform(this.m_oObjet, sTransform);
};

//D�placement maximum
//Entr�e :	nDim			Dimension (largeur ou hauteur)
//Sortie :	D�placement maximum dans la dimension (largeur ou hauteur)
WDGesture.prototype.nDeplacementMax = function nDeplacementMax(nDim)
{
	//Maximum la moiti� de ce qui est ajout� par grossissement
	return ((this.m_nEchelle - 1) * nDim / 2);
};

//D�placement
//Entr�e :	nDeplacementAvant	Ancienne valeur d�placement
//			nDeplacementEvAvant	Ancienne valeur d�placement �v�nement
//			nDeplacementEv		Valeur d�placement �v�nement
//			nDimension			Dimension (largeur ou hauteur)
//			nDimensionAffichage	Dimension affichage (largeur ou hauteur)
//Sortie :	D�placement encadr� par valeur maximum
WDGesture.prototype.nDeplacement = function nDeplacement(nDeplacementAvant, nDeplacementEvAvant, nDeplacementEv, nDimension, nDimensionAffichage)
{
	//Calcul d�placement maximum
	var nMax = this.nDeplacementMax(nDimension, nDimensionAffichage);
	//D�placement encadr� par valeur maximum
	return Math.min(Math.max(nDeplacementAvant - nDeplacementEvAvant + nDeplacementEv, -nMax - (nDimension - nDimensionAffichage)), nMax);
};

//Gesture �v�nement
//Entr�e :	oEvenement	Ev�nement
//Sortie :	Gesture de l'�v�nement si �v�nement gesture, null sinon
WDGesture.prototype.oEvenementGesture = function oEvenementGesture(oEvenement)
{
	//Indique si �v�nement de gesture
	return ((oEvenement != null) && (oEvenement.gesture != null)) ? oEvenement.gesture : null;
};

//Mise � jour direction
//Entr�e :	oEvenement	Ev�nement
WDGesture.prototype.MajDirection = function MajDirection(oEvenement)
{
	//R�cup�ration gesture �v�nement
	var oGesture = this.oEvenementGesture(oEvenement);
	//Gesture ?
	if (oGesture == null)
	{
		//Non => rien � faire
		return;
	}
	//Oui => mise � jour direction
	switch (oGesture.direction)
	{
	case "up":
		this.m_nDirection = this.BasEnHaut;
		break;
	case "down":
		this.m_nDirection = this.HautEnBas;
		break;
	case "left":
		this.m_nDirection = this.DroiteAGauche;
		break;
	case "right":
		this.m_nDirection = this.GaucheADroite;
		break;
	}
};

//D�placement �v�nement vers d�placement WLangage
//Entr�e :	nDistanceEv	Distance �v�nement
//			D�placement �v�nement convertie en d�placement WLangage
WDGesture.prototype.nDeplacementEvenementVersDeplacementWL = function nDeplacementEvenementVersDeplacementWL(nDeplacementEv)
{
	//Conversion d�placement �v�nement
	return Math.round(nDeplacementEv);
};

//Mise � jour distance
//Entr�e :	oEvenement	Ev�nement
WDGesture.prototype.MajDistance = function MajDistance(oEvenement)
{
	//R�cup�ration gesture �v�nement
	var oGesture = this.oEvenementGesture(oEvenement);
	//Gesture ?
	if (oGesture == null)
	{
		//Non => rien � faire
		return;
	}
	//Oui => mise � jour distance
	switch (this.m_nDirection)
	{
	case this.GaucheADroite:
	case this.DroiteAGauche:
		this.m_nDistance = oGesture.deltaX;
		break;
	case this.BasEnHaut:
	case this.HautEnBas:
		this.m_nDistance = oGesture.deltaY;
		break;
	default:
		return;
	}
	//Conversion d�placement �v�nement en d�placement WLangage
	this.m_nDistance = this.nDeplacementEvenementVersDeplacementWL(this.m_nDistance);
};

//Conversion vitesse �v�nement en vitesse WLangage
//Entr�e :	nVitesse	Vitesse �v�nement
//Sortie :	Vitesse �v�nement convertie en vitesse WLangage
WDGesture.prototype.nVitesseEvenementVersVitesseWL = function nVitesseEvenementVersVitesseWL(nVitesse)
{
	return Math.round(nVitesse * 1000);
};

//Mise � jour vitesse
//Entr�e :	oEvenement	Ev�nement
WDGesture.prototype.MajVitesse = function MajVitesse(oEvenement)
{
	//R�cup�ration gesture �v�nement
	var oGesture = this.oEvenementGesture(oEvenement);
	//Gesture ?
	if (oGesture == null)
	{
		//Non => rien � faire
		return;
	}
	//Oui => mise � jour vitesse
	switch (this.m_nDirection)
	{
	case this.GaucheADroite:
	case this.DroiteAGauche:
		this.m_nVitesse = oGesture.velocityX;
		break;
	case this.BasEnHaut:
	case this.HautEnBas:
		this.m_nVitesse = oGesture.velocityY;
		break;
	default:
		return;
	}
	//Conversion vitesse �v�nement en vitesse WLangage
	this.m_nVitesse = this.nVitesseEvenementVersVitesseWL(this.m_nVitesse);
};

//Mise � jour nombre pointeurs
//Entr�e :	oEvenement	Ev�nement
WDGesture.prototype.MajNbPointeur = function MajNbPointeur(oEvenement)
{
	//R�cup�ration gesture �v�nement
	var oGesture = this.oEvenementGesture(oEvenement);
	//Gesture ?
	if (oGesture == null)
	{
		//Non => pas de pointeur
		return;
	}
	//Oui => r�cup�ration nombre pointeurs
	this.m_nNbPointeur = oGesture.touches.length;
};

//Mise � jour indice pointeur en cours
//Entr�e :	oEvenement	Ev�nement
WDGesture.prototype.MajIndicePointeurEnCours = function MajIndicePointeurEnCours(oEvenement)
{
	//R�cup�ration gesture �v�nement
	var oGesture = this.oEvenementGesture(oEvenement);
	//Gesture ?
	if (oGesture == null)
	{
		//Non => rien � faire
		return;
	}
	//Oui => r�cup�ration nombre pointeurs
	this.m_nIndicePointeurEnCours = (oGesture.touches.length > 0) ? 1 : 0;
};

//Conversion coordonn�e �v�nement relative � l'objet en coordonn�e relative � l'objet
//Entr�e :	oEvenement		Ev�nement
//			nCoordEvPage	Coordonn�e �v�nement relative � la page
//			bAbscisse		Indique si abscisse (ordonn�e si faux)
//Sortie : Coordonn�e relative � l'objet correspondant � la coordonn�e �v�nement relative � l'objet
WDGesture.prototype.nCoordEvObjetVersCoordObjet = function nCoordEvObjetVersCoordObjet(oEvenement, nCoordEvPage, bAbscisse)
{
	//Conversion coordonn�e �v�nement relative � l'objet en coordonn�e relative � l'objet
	//Objet cible de l'�v�nement
	var oObjetCible = oEvenement.target;
	//Coordonn�e champ
	var nCoordChamp = bAbscisse ? oObjetCible.offsetLeft : oObjetCible.offsetTop;
	//Balise body
	var oBody = oObjetCible.ownerDocument.body;
	//Parcours des parents
	while (1)
	{
		//Parent suivant
		var oParent = oObjetCible.offsetParent;
		oObjetCible = (oParent != null) ? oParent : oObjetCible.parentNode;
		//Pas de parent ou body ?
		if ((oObjetCible == null) || (oObjetCible == oBody))
		{
			//Oui => on arr�te le parcours
			break;
		}
		//Coordonn�e parent
		var nCoordParent = bAbscisse ? oObjetCible.offsetLeft : oObjetCible.offsetTop;
		//Ajout coordonn�e parent � coordonn�e champ
		if (nCoordParent !== undefined)
		{
			nCoordChamp += nCoordParent;
		}
	}
	return (bAbscisse ? window.pageXOffset : window.pageYOffset) + (bAbscisse ? oEvenement.clientX : oEvenement.clientY) - nCoordChamp - nCoordEvPage;
};

//Conversion coordonn�e relative � l'objet en coordonn�e relative � l'image
//Entr�e :	nCoordObjet		Coordonn�e relative � l'objet
//			nDimension		Dimension (largeur ou hauteur)
//			nCoord			Coordonn�e de l'image
//Sortie : Coordonn�e relative � l'image correspondant � la coordonn�e relative � l'objet
WDGesture.prototype.nCoordObjetVersCoordImage = function nCoordObjetVersCoordImage(nCoordObjet, nDimension, nCoord)
{
	//Conversion coordonn�e relative � l'objet en coordonn�e relative � l'image
	return Math.round((nCoordObjet + ((nDimension * (this.m_nEchelle - 1)) / 2) - nCoord) / this.m_nEchelle);
};

//Mise � jour pointeurs
//Entr�e :	oEvenement	Ev�nement
WDGesture.prototype.MajPointeur = function MajPointeur(oEvenement)
{
	//R�cup�ration gesture �v�nement
	var oGesture = this.oEvenementGesture(oEvenement);
	//Gesture ?
	if (oGesture == null)
	{
		//Non => rien � faire
		return;
	}
	//Oui => r�cup�ration pointeurs
	this.m_oTabPointeur = oGesture.touches;
	//R�cup�ration �v�nement
	var oEvenementPointeur = oGesture.srcEvent;
	//Les iPad ne mettent pas les coordonn�es �cran et client dans l'�v�nement touch, mais dans les pointeurs associ�s
	if (oEvenementPointeur.screenX == undefined)
	{
		oEvenementPointeur = oEvenementPointeur.touches.item(0);
		if (oEvenementPointeur == null)
		{
			return;
		}
	}
	//R�cup�ration coordonn�es relatives �cran
	this.m_nXEcran = oEvenementPointeur.screenX - oEvenementPointeur.pageX;
	this.m_nYEcran = oEvenementPointeur.screenY - oEvenementPointeur.pageY;
	//R�cup�ration coordonn�es relatives zone client
	this.m_nXClient = oEvenementPointeur.clientX - oEvenementPointeur.pageX;
	this.m_nYClient = oEvenementPointeur.clientY - oEvenementPointeur.pageY;
	//R�cup�ration coordonn�es relatives objet
	this.m_nXObjet = this.nCoordEvObjetVersCoordObjet(oEvenementPointeur, oEvenementPointeur.pageX, true);
	this.m_nYObjet = this.nCoordEvObjetVersCoordObjet(oEvenementPointeur, oEvenementPointeur.pageY, false);
	//R�cup�ration coordonn�es relatives image
	this.m_nXImage = this.nCoordObjetVersCoordImage(this.m_nXObjet, this.m_nLargeur, this.m_nX);
	this.m_nYImage = this.nCoordObjetVersCoordImage(this.m_nYObjet, this.m_nHauteur, this.m_nY);
};

//Mise � jour variable
//Entr�e :	oEvenement	Ev�nement
WDGesture.prototype.MajVariable = function MajVariable(oEvenement)
{
	//Mise � jour direction
	this.MajDirection(oEvenement);
	//Mise � jour distance
	this.MajDistance(oEvenement);
	//Mise � jour vitesse
	this.MajVitesse(oEvenement);
	//Mise � jour nombre pointeurs
	this.MajNbPointeur(oEvenement);
	//Mise � jour indice pointeur en cours
	this.MajIndicePointeurEnCours(oEvenement);
	//Mise � jour pointeurs
	this.MajPointeur(oEvenement);
};

//Mise � jour d�placement
//Entr�e :	oEvenement	Ev�nement
WDGesture.prototype.MajDeplacement = function MajDeplacement(oEvenement)
{
	//R�cup�ration gesture �v�nement
	var oGesture = this.oEvenementGesture(oEvenement);
	//Gesture ?
	if (oGesture == null)
	{
		//Non => rien � faire
		return;
	}
	//Oui => mise � jour variable
	this.MajVariable(oEvenement);
	//Mise � jour gesture en cours
	WDGesture.prototype.goGesture = this;
	//Mise � jour d�placement horizontal
	this.m_nX = this.nDeplacement(this.m_nX, this.m_nDeplacementX, oGesture.deltaX, this.m_nLargeur, this.m_nLargeurAffichage);
	//Mise � jour d�placement vertical
	this.m_nY = this.nDeplacement(this.m_nY, this.m_nDeplacementY, oGesture.deltaY, this.m_nHauteur, this.m_nHauteurAffichage);
	//R�cup�ration d�placement horizontal
	this.m_nDeplacementX = oGesture.deltaX;
	//R�cup�ration d�placement vertical
	this.m_nDeplacementY = oGesture.deltaY;
	//On applique la transformation
	this.Transform();
};

//Nombre de pointeurs
WDGesture.prototype.GesteNbPointeur = function GesteNbPointeur()
{
	//R�cup�ration gesture en cours
	var oGesture = WDGesture.prototype.goGesture;
	//Gesture en cours ?
	if (oGesture == null)
	{
		//Non => pas de pointeur
		return 0;
	}
	//Oui => nombre de pointeurs
	return oGesture.m_nNbPointeur;
};

//Indice pointeur en cours
WDGesture.prototype.GestePointeurEncours = function GestePointeurEncours()
{
	//R�cup�ration gesture en cours
	var oGesture = WDGesture.prototype.goGesture;
	//Gesture en cours ?
	if (oGesture == null)
	{
		//Non => pas de pointeur en cours
		return 0;
	}
	//Oui => indice pointeur en cours
	return oGesture.m_nIndicePointeurEnCours;
};

//Position pointeur
//Entr�e :	nIndicePointeur		Indice pointeur dont on veut la position (1 si non pr�cis�)
//			nReperePosition		Rep�re par rapport auquel on veut la position (par rapport au champ si non pr�cis�)
//			bVerticale			Indique si on veut la position horizontale
//Sortie :	Position d�sir�e du pointeur d�sir� par rapport au rep�re d�sir�
WDGesture.prototype.GestePos = function GestePos(nIndicePointeur, nReperePosition, bVerticale)
{
	//R�cup�ration gesture en cours
	var oGesture = WDGesture.prototype.goGesture;
	//Gesture en cours ?
	if (oGesture == null)
	{
		//Non => pas de position
		return -1;
	}
	//R�cup�ration indice pointeur
	nIndicePointeur = (nIndicePointeur != undefined) ? (nIndicePointeur - 1) : 0;
	//R�cup�ration tableau pointeurs
	var oTabPointeur = oGesture.m_oTabPointeur;
	//Indice pointeur correct ?
	if (nIndicePointeur > oTabPointeur.length)
	{
		//Non => pas de position
		return -1;
	}
	//R�cup�ration pointeur
	var oPointeur = oTabPointeur[nIndicePointeur];
	//R�cup�ration position
	var nPosition = bVerticale ? oPointeur.pageY : oPointeur.pageX;
	//Position en fonction du rep�re d�sir�
	switch (nReperePosition)
	{
	case oGesture.gpEcran:
		return nPosition + (bVerticale ? oGesture.m_nYEcran : oGesture.m_nXEcran);
	case oGesture.gpPage:
		return nPosition + (bVerticale ? oGesture.m_nYClient : oGesture.m_nXClient);
	case oGesture.gpImage:
		return Math.round((nPosition + (bVerticale ? oGesture.m_nYImage : oGesture.m_nXImage)) / oGesture.m_nEchelle);
	default:
		return nPosition + (bVerticale ? oGesture.m_nYObjet : oGesture.m_nXObjet);
	}
};

//Position horizontale pointeur
//Entr�e :	nIndicePointeur		Indice pointeur dont on veut la position (1 si non pr�cis�)
//			nReperePosition		Rep�re par rapport auquel on veut la position (par rapport au champ si non pr�cis�)
//Sortie :	Position horizontale du pointeur d�sir� par rapport au rep�re d�sir�
WDGesture.prototype.GestePosX = function GestePosX(nIndicePointeur, nReperePosition)
{
	return WDGesture.prototype.GestePos(nIndicePointeur, nReperePosition);
};

//Position verticale pointeur
//Entr�e :	nIndicePointeur		Indice pointeur dont on veut la position (1 si non pr�cis�)
//			nReperePosition		Rep�re par rapport auquel on veut la position (par rapport au champ si non pr�cis�)
//Sortie :	Position verticale du pointeur d�sir� par rapport au rep�re d�sir�
WDGesture.prototype.GestePosY = function GestePosY(nIndicePointeur, nReperePosition)
{
	return WDGesture.prototype.GestePos(nIndicePointeur, nReperePosition, true);
};
