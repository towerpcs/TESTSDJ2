// WDSaisieRiche.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS bIE
// - WDChamp.js
///#GLOBALS WDChamp WDChampParametresHote
// - WDTable.js
///#GLOBALS WDTable

// Classe de base de manipulation des boutons
// Sert aussi pour les boutons d'action simple
function WDBarreBouton (oObjetParent, oBouton, sCommande, oParamCommande)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		this.m_oObjetParent = oObjetParent;
		this.m_oBouton = oBouton;
		this.m_sCommande = sCommande;
		this.m_oParamCommande = oParamCommande;

		// Hook les methodes des boutons
		var oThis = this;
		this.m_oBouton.onmouseover = function(oEvent) { oThis.OnMouseOver(oEvent || event); };
		this.m_oBouton.onmouseout = function(oEvent) { oThis.OnMouseOut(oEvent || event); };
		this.m_oBouton.onclick = function(oEvent) { oThis.OnClick(oEvent || event); };
	}
};

// Pas d'heritage

// Membre statiques
// Etat des boutons
WDBarreBouton.prototype.ms_eEtatNormal = 0;
WDBarreBouton.prototype.ms_eEtatSurvol = 1;
WDBarreBouton.prototype.ms_eEtatActif = 2;

// Declare les fonction une par une

// Hook les boutons
WDBarreBouton.prototype.vPrePlaceBarre = clWDUtil.m_pfVide;
WDBarreBouton.prototype.vPostPlaceBarre = clWDUtil.m_pfVide;

// Gestion de la souris
WDBarreBouton.prototype.OnMouseOver = function(oEvent)
{
	// La souris est au dessus du champ
	this.m_bSurvol = true;

	// Rafraichit le bouton
	this.RafEtatSimple(oEvent);
};

WDBarreBouton.prototype.OnMouseOut = function(oEvent)
{
	// La souris n'est plus au dessus du champ
	delete this.m_bSurvol;

	// Rafraichit le bouton
	this.RafEtatSimple(oEvent);
};

WDBarreBouton.prototype.OnClick = function(oEvent)
{
	// Execute la commande : methode definie dans les classes derivees
	this.ExecuteCommande(oEvent);

	// Rafraichit le bouton
	// => inutile car fait par la gestion des commandes
//	this.RafEtatSimple(oEvent);
};

// Execute la commande
WDBarreBouton.prototype.ExecuteCommande = function(oEvent)
{
	// Execute la fonction
	if (this.m_oObjetParent[this.m_sCommande])
	{
		this.m_oObjetParent[this.m_sCommande](oEvent, this.m_oParamCommande);
	}
};

// Rafraichit le bouton : methode par defaut
WDBarreBouton.prototype.RafEtatSimple = function(oEvent)
{
	this.RafEtat(oEvent, this.m_oObjetParent.oGetParamEtat(oEvent, false));
};

// Rafraichit le bouton : methode par defaut
WDBarreBouton.prototype.RafEtat = function(oEvent, oDataEtat)
{
	// Calcul de l'etat de survol du bouton
	var eEtat = this.__eGetEtatSurvol(this.m_bSurvol);

	// Applique ensuite l'etat d'activation
	eEtat = this._veGetEtatSpecifique(oEvent, eEtat, oDataEtat);

	// Puis dessine l'etat
	this.__DessineEtat(eEtat, this, this.m_oBouton, oDataEtat);
};

// Trouve l'�tat selon le survol
WDBarreBouton.prototype.__eGetEtatSurvol = function __eGetEtatSurvol(bSurvol)
{
	return bSurvol ? this.ms_eEtatSurvol : this.ms_eEtatNormal;
};

// Dessine un etat
WDBarreBouton.prototype.__DessineEtat = function __DessineEtat(eEtat, oObjetEtat, oObjetStyle/*, oDataEtat*/)
{
	// Puis dessine l'etat
	if (eEtat != oObjetEtat.m_eEtat)
	{
		if (eEtat != this.ms_eEtatNormal)
		{
			oObjetEtat.m_eEtat = eEtat;
		}
		else
		{
			delete oObjetEtat.m_eEtat;
		}
		oObjetStyle.style.backgroundColor = this.m_oObjetParent.sGetCouleurFond(eEtat);
	}
};

// Calcule l'etat specifique du bouton : inchange
WDBarreBouton.prototype._veGetEtatSpecifique = function _veGetEtatSpecifique(oEvent, eEtat/*, oDataEtat*/)
{
	return eEtat;
};


// Manipulation d'un bouton On/Off du champ de saisie
function WDBarreBoutonOnOff (/*oObjetParent*//*, oBouton*//*, sCommande*//*, oParamCommande*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDBarreBouton.prototype.constructor.apply(this, arguments);
	}
};

// Declare l'heritage
WDBarreBoutonOnOff.prototype = new WDBarreBouton();
// Surcharge le constructeur qui a ete efface
WDBarreBoutonOnOff.prototype.constructor = WDBarreBoutonOnOff;

// Declare les fonction une par une

// Applique ensuite l'etat d'activation
WDBarreBoutonOnOff.prototype._veGetEtatSpecifique = function _veGetEtatSpecifique(oEvent, eEtat, oDataEtat)
{
	// Si on a un etat surcharge
	// Appele la methode des classes derive de calcul de l'etat
	if (this.bActif(oEvent, oDataEtat))
	{
		return this.ms_eEtatActif;
	}
	else
	{
		return WDBarreBouton.prototype._veGetEtatSpecifique.apply(this, arguments);
	}
};

// Pas de surcharge de l'etat par defaut
WDBarreBoutonOnOff.prototype.bEtatSurcharge = function(/*oEvent*//*, oDataEtat*/)
{
	return false;
};

// Manipulation d'un bouton dropdown du champ de saisie
function WDBarreBoutonPopup (oObjetParent, oBouton, sCommande, oParamCommande, oPopup)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDBarreBouton.prototype.constructor.apply(this, [oObjetParent, oBouton, sCommande, oParamCommande]);

		this.m_oPopup = oPopup;

		// Hook les methodes des boutons
		var oThis = this;
		this.m_oBouton.getElementsByTagName(oObjetParent.ms_tagBoutonClic)[0].onclick = function(oEvent) { oThis.OnClick(oEvent || event); };
		var fClickPopup = function(oEvent) { oThis.OnClickP(oEvent || event); return clWDUtil.bStopPropagation(oEvent); };

		// Et les clics de la popup
		var tabTD = this.m_oPopup.getElementsByTagName("td");
		// Utilise un parcours par index car sinon var/in liste des propri�t�s ind�sirables (length entre autre)
		var i;
		var nLimiteI = tabTD.length;
		for (i = 0; i < nLimiteI; i++)
		{
			tabTD[i].onmousedown = fClickPopup;
		}

		this.m_bSurvol = false;

		this.m_pfMouseOutSimule = function() { oThis.OnMouseOut(bIE ? { toElement: null} : { relatedTarget: null }); };
		this.m_tabZIndex = [];
	}
};

// Declare l'heritage
WDBarreBoutonPopup.prototype = new WDBarreBouton();
// Surcharge le constructeur qui a ete efface
WDBarreBoutonPopup.prototype.constructor = WDBarreBoutonPopup;

// Declare les fonction une par une

//balise du bouton ecoutant le clic
WDBarreBoutonPopup.prototype.ms_tagBoutonClic = "img";

// Surcharge des fonctions de survol
WDBarreBoutonPopup.prototype.OnMouseOver = function(/*oEvent*/)
{
	// Filtre les cas ou le focus reste dans le TD
	if (!this.m_bSurvol)
	{
		// Rappel de la methode de la classe de base
		WDBarreBouton.prototype.OnMouseOver.apply(this, arguments);
	}
};

WDBarreBoutonPopup.prototype.OnMouseOut = function(oEvent)
{
	// Detecte si la souris quitte vraiment l'objet
	var oDestination = bIE ? oEvent.toElement : oEvent.relatedTarget;
	if (clWDUtil.bEstFils(oDestination, this.m_oBouton))
	{
		// L'element qui recoit la souris est encore dans le bouton : ne masque pas la popup
		return;
	}

	// Masque la popup
	this.__SetDisplayPopup(false);

	// Rappel de la methode de la classe de base
	WDBarreBouton.prototype.OnMouseOut.apply(this, arguments);
};

// Execute la commande : affiche la popup
WDBarreBoutonPopup.prototype.ExecuteCommande = function(/*oEvent*/)
{
	this.__SetDisplayPopup(true);
};

// Clic sur un element : a definir dans les classes derivees
WDBarreBoutonPopup.prototype.OnClickP = function(oEvent)
{
	// Ferme la popup
	this.__SetDisplayPopup(false);

	// L'element n'est plus survole
	WDBarreBouton.prototype.OnMouseOut.apply(this, [oEvent]);

	// Pour une raison non claire, on a un evenement MouseOver appele apres avoir masque le menu : on le bloque
	clWDUtil.nSetTimeout(this.m_pfMouseOutSimule, clWDUtil.ms_nTimeoutNonImmediat100);
};

// Affiche ou masque le sous menu
WDBarreBoutonPopup.prototype.__SetDisplayPopup = function __SetDisplayPopup(bAffiche)
{
	clWDUtil.SetDisplay(this.m_oPopup, bAffiche);

	var oBarre = this.m_oObjetParent.m_oBarre;
	var oParent = oBarre;

	if (bAffiche)
	{
		// GP 25/03/2014 : TB74101 : Si on affiche la popup : tente de la faire passer au dessus de tout
		// => Masque les barres
		if (!this.m_tabZIndex.length)
		{
			while ((oParent = oParent.parentNode))
			{
				if ((oParent == document.body) || clWDUtil.bBaliseEstTag(oParent, "form"))
				{
					break;
				}
				this.m_tabZIndex.push(oParent.style.zIndex);
				oParent.style.zIndex = "991";
			}
		}
	}
	else
	{
		// Si on masque la popup : supprime ce que l'on a modifi� pour la faire passer au dessus de tout
		if (this.m_tabZIndex.length)
		{
			var nPos = 0;
			while ((oParent = oParent.parentNode))
			{
				var sZIndex = this.m_tabZIndex[nPos++];
				if ((oParent == document.body) || clWDUtil.bBaliseEstTag(oParent, "form") || (undefined == sZIndex))
				{
					break;
				}
				oParent.style.zIndex = sZIndex;
			}
			this.m_tabZIndex.length = 0;
		}
	}
};

// Manipulation d'une popup "menu"
function WDBarreBoutonPopupMenu (oObjetParent, oBouton, sCommande, oPopup, tabOptions)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDBarreBoutonPopup.prototype.constructor.apply(this, [oObjetParent, oBouton, sCommande, null, oPopup]);

		// Memorise le tableau des options
		this.m_tabOptions = tabOptions;

		// Calcul les fonctions
		var oThis = this;
		var fOnMouseOver = function(oEvent) { oThis.OnMouseOverMenu(oEvent || event); };
		var fOnMouseOut = function(oEvent) { oThis.OnMouseOutMenu(oEvent || event); };

		// Et fixe le texte dans les options
		var i;
		var nLimiteI = this.m_tabOptions.length;
		for (i = 0; i < nLimiteI; i++)
		{
			var oSPAN = document.createElement("span");
			var sTexte = this.m_tabOptions[i].sTexte;
			var oTexte = document.createTextNode(sTexte);
			oSPAN.appendChild(oTexte);
			var oTD = this.m_tabOptions[i].oTD;
			oTD.appendChild(oSPAN);
			oTD.noWrap = "true";
			oTD.onmouseover = fOnMouseOver;
			oTD.onmouseout = fOnMouseOut;
			// Force le texte dans le ALT des images
			var oImg = oTD.getElementsByTagName(oObjetParent.ms_tagBoutonClic)[0];
			if (oImg)
			{
				oImg.alt = sTexte;
				oImg.title = sTexte;
			}
		}
	}
};

// Declare l'heritage
WDBarreBoutonPopupMenu.prototype = new WDBarreBoutonPopup();
// Surcharge le constructeur qui a ete efface
WDBarreBoutonPopupMenu.prototype.constructor = WDBarreBoutonPopupMenu;
WDBarreBoutonPopupMenu.prototype.m_nOptionSurvol = -1;

// Declare les fonction une par une

WDBarreBoutonPopupMenu.prototype.OnMouseOverMenu = function(oEvent)
{
	// Indique quelle option est survolee
	var nOptionSurvol = this.__nGetOptionEvent(oEvent);
	if (this.m_nOptionSurvol != nOptionSurvol)
	{
		this.m_nOptionSurvol = nOptionSurvol;
	}

	// Rafraichit les options du sous menu si besoin
	this.__RafEtatOptions(oEvent);
};

WDBarreBoutonPopupMenu.prototype.OnMouseOutMenu = function(oEvent)
{
	// Indique quelle option est survolee
	var nOptionSurvol = this.__nGetOptionEvent(oEvent);
	if (this.m_nOptionSurvol == nOptionSurvol)
	{
		delete this.m_nOptionSurvol;
	}

	// Rafraichit les options du sous menu si besoin
	this.__RafEtatOptions(oEvent);
};

// Trouve l'option parent
WDBarreBoutonPopupMenu.prototype.__nGetOptionEvent = function(oEvent)
{
	var oSource = clWDUtil.oGetTarget(oEvent);
	var i;
	var nLimiteI = this.m_tabOptions.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (clWDUtil.bEstFils(oSource, this.m_tabOptions[i].oTD))
		{
			return i;
		}
	}

	return -1;
};

// Rafraichit les options du sous menus
WDBarreBoutonPopupMenu.prototype.ExecuteCommande = function(oEvent)
{
	// Appel de la classe de base
	WDBarreBoutonPopup.prototype.ExecuteCommande.apply(this, arguments);

	// Rafraichit les options du sous menu si besoin
	this.__RafEtatOptions(oEvent);
};

// Rafraichit les options du sous menu si besoin
WDBarreBoutonPopupMenu.prototype.__RafEtatOptions = function(oEvent)
{
	var i;
	var nLimiteI = this.m_tabOptions.length;
	for (i = 0; i < nLimiteI; i++)
	{
		// Aucune option n'est survolee
		this.__RafEtatOption(oEvent, i, this.m_nOptionSurvol);
	}
};

// Rafraichit l'etat d'un bouton lors de l'ouverture du menu
WDBarreBoutonPopupMenu.prototype.__RafEtatOption = function(oEvent, nOption, nOptionSurvol)
{
	// Regarde si l'option est active
	var oOption = this.m_tabOptions[nOption];

	var eEtat = this.__eGetEtatSurvol(nOption == nOptionSurvol);
	eEtat = this.__eGetEtatSpecifiqueOption(oEvent, eEtat, oOption);

	// Puis dessine l'etat
	this.__DessineEtat(eEtat, oOption, oOption.oTD);
};

// Regarde si l'option est active
WDBarreBoutonPopupMenu.prototype.__eGetEtatSpecifiqueOption = function __eGetEtatSpecifiqueOption(oEvent, eEtat, oOption)
{
	// Si on a un etat surcharge
	return this.m_oObjetParent.bActifOption(oEvent, oOption.oParamCommande) ? this.ms_eEtatActif : eEtat;
};

// Clic sur une option : trouve la commande associe et l'execute
WDBarreBoutonPopupMenu.prototype.OnClickP = function(oEvent)
{
	// Trouve l'option parent
	var nOption = this.__nGetOptionEvent(oEvent);
	if (nOption != -1)
	{
		// Fixe les parametres de la commande
		this.m_oParamCommande = this.m_tabOptions[nOption].oParamCommande;
	}

	// Appel la methode dans ExecuteCommande en evitant l'implementation de la classe parent
	WDBarreBouton.prototype.ExecuteCommande.apply(this, [oEvent]);

	// Appel de la classe de base (ferme le menu)
	WDBarreBoutonPopup.prototype.OnClickP.apply(this, arguments);
};

// Manipulation d'une popup "menu" avec selection du bouton parent si un des fils est selectionne
function WDBarreBoutonPopupMenuS (/*oObjetParent*//*, oBouton*//*, sCommande*//*, oPopup*//*, tabOptions*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDBarreBoutonPopupMenu.prototype.constructor.apply(this, arguments);
	}
};

// Declare l'heritage
WDBarreBoutonPopupMenuS.prototype = new WDBarreBoutonPopupMenu();
// Surcharge le constructeur qui a ete efface
WDBarreBoutonPopupMenuS.prototype.constructor = WDBarreBoutonPopupMenuS;

// Declare les fonction une par une

// Calcule l'etat specifique du bouton : inchange
WDBarreBoutonPopupMenuS.prototype._veGetEtatSpecifique = function _veGetEtatSpecifique(oEvent/*, eEtat*//*, oDataEtat*/)
{
	// Si on a une option d'activee
	var i;
	var nLimiteI = this.m_tabOptions.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (this.m_oObjetParent.bActifOption(oEvent, this.m_tabOptions[i].oParamCommande))
		{
			return this.ms_eEtatActif;
		}
	}

	// Aucune option du menu n'est active : appele la methode de la classe de base
	return WDBarreBoutonPopupMenu.prototype._veGetEtatSpecifique.apply(this, arguments);
};

// Classe de base pour un champ avec une barre
function WDBarre(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChampParametresHote.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees, eModeBarre, sCouleurFondSurvol, sCouleurFondActif, tabBoutonsInfo ]
		var eModeBarre = tabParametresSupplementaires[2];
		var sCouleurFondSurvol = tabParametresSupplementaires[3];
		var sCouleurFondActif = tabParametresSupplementaires[4];
		var tabBoutonsInfo = tabParametresSupplementaires[5];

		// Mode de la barre
		// GP 17/06/2015 : eModeBarre est maintenant toujours g�n�r�
//		this.m_eModeBarre = (undefined !== eModeBarre) ? eModeBarre : this.ms_eModeBarreAutomatique;
		this.m_eModeBarre = eModeBarre;
		// Image de survol
		this.m_tabCouleurFond = [];
		this.m_tabCouleurFond[WDBarreBouton.prototype.ms_eEtatNormal] = "";
		// GP 17/06/2015 : sCouleurFondSurvol et sCouleurFondActif sont maintenant toujours g�n�r�
//		this.m_tabCouleurFond[WDBarreBouton.prototype.ms_eEtatSurvol] = sCouleurFondSurvol || this.ms_sCouleurFondSurvolDefaut;
//		this.m_tabCouleurFond[WDBarreBouton.prototype.ms_eEtatActif] = sCouleurFondActif || this.ms_sCouleurFondActifDefaut;
		this.m_tabCouleurFond[WDBarreBouton.prototype.ms_eEtatSurvol] = sCouleurFondSurvol;
		this.m_tabCouleurFond[WDBarreBouton.prototype.ms_eEtatActif] = sCouleurFondActif;

		this.m_tabBoutonsInfo = tabBoutonsInfo;

		this.m_tabElementRacineDisplay = [];
	}
};

// Declare l'heritage
// Derive maintenant de WDChampParametresHote, meme si les champs n'ont pas de parametres
WDBarre.prototype = new WDChampParametresHote();
// Surcharge le constructeur qui a ete efface
WDBarre.prototype.constructor = WDBarre;

// Membres statiques
//WDBarre.prototype.ms_sCouleurFondSurvolDefaut = "#EAEFF2";
//WDBarre.prototype.ms_sCouleurFondActifDefaut = "#C5E0EC";
WDBarre.prototype.ms_eModeBarreAutomatique = 0;
WDBarre.prototype.ms_eModeBarreToujours = 1;
WDBarre.prototype.ms_eModeBarreJamais = 2;
WDBarre.prototype.ms_nBoutonOnOff = 0;			// WDSaisieRicheBtn
WDBarre.prototype.ms_nBoutonPopup = 1;			// WDBarreBoutonPopup
WDBarre.prototype.ms_nBoutonAction = 2;			// WDSaisieRicheBtnC
WDBarre.prototype.ms_nCombo = 3;				// WDSaisieRicheCbm
WDBarre.prototype.ms_nBoutonPopupMenu = 4;		// WDBarreBoutonPopupMenu
WDBarre.prototype.ms_nBoutonPopupMenuS = 5;		// WDBarreBoutonPopupMenuS
WDBarre.prototype.ms_sSuffixeCommande = "_COM";
WDBarre.prototype.ms_nMarqueBordureGauche = 0x1;
WDBarre.prototype.ms_nMarqueBordureDroite = 0x2;
// Calcule une fois pour toute si la page contient des �l�ments fixed
WDBarre.prototype.ms_bAvecFixed = (function(oRacine)
{
	function bFilsFixed(oElement)
	{
		// On ne test pas oElement, on le test avec les fils, cela permet de ne pas tester document.body (micro optimisation)
		for (var oFils = oElement.firstChild; oFils; oFils = oFils.nextSibling)
		{
			switch (oFils.nodeName)
			{
			case "#comment":
			case "#text":
				// GP 24/09/2015 : QW262103 : Ignore aussi le cas "#comment" 
				break;
			default:
				// Test si :
				// - Le fils est en fixed
				// - Un des fils du fils est fixe
				// GF indique : "le fixed est toujours �crit inline" (On �vite le couteux calcul du currentStyle)
				// GP 24/09/2015 : QW262103 : filtre aussi par s�curit� le cas d'un autre �l�ment sans style
//				if ((oFils.style && ("fixed" == clWDUtil.oGetCurrentStyle(oFils).position)) || arguments.callee.apply(this, [oFils]))
				if ((oFils.style && ("fixed" == oFils.style.position)) || bFilsFixed(oFils))
				{
					return true;
				}
			}
		}
		return false;
	}

	return (0 < clWDUtil.tabGetElementsByClass(oRacine, "fixedcoulisse").length) || bFilsFixed(oRacine);
})(document.body);
// Parfois (par exemple dans le cas d'un champ simple dans une page hors ZR) la barre est positionn�e dans un div. On ne ignore le div :
// - On n'est a pas besoin pour le positionnement
// - Il va complexifier les calculs (si on place dans le formulaire, la barre est en r�f�rence � la page donc les calculs sont plus simples
// - Le zIndex du div (990) n'a pas besoin d'�tre pris en compte. La barre est dans un conteneur racine, apr�s le reste du HTML et sans concurrent a son niveau donc est toujours au dessus.

// GP 14/04/2015 : Vu avec le site de FCH : Ce n'est pas vrai. Le calcul n'est pas strictement par conteneurs. En fait un certaines cat�gories de balises definissent un niveau de zIndex
// (par exemple les balises avec positionnement)
// => Ce que l'on fait : on place la barre mais en 988 (= sous le zIndex)
// GP 18/09/2015 : TB93244 : Gestion du fixed
WDBarre.prototype.ms_sZIndexDefautDefaut = "988";
WDBarre.prototype.ms_sZIndexDefautFixed = "799";
WDBarre.prototype.ms_sZIndexDefaut = WDBarre.prototype.ms_bAvecFixed ? WDBarre.prototype.ms_sZIndexDefautFixed : WDBarre.prototype.ms_sZIndexDefautDefaut;
WDBarre.prototype.ms_sZIndexPopup = "991";

// Declare les fonction une par une

// Initialisation
WDBarre.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype.Init.apply(this, arguments);

	// Initialisation de la barre
	this._InitBarre();
};

// Trouve les divers elements : liaison avec le HTML
WDBarre.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype._vLiaisonHTML.apply(this, arguments);

	// La barre est une seule fois dans la page : pas de recherche en tenant compte de la ZR
	this.m_oBarre = this.oGetElementById(document, this.ms_sSuffixeCommande);

	if (this.m_oBarre && this.__bBarreDeplace())
	{
		this.m_oBarre.style.zIndex = this.__sGetZIndex();

		// Change le parent de la barre
		// GP 05/09/2014 : Utilisation de _PAGE_ au lieu de document.forms[0] ?
		this.m_oBarre = document.forms[0].appendChild(this.m_oBarre.parentNode.removeChild(this.m_oBarre));

		// On peut avoir plusieurs appel de _vLiaisonHTML : on ne le fait que une fois
		this.m_bBarreDeplacee = true;
	}
};
// GP 05/09/2014 : QW247610 : On d�place la barre en bas du formulaire pour la sortir de son conteneur.
// En effet si le conteneur est sans d�bordement, et que la barre est en haut, elle ne sort pas du conteneur.
// C'est par exemple le cas dans les widgets de tableaux de bord.
WDBarre.prototype.__bBarreDeplace = function __bBarreDeplace()
{
	// Note 1 : On peut avoir plusieurs appel de _vLiaisonHTML : on ne fait le d�placement que une fois
	// Note 2 : L'appel de _vLiaisonHTML est avant l'appel de _InitBarre donc on ne casse rien en d�placant
	if (this.m_bBarreDeplacee)
	{
		return false;
	}
	// Note 3 : On ne d�place pas la barre si on est dans une ZR (ancien comportement)
	if (this.bGestionTableZR())
	{
		// GP 26/11/2015 : TB93234 : Sauf que si on est dans une table/ZR AJAX avec limite on va �tre limit� par la ZR
		var oTableZRParent = this.oGetTableZRParent();
		if (!oTableZRParent)
		{
			// Table/ZR classique : sans d�placement
			return false;
		}
		if (!(oTableZRParent instanceof WDTable))
		{
			// Table/ZR non AJAX : sans d�placement
			return false;
		}
		if (oTableZRParent.bGetSansLimite())
		{
			// Table/ZR AJAX illimit� : sans d�placement
			return false;
		}
	}
// GF 26/11/2020 TB#118428 Sauf que cela casse compl�tement le fonctionnement pour le champ de saisie HTML que m�me pour le graphe cela ne corrige rien, je retire donc ce code
	// // GP 12/11/2014 : QW251307 : Sauf que si le champ est superposable, la barre ne fonctionne alors plus bien.
	// // Supprime le cas superposable (ce qui fait que le graphe superposable dans un widget ne fonctionnera probablement pas bien)
	// if (document.getElementById("dww" + this.m_sAliasChamp.replace(/_/g, "")))
	// {
	// 	return false;
	// }

	return true;
};

// Passe en mode editable les barres affichees
WDBarre.prototype.OnDisplay = function(oElementRacine, bAffiche)
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype.OnDisplay.apply(this, arguments);

	// GP 08/07/2016 : TB98600 : Force le zIndex si on d�termine que le champ est dans une popup
	clWDUtil.SupprimeDansTableau(this.m_tabElementRacineDisplay, oElementRacine);
	if (bAffiche)
	{
		this.m_tabElementRacineDisplay.push(oElementRacine);
	}

	// GP 03/10/2014 : QW249324 : En cas d'affichage de popup la barre est en concurrence avec la popup
	// Ce que l'on test est bien que l'hote est dans la popup pas la barre. La barre est � la racine donc jamais dans la popup
	if (this.m_bBarreDeplacee && this.m_oBarre && this.m_oHote && clWDUtil.bEstFils(this.m_oHote, oElementRacine))
	{
		this.m_oBarre.style.zIndex = this.__sGetZIndex();

		// GP 06/10/2014 : QW249402 : Si la barre a �t� d�plac�e, la visibilit� n'est plus h�rit�e du parent.
		if (this.m_eModeBarre == this.ms_eModeBarreToujours)
		{
			this.RafBarre(null, bAffiche);
		}
	}
};

// Recupere le zIndex pour le champ
WDBarre.prototype.__sGetZIndex = function __sGetZIndex()
{
	// GP 08/07/2016 : TB98600 : Force le zIndex si on d�termine que le champ est dans une popup
	// Dans tous les cas vides le tableau en sortie
	var tabElementRacineDisplay = this.m_tabElementRacineDisplay;
	this.m_tabElementRacineDisplay = [];
	var oHote = this.m_oHote;
	if (!clWDUtil.bForEach(tabElementRacineDisplay, function (oElementRacineDisplay)
	{
		return !clWDUtil.bEstFils(oHote, oElementRacineDisplay);
	}))
	{
		return this.ms_sZIndexPopup;
	}
	else if (this.ms_bAvecFixed && this.m_oHote && (function(oElement)
	{
		for (var oBody = document.body; oElement && (oElement != oBody); oElement = oElement.parentNode)
		{
			// GF indique : "le fixed est toujours �crit inline" (On �vite le couteux calcul du currentStyle)
//			if (("fixed" == clWDUtil.oGetCurrentStyle(oElement).position) || clWDUtil.bAvecClasse(oElement, "fixedcoulisse"))
			if (("fixed" == oElement.style.position) || clWDUtil.bAvecClasse(oElement, "fixedcoulisse"))
			{
				return true;
			}
		}	
		return false;
	})(this.m_oHote))
	{
		return this.ms_sZIndexDefautDefaut;
	}
	else
	{
		return this.ms_sZIndexDefaut;
	}
};

// Initialisation de la barre dans l'init
WDBarre.prototype._InitBarre = function _InitBarre()
{
	var bInitialiseBarre = false;

	// Selon le mode de la barre
	switch (this.m_eModeBarre)
	{
	case this.ms_eModeBarreToujours:
		// Toujours
		// GP 06/10/2014 : QW249402 : Si la barre a �t� d�plac�e, la visibilit� n'est plus h�rit�e du parent.
		clWDUtil.SetDisplay(this.m_oBarre, this.m_bBarreDeplacee ? clWDUtil.bEstDisplay(this.m_oHote, document, true) : true);
		bInitialiseBarre = true;
		break;
	case this.ms_eModeBarreJamais:
		// Jamais : rien
		break;
	case this.ms_eModeBarreAutomatique:
		// Automatique
	default:
		bInitialiseBarre = true;
		break;
	}

	(this.m_tabBarreElements = []);
	if (bInitialiseBarre)
	{
		// Utilise la definition par la classe derive pour le hook du rafraichissement
		this._InitBarreAutomatique();


		// Associe les boutons de la barre
		this._AssocieBarreElements();
	}
};

// Evenement sur le rechargement du champ apres filtrage par la classe de base
WDBarre.prototype._vOnResize = function _vOnResize(/*oEvent*/)
{
	// Appel de la classe de base
	WDChampParametresHote.prototype._vOnResize.apply(this, arguments);

	// GP 14/12/2015 : R�activation de l'appel mais dans un appel diff�r�
	// GP 08/09/2014 : D�place la barre si besoin
	this._DeplaceBarreSiBesoinAvecTimeout();
};

WDBarre.prototype._vOnScroll = function _vOnScroll(/*oEvent*/)
{
	// GP 12/11/2014 : QW251567 : Il faut d�placer la barre d'outils en cas de scroll (pour le cas de l'�l�ment fixed)

	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype._vOnScroll.apply(this, arguments);

	// GP 03/10/2014 : QW249324 : En cas d'affichage de popup la barre est en concurrence avec la popup
	// Ce que l'on test est bien que l'hote est dans la popup pas la barre. La barre est � la racine donc jamais dans la popup
	this._DeplaceBarreSiBesoinAvecTimeout();
};

WDBarre.prototype._DeplaceBarreSiBesoinAvecTimeout = function()
{
	// GP 03/10/2014 : QW249324 : En cas d'affichage de popup la barre est en concurrence avec la popup
	// Ce que l'on test est bien que l'hote est dans la popup pas la barre. La barre est � la racine donc jamais dans la popup
	if (this.m_bBarreDeplacee && this.m_oBarre && this.m_oHote && clWDUtil.bEstDisplay(this.m_oHote, document, true))
	{
		var oThis = this;
		clWDUtil.nSetTimeout(function() { oThis._DeplaceBarre(); }, clWDUtil.ms_oTimeoutImmediat);
	}
};

// Associe les boutons de la barre
WDBarre.prototype._AssocieBarreElements = function _AssocieBarreElements()
{
	// m_tabDescBarre est un tableau definies par les classes derivees
	// Chaque ligne contient au minimum 3 parametres :
	// - nType : Type du bouton
	// - sSuf : Suffixe du bouton
	// - sCom : Commande associee
	// Les classes derives doivent implementer les classes de creation pour creer leur bon objet du bon type derive

	// Creation des boutons
	var i;
	var nLimiteI = this.m_tabDescBarre.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oDesc = this.m_tabDescBarre[i];
		// Comme this.m_tabDescBouton est un tableau inline, on semble lister aussi la propriete .length que l'on ne veux pas
		if (oDesc)
		{
			var oBouton = null;
			var oElementBarre = this.oGetElementByIdBarre(document, oDesc.sSuf);
			if (!oElementBarre)
			{
				continue;
			}			
			switch (oDesc.nType)
			{
			case this.ms_nBoutonOnOff:
				oBouton = this._voNewBoutonOnOff(oElementBarre, oDesc);
				break;
			case this.ms_nBoutonPopup:
				oBouton = this._voNewBoutonPopup(oElementBarre, oDesc);
				break;
			case this.ms_nBoutonAction:
				oBouton = this._voNewBoutonAction(oElementBarre, oDesc);
				break;
			case this.ms_nCombo:
				oBouton = this._voNewBoutonCombo(oElementBarre, oDesc);
				break;
			case this.ms_nBoutonPopupMenu:
				oBouton = this._voNewBoutonMenu(oElementBarre, oDesc);
				break;
			case this.ms_nBoutonPopupMenuS:
				oBouton = this._voNewBoutonMenuS(oElementBarre, oDesc);
				break;
			}

			// Ajoute le bouton
			if (oBouton)
			{
				this.m_tabBarreElements.push(oBouton);

				// Traite les options du bouton
				var oOptionsBouton = this.m_tabBoutonsInfo[oDesc.sSuf];
				if (oOptionsBouton)
				{
					// GP 27/05/2016 : QW273517 : Dans le cas des combo, il faut remonter au parent pour la visibilit� mais aussi pour la bordure.
					// Si l'element est une combo, il faut remonter d'un cran
					if (oDesc.nType == this.ms_nCombo)
					{
						oElementBarre = oElementBarre.parentNode;
					}

					// Visibilite
					if (oOptionsBouton.bVisible !== undefined)
					{
						clWDUtil.SetDisplay(oElementBarre, oOptionsBouton.bVisible);
					}
					// Bordures
					if (oOptionsBouton.nSeparateurs !== undefined)
					{
						//le className peut contenir des classes plac�es par la g�n�ration HTML pour des bordures lat�rales
						// GP 01/10/2015 : Utilisation de RemplaceClassName pour ne pas mettre deux fois la classe
						clWDUtil.ActiveDesactiveClassName(oElementBarre, "WDBordGauche", !!(oOptionsBouton.nSeparateurs & 0x1));
						clWDUtil.ActiveDesactiveClassName(oElementBarre, "WDBordDroit", !!(oOptionsBouton.nSeparateurs & 0x2));
					}
				}
				// Texte alternatif 
				if (oDesc.sTitle)
				{
					oElementBarre.title = oDesc.sTitle;
				}
			}
		}
	}
};

// Creation des boutons de la barre d'outils

// Boutons on/off
WDBarre.prototype._voNewBoutonOnOff = function _voNewBoutonOnOff(/*oElementBarre*//*, oDesc*/)
{
	return null;
};
// Boutons popup
WDBarre.prototype._voNewBoutonPopup = function _voNewBoutonPopup(/*oElementBarre*//*, oDesc*/)
{
	return null;
};
// Boutons action
WDBarre.prototype._voNewBoutonAction = function _voNewBoutonAction(/*oElementBarre*//*, oDesc*/)
{
	return null;
};
// Combos
WDBarre.prototype._voNewBoutonCombo = function _voNewBoutonCombo(/*oElementBarre*//*, oDesc*/)
{
	return null;
};
// Menus
WDBarre.prototype._voNewBoutonMenu = function _voNewBoutonMenu(/*oElementBarre*//*, oDesc*/)
{
	return null;
};
// Menus avec highlight du parent si un element est selectionne
WDBarre.prototype._voNewBoutonMenuS = function _voNewBoutonMenuS(/*oElementBarre*//*, oDesc*/)
{
	return null;
};

WDBarre.prototype.oGetElementByIdBarre = function oGetElementByIdBarre(oDocument, sSuffixe)
{
	// Trouve l'element
	var oElement = this.oGetElementById(oDocument, this.ms_sSuffixeCommande + "_" + sSuffixe);

	// Et en profite pour lui donner son texte alternatif
	if (oElement)
	{
		this.__sAppliqueBulle(oElement, sSuffixe);
	}
	return oElement;
};

// Met a jour la barre d'outils
WDBarre.prototype.RafBarre = function (oEvent, bAfficheBarre)
{
	// Si le champ est desactive : masque la barre
	if (this.eGetEtat() != WDChamp.prototype.ms_eEtatActif)
	{
		bAfficheBarre = false;
	}

	// Selon le mode de la barre
	switch (this.m_eModeBarre)
	{
	// Jamais : rien a faire
	case this.ms_eModeBarreJamais:
		// Rien
		break;

	// Automatique : calcule l'etat de la barre
	case this.ms_eModeBarreAutomatique:
	default:
		// Affiche/masque la barre
		clWDUtil.SetDisplay(this.m_oBarre, bAfficheBarre);
		if (!bAfficheBarre)
		{
			// Pas besoin de la MAJ des boutons
			break;
		}
		// Pas de break;

	// Toujours + automatique : MAJ des boutons
	case this.ms_eModeBarreToujours:
		// D�place la barre (au cas ou le champ se d�place)
		this._DeplaceBarre();

		// GP 06/10/2014 : QW249402 : Si la barre a �t� d�plac�e, la visibilit� n'est plus h�rit�e du parent.
		if (this.m_bBarreDeplacee)
		{
			clWDUtil.SetDisplay(this.m_oBarre, clWDUtil.bEstDisplay(this.m_oHote, document, true));
		}

		var oDataEtat = this.oGetParamEtat(oEvent, false);

		// Demande a chaque element de la barre
		var i;
		var nLimiteI = this.m_tabBarreElements.length;
		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabBarreElements[i].RafEtat(oEvent, oDataEtat);
		}
		break;
	}
};

// D�place la barre au bon endroit
WDBarre.prototype._DeplaceBarre = function _DeplaceBarre()
{
	// D�place la barre (au cas ou le champ se d�place)
	if (this.m_bBarreDeplacee)
	{
		var oBarre = this.m_oBarre;

		// Le d�place
		var oBarreOffsetParent = oBarre.offsetParent;
		// Dans des cas idiots (HTML invalide) oBarre.document n'est pas toujours d�fini.
		var bBarreOffsetParentEstBody = (oBarreOffsetParent == (oBarre.document ? oBarre.document.body : document.body));
		// GP 08/09/2014 : QW247817 : On tient compte de la bordure si besoin.
		var bBordurePourParent = bBarreOffsetParentEstBody;
		// GP 10/06/2015 : pour le parent bAvecScroll est a faux uniquement sur le body. Pour les autres �l�ments il faut en tenir compte (car on en tient compte pour la barre)
		var bScrollPourParent = !bBarreOffsetParentEstBody;
		oBarre.style.left = (clWDUtil.nGetBoundingClientRectLeft(this.m_oHote, true, false) - clWDUtil.nGetBoundingClientRectLeft(oBarreOffsetParent, bScrollPourParent, bBordurePourParent)) + "px";
		oBarre.style.top = (clWDUtil.nGetBoundingClientRectTop(this.m_oHote, true, false) - 23 - clWDUtil.nGetBoundingClientRectTop(oBarreOffsetParent, bScrollPourParent, bBordurePourParent)) + "px";
	}
};

// Recupere les parametres pour RafEtat
WDBarre.prototype.oGetParamEtat = function(/*oEvent*//*, bSimple*/)
{
	return null;
};

// Recupere l'image de fond des bouton
// 0 : Normal
// 1 : Survol
// 2 : Actif
WDBarre.prototype.sGetCouleurFond = function sGetCouleurFond(eEtat)
{
	return this.m_tabCouleurFond[eEtat];
};

// Applique la bulle a l'element
WDBarre.prototype.__sAppliqueBulle = function (oElement, sSuffixe)
{
	var sAltTexte = this.sGetAltText(sSuffixe);
	if (sAltTexte)
	{
		// Traite le cas des images
		var tabFils = oElement.getElementsByTagName("img");
		if (tabFils.length)
		{
			tabFils[0].alt = sAltTexte;
			tabFils[0].title = sAltTexte;
		}
		// Traite le cas des combos
		tabFils = oElement.getElementsByTagName("select");
		if (tabFils.length)
		{
			tabFils[0].title = sAltTexte;
		}
	}
};

// Recupere le texte alternatif d'un bouton
// A surcharger par les classes derivees si besoin
WDBarre.prototype.sGetAltText = function (/*sSuffixe*/)
{
	return null;
};

// Masque la barre d'outil a la demande d'un autre champ
WDBarre.prototype._vMasqueBarre = function _vMasqueBarre(/*oEvent*/)
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype._vMasqueBarre.apply(this, arguments);

	if (this.m_eModeBarre == this.ms_eModeBarreAutomatique)
	{
		clWDUtil.SetDisplay(this.m_oBarre, false);
	}
};

// Deplace la barre
WDBarre.prototype.DeplaceBarre = function(oHoteBarre)
{
	if (this.m_bBarreDeplacee)
	{
		this._DeplaceBarre();
	}
	else if (oHoteBarre && this.m_oBarre)
	{
		// Demande a chaque element de la barre
		var i;
		var nLimiteI = this.m_tabBarreElements.length;
		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabBarreElements[i].vPrePlaceBarre();
		}

		this.m_oBarre = oHoteBarre.insertBefore(this.m_oBarre, null);

		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabBarreElements[i].vPostPlaceBarre();
		}
	}
};
