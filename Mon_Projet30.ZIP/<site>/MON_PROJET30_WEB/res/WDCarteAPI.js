// WDCarteAPI.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */
// PAS de numéro de VERSION (VI) car le fichier est inclus en ressource dans WDxxxOBJ et la chaine est alors patché par ViPatch qui inclus un zéro binaire dans le fichier
// (Le commentaire ci dessus n'inclus pas non plus la chaine patché pour ne pas avoir le commentaire de patche)
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// COmmun aux APIs de Maps

///#DEBUG=clWDUtil.WDDebug

// Définition des globales définies dans :
///#GLOBALS google clWDAJAXMain clWDUtil GPSSuitDeplacement WDDinoMarqueurImage WDDinoBaseObjetCarte

// Types de trait
WDCarteAPI.nTypeTraitContinu = 1;
WDCarteAPI.nTypeTraitTiret = 2;
WDCarteAPI.nTypeTraitPointille = 3;
WDCarteAPI.nTypeTraitMixte = 4;

// Formes
WDCarteAPI.nFormeNonDefini = -1;
WDCarteAPI.nFormeRond = 3;
WDCarteAPI.nFormeCarre = 4;
WDCarteAPI.nFormeCarreArrondi = 6;

// Opacité couleur WLangage maximum
WDCarteAPI.nOpaciteCouleurWLMax = 255;

// Styles de carte
WDCarteAPI.nStyleAuto = 0;
WDCarteAPI.nStyleDefaut = 1;
WDCarteAPI.nStyleSombre = 2;
WDCarteAPI.nStyleNuit = 3;
WDCarteAPI.nStyleArgent = 4;
WDCarteAPI.nStyleRetro = 5;
WDCarteAPI.nStyleAubergine = 6;
WDCarteAPI.nStylePerso = 7;

// Styles carte prédéfinis
WDCarteAPI.tabStyle = [];
// Style carte sombre
WDCarteAPI.tabStyle[WDCarteAPI.nStyleSombre] =
	[
		{
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#212121"
				}
			]
		},
		{
			"elementType": "labels.icon",
			"stylers": [
				{
					"visibility": "off"
				}
			]
		},
		{
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#212121"
				}
			]
		},
		{
			"featureType": "administrative",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "administrative.country",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		},
		{
			"featureType": "administrative.land_parcel",
			"stylers": [
				{
					"visibility": "off"
				}
			]
		},
		{
			"featureType": "administrative.locality",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#bdbdbd"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#181818"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#616161"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#1b1b1b"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "geometry.fill",
			"stylers": [
				{
					"color": "#2c2c2c"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#8a8a8a"
				}
			]
		},
		{
			"featureType": "road.arterial",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#373737"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#3c3c3c"
				}
			]
		},
		{
			"featureType": "road.highway.controlled_access",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#4e4e4e"
				}
			]
		},
		{
			"featureType": "road.local",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#616161"
				}
			]
		},
		{
			"featureType": "transit",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#000000"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#3d3d3d"
				}
			]
		}
	];

// Style carte nuit
WDCarteAPI.tabStyle[WDCarteAPI.nStyleNuit] =
	[
		{
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#242f3e"
				}
			]
		},
		{
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#746855"
				}
			]
		},
		{
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#242f3e"
				}
			]
		},
		{
			"featureType": "administrative.locality",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#d59563"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#d59563"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#263c3f"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#6b9a76"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#38414e"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#212a37"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9ca5b3"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#746855"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#1f2835"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#f3d19c"
				}
			]
		},
		{
			"featureType": "transit",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#2f3948"
				}
			]
		},
		{
			"featureType": "transit.station",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#d59563"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#17263c"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#515c6d"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#17263c"
				}
			]
		}
	];

// Style carte argent
WDCarteAPI.tabStyle[WDCarteAPI.nStyleArgent] =
	[
		{
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#f5f5f5"
				}
			]
		},
		{
			"elementType": "labels.icon",
			"stylers": [
				{
					"visibility": "off"
				}
			]
		},
		{
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#616161"
				}
			]
		},
		{
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#f5f5f5"
				}
			]
		},
		{
			"featureType": "administrative.land_parcel",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#bdbdbd"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#eeeeee"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#e5e5e5"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#ffffff"
				}
			]
		},
		{
			"featureType": "road.arterial",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#dadada"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#616161"
				}
			]
		},
		{
			"featureType": "road.local",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		},
		{
			"featureType": "transit.line",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#e5e5e5"
				}
			]
		},
		{
			"featureType": "transit.station",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#eeeeee"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#c9c9c9"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		}
	];

// Style carte rétro
WDCarteAPI.tabStyle[WDCarteAPI.nStyleRetro] =
	[
		{
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#ebe3cd"
				}
			]
		},
		{
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#523735"
				}
			]
		},
		{
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#f5f1e6"
				}
			]
		},
		{
			"featureType": "administrative",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#c9b2a6"
				}
			]
		},
		{
			"featureType": "administrative.land_parcel",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#dcd2be"
				}
			]
		},
		{
			"featureType": "administrative.land_parcel",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#ae9e90"
				}
			]
		},
		{
			"featureType": "landscape.natural",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#dfd2ae"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#dfd2ae"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#93817c"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "geometry.fill",
			"stylers": [
				{
					"color": "#a5b076"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#447530"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#f5f1e6"
				}
			]
		},
		{
			"featureType": "road.arterial",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#fdfcf8"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#f8c967"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#e9bc62"
				}
			]
		},
		{
			"featureType": "road.highway.controlled_access",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#e98d58"
				}
			]
		},
		{
			"featureType": "road.highway.controlled_access",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#db8555"
				}
			]
		},
		{
			"featureType": "road.local",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#806b63"
				}
			]
		},
		{
			"featureType": "transit.line",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#dfd2ae"
				}
			]
		},
		{
			"featureType": "transit.line",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#8f7d77"
				}
			]
		},
		{
			"featureType": "transit.line",
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#ebe3cd"
				}
			]
		},
		{
			"featureType": "transit.station",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#dfd2ae"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "geometry.fill",
			"stylers": [
				{
					"color": "#b9d3c2"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#92998d"
				}
			]
		}
	];

// Style carte aubergine
WDCarteAPI.tabStyle[WDCarteAPI.nStyleAubergine] =
	[
		{
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#1d2c4d"
				}
			]
		},
		{
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#8ec3b9"
				}
			]
		},
		{
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#1a3646"
				}
			]
		},
		{
			"featureType": "administrative.country",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#4b6878"
				}
			]
		},
		{
			"featureType": "administrative.land_parcel",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#64779e"
				}
			]
		},
		{
			"featureType": "administrative.province",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#4b6878"
				}
			]
		},
		{
			"featureType": "landscape.man_made",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#334e87"
				}
			]
		},
		{
			"featureType": "landscape.natural",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#023e58"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#283d6a"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#6f9ba5"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#1d2c4d"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "geometry.fill",
			"stylers": [
				{
					"color": "#023e58"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#3C7680"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#304a7d"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#98a5be"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#1d2c4d"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#2c6675"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry.stroke",
			"stylers": [
				{
					"color": "#255763"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#b0d5ce"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#023e58"
				}
			]
		},
		{
			"featureType": "transit",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#98a5be"
				}
			]
		},
		{
			"featureType": "transit",
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#1d2c4d"
				}
			]
		},
		{
			"featureType": "transit.line",
			"elementType": "geometry.fill",
			"stylers": [
				{
					"color": "#283d6a"
				}
			]
		},
		{
			"featureType": "transit.station",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#3a4762"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#0e1626"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#4e6d70"
				}
			]
		}
	];

function WDCarteAPI(bEnModeWebDev)
{
	if (arguments.length)
	{
		this.m_bModeWebDev = !!bEnModeWebDev;

		//objet carte de l'API
		this.m_clCarte = undefined;

		//id de la balise support
		this.m_sId = '';

		// Style
		this.m_nStyle = WDCarteAPI.nStyleDefaut;

		//infos communes à toutes les cartes
		this.m_tabMarker = [];
		this.m_tabItineraire = [];
		this.m_tabForme = [];
		this.m_tabImage = [];

		// globales remplacée dans le code C++
		// --------------------------------
		//
		// ATTENTION : NE PAS MODIFIER LE NOM DE CES VARIABLES
		// un Remplace() est fait dans CVueChampMapView_Win32::_InitOptionEdition()
		//
		this.m_nTypeCarte_Initial=1;
		this.m_bAfficheControleZoom_Initial=true; // /!\ ATTENTION : ne pas modifier UN SEUL CARACTERE de cette ligne et des suivantes
		this.m_sImageMarqueur_Initial=null;
		this.m_nLatitude_Initial=null;
		this.m_nLongitude_Initial=null;
		this.m_sAdresse_Initial=null;
		this.m_nZoom_Initial=null;
		//
		// --------------------------------


		//en cas de modification de la position
		this.m_fChangementPosition = undefined;
		//utile en WebDev pour que l'API est connaissance du champ JS
		this.m_oChamp = undefined;

		//singleton pour WinDev
		WDCarteAPI.gclSingleton = this;
	}
}

// Modification tableau marqueurs
// Entrée :	tabMarqueur	Nouveau tableau marqueurs
WDCarteAPI.prototype._SetTableauMarqueur = function (tabMarqueur)
{
	this.m_tabMarker = tabMarqueur;
};

// Modification tableau formes
// Entrée :	tabForme	Nouveau tableau formes
WDCarteAPI.prototype._SetTableauForme = function (tabForme)
{
	this.m_tabForme = tabForme;
};

// Modification tableau images
// Entrée :	tabImage	Nouveau tableau images
WDCarteAPI.prototype._SetTableauImage = function (tabImage)
{
	this.m_tabImage = tabImage;
};

// Types objet
WDCarteAPI.nTypeMarqueur = 0;	// Marqueur
WDCarteAPI.nTypePolyligne = 1;	// Polyligne
WDCarteAPI.nTypePolygone = 2;	// Polygone
WDCarteAPI.nTypeCercle = 3;		// Cercle
WDCarteAPI.nTypeImage = 4;		// Image

// Retourne un nouvel identifiant
// Entrée :	nTypeObjet	Type d'objet pour lequel on veut un identifiant
// Sortie : Identifiant
WDCarteAPI.CreerIdentifiant = function (nTypeObjet)
{
	// Préfixe
	var sPrefixe = "";
	// Si le type d'objet est
	switch (nTypeObjet)
	{
		// Marqueur :
		case WDCarteAPI.nTypeMarqueur:
			// Préfixe marqueur
			sPrefixe = "Marker";
			break;
		// Polyligne :
		case WDCarteAPI.nTypePolyligne:
			// Préfixe polyligne
			sPrefixe = "Polyline";
			break;
		// Polygone :
		case WDCarteAPI.nTypePolygone:
			// Préfixe polygone
			sPrefixe = "Polygon";
			break;
		// Cercle :
		case WDCarteAPI.nTypeCercle:
			// Préfixe cercle
			sPrefixe = "Circle";
			break;
		// Image
		case WDCarteAPI.nTypeImage:
			// Préfixe image
			sPrefixe = "Image";
			break;
		// Autre
		default:
			// Préfixe type objet inconnu
			break;
	}
	// Identifiant
	return ((sPrefixe != "") ? (sPrefixe + "#") : 0) + (++WDCarteAPI.gnIdentifiant);
};

// Conversion coordonnées en chaîne
// Entrée :	nAbscisse	Abscisse
//			nOrdonnee	Ordonnée
// Sortie : Conversion en chaîne (format "<Abscisse>,<Ordonnée>")
WDCarteAPI.sCoordVersChaine = function (nAbscisse, nOrdonnee)
{
	//Conversion coordonnées en chaîne
	return "" + nAbscisse + "," + nOrdonnee;
};

// Identifiant (commence à 0 comme en Android)
WDCarteAPI.gnIdentifiant = 0;
//singleton pour WinDev
WDCarteAPI.gclSingleton = undefined;
// ID du dernier marqueur cliqué
WDCarteAPI.gsIDClic = "";
// ID de la dernière forme cliquée
WDCarteAPI.gsIDClicForme = "";
// ID de la dernière image cliquée
WDCarteAPI.gsIDClicImage = "";
// ID du dernier marqueur déplacé
WDCarteAPI.gsIDDeplacement = "";
// ID du dernier marqueur sur la popup duquel on a cliqué
WDCarteAPI.gsIDClicPopup = "";
// ID du cluster affiché
WDCarteAPI.gsIDClusterAffiche = "";
// ID du marqueur dont on veut afficher la popup
WDCarteAPI.gsIDPopupAffiche = "";
// cf CarteAffichePosition() 2/2
WDCarteAPI.gsRetVal_SetPositionLieux = "";
//Pos par défaut
WDCarteAPI.gnLatitudeDefaut = 48.856558;
WDCarteAPI.gnLongitudeDefaut = 2.3509660000000001;
WDCarteAPI.gnZoomDefaut = 3;
WDCarteAPI.m_bToutEstCharge = false;

// Indique si on est en WD
WDCarteAPI.gbModeWD = false;

// Indique si callback affichage cluster WD
WDCarteAPI.gbCallbackClusterWD = false;

//création de l'API carte demandée
WDCarteAPI.s_pclFactory = function (TypeCarte, sIdBaliseSupport, bEnModeWebDev, fInit, fApresInit)
{
	// Déclaration des prototypes devant être déclarés après chargement de la page
	TypeCarte.DeclarePrototype();
	//aiguille vers Google Maps, ou Bing Maps etc.
	var oInstance = new TypeCarte.prototype.constructor(bEnModeWebDev);
	//init personnalisée
	!fInit || fInit(oInstance);
	//création de la carte selon l'api
	oInstance.CreateMap(sIdBaliseSupport, fApresInit);
	//retourne l'instance spécifique créée
	return oInstance;
};

//modifie la taille de la balise support
WDCarteAPI.prototype._SetSize = function (sLargeur, sHauteur)
{
	var domBalise = this.domGetBaliseSupport();
	domBalise.style.width = sLargeur;
	domBalise.style.height = sHauteur;
};

//retourne la balise du DOM associée à la carte
WDCarteAPI.prototype.domGetBaliseSupport = function ()
{
	return document.getElementById(this.m_sId);
};

//en cas de changement de position
WDCarteAPI.prototype.EcouteChangementPosition = function (fChangementPosition)
{
	//en cas de modification de la position
	this.m_fChangementPosition = fChangementPosition;
};

// Init callback affichage cluster
WDCarteAPI.prototype.EcouteAffichageCluster = function (fAffichageCluster)
{
	//en cas de modification de la position
	this.m_fAffichageCluster = fAffichageCluster;
};

// Appel callback affichage cluster
// Entrée :	tabMarqueurApi	Marqueurs API du cluster affiché
// Sortie : résultat callback affichage cluster
WDCarteAPI.prototype.AppelCallbackAffichageCluster = function (tabMarqueurApi)
{
	// Callback affichage cluster ?
	if (!this.m_fAffichageCluster)
	{
		// Non => rien à faire
		return;
	}
	// Tableau des dinos marqueurs correspondant aux marqueurs du cluster affiché
	var tabDinoMarqueur = [];
	// Remplissage tableau dinos marqueurs
	for (var nMarqueur = 0; nMarqueur < tabMarqueurApi.length; nMarqueur++)
	{
		// Ajout dino marqueur correspondant au marqueur API
		tabDinoMarqueur.push(this.clDinoMarqueurApi(tabMarqueurApi[nMarqueur]));
	}
	// Appel callback
	return this.m_fAffichageCluster(undefined, tabDinoMarqueur);
};

// vrai si les coordonnées sont valides
WDCarteAPI.bValideCoordonnees = function (dLatitude, dLongitude)
{
	//coordonnées incorrectes
	if (dLatitude < -90 || dLatitude > 90 || dLongitude < -180 || dLongitude > 180)
	{
		return false;
	}
	return true;
};

WDCarteAPI.emqHaut = 0,
	WDCarteAPI.emqBas = 1;
WDCarteAPI.emqCentre = 2;
WDCarteAPI.emqGauche = 3;
WDCarteAPI.emqDroite = 4;

// Calcul ancrage de l'image du marqueur
WDCarteAPI._CalculeAnchor = function _CalculeAnchor(eAlignement, nLargeur, nHauteur, oPoint)
{
	// RAZ
	var nAnchorX = 0;
	var nAnchorY = 0;

	//WX21 :
	// 	=>> <Alignement> : (L/E) : Permet de spécifier l'alignement du marqueur lorsqu'il est affiché sur la carte :
	// 0- mqHaut : en haut de la position => emqHaut (styleconst.h)
	// 1- mqBas : en bas de la position 1
	// 2- mqCentre : sur la position
	// 3- mqGauche : a gauche de la position
	// 4- mqDroite : à droite de la position
	switch (eAlignement)
	{
		default:
		/*clWDUtil.WDDebug.assert(false);*/
		/*break absent*/
		case WDCarteAPI.emqBas:
			nAnchorX = nLargeur / 2;
			nAnchorY = 0;
			break;
		case WDCarteAPI.emqHaut:
			nAnchorX = nLargeur / 2;
			nAnchorY = nHauteur;
			break;
		case WDCarteAPI.emqCentre:
			nAnchorX = nLargeur / 2;
			nAnchorY = nHauteur / 2;
			break;
		case WDCarteAPI.emqDroite:
			nAnchorX = 0;
			nAnchorY = nHauteur / 2;
			break;
		case WDCarteAPI.emqGauche:
			nAnchorX = nLargeur;
			nAnchorY = nHauteur / 2;
			break;
	}

	//OUT
	oPoint.x = nAnchorX;
	oPoint.y = nAnchorY;
};

// Recherche objet par identifiant
// Entrée :	nId			Identifiant objet
//			tabObjet	Tableau des objets
// Sortie : Objet trouvé, null en cas d'échec
WDCarteAPI.prototype.clObjetParId = function (nId, tabObjet)
{
	// Recherche objet dans tableau objets
	for (var nObjet = 0; nObjet < tabObjet.length; ++nObjet)
	{
		// Objet tableau parcouru
		var clObjetTableau = tabObjet[nObjet];
		// L'identifiant de l'objet du tableau est celui recherché ?
		if (clObjetTableau.ID_WD == nId)
		{
			// Oui => objet trouvé
			return clObjetTableau;
		}
	}
	// Pas trouvé
	return null;
};

// Recherche marqueur par identifiant
// Entrée :	nId			Identifiant marqueur
// Sortie : Marqueuer trouvé, null en cas d'échec
WDCarteAPI.prototype.clMarqueurParId = function (nId)
{
	// Recherche marqueur
	return this.clObjetParId(nId, this.m_tabMarker);
};

// Recherche dino correspondant à objet API
// Entrée :	clObjetApi	Objet API
//			tabObjetWD	Tableau des objets du champ
// Sortie : Dino correspondant à objet API (null en cas d'échec)
WDCarteAPI.prototype.clDinoObjetApi = function (clObjetApi, tabObjetWD)
{
	// Tableau de champs OK ?
	if (!tabObjetWD)
	{
		// Non => pas de dino
		return null;
	}
	// Dino correspondant à objet API
	var clDinoObjetApi = null;
	// Recherche champ correspondant à objet API
	clWDUtil.bForEach(tabObjetWD, function (clObjetChamp)
	{
		// L'objet du champ correspond à l'objet API ?
		if (clObjetChamp.pszGetIDInterne() == clObjetApi.ID_WD)
		{
			// Oui => récupération dino correspondant à objet API
			clDinoObjetApi = clObjetChamp;
			// Arrêt de la recherche
			return false;
		}
		// On continue la recherche
		return true;
	});
	// Dino correspondant à objet API
	return clDinoObjetApi;
};

// Indique si champ WebDev
WDCarteAPI.prototype.bChampWebDev = function ()
{
	// Indique si champ WebDev
	return this.m_oChamp && this.m_bModeWebDev;
};

// Recherche dino marqueur correspondant à marqueur API
// Entrée :	clMarqueurApi	Marqueur API
// Sortie : Dino marqueur correspondant à marqueur API (null en cas d'échec)
WDCarteAPI.prototype.clDinoMarqueurApi = function (clMarqueurApi)
{
	// Champs WebDev ?
	if (!this.bChampWebDev())
	{
		// Non => pas de dino
		return null;
	}
	// Dino marqueur correspondant à marqueur API
	return this.clDinoObjetApi(clMarqueurApi, this.m_oChamp.m_oDonnees.m_tabMarqueurs);
};

/// Méthodes d'nterfaces à redéfinir pour toutes les APIs de graphes (bing, google, etc.)

//WDCarteAPI.prototype.CreateMap = function CreateMap(sNomChampCarte,fApresInit) {};
//// CarteAffichePosition() 1/2
//WDCarteAPI.prototype.MAP_SetPosition = function(dLatitude, dLongitude, bAnimation) {};
//// CarteAffichePosition() 2/2
//WDCarteAPI.prototype.MAP_SetPositionLieux = function(Lieux, bAnimation) {};
//// CarteRécupèrePosition()
//WDCarteAPI.prototype.MAP_GetPosition = function() {};
//// CarteInfoXY ()
//WDCarteAPI.prototype.MAP_GetPositionFromPoint = function(x, y) {};
//// CarteInfoPosition()
//WDCarteAPI.prototype.MAP_GetPointFromPosition = function(dLatitude, dLongitude) {};
//// ..Zoom=
//WDCarteAPI.prototype.MAP_SetZoom = function(Zoom) {};
//// CarteAfficheZone()
//WDCarteAPI.prototype.MAP_AfficheZone = function(dLatitudeNord, dLongitudeOuest, dLatitudeSud, dLongitudeEst) {};
//// CarteLimiteZone()
//WDCarteAPI.prototype.MAP_LimiteZone = function(dLatitudeNord, dLongitudeOuest, dLatitudeSud, dLongitudeEst) {};
//// CarteChangeStyle()
//WDCarteAPI.prototype.MAP_ChangeStyle = function(nIdStyle, tabStylePerso) {};
//// CarteRécupèreStyle()
//WDCarteAPI.prototype.MAP_RecupereStyle = function() {};
//// CarteAjouteMarqueur
//WDCarteAPI.prototype.MAP_AjouteMarqueur = function(dLatitude, dLongitude, slibelle, sActionClic, sImage, nIdOptionnel, nAncrageX, nAncrageY, nOpacite, nAltitude, bDeplacable, sActionDeplacement, bAvecPopup, sNom, sActionClicPopup, bCluster, nFormeImage, nTailleFormeImage, sTexteFormeImage, sCouleurTraitFormeImage, nOpaciteTraitFormeImage, sCouleurFondFormeImage, nOpaciteFondFormeImage, sIdPourPopup) {};
//// CarteSupprimeMarqueur
//WDCarteAPI.prototype.MAP_SupprimeMarqueur = function(nID) {};
//// CarteModifieMarqueur
//WDCarteAPI.prototype.MAP_ModifieMarqueur = function(nID, dLatitude, dLongitude, slibelle, sImage, nAncrageX, nAncrageY, sActionClic, nOpacite, nAltitude, bDeplacable, sActionDeplacement, bAvecPopup, sNom, sActionClicPopup, bCluster, nFormeImage, nTailleFormeImage, sTexteFormeImage, sCouleurTraitFormeImage, nOpaciteTraitFormeImage, sCouleurFondFormeImage, nOpaciteFondFormeImage, sIdPourPopup) {};
//// CarteClusterAffiche
//WDCarteAPI.prototype.MAP_ClusterAffiche = function (sId, sImage, nFormeImage, nTailleFormeImage, sTexteFormeImage, sCouleurTraitFormeImage, nOpaciteTraitFormeImage, sCouleurFondFormeImage, nOpaciteFondFormeImage) { }
//// CarteSupprimeTout
//WDCarteAPI.prototype.MAP_SupprimeToutMarqueur = function() {};
//// CarteAffichePopup
//WDCarteAPI.prototype.MAP_AffichePopup = function(nIdMarqueur) {};
//// CarteFermePopup
//WDCarteAPI.prototype.MAP_FermePopup = function(nIdMarqueur) {};
//// CartePopupAffichée
//WDCarteAPI.prototype.MAP_PopupAffichee = function(nIdMarqueur) {};
//// CarteAjoutePolyligne
//WDCarteAPI.prototype.MAP_AjoutePolyligne = function(tabPoint, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sLibelle, sActionClic, nAltitude, bGeodesique, nIdOptionnel) {};
//// CarteModifiePolyligne
//WDCarteAPI.prototype.MAP_ModifiePolyligne = function(nId, tabPoint, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sLibelle, sActionClic, nAltitude, bGeodesique) {};
//// CarteAjoutePolygone
//WDCarteAPI.prototype.MAP_AjoutePolygone = function(tabPoint, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sCouleurFond, nOpaciteFond, sLibelle, sActionClic, nAltitude, bGeodesique, nIdOptionnel) {};
//// CarteModifiePolygone
//WDCarteAPI.prototype.MAP_ModifiePolygone = function(nId, tabPoint, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sCouleurFond, nOpaciteFond, sLibelle, sActionClic, nAltitude, bGeodesique) {};
//// CarteAjouteCercle
//WDCarteAPI.prototype.MAP_AjouteCercle = function(dLatitude, dLongitude, nRayon, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sCouleurFond, nOpaciteFond, sLibelle, sActionClic, nAltitude, nIdOptionnel) {};
//// CarteModifieCercle
//WDCarteAPI.prototype.MAP_ModifieCercle = function(nId, dLatitude, dLongitude, nRayon, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sCouleurFond, nOpaciteFond, sLibelle, sActionClic, nAltitude) {};
//// CarteSupprimeForme
//WDCarteAPI.prototype.MAP_SupprimeForme = function(nID) {};
//// CarteSupprimeToutForme
//WDCarteAPI.prototype.MAP_SupprimeToutForme = function() {};
//// CarteAjouteImage
//WDCarteAPI.prototype.MAP_AjouteImage = function(dLatitude, dLongitude, sImage, dLargeur, dHauteur, eAlignement, nOpacite, sLibelle, sActionClic, nAltitude, nAngle, nIdOptionnel) {};
//// CarteSupprimeImage
//WDCarteAPI.prototype.MAP_SupprimeImage = function(nID) {};
//// CarteModifieImage
//WDCarteAPI.prototype.MAP_ModifieImage = function(nId, dLatitude, dLongitude, sImage, dLargeur, dHauteur, eAlignement, nOpacite, sLibelle, sActionClic, nAltitude, nAngle) {};
//// CarteSupprimeToutImage
//WDCarteAPI.prototype.MAP_SupprimeToutImage = function() {};
//// ..ModeCarte
//WDCarteAPI.prototype.MAP_SetModeCarte = function( nMode ) {};
//// X = ..ModeCarte
//WDCarteAPI.prototype.MAP_GetModeCarte = function(nMode) {};
//// ..Zoom
//WDCarteAPI.prototype.MAP_GetZoom = function() {};
//// ..InfoTrafic
//WDCarteAPI.prototype.MAP_SetInfoTrafic = function( bInfoTrafic ) {};
//// X = ..InfoTrafic
//WDCarteAPI.prototype.MAP_GetInfoTrafic = function() {};
//// ..Boussole
//WDCarteAPI.prototype.MAP_SetBoussole = function( bBoussole ) {};
//// X = ..Boussole
//WDCarteAPI.prototype.MAP_GetBoussole = function() {};
//// ..AvecZoom
//WDCarteAPI.prototype.MAP_SetAvecZoom = function( bAvecZoom ) {};
//// X = ..AvecZoom
//WDCarteAPI.prototype.MAP_GetAvecZoom = function() {};
//// ..AvecRotation
//WDCarteAPI.prototype.MAP_SetAvecRotation = function( bAvecRotation ) {};
//// X = ..AvecRotation
//WDCarteAPI.prototype.MAP_GetAvecRotation = function() {};
//// ..AvecScroll
//WDCarteAPI.prototype.MAP_SetAvecScroll = function( bAvecScroll ) {};
//// X = ..AvecScroll
//WDCarteAPI.prototype.MAP_GetAvecScroll = function() {};
//// ..AvecInclinaison
//WDCarteAPI.prototype.MAP_SetAvecInclinaison = function( bAvecInclinaison ) {};
//// X = ..AvecInclinaison
//WDCarteAPI.prototype.MAP_GetAvecInclinaison = function() {};
//// ..AngleRotation
//WDCarteAPI.prototype.MAP_SetAngleRotation = function( nAngleRotation ) {};
//// X = ..AvecInclinaison
//WDCarteAPI.prototype.MAP_GetAngleRotation = function() {};
//// ..Inclinaison
//WDCarteAPI.prototype.MAP_SetInclinaison = function( nInclinaison ) {};
//// X = ..Inclinaison
//WDCarteAPI.prototype.MAP_GetInclinaison = function() {};
//// CarteAjouteItinéraire()
//WDCarteAPI.prototype.MAP_AjouteItineraire = function(dLatitudeDepart, dLongitudeDepart, dLatitudeArrivee, dLongitudeArrivee, nMode, sColor) {};
//// CarteAjouteItinéraire()
//WDCarteAPI.prototype.MAP_AjouteItineraireStr = function(sLieuDepart, sLieuArrivee, nMode, sColor) {};
//// CarteSupprimeItineraire()
//WDCarteAPI.prototype.MAP_SupprimeItineraire = function(nID) {};
//// CarteSupprimeTou
//WDCarteAPI.prototype.MAP_SupprimeToutItineraire = function() {};
//// ..Image = x
//WDCarteAPI.prototype.MAP_SetImageMarqueur = function(sUrlImage) {};
//// CarteSuitDéplacement
//WDCarteAPI.prototype.MAP_SuitDeplacement = function(Boussole, NomProcedure)	{};
// CarteFinDéplacement
//WDCarteAPI.prototype.MAP_FinDeplacement = function()	{}
//lecture seule
//WDCarteAPI.prototype.PasseEnLectureSeule = function()
// Mise à jour de la taille de la carte
//WDCarteAPI.prototype.UpdateSize = function UpdateSize()
// Affichage image popup marqueur
//WDCarteAPI.prototype.MAP_AfficheImagePopupMarqueur = function (sURLImagePopup)

/// GOOGLE MAPS
//Ne dépend QUE de "http://maps.google.com/maps/api/js?v=3"

// Objet carte API
function CWDCarteApiObjet()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
	}
}

// Création options objet API
// Entrée :	clParam		Paramètres
// Sortie : Options objet API
CWDCarteApiObjet.prototype._clCreationOptionObjetApi = function (/*clParam*/)
{
	return {};
};

// Création objet coordonnées API
// Entrée :	clParam			Paramètres
// Sortie : Objet coordonnées API créé (null en cas d'échec)
CWDCarteApiObjet.prototype._clCreationCoordApi = function (clParam)
{
	// Création position API
	return WDCarteGoogleMaps.clCreationPositionApi(clParam.m_dLatitude, clParam.m_dLongitude);
};

// Recherche dino correspondant à objet API
// Entrée :	clObjetApi	Objet API
//			clParam		Paramètres
// Sortie : Dino correspondant à objet API (null en cas d'échec)
CWDCarteApiObjet.prototype._clDinoObjetApi = function (clObjetApi, clParam)
{
	// Champs WebDev ?
	if (!clParam.m_clCarteApi.bChampWebDev())
	{
		// Non => pas de dino
		return null;
	}
	// Dino correspondant à objet API
	return clParam.m_clCarteApi.clDinoObjetApi(clObjetApi, this._tabObjetChamp(clParam));
};

// Nom propriété évènement
// Entrée :	sEvenement					Evènement géré
// Sortie :	Nom propriété pour évènement
CWDCarteApiObjet.prototype._sNomPropEvenement = function (sEvenement)
{
	// Nom propriété pour évènement
	return "WDCallback_" + sEvenement;
};

// Indique si paramètre défini et non chaîne vide
// Entrée :	sParam					Paramètre testé
// Sortie :	true si paramètre définie et non chaîne vide, false sinon
CWDCarteApiObjet.prototype._bDefiniNonChaineVide = function (sParam)
{
	// Nom propriété pour évènement
	return (!!sParam) && (sParam != "");
};

// Appel callback WLangage
// Entrée :	clObjetApi					Objet API à l'origine de l'appel
//			clParam						Paramètres
//			sNomPropGestionEvenement	Nom de la propriété de l'objet API contenant la callback
//			sNomVarEvenementWD			Nom de la variable que WD va lire pour détecter que l'évènement a eu lieu
CWDCarteApiObjet.prototype._AppelCallbackWL = function (clObjetApi, clParam, sNomPropGestionEvenement, sNomVarEvenementWD)
{
	// Récupération Nom callback
	var sNomCallback = clObjetApi[sNomPropGestionEvenement];
	// Callback ?
	if (sNomCallback == "")
	{
		// Non => rien à faire
		return;
	}
	// Nom de Variable WD de gestion de l'évènement ?
	if (sNomVarEvenementWD)
	{
		// Oui => on modifie la globale que la OBJ va lire par timer en appelant une callback dans la OBJ correspondant à l'évènement.
		WDCarteAPI[sNomVarEvenementWD] = sNomCallback;
	}
	// Récupération dino correspondant à objet API
	var clObjetChamp = this._clDinoObjetApi(clObjetApi, clParam);
	// QW#250818 : appeler la fonction directement en mode WebDev
	// Dino trouvé ?
	if (clObjetChamp != null)
	{
		// Oui => fonction navigateur à appeler
		var fProc;
		{
			try
			{
				// Procédure avec code javascript ?
				if (clWDUtil.s_bCommencePar(sNomCallback, "javascript:"))
				{
					// Oui => Evaluation code javascript
					fProc = eval(sNomCallback.substr("javascript:".length));
				}
				else
				{
					// Non => récupération function par nom
					fProc = eval(sNomCallback);
				}
			}
			catch (__e)
			{
				//erreur d'eval
				clWDUtil.WDDebug.log(__e);
				fProc = undefined;
			}
		}
		// Fonction OK ?
		if (fProc)
		{
			// Oui => exécution code
			fProc(clObjetChamp);
		}
		// Non => procédure navigateur clic ?
		else if (window[sNomCallback])
		{
			// Oui => exécution procédure navigateur
			window[sNomCallback](clObjetChamp);
		}
		else
		{
			// Non => exécution fonction serveur
			clWDAJAXMain.AJAXExecuteSynchrone20(sNomCallback, clParam.m_clCarteApi.m_oChamp.m_sAliasChamp, 1, clObjetChamp.clCloneNettoyePourJsonServeur());
		}
	}
};

// Branchement callback sur évènement
// Entrée :	clObjetApi					Objet API modifié
//			clParam						Paramètres
//			sEvenement					Evènement géré
//			sCallback					Nom de la callback (en WD, c'est l'identifiant du dino, qui est en fait un pointeur sur le dino converti en chaîne)
//			sNomVarEvenementWD			Nom de la variable que WD va lire pour détecter que l'évènement a eu lieu
//			bEvNonMap					Evènement non géré par API map
CWDCarteApiObjet.prototype._BrancheCallback = function (clObjetApi, clParam, sEvenement, sCallback, sNomVarEvenementWD, bEvNonMapApi)
{
	// Indique si callback
	var bCallback = this._bDefiniNonChaineVide(sCallback);
	// Conctruction du nom de la propriété de l'objet API contenant le gestionnaire d'évènement
	var sNomGestionEvenement = this._sNomPropEvenement(sEvenement);
	// Indique si évènement branché sur objet API
	var bEvenementBrancheSurObjetApi = (clObjetApi[sNomGestionEvenement] != undefined);
	// Callback ou gestion de l'évènement branchée sur l'objet API ?
	if ((!bCallback) && (!bEvenementBrancheSurObjetApi))
	{
		// Non => rien à faire
		return;
	}
	// On met l'action dans l'objet API
	clObjetApi[sNomGestionEvenement] = sCallback;
	// Evenement déjà branché
	if (!bEvenementBrancheSurObjetApi)
	{
		// Non => objet dans callback
		var clThis = this;
		// Callback API
		var fCallbackAPI = function ()
		{
			// Appell callback WLangage
			clThis._AppelCallbackWL(clObjetApi, clParam, sNomGestionEvenement, sNomVarEvenementWD);
		};
		// Evènement géré par map API ?
		if (bEvNonMapApi)
		{
			// Non => branchement callback non map API
			clObjetApi.addEventListener(sEvenement, fCallbackAPI);
		}
		else
		{
			// Oui => branchement callback sur l'objet API
			google.maps.event.addListener(clObjetApi, sEvenement, fCallbackAPI);
		}
	}
};

// Nom variable clic WD
CWDCarteApiObjet.prototype._sNomVarClicWD = function ()
{
	return "gsIDClic";
};

// Opération après modification objet API
// Entrée :	clObjetApi					Objet API modifié
//			clParam						Paramètres
// Sortie : true si modification réussie, false sinon
CWDCarteApiObjet.prototype._ApresModificationObjetApi = function (/*clObjetApi, clParam*/)
{
};

// Modification objet API
// Entrée :	clObjetApi					Objet API modifié
//			clParam						Paramètres
// Sortie : true si modification réussie, false sinon
CWDCarteApiObjet.prototype._bModificationObjetApi = function (clObjetApi, clParam)
{
	// Création coordonnées API
	this.m_clCoordApi = this._clCreationCoordApi(clParam);
	// Coordonnées API OK ?
	if (this.m_clCoordApi == null)
	{
		//Non => échec
		return false;
	}
	// Récupération objet API
	this.m_clObjetApi = clObjetApi;
	// Modification objet API
	clObjetApi.setOptions(this._clCreationOptionObjetApi(clParam));
	// Branchement callback clic
	this._BrancheCallback(clObjetApi, clParam, "click", clParam.m_sActionClic, this._sNomVarClicWD());
	// Ré-asscocie la carte API pour que le déplacement soit fait
	WDCarteGoogleMaps.RefreshCarte(clObjetApi, clParam.m_clCarteApi.m_clCarte);
	// Opération après modification objet API
	this._ApresModificationObjetApi(clObjetApi, clParam);
	// OK
	return true;
};

// Ajout
// Entrée :	clParam	Paramètres
// Sortie : Identifiant objet ajouté si ajout OK, false sinon
CWDCarteApiObjet.prototype.nAjout = function (clParam)
{
	// Création objet API
	var clObjetApi = this._clCreationObjetApi(clParam);
	// Récupération tableau objets
	var tabObjet = this._tabObjetApi(clParam);
	// Modification objet API OK ?
	if (!this._bModificationObjetApi(clObjetApi, clParam))
	{
		// Non => échec
		return false;
	}
	// Ajout dans le tableau
	tabObjet.push(clObjetApi);
	// On note l'ID dans l'objet
	clObjetApi.ID_WD = clParam.m_nID || this.sCreerIdentifiant();
	// On renvoie l'ID
	return clObjetApi.ID_WD;
};

// Modification objet
// Entrée :	clParam	Paramètres
// Sortie : true si modification réussie, false sinon
CWDCarteApiObjet.prototype.Modification = function (clParam)
{
	// Objet à modifier
	var clObjet = clParam.m_clCarteApi.clObjetParId(clParam.m_nID, this._tabObjetApi(clParam));
	// On a trouvé l'objet recherché ?
	if (clObjet == null)
	{
		// Non => rien à faire
		return false;
	}
	// Modification objet API
	return this._bModificationObjetApi(clObjet, clParam);
};

// Coordonnées path
// Entrée :	nX		Abscisse
//			nY		Ordonnée
// Sortie : coordonnées path
CWDCarteApiObjet.prototype.sPathCoord = function (nX, nY)
{
	// Coordonnées path
	return " " + nX + "," + nY;
};

// Coordonnées path déplacement vertical
// Entrée :	clPosition		Position
//			nDeplacement	Déplacement
// Sortie : clPosition		Position après déplacement
//			Résultat		Coordonnées path
CWDCarteApiObjet.prototype.sPathCoordV = function (clPosition, nDeplacement)
{
	// Coordonnées path déplacement vertical
	return this.sPathCoord(0, clPosition.m_nPosition += nDeplacement);
};

// Positionnement coordonnées path
// Entrée :	sCoord	Coordonnées
// Sortie : Positionnement coordonnées path
CWDCarteApiObjet.prototype.sPathPositionCoord = function (sCoord)
{
	// Positionnement coordonnées path
	return "M" + sCoord;
};

// Positionnement path
// Entrée :	nX		Abscisse
//			nY		Ordonnée
// Sortie : Positionnement path
CWDCarteApiObjet.prototype.sPathPosition = function (nX, nY)
{
	// Positionnement path
	return this.sPathPositionCoord(this.sPathCoord(nX, nY));
};

// Positionnement vertical path
// Entrée :	clPosition		Position
//			nPosition		Nouvelle position verticale
// Sortie : clPosition		Postion après positionnement
//			Résultat		Positionnement path
CWDCarteApiObjet.prototype.sPathPositionV = function (clPosition, nPosition)
{
	// Positionnement vertical path
	return this.sPathPositionCoord(this.sPathCoordV(clPosition, nPosition));
};

// Arc path
// Entrée :	nRayon		Rayon
//			nX			Abscisse
//			nY			Ordonnée
// Sortie : Arc path
CWDCarteApiObjet.prototype.sPathArc = function (nRayon, nX, nY)
{
	// Arc path
	return "a" + this.sPathCoord(nRayon, nRayon) + " 0 0 1" + this.sPathCoord(nX, nY);
};

// Trait path
// Entrée :	sTypeTrait		Type de trait (horizontal ou vertical)
//			nLongueur		Longueur trait
// Sortie : Trait path
CWDCarteApiObjet.prototype.sPathTrait = function (sTypeTrait, nLongueur)
{
	// Trait path
	return sTypeTrait + nLongueur;
};

// Trait horizontal path
// Entrée :	nLongueur		Longueur trait
// Sortie : Trait horizontal path
CWDCarteApiObjet.prototype.sPathTraitH = function (nLongueur)
{
	// Trait horizontal path
	return this.sPathTrait("h", nLongueur);
};

// Trait vertical path
// Entrée :	nLongueur		Longueur trait
// Sortie : Trait vertical path
CWDCarteApiObjet.prototype.sPathTraitV = function (nLongueur)
{
	// Trait vertical path
	return this.sPathTrait("v", nLongueur);
};

// Objet avec image carte API
function CWDCarteApiObjetAvecImage()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		CWDCarteApiObjet.prototype.constructor.apply(this, arguments);
	}
}

// Déclare l'héritage
CWDCarteApiObjetAvecImage.prototype = new CWDCarteApiObjet();
// Surcharge le constructeur qui a été effacé
CWDCarteApiObjetAvecImage.prototype.constructor = CWDCarteApiObjetAvecImage;

// Création options objet API
// Entrée :	clParam		Paramètres
// Sortie : Options objet API
CWDCarteApiObjetAvecImage.prototype._clCreationOptionObjetApi = function (clParam)
{
	var clOption = CWDCarteApiObjet.prototype._clCreationOptionObjetApi.apply(this, [clParam]);
	// Opacité
	clOption.opacity = WDCarteGoogleMaps.nOpaciteWLVersVue(clParam.m_nOpacite);
	return clOption;
};

// Chargement image
// Entrée :	clCarte			Carte API de l'objet
//			sUrlImage		URL image
//			eAlignement		Alignement image
//			bChargerImage	Indique si on doit charger l'image
// Sortie :	true si URL image OK, false sinon
CWDCarteApiObjetAvecImage.prototype.bChargeImage = function (clCarte, sUrlImage, eAlignement, bChargerImage)
{
	// URL image OK ?
	if (!(("string" == typeof sUrlImage) && !!sUrlImage))
	{
		// Non => URL incorrecte
		return false;
	}
	// On charge l'image ?
	if (bChargerImage)
	{
		// Oui => création image
		var clImage = new Image();
		// Objet pour fonction appelée par chargement image
		var clObjet = this;
		// Appelé au chargement de l'image
		clImage.onload = function ()
		{
			// Traitement image chargée
			clObjet.TraiteChargementImage(this, eAlignement);
			// Objet API ?
			if (clObjet.m_clObjetApi)
			{
				// Oui => refresh carte
				WDCarteGoogleMaps.RefreshCarte(clObjet.m_clObjetApi, clCarte);
			}
		};
		// Chargement image
		clImage.src = sUrlImage;
	}
	// URL image OK
	return true;
};

// Gestion clusters marqueurs carte API
function CWDCarteApiGestionClusterMarqueur(map, opt_markers, opt_options)
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		google.maps.OverlayView.prototype.constructor.apply(this, []);

		// Identifiant
		this.m_nId = 0;

		// Carte API
		this.map_ = map;

		// Marqueurs
		this.markers_ = [];

		// Clusters
		this.clusters_ = [];

		// Formes clusters
		this.m_tabForme =
			[
				{ m_nSeuil: 2, m_nTaille: 40, m_sCouleur: "#003b99" },
				{ m_nSeuil: 3, m_nTaille: 40, m_sCouleur: "#003d99" },
				{ m_nSeuil: 4, m_nTaille: 40, m_sCouleur: "#004299" },
				{ m_nSeuil: 5, m_nTaille: 40, m_sCouleur: "#004699" },
				{ m_nSeuil: 6, m_nTaille: 40, m_sCouleur: "#004899" },
				{ m_nSeuil: 7, m_nTaille: 40, m_sCouleur: "#004c99" },
				{ m_nSeuil: 8, m_nTaille: 40, m_sCouleur: "#005099" },
				{ m_nSeuil: 9, m_nTaille: 40, m_sCouleur: "#005499" },
				{ m_nSeuil: 10, m_nTaille: 45, m_sCouleur: "#005999" },
				{ m_nSeuil: 20, m_nTaille: 45, m_sCouleur: "#007b99" },
				{ m_nSeuil: 50, m_nTaille: 45, m_sCouleur: "#009954" },
				{ m_nSeuil: 100, m_nTaille: 48, m_sCouleur: "#489900" },
				{ m_nSeuil: 200, m_nTaille: 48, m_sCouleur: "#993d00" },
				{ m_nSeuil: 500, m_nTaille: 48, m_sCouleur: "#990000" },
				{ m_nSeuil: 1000, m_nTaille: 55, m_sCouleur: "#990000" }
			];

		// Indique si pret
		this.ready_ = false;

		// Options
		var options = opt_options || {};

		// Altitude
		this.zIndex_ = options["zIndex"] || google.maps.Marker.MAX_ZINDEX + 1;

		// Taille de grille
		this.gridSize_ = options["gridSize"] || 60;

		// Nombre minimum de marqueurs dans un cluster
		this.minClusterSize_ = options["minimumClusterSize"] || 2;

		// Zoom maximum
		this.maxZoom_ = options["maxZoom"] || null;

		// Indique si on zoom quand on clique sur un cluster
		this.zoomOnClick_ = true;
		if (options["zoomOnClick"] != undefined)
		{
			this.zoomOnClick_ = options["zoomOnClick"];
		}

		// Indique si on centre le cluster par rapport aux marqueurs qu'il contient
		this.averageCenter_ = false;
		if (options["averageCenter"] != undefined)
		{
			this.averageCenter_ = options["averageCenter"];
		}

		// Carte
		this.m_clCarte = options.m_clCarte;

		// Ajout gestion clusters à carte API
		this.setMap(map);

		// Zoom précédent
		this.prevZoom_ = this.map_.getZoom();

		// Gestion changement de zoom
		var that = this;
		google.maps.event.addListener(this.map_, "zoom_changed", function ()
		{
			// Controle zoom
			var zoom = that.map_.getZoom();
			var minZoom = that.map_.minZoom || 0;
			var maxZoom = Math.min(
				that.map_.maxZoom || 100,
				that.map_.mapTypes[that.map_.getMapTypeId()].maxZoom
			);
			zoom = Math.min(Math.max(zoom, minZoom), maxZoom);

			if (that.prevZoom_ != zoom)
			{
				that.prevZoom_ = zoom;
				that.resetViewport();
			}
		});

		// Gestion temps mort
		google.maps.event.addListener(this.map_, "idle", function ()
		{
			that.redraw();
		});

		// Ajout marqueurs
		if (
			opt_markers &&
			(opt_markers.length || Object.keys(opt_markers).length)
		)
		{
			this.addMarkers(opt_markers, false);
		}
	}
}

// Déclaration prototype
CWDCarteApiGestionClusterMarqueur.DeclarePrototype = function ()
{
	// Déclare l'héritage
	CWDCarteApiGestionClusterMarqueur.prototype = new google.maps.OverlayView();
	// Surcharge le constructeur qui a été effacé
	CWDCarteApiGestionClusterMarqueur.prototype.constructor = CWDCarteApiGestionClusterMarqueur;

	// Méthode appelée par gestion carte lors de l'ajout de l'élément dans la carte
	CWDCarteApiGestionClusterMarqueur.prototype.onAdd = function ()
	{
		this.setReady_(true);
		// Compteur
		var nCpt = 0;
		// this pour callback timer
		var clThis = this;
		var fDessin = function ()
		{
			// Dessin en attente ?
			if (!clThis.m_bDessinEnAttente)
			{
				// Non => rien à faire
				return;
			}
			// On a assez attendu ?
			if (nCpt++ > 0)
			{
				// Oui => dessin
				clThis.redraw();
			}
			else
			{
				// Non => on attend encore
				setTimeout(fDessin, 1);
			}
		};
		// Dessin
		fDessin();
	};

	// Méthode appelée par gestion carte dessin
	CWDCarteApiGestionClusterMarqueur.prototype.draw = function ()
	{
	};

	// Ajuste la carte pour contenir les marqueurs
	CWDCarteApiGestionClusterMarqueur.prototype.fitMapToMarkers = function ()
	{
		var markers = this.getMarkers();
		var bounds = new google.maps.LatLngBounds();
		for (var i = 0, marker; (marker = markers[i]); i++)
		{
			bounds.extend(marker.getPosition());
		}

		this.map_.fitBounds(bounds);
	};

	// Modif altitude
	CWDCarteApiGestionClusterMarqueur.prototype.setZIndex = function (zIndex)
	{
		this.zIndex_ = zIndex;
	};

	// Altitude
	CWDCarteApiGestionClusterMarqueur.prototype.getZIndex = function ()
	{
		return this.zIndex_;
	};

	// Indique si zoom surclic sur cluster
	CWDCarteApiGestionClusterMarqueur.prototype.isZoomOnClick = function ()
	{
		return this.zoomOnClick_;
	};

	// Indique si cluster centré sur ses marqueurs
	CWDCarteApiGestionClusterMarqueur.prototype.isAverageCenter = function ()
	{
		return this.averageCenter_;
	};

	// Marqueurs
	CWDCarteApiGestionClusterMarqueur.prototype.getMarkers = function ()
	{
		return this.markers_;
	};

	// Nombre marqueurs
	CWDCarteApiGestionClusterMarqueur.prototype.getTotalMarkers = function ()
	{
		return this.markers_.length;
	};

	// Modif zoom maximum
	CWDCarteApiGestionClusterMarqueur.prototype.setMaxZoom = function (maxZoom)
	{
		this.maxZoom_ = maxZoom;
	};

	// Zoom maximum
	CWDCarteApiGestionClusterMarqueur.prototype.getMaxZoom = function ()
	{
		return this.maxZoom_;
	};

	// Calcul paramètres affichage cluster
	CWDCarteApiGestionClusterMarqueur.prototype.calculator = function (markers)
	{
		// Résultat appel callback affichage cluster
		var clRes;
		// Carte ?
		if (this.m_clCarte)
		{
			// Oui => Appel callback affichage cluster de carte
			clRes = this.m_clCarte.AppelCallbackAffichageCluster(markers);
		}
		// Paramètres forme cluster
		var clParam = {};
		// Le résultat est un dino MarqueurImage (on teste si le membre forme existe au lieu de tester si le résultat est une instande de dino MarqueurImage sinon erreur en WD car dino pas défini) ?
		if (clRes && (clRes.m_eForme !== undefined))
		{
			// Oui => récupération infos dino
			clParam =
				{
					m_nFormeImage: clRes.m_eForme,
					m_nTailleFormeImage: clRes.m_nTaille,
					m_sCouleurFondFormeImage: WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(clRes.m_clCouleurFond),
					m_nOpaciteFondFormeImage: WDDinoBaseObjetCarte.nOpaciteDinoCouleur(clRes.m_clCouleurFond),
					m_sCouleurTraitFormeImage: WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(clRes.m_clCouleur),
					m_nOpaciteTraitFormeImage: WDDinoBaseObjetCarte.nOpaciteDinoCouleur(clRes.m_clCouleur),
					m_sTexteFormeImage: "" + clRes.m_sTexte
				};
		}
		// Non => le résultat est une chaîne non vide ?
		else if ((typeof clRes == "string") && clRes.length)
		{
			// Oui => c'est l'url de l'image
			clParam.m_sUrlImage = clRes;
		}
		else
		{
			// Non => nombre marqueurs
			var nNbMarqueur = markers.length;
			// Nombre de paramétrage de forme possibles
			var nNbFormes = this.m_tabForme.length;
			// Recherche paramétrage forme en fonction du nombre de marqueurs
			var nForme = 0;
			for (nForme = 0; nForme < nNbFormes; nForme++)
			{
				if (nNbMarqueur <= this.m_tabForme[nForme].m_nSeuil)
				{
					break;
				}
			}
			var clForme = this.m_tabForme[Math.min(nForme, nNbFormes - 1)];
			// Paramétrage forme cluster par défaut
			clParam =
				{
					m_nFormeImage: WDCarteAPI.nFormeRond,
					m_nTailleFormeImage: clForme.m_nTaille,
					m_sCouleurFondFormeImage: clForme.m_sCouleur,
					m_nOpaciteFondFormeImage: WDCarteAPI.nOpaciteCouleurWLMax,
					m_sCouleurTraitFormeImage: "white",
					m_nOpaciteTraitFormeImage: WDCarteAPI.nOpaciteCouleurWLMax / 2,
					m_sTexteFormeImage: "" + nNbMarqueur
				};
		}
		// Carte Api
		clParam.m_clCarteApi = { m_clCarte: this.map_ };
		// Image au-dessus du cluster
		clParam.m_nAncrageX = WDCarteAPI.emqHaut;
		// Paramétrage icone cluster
		return clParam;
	};

	// Affichage cluster
	CWDCarteApiGestionClusterMarqueur.prototype.AfficheCluster = function (clParam)
	{
		// Recherche cluster par id
		for (var nCluster = 0; nCluster < this.clusters_.length; nCluster++)
		{
			// Cluster parcouru
			var clCluster = this.clusters_[nCluster];
			// Le cluster est celui recherché ?
			if (clCluster.m_sId == clParam.m_sId)
			{
				// Affichage icone cluster
				clCluster.clusterIcon_.show(clParam);
				// Fin de la recherche
				return;
			}
		}
	};

	// Ajout marqueurs
	CWDCarteApiGestionClusterMarqueur.prototype.addMarkers = function (markers, opt_nodraw)
	{
		if (markers.length)
		{
			for (var i = 0, marker; (marker = markers[i]); i++)
			{
				this.pushMarkerTo_(marker);
			}
		} else if (Object.keys(markers).length)
		{
			for (var marker = 0; marker < markers.length; marker++)
			{
				this.pushMarkerTo_(markers[marker]);
			}
		}
		if (!opt_nodraw)
		{
			this.redraw();
		}
	};

	// Ajout marqueur
	CWDCarteApiGestionClusterMarqueur.prototype.pushMarkerTo_ = function (marker)
	{
		marker.isAdded = false;
		// Marqueur déplaçable ?
		if (marker["draggable"])
		{
			// Oui => ajout gestion clusters en fin de déplacement
			var that = this;
			google.maps.event.addListener(marker, "dragend", function ()
			{
				marker.isAdded = false;
				that.repaint();
			});
		}
		this.markers_.push(marker);
	};

	// Ajout marqueur
	CWDCarteApiGestionClusterMarqueur.prototype.addMarker = function (marker, opt_nodraw)
	{
		this.pushMarkerTo_(marker);
		if (!opt_nodraw)
		{
			this.redraw();
		}
	};

	// Suppression marqueur
	// Entrée :	marker						Marqueur à supprimer
	//			bNePasSuppprimerDeLaCarte	Indique si le marqueur ne doit pas être supprimé de la carte
	// Sortie :	true si marqueur supprimé, false sinon
	CWDCarteApiGestionClusterMarqueur.prototype.removeMarker_ = function (marker, bNePasSuppprimerDeLaCarte)
	{
		var index = -1;
		if (this.markers_.indexOf)
		{
			index = this.markers_.indexOf(marker);
		} else
		{
			for (var i = 0, m; (m = this.markers_[i]); i++)
			{
				if (m == marker)
				{
					index = i;
					break;
				}
			}
		}

		if (index == -1)
		{
			// Marker is not in our list of markers.
			return false;
		}

		// On suprime le marqueur de la carte ?
		if (!bNePasSuppprimerDeLaCarte)
		{
			// Oui => suppresion du marqueur de la carte
			marker.setMap(null);
		}

		this.markers_.splice(index, 1);

		return true;
	};

	// Suppression marqueur
	// Entrée :	marker						Marqueur à supprimer
	//			opt_nodraw					Indique si on ne veut pas réafficher la cluster
	//			bNePasSuppprimerDeLaCarte	Indique si le marqueur ne doit pas être supprimé de la carte
	// Sortie :	true si marqueur supprimé, false sinon
	CWDCarteApiGestionClusterMarqueur.prototype.removeMarker = function (marker, opt_nodraw, bNePasSuppprimerDeLaCarte)
	{
		var removed = this.removeMarker_(marker, bNePasSuppprimerDeLaCarte);

		if (!opt_nodraw && removed)
		{
			this.resetViewport();
			this.redraw();
			return true;
		} else
		{
			return false;
		}
	};

	// Suppression marqueurs
	CWDCarteApiGestionClusterMarqueur.prototype.removeMarkers = function (markers, opt_nodraw)
	{
		// La liste des marqueurs supprmiée est la liste des marqueurs de la gestion de clusters ? oui => Copie de la liste des marqueurs car la suppresion de marqueur modifie la liste des marqueurs
		var markersCopy = markers === this.getMarkers() ? markers.slice() : markers;
		var removed = false;

		for (var i = 0, marker; (marker = markersCopy[i]); i++)
		{
			var r = this.removeMarker_(marker);
			removed = removed || r;
		}

		if (!opt_nodraw && removed)
		{
			this.resetViewport();
			this.redraw();
			return true;
		}
	};

	// Activation
	CWDCarteApiGestionClusterMarqueur.prototype.setReady_ = function (ready)
	{
		if (!this.ready_)
		{
			this.ready_ = ready;
		}
	};

	// Nombre de clusters
	CWDCarteApiGestionClusterMarqueur.prototype.getTotalClusters = function ()
	{
		return this.clusters_.length;
	};

	// Carte API
	CWDCarteApiGestionClusterMarqueur.prototype.getMapApi = function ()
	{
		return this.map_;
	};

	// Modification carte API
	CWDCarteApiGestionClusterMarqueur.prototype.setMapApi = function (map)
	{
		this.map_ = map;
	};

	// Taille de grille
	CWDCarteApiGestionClusterMarqueur.prototype.getGridSize = function ()
	{
		return this.gridSize_;
	};

	// Modification taille grille
	CWDCarteApiGestionClusterMarqueur.prototype.setGridSize = function (size)
	{
		this.gridSize_ = size;
	};

	// Nombre minimum marqueur par cluster
	CWDCarteApiGestionClusterMarqueur.prototype.getMinClusterSize = function ()
	{
		return this.minClusterSize_;
	};

	// Modification nombre minimum marqueur par cluster
	CWDCarteApiGestionClusterMarqueur.prototype.setMinClusterSize = function (size)
	{
		this.minClusterSize_ = size;
	};

	// Ajout dimensions grille à une étendue
	CWDCarteApiGestionClusterMarqueur.prototype.getExtendedBounds = function (bounds)
	{
		var projection = this.getProjection();

		// Récupération extrémité étendue
		var tr = new google.maps.LatLng(
			bounds.getNorthEast().lat(),
			bounds.getNorthEast().lng()
		);
		var bl = new google.maps.LatLng(
			bounds.getSouthWest().lat(),
			bounds.getSouthWest().lng()
		);

		// Conversion en pixels et ajout dimensions grille
		var trPix = projection.fromLatLngToDivPixel(tr);
		trPix.x += this.gridSize_;
		trPix.y -= this.gridSize_;

		var blPix = projection.fromLatLngToDivPixel(bl);
		blPix.x -= this.gridSize_;
		blPix.y += this.gridSize_;

		// Conversion en coordonnées
		var ne = projection.fromDivPixelToLatLng(trPix);
		var sw = projection.fromDivPixelToLatLng(blPix);

		// On étend la zone pour contenir les nouvelles coordonnées
		bounds.extend(ne);
		bounds.extend(sw);

		return bounds;
	};

	// Indique si un marqueur est dans une zone
	CWDCarteApiGestionClusterMarqueur.prototype.isMarkerInBounds_ = function (marker, bounds)
	{
		return bounds.contains(marker.getPosition());
	};

	// Supprime tous les marqueurs
	CWDCarteApiGestionClusterMarqueur.prototype.clearMarkers = function ()
	{
		this.resetViewport(true);

		// On vide le tableau des marqueurs
		this.markers_ = [];
	};

	// Réinitialisation
	CWDCarteApiGestionClusterMarqueur.prototype.resetViewport = function (opt_hide)
	{
		// Supprime tous les clusters
		for (var i = 0, cluster; (cluster = this.clusters_[i]); i++)
		{
			cluster.remove();
		}

		// On note que les marqueurs ne sont plus dans gestion clusters et on les passe en invisible
		for (var i = 0, marker; (marker = this.markers_[i]); i++)
		{
			marker.isAdded = false;
			if (opt_hide)
			{
				marker.setMap(null);
			}
		}

		this.clusters_ = [];
	};

	// Affichage
	CWDCarteApiGestionClusterMarqueur.prototype.repaint = function ()
	{
		var oldClusters = this.clusters_.slice();
		this.clusters_.length = 0;
		this.resetViewport();
		this.redraw();

		// Suppression anciens clusters par timer pour permettre aux autres clusters de se dessiner avant
		setTimeout(function ()
		{
			for (var i = 0, cluster; (cluster = oldClusters[i]); i++)
			{
				cluster.remove();
			}
		}, 0);
	};

	// Réaffichage
	CWDCarteApiGestionClusterMarqueur.prototype.redraw = function ()
	{
		this.createClusters_();
	};

	// Calcule de la distance entre deux points en kilomètres
	CWDCarteApiGestionClusterMarqueur.prototype.distanceBetweenPoints_ = function (p1, p2)
	{
		if (!p1 || !p2)
		{
			return 0;
		}

		// Rayon de la terre en kilomètres
		var R = 6371;
		var dLat = ((p2.lat() - p1.lat()) * Math.PI) / 180;
		var dLon = ((p2.lng() - p1.lng()) * Math.PI) / 180;
		var a =
			Math.sin(dLat / 2) * Math.sin(dLat / 2) +
			Math.cos((p1.lat() * Math.PI) / 180) *
			Math.cos((p2.lat() * Math.PI) / 180) *
			Math.sin(dLon / 2) *
			Math.sin(dLon / 2);
		var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		var d = R * c;
		return d;
	};

	// Ajout marqueur à cluster nouveau ou existant
	CWDCarteApiGestionClusterMarqueur.prototype.addToClosestCluster_ = function (marker)
	{
		// Distance très grande
		var distance = 40000;
		var clusterToAddTo = null;
		for (var i = 0, cluster; (cluster = this.clusters_[i]); i++)
		{
			var center = cluster.getCenter();
			if (center)
			{
				var d = this.distanceBetweenPoints_(center, marker.getPosition());
				if (d < distance)
				{
					distance = d;
					clusterToAddTo = cluster;
				}
			}
		}

		if (clusterToAddTo && clusterToAddTo.isMarkerInClusterBounds(marker))
		{
			clusterToAddTo.addMarker(marker);
		} else
		{
			var newCluster = new CWDCarteApiCluster(this);
			newCluster.addMarker(marker);
			this.clusters_.push(newCluster);
		}
	};

	// Création clusters
	CWDCarteApiGestionClusterMarqueur.prototype.createClusters_ = function ()
	{
		if (!this.ready_)
		{
			// Dessin en attente
			this.m_bDessinEnAttente = true;
			return;
		}
		// Pas de dessin en attente
		this.m_bDessinEnAttente = false;
		// Get our current map view bounds.
		// Create a new bounds object so we don't affect the map.
		var mapBounds = new google.maps.LatLngBounds(
			this.map_.getBounds().getSouthWest(),
			this.map_.getBounds().getNorthEast()
		);
		var bounds = this.getExtendedBounds(mapBounds);

		for (var i = 0, marker; (marker = this.markers_[i]); i++)
		{
			if (!marker.isAdded && this.isMarkerInBounds_(marker, bounds))
			{
				this.addToClosestCluster_(marker);
			}
		}

		// Affichage icônes clusters
		for (var nCluster = 0; nCluster < this.clusters_.length; nCluster++)
		{
			this.clusters_[nCluster].updateIcon();
		}
	};

	// Identifiant
	CWDCarteApiGestionClusterMarqueur.prototype.sGetId = function ()
	{
		return "" + this.m_nId++;
	};
};


// Cluster de marqueurs de carte API
function CWDCarteApiCluster(markerClusterer)
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		this.markerClusterer_ = markerClusterer;
		// Id cluster
		this.m_sId = this.markerClusterer_.sGetId();
		this.map_ = markerClusterer.getMap();
		this.gridSize_ = markerClusterer.getGridSize();
		this.minClusterSize_ = markerClusterer.getMinClusterSize();
		this.averageCenter_ = markerClusterer.isAverageCenter();
		this.center_ = null;
		this.markers_ = [];
		this.bounds_ = null;
		this.clusterIcon_ = new CWDCarteApiIconeCluster(
			this,
			markerClusterer.getGridSize()
		);
	}
}

// Indique si marqueur déjà dans cluster
CWDCarteApiCluster.prototype.isMarkerAlreadyAdded = function (marker)
{
	if (this.markers_.indexOf)
	{
		return this.markers_.indexOf(marker) != -1;
	} else
	{
		for (var i = 0, m; (m = this.markers_[i]); i++)
		{
			if (m == marker)
			{
				return true;
			}
		}
	}
	return false;
};

// Ajout marqueur au cluster
CWDCarteApiCluster.prototype.addMarker = function (marker)
{
	if (this.isMarkerAlreadyAdded(marker))
	{
		return false;
	}

	if (!this.center_)
	{
		this.center_ = marker.getPosition();
		this.calculateBounds_();
	} else
	{
		if (this.averageCenter_)
		{
			var l = this.markers_.length + 1;
			var lat =
				(this.center_.lat() * (l - 1) + marker.getPosition().lat()) / l;
			var lng =
				(this.center_.lng() * (l - 1) + marker.getPosition().lng()) / l;
			this.center_ = new google.maps.LatLng(lat, lng);
			this.calculateBounds_();
		}
	}

	marker.isAdded = true;
	this.markers_.push(marker);

	var len = this.markers_.length;
	// Nombre de marqueurs dans le cluster suffisant ?
	if (len < this.minClusterSize_ && marker.getMap() != this.map_)
	{
		// Non => afichage du marqueur
		marker.setMap(this.map_);
	}

	if (len == this.minClusterSize_)
	{
		// Cache les marqueurs qui étaient affichés
		for (var i = 0; i < len; i++)
		{
			this.markers_[i].setMap(null);
		}
	}

	if (len >= this.minClusterSize_)
	{
		marker.setMap(null);
	}

	return true;
};

// Gestionnaire de clusters
CWDCarteApiCluster.prototype.getMarkerClusterer = function ()
{
	return this.markerClusterer_;
};

// Etendue du cluster
CWDCarteApiCluster.prototype.getBounds = function ()
{
	var bounds = new google.maps.LatLngBounds(this.center_, this.center_);
	var markers = this.getMarkers();
	for (var i = 0, marker; (marker = markers[i]); i++)
	{
		bounds.extend(marker.getPosition());
	}
	return bounds;
};

// Suppression du cluster
CWDCarteApiCluster.prototype.remove = function ()
{
	this.clusterIcon_.remove();
	this.markers_.length = 0;
	delete this.markers_;
};

// Nombre de marqueurs du cluster
CWDCarteApiCluster.prototype.getSize = function ()
{
	return this.markers_.length;
};

// Marqueurs du cluster
CWDCarteApiCluster.prototype.getMarkers = function ()
{
	return this.markers_;
};

// Centre du cluster
CWDCarteApiCluster.prototype.getCenter = function ()
{
	return this.center_;
};

// Etendue du cluster avec taille de la grille
CWDCarteApiCluster.prototype.calculateBounds_ = function ()
{
	var bounds = new google.maps.LatLngBounds(this.center_, this.center_);
	this.bounds_ = this.markerClusterer_.getExtendedBounds(bounds);
};

// Indique si un marqueur est dans la zone du cluster
CWDCarteApiCluster.prototype.isMarkerInClusterBounds = function (marker)
{
	return this.bounds_.contains(marker.getPosition());
};

// Carte API
CWDCarteApiCluster.prototype.getMap = function ()
{
	return this.map_;
};

// Mise à jour de l'icone du cluster
CWDCarteApiCluster.prototype.updateIcon = function ()
{
	var zoom = this.map_.getZoom();
	var mz = this.markerClusterer_.getMaxZoom();

	// Zoom maximum ?
	if (mz && zoom > mz)
	{
		// Oui => on affiche les marqueurs du cluster
		for (var i = 0, marker; (marker = this.markers_[i]); i++)
		{
			marker.setMap(this.map_);
		}
		return;
	}

	// Nombre de marqueurs dans le cluster suffisant ?
	if (this.markers_.length < this.minClusterSize_)
	{
		// Non => on cache l'icone
		this.clusterIcon_.hide();
		return;
	}
	// On a une callback d'affichage de cluster en WINDEV ?
	if (WDCarteAPI.gbCallbackClusterWD)
	{
		// Oui => on modifie la globale <gsIDClusterAffiche> que la OBJ va lire par timer en appelant MAP_sGetMarqueurAfficheClusterEtRaz()
		// On met l'identifiant du cluster pour que la OBJ puisse appeler la fonction d'affichage de cluster avec cet identifiant
		var sIdClusterAffiche = this.m_sId;
		// Ajout des identifiants des marqueurs de cluster pour que la OBJ puisse construire le tableau des marqeurs à passer en paramètre au pcode d'affichage de cluster
		for (var nMarqueur = 0; nMarqueur < this.markers_.length; nMarqueur++)
		{
			sIdClusterAffiche += "," + this.markers_[nMarqueur].ID_WD;
		}
		// On a déja mémorisé des infos de cluster
		if (WDCarteAPI.gsIDClusterAffiche)
		{
			// Oui => ajout séparateur
			WDCarteAPI.gsIDClusterAffiche += "\t";
		}
		// On ne remplit la variable qu'à la fin pour éviter que la callback appelé par timer de la OBJ ne vienne lire une chaîne incomplète
		WDCarteAPI.gsIDClusterAffiche += sIdClusterAffiche;
	}
	var sums = this.markerClusterer_.calculator(this.markers_);
	this.clusterIcon_.setCenter(this.center_);
	this.clusterIcon_.show(sums);
};

// Icone de cluster de marqueurs de carte API
function CWDCarteApiIconeCluster(cluster)
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		google.maps.Marker.prototype.constructor.apply(this);

		this.cluster_ = cluster;
		this.center_ = null;
		this.map_ = cluster.getMap();
		this.sums_ = null;
		this.visible_ = false;

		this.setMap(this.map_);
	}
}

// Déclaration prototype
CWDCarteApiIconeCluster.DeclarePrototype = function ()
{
	// Déclare l'héritage
	CWDCarteApiIconeCluster.prototype = new google.maps.Marker();
	// Surcharge le constructeur qui a été effacé
	CWDCarteApiIconeCluster.prototype.constructor = CWDCarteApiIconeCluster;

	// Gestion clic sur cluster
	CWDCarteApiIconeCluster.prototype.triggerClusterClick = function ()
	{
		var clusterBounds = this.cluster_.getBounds();
		var markerClusterer = this.cluster_.getMarkerClusterer();

		// Déclenche l'évènement de clic sur cluster
		google.maps.event.trigger(
			markerClusterer.map_,
			"clusterclick",
			this.cluster_
		);

		if (markerClusterer.isZoomOnClick())
		{
			// Zoom dans le cluster
			this.map_.fitBounds(clusterBounds);
			this.map_.setCenter(clusterBounds.getCenter());
		}
	};

	// Position en pixels correspondant à coordonnées
	CWDCarteApiIconeCluster.prototype.getPosFromLatLng_ = function (latlng)
	{
		var pos = this.getProjection().fromLatLngToDivPixel(latlng);
		pos.x -= parseInt(this.width_ / 2, 10);
		pos.y -= parseInt(this.height_ / 2, 10);
		return pos;
	};

	// Cache l'icone
	CWDCarteApiIconeCluster.prototype.hide = function ()
	{
		this.setMap(null);
		this.visible_ = false;
	};

	// Affiche l'icone
	CWDCarteApiIconeCluster.prototype.show = function (clParam)
	{
		// Paramètres affichage ?
		if (clParam)
		{
			// Oui => récupération paramètres
			this.setSums(clParam);
		}
		this.setPosition(this.center_);
		var clOption = {};
		new CWDCarteApiMarqueur(true).InitOptionImage(clOption, this.sums_.m_sUrlImage, this.sums_);
		this.setOptions(clOption);
		this.setMap(this.map_);
		this.visible_ = true;
	};

	// Enlève l'icone de la carte
	CWDCarteApiIconeCluster.prototype.remove = function ()
	{
		this.setMap(null);
	};

	// Modification paramètres icone
	CWDCarteApiIconeCluster.prototype.setSums = function (sums)
	{
		this.sums_ = sums;
	};

	// Modification centre icone
	CWDCarteApiIconeCluster.prototype.setCenter = function (center)
	{
		this.center_ = center;
	};

};

// Marqueur carte API
function CWDCarteApiMarqueur()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		CWDCarteApiObjetAvecImage.prototype.constructor.apply(this, arguments);
	}
}

// Déclare l'héritage
CWDCarteApiMarqueur.prototype = new CWDCarteApiObjetAvecImage();
// Surcharge le constructeur qui a été effacé
CWDCarteApiMarqueur.prototype.constructor = CWDCarteApiMarqueur;

// Création identifiant
CWDCarteApiMarqueur.prototype.sCreerIdentifiant = function ()
{
	// Identifiant marqueur
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypeMarqueur);
};

// Popup API commune à tous les marqueur pour ne pouvoir afficher qu'une popup à la fois
CWDCarteApiMarqueur.m_sclPopupApi = null;

// Recupération popup API
CWDCarteApiMarqueur.prototype.clPopupApi = function ()
{
	// Popup API déjà créée
	if (CWDCarteApiMarqueur.m_sclPopupApi == null)
	{
		// Non => on la crée
		var clPopup = CWDCarteApiMarqueur.m_sclPopupApi = new google.maps.InfoWindow();
		// Gestion fermeture popup
		google.maps.event.addListener(clPopup, 'closeclick', function ()
		{
			// On note que la popup est fermée
			this.m_bOuvert = false;
		});
		// Création div popup
		clPopup.m_clDivPopup = document.createElement("div");
		// Affectation contenu popup
		clPopup.setContent(clPopup.m_clDivPopup);
	}
	// Popup API
	return CWDCarteApiMarqueur.m_sclPopupApi;
};

// Initialisation options pour image
// Entrée :	clOption	Options objet API à modifier
//			sUrlImage	URL image
//			clParam		Paramètres
// Sortie : Options objet API modifié avec opti
CWDCarteApiMarqueur.prototype.InitOptionImage = function (clOption, sUrlImage, clParam)
{
	// Création image API (alignement pris en compte uniquement pour une image perso)
	clOption.icon = WDCarteGoogleMaps.ModifieMarqueurAlignement(clParam.m_clCarteApi.m_clCarte, this, sUrlImage, clParam.m_nAncrageX, clParam.m_nAncrageY);
	// Indique si image gérée par symboles
	var bImageSymbole = true;
	// Path symbole selon forme
	var sPathSymbole = "";
	switch (clParam.m_nFormeImage)
	{
		case WDCarteAPI.nFormeRond:
			var nRayon = clParam.m_nTailleFormeImage / 2;
			sPathSymbole = this.sPathPosition(0, nRayon) + this.sPathArc(nRayon, clParam.m_nTailleFormeImage, 0) + this.sPathArc(nRayon, -clParam.m_nTailleFormeImage, 0);
			break;
		case WDCarteAPI.nFormeCarre:
			sPathSymbole = this.sPathPosition(0, 0) + this.sPathTraitH(clParam.m_nTailleFormeImage) + this.sPathTraitV(clParam.m_nTailleFormeImage) + this.sPathTraitH(-clParam.m_nTailleFormeImage) + this.sPathTraitV(-clParam.m_nTailleFormeImage);
			break;
		case WDCarteAPI.nFormeCarreArrondi:
			var nRayonArrondi = clParam.m_nTailleFormeImage / 10;
			var nLngTrait = clParam.m_nTailleFormeImage - (2 * nRayonArrondi);
			sPathSymbole = this.sPathPosition(nRayonArrondi, 0) + this.sPathTraitH(nLngTrait) + this.sPathArc(nRayonArrondi, nRayonArrondi, nRayonArrondi) + this.sPathTraitV(nLngTrait) + this.sPathArc(nRayonArrondi, -nRayonArrondi, nRayonArrondi) + this.sPathTraitH(-nLngTrait) + this.sPathArc(nRayonArrondi, -nRayonArrondi, -nRayonArrondi) + this.sPathTraitV(-nLngTrait) + this.sPathArc(nRayonArrondi, nRayonArrondi, -nRayonArrondi);
			break;
		default:
			bImageSymbole = false;
			break;
	}
	// Image gérée par symbole ?
	if (bImageSymbole)
	{
		// Oui => position libellé
		var nPositionLibelle = clParam.m_nTailleFormeImage / 2;
		// Symbole
		clOption.icon =
			{
				path: sPathSymbole,
				anchor: { x: 0, y: 0 },
				fillColor: clParam.m_sCouleurFondFormeImage,
				fillOpacity: WDCarteGoogleMaps.nOpaciteCouleurWLVersVue(clParam.m_nOpaciteFondFormeImage),
				strokeColor: clParam.m_sCouleurTraitFormeImage,
				strokeOpacity: WDCarteGoogleMaps.nOpaciteCouleurWLVersVue(clParam.m_nOpaciteTraitFormeImage),
				labelOrigin: { x: nPositionLibelle, y: nPositionLibelle }
			};
		// Ancrage forme
		WDCarteAPI._CalculeAnchor(clParam.m_nAncrageX, clParam.m_nTailleFormeImage, clParam.m_nTailleFormeImage, clOption.icon.anchor);
	}
	// Etiquette (si pas d'étiquette, on met non défini et pas chaîne vide car le fait d'avoir une chaine même vide ralentit énormément les performances)
	clOption.label = (bImageSymbole && clParam.m_sTexteFormeImage) ? { text: "" + clParam.m_sTexteFormeImage, color: clParam.m_sCouleurTraitFormeImage } : undefined;
};

// Création options objet API
// Entrée :	clParam		Paramètres
// Sortie : Options objet API
CWDCarteApiMarqueur.prototype._clCreationOptionObjetApi = function (clParam)
{
	// Création options marqueur
	var clOption = CWDCarteApiObjetAvecImage.prototype._clCreationOptionObjetApi.apply(this, [clParam]);
	// Position
	clOption.position = this.m_clCoordApi;
	// Libellé
	clOption.title = clParam.m_sLibelle;
	// URL image
	var sUlrImage = '';
	// Image par défaut ?
	if (clParam.m_clCarteApi.m_sImageMarqueur_Initial != null)
	{
		// Oui => on prend image par défaut
		sUlrImage = clParam.m_clCarteApi.m_sImageMarqueur_Initial;
		// RAZ image par défaut
		clParam.m_clCarteApi.m_sImageMarqueur_Initial = null;
	}
	// Image redéfinie ?
	if (clParam.m_sImage && clParam.m_sImage.length)
	{
		// Oui => on prend image redéfinie
		sUlrImage = clParam.m_sImage;
	}
	// Init options image
	this.InitOptionImage(clOption, sUlrImage, clParam);
	// Altitude
	clOption.zIndex = clParam.m_nAltitude;
	// Déplaçable
	clOption.draggable = clParam.m_bDeplacable;
	// Evènement fin déplacement
	var sEvFinDeplacement = "dragend";
	// Marqueur API
	var clMarqueurApi = this.m_clObjetApi;
	// This dans callback
	var clThis = this;
	// Déplaçable
	if (clParam.m_bDeplacable)
	{
		// Nom propriété gestion callback fin déplacement
		var sNomPropCalbackFinDeplacement = this._sNomPropEvenement(sEvFinDeplacement);
		// Indique si évènement branché sur objet API
		var bEvenementBrancheSurObjetApi = clMarqueurApi[sNomPropCalbackFinDeplacement];
		// On stocke l'identifiant WD du dino (pointeur converti en chaîne) dans le marqueur API
		clMarqueurApi[sNomPropCalbackFinDeplacement] = clParam.m_sActionDeplacement;
		// Evènement branché sur Objet API ?
		if (!bEvenementBrancheSurObjetApi)
		{
			// Branchement évènement fin déplacement
			google.maps.event.addListener(clMarqueurApi, sEvFinDeplacement, function ()
			{
				// Position
				var clPosition = this.getPosition();
				// On modifie la globle <gsIDDeplacement> que la OBJ va lire par timer en appelant _sGetMarqueurDeplaceeEtRaz(). (format : <identifiant dino> + TAB + <latitude> + TAB + <longitude>)
				WDCarteAPI.gsIDDeplacement = this[sNomPropCalbackFinDeplacement] + "\t" + WDCarteGoogleMaps.sPositionVersChaine(clPosition);
				// Récupération dino correspondant à objet API déplacé
				var clDinoObjetApi = clThis._clDinoObjetApi(this, clParam);
				// Dino trouvé ?
				if (clDinoObjetApi != null)
				{
					// Oui => modification position dino
					clDinoObjetApi.SetLatitude(clPosition.lat());
					clDinoObjetApi.SetLongitude(clPosition.lng());
				}
				// Appel callback WLangage
				clThis._AppelCallbackWL(clMarqueurApi, clParam, sNomPropCalbackFinDeplacement);
				// Marqueur avec gestion cluster ?
				if (this.m_bCluster)
				{
					// Oui => réaffichage clusters
					clParam.m_clCarteApi.clGestionCluster().repaint();
				}
			});
		}
	}
	// Mémorisation paramètres dans marqueur API pour pouvoir les retrouver lors du clic sur le marqueur
	clMarqueurApi.m_clParam = clParam;
	// Popup ?
	if (clParam.m_bAvecPopup)
	{
		// Oui => la popup existe déjà ?
		if (!clMarqueurApi.m_clPopupApi)
		{
			// Non => on récupère la poup commune à tous les marqueurs
			clMarqueurApi.m_clPopupApi = this.clPopupApi();
			// Ouverture popup sur clic branché ?
			if (!clMarqueurApi.m_bClicOuvrePopup)
			{
				// Non => gestion clic sur marqueur api 
				clMarqueurApi.addListener("click", function ()
				{
					// Ouverture popup
					clParam.m_clCarteApi.bAffichePopup(this);
				});
				// Ouverture popup sur clic branché	
				clMarqueurApi.m_bClicOuvrePopup = true;
			}
		}
		// Mémorisation objet dans marqueur API pour pouvoir le retrouver lors du clic sur le marqueur
		clMarqueurApi.m_clObjet = this;
	}
	else
	{
		// Non => la popup exite ?
		if (clMarqueurApi.m_clPopupApi)
		{
			// Oui => on la détruit
			delete clMarqueurApi.m_clPopupApi;
		}
	}
	
	// Options objet API 
	return clOption;
};

// Opération après modification objet API
// Entrée :	clObjetApi					Objet API modifié
//			clParam						Paramètres
// Sortie : true si modification réussie, false sinon
CWDCarteApiMarqueur.prototype._ApresModificationObjetApi = function (clObjetApi, clParam)
{
	// Changement gestion cluster ?
	if ((!!clParam.m_bCluster) != (!!clObjetApi.m_bCluster))
	{
		// Oui => on note la nouvelle gestion de clusters dans le marqueur API
		clObjetApi.m_bCluster = clParam.m_bCluster;
		// Oui => récupération gestion clusters
		var clGestionCluster = clParam.m_clCarteApi.clGestionCluster();
		// Ajout gestion clusters ?
		if (clParam.m_bCluster)
		{
			// Oui => ajout marqueur à gestion clusters
			clGestionCluster.addMarker(clObjetApi);
		}
		else
		{
			// Non => retrait marqueur de gestion clusters
			clGestionCluster.removeMarker(clObjetApi, false, true);
		}
	}
	// Non => marqueur avec gestion cluster ?
	else if (clObjetApi.m_bCluster)
	{
		// Oui => réaffichage clusters
		clParam.m_clCarteApi.clGestionCluster().repaint();
	}
};

// Création objet API
// Sortie : Objet API créé
CWDCarteApiMarqueur.prototype._clCreationObjetApi = function ()
{
	// Création du marqueur
	return new google.maps.Marker();
};

// Tableau des objets API
// Entrée :	clParam		Paramètres
// Sortie : Tableau des objets API
CWDCarteApiMarqueur.prototype._tabObjetApi = function (clParam)
{
	// Tableau des marqueurs API
	return clParam.m_clCarteApi.m_tabMarker;
};

// Tableau des objets du champ
// Entrée :	clParam		Paramètres
// Sortie : Tableau des objets du champ
CWDCarteApiMarqueur.prototype._tabObjetChamp = function (clParam)
{
	// Tableau des marqueurs API
	return clParam.m_clCarteApi.m_oChamp.m_oDonnees.m_tabMarqueurs;
};

// Traitement chargement image
// Entrée :	clImage		Image chargée
//			eAlignement	Alignement image
CWDCarteApiMarqueur.prototype.TraiteChargementImage = function (clImage, eAlignement)
{
	// Calcul ancrage
	var clAncrage = new google.maps.Point(0, 0);
	WDCarteAPI._CalculeAnchor(eAlignement, clImage.width, clImage.height,/*OUT*/ clAncrage);
	// Objet API ?
	if (this.m_clObjetApi)
	{
		// Oui => modif ancrage objet API
		this.m_clObjetApi.icon.anchor = clAncrage;
	}
};

// Forme carte API
function CWDCarteApiForme()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		CWDCarteApiObjet.prototype.constructor.apply(this, arguments);
	}
}

// Déclare l'héritage
CWDCarteApiForme.prototype = new CWDCarteApiObjet();
// Surcharge le constructeur qui a été effacé
CWDCarteApiForme.prototype.constructor = CWDCarteApiForme;

// Nom variable clic WD
CWDCarteApiForme.prototype._sNomVarClicWD = function ()
{
	return "gsIDClicForme";
};

// Tableau des objets API
// Entrée :	clParam		Paramètres
// Sortie : Tableau des objets API
CWDCarteApiForme.prototype._tabObjetApi = function (clParam)
{
	// Tableau des formes API
	return clParam.m_clCarteApi.m_tabForme;
};

// Tableau des objets du champ
// Entrée :	clParam		Paramètres
// Sortie : Tableau des objets du champ
CWDCarteApiForme.prototype._tabObjetChamp = function (clParam)
{
	// Tableau des marqueurs API
	return clParam.m_clCarteApi.m_oChamp.m_oDonnees.m_tabFormes;
};

// Indique si la forme ne supporte que les traits continu
CWDCarteApiForme.prototype._bTraitContinuSeulement = function ()
{
	// par défaut, les formes ne supportent que les traits continus
	return true;
};

// Création options objet API
// Entrée :	clParam		Paramètres
// Sortie : Options objet API
CWDCarteApiForme.prototype._clCreationOptionObjetApi = function (clParam)
{
	var clOption = CWDCarteApiObjet.prototype._clCreationOptionObjetApi.apply(this, [clParam]);
	// Couleur trait
	clOption.strokeColor = clParam.m_sCouleurTrait;
	// Epaisseur trait
	clOption.strokeWeight = clParam.m_nEpaisseurTrait;
	// Opacité trait
	var nOpaciteTrait = WDCarteGoogleMaps.nOpaciteCouleurWLVersVue(clParam.m_nOpaciteTrait);
	// Indique si trait continu
	var bTraitContinu = this._bTraitContinuSeulement();
	// Trait forcémebt continu ?
	if (!bTraitContinu)
	{
		// Espacement entre tirets ou pointillés
		var nEspacement = 3;
		// Position dans le pattern
		var clPosition = { m_nPosition: 0 };
		// Pattern de trait selon type de trait
		var sPatternTrait = this.sPathPosition(0, 0);
		switch (clParam.m_nTypeTrait)
		{
			case WDCarteAPI.nTypeTraitMixte:
				sPatternTrait += this.sPathCoordV(clPosition, nEspacement) + this.sPathPositionV(clPosition, nEspacement) + this.sPathCoordV(clPosition, 1);
				break;
			case WDCarteAPI.nTypeTraitPointille:
				sPatternTrait += this.sPathCoordV(clPosition, 1);
				break;
			case WDCarteAPI.nTypeTraitTiret:
				sPatternTrait += this.sPathCoordV(clPosition, nEspacement);
				break;
			default:
				bTraitContinu = true;
				break;
		}
		//Trait continu ?
		if (!bTraitContinu)
		{
			// Non => on fixe le pattern de trait dans les options
			clOption.icons = [{ icon: { path: sPatternTrait, strokeOpacity: nOpaciteTrait }, repeat: "" + ((clPosition.m_nPosition + nEspacement) * clParam.m_nEpaisseurTrait) + "px" }];
		}
	}
	// Opacité trait (si le trait n'est pas continu, il faut rendre le trait invisible car l'affichage sera fait par symbole)
	clOption.strokeOpacity = bTraitContinu ? nOpaciteTrait : 0;
	// Altitude
	clOption.zIndex = clParam.m_nAltitude;
	// Options
	return clOption;
};

// Initialisation fond options objet API
// Entrée :	clParam		Paramètres
//			clOption	Options objet API
// Sortie : Options objet API initialisées
CWDCarteApiForme.prototype._InitFondOptionObjetApi = function (clParam, clOption)
{
	// Couleur fond
	clOption.fillColor = clParam.m_sCouleurFond;
	// Opacité fond
	clOption.fillOpacity = WDCarteGoogleMaps.nOpaciteCouleurWLVersVue(clParam.m_nOpaciteFond);
};

// Polyligne carte API
function CWDCarteApiPolyligne()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		CWDCarteApiForme.prototype.constructor.apply(this, arguments);
	}
}

// Déclare l'héritage
CWDCarteApiPolyligne.prototype = new CWDCarteApiForme();
// Surcharge le constructeur qui a été effacé
CWDCarteApiPolyligne.prototype.constructor = CWDCarteApiPolyligne;

// Création identifiant
CWDCarteApiPolyligne.prototype.sCreerIdentifiant = function ()
{
	// Identifiant polyligne
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypePolyligne);
};

// Indique si la forme ne supporte que les traits continu
CWDCarteApiPolyligne.prototype._bTraitContinuSeulement = function ()
{
	// Les lignes ne supportent pas que le trait continu
	return false;
};

// Création objet coordonnées API
// Entrée :	clParam			Paramètres
// Sortie : Objet coordonnées API créé (null en cas d'échec)
CWDCarteApiPolyligne.prototype._clCreationCoordApi = function (clParam)
{
	// Coordonnées
	var tabCoord = [];
	// Récupération coordonnées
	for (var nPoint = 0; nPoint < clParam.m_tabPoint.length; nPoint++)
	{
		// Coordonnées point
		var tabCoordPoint = clParam.m_tabPoint[nPoint];
		// Création position API
		var clPositionApi = WDCarteGoogleMaps.clCreationPositionApi(tabCoordPoint[0], tabCoordPoint[1]);
		// Position API OK ?
		if (clPositionApi == null)
		{
			// Non => échec
			return null;
		}
		// Ajout position API à tableau coordonnées
		tabCoord.push(clPositionApi);
	}
	// Objet coordonnées API
	return tabCoord;
};

// Création options objet API
// Entrée :	clParam		Paramètres
// Sortie : Options objet API
CWDCarteApiPolyligne.prototype._clCreationOptionObjetApi = function (clParam)
{
	var clOption = CWDCarteApiForme.prototype._clCreationOptionObjetApi.apply(this, [clParam]);
	clOption.path = this.m_clCoordApi;
	clOption.geodesic = clParam.m_bGeodesique;
	return clOption;
};

// Création objet API
// Sortie : Objet API créé
CWDCarteApiPolyligne.prototype._clCreationObjetApi = function ()
{
	// Création du polyligne
	return new google.maps.Polyline();
};

// Polygone carte API
function CWDCarteApiPolygone()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		CWDCarteApiPolyligne.prototype.constructor.apply(this, arguments);
	}
}

// Déclare l'héritage
CWDCarteApiPolygone.prototype = new CWDCarteApiPolyligne();
// Surcharge le constructeur qui a été effacé
CWDCarteApiPolygone.prototype.constructor = CWDCarteApiPolygone;

// Création identifiant
CWDCarteApiPolygone.prototype.sCreerIdentifiant = function ()
{
	// Identifiant polygone
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypePolygone);
};

// Indique si la forme ne supporte que les traits continu
CWDCarteApiPolygone.prototype._bTraitContinuSeulement = function ()
{
	// les polygones ne supportent que les traits continus
	return true;
};

// Création options objet API
// Entrée :	clParam		Paramètres
// Sortie : Options objet API
CWDCarteApiPolygone.prototype._clCreationOptionObjetApi = function (clParam)
{
	var clOption = CWDCarteApiPolyligne.prototype._clCreationOptionObjetApi.apply(this, [clParam]);
	// Fond
	this._InitFondOptionObjetApi(clParam, clOption);
	return clOption;
};

// Création objet API
// Sortie : Objet API créé
CWDCarteApiPolygone.prototype._clCreationObjetApi = function ()
{
	// Création du polygone
	return new google.maps.Polygon();
};

// Cercle carte API
function CWDCarteApiCercle()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		CWDCarteApiForme.prototype.constructor.apply(this, arguments);
	}
}

// Déclare l'héritage
CWDCarteApiCercle.prototype = new CWDCarteApiForme();
// Surcharge le constructeur qui a été effacé
CWDCarteApiCercle.prototype.constructor = CWDCarteApiCercle;

// Création identifiant
CWDCarteApiCercle.prototype.sCreerIdentifiant = function ()
{
	// Identifiant cercle
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypeCercle);
};

// Création options objet API
// Entrée :	clParam		Paramètres
// Sortie : Options objet API
CWDCarteApiCercle.prototype._clCreationOptionObjetApi = function (clParam)
{
	var clOption = CWDCarteApiForme.prototype._clCreationOptionObjetApi.apply(this, [clParam]);
	// Centre
	clOption.center = this.m_clCoordApi;
	// Rayon
	clOption.radius = clParam.m_nRayon;
	// Fond
	this._InitFondOptionObjetApi(clParam, clOption);
	return clOption;
};

// Création objet API
// Sortie : Objet API créé
CWDCarteApiCercle.prototype._clCreationObjetApi = function ()
{
	// Création du cercle
	return new google.maps.Circle();
};

// Image Google map API avec rotation
function CImageGoogleMapAvecRotation()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		google.maps.OverlayView.prototype.constructor.apply(this, []);
	}
}

CImageGoogleMapAvecRotation.DeclarePrototype = function ()
{

	// Hérite de la vue d'image Google map
	CImageGoogleMapAvecRotation.prototype = new google.maps.OverlayView();
	// Surcharge le constructeur qui a été effacé
	CImageGoogleMapAvecRotation.prototype.constructor = CImageGoogleMapAvecRotation;

	// Div image
	CImageGoogleMapAvecRotation.prototype.clDivImage = function ()
	{
		// Div image OK ?
		if (!this.m_clDiv)
		{
			// Non => création div image
			this.m_clDiv = document.createElement('div');
			var clStyle = this.m_clDiv.style;
			clStyle.borderStyle = 'none';
			clStyle.borderWidth = '0px';
			clStyle.position = 'absolute';
		}
		// Div image
		return this.m_clDiv;
	};

	// Méthode appelée quand image ajoutée à la carte
	CImageGoogleMapAvecRotation.prototype.onAdd = function ()
	{
		// Création image dans div
		var clImg = document.createElement('img');
		clImg.src = this.url;
		var clStyleImage = clImg.style;
		clStyleImage.width = '100%';
		clStyleImage.height = '100%';
		clStyleImage.position = 'absolute';
		var clDiv = this.clDivImage();
		clDiv.appendChild(clImg);
		// Ajout du div au plan des images
		this.getPanes().overlayMouseTarget.appendChild(clDiv);
		// On donne au div le même identifiant que son image associée pour pouvoir retrouver le dino CarteImage à partir du div lors du clic dans le div
		clDiv.ID_WD = this.ID_WD;
		// Branchement callback clic
		this.m_clObjet._BrancheCallback(clDiv, this.m_clParam, "click", this.m_clParam.m_sActionClic, this.m_clObjet._sNomVarClicWD(), true);
		// Style div objet API
		var clStyleDiv = clDiv.style;
		// Angle rotation
		clStyleDiv.transform = "rotate(" + this.m_clParam.m_nAngle + "deg)";
		// Altitude
		clStyleDiv.zIndex = this.m_clParam.m_nAltitude;
		// Opacité
		clStyleDiv.opacity = WDCarteGoogleMaps.nOpaciteWLVersVue(this.m_clParam.m_nOpacite);
	};

	// Méthode appelée lors du dessin de l'image
	CImageGoogleMapAvecRotation.prototype.draw = function ()
	{
		// Récupération projection
		var clProjection = this.getProjection();

		// Conversion coordonnées en pixels
		var clCoord = this.bounds;
		var clCoordSudOuestPixel = clProjection.fromLatLngToDivPixel(clCoord.getSouthWest());
		var clCoordNordEstPixel = clProjection.fromLatLngToDivPixel(clCoord.getNorthEast());

		// Redimensionnement du div
		var clStyle = this.m_clDiv.style;
		clStyle.left = clCoordSudOuestPixel.x + 'px';
		clStyle.top = clCoordNordEstPixel.y + 'px';
		clStyle.width = (clCoordNordEstPixel.x - clCoordSudOuestPixel.x) + 'px';
		clStyle.height = (clCoordSudOuestPixel.y - clCoordNordEstPixel.y) + 'px';
	};

	// Méthode appelée lors de la suppresion de l'image de la carte
	CImageGoogleMapAvecRotation.prototype.onRemove = function ()
	{
		// On enlève le div de la page
		this.m_clDiv.parentNode.removeChild(this.m_clDiv);
		// Réinit div
		this.m_clDiv = null;
	};
};

// Image carte API
function CWDCarteApiImage()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		CWDCarteApiObjetAvecImage.prototype.constructor.apply(this, arguments);
	}
}

// Déclare l'héritage
CWDCarteApiImage.prototype = new CWDCarteApiObjetAvecImage();
// Surcharge le constructeur qui a été effacé
CWDCarteApiImage.prototype.constructor = CWDCarteApiImage;

// Création identifiant
CWDCarteApiImage.prototype.sCreerIdentifiant = function ()
{
	// Identifiant image
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypeImage);
};

// Nom variable clic WD
CWDCarteApiImage.prototype._sNomVarClicWD = function ()
{
	return "gsIDClicImage";
};

// Tableau des objets API
// Entrée :	clParam		Paramètres
// Sortie : Tableau des objets API
CWDCarteApiImage.prototype._tabObjetApi = function (clParam)
{
	// Tableau des images API
	return clParam.m_clCarteApi.m_tabImage;
};

// Tableau des objets du champ
// Entrée :	clParam		Paramètres
// Sortie : Tableau des objets du champ
CWDCarteApiImage.prototype._tabObjetChamp = function (clParam)
{
	// Tableau des marqueurs API
	return clParam.m_clCarteApi.m_oChamp.m_oDonnees.m_tabImages;
};

// Déplacement vers nord
CWDCarteApiImage.nVersNord = 0;
// Déplacement vers sud
CWDCarteApiImage.nVersSud = 180;
// Déplacement vers est
CWDCarteApiImage.nVersEst = 90;
// Déplacement vers ouest
CWDCarteApiImage.nVersOuest = 270;

// Position API résultantes d'un décalage sur une coordonnée par rapport à une position API
// Entrée :	clPositionApi		Position API de départ
//			dDecalage			Décalage coordonnée
//			nDirection			Direction décalage (constante CWDCarteApiImage.nVers...)
CWDCarteApiImage.prototype._clDecalageCoordApi = function (clPositionApi, dDecalage, nDirection)
{
	// Décalage ?
	if (dDecalage)
	{
		// Oui => calcul position après décalage
		clPositionApi = google.maps.geometry.spherical.computeOffset(clPositionApi, dDecalage, nDirection);
	}
	// Position API après décalage
	return clPositionApi;
};

// Position API résultantes d'un décalage par rapport à une position API
// Entrée :	clPositionApi		Position API de départ
//			dDecalageLongitude	Décalage longitude
//			dDecalageLatitude	Décalage latitude
//			bVersNordEst		Indique si décalage vers nord-est
CWDCarteApiImage.prototype._clDecalagePositionApi = function (clPositionApi, dDecalageLongitude, dDecalageLatitude, bVersNordEst)
{
	// Position API après décalage
	return this._clDecalageCoordApi
		(
		this._clDecalageCoordApi(clPositionApi, dDecalageLongitude, bVersNordEst ? CWDCarteApiImage.nVersEst : CWDCarteApiImage.nVersOuest),
		dDecalageLatitude,
		bVersNordEst ? CWDCarteApiImage.nVersNord : CWDCarteApiImage.nVersSud
		);
};

// Calcul coordonnées API
// Entrée :	nHauteur	Hauteur
//			eAlignement	Alignement
// Sortie : Coordonnées API
CWDCarteApiImage.prototype._clCalculCoordApi = function (nHauteur, eAlignement)
{
	// Coin sud-ouest
	var clSudOuest = {};
	// Décalage longitude
	var dDecalageLongitude = this.m_dLargeur / 2;
	// Décalage latitude
	var dDecalageLatitude = nHauteur / 2;
	// Si l'alignement est
	switch (eAlignement)
	{
		// Bas :
		case WDCarteAPI.emqBas:
			// Le coin sud-ouest est décalé de la moitié de la largeur de l'image vers l'ouest et de la hauteur de l'image vers le sud par rapport à la position
			clSudOuest = this._clDecalagePositionApi(this.m_clPositionApi, dDecalageLongitude, nHauteur);
			break;
		// Haut :
		case WDCarteAPI.emqHaut:
			// Le coin sud-ouest est décalé de la moitié de la largeur de l'image vers l'ouest par rapport à la position
			clSudOuest = this._clDecalagePositionApi(this.m_clPositionApi, dDecalageLongitude);
			break;
		// Centré :
		case WDCarteAPI.emqCentre:
		// Centré par défaut :
		default:
			// Le coin sud-ouest est décalé de la moitié de la largeur de l'image vers l'ouest et de la moitié de la hauteur de l'image vers le sud par rapport à la position
			clSudOuest = this._clDecalagePositionApi(this.m_clPositionApi, dDecalageLongitude, dDecalageLatitude);
			break;
		// Droite :
		case WDCarteAPI.emqDroite:
			// Le coin sud-ouest est décalé de la moitié de la hauteur de l'image vers le nord par rapport à la position
			clSudOuest = this._clDecalagePositionApi(this.m_clPositionApi, 0, dDecalageLatitude);
			break;
		// Gauche :
		case WDCarteAPI.emqGauche:
			// Le coin sud-ouest est décalé de la largeur de l'image vers l'ouest et de la moitié de la hauteur de l'image vers le sud par rapport à la position
			clSudOuest = this._clDecalagePositionApi(this.m_clPositionApi, this.m_dLargeur, dDecalageLatitude);
			break;
	}
	// Coordonnées API
	return new google.maps.LatLngBounds(clSudOuest, this._clDecalagePositionApi(clSudOuest, this.m_dLargeur, nHauteur, true));
};

// Création objet coordonnées API
// Entrée :	clParam			Paramètres
// Sortie : Objet coordonnées API créé (null en cas d'échec)
CWDCarteApiImage.prototype._clCreationCoordApi = function (clParam)
{
	// Récupération position API
	this.m_clPositionApi = CWDCarteApiObjet.prototype._clCreationCoordApi.apply(this, [clParam]);
	// Position correcte ?
	if (this.m_clPositionApi == null)
	{
		// Non => échec
		return null;
	}
	// Récupération largeur image
	this.m_dLargeur = clParam.m_dLargeur;
	// Calcul coordonnées API
	return this._clCalculCoordApi(clParam.m_dHauteur, clParam.m_eAlignement);
};

// Modification coordonnées API
// Entrée :	clCoordApi	Nouvelles coordonnées API
CWDCarteApiImage.prototype._SetCoordApi = function (clCoordApi)
{
	this.m_clObjetApi.bounds = clCoordApi;
};

// Création options objet API
// Entrée :	clParam		Paramètres
// Sortie : Options objet API
CWDCarteApiImage.prototype._clCreationOptionObjetApi = function (clParam)
{
	var clOption = CWDCarteApiObjetAvecImage.prototype._clCreationOptionObjetApi.apply(this, [clParam]);
	// Coordonnées
	this._SetCoordApi(this.m_clCoordApi);
	// Chargement image
	this.bChargeImage(clParam.m_clCarteApi.m_clCarte, clParam.m_sImage, clParam.m_eAlignement, clParam.m_dHauteur == 0);
	// Image
	this.m_clObjetApi.url = clParam.m_sImage;
	// Mémorisation paramètres dans image API pour pouvoir les retrouver lors de l'ajout de l'objet image API dans la carte
	this.m_clObjetApi.m_clParam = clParam;
	// Mémorisation objet dans image API pour pouvoir le retrouver lors de l'ajout de l'objet image API dans la carte
	this.m_clObjetApi.m_clObjet = this;
	// Options
	return clOption;
};

// Création objet API
// Sortie : Objet API créé
CWDCarteApiImage.prototype._clCreationObjetApi = function ()
{
	// Création du image
	return new CImageGoogleMapAvecRotation(true);
};

// Traitement chargement image
// Entrée :	clImage		Image chargée
//			eAlignement	Alignement image
CWDCarteApiImage.prototype.TraiteChargementImage = function (clImage, eAlignement)
{
	// Calcul coordonées avec hauteur calculée pour garder proportions image
	this._SetCoordApi(this._clCalculCoordApi(this.m_dLargeur * clImage.height / clImage.width, eAlignement));
};

function WDCarteGoogleMaps(/*bEnModeWebDev*/)
{
	if (arguments.length)
	{
		WDCarteAPI.prototype.constructor.apply(this, arguments);

		//infos spécifiques à Google Maps
	}
}

// Declare l'heritage
WDCarteGoogleMaps.prototype = new WDCarteAPI();
// Surcharge le constructeur qui a ete efface
WDCarteGoogleMaps.prototype.constructor = WDCarteGoogleMaps;

//URL de l'API
WDCarteGoogleMaps.URL = "http://maps.google.com/maps/api/js?v=3&libraries=geometry";

// Déclaration des prototypes nécessaires qu'on doit déclarer en différé pour WinDev car dérivent de classes ggogle maps et le script google maps n'est inclus qu'au chargement de formulaire
WDCarteGoogleMaps.DeclarePrototype = function ()
{
	// Déclaration prototypes déjà faite ?
	if (WDCarteGoogleMaps.bDeclarePrototype)
	{
		// Oui => rien à faire
		return;
	}
	// Les prototypes vont être déclarés
	WDCarteGoogleMaps.bDeclarePrototype = true;
	// Déclaration prototype gestion clusters de marqueurs
	CWDCarteApiGestionClusterMarqueur.DeclarePrototype();
	// Déclaration prototype icone cluster
	CWDCarteApiIconeCluster.DeclarePrototype();
	// Déclaration prototype image avec rotation
	CImageGoogleMapAvecRotation.DeclarePrototype();
};

// convertion de ..ModeCarte vers la constante google correspondante
WDCarteGoogleMaps._nModeCarteWlVersGGl = function (nMode)
{
	//	#define nCarteMode2D		1
	if (nMode == 1)
	{
		return google.maps.MapTypeId.ROADMAP;
	}
	//	#define nCarteModeSatellite	2
	if (nMode == 2)
	{
		return google.maps.MapTypeId.HYBRID; // QW#247164
	}
	// defaut
	return google.maps.MapTypeId.ROADMAP;
};

// Création position API
// Entrée :	dLatitude		Latitude
//			dlongitude		Longitude
// Sortie : Position API créée (null en cas d'échec)
WDCarteGoogleMaps.clCreationPositionApi = function (dLatitude, dLongitude)
{
	// Coordonées valides ?
	if (!WDCarteAPI.bValideCoordonnees(dLatitude, dLongitude))
	{
		// Non => échec
		return null;
	}
	return new google.maps.LatLng(dLatitude, dLongitude);
};

// Création zone API
// Entrée :	dLatitudeNord		Latitude nord
//			dlongitudeOuest		Longitude ouest
//			dLatitudeSud		Latitude sud
//			dlongitudeEst		Longitude est
// Sortie : Zone API créée (null en cas d'échec)
WDCarteGoogleMaps.clCreationZoneApi = function (dLatitudeNord, dLongitudeOuest, dLatitudeSud, dLongitudeEst)
{
	// Coordonnées OK ?
	if ((dLatitudeNord <= dLatitudeSud) || (dLongitudeEst <= dLongitudeOuest))
	{
		// Non échec
		return null;
	}
	// Création limite sud-ouest
	var clLimiteSudOuest = WDCarteGoogleMaps.clCreationPositionApi(dLatitudeSud, dLongitudeOuest);
	// Limite sud-ouest OK ?
	if (clLimiteSudOuest == null)
	{
		// Non => échec
		return null;
	}
	// Création limite nord-est
	var clLimiteNordEst = WDCarteGoogleMaps.clCreationPositionApi(dLatitudeNord, dLongitudeEst);
	// Limite nord-est OK ?
	if (clLimiteNordEst == null)
	{
		// Non => échec
		return null;
	}
	// Création zone API
	return new google.maps.LatLngBounds(clLimiteSudOuest, clLimiteNordEst);
};

// Refraichissement carte objet API
// Entrée :	clObjet		Objet API
//			clCarte		Carte API
WDCarteGoogleMaps.RefreshCarte = function (clObjet, clCarte)
{
	clObjet.setMap(null);
	clObjet.setMap(clCarte);
};

// PAD le 09/12/2014 v: code revu pour TB#90077
// convertion d'un point courant de la vue en 256*256
WDCarteGoogleMaps.prototype.ConvPointToWord256x256 = function (point)
{
	var clProjection = this.m_clCarte.getProjection();

	// récup taille de la carte
	var domBalise = this.domGetBaliseSupport();
	var nLargeur = domBalise.clientWidth;	// style.width;
	var nHauteur = domBalise.clientHeight;	// style.height;

	// limite de la vue en coord 255*256 monde
	var bounds = this.m_clCarte.getBounds();
	// convertion en coord ecran courant
	var clNElatlng = bounds.getNorthEast();
	var clSWlatlng = bounds.getSouthWest();
	var ptNE256 = clProjection.fromLatLngToPoint(clNElatlng);
	var ptSW256 = clProjection.fromLatLngToPoint(clSWlatlng);
	if (ptNE256.x < ptSW256.x)
	{
		// cas si on voit la ligne de changement de date. QW#253011
		ptNE256.x += 256;
	}

	var nLargeurBound = ptNE256.x - ptSW256.x;
	var nHauteurBound = ptSW256.y - ptNE256.y;

	// convertion Ecran => 256*256 monde
	var pt256 = new google.maps.Point(0, 0);
	pt256.x = ptSW256.x + (point.x * nLargeurBound / nLargeur);
	if (pt256.x > 256)
	{
		// modulo 256 en fait
		pt256.x -= 256;
	}
	pt256.y = ptNE256.y + (point.y * nHauteurBound / nHauteur);

	return pt256;
};

// convertion d'un point monde en 256*256 en point courant de la vue
WDCarteGoogleMaps.prototype.ConvPointToVue = function (pt256)
{
	var clProjection = this.m_clCarte.getProjection();

	// récup taille de la carte
	var domBalise = this.domGetBaliseSupport();
	var nLargeur = domBalise.clientWidth;	// style.width;
	var nHauteur = domBalise.clientHeight;	// style.height;

	// limite de la vue en coord 255*256 monde
	var bounds = this.m_clCarte.getBounds();
	// convertion en coord ecran courant
	var clNElatlng = bounds.getNorthEast();
	var clSWlatlng = bounds.getSouthWest();
	var ptNE256 = clProjection.fromLatLngToPoint(clNElatlng);
	var ptSW256 = clProjection.fromLatLngToPoint(clSWlatlng);
	if (ptNE256.x < ptSW256.x)
	{
		// cas si on voit la ligne de changement de date
		ptNE256.x += 256;
	}

	var nLargeurBound = ptNE256.x - ptSW256.x;
	var nHauteurBound = ptSW256.y - ptNE256.y;

	// convertion 256*256 monde => Ecran
	var point = new google.maps.Point(0, 0);
	point.x = (nLargeur * (pt256.x - ptSW256.x)) / nLargeurBound;
	point.y = (nHauteur * (pt256.y - ptNE256.y)) / nHauteurBound;
	return point;
};

// Conversion opacité WLangage vers opacité vue
// Entrée :	nOpacite	Opacité WLangage
//			nOpaciteMax Opacité maximum (100 par défaut)
// Sortie :	Opacité vue correspondant à opacité WLangage
WDCarteGoogleMaps.nOpaciteWLVersVue = function (nOpacite, nOpaciteMax)
{
	return nOpacite / ((nOpaciteMax === undefined) ? 100: nOpaciteMax);
};

// Conversion opacité couleur WLangage vers opacité vue
// Entrée :	nOpacite	Opacité WLangage
// Sortie :	Opacité vue correspondant à opacité WLangage
WDCarteGoogleMaps.nOpaciteCouleurWLVersVue = function (nOpacite)
{
	return WDCarteGoogleMaps.nOpaciteWLVersVue(nOpacite, WDCarteAPI.nOpaciteCouleurWLMax);
};

// version interne de CarteAjouteItinéraire()
WDCarteGoogleMaps.prototype._bMarqueurExiste = function (positionRech)
{

	for (var i = 0; i < this.m_tabMarker.length; ++i)
	{
		var clMarkerI = this.m_tabMarker[i];
		if (clMarkerI != null
			&& clMarkerI.position.equals(positionRech)
		)
		{
			// trouvé
			return true;
		}
	}

	return false;
};

//retrouve la licence placée dans l'inclusion de l'API MAPS dans le document
WDCarteGoogleMaps.prototype._sGetLicence = function _sGetLicence()
{
	//retrouve le script d'inclusion de maps
	for (var iScript = 0; iScript < document.scripts.length; ++iScript)
	{
		var sSource = document.scripts[iScript].src;
		var sSourceAPI = "//maps.google.com/maps/api/js" + "?";
		var nPosSourceAPI = sSource.indexOf(sSourceAPI);
		if (nPosSourceAPI > -1)
		{
			var sKey = sSource.substr(sSourceAPI.length + nPosSourceAPI);
			//blindage
			if (!sKey)
			{
				return '';
			}
			return ('&' + sKey).replace('&v=3', ''); //sans la version
		}
	}
	return '';
};

// Appel requête récupération position depuis adresse
// Entrée :	sAdresse	Adresse dont on veut récupérer la position
// Sortie :	JSON résultat de la requête
WDCarteGoogleMaps.prototype.clJSONAppelRequeteRecupPositionAdresse = function (sAdresse)
{
	//utilise le service geocode de Google, ex :
	//https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA
	// Appel de la requête
	return clWDAJAXMain.JSONExecute("https://maps.googleapis.com/maps/api/geocode/json?address=" + sAdresse + this._sGetLicence());
};

// version interne de CarteAjouteItinéraire()
WDCarteGoogleMaps.prototype._AjouteItineraireDeVers = function (tabPositions, nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel)
{

	// QW#250760 : ne pas afficher les marqueurs, permet de mettre les siens
	var mYMarkerOptions = {
		visible: true
	};

	//analyse le tableau
	var tabAdresses = [];
	for (var index = 0; index < tabPositions.length; index++)
	{
		var element = tabPositions[index];

		var sAddresse = undefined;
		//[ [X,Y], [X,Y] , .... ]
		if (element instanceof Array)
		{
			// position de départ/arrivée
			//coordonées invalides ?
			if (!WDCarteAPI.bValideCoordonnees(element[0], element[1]))
			{
				// oui => quitte
				return "";
			}
			sAddresse = new google.maps.LatLng(element[0], element[1]);
			// si il exite un marqueur à la position on ne l'affiche pas comme android/IOS
			if (this._bMarqueurExiste(sAddresse))
			{
				mYMarkerOptions.visible = false;
			}
		}
		//[ lieu, lieu , .... ]
		else
		{
			sAddresse = element;
			//cas de l'itinéraire manuel
			if (nMode == 1)
			{
				//oui => il faut résoudre les adresses
				if (this.m_bModeWebDev)
				{
					// Récupération JSON résultat réquête récupération position depuis adresse
					var jsonAdresse = this.clJSONAppelRequeteRecupPositionAdresse(sAddresse);
					if (jsonAdresse && jsonAdresse.results && jsonAdresse.results.length > 0)
					{
						var stLocation = jsonAdresse.results[0].geometry.location;
						sAddresse = new google.maps.LatLng(stLocation.lat, stLocation.lng);
					}
					//else erreur : adresse inconnue
					//on saute l'étape
					else
					{
						continue;
					}
				}
				//else erreur : WinDev ne supportent pas les itinéraires manuels avec des adresses car la résolution requière un appel AJAX
				//=> or le framework JS n'est pas présent pour supporter cette implémentation
				//on saute l'étape
				else
				{
					continue;
				}
			}
		}
		//ajoute l'adresse à l'itineraire
		tabAdresses.push(sAddresse);
	}

	// convertion du mode WL vers API Google MAP
	var nModeGoogle = google.maps.DirectionsTravelMode.DRIVING;
	switch (nMode)
	{
		case 1: // ITINERAIRE_MANUEL
			nModeGoogle = google.maps.DirectionsTravelMode.DRIVING;
			break;
		case 2: // ITINERAIRE_PIETON
			nModeGoogle = google.maps.DirectionsTravelMode.WALKING;
			break;
		case 3: // ITINERAIRE_CYCLISTE
			nModeGoogle = google.maps.DirectionsTravelMode.BICYCLING;
			break;
		case 4: // ITINERAIRE_AUTOMOBILE
			nModeGoogle = google.maps.DirectionsTravelMode.DRIVING;
			break;
		case 5: // ITINERAIRE_AUTOMOBILE_NONOPTIMISE
			nModeGoogle = google.maps.DirectionsTravelMode.DRIVING;
			break;
	}

	var bOptionParDefaut = true;
	// gestion couleur
	var OptionsLigne = {};
	//options facultatives
	if (sColor !== undefined)
	{
		OptionsLigne.strokeColor = sColor;
		bOptionParDefaut = false;
	}
	if (nOpacite !== undefined)
	{
		OptionsLigne.strokeOpacity = nOpacite / 100;
		bOptionParDefaut = false;
	}
	if (nEpaisseur !== undefined)
	{
		OptionsLigne.strokeWeight = nEpaisseur;
		bOptionParDefaut = false;
	}
	//chemin avec waypoints ? sauf pour le cas de la Polyline car le Polyline ne peut pas être instancié à partir de lieux
	//(la résolution des points se fera après)
	if (tabAdresses.length > 2 && nMode != 1)
	{
		OptionsLigne.path = tabAdresses;
		bOptionParDefaut = false;
	}

	//à vol d'oiseau, inutile de DirectionsRenderer
	if (nMode == 1)
	{
		var clItineraire = new google.maps.Polyline(OptionsLigne);
		clItineraire.distanceEnMetre = 0.0;

		//itinéraire manuel => les coordonnées sont déjà résolues
		clItineraire.setPath(tabAdresses);
	}
	else
	{
		var clItineraire = new google.maps.DirectionsRenderer(
			bOptionParDefaut ? undefined : { polylineOptions: /*new google.maps.Polyline(*/OptionsLigne/*)*/, markerOptions: mYMarkerOptions }
		);
		clItineraire.distanceEnMetre = undefined;

		var directionsService = new google.maps.DirectionsService();
		var request =
			{
				origin: tabAdresses[0],
				destination: tabAdresses[tabAdresses.length - 1],
				travelMode: nModeGoogle
			};

		//waypoints ?
		if (tabAdresses.length > 0)
		{
			var tabWayPoints = [];
			for (var iWayPoint = 1; iWayPoint < tabAdresses.length - 1; ++iWayPoint)
			{
				tabWayPoints.push(
					{
						location: tabAdresses[iWayPoint]
						, stopover: true
					});
			}
			if (nMode != 5)
			{
				// nouveau mode WX21 : itinéraireAutomobileNonOptimise - sugg TB#93125
				request.optimizeWaypoints = true;
			}
			request.waypoints = tabWayPoints;
		}

		// reseingne l'itinéraire dans la closure
		directionsService.route(request, function (response, status)
		{
			// appelée lorsque l'itinéraire est calculé (ou erreur)
			if (status == google.maps.DirectionsStatus.OK)
			{
				clItineraire.setDirections(response);
				// Init distance
				clItineraire.distanceEnMetre = response.routes[0].legs[0].distance.value;
				// ajout des segments suppl;
				for (var i = 1; i < response.routes[0].legs.length; i++)
				{
					clItineraire.distanceEnMetre += response.routes[0].legs[i].distance.value
				}
			}
			else
			{
				clItineraire.distanceEnMetre = 0.0;
			}
		});
	}

	//ajoute l'itinéraire à la carte
	clItineraire.setMap(this.m_clCarte);

	// Ajout a la table des itineraires
	this.m_tabItineraire.push(clItineraire);

	//id de l'itineraire
	return (clItineraire.m_nID = (nIdOptionnel || WDCarteAPI.CreerIdentifiant()));
};

//en cas de changement de position
WDCarteGoogleMaps.prototype.EcouteChangementPosition = function (/*fChangementPosition*/)
{
	WDCarteAPI.prototype.EcouteChangementPosition.apply(this, arguments);
	//en cas de modification de la position
	if (this.m_clCarte !== undefined && this.m_fChangementPosition !== undefined)
	{
		//appellera la callback de changement de position
		google.maps.event.addListener(this.m_clCarte, 'center_changed', this.m_fChangementPosition);
	}


};

WDCarteGoogleMaps.prototype.CreateMap = function CreateMap(sNomChampCarte, fApresInit)
{
	// Init pos initiale
	//par défaut sur Paris
	var LatitudeCentre = WDCarteAPI.gnLatitudeDefaut;
	var LongitudeCentre = WDCarteAPI.gnLongitudeDefaut;
	if (this.m_nLatitude_Initial != null)
	{
		LatitudeCentre = this.m_nLatitude_Initial;
		LongitudeCentre = this.m_nLongitude_Initial;
	}
	//depuis adresse ?
	else if (this.m_sAdresse_Initial)
	{
		// on utiliser le geocoder de google.
		var geocoder = new google.maps.Geocoder();

		// demande a décoder l'adress avec retour asynchrone
		var oThis = this;
		geocoder.geocode({ 'address': this.m_sAdresse_Initial }, function (results, status)
		{
			// si on a a trouvé une position qui correspond
			if (status == google.maps.GeocoderStatus.OK)
			{
				var oPosition = results[0].geometry.location;
				oThis.m_nLatitude_Initial = oPosition.lat();
				oThis.m_nLongitude_Initial = oPosition.lng();
				oThis.CreateMap(sNomChampCarte, fApresInit);
			}
		});
		return;
	}

	//zoom init
	var nZoom = WDCarteAPI.gnZoomDefaut;
	if (this.m_nZoom_Initial != null)
	{
		nZoom = this.m_nZoom_Initial;
	}
	if (nZoom == 0)
	{
		nZoom = 4;
	}


	var mapOptions =
		{
			center: new google.maps.LatLng(LatitudeCentre, LongitudeCentre),
			zoom: nZoom,
			mapTypeControl: true,
			mapTypeId: WDCarteGoogleMaps._nModeCarteWlVersGGl(this.m_nTypeCarte_Initial),
			mapTypeControlOptions: { style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR },
			navigationControl: true,
			zoomControl: true,
			panControl: true,
			scaleControl: true,
			keyboardShortcuts: false,
			disableDefaultUI: false,
			noClear: false,
			streetViewControl: true,
			streetViewControlOptions: { position: google.maps.ControlPosition.LEFT_TOP }
		};

	mapOptions.zoomControl = this.m_bAfficheControleZoom_Initial;
	mapOptions.panControl = this.m_bAfficheControleZoom_Initial;
	mapOptions.scaleControl = this.m_bAfficheControleZoom_Initial;

	//identifiant de la balise support
	this.m_sId = sNomChampCarte;
	//création de l'objet Map de Google
	this.m_clCarte = new google.maps.Map(this.domGetBaliseSupport(), mapOptions);

	// Info trafic
	this.MAP_SetInfoTrafic(this.m_bInfoTrafic_Initial);

	// Boussole
	this.MAP_SetBoussole(this.m_bBoussole_Initial);

	// Angle rotation
	this.MAP_SetAngleRotation(this.m_nAngleRotation_Initial);

	// Inclinaison
	this.MAP_SetInclinaison(this.m_nInclinaison_Initial);

	//@Test :a ajout d'un moyen de savoir quand toutes les images sont chargées. - TB#92680
	google.maps.event.addListener(this.m_clCarte, 'tilesloaded', function (/*evt*/)
	{
		WDCarteAPI.m_bToutEstCharge = true;
	});

	// Mise à jour zoom dans données champ WebDev si changement de zoom par interface utilisateur
	var clThis = this;
	google.maps.event.addListener(this.m_clCarte, "zoom_changed", function ()
	{
		// Champ WebDev ?
		if (clThis.bChampWebDev())
		{
			// Oui => récupération zoom carte
			var nZoom = clThis.MAP_GetZoom();
			// Zoom OK (à l'init de la carte on est appelé avec valeur 0 => il ne faut pas modifier le champ Webdev dans ce cas) ?
			if (nZoom > 0)
			{
				// Oui => récupération zoom dans données champs
				clThis.m_oChamp.m_oDonnees.m_nZoom = nZoom;
				// Mise à jour champ caché pour champ WebDev avec les données
				clThis.m_oChamp.__UpdateChampCache();
			}
		}
	});
	
	//après init
	!fApresInit || fApresInit(this);
};

WDCarteGoogleMaps.prototype.MAP_bGetToutEstCharge = function ()
{
	return WDCarteAPI.m_bToutEstCharge;
};

// fonctions WL :

// CarteAffichePosition() 1/2
WDCarteGoogleMaps.prototype.MAP_SetPosition = function (dLatitude, dLongitude, bAnimation, fCallback)
{
	//coordonées invalides ?
	if (!WDCarteAPI.bValideCoordonnees(dLatitude, dLongitude))
	{
		// oui => quitte
		return false;
	}
	//récupère le singleton
	var newPos = new google.maps.LatLng(dLatitude, dLongitude);
	if (bAnimation)
	{
		this.m_clCarte.panTo(newPos);
	}
	else
	{
		this.m_clCarte.setCenter(newPos);
	}
	//appel de la callback
	!fCallback || fCallback(true);
};

// CarteAffichePosition() 2/2
WDCarteGoogleMaps.prototype.MAP_SetPositionLieux = function (Lieux, bAnimation, fCallback)
{
	// RAZ valeur de retour
	WDCarteAPI.gsRetVal_SetPositionLieux = "*";

	// on utiliser le geocoder de google.
	var geocoder = new google.maps.Geocoder();

	// demande a décoder l'adress avec retour asynchrone
	var oThis = this;
	geocoder.geocode({ 'address': Lieux }, function (results, status)
	{
		// si on a a trouvé une position qui correspond
		if (status == google.maps.GeocoderStatus.OK)
		{
			if (bAnimation)
			{
				oThis.m_clCarte.panTo(results[0].geometry.location);
			}
			else
			{
				oThis.m_clCarte.setCenter(results[0].geometry.location);
			}
			WDCarteAPI.gsRetVal_SetPositionLieux = "1"; // succes
			//appel de la callback
			!fCallback || fCallback(true);
		}
		else
		{
			WDCarteAPI.gsRetVal_SetPositionLieux = "0"; // echec
			//appel de la callback
			!fCallback || fCallback(false);
		}
	});

};

// Conversion position en chaîne
// Entrée :	clPosition	Position
// Sortie : Conversion en chaîne (format "<Latitude>,<Longitude>")
WDCarteGoogleMaps.sPositionVersChaine = function (clPosition)
{
	//Conversion position en chaîne
	return WDCarteAPI.sCoordVersChaine(clPosition.lat(), clPosition.lng());
};

// pour récupérer une positoin a partir d'un lieu. interne OBJ
// résultat Mis en globales pour gestion asynchronisme.§
WDCarteGoogleMaps.prototype.MAP_GetPositionLieux = function (Lieux)
{
    try {
        // RAZ valeur de retour
        WDCarteAPI.gsRetVal_SetPositionLieux = "*";

        // on utiliser le geocoder de google.
        var geocoder = new google.maps.Geocoder();

        // demande a décoder l'adress avec retour asynchrone
        geocoder.geocode({ 'address': Lieux }, function (results, status) {
            // si on a a trouvé une position qui correspond
            if (status == google.maps.GeocoderStatus.OK) {
				var stLocation = results[0].geometry.location;
				WDCarteAPI.gsRetVal_SetPositionLieux = WDCarteGoogleMaps.sPositionVersChaine(stLocation); // succes
            }
            else {
                WDCarteAPI.gsRetVal_SetPositionLieux = "0"; // echec
            }
        });
    }
    catch (erreur) {
        // echec. 
        // ex : arrirve si clé de licence invalide
        WDCarteAPI.gsRetVal_SetPositionLieux = "0"; // echec
    }


};

// CarteRécupèrePosition()
WDCarteGoogleMaps.prototype.MAP_GetPosition = function ()
{
    try {
		// retour de la position au langage
		return WDCarteGoogleMaps.sPositionVersChaine(this.m_clCarte.getCenter());
    }
    catch (erreur) {
        // echec. 
        // ex : arrirve si clé de licence invalide
        WDCarteAPI.gsRetVal_SetPositionLieux = "0"; // echec
    }
};

// CarteInfoXY ()
WDCarteGoogleMaps.prototype.MAP_GetPositionFromPoint = function (x, y)
{
	// récup de la projection de la carte
	var clProjection = this.m_clCarte.getProjection();
	if (clProjection == null)
	{
		// carte pas encore finie d'être chargée.
		return "";
	}

	// point en coord vue courante
	// + convertion en 256*256 monde, comme le demande fromPointToLatLng
	var clPointDiv = new google.maps.Point(x, y);
	var clPoint256 = this.ConvPointToWord256x256(clPointDiv);

	// récup des coordonées et retour de la position au langage
	return WDCarteGoogleMaps.sPositionVersChaine(clProjection.fromPointToLatLng(clPoint256));
};

// CarteInfoPosition()
WDCarteGoogleMaps.prototype.MAP_GetPointFromPosition = function (dLatitude, dLongitude)
{
	//coordonées invalides ?
	if (!WDCarteAPI.bValideCoordonnees(dLatitude, dLongitude))
	{
		// oui => quitte
		return "";
	}
	// récup de la projection de la carte
	var clProjection = this.m_clCarte.getProjection();
	if (clProjection == null)
	{
		// carte pas encore finie d'être chargée.
		return "";
	}

	// crée une coord avec latidute/longitude
	var Pos = new google.maps.LatLng(dLatitude, dLongitude);
	// récup des coordonées en 256x256 monde
	var ClPoint256 = clProjection.fromLatLngToPoint(Pos);
	// convertion en coorodnée vue
	var ClPoint = this.ConvPointToVue(ClPoint256);

	// retour de la position au langage
	return WDCarteAPI.sCoordVersChaine(ClPoint.x, ClPoint.y);
};

// ..Zoom=
WDCarteGoogleMaps.prototype.MAP_SetZoom = function (Zoom)
{
	this.m_clCarte.setZoom(Zoom);
};
// ..Zoom=zoomAdapteTaille
WDCarteGoogleMaps.prototype.MAP_SetZoomAdapte = function ()
{
	// sans effet si aucun marqueur
	if (this.m_tabMarker.length <= 0)
	{
		return;
	}

	var TabLabLng = new google.maps.LatLngBounds();
	for (var i = 0; i < this.m_tabMarker.length; i++)
	{
		TabLabLng.extend(this.m_tabMarker[i].position);
	}

	this.m_clCarte.fitBounds(TabLabLng);
};

// CarteAfficheZone()
WDCarteGoogleMaps.prototype.MAP_AfficheZone = function (dLatitudeNord, dLongitudeOuest, dLatitudeSud, dLongitudeEst)
{
	// Récupération zone
	var clZone = WDCarteGoogleMaps.clCreationZoneApi(dLatitudeNord, dLongitudeOuest, dLatitudeSud, dLongitudeEst);
	// Zone OK ?
	if (!clZone)
	{
		// Non => échec
		return false;
	}
	// Affichage zone
	this.m_clCarte.fitBounds(clZone);
	// OK
	return true;
};

// CarteLimiteZone()
WDCarteGoogleMaps.prototype.MAP_LimiteZone = function (dLatitudeNord, dLongitudeOuest, dLatitudeSud, dLongitudeEst)
{
	// Paramètres limitation
	var clParamLimite;
	// Limites précisées ?
	if (dLatitudeNord !== undefined)
	{
		// Oui => récupération zone
		var clZone = WDCarteGoogleMaps.clCreationZoneApi(dLatitudeNord, dLongitudeOuest, dLatitudeSud, dLongitudeEst);
		// Zone OK ?
		if (!clZone)
		{
			// Non => échec
			return false;
		}
		// Oui => initialisation paramètres limitation
		clParamLimite = { latLngBounds: clZone };
	}
	// Limitation zone
	this.m_clCarte.setOptions({ restriction: clParamLimite });
	// OK
	return true;
};

// CarteChangeStyle()
WDCarteGoogleMaps.prototype.MAP_ChangeStyle = function (nIdStyle, tabStylePerso)
{
	// Style
	var tabStyle;
	// Si le style demandé est
	switch (nIdStyle)
	{
		// Automatique :
		case WDCarteAPI.nStyleAuto:
			// Style par défaut car pas de thème sombre en code navigateur (en IOS/Android, on renvoie style sombre si on est en thème sombre)
			nIdStyle = WDCarteAPI.nStyleDefaut;
			// break;
		// Style par défaut :
		case WDCarteAPI.nStyleDefaut:
			// Rien à faire
			break;
		// Style prédéfini :
		case WDCarteAPI.nStyleSombre:
		case WDCarteAPI.nStyleNuit:
		case WDCarteAPI.nStyleArgent:
		case WDCarteAPI.nStyleRetro:
		case WDCarteAPI.nStyleAubergine:
			// Récupération style prédéfini
			tabStyle = WDCarteAPI.tabStyle[nIdStyle];
			break;
		// Style perso :
		case WDCarteAPI.nStylePerso:
			// Récupération style perso
			tabStyle = tabStylePerso;
			break;
		// Autre :
		default:
			// Echec
			return false;
	}
	// Modification style carte
	this.m_clCarte.setOptions({ styles: tabStyle });
	// Récupération style
	this.m_nStyle = nIdStyle;
	// OK
	return true;
};

// CarteRécupèreStyle()
WDCarteGoogleMaps.prototype.MAP_RecupereStyle = function ()
{
	// Récupération style
	return this.m_nStyle;
};

// Affichage image popup marqueur
// sURLImagePopup	URL image popup
WDCarteGoogleMaps.prototype.MAP_AfficheImagePopupMarqueur = function (sURLImagePopup)
{
	// Récupération popup
	var clPopup = CWDCarteApiMarqueur.m_sclPopupApi;
	if (!clPopup)
	{
		return;
	}
	// Récupération div popup
	var clDivPopup = clPopup.m_clDivPopup;
	if (!clDivPopup)
	{
		return;
	}
	// Affichage image popup
	clDivPopup.innerHTML = "<img src='" + sURLImagePopup + "'>";
};

// CarteAjouteMarqueur
// <nAncrageX> ancrage horizontal ou alignement du marqueur au format Dino WL.
WDCarteGoogleMaps.prototype.MAP_AjouteMarqueur = function (dLatitude, dLongitude, sLibelle, sActionClic, sImage, nIdOptionnel, nAncrageX, nAncrageY, nOpacite, nAltitude, bDeplacable, sActionDeplacement, bAvecPopup, sNom, sActionClicPopup, bCluster, nFormeImage, nTailleFormeImage, sTexteFormeImage, sCouleurTraitFormeImage, nOpaciteTraitFormeImage, sCouleurFondFormeImage, nOpaciteFondFormeImage, sIdPourPopup)
{
	// Ajout marqueur
	return new CWDCarteApiMarqueur(true).nAjout
		(
		{
			m_clCarteApi: this,
			m_dLongitude: dLongitude,
			m_dLatitude: dLatitude,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_sImage: sImage,
			m_nID: nIdOptionnel,
			m_nAncrageX: nAncrageX,
			m_nAncrageY: nAncrageY,
			m_nOpacite: nOpacite,
			m_nAltitude: nAltitude,
			m_bDeplacable: bDeplacable,
			m_sActionDeplacement: sActionDeplacement,
			m_bAvecPopup: bAvecPopup,
			m_sNom: sNom,
			m_sActionClicPopup: sActionClicPopup,
			m_nFormeImage: nFormeImage,
			m_bCluster: bCluster,
			m_nTailleFormeImage: nTailleFormeImage,
			m_sTexteFormeImage: sTexteFormeImage,
			m_sCouleurTraitFormeImage: sCouleurTraitFormeImage,
			m_nOpaciteTraitFormeImage: nOpaciteTraitFormeImage,
			m_sCouleurFondFormeImage: sCouleurFondFormeImage,
			m_nOpaciteFondFormeImage: nOpaciteFondFormeImage,
			m_sIdPourPopup: sIdPourPopup
		}
		);
};

// Modification alignement marqueur
// Entrée :	clCarteApi	Carte API
//			clMarqueur	Marqueur API
//			sUrlImage	Url image marqueur
//			nAncrageX	Ancrage horizontal image
//			nAncrageY	Ancrage vertical image
// Sortie :	Icone options API marqueur (chaîne vide si pas d'image ou problème chargement image)
WDCarteGoogleMaps.ModifieMarqueurAlignement = function (clCarteApi, clMarqueur, sUrlImage, nAncrageX, nAncrageY)
{
	//Indique on doit charger l'image (si l'ancrage vertical n'est pas défini, l'ancrage horizontal est en fait l'alignement et il faut charger l'image pour calculer les ancrages)
	var bChargerImage = (nAncrageY === undefined);
	// URL image OK ?
	if (!clMarqueur.bChargeImage(clCarteApi, sUrlImage, nAncrageX, bChargerImage))
	{
		// Non => pas d'orientation pour les images par défaut
		return "";
	}
	// Icone marqueur
	var clIcone = { url: sUrlImage, origin: new google.maps.Point(0, 0) };
	// Chargement image ?
	if (!bChargerImage)
	{
		// Non => ancrage déjà calculé
		clIcone.anchor = new google.maps.Point(nAncrageX, nAncrageY);
	}
	//Icone marqueur
	return clIcone;
};

// Suppression objet
// Entrée :	nIdObjet				Identifiant objet à supprimer
//			tabObjet				Tableau contenant objet
//			fnMethodeModifTableau	Méthode modification tableau objet
// Sortie :	true si objet supprimé, false sinon
WDCarteGoogleMaps.prototype._bMAP_SupprimeObjet = function (nIdObjet, tabObjet, fnMethodeModifTableau)
{
	// Tableau résultat
	var tabObjetResultat = [];
	// Suppression objet
	for (var nObjet = 0; nObjet < tabObjet.length; ++nObjet)
	{
		// Récupération objet
		var clObjet = tabObjet[nObjet];
		// L'objet est celui recherché ?
		if (clObjet.ID_WD != nIdObjet)
		{
			// Non => on le met dans le tableau résultat
			tabObjetResultat.push(clObjet);
		}
		else
		{
			// Oui => on supprime de la carte puis du tableau (en ne le mettant pas dans le tableau résultat)
			clObjet.setMap(null);
		}
	}
	// Marqueur trouvé ?
	if (tabObjet.length === tabObjetResultat.length)
	{
		// Non => échec
		return false;
	}
	// Oui => modification tableau
	fnMethodeModifTableau.apply(this, [tabObjetResultat]);
	// Objet supprimé
	return true;
};

// CarteSupprimeMarqueur
WDCarteGoogleMaps.prototype.MAP_SupprimeMarqueur = function (nID)
{
	// Gestion cluster ?
	if (this.m_clGestionCluster)
	{
		// Oui => récupération marqueur par Identifiant
		var clMarqueur = this.clMarqueurParId(nID);
		// Marqueur OK ?
		if (!clMarqueur)
		{
			// Non => échec
			return false;
		}
		// Marqueur avec gestion cluster ?
		if (clMarqueur.m_bCluster)
		{
			// Oui => suppression marqueur de gestion clusters
			this.m_clGestionCluster.removeMarker(clMarqueur);
		}
	}
	// Supprime le marqueur
	return this._bMAP_SupprimeObjet(nID, this.m_tabMarker, this._SetTableauMarqueur);
};

// CarteModifieMarqueur
WDCarteGoogleMaps.prototype.MAP_ModifieMarqueur = function (nId, dLatitude, dLongitude, sLibelle, sImage, nAncrageX, nAncrageY, sActionClic, nOpacite, nAltitude, bDeplacable, sActionDeplacement, bAvecPopup, sNom, sActionClicPopup, bCluster, nFormeImage, nTailleFormeImage, sTexteFormeImage, sCouleurTraitFormeImage, nOpaciteTraitFormeImage, sCouleurFondFormeImage, nOpaciteFondFormeImage, sIdPourPopup)
{
	// Modification marqueur
	return new CWDCarteApiMarqueur(true).Modification
		(
		{
			m_clCarteApi: this,
			m_dLongitude: dLongitude,
			m_dLatitude: dLatitude,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_sImage: sImage,
			m_nID: nId,
			m_nAncrageX: nAncrageX,
			m_nAncrageY: nAncrageY,
			m_nOpacite: nOpacite,
			m_nAltitude: nAltitude,
			m_bDeplacable: bDeplacable,
			m_sActionDeplacement: sActionDeplacement,
			m_bAvecPopup: bAvecPopup,
			m_sNom: sNom,
			m_sActionClicPopup: sActionClicPopup,
			m_bCluster: bCluster,
			m_nFormeImage: nFormeImage,
			m_nTailleFormeImage: nTailleFormeImage,
			m_sTexteFormeImage: sTexteFormeImage,
			m_sCouleurTraitFormeImage: sCouleurTraitFormeImage,
			m_nOpaciteTraitFormeImage: nOpaciteTraitFormeImage,
			m_sCouleurFondFormeImage: sCouleurFondFormeImage,
			m_nOpaciteFondFormeImage: nOpaciteFondFormeImage,
			m_sIdPourPopup: sIdPourPopup
		}
		);
};

// CarteClusterAffiche
WDCarteGoogleMaps.prototype.MAP_ClusterAffiche = function (sId, sImage, nFormeImage, nTailleFormeImage, sTexteFormeImage, sCouleurTraitFormeImage, nOpaciteTraitFormeImage, sCouleurFondFormeImage, nOpaciteFondFormeImage)
{
	// Affichage cluster
	return this.clGestionCluster().AfficheCluster
		(
		{
			m_clCarteApi: this,
			m_sId: sId,
			m_sUrlImage: sImage,
			m_nFormeImage: nFormeImage,
			m_nTailleFormeImage: nTailleFormeImage,
			m_sTexteFormeImage: sTexteFormeImage,
			m_sCouleurTraitFormeImage: sCouleurTraitFormeImage,
			m_nOpaciteTraitFormeImage: nOpaciteTraitFormeImage,
			m_sCouleurFondFormeImage: sCouleurFondFormeImage,
			m_nOpaciteFondFormeImage: nOpaciteFondFormeImage,
			m_nAncrageX :  WDCarteAPI.emqHaut
		}
		);
};

// Suppression de tous les objets d'un type donné
// Entrée :	tabObjet				Tableau contenant les objets à supprimer
//			fnMethodeModifTableau	Méthode modification tableau objet
// Sortie :	true si objet supprimé, false sinon
WDCarteGoogleMaps.prototype._MAP_SupprimeToutObjet = function (tabObjet, fnMethodeModifTableau)
{
	// Supprime tous les objets de la carte
	for (var nObjet = 0; nObjet < tabObjet.length; ++nObjet)
	{
		// Supprime l'objet de la carte
		tabObjet[nObjet].setMap(null);
	}
	// Vide le tableau des objets
	fnMethodeModifTableau.apply(this, [[]]);
	// OK
	return true;
};

// CarteSupprimeTout
WDCarteGoogleMaps.prototype.MAP_SupprimeToutMarqueur = function () 
{
	// Gestion clusters ?
	if (this.m_clGestionCluster)
	{
		// Oui => suppression de tous les marqueurs dans gestion clusters
		this.m_clGestionCluster.clearMarkers();
	}
	// Suppprime les marqueurs de la carte
	return this._MAP_SupprimeToutObjet(this.m_tabMarker, this._SetTableauMarqueur);
};

// Popup marqueur
// Entrée :	clMarqueur	Marqueur API dont on veut la popup
//			bChange		Indique si le marqueur devient le marqueur en cours de la popup API partagée par tous les marqueurs
// Sortie :	Popup marqueur, null en cas d'échec
WDCarteGoogleMaps.prototype._clPopupMarqueur = function (clMarqueur, bChange) 
{
	// Marqueur avec popup ?
	if ((!clMarqueur) || (!clMarqueur.m_clPopupApi))
	{
		// Non => échec
		return null;
	}
	// Popup marqueur
	var clPopup = clMarqueur.m_clPopupApi;
	// On change de marqueur ?
	if (bChange)
	{
		// Oui => le marqueur devient le marqueur en cours de la popup API partagée par tous les marqueurs
		clPopup.m_clMarqueurApi = clMarqueur
	}
	// Le marqueur est le marqueur en cours de la popup des marqueurs ?
	if (clPopup.m_clMarqueurApi != clMarqueur)
	{
		// Non => échec
		return null;
	}
	// Popup marqueur
	return clPopup;
};

// Identifiant iframe popup marqueur
WDCarteGoogleMaps.sIdFramePopupMarqueur = "_PCS_ID_FRAME_POPUP_MARQUEUR";

// Changement taille élément
WDCarteGoogleMaps.ChangeTailleElement = function (clElement, nLargeur, nHauteur)
{
	var clStyleElem = clElement.style;
	clStyleElem.width = clWDUtil.GetDimensionPxPourStyle(nLargeur);
	clStyleElem.height = clWDUtil.GetDimensionPxPourStyle(nHauteur);
};

// Callback appelée par le chargement du contenu de l'iframe de popup de marqueur
WDCarteGoogleMaps.CharmentIframePopupMarqueur = function ()
{
	// Récupération iframe dans page contenant la carte
	var clIframe = this.parent.document.getElementById(WDCarteGoogleMaps.sIdFramePopupMarqueur);
	if (clIframe)
	{
		// Récupération corps document iframe popup marqueur
		var clCorps = clIframe.contentWindow.document.body;
		if (clCorps)
		{
			// On affecte à l'iframe la taille de son contenu (sinon l'iframe a une taille par défaut qui n'est pas bonne)
			WDCarteGoogleMaps.ChangeTailleElement(clIframe, clCorps.offsetWidth, clCorps.offsetHeight);
		}
	}
};

// Affichage popup marqueur
// Entrée : clMarqueur	Marqueur API dont on affiche la popup
WDCarteGoogleMaps.prototype.bAffichePopup = function (clMarqueur) 
{
	// Paramètres marqueur
	var clParam = clMarqueur.m_clParam;
	// On demande l'affichage de la popup à WD
	WDCarteAPI.gsIDPopupAffiche = clParam.m_sIdPourPopup;
	// Recupération popup marqueur
	var clPopup = this._clPopupMarqueur(clMarqueur, true);
	// Popup OK ?
	if (!clPopup)
	{
		// Non => échec
		return false;
	}
	// Div popup
	var clDivPopup = clPopup.m_clDivPopup;
	// On donne au div de la popup le même identifiant que son marqueur associé pour pouvoir retrouver le dino marqueur à partir de la popup lors du clic dans le div de la popup
	clDivPopup.ID_WD = clMarqueur.ID_WD;
	// Branchement callback clic popup
	clMarqueur.m_clObjet._BrancheCallback(clDivPopup, clParam, "click", clParam.m_sActionClicPopup, "gsIDClicPopup", true);
	// On est en WD ?
	if (!WDCarteAPI.gbModeWD)
	{
		// Non => contenu popup par défaut
		var sContenuPopup = "<div align=center color=black><b>" + clWDUtil.sEncodeInnerHTML(clParam.m_sNom, true) + "</b></div>";
		// Description ?
		if (clParam.m_sLibelle != "")
		{
			// Oui => ajout description
			sContenuPopup += "<div align=center color=gray>" + clWDUtil.sEncodeInnerHTML(clParam.m_sLibelle, true) + "</div> ";
		}
		// Modification contenu div popup
		clDivPopup.innerHTML = sContenuPopup;
	}
	// Ouverture popup
	clPopup.open(this.m_clCarte, clMarqueur);
	// Mise à jour flag ouverture
	clPopup.m_bOuvert = true;

	// Gestion popup personnalisée
	// Récupération dino correspondant au marqueur API
	var clDinoMarqueur = this.clDinoMarqueurApi(clMarqueur);
	if (!clDinoMarqueur)
	{
		return true;
	}
	// Champ carte WEBDEV serveur ?
	var clChampCarte = this.m_oChamp;
	if ((!clChampCarte) || (!clChampCarte.m_oDonnees))
	{
		// Non => rien à faire
		return true;
	}
	// Action page
	var sActionPage;
	if (clWDUtil && clWDUtil.sGetPageAction)
	{
		sActionPage = clWDUtil.sGetPageAction();
	}
	if (!sActionPage)
	{
		return true;
	}
	// Appel AJAX asynchrone
	var xhr = new XMLHttpRequest();
	xhr.open("POST", sActionPage, true);
	xhr.onload = function () 
	{
		// Requête OK ?
		if (false === ((xhr.readyState === 4/*état terminé*/) && (xhr.status === 200/*code http OK*/))) 
		{
			// Non => on de fait rien
			return;
		}

		// Construit l'iframe interne
		var oIFrame = document.createElement("iframe");
		oIFrame.src = "javascript:\"\"";
		oIFrame.frameBorder = "0";
		oIFrame.border = "0";
		// Identifiant qui permettra de retouver l'iframe dans le code de chargement du contenu l'iframe
		oIFrame.id = WDCarteGoogleMaps.sIdFramePopupMarqueur;
		// L'iframe devient l'unique fils du div de la popup
		clWDUtil.SupprimeFils(clDivPopup);
		oIFrame = clDivPopup.appendChild(oIFrame);
		// On passe la taille de l'iframe à 0 pour éviter d'avoir une popup qui commence par s'afficher en gros puis se réduit (effet d'affichage)
		WDCarteGoogleMaps.ChangeTailleElement(oIFrame, 0, 0);
		// Récupération page résultat dans iframe
		var clDoc = oIFrame.contentWindow.document;
		// On ouvre le document sinon pas de onload du document chargé
		clDoc.open();
		// Chargement de la page interne dans l'iframe avec un script pour brancher callback chargement contenu iframe nécessaire pour calcul taille contenu iframe (délimiteurs encodés sinon pb en WD)
		clDoc.write(xhr.responseText + "\x3Cscript\x3Ewindow.onload=window.parent.WDCarteGoogleMaps.CharmentIframePopupMarqueur\x3C\x2Fscript\x3E");
		// Fermeture document
		clDoc.close();
	};
	// En-tête requête
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");            
	// Paramètres post 
	var sAliasChampCarte = clChampCarte.m_sAliasChamp;
	var clParamPourJson = clDinoMarqueur.clCloneNettoyePourJsonServeur();
	xhr.send("WD_ACTION_=DETAILMARQUEUR&WD_BUTTON_CLICK_=" + sAliasChampCarte + "&" + sAliasChampCarte + "=" + clParamPourJson.ms_sNomPourParam + "|" + encodeURIComponent(JSON.stringify(clParamPourJson)));

	// OK
	return true;
};

// CarteAffichePopup
WDCarteGoogleMaps.prototype.MAP_AffichePopup = function (nIdMarqueur) 
{
	// Affichage popup marqueur
	return this.bAffichePopup(this.clMarqueurParId(nIdMarqueur));
};

// Fermeture popup marqueur
// Entrée : clMarqueur	Marqueur dont on affiche la popup
WDCarteGoogleMaps.prototype.bFermePopup = function (clMarqueur) 
{
	// Marqueur OK ?
	if (!clMarqueur)
	{
		// Non => échec
		return false;
	}
	// Recupération popup marqueur
	var clPopup = this._clPopupMarqueur(clMarqueur);
	// Popup OK ?
	if (!clPopup)
	{
		// Non => popup fermée
		return true;
	}
	// Fermeture popup
	clPopup.close();
	// Mise à jour flag ouverture
	clPopup.m_bOuvert = false;
	// OK
	return true;
};

// CarteFermePopup
WDCarteGoogleMaps.prototype.MAP_FermePopup = function (nIdMarqueur) 
{
	// Affichage popup marqueur
	return this.bFermePopup(this.clMarqueurParId(nIdMarqueur));
};

// CartePopupAffichée
WDCarteGoogleMaps.prototype.MAP_PopupAffichee = function (nIdMarqueur) 
{
	// Recupération popup marqueur
	var clPopup = this._clPopupMarqueur(this.clMarqueurParId(nIdMarqueur));
	// Popup OK ?
	if (!clPopup)
	{
		// Non => échec
		return false;
	}
	// Indique si popup affichée
	return clPopup.m_bOuvert;
};

// Suppression forme
// Entrée :	nId	Identifiant forme supprimée
// Sortie :	true si forme supprimée, false sinon
WDCarteGoogleMaps.prototype.MAP_SupprimeForme = function (nId)
{
	// Supprime la forme
	return this._bMAP_SupprimeObjet(nId, this.m_tabForme, this._SetTableauForme);
};

// Suppression de toutes les formes
WDCarteGoogleMaps.prototype.MAP_SupprimeToutForme = function () 
{
	// Suppprime les formes de la carte
	return this._MAP_SupprimeToutObjet(this.m_tabForme, this._SetTableauForme);
};

// Ajout polyligne
// Entrée :	tabPoint		Points
//			sCouleurTrait	Couleur trait
//			nTypeTrait		Type trait
//			nEpaisseurTrait	Epaisseur trait
//			nOpaciteTrait	Opacité trait
//			sLibelle		Libellé
//			sActionClic		Action sur clic
//			nAltitude		Altitude
//			bGeodesique		Indique si géodésique
//			nIdOptionnel	Identifiant polyligne optionnel
WDCarteGoogleMaps.prototype.MAP_AjoutePolyligne = function (tabPoint, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sLibelle, sActionClic, nAltitude, bGeodesique, nIdOptionnel)
{
	// Ajout polyligne
	return new CWDCarteApiPolyligne(true).nAjout
		(
		{
			m_clCarteApi: this,
			m_tabPoint: tabPoint,
			m_sCouleurTrait: sCouleurTrait,
			m_nTypeTrait: nTypeTrait,
			m_nEpaisseurTrait: nEpaisseurTrait,
			m_nOpaciteTrait: nOpaciteTrait,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_nAltitude: nAltitude,
			m_bGeodesique: bGeodesique,
			m_nID: nIdOptionnel
		}
		);
};

// Modification polyligne
// Entrée :	nId				Identifiant polyligne
//			tabPoint		Points
//			sCouleurTrait	Couleur trait
//			nTypeTrait		Type trait
//			nEpaisseurTrait	Epaisseur trait
//			nOpaciteTrait	Opacité trait
//			sLibelle		Libellé
//			sActionClic		Action sur clic
//			nAltitude		Altitude
//			bGeodesique		Indique si géodésique
WDCarteGoogleMaps.prototype.MAP_ModifiePolyligne = function (nId, tabPoint, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sLibelle, sActionClic, nAltitude, bGeodesique)
{
	// Modification polyligne
	return new CWDCarteApiPolyligne(true).Modification
		(
		{
			m_clCarteApi: this,
			m_tabPoint: tabPoint,
			m_sCouleurTrait: sCouleurTrait,
			m_nTypeTrait: nTypeTrait,
			m_nEpaisseurTrait: nEpaisseurTrait,
			m_nOpaciteTrait: nOpaciteTrait,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_nAltitude: nAltitude,
			m_bGeodesique: bGeodesique,
			m_nID: nId
		}
		);
};

// Ajout polygone
// Entrée :	tabPoint		Points
//			sCouleurTrait	Couleur trait
//			nTypeTrait		Type trait
//			nEpaisseurTrait	Epaisseur trait
//			nOpaciteTrait	Opacité trait
//			sCouleurFond	Couleur de fond
//			nOpaciteFond	Opacité fond
//			sLibelle		Libellé
//			sActionClic		Action sur clic
//			nAltitude		Altitude
//			bGeodesique		Indique si géodésique
//			nIdOptionnel	Identifiant polygone optionnel
WDCarteGoogleMaps.prototype.MAP_AjoutePolygone = function (tabPoint, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sCouleurFond, nOpaciteFond, sLibelle, sActionClic, nAltitude, bGeodesique, nIdOptionnel)
{
	// Ajout polygone
	return new CWDCarteApiPolygone(true).nAjout
		(
		{
			m_clCarteApi: this,
			m_tabPoint: tabPoint,
			m_sCouleurTrait: sCouleurTrait,
			m_nTypeTrait: nTypeTrait,
			m_nEpaisseurTrait: nEpaisseurTrait,
			m_nOpaciteTrait: nOpaciteTrait,
			m_sCouleurFond: sCouleurFond,
			m_nOpaciteFond: nOpaciteFond,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_nAltitude: nAltitude,
			m_bGeodesique: bGeodesique,
			m_nID: nIdOptionnel
		}
		);
};

// Modification polygone
// Entrée :	nId				Identifiant polygone
//			tabPoint		Points
//			sCouleurTrait	Couleur trait
//			nTypeTrait		Type trait
//			nEpaisseurTrait	Epaisseur trait
//			nOpaciteTrait	Opacité trait
//			sCouleurFond	Couleur de fond
//			nOpaciteFond	Opacité fond
//			sLibelle		Libellé
//			sActionClic		Action sur clic
//			nAltitude		Altitude
//			bGeodesique		Indique si géodésique
WDCarteGoogleMaps.prototype.MAP_ModifiePolygone = function (nId, tabPoint, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sCouleurFond, nOpaciteFond, sLibelle, sActionClic, nAltitude, bGeodesique)
{
	// Modification polyligne
	return new CWDCarteApiPolygone(true).Modification
		(
		{
			m_clCarteApi: this,
			m_tabPoint: tabPoint,
			m_sCouleurTrait: sCouleurTrait,
			m_nTypeTrait: nTypeTrait,
			m_nEpaisseurTrait: nEpaisseurTrait,
			m_nOpaciteTrait: nOpaciteTrait,
			m_sCouleurFond: sCouleurFond,
			m_nOpaciteFond: nOpaciteFond,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_nAltitude: nAltitude,
			m_bGeodesique: bGeodesique,
			m_nID: nId
		}
		);
};

// Ajout cercle
// Entrée :	dLatitude		Latitude centre
//			dLongitude		Longitude centre
//			nRayon			Rayon
//			sCouleurTrait	Couleur trait
//			nTypeTrait		Type trait
//			nEpaisseurTrait	Epaisseur trait
//			nOpaciteTrait	Opacité trait
//			sCouleurFond	Couleur de fond
//			nOpaciteFond	Opacité fond
//			sLibelle		Libellé
//			sActionClic		Action sur clic
//			nAltitude		Altitude
//			nIdOptionnel	Identifiant cercle optionnel
WDCarteGoogleMaps.prototype.MAP_AjouteCercle = function (dLatitude, dLongitude, nRayon, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sCouleurFond, nOpaciteFond, sLibelle, sActionClic, nAltitude, nIdOptionnel)
{
	// Ajout polygone
	return new CWDCarteApiCercle(true).nAjout
		(
		{
			m_clCarteApi: this,
			m_dLatitude: dLatitude,
			m_dLongitude: dLongitude,
			m_nRayon: nRayon,
			m_sCouleurTrait: sCouleurTrait,
			m_nTypeTrait: nTypeTrait,
			m_nEpaisseurTrait: nEpaisseurTrait,
			m_nOpaciteTrait: nOpaciteTrait,
			m_sCouleurFond: sCouleurFond,
			m_nOpaciteFond: nOpaciteFond,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_nAltitude: nAltitude,
			m_nID: nIdOptionnel
		}
		);
};

// Modification cercle
// Entrée :	nId				Identifiant cercle
//			dLatitude		Latitude centre
//			dLongitude		Longitude centre
//			nRayon			Rayon
//			sCouleurTrait	Couleur trait
//			nTypeTrait		Type trait
//			nEpaisseurTrait	Epaisseur trait
//			nOpaciteTrait	Opacité trait
//			sCouleurFond	Couleur de fond
//			nOpaciteFond	Opacité fond
//			sLibelle		Libellé
//			sActionClic		Action sur clic
//			nAltitude		Altitude
WDCarteGoogleMaps.prototype.MAP_ModifieCercle = function (nId, dLatitude, dLongitude, nRayon, sCouleurTrait, nTypeTrait, nEpaisseurTrait, nOpaciteTrait, sCouleurFond, nOpaciteFond, sLibelle, sActionClic, nAltitude)
{
	// Modification polyligne
	return new CWDCarteApiCercle(true).Modification
		(
		{
			m_clCarteApi: this,
			m_dLatitude: dLatitude,
			m_dLongitude: dLongitude,
			m_nRayon: nRayon,
			m_sCouleurTrait: sCouleurTrait,
			m_nTypeTrait: nTypeTrait,
			m_nEpaisseurTrait: nEpaisseurTrait,
			m_nOpaciteTrait: nOpaciteTrait,
			m_sCouleurFond: sCouleurFond,
			m_nOpaciteFond: nOpaciteFond,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_nAltitude: nAltitude,
			m_nID: nId
		}
		);
};

// Ajout image
// Entrée :	dLatitude		Latitude centre
//			dLongitude		Longitude centre
//			sImage			URL image
//			dLargeur		Largeur image
//			dHauteur		Hauteur image
//			eAlignement		Alignement
//			nOpacite		Opacité
//			sLibelle		Libellé
//			sActionClic		Action sur clic
//			nAltitude		Altitude
//			nAngle			Angle de rotation de l'image
//			nIdOptionnel	Identifiant image optionnel
//			nAncrageX		Ancrage horizontal ou alignement
//			nAncrageY		Ancrage vertical
WDCarteGoogleMaps.prototype.MAP_AjouteImage = function (dLatitude, dLongitude, sImage, dLargeur, dHauteur, eAlignement, nOpacite, sLibelle, sActionClic, nAltitude, nAngle, nIdOptionnel)
{
	// Ajout image
	return new CWDCarteApiImage(true).nAjout
		(
		{
			m_clCarteApi: this,
			m_dLatitude: dLatitude,
			m_dLongitude: dLongitude,
			m_sImage: sImage,
			m_dLargeur: dLargeur,
			m_dHauteur: dHauteur,
			m_eAlignement: eAlignement,
			m_nOpacite: nOpacite,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_nAltitude: nAltitude,
			m_nAngle: nAngle,
			m_nID: nIdOptionnel
		}
		);
};

// Suppression image
// Entrée :	nId	Identifiant image supprimée
// Sortie :	true si image supprimée, false sinon
WDCarteGoogleMaps.prototype.MAP_SupprimeImage = function (nId)
{
	// Supprime la forme
	return this._bMAP_SupprimeObjet(nId, this.m_tabImage, this._SetTableauImage);
};

// Modification image
// Entrée :	nId				Identifiant image
//			dLatitude		Latitude centre
//			dLongitude		Longitude centre
//			sImage			URL image
//			dLargeur		Largeur image
//			dHauteur		Hauteur image
//			eAlignement		Alignement
//			nOpacite		Opacité
//			sLibelle		Libellé
//			sActionClic		Action sur clic
//			nAltitude		Altitude
//			nAngle			Angle de rotation de l'image
//			nAncrageX		Ancrage horizontal ou alignement
//			nAncrageY		Ancrage vertical
WDCarteGoogleMaps.prototype.MAP_ModifieImage = function (nId, dLatitude, dLongitude, sImage, dLargeur, dHauteur, eAlignement, nOpacite, sLibelle, sActionClic, nAltitude, nAngle)
{
	// Modification polyligne
	return new CWDCarteApiImage(true).Modification
		(
		{
			m_clCarteApi: this,
			m_dLatitude: dLatitude,
			m_dLongitude: dLongitude,
			m_sImage: sImage,
			m_dLargeur: dLargeur,
			m_dHauteur: dHauteur,
			m_eAlignement: eAlignement,
			m_nOpacite: nOpacite,
			m_sLibelle: sLibelle,
			m_sActionClic: sActionClic,
			m_nAltitude: nAltitude,
			m_nAngle: nAngle,
			m_nID: nId
		}
		);
};

// Suppression de toutes les images
WDCarteGoogleMaps.prototype.MAP_SupprimeToutImage = function () 
{
	// Suppprime les formes de la carte
	return this._MAP_SupprimeToutObjet(this.m_tabImage, this._SetTableauImage);
};

// ..ModeCarte
WDCarteGoogleMaps.prototype.MAP_SetModeCarte = function (nMode)
{
	// MAJ Mode
	this.m_clCarte.setMapTypeId(WDCarteGoogleMaps._nModeCarteWlVersGGl(nMode));
};

// X = ..ModeCarte
WDCarteGoogleMaps.prototype.MAP_GetModeCarte = function ()
{
	var Mode = this.m_clCarte.getMapTypeId();
//	#define	nCarteMode2D		1
	if (Mode == google.maps.MapTypeId.ROADMAP)
	{
		return 1;
	}
//	#define nCarteModeSatellite	2
	if (Mode == google.maps.MapTypeId.HYBRID)
	{
		return 2;
	}
	// Inconnu
	return 0;
};

// ..Zoom
WDCarteGoogleMaps.prototype.MAP_GetZoom = function ()
{
	return this.m_clCarte.getZoom();
};

// ..InfoTrafic
WDCarteGoogleMaps.prototype.MAP_SetInfoTrafic = function (bInfoTrafic)
{
	// Modif infos trafic ?
	if (!!bInfoTrafic == this.MAP_GetInfoTrafic())
	{
		// Non => rien à faire
		return;
	}
	// Oui => on met les infos trafic ?
	if (bInfoTrafic)
	{
		// Oui => création infos trafic
		this.m_clInfoTrafic = new google.maps.TrafficLayer({ map: this.m_clCarte });
	}
	else
	{
		// Non => retrait infos trafic de carte
		this.m_clInfoTrafic.setMap(null);
		// Plus d'infos trafic
		this.m_clInfoTrafic = null;
	}
};

// X = ..InfoTrafic
WDCarteGoogleMaps.prototype.MAP_GetInfoTrafic = function ()
{
	// Validité infos trafic convertie en booléen
	return !!this.m_clInfoTrafic;
};

// ..Boussole
WDCarteGoogleMaps.prototype.MAP_SetBoussole = function (bBoussole)
{
	this.m_bBoussole = bBoussole;
};

// X = ..Boussole
WDCarteGoogleMaps.prototype.MAP_GetBoussole = function ()
{
	return this.m_bBoussole;
};

// Mise à jour gesture
WDCarteGoogleMaps.prototype.MajGesture = function ()
{
	// Toute gesture desactivée ? oui => on désactive gesture; non => on passe en mode auto
	this.m_clCarte.setOptions({ gestureHandling: (this.m_bAvecZoom || this.m_bAvecRotation || this.m_bAvecScroll || this.m_bAvecInclinaison) ? "auto" : "none" });
};

// ..AvecZoom
WDCarteGoogleMaps.prototype.MAP_SetAvecZoom = function (bAvecZoom)
{
	this.m_bAvecZoom = bAvecZoom;
	this.MajGesture();
};

// X = ..AvecZoom
WDCarteGoogleMaps.prototype.MAP_GetAvecZoom = function ()
{
	return this.m_bAvecZoom;
};

// ..AvecRotation
WDCarteGoogleMaps.prototype.MAP_SetAvecRotation = function (bAvecRotation)
{
	this.m_bAvecRotation = bAvecRotation;
	this.MajGesture();
};

// X = ..AvecRotation
WDCarteGoogleMaps.prototype.MAP_GetAvecRotation = function ()
{
	return this.m_bAvecRotation;
};

// ..AvecScroll
WDCarteGoogleMaps.prototype.MAP_SetAvecScroll = function (bAvecScroll)
{
	this.m_bAvecScroll = bAvecScroll;
	this.MajGesture();
};

// X = ..AvecScroll
WDCarteGoogleMaps.prototype.MAP_GetAvecScroll = function ()
{
	return this.m_bAvecScroll;
};

// ..AvecInclinaison
WDCarteGoogleMaps.prototype.MAP_SetAvecInclinaison = function (bAvecInclinaison)
{
	this.m_bAvecInclinaison = bAvecInclinaison;
	this.MajGesture();
};

// X = ..AvecInclinaison
WDCarteGoogleMaps.prototype.MAP_GetAvecInclinaison = function ()
{
	return this.m_bAvecInclinaison;
};

// ..AngleRotation
WDCarteGoogleMaps.prototype.MAP_SetAngleRotation = function (nAngleRotation)
{
	this.m_clCarte.setHeading(nAngleRotation);
};

// X = ..AngleRotation
WDCarteGoogleMaps.prototype.MAP_GetAngleRotation = function ()
{
	return this.m_clCarte.getHeading();
};

// ..Inclinaison
WDCarteGoogleMaps.prototype.MAP_SetInclinaison = function (nInclinaison)
{
	this.m_clCarte.setTilt(nInclinaison);
};

// X = ..Inclinaison
WDCarteGoogleMaps.prototype.MAP_GetInclinaison = function ()
{
	return this.m_clCarte.getTilt();
};

// CarteAjouteItinéraire()
WDCarteGoogleMaps.prototype.MAP_AjouteItineraire = function (dLatitudeDepart, dLongitudeDepart, dLatitudeArrivee, dLongitudeArrivee, nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel)
{
	// calcul a partir de ce paramètres
	return this._AjouteItineraireDeVers([[dLatitudeDepart, dLongitudeDepart], [dLatitudeArrivee, dLongitudeArrivee]], nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel);
};
// CarteAjouteItinéraire()
WDCarteGoogleMaps.prototype.MAP_AjouteItineraireStr = function (sLieuDepart, sLieuArrivee, nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel)
{
	// calcul a partir de ce paramètres
	return this._AjouteItineraireDeVers([sLieuDepart, sLieuArrivee], nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel);
};
// CarteAjouteItinéraire()
WDCarteGoogleMaps.prototype.MAP_AjouteItineraireArray = function (tabPositions, nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel)
{
	// calcul a partir de ce paramètres
	return this._AjouteItineraireDeVers(tabPositions, nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel);
};

// CarteSupprimeItineraire()
WDCarteGoogleMaps.prototype.MAP_SupprimeItineraire = function (nID)
{
	var tabItineraires = [];
	//retire l'itinéraires du tableau
	for (var iItineraire = 0; iItineraire < this.m_tabItineraire.length; ++iItineraire)
	{
		if (this.m_tabItineraire[iItineraire].m_nID != nID)
		{
			tabItineraires.push(this.m_tabItineraire[iItineraire]);
		}
		else
		{
			this.m_tabItineraire[iItineraire].setMap(null);
		}
	}
	if (this.m_tabItineraire.length == tabItineraires.length)
	{
		return false;
	}
	this.m_tabItineraire = tabItineraires;
	return true;
};
// CarteDistanceItineraire
WDCarteGoogleMaps.prototype.MAP_DistanceItineraire = function (nID)
{
	//retire l'itinéraires du tableau
	for (var iItineraire = 0; iItineraire < this.m_tabItineraire.length; ++iItineraire)
	{
		if (this.m_tabItineraire[iItineraire].m_nID == nID)
		{
			// trouvé
			var clItineraire = this.m_tabItineraire[iItineraire];
			// si distance pas encore rensigne
			if (clItineraire.distanceEnMetre == undefined)
			{
				return "";
			}

			return clItineraire.distanceEnMetre;
		}
	}

	// pas trouvé
	return -1.0;
};


// CarteSupprimeTout
WDCarteGoogleMaps.prototype.MAP_SupprimeToutItineraire = function ()
{
	// suppprime les itineraires de la carte
	for (var i = 0; i < this.m_tabItineraire.length; ++i)
	{
		this.m_tabItineraire[i].setMap(null);
	}
	// vider le tableau de
	this.m_tabItineraire = [];
	return true;
};

// ..Image = x
WDCarteGoogleMaps.prototype.MAP_SetImageMarqueur = function (sUrlImage)
{
	this.m_sImageMarqueur_Initial = sUrlImage;
};

// CarteSuitDéplacement
WDCarteGoogleMaps.prototype.MAP_SuitDeplacement = function (Boussole, fProcedure)
{
	//Boussole ?
	this.m_clCarte.setTilt(Boussole ? 45 : 0);
	//démarre le suivi
	var oThis = this;
	GPSSuitDeplacement(function (oGeoPosition)
	{
		//cas d'erreur de localisation
		if (oGeoPosition == null)
		{
			return;
		}
		//appelle la procédure utilisateur
		if (!fProcedure(oGeoPosition))
		{
			//si la procédure renvoie faux, la carte doit être centrée sur la position courante
			oThis.MAP_SetPosition(oGeoPosition.GetLatitude(), oGeoPosition.GetLongitude(), true);
		}
	});
};

// CarteFinDéplacement
WDCarteGoogleMaps.prototype.MAP_FinDeplacement = function ()
{
	//arrêt du suivi
	GPSSuitDeplacement(null);
};

// Mise à jour de la taille de la carte
// source : http://stackoverflow.com/questions/11214651/google-maps-api-v3-gray-areas
WDCarteGoogleMaps.prototype.UpdateSize = function UpdateSize()
{
	google.maps.event.trigger(this.m_clCarte, 'resize');
};

//lecture seule ou non
WDCarteGoogleMaps.prototype.PasseEnLectureSeuleEx = function (bReadOnly)
{
	var bAvecControle = !bReadOnly;

	this.m_clCarte.setOptions({
		draggable: bAvecControle,
		zoomControl: bAvecControle,
		scrollwheel: bAvecControle,
		disableDoubleClickZoom: !bAvecControle,
		disableDefaultUI: !bAvecControle,
		panControl: bAvecControle,
		streetViewControl: bAvecControle
	});
};
//lecture seule
WDCarteGoogleMaps.prototype.PasseEnLectureSeule = function ()
{
	this.PasseEnLectureSeuleEx(true);
};

// Récupération gestion clusters
// Sortie :	Gestion clusters
WDCarteGoogleMaps.prototype.clGestionCluster = function ()
{
	// Gestion cluster initialisée pour la carte
	if (!this.m_clGestionCluster)
	{
		// Non => on l'initialise
		this.m_clGestionCluster = new CWDCarteApiGestionClusterMarqueur(this.m_clCarte, undefined, { gridSize: 40, averageCenter: false, m_clCarte: this });
	}
	// Gestion clusters
	return this.m_clGestionCluster;
};
