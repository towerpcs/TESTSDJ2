// WDChamp.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - La page
///#GLOBALS _COL
// - WDUtil.js
///#GLOBALS bIE bIEQuirks AppelMethode AppelMethodePtr
// - jQuery
///#GLOBALS $

// Classe de base de manipulation des champs de WebDev
// - Gestion de l'appartenace a :
//	- Une ZR
//	- Un onglet
// - Gestion des evenements AJAX (affectation etc)
var WDChamp = (function ()
{
	"use strict";

	function __WDChamp(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires/*, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// L'alias du champ
			this.m_sAliasChamp = sAliasChamp;
			// La ZR eventuelle qui contient le champ si la propriete ..Valeur est liee a un attribut (sAliasChamp est alors l'alias de cet attribut)
			if (sAliasTableZRParent)
			{
				this.m_sAliasTableZRParent = sAliasTableZRParent;
				this.m_sAliasAttribut = sAliasAttribut;
			}
			this.m_pfConstructeursSupplementaires = pfConstructeursSupplementaires;

			// Initialise le tableau des champs fils
			this.m_tabChampsFils = new clWDUtil.WDTableauChamps();

			// Le champ est actif
			this.m_eEtat = this.ms_eEtatActif;

			// Le champ n'est pas encore valide
			this.m_eValide = 0;

			// Si le HTML du champ est pr�sent dans le HTML : oui par d�faut
			// GP 19/01/2016 : Il faudrait mettre ce param�tre dans les param�tres du constructeur => Faire le refactoring un jour
			this.m_bChampDansHTML = true;
			this.m_bDansPlanAffiche = true;

			// GP 12/11/2018 : QW306242 : Nombre d'animations sur le champ. En fait c'est par champ. Car avant le refactoring, la syntaxe this.ms_nNbAnimationsActives++ �tait en fait �quivalente � :
			// this.ms_nNbAnimationsActives = __WDChamp.prototype.ms_nNbAnimationsActives + 1;
			// => Cela duplicait le membre dans chaque instance � la premi�re utilisation. On avait donc un membre d'instance.
			this.m_nNbAnimationsActives = 0;
		}
	};

	// Tableau global des ZRs/Tables de la page (pour pouvoir les manipulers des les inits des champs
	__WDChamp.prototype.ms_tabTablesZRs = new clWDUtil.WDTableauChamps();
	// Numero des PCodes navigateurs
	__WDChamp.prototype.ms_nEventNavClick = 0;
	__WDChamp.prototype.ms_nEventNavBlur = 10;
	__WDChamp.prototype.ms_nEventNavChange = 11;
	__WDChamp.prototype.ms_nEventNavFocus = 12;
	__WDChamp.prototype.ms_nEventNavLoad = 15;
	__WDChamp.prototype.ms_nEventNavSubmit = 18;
	__WDChamp.prototype.ms_nEventNavSelectLigne = 20;
	__WDChamp.prototype.ms_nEventNavModifSimple = 21;
	__WDChamp.prototype.ms_nEventNavAffichageMois = 28;
	__WDChamp.prototype.ms_nEventNavSelectionJour = 29;
	__WDChamp.prototype.ms_nEventNavUploadSelection = 30;
	__WDChamp.prototype.ms_nEventNavUploadAvancement = 31;
	__WDChamp.prototype.ms_nEventNavAgendaRdvSelection = 32;
	__WDChamp.prototype.ms_nEventNavAgendaRdvDeplacement = 33;
	__WDChamp.prototype.ms_nEventNavAgendaRdvRedim = 34;
	__WDChamp.prototype.ms_nEventNavAgendaPeriodeSelect = 35;
	__WDChamp.prototype.ms_nEventNavAgendaRdvSupprime = 36;
	__WDChamp.prototype.ms_nEventNavAgendaRdvAjoute = 37;
	__WDChamp.prototype.ms_nEventNavAgendaRdvEdition = 38;
	__WDChamp.prototype.ms_nEventNavAgendaRdvModifTitre = 39;
	__WDChamp.prototype.ms_nEventNavPlanningRdvDeplacementRessource = 40;
	__WDChamp.prototype.ms_nEventNavCalendrierChangementMois = 41;
	__WDChamp.prototype.ms_nEventNavAgendaPeriodeAffiche = 45;
	__WDChamp.prototype.ms_nEventNavUploadFin = 46;
	__WDChamp.prototype.ms_nEventNavAffichageLigne = 47;
	__WDChamp.prototype.ms_nEventNavTdbAjoute = 64;
	__WDChamp.prototype.ms_nEventNavTdbSupprime = 65;
	__WDChamp.prototype.ms_nEventNavTdbDeplacement = 66;
	__WDChamp.prototype.ms_nEventNavTdbRedimensionnement = 67;
	__WDChamp.prototype.ms_nEventNavTdbWidgetRefresh = 68;
	__WDChamp.prototype.ms_nEventNavCarteChangePosition = 69;
//	__WDChamp.prototype.ms_nEventNavAction = 73;
//	__WDChamp.prototype.ms_nEventNavGetValeur = 74;
//	__WDChamp.prototype.ms_nEventNavSetValeur = 75;
	__WDChamp.prototype.ms_nEventNavCarteCreationCluster = 91;

	// Etats des champs.AppelMethode Les valeurs mappent sur les valeurs WL meme si visible n'est pas utilise
	__WDChamp.prototype.ms_eEtatActif = 0;
	__WDChamp.prototype.ms_eEtatLectureSeule = 1;
	__WDChamp.prototype.ms_eEtatGrise = 4;

	// Type de champs (d�plac� progressivement de clWDAJAXMain vers ici
	__WDChamp.prototype.ms_nIDObjetSaisie = 2;
	__WDChamp.prototype.ms_nIDObjetLibelle = 3;
	__WDChamp.prototype.ms_nIDObjetBouton = 4;
	__WDChamp.prototype.ms_nIDObjetInterrupteur = 5;
	__WDChamp.prototype.ms_nIDObjetImage = 8;
	__WDChamp.prototype.ms_nIDObjetCombo = 14;
	__WDChamp.prototype.ms_nIDObjetCellule = 39;
	__WDChamp.prototype.ms_nIDObjetCodeBarre = 91;
	__WDChamp.prototype.ms_nIDObjetInterrupteurABascule = 132;

	var ID_SEPARATEUR = "_";
	__WDChamp.prototype.ms_sSuffixeHote = "_HTE";

	// Initialisation
	__WDChamp.prototype.Init = function Init()
	{
		// Si c'est l'init du premier champ
		this._vInitInitiale();

		// Si le champ est dans une ZR : notifie l'objet ZR de sa presence
		// Note : On ne peut pas faire cette declaration dans le constructeur car l'existence de l'objet de la ZR n'est pas garanti
		// En effet l'ordre actuel de creation des objets est : fils puis parent
		// Ce qui signifie que la liste comlete n'est pas complete avant la fin de tous les init. Sauf que l'init de la ZR est alors apres celui de tous ces fils donc on peut considerer qu'il existe.
		// GP 08/09/2014 : QW247797 : Si on est dans une ZR classique, il n'y a pas d'objet (le code pr�c�dent filtrait en interne sur la m�thode)
		var oTableZR = this.oGetTableZRParent();
		if (oTableZR)
		{
			oTableZR.m_tabChampsFils.DeclareChamp(this);
		}

		// Appel des constructeurs suppl�mentaires
		if (this.m_pfConstructeursSupplementaires)
		{
			if (this.bGestionTableZR())
			{
				// GP 07/01/2016 : TB93214 : Probl�me avec "_DEB" : maintenant la valeur est toujours en indice WL (base 1) (y compris pour les tables/ZRs AJAX)
				// Table/ZR : it�ration sur les �l�ments affich�s
				this.PourToutesLignesTableZR(this.__AppelConstructeursSupplementairesZR);
			}
			else
			{
				// GP 11/04/2018 : TB102026 : undefined : sans num�ro de ligne.
				this.m_pfConstructeursSupplementaires(this.m_sAliasChamp, this.m_sAliasChamp, undefined);
			}
		}

		// Se memorise comme champ valide dans le tableau global
		// Fait dans l'init et pas dans la construction, pour ne pas ajouter un champ invalide
		this.m_eValide = 1;

		// Trouve les divers elements : liaison avec le HTML
		this._vLiaisonHTML();
	};

	// Methode d'initialisation generale de la classe (ne s'execute que lors de l'init de la premi�re instance de ce type)
	__WDChamp.prototype._vInitInitiale = function _vInitInitiale()
	{
		// Enregistre l'evenement onresize sur la fenetre
		clWDUtil.AttacheOnScrollResize(__WDChamp.prototype.__s_OnScrollResize);

		// S'auto efface pour ne plus etre appele
		__WDChamp.prototype._vInitInitiale = clWDUtil.m_pfVide;
	};
	__WDChamp.prototype.__s_OnScrollResize = function __s_OnScrollResize(oEvent, bOnScroll)
	{
		AppelMethodePtr(bOnScroll ? __WDChamp.prototype.OnScroll : __WDChamp.prototype.OnResize, [oEvent], undefined);
	};

	// Appel des constructeurs suppl�mentaires sur une ligne de ZR
	__WDChamp.prototype.__AppelConstructeursSupplementairesZR = function __AppelConstructeursSupplementairesZR(nLigneAbsolueBase1)
	{
		// Plusieurs possibilit� pour l'alias :
		// - zrl_Indice_AliasAttribut
		// - zrl_Indice_AliasChamp (TB102026)
		// GP 04/12/2019 : Le cas c- n'existe plus.
		var sAliasHTML = this.sGetNomElementAttributIndice(nLigneAbsolueBase1, "");
		// GP 11/04/2018 : TB102026 : Il semble y avoir encore d'autres cas d'alias. Dans le cas du champ vignette de la fiche l'alias est zrl_<indice ligne>_<alias champ>
		// Logiquement l'alias du champ n'a rien a faire ici, mais comme c'est ce que l'on trouve...
		if (!document.getElementById(sAliasHTML))
		{
			sAliasHTML = "zrl_" + nLigneAbsolueBase1 + "_" + this.m_sAliasChamp;
			// GP 22/08/2016 : TB99381 : Il y a des cas bizarres out la ZRs n'est pas encore initialis�e... (d�pend de l'ordre de d�claration...)
			if (!document.getElementById(sAliasHTML))
			{
				return;
			}
		}
		// GP 11/04/2018 : TB102026 : avec num�ro de ligne.
		this.m_pfConstructeursSupplementaires(sAliasHTML, this.m_sAliasChamp, nLigneAbsolueBase1);
	};

	// Appele une methode sur tout les champs sauf sur le champ courant
	// tabParam : tableau des parametres
	__WDChamp.prototype.AppelMethodeAutres = function AppelMethodeAutres(sFonction, tabParam)
	{
		AppelMethode(sFonction, tabParam, this);
	};
	__WDChamp.prototype.AppelMethodeAutresPtr = function AppelMethodeAutresPtr(fFonction, tabParam)
	{
		AppelMethodePtr(fFonction, tabParam, this);
	};

	//////////////////////////////////////////////////////////////////////////
	// Gestion des PCodes

	// Recupere un PCode navigateur du champ
	__WDChamp.prototype.RecuperePCode = function RecuperePCode(ePCodeNav)
	{
		return clWDUtil.pfGetTraitement(this.m_sAliasChamp, ePCodeNav);
	};

	// Cree un Timeout sur le champ courant et renvoi l'id du Timeout
	// La fonction est en fait une fonction '...'. Elle concatene les parametre a partir du troisieme comme arguments de la procedure appelee
	// Seule les parametres de type chaines sont encadre par des " MAIS NE sont pas escapes
	__WDChamp.prototype.nSetTimeout = function nSetTimeout(fFonction, oDelai)
	{
		var oThis = this;
		var tabArguments = this.__tabArgumentsVersTableau(arguments, 2);
		return clWDUtil.nSetTimeout(function() { fFonction.apply(oThis, tabArguments); }, oDelai);
	};

	// Cree un timer sur le champ courant et renvoi l'id du timer
	// La fonction est en fait une fonction '...'. Elle concatene les parametre a partir du troisieme comme arguments de la procedure appelee
	// Seule les parametres de type chaines sont encadre par des " MAIS NE sont pas escapes
	__WDChamp.prototype.SetInterval = function SetInterval(sFonction, fFonction, nDuree)
	{
		this[this.sNomVariableTimeXXX(sFonction)] = setInterval(fFonction, nDuree);
	};


	// Recupere le tableau des arguments d'une fonction
	__WDChamp.prototype.__tabArgumentsVersTableau = function __tabArgumentsVersTableau(tabParam, nPremier)
	{
		return Array.prototype.slice.call(tabParam, nPremier);
	};

	// Gestion de SetTimeout avec appel unique (un seul appel en attente)
	__WDChamp.prototype.nSetTimeoutUnique = function nSetTimeoutUnique(sFonction, oDelai)
	{
		// Supprime le Timeout de meme nom s'il existe
		this.AnnuleTimeXXX(sFonction, false);

		// Et cree le nouveau
		var nTimeout = this.nSetTimeout(this.TimeoutUnique, oDelai, sFonction, this.__tabArgumentsVersTableau(arguments, 2));
		this[this.sNomVariableTimeXXX(sFonction)] = nTimeout;
		return nTimeout;
	};
	// Version qui autorise l'optimisation de l'appel :
	// - Le d�lai est imm�diat.
	// - Il n'y a aucun param�tres.
	// Ne le fait pas dans tous les cas car le risque th�orique est de changer l'ordre des timeout.
	// Ce timeout n'est pas annulable.
	__WDChamp.prototype.SetTimeoutUniqueO = function nSetTimeoutUniqueO(sFonction)
	{
		var sVarTimeXXX = this.sNomVariableTimeXXX(sFonction);
		var oTimeXXX = this[sVarTimeXXX];
		if (undefined !== oTimeXXX)
		{
			return;
		}
		else if (window.requestAnimationFrame)
		{
			var oThis = this;
			this[sVarTimeXXX] = requestAnimationFrame(function() { oThis.TimeoutUnique(sFonction, []); });
			return;
		}
		else
		{
			this.nSetTimeoutUnique(sFonction, clWDUtil.ms_oTimeoutImmediat);
		}
	};

	// Callback pour la gestion des timeouts uniques
	__WDChamp.prototype.TimeoutUnique = function TimeoutUnique(sFonction, tabParam)
	{
		// Supprime le timeout
		this.SupprimeTimeout(sFonction);
		// Appel la fonction
		this[sFonction].apply(this, tabParam);
	};

	// Recupere un timer
	__WDChamp.prototype.bGetTimeXXXExiste = function bGetTimeXXXExiste(sFonction)
	{
		// Si le Timeout existe
		return this[this.sNomVariableTimeXXX(sFonction)] !== undefined;
	};

	// Annule un Timeout
	__WDChamp.prototype.AnnuleTimeXXX = function AnnuleTimeXXX(sFonction, bInterval)
	{
		// Si le Timeout existe
		var sVarTimeXXX = this.sNomVariableTimeXXX(sFonction);
		var oTimeXXX = this[sVarTimeXXX];
		if (oTimeXXX !== undefined)
		{
			// Le libere
			if (bInterval)
			{
				clearInterval(oTimeXXX);
			}
			else
			{
				clWDUtil.ClearTimeout(oTimeXXX);
			}
			// Et supprime la variable
			delete this[sVarTimeXXX];
		}
	};

	// Supprime la reference a un Timeout
	__WDChamp.prototype.SupprimeTimeout = function SupprimeTimeout(sFonction)
	{
		// Si le Timeout existe
		var sVarTimeout = this.sNomVariableTimeXXX(sFonction);
		if (this[sVarTimeout] !== undefined)
		{
			delete this[sVarTimeout];
		}
	};

	// Calcule le nom de la variable memorisant le Timeout
	__WDChamp.prototype.sNomVariableTimeXXX = function sNomVariableTimeXXX(sFonction)
	{
		return "m_nTimeXXX_" + sFonction;
	};

	//////////////////////////////////////////////////////////////////////////
	// Etat du champ

	// Etats des champs. Les valeurs mappent sur les valeurs WL meme si visible n'est pas utilise
	__WDChamp.prototype.SetEtat = function SetEtat(eEtat)
	{
		this.m_eEtat = eEtat;
	};
	__WDChamp.prototype.eGetEtat = function eGetEtat()
	{
		return this.m_eEtat;
	};

	// Methode predefinies nommee
	// - Tous les champs : affectation du contenu HTML pour l'AJAX
	__WDChamp.prototype.PreAffecteHTML = function PreAffecteHTML(/*bDepuisAJAX*/) { this._vPreAffecteHTML.apply(this, arguments); };
	__WDChamp.prototype._vPreAffecteHTML = clWDUtil.m_pfVide;
	__WDChamp.prototype.PostAffecteHTML = function PostAffecteHTML(/*bDepuisAJAX*/) { this._vPostAffecteHTML.apply(this, arguments); };
	__WDChamp.prototype._vPostAffecteHTML = clWDUtil.m_pfVide;
	// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
	__WDChamp.prototype.OnDisplay = function OnDisplay(/*oElementRacine*//*, bAffiche*/) { };
	__WDChamp.prototype.ms_sOnDisplay = "OnDisplay";
	// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
	__WDChamp.prototype.OnResize = function OnResize(/*oEvent*/)
	{
		// GP 15/02/2017 : D�sactive le redimensionnement si dans un plan masqu� (car on est display none)
		if (!clWDUtil.bDansPlanMasque(this.m_oChampFormulaire))
		{
			this._vOnResize.apply(this, arguments);
		}
	};
	__WDChamp.prototype._vOnResize = clWDUtil.m_pfVide;
	// Pas d�faut _voGetConteneurPourPlanMasque ne retourne rien (ce qui fait que bDansPlanMasque ne teste rien)
	__WDChamp.prototype._voGetConteneurPourPlanMasque = function() { };
	// - Tous les champs : Notifie le champ que la fenetre d�file
	__WDChamp.prototype.OnScroll = function OnScroll(/*oEvent*/) { this._vOnScroll.apply(this, arguments); };
	__WDChamp.prototype._vOnScroll = clWDUtil.m_pfVide;
	// - Tous les champs : Notifie le champ du submit du formulaire
	// Note : n'est appel� que sur les champs avec un comportement particulier (= avec ce traitement)
	__WDChamp.prototype.OnSubmit = function OnSubmit(oEvent)
	{
		this.RecuperePCode(this.ms_nEventNavSubmit)(oEvent);
	};
	// - Tous les champs : affectation de la valeur
	__WDChamp.prototype.SetValeur = function SetValeur(oEvent, sValeur/*, oChamp*/) { return sValeur; };
	__WDChamp.prototype.ms_sSetValeur = "SetValeur";
	__WDChamp.prototype.GetValeur = function GetValeur(oEvent, sValeur/*, oChamp*/) { return sValeur; };
	__WDChamp.prototype.ms_sGetValeur = "GetValeur";
	// - Affectation des parametres du champ (pas besoin de apply ici car on transforme les parametres)
	__WDChamp.prototype.DeduitParam = function DeduitParam(sParametres) { this._vDeduitParam(clWDUtil.oEvalJSON(sParametres)); };
	__WDChamp.prototype._vDeduitParam = clWDUtil.m_pfVide;
	// - Ecriture des parametres du champ dans le champ formulaire associe
	// => N'affecte rien pour le cas des valeurs vide (car des champs qui font des MAJs en direct)
	__WDChamp.prototype.ConstruitParam = function ConstruitParam()
	{
		var sParam = this._vsConstruitParam.apply(this, arguments);
		if (sParam.length > 0)
		{
			this._vSetValeurChampFormulaire(sParam);
		}
	};
	// Recupere les parametres du champs (accepte des parametres variables)
	__WDChamp.prototype._vsConstruitParam = function _vsConstruitParam() { return ""; };
	// - Champ table : rafraichissement du contenu
	__WDChamp.prototype.Refresh = function Refresh(/*nReset*//*, nNouveauDebut*//*, sCleNouveauDebut*//*, sData*//*, nNbLignes*//*, oXMLFils*//*, nTri*//*, bSens*/) { this._vRefresh.apply(this, arguments); };
	__WDChamp.prototype._vRefresh = clWDUtil.m_pfVide;
	// - Champ avec "barre" (graphe/saisie riche)
	__WDChamp.prototype.MasqueBarre = function MasqueBarre(/*oEvent*/) { this._vMasqueBarre.apply(this, arguments); };
	__WDChamp.prototype._vMasqueBarre = clWDUtil.m_pfVide;
	// - Tous les champs : animation
	__WDChamp.prototype.AnimationDebut = function AnimationDebut(/*oAnimation*/) { this._vAnimationDebut.apply(this, arguments); };
	__WDChamp.prototype._vAnimationDebut = function _vAnimationDebut(/*oAnimation*/)
	{
		this.m_nNbAnimationsActives++;
	};
	__WDChamp.prototype.AnimationFin = function AnimationFin(/*oAnimation*/) { this._vAnimationFin.apply(this, arguments); };
	__WDChamp.prototype._vAnimationFin = function _vAnimationFin(/*oAnimation*/)
	{
		this.m_nNbAnimationsActives--;
	};

	// Methode appele directement
	// - Champ dans une table/ZR : notifie le champ de l'affichage/suppression de la ligne
	__WDChamp.prototype.OnLigneTableZRAffiche = function OnLigneTableZRAffiche(/*nLigneAbsolueBase1*//*, bSelectionne*/) { this._vOnLigneTableZRAffiche.apply(this, arguments); };
	__WDChamp.prototype._vOnLigneTableZRAffiche = function _vOnLigneTableZRAffiche(nLigneAbsolueBase1/*, bSelectionne*/)
	{
		// Si on doit d�clarer des objets suppl�mentaires
		if (this.m_pfConstructeursSupplementaires)
		{
			this.__AppelConstructeursSupplementairesZR(nLigneAbsolueBase1);
		}
	};
	__WDChamp.prototype.OnLigneTableZRMasque = function OnLigneTableZRMasque(/*nLigneAbsolueBase1*//*, bSelectionne*//*, oEvent*/) { this._vOnLigneTableZRMasque.apply(this, arguments); };
	__WDChamp.prototype._vOnLigneTableZRMasque = clWDUtil.m_pfVide;
	// - Tous les champs : notifie que une table ou ZR a �t� MAJ en AJAX (= table/ZR non AJAX mais avec les ZR horizontales)
	__WDChamp.prototype.OnTableZRAfficheAJAX = function OnTableZRAfficheAJAX(/*sAliasTableZR*/)
	{
		this._vOnTableZRAfficheAJAX.apply(this, arguments);
	};
	__WDChamp.prototype._vOnTableZRAfficheAJAX = function _vOnTableZRAfficheAJAX(sAliasTableZR)
	{
		if (this.m_sAliasTableZRParent === sAliasTableZR)
		{
			this._vOnTableZRAfficheAJAXInterne();
		}
	};
	__WDChamp.prototype._vOnTableZRAfficheAJAXInterne = clWDUtil.m_pfVide;

	// - Tous les champs : ..Xxx generique
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_SOUSELEMENT = -2;	// Objet
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_CONTENU = -1;		// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR = 1;		// Chaine/Valeur formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLE = 3;		// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_NOTE = 4; 			// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_HAUTEUR = 5;		// Entier
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_LARGEUR = 6;		// Entier
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEUR = 10;		// Formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURFOND = 11;	// Formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_ETAT = 12;			// Balise XML
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_OCCURRENCE = 14;	// Entier
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_VISIBLE = 18;		// Valeur formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEURAFFICHEE = 21; // Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_TITRENOTE = 27; 	// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_IMAGE = 34;		// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_URL = 38;			// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_BULLE = 39;		// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_X = 41;			// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_Y = 42;			// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_CURSEURSOURIS = 43; // Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEGRAS = 47;	// Entier
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEITALIQUE = 48; // Booleen formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICENOM = 49;	// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICESOULIGNE = 50; // Booleen formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICETAILLE = 51;	// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_OPACITE = 52;		// Entier
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_CADRAGEH = 53;		// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_CADRAGEV = 54;		// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_SELECTIONNEE = 55;	// Booleen formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_INDICATION = 58; 	// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_BORNEMIN = 64; 	// Entier/Flottant
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_BORNEMAX = 65; 	// Entier/Flottant
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_BOUTONCALENDRIER = 66; // Booleen formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_VIGNETTE = 68;		// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_ENROULE = 72;		// Booleen formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEURINFERIEURE = 89; // Chaine/Valeur formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEURSUPERIEURE = 90; // Chaine/Valeur formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLEHTML = 96;	// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_MODECARTE = 107; 	// Entier
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_ZOOM = 108; 		// Entier
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_CLASSEHTML = 113; 	// Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_TEXTEALTERNATIF = 115; // Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_PLAN = 118; 		 // Entier
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_IMAGEFOND = 122; 	 // Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURJAUGE = 123; // Formate en chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_TEXTESANSFORMAT = 130; // Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_BULLETITRE = 131; // Chaine
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_JETONLISTESEPARATEUR = 133; // Cha�ne
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_JETONAUTORISEDOUBLON = 134; // Bool�en format� en cha�ne
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_INFOTRAFIC = 137; // Bool�en format� en cha�ne
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_ANGLEROTATION = 138; // Entier/Flottant
	__WDChamp.prototype.XML_CHAMP_PROP_NUM_ANGLEINCLINAISON = 139; // Entier/Flottant

	// GP 14/03/2018 : D�placement de JS_ChampGetSetPropriete depuis le wwjs_script.fic.
	__WDChamp.prototype.s_oGetSetProp = function s_oGetSetProp(oValeur, oChamp, oObjet, oEvent, bSet, ePropriete)
	{
		// Gere l'indication dans le champ
		if (oObjet)
		{
			if (bSet)
			{
				return oObjet.SetProp(ePropriete, oEvent, oValeur, oChamp);
			}
			else
			{
				return oObjet.GetProp(ePropriete, oEvent, oValeur, oChamp);
			}
		}
		else
		{
			return oValeur;
		}
	};


	// @@@@ Ici nouvelle propri�t� WebDev (Si besoin)
	__WDChamp.prototype.GetProp = function GetProp(eProp, oEvent, oValeur, oChamp)
	{
		// Traite le cas de ..Valeur pour faire un rebond sur GetValeur
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_SOUSELEMENT:
			return null;
		case this.XML_CHAMP_PROP_NUM_VALEUR:
		// GP 26/10/2012 : QW224942 : g�r� explictement par les classes d�riv�es (qui en fait transforment ..Valeur en ..ValeurInf�rieure)
	//	case this.XML_CHAMP_PROP_NUM_VALEURINFERIEURE:
			return this.GetValeur(oEvent, oValeur, oChamp);
		case this.XML_CHAMP_PROP_NUM_PLAN:
			var jqChamp = $(oChamp);
			return jqChamp.wbPlanGet();
		default:
			return oValeur;
		}
	};
	__WDChamp.prototype.ms_sGetProp = "GetProp";
	__WDChamp.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp/*, oXMLAction*/)
	{
		// Traite le cas de ..Valeur pour faire un rebond sur SetValeur
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_VALEUR:
			// GP 26/10/2012 : QW224942 : g�r� explictement par les classes d�riv�es (qui en fait transforment ..Valeur en ..ValeurInf�rieure)
	//	case this.XML_CHAMP_PROP_NUM_VALEURINFERIEURE:
			return this.SetValeur(oEvent, oValeur, oChamp);
		case this.XML_CHAMP_PROP_NUM_PLAN:
			var jqChamp = $(oChamp);
			return jqChamp.wbPlanSet(oValeur);
		default:
			// Retourne inchangee la valeur de la propriete
			return oValeur;
		}
	};
	__WDChamp.prototype.ms_sSetProp = "SetProp";

	//////////////////////////////////////////////////////////////////////////
	// Gestion des ZRs

	// Indique que le champ est une ZR (ou pas dans le cas pr�sent)
	__WDChamp.prototype.vbZR = function vbZR()
	{
		return false;
	};

	// Indique si on est dans une ZR
	__WDChamp.prototype.bGestionTableZR = function bGestionTableZR()
	{
		return !!this.m_sAliasTableZRParent;
	};
	// Indique si on est dans une ZR AJAX et si c'est le cas retourne l'objet de la ZR (sinon retourne undefined)
	__WDChamp.prototype.oGetTableZRParent = function oGetTableZRParent()
	{
		return this.bGestionTableZR() ? this.ms_tabTablesZRs.oGetChampDirect(this.m_sAliasTableZRParent) : undefined;
	};

	// Retourne le premier element d'une ZR (le champ DOIT etre dans une ZR)
	__WDChamp.prototype.sGetTableZRValeur = function sGetTableZRValeur()
	{
		// GP 02/09/2014 : @@@ Faire une lecture directe si on a un objet champ (au lieu de lire dans le HTML)
		return document.getElementsByName(this.m_sAliasTableZRParent)[0].value;
	};
	__WDChamp.prototype.nGetTableZRValeur = function nGetTableZRValeur()
	{
		// GP 02/09/2014 : @@@ Faire une lecture directe si on a un objet champ (au lieu de lire dans le HTML)
		return parseInt(this.sGetTableZRValeur(), 10);
	};
	__WDChamp.prototype.SetTableZRValeur = function SetTableZRValeur(oEvent, nLigneAbsolueBase1, bDirect)
	{
		// Si on est dans une ZR AJAX, notifie le champ
		if (!bDirect)
		{
			var oTableZRParent = this.oGetTableZRParent();
			if (oTableZRParent)
			{
				oTableZRParent.vTableZROnSelectLigne(nLigneAbsolueBase1, oEvent);
				return;
			}
		}
		// Sinon ecrit directement dans le champ formulaire
		document.getElementsByName(this.m_sAliasTableZRParent)[0].value = nLigneAbsolueBase1;
	};
	// Fixe la valeur dans la ZR mais sans redessin
	__WDChamp.prototype.SetTableZRValeurDirect = function SetTableZRValeurDirect(nLigneAbsolueBase1)
	{
		this.SetTableZRValeur(null, nLigneAbsolueBase1, true);
	};
	__WDChamp.prototype.nGetTableZRDebut = function nGetTableZRDebut()
	{
		return parseInt(document.getElementsByName(this.m_sAliasTableZRParent + "_DEB")[0].value, 10);
	};
	__WDChamp.prototype.nGetTableZROccurrence = function nGetTableZROccurrence()
	{
		return this.s_nGetTableZROccurrence(this.m_sAliasTableZRParent);
	};
	__WDChamp.prototype.s_nGetTableZROccurrence = function s_nGetTableZROccurrence(sAliasTableZR)
	{
		var tabChamp = document.getElementsByName("_" + sAliasTableZR + "_OCC");
		// Pour les ZR horizontale tente sans le "_"
		if (0 == tabChamp.length)
		{
			tabChamp = document.getElementsByName(sAliasTableZR + "_OCC");
		}
		return (0 < tabChamp.length) ? parseInt(tabChamp[0].value, 10) : 0;
	};
	__WDChamp.prototype.PourToutesLignesTableZR = function PourToutesLignesTableZR(fFonction, oParametre)
	{
		// Trouve les bornes de la ZR
		var nDebut = this.nGetTableZRDebut();
		var nFin = nDebut + this.nGetTableZROccurrence();

		// Allocation et parcours du tableau
		for (var nLigneBase1 = nDebut; nLigneBase1 < nFin; nLigneBase1++)
		{
			fFonction.apply(this, [nLigneBase1, oParametre]);
		}
	};
	// Appel une methode sur une ligne particuliere de la ZR (ou sans ligne si on n'est pas dans une ZR)
	__WDChamp.prototype.oAppelSurLigneTableZR = function oAppelSurLigneTableZR(nIndiceTableZR, fFonction, tabParametres, oValeurDefaut)
	{
		var oResultat = oValeurDefaut;
		var sIndiceTableZRSav;
		try
		{
			if ((nIndiceTableZR !== undefined) && this.bGestionTableZR())
			{
				sIndiceTableZRSav = this.sGetTableZRValeur();
			}
			if ((sIndiceTableZRSav !== undefined) && (sIndiceTableZRSav != nIndiceTableZR))
			{
				this.SetTableZRValeurDirect(nIndiceTableZR);
			}
			else
			{
				sIndiceTableZRSav = undefined;
			}

			oResultat = fFonction.apply(this, tabParametres);
		}
		finally
		{
			if (sIndiceTableZRSav !== undefined)
			{
				this.SetTableZRValeurDirect(sIndiceTableZRSav);
			}
		}
		return oResultat;
	};

	// Notifie la ZR de la modification du champ
	__WDChamp.prototype._OnChampModifie = function _OnChampModifie(oEvent, oValeur)
	{
		if (oEvent)
		{
			var oTableZRParent = this.oGetTableZRParent();
			if (oTableZRParent)
			{
				oTableZRParent.vTableZROnValideLigne(oEvent, this, oValeur);
			}
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Methodes "virtuelles"

	// Trouve les divers elements : liaison avec le HTML
	__WDChamp.prototype._vLiaisonHTML = function _vLiaisonHTML(sSuffixeFormulaire/*, sSuffixeHote*/)
	{
		// Trouve le champ formulaire s'il existe
		sSuffixeFormulaire = sSuffixeFormulaire || "";
		var oChampFormulaire;
		if (this.bGestionTableZR())
		{
			oChampFormulaire = this.oGetElementByNameZR(document, sSuffixeFormulaire);
		}
		else
		{
			// On ne peut pas retourner la valeur par defaut car c'est le champ image qui a l'ID+NAME
			// On utilise donc un autre champ
			oChampFormulaire = this.oGetElementByName(document, sSuffixeFormulaire);
		}
		if (oChampFormulaire)
		{
			this.m_oChampFormulaire = oChampFormulaire;
		}
	};

	// Construit un parametre pour un objet (encode au format des parametres d'URL + encodage des ,)
	__WDChamp.prototype._sConstruitParamObjet = function _sConstruitParamObjet(oObjet)
	{
		var tabParam = [];
		for (var sCle in oObjet)
		{
			var sValeur = oObjet[sCle];
			// Selon le type de la valeur
			switch (typeof sValeur)
			{
			case "boolean":
				sValeur = sValeur ? "1" : "0";
				break;
			case "string":
			case "number":
			default:
				sValeur = encodeURIComponent(sValeur);
				break;
			case "object":
				// Accepte les dates
				// GP 20/03/2015 : null passe ici
				if ((null !== sValeur) && ("function" == typeof sValeur.getTime))
				{
					sValeur = sValeur.getTime() + "";
					break;
				}
				// Pas de break;
			case "function":
			case "undefined":
				continue;
			}
			// sCle ne contient normalement pas de ",", "=", "&"
			tabParam.push(sCle + "=" + sValeur.replace(/\,/g, "%2C"));
		}

		return tabParam.join("&");
	};

	// Lit la valeur si elle existe (sinon "")
	__WDChamp.prototype._vsGetValeurChampFormulaire = function _vsGetValeurChampFormulaire()
	{
		return this.m_oChampFormulaire ? this.m_oChampFormulaire.value : "";
	};

	// Ecrit la valeur du champ formulaire si il existe
	__WDChamp.prototype._vSetValeurChampFormulaire = function _vSetValeurChampFormulaire(sValeur)
	{
		if (this.m_oChampFormulaire)
		{
			this.m_oChampFormulaire.value = sValeur;
		}
	};

	// Indique si le champ est grise via le champ formulaire desactive
	__WDChamp.prototype._bEstGrise = function _bEstGrise(oChampFormulaire)
	{
		if (oChampFormulaire)
		{
			return bIE ? oChampFormulaire.disabled : oChampFormulaire.attributes.getNamedItem("disabled");
		}
		else
		{
			// Pas de champ : on consid�re non gris�
			return false;
		}
	};


	//////////////////////////////////////////////////////////////////////////
	// Gestion des champs

	// Retourne le nom d'un objet en fonction de son suffixe et du nom du champ
	__WDChamp.prototype.sGetNomElement = function sGetNomElement(sSuffixe)
	{
		return this.m_sAliasChamp + sSuffixe;
	};
	// Retourne un objet en fonction de son suffixe et du nom du champ
	__WDChamp.prototype.oGetElementById = function oGetElementById(oDocument, sSuffixe)
	{
		return oDocument.getElementById(this.sGetNomElement(sSuffixe));
	};
	__WDChamp.prototype.oGetElementByName = function oGetElementByName(oElement, sSuffixe)
	{
		return oElement.getElementsByName(this.sGetNomElement(sSuffixe))[0];
	};

	// Construit l'id d'un element par concatenation des suffixes
	__WDChamp.prototype.sGetSuffixeIDElement = function sGetSuffixeIDElement()
	{
		// On doit avoir au moins un parametre
		var tabSuffixe = [];
		var i;
		var nLimiteI = arguments.length;
		for (i = 0; i < nLimiteI; i++)
		{
			tabSuffixe.push(arguments[i]);
		}
		return ID_SEPARATEUR + tabSuffixe.join(ID_SEPARATEUR);
	};

	// Recupere un element en construisant son identifiant
	// Fonction en '...' : accepte un nombre variable d'arguments
	__WDChamp.prototype.oGetIDElement = function oGetIDElement()
	{
		return this.oGetElementById(document, this.sGetSuffixeIDElement.apply(this, arguments));
	};

	//////////////////////////////////////////////////////////////////////////
	// Gestion des champs dans les ZRs

	// Retourne le nom d'un objet en fonction de son suffixe, du nom du champ et de la presence d'une ZR
	__WDChamp.prototype.sGetNomElementZR = function sGetNomElementZR(sSuffixe)
	{
		return this.sGetNomElementZRCalc(this.bGestionTableZR(), sSuffixe);
	};
	// Retourne le nom d'un objet en fonction de son suffixe, du nom du champ et de la presence d'une ZR selon le parametre
	__WDChamp.prototype.sGetNomElementZRCalc = function sGetNomElementZRCalc(bDansZR, sSuffixe)
	{
		// Si on est dans une ZR
		if (bDansZR)
		{
			// Retourne _INDICEZR_ALIASCHAMP + suffixe
			return this.sGetNomElementAttributIndice(this.nGetTableZRValeur(), sSuffixe);
		}
		else
		{
			// Pas dans une ZR : methode normale
			return this.sGetNomElement(sSuffixe);
		}
	};

	// Retourne le nom d'un objet en fonction de son suffixe, du nom du champ et de son indice dans la ZR
	__WDChamp.prototype.sGetNomElementAttributIndice = function sGetNomElementAttributIndice(nIndice, sSuffixe)
	{
		// Retourne _INDICEZR_ALIASCHAMP + suffixe
		// Dans les ZR fichier avec rebond il faut tenir compte de this.nGetTableZRDebut() ?
		return "zrl_" + nIndice + "_" + this.m_sAliasAttribut + sSuffixe;
	};

	// Retourne un objet en fonction de son suffixe, du nom du champ et de la presence d'une ZR
	__WDChamp.prototype.oGetElementByIdZR = function oGetElementByIdZR(oDocument, sSuffixe)
	{
		return oDocument.getElementById(this.sGetNomElementZRCalc(this.bGestionTableZR(), sSuffixe));
	};
	__WDChamp.prototype.oGetElementByNameZR = function oGetElementByNameZR(oElement, sSuffixe)
	{
		return this.oGetElementByNameZRCalc(this.bGestionTableZR(), oElement, sSuffixe);
	};

	// Retourne un objet en fonction de son suffixe, du nom du champ et de la presence d'une ZR selon le parametre
	__WDChamp.prototype.oGetElementByNameZRCalc = function oGetElementByNameZRCalc(bDansZR, oElement, sSuffixe)
	{
		return oElement.getElementsByName(this.sGetNomElementZRCalc(bDansZR, sSuffixe))[0];
	};

	// Retourne un objet en fonction de son suffixe, du nom du champ et de son indice dans la ZR
	__WDChamp.prototype.oGetElementByIdZRIndice = function oGetElementByIdZRIndice(oDocument, nIndice, sSuffixe)
	{
		return oDocument.getElementById(this.sGetNomElementAttributIndice(nIndice, sSuffixe))
			// GP 02/03/2020 : Parfois l'alias donn� par WDJS est un alias d'attribut auto que la g�n�ration HTML ne respecte pas (sur les table/zrs navigateur ? <= mais il ne doit peut-�tre pas le respecter.)
			// => Donc en cas d'�chec fait une recherche avec juste l'alias du champ (comme ce qui est fait dans _JGE).
			|| oDocument.getElementById("zrl_" + nIndice + "_" + this.m_sAliasChamp + sSuffixe);
	};

	// Recupere un balise object ou embeb en fonction du navigateur
	// GP 03/12/2015 : TB90136 : Ajout de bAccepteEmbebPremier pour faire un cas particulier et ne pas prendre de risque avec le reste du code
	__WDChamp.prototype.oGetObjectEmbed = function oGetObjectEmbed(sNom, bAccepteObject, bAccepteEmbedPremier)
	{
		var tabChamp = document.getElementsByName(sNom);
		// Uniquement sous IE (balise object manipule par IE, embed par FF)
		if (tabChamp && (1 <= tabChamp.length))
		{
			if (tabChamp[0] && ((clWDUtil.bBaliseEstTag(tabChamp[0], "object") && bAccepteObject) || (clWDUtil.bBaliseEstTag(tabChamp[0], "embed") && bAccepteEmbedPremier)))
			{
				return tabChamp[0];
			}
			else if ((1 < tabChamp.length) && tabChamp[1])
			{
				return tabChamp[1];
			}
		}
		return document.getElementById(sNom);
	};

	// Autres methodes

	// Conversion d'une valeur quelquonque en booleen
	__WDChamp.prototype.bConversionValeur = function bConversionValeur(oValeur)
	{
		// Selon le type de la valeur
		switch (typeof oValeur)
		{
		case "boolean":
			return oValeur;
		case "string":
			return oValeur !== "0";
		case "number":
			return oValeur !== 0;
		case "function":
		case "object":
		case "undefined":
		default:
			return false;
		}
	};

	__WDChamp.prototype.s_dGetOffset = function s_dGetOffset(sVal)
	{
		var nOffset = parseFloat(sVal, 10);
		return (!isNaN(nOffset) && (nOffset > 0)) ? nOffset : 0;
	};
	__WDChamp.prototype.s_nGetOffsetBorderPourWidth = function s_nGetOffsetBorderPourWidth(oStyle)
	{
		return Math.floor(__WDChamp.prototype.s_dGetOffset(oStyle.borderLeftWidth) + __WDChamp.prototype.s_dGetOffset(oStyle.borderRightWidth));
	};
	__WDChamp.prototype.s_nGetOffsetBorderPourHeight = function s_nGetOffsetBorderPourHeight(oStyle)
	{
		return Math.floor(__WDChamp.prototype.s_dGetOffset(oStyle.borderTopWidth) + __WDChamp.prototype.s_dGetOffset(oStyle.borderBottomWidth));
	};

	// Remplace les fonctions par les fonctions bIEQuirks si besoin
	if (bIEQuirks)
	{
		// Lit le le offsetWidth/offsetHeight d'un champ (version bIEQuirks)
		// oStyle : optionnel
		__WDChamp.prototype._nGetOffsetWidth = function _nGetOffsetHeightIEQuirks(oElement, oStyle)
		{
			if (undefined === oStyle)
			{
				oStyle = oElement.currentStyle;
			}
			return oElement.offsetWidth - this.s_nGetOffsetBorderPourWidth(oStyle);
		};
		__WDChamp.prototype._nGetOffsetHeight = function _nGetOffsetHeightIEQuirks(oElement, oStyle)
		{
			if (undefined === oStyle)
			{
				oStyle = oElement.currentStyle;
			}
			return oElement.offsetHeight - this.s_nGetOffsetBorderPourHeight(oStyle);
		};
	}
	else
	{
		// Lit le le offsetWidth/offsetHeight d'un champ (version selon norme)
		__WDChamp.prototype._nGetOffsetWidth = function _nGetOffsetWidth(oElement)
		{
			return oElement.offsetWidth;
		};
		__WDChamp.prototype._nGetOffsetHeight = function _nGetOffsetHeight(oElement)
		{
			return oElement.offsetHeight;
		};
	}

	// Donne la largeur/hauteur de l'ascenseur dans un champ
	__WDChamp.prototype._nGetLargeurAscenseurVertical = function _nGetLargeurAscenseurVertical(oElement)
	{
		// GP 12/03/2014 : En mode quirks, on a parfois un clientWidth de z�ro selon le contenu
		// Si clientWidth et clientHeight sont a z�ro, on consid�re que l'on est dans ce cas bizarre.
		// (C'est techniquement possible hors de ce cas avec un �l�ment qui n'affiche que des ascenseurs)
		var nClientWidth = oElement.clientWidth;
		if ((0 == nClientWidth) && (0 == oElement.clientHeight))
		{
			return 0;
		}

		return this._nGetOffsetWidth(oElement) - nClientWidth;
	};
	__WDChamp.prototype._nGetHauteurAscenseurHorizontal = function _nGetHauteurAscenseurHorizontal(oElement)
	{
		// GP 12/03/2014 : En mode quirks, on a parfois un clientHeight de z�ro selon le contenu
		// Si clientHeight et clientHeight sont a z�ro, on consid�re que l'on est dans ce cas bizarre.
		// (C'est techniquement possible hors de ce cas avec un �l�ment qui n'affiche que des ascenseurs)
		var nClientHeight = oElement.clientHeight;
		if ((0 == nClientHeight) && (0 == oElement.clientWidth))
		{
			return 0;
		}

		return this._nGetOffsetHeight(oElement) - nClientHeight;
	};

	// Manipulation des styles (implementation des fonctions virtuelles)
	function __SetStyle(oElement, sStyle, oValeur)
	{
		// Ajout "px" pour les valeurs enti�res (sauf dans le cas 0)
		if ("number" === typeof oValeur)
		{
			oValeur = clWDUtil.GetDimensionPxPourStyle(oValeur);
		}
		oElement.style[sStyle] = oValeur;
	};
	__WDChamp.prototype.s_SetStyleLeft = function s_SetStyleLeft(oElement, oValeur)
	{
		__SetStyle(oElement, "left", oValeur);
	};
	__WDChamp.prototype.s_SetStyleTop = function s_SetStyleTop(oElement, oValeur)
	{
		__SetStyle(oElement, "top", oValeur);
	};
	__WDChamp.prototype.s_SetStyleRight = function s_SetStyleRight(oElement, oValeur)
	{
		__SetStyle(oElement, "right", oValeur);
	};
	__WDChamp.prototype.s_SetStyleBottom = function s_SetStyleBottom(oElement, oValeur)
	{
		__SetStyle(oElement, "bottom", oValeur);
	};
	__WDChamp.prototype.s_SetStyleWidth = function s_SetStyleWidth(oElement, oValeur)
	{
		__SetStyle(oElement, "width", oValeur);
	};
	__WDChamp.prototype.s_SetStyleHeight = function s_SetStyleHeight(oElement, oValeur)
	{
		__SetStyle(oElement, "height", oValeur);
	};

	// Si le champ a des animations
	__WDChamp.prototype.bAnimationsActives = function bAnimationsActives()
	{
		// GP 12/11/2018 : QW306242 : Nombre d'animations sur le champ.
//		return 0 < ms_nNbAnimationsActives;
		return 0 < this.m_nNbAnimationsActives;
	};

	return __WDChamp;
})();

// Champ avec des parametres
var WDChampParametres = (function ()
{
	"use strict";

	function __WDChampParametres(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChamp.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
			var oParametres = tabParametresSupplementaires[0];
			var oDonnees = tabParametresSupplementaires[1];

			this.m_oParametres = oParametres;
			this.m_oDonnees = oDonnees;
		}
	};

	// Declare l'heritage
	__WDChampParametres.prototype = new WDChamp();
	// Surcharge le constructeur qui a ete efface
	__WDChampParametres.prototype.constructor = __WDChampParametres;

	// Declare les fonction une par une

	// Fixe les parametres du champ (appel avant l'init ou en cas de retour AJAX)
	__WDChampParametres.prototype.SetParametres = function SetParametres(oParametres, oDonnees)
	{
		// Initialise les donnees
		this.m_oParametres = oParametres;
		// La valeur existe et est a false
		var oParametreFusion;
		if (false === oDonnees.m_bToutModifie)
		{
			oParametreFusion = this._voFusionneDonne(oDonnees);
		}
		else
		{
			this.m_oDonnees = oDonnees;
		}

		// Applique les modifications (Attention ! le champ n'est pas forcement encore initialise
		this._vAppliqueParametres(oParametreFusion);
	};

	// Pas de fusion (ne doit pas arriver)
	__WDChampParametres.prototype._voFusionneDonne = clWDUtil.m_pfVide;
	__WDChampParametres.prototype._vAppliqueParametres = clWDUtil.m_pfVide;

	// Fixe les parametres du champ (retour AJAX)
	// oParametres est un tableau de la forme : [Parametres, Donnees]
	__WDChampParametres.prototype._vDeduitParam = function _vDeduitParam(oParametres)
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype._vDeduitParam.apply(this, arguments);

		// Les parametres sont un tableau
		this.SetParametres(oParametres[0], oParametres[1]);
	};

	// Trouve les divers elements : liaison avec le HTML
	__WDChampParametres.prototype._vLiaisonHTML = function _vLiaisonHTML(sSuffixeFormulaire, sSuffixeHote)
	{
		sSuffixeFormulaire = (undefined !== sSuffixeFormulaire) ? sSuffixeFormulaire : "_DATA";

		// Appel de la methode de la classe de base avec les bon param�tres
		WDChamp.prototype._vLiaisonHTML.apply(this, [sSuffixeFormulaire, sSuffixeHote]);
	};

	// Indique si le champ est grise via le champ formulaire desactive
	__WDChampParametres.prototype._bGrise = function _bGrise()
	{
		this._vLiaisonHTML();
		return this._bEstGrise(this.m_oChampFormulaire);
	};

	// Indique si le champ est grise via le champ formulaire desactive
	__WDChampParametres.prototype._bLectureSeuleOuGrise = function _bLectureSeuleOuGrise()
	{
		this._vLiaisonHTML();
		var oChamp = this.m_oChampFormulaire;
		return bIE ? (oChamp.disabled || oChamp.readOnly) : (oChamp.attributes.getNamedItem("disabled") || oChamp.attributes.getNamedItem("readonly"));
	};

	// Lit le flag lecture seule
	__WDChampParametres.prototype.bLectureSeuleOuGriseExterne = function bLectureSeuleOuGriseExterne(nIndiceZR)
	{
		return this.oAppelSurLigneTableZR(nIndiceZR, this._bLectureSeuleOuGrise, [], true);
	};

	return __WDChampParametres;
})();

// Champ avec des parametres
var WDChampParametresHote = (function ()
{
	"use strict";

	function __WDChampParametresHote(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChampParametres.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]

			this.m_oHote = null;
		}
	};

	// Declare l'heritage
	__WDChampParametresHote.prototype = new WDChampParametres();
	// Surcharge le constructeur qui a ete efface
	__WDChampParametresHote.prototype.constructor = __WDChampParametresHote;

	// Declare les fonction une par une

	// Trouve les divers elements : liaison avec le HTML
	__WDChampParametresHote.prototype._vLiaisonHTML = function _vLiaisonHTML(sSuffixeFormulaire, sSuffixeHote)
	{
		sSuffixeHote = (undefined !== sSuffixeHote) ? sSuffixeHote : this.ms_sSuffixeHote;

		// Appel de la methode de la classe de base
		WDChampParametres.prototype._vLiaisonHTML.apply(this, [sSuffixeFormulaire, sSuffixeHote]);

		// La zone de dessin
		this.m_oHote = this.oGetElementByIdZR(document, sSuffixeHote);

		if (this.m_oHote)
		{
			// Regarde si on est avec un dimensionnement en %
			// Si le champ n'est pas a taille variable mais qu'il est non affichee alors la taille va changer quand meme (on lit une taille de zero alors)
			// Il faut aussi tester le cas cache en quirks
			this.m_bTailleVariable = __bStyleEnPourcent(this.m_oHote, "width") || __bStyleEnPourcent(this.m_oHote, "height") || !clWDUtil.bEstDisplay(this.m_oHote, document, bIEQuirks);
		}
	};

	// GP 10/12/2013 : Ce code est soit faux soit inutile :
	// - __WDChampParametresHote.prototype._vOnResize = clWDUtil.m_pfVide masque cette d�finition
	// - On fait un appel r�cursif infini sur nous m�me
//	// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
//	__WDChampParametresHote.prototype._vOnResize = function _vOnResize(/*oEvent*/)
//	{
//		// Appel de la methode de la classe de base
//		WDChampParametres.prototype._vOnResize.apply(this, arguments);
//	
//		// Uniquement si le contenu est de taille variable
//		if (this.m_oHote && this.m_bTailleVariable)
//		{
//			this._vOnResize.apply(this, arguments);
//		}
//	};
//	__WDChampParametresHote.prototype._vOnResize = clWDUtil.m_pfVide;

	function __bStyleEnPourcent(oElement, sStyle)
	{
		return -1 != __sGetElementStyleReel(oElement, sStyle).indexOf("%");
	};
	// Trouve la valeur originale. La lecture de la largeur effective ne fonctionne que en en quirks (on peux lire la valeur en %)
	// Avec les autres navigateurs on recoit la valeur finale en px
	function __sGetElementStyleReel(oElement, sStyle)
	{
		// La valeur directe (champ planning)
		var sValeur = oElement.style[sStyle];
		if ("" != sValeur)
		{
			return sValeur;
		}
		// Rien ne d�fini __oGetStyleRule
//		// La valeur dans un style sur l'ID (champ de saisie riche)
//		if (this.__oGetStyleRule)
//		{
//			var oRule = this.__oGetStyleRule("#" + this.sGetNomElement(this.ms_sSuffixeHote));
//			if (oRule)
//			{
//				sValeur = oRule.style[sStyle];
//				if ("" != sValeur)
//				{
//					return sValeur;
//				}
//			}
//		}

//		return clWDUtil.oGetCurrentStyle(oElement);
		return "";
	};

	return __WDChampParametresHote;
})();

//////////////////////////////////////////////////////////////////////////
// Classes utilitaires
//	WDMenuContextuel
//		Affichage des menus contextuels (tables, zone r�p�t�es et tableau de bord)
var WDMenuContextuel = (function()
{
	"use strict";

	function __WDMenuContextuel(oEvent, tabOptionsDescription, eSensOuverture, tabTraductions, pfCallbackSurFermeture)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// M�morise le tableau des options
			this.m_tabOptionsDescription = tabOptionsDescription;

			this.m_pfCallbackSurFermeture = pfCallbackSurFermeture;

			// GP 14/11/2014 : M�morise l'objet qui est la source de l'ouverture
			this.m_oSource = oEvent && clWDUtil.oGetOriginalTarget(oEvent);

			// Et d�claration des autres variables
			this.m_nOptionSurvol = -1;
			var oThis = this;
			this.m_fOnMouseMove = function(oEvent) { return oThis.__OnMouseMove(oEvent || event); };
			this.m_fOnClick = function(oEvent) { return oThis.__OnClick(oEvent || event); };

			// Cr�ation de la feuille de style si elle n'existe pas encore
			__CreeStyle();

			// Cr�ation et affichage du menu
			this.__CreeMenu(tabTraductions);
			this.__Ouvre(oEvent, eSensOuverture);
		}
	};

	// Constantes
	var ms_sClasseGenerale = "wb-menu-contextuel";
	var ms_sClasseSeparateur = "wb-menu-contextuel-separateur";
	var ms_sClasseInactif = "wb-menu-contextuel-inactif";
	var ms_sClasseSurvol = "wb-menu-contextuel-survol";
	var ms_sAnimation = "wb-menu-contextuel-animation";
	// GP 25/02/2015 : TB88160 : ms_eOuvreSensAutomatique : Demande l'ouverture dans une direction "intelligente"
	__WDMenuContextuel.prototype.ms_eOuvreSensAutomatique = -1;
	__WDMenuContextuel.prototype.ms_eOuvreBasDroite = 0;
	__WDMenuContextuel.prototype.ms_eOuvreBasGauche = 1;
	__WDMenuContextuel.prototype.ms_eOuvreHautDroite = 2;
	__WDMenuContextuel.prototype.ms_eOuvreHautGauche = 3;

	// Feuille de style globale (cr�� une seule fois) : le premier appel rend la fonction inop�rante.
	var __CreeStyle = function ()
	{
		var oFeuilleStyle = clWDUtil.oCreeFeuilleStyle();
		// 0 = FondGeneral1
		// 10 = TexteGeneral1
		// 16 = CadreGeneral1
		clWDUtil.CreeStyle(oFeuilleStyle, "ul." + ms_sClasseGenerale, "background-color:" + _COL[0] + ";color:" + _COL[10] + ";border:1px solid " + _COL[16] + ";z-index:999;position:absolute;text-align:left;margin:0;padding:0;list-style-type:none;font-family:Arial,Helvetica,sans-serif;cursor:pointer;animation:" + ms_sAnimation + " 300ms 1;");
//		lineHeight:19px;
//		top:0;left:0;		=> Inutile, on va ensuite plac� le menu
		clWDUtil.CreeStyle(oFeuilleStyle, "ul." + ms_sClasseGenerale + " li", "padding-right:1em");
		// 16 = CadreGeneral1
		clWDUtil.CreeStyle(oFeuilleStyle, "ul." + ms_sClasseGenerale + " li." + ms_sClasseSeparateur, "border-bottom:1px solid " + _COL[16]);
		clWDUtil.CreeStyle(oFeuilleStyle, "ul." + ms_sClasseGenerale + " li." + ms_sClasseInactif, "cursor:default;font-style:italic");
		// 5 = FondSelection
		// 15 = TexteSelection
		clWDUtil.CreeStyle(oFeuilleStyle, "ul." + ms_sClasseGenerale + " li." + ms_sClasseSurvol, "background-color:" + _COL[5] + ";color:" + _COL[15]);

		// 21 = FondGeneral2
		clWDUtil.CreeStyle(oFeuilleStyle, "ul." + ms_sClasseGenerale + " li img", "background-color:" + _COL[21] + ";width:2em;height:2em;object-fit:none;margin-right:0.5em;vertical-align:middle");
		// 5 = FondSelection
		// Utilise la couleur transparente : permet de voir la couleur du li et �vite un d�calage de couleur si il y a un bug en grande police avec le navigateur
//		clWDUtil.CreeStyle(oFeuilleStyle, "ul." + ms_sClasseGenerale + " li." + ms_sClasseSurvol + " img", "background-color:" + _COL[5]);
		clWDUtil.CreeStyle(oFeuilleStyle, "ul." + ms_sClasseGenerale + " li." + ms_sClasseSurvol + " img", "background-color:transparent");

		clWDUtil.CreeStyle(oFeuilleStyle, "@keyframes " + ms_sAnimation, "0%{transform:scaleY(0.8);transform-origin:0% 0%;opacity:0;}100%{transform:scaleY(1);transform-origin:0% 0%;opacity: 1;}");

		// Inhibe les prochains appel.
		__CreeStyle = clWDUtil.m_pfVide;
	};

	function __sGetVariableOuDefaut(oLibelle, tabTraduction, bTitre)
	{
		if (tabTraduction)
		{
			var oTraduction = tabTraduction[oLibelle.m_sTraduction];
			if (oTraduction)
			{
				oLibelle = oTraduction;
			}
		}
		return bTitre ? oLibelle.sTitre : oLibelle.sLibelle;
	}

	// M�thodes virtuelles pures
	// _vAction

	// Cr�ation du code HTML du menu
	__WDMenuContextuel.prototype.__CreeMenu = function __CreeMenu(tabTraductions)
	{
		// Creation du div
		var oUL = document.createElement("ul");
		oUL.className = ms_sClasseGenerale;

		var tabOptions = this.m_tabOptionsDescription;
		var nOptionDescription;
		var nLimiteOptionDescription = tabOptions.length;
		for (nOptionDescription = 0; nOptionDescription < nLimiteOptionDescription; nOptionDescription++)
		{
			var oOption = tabOptions[nOptionDescription];
			var oLI = document.createElement("li");
			var tabClasse = [];
			if (undefined !== oOption.m_oLibelle.sTitre)
			{
				oLI.title = __sGetVariableOuDefaut(oOption.m_oLibelle, tabTraductions, true);
			}
			if (oOption.m_bSeparateur)
			{
				tabClasse.push(ms_sClasseSeparateur);
			}
			if (oOption.m_bInactif)
			{
				tabClasse.push(ms_sClasseInactif);
			}
			if (tabClasse.length)
			{
				oLI.className = tabClasse.join(" ");
			}
			oLI.innerHTML = clWDUtil.sEncodeInnerHTML(__sGetVariableOuDefaut(oOption.m_oLibelle, tabTraductions, false));

			// L'image
			var oImg = document.createElement("img");
			oImg.src = clWDUtil.sCheminImageRes(undefined, (oOption.m_sImage || "vide.gif"));
			// GP 26/01/2021 : QW333949 : On veux bien s'ins�rer avant le premier �l�ment qui est du texte. Donc on utilise bien firstChild.
			// De plus comme on est dans un �l�ment construit, la mise en forme du HTML n'a pas d'effet.
			oLI.insertBefore(oImg, oLI.firstChild);

			oUL.appendChild(oLI);
		}

		// GP 16/02/2015 : QW254408 : Cr�" le menu en invisible
		oUL.style.display = "none";
		this.m_oMenu = document.body.appendChild(oUL);
		this.m_tabOptions = this.m_oMenu.getElementsByTagName("li");
	};

	// Ouvre le menu
	__WDMenuContextuel.prototype.__Ouvre = function __Ouvre(oEvent, eSensOuverture)
	{
		var nX = clWDUtil.nSourisPosX(oEvent, 0);
		var nY = clWDUtil.nSourisPosY(oEvent, 0);

		// GP 25/02/2015 : TB88160 : Si on demande l'ouverture dans une direction "intelligente" : mesure la page avant l'affichage du menu
		var nLargeurPage;
		var nLargeurScrollPage;
		var nHauteurPage;
		var nHauteurScrollPage;
		var eSensOuvertureEffectif;
		if (this.ms_eOuvreSensAutomatique === eSensOuverture)
		{
			nLargeurPage = clWDUtil.__nGetBodyPropriete(document, "clientWidth");
			nHauteurPage = clWDUtil.__nGetBodyPropriete(document, "clientHeight");
			// GP 19/04/2017 : TB98329 : Il faut aussi d�tecter le changement de largeur/hauteur si il y a d�j� des ascenseurs
			nLargeurScrollPage = clWDUtil.__nGetBodyPropriete(document, "scrollWidth");
			nHauteurScrollPage = clWDUtil.__nGetBodyPropriete(document, "scrollHeight");
			eSensOuvertureEffectif = this.ms_eOuvreBasDroite;
		}
		else
		{
			eSensOuvertureEffectif = eSensOuverture;
		}

		// GP 16/02/2015 : QW254408 : Affiche le menu mais apr�s les calculs de la position de la page (pour ne pas d�clencher de reflow/scroll avant le calcul de nSourisPosX/nSourisPosY)
		// Et avant la lecture de offsetWidth/offsetHeight pour ne pas lire 0
		this.m_oMenu.style.display = "";

		// GP 25/02/2015 : Prend les mesure une fois pour toutes car dans le cas this.ms_eOuvreSensAutomatique, la modification de .left et .top change la valeur lue
		var nLargeurMenuMoins1;
		var nHauteurMenuMoins1;
		switch (eSensOuverture)
		{
		case this.ms_eOuvreBasDroite:
			break;
		case this.ms_eOuvreBasGauche:
			nLargeurMenuMoins1 = this.m_oMenu.offsetWidth - 1;
			break;
		case this.ms_eOuvreHautDroite:
			nHauteurMenuMoins1 = this.m_oMenu.offsetHeight - 1;
			break;
		case this.ms_eOuvreHautGauche:
		case this.ms_eOuvreSensAutomatique:
			nLargeurMenuMoins1 = this.m_oMenu.offsetWidth - 1;
			nHauteurMenuMoins1 = this.m_oMenu.offsetHeight - 1;
			break;
		}

		while (true)
		{
			switch (eSensOuvertureEffectif)
			{
			case this.ms_eOuvreBasDroite:
				break;
			case this.ms_eOuvreBasGauche:
				nX -= nLargeurMenuMoins1;
				break;
			case this.ms_eOuvreHautDroite:
				nY -= nHauteurMenuMoins1;
				break;
			case this.ms_eOuvreHautGauche:
				nX -= nLargeurMenuMoins1;
				nY -= nHauteurMenuMoins1;
				break;
			}

			// Rend visible et modifie la position du menu contextuel en fonction du curseur de la souris
			this.m_oMenu.style.left = clWDUtil.GetDimensionPxPourStyle(nX);
			this.m_oMenu.style.top = clWDUtil.GetDimensionPxPourStyle(nY);

			// GP 25/02/2015 : TB88160 : Si on demande l'ouverture dans une direction "intelligente" : mesure la page apr�s l'affichage du menu et regarde si la page a changer
			// Si la zone a r�duit c'est un ascenseur est apparu
			// GP 19/04/2017 : TB98329 : Il faut aussi d�tecter le changement de largeur/hauteur si il y a d�j� des ascenseurs
			if ((this.ms_eOuvreSensAutomatique === eSensOuverture) && ((clWDUtil.__nGetBodyPropriete(document, "clientWidth") < nLargeurPage) || (clWDUtil.__nGetBodyPropriete(document, "clientHeight") < nHauteurPage) || (nLargeurScrollPage < clWDUtil.__nGetBodyPropriete(document, "scrollWidth")) || (nHauteurScrollPage < clWDUtil.__nGetBodyPropriete(document, "scrollHeight"))))
			{
				if (eSensOuvertureEffectif < this.ms_eOuvreHautGauche)
				{
					// Essaie une autre direction
					eSensOuvertureEffectif++;
				}
				else
				{
					// On essay� dans les 4 directions et aucune ne convient (!!!) : fait un dernier calcul avec this.ms_eOuvreBasDroite et arrete
					// Force eSensOuverture pour sortir de la boucle ensuite
					eSensOuverture = this.ms_eOuvreBasDroite;
					eSensOuvertureEffectif = this.ms_eOuvreBasDroite;
				}
			}
			else
			{
				break;
			}
		}

		// GP 05/12/2018 : TB110262 : Force la largeur du menu. Ainsi le menu n'est pas tente de prendre une largeur plus faible.
		// GP 20/12/2018 : QW308055 : Uniquement si nLargeurMenuMoins1 a �t� calcul� (la valeur n'est pas calcul� si on force le sens d'ouverture).
		if (undefined !== nLargeurMenuMoins1)
		{
			this.m_oMenu.style.width = clWDUtil.GetDimensionPxPourStyle(nLargeurMenuMoins1 + 1);
		}

		// Hook onmousemove pour le document entier
		clWDUtil.AttacheDetacheEvent(true, document, "mousemove", this.m_fOnMouseMove, false);
		// Hook click pour le menu
		clWDUtil.AttacheDetacheEvent(true, this.m_oMenu, "click", this.m_fOnClick, false);

		// Mise a jout du style
		this.__Selection(null);
	};

	__WDMenuContextuel.prototype.__Selection = function __Selection(oElementSurvol)
	{
		// Ancienne option survol�e
		var nOptionSurvolInitial = this.m_nOptionSurvol;

		// Calcule la nouvelle option survol�e
		var nOptionSurvolNouveau = -1;
		if (oElementSurvol)
		{
			var tabOptions = this.m_tabOptions;
			var nOption;
			var nLimiteOption = tabOptions.length;
			for (nOption = 0; nOption < nLimiteOption; nOption++)
			{
				// Si c'est l'option survol�e
				if (clWDUtil.bEstFils(oElementSurvol, tabOptions[nOption]))
				{
					// GP 14/11/2013 : QW239003 : Utilise bien l'indice dans this.m_tabOptionsDescription et pas dans this.m_tabOptions
					// Si l'option est d�sactiv�, pas de survol
					nOptionSurvolNouveau = this.m_tabOptionsDescription[nOption].m_bInactif ? -1 : nOption;
					// Fin de la recherche
					break;
				}
			}
		}

		// Si l'option survol�e a chang�e
		if (nOptionSurvolNouveau != nOptionSurvolInitial)
		{
			// Supprime le style de l'option survol�e initiale
			this.__SetStyleOption(nOptionSurvolInitial, ms_sClasseSurvol, undefined);
			// Ajoute le style a la nouvelle option survol�e
			this.__SetStyleOption(nOptionSurvolNouveau, undefined, ms_sClasseSurvol);

			// Et m�morise la nouvelle option
			this.m_nOptionSurvol = nOptionSurvolNouveau;
		}
	};

	// Fixe le style d'une option
	__WDMenuContextuel.prototype.__SetStyleOption = function __SetStyleOption(nOption, sClasseSupprime, sClasseAjoute)
	{
		if (-1 != nOption)
		{
			clWDUtil.RemplaceClassName(this.m_tabOptions[nOption], sClasseSupprime, sClasseAjoute);
		}
	};

	// Masque le menu
	__WDMenuContextuel.prototype.__Masque = function __Masque()
	{
		// Unhook click pour le menu
		clWDUtil.AttacheDetacheEvent(false, this.m_oMenu, "click", this.m_fOnClick, false);
		// Unhook onmousemove pour le document entier
		clWDUtil.AttacheDetacheEvent(false, document, "mousemove", this.m_fOnMouseMove, false);

		// Le menu n'est plus survol�e
		clWDUtil.oSupprimeElement(this.m_oMenu);

		if (this.m_pfCallbackSurFermeture)
		{
			this.m_pfCallbackSurFermeture();
		}
	};

	// Hook sur onmousemove pour le document entier
	__WDMenuContextuel.prototype.__OnMouseMove = function __OnMouseMove(oEvent)
	{
		// Si la source du mousemove est dans le menu : garde le menu ouvert, sinon ferme le menu
		var oSource = clWDUtil.oGetTarget(oEvent);
		if (clWDUtil.bEstFils(oSource, this.m_oMenu))
		{
			// Change le menu styl� si besoin
			this.__Selection(oSource);
		}
		// GP 14/11/2014 : QW251081 : Ajout de l'�l�ment source
		else if (this.m_oSource && clWDUtil.bEstFils(oSource, this.m_oSource))
		{
			// Ne fait rien : ni survol ni masquage
		}
		else
		{
			// Masque le menu (lib�re ce qui nous d�truit)
			this.__Masque();
		}
	};

	// Hook sur onclick pour le menu
	__WDMenuContextuel.prototype.__OnClick = function __OnClick(oEvent)
	{
		var nOptionSelection = this.m_nOptionSurvol;
		if (-1 != nOptionSelection)
		{
			// GP 14/11/2013 : QW239003 : Utilise bien l'indice dans this.m_tabOptionsDescription et pas dans this.m_tabOptions
			// Lance l'action
			this._vAction(oEvent, this.m_tabOptionsDescription[nOptionSelection]);
			// Et masque le menu (lib�re ce qui nous d�truit)
			this.__Masque();
		}
	};

	return __WDMenuContextuel;
})();
