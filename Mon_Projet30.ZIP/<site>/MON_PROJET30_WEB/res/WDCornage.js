// WDCornage.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDChamp.js
///#GLOBALS WDChamp

function WDCornage(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChamp.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ eCoin ]
		var eCoin = tabParametresSupplementaires[0];

		this.m_eCoin = eCoin;
	}
};

WDCornage.prototype=new WDChamp();
WDCornage.prototype.constructor=WDCornage;

WDCornage.prototype.ms_nCoinHautGauche=0;
WDCornage.prototype.ms_nCoinHautDroit=1;
WDCornage.prototype.ms_nCoinBasGauche=2;
WDCornage.prototype.ms_nCoinBasDroit=3;

WDCornage.prototype.ms_nDelta=10;
WDCornage.prototype.ms_nDelai=10;

function sExtraitImage(sURLImage,sSepDeb,sSepFin)
{
	return sURLImage.substring(sURLImage.indexOf(sSepDeb)+1,sURLImage.lastIndexOf((sSepFin==null)?sSepDeb:sSepFin));
};

WDCornage.prototype.Init=function Init()
{
	WDChamp.prototype.Init.apply(this, arguments);
	this.m_oObjet=document.getElementById(this.m_sAliasChamp);
	this.InitTailleImageStyle(clWDUtil.oGetCurrentStyle(this.m_oObjet).backgroundImage);
	this.m_nLargeurInit=this.nGetLargeur();
	this.m_nHauteurInit=this.nGetHauteur();
	this.m_nTimer = null;
	var oThis=this;
	this.m_oObjet.onmouseover=function(oEvent) { oThis.OnMouseOver(oEvent||event); };
	this.m_oObjet.onmouseout=function(oEvent) { oThis.OnMouseOut(oEvent||event); };
	this.m_pfCallBack=function() { oThis.Anim(); }
};

// Calcul les hauteurs de l'image du champ depuis le style
WDCornage.prototype.InitTailleImageStyle=function InitTailleImageStyle(sURLImageStyle)
{
	// Extrait le chemin de l'image
	var sURLImage=sExtraitImage(sURLImageStyle,"\"");
	if(sURLImage=="")
	{
		sURLImage=sExtraitImage(sURLImageStyle,"\'");
		if(sURLImage=="")
		{
			sURLImage=sExtraitImage(sURLImageStyle,"(",")");
		}
	}

	this.InitTailleImage(sURLImage);
};

WDCornage.prototype.ms_sInitTailleImage="InitTailleImage";
WDCornage.prototype.InitTailleImage=function InitTailleImage(sURLImage)
{
	// Il faut attendre le chargement de l'image pour lire sa taille
	// Donc on memorise directement l'image
	this.m_oImage=new Image();
	this.m_oImage.src=sURLImage;
};

WDCornage.prototype.nGetLargeur=function nGetLargeur()
{
	return this.m_oObjet.offsetWidth;
};

WDCornage.prototype.nGetHauteur=function nGetHauteur()
{
	return this.m_oObjet.offsetHeight;
};

WDCornage.prototype.nDelta=function nDelta(nValInit,nValFin,nVal)
{
	var nFacteur=(nValInit>nValFin)?(-1):1;
	return (this.m_bOuvre?1:(-1))*nFacteur*Math.min(Math.max(1,Math.round((nFacteur*(nValFin-nValInit))/this.ms_nDelta)),nFacteur*(this.m_bOuvre?(nValFin-nVal):(nVal-nValInit)));
};

WDCornage.prototype.sValeurStyle=function sValeurStyle(nVal)
{
	return nVal+"px";
};

WDCornage.prototype.Anim = function Anim()
{
	var nLargeur = this.nGetLargeur();
	var nDeltaX = this.nDelta(this.m_nLargeurInit, this.m_oImage.width, nLargeur);
	var nHauteur = this.nGetHauteur();
	var nDeltaY = this.nDelta(this.m_nHauteurInit, this.m_oImage.height, nHauteur);
	var oObjet = this.m_oObjet;
	var oStyle = oObjet.style;
	var bDeltaX = (nDeltaX != 0);
	if (bDeltaX)
	{
		if ((this.m_eCoin == this.ms_nCoinHautDroit) || (this.m_eCoin == this.ms_nCoinBasDroit))
		{
			oStyle.left = this.sValeurStyle(oObjet.offsetLeft - nDeltaX);
		}
		oStyle.width = this.sValeurStyle(nLargeur + nDeltaX);
	}
	var bDeltaY = (nDeltaY != 0);
	if (bDeltaY)
	{
		if (this.m_eCoin > this.ms_nCoinHautDroit)
		{
			oStyle.top = this.sValeurStyle(oObjet.offsetTop - nDeltaY);
		}
		oStyle.height = this.sValeurStyle(nHauteur + nDeltaY);
	}
	if (bDeltaX || bDeltaY)
	{
		this.m_nTimer = clWDUtil.nSetTimeout(this.m_pfCallBack, this.ms_nDelai);
	}
	else
	{
		this.m_nTimer = null;
	}
};

function FinAnim(oAnim)
{
	if(oAnim!=null)
	{
		oAnim.vAnnule();
		delete oAnim;
	}
	return null;
};

WDCornage.prototype.LanceAnim = function LanceAnim(bOuvre)
{
	if (bOuvre != this.m_bOuvre)
	{
		if(this.m_nTimer != null)
		{
			clWDUtil.ClearTimeout(this.m_nTimer);
			this.m_nTimer = null;
		}
		this.m_bOuvre = bOuvre;
	}
	if (this.m_nTimer == null)
	{
		this.Anim();
	}
};

WDCornage.prototype.OnMouseOver=function OnMouseOver(/*oEvent*/)
{
	this.LanceAnim(true);
};

WDCornage.prototype.OnMouseOut=function OnMouseOut(/*oEvent*/)
{
	this.LanceAnim(false);
};
