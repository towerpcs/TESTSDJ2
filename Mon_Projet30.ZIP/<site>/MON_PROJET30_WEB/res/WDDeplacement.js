// WDDeplacement.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - StdAction.js
///#GLOBALS _JGE _JGEN
// - WDUtil.js
///#GLOBALS bIE
// - WDDrag.js
///#GLOBALS WDDrag

// Objet pour suivre le d�placement pour WDPositionXY
function WDDeplace(/*bPasPourPrototype*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel du constructeur de la classe de base
		// GP 26/11/2014 : TB88706 : Pas de d�lai
//		WDDrag.prototype.constructor.apply(this, [0, 50]);
		WDDrag.prototype.constructor.apply(this, [0, 0]);

		this.m_nBloqueTime = 0;
	}
};
// Declare l'heritage
WDDeplace.prototype = new WDDrag();
// Surcharge le constructeur qui a ete efface
WDDeplace.prototype.constructor = WDDeplace;

// Bloque le traitement du deplacement
WDDeplace.prototype.BloqueDeplacement = function BloqueDeplacement()
{
	// On ne peu pas bloquer la propagation (Empecherait des traitements legitime de mousedown au niveau plus global)
	// On note de na pas traiter ce clic a ce moment
	this.m_nBloqueTime = (new Date()).getTime();
};
// Si on bloque le d�placement
WDDeplace.prototype.__bBloque = function __bBloque()
{
	// Si la classe de base bloque
	if (WDPosition.prototype.s_bBloque())
	{
		return true;
	}

	// Si on est proche d'un deplacement bloque : on se bloque. La limite est fixe raisonnablement a 20ms (Resolution du timer)
	return (((new Date()).getTime() - this.m_nBloqueTime) < 20);
};

// Appel lors du debut d'un click pour le redimensionnement
WDDeplace.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent, sIDDeplace, bSauvePosition, bTableZR)
{
		// Si on est proche d'un deplacement bloque : on se bloque. La limite est fixe raisonnablement a 20ms (Resolution du timer)
	if (this.__bBloque())
	{
		return false;
	}

	// Cherche l'element a modifier
	var oObjet = _JGE(sIDDeplace, document, true, false);
	if (!oObjet)
	{
		return;
	}

	// Si il y a deja un deplacement en cours : le libere
	if (this.m_oObjetDeplace)
	{
		this.bOnMouseUp(oEvent);
	}

	// Appel de la classe de base : sauve la position de la souris et place les hooks
	if (!WDDrag.prototype._vbOnMouseDown.apply(this, arguments))
	{
		return false;
	}

	// GP 27/11/2007 : QW45597 Si on est dans une zone repetee : on tente de trouver l'element directement au lieu de premier dans la page
	if (bTableZR)
	{
		var sIdDww = "dww" + sIDDeplace.replace(/_/g, "");
		var sIdDwwCz = "dwwcz" + sIDDeplace.replace(/_/g, "");
		var oCurseur = clWDUtil.oGetTarget();
		var oCurseurPrec = null;
		while ((oCurseur != null) && (oCurseur != document.body) && (oCurseur != oCurseurPrec))
		{
			// Regarde si on ne trouve pas un element plus favorable
			if ((oCurseur.id == sIdDww) || (oCurseur.id == sIdDwwCz))
			{
				oObjet = oCurseur;
				break;
			}
			// Remonte au parent
			oCurseurPrec = oCurseur;
			oCurseur = oCurseur.parentNode;
		}
	}

//	// GP 12/02/2014 : TB85639, sur certains navigateur certaines balises sont draggable par d�faut (draggable absent => draggable="auto" => draggable)
//	// c'est le cas par exemple de firefox avec les balises img.
//	var tabBalises = clWDUtil.tabDupliqueTableau(oObjet.getElementsByTagName("img"));
//	tabBalises.push(oObjet);
//	var tabDraggable = [];
//	clWDUtil.bForEach(tabBalises, function(oImg)
//	{
//		var oObjetImg = { m_oImg: oImg };
//		if (oImg.hasAttribute && oImg.hasAttribute("draggable"))
//		{
//			oObjetImg.m_sDraggable = oImg.getAttribute("draggable");
//		}
//		oImg.setAttribute("draggable", "false", 0);
//		tabDraggable.push(oObjetImg);
//		return true;
//	});
//	this.m_tabDraggable = tabDraggable;

	// Et la position originale de l'element
	this.m_nPosElementX = parseInt(clWDUtil.GetStyleLeft(clWDUtil.oGetCurrentStyle(oObjet)), 10);
	this.m_nPosElementY = parseInt(clWDUtil.oGetCurrentStyle(oObjet).top, 10);

	// Et l'objet a deplacer
	this.m_oObjetDeplace = oObjet;
	this.m_bSauvePosition = bSauvePosition;
	this.m_sIDDeplace = sIDDeplace;

	// Bloque les prochain traitement du deplacement
	this.BloqueDeplacement();

	// Sauf que si on est sur un champ formulaire, il ne prend le focus que sous IE. On le fait au moins sur les inputs
	if (!bIE)
	{
		var oSource = clWDUtil.oGetOriginalTarget(oEvent);
		if (clWDUtil.bBaliseEstTag(oSource, "input"))
		{
			oSource.focus();
		}
	}

	// Empeche la propagation de l'evenement
	return true;
};

// Appel lors du deplacement de la souris
WDDeplace.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
{
	// Appel de la classe de base
	WDDrag.prototype._vOnMouseMove.apply(this, arguments);

	// Effectue le deplacement
	clWDUtil.SetStyleLeft(this.m_oObjetDeplace.style, this.m_nPosElementX, this.nGetOffsetPosX(oEvent));
	this.m_oObjetDeplace.style.top = (this.m_nPosElementY + this.nGetOffsetPosY(oEvent)) + "px";
};

// Appel lors du relachement de la souris
WDDeplace.prototype._vOnMouseUp = function _vOnMouseUp(/*oEvent*/)
{
	var oObjet = this.m_oObjetDeplace;

	// Sauve la position si demandee
	if (this.m_bSauvePosition)
	{
		// Ajoute la position dans le tableau des positions (ou la remplace)
		var oPosition = new WDPositionXY(null);
		oPosition.vSauve(oObjet);
		WDPosition.prototype.s_Ajoute(oPosition, this.m_sIDDeplace);
	}

	// Supprime la position souris
	delete this.m_nPosElementX;
	delete this.m_nPosElementY;

//	// Supprime l'�tat draggable=false des imgs
//	clWDUtil.bForEach(this.m_tabDraggable, function(oObjetImg)
//	{
//		var oImg = oObjetImg.m_oImg;
//		if (undefined !== oObjetImg.m_sDraggable)
//		{
//			oImg.setAttribute("draggable", oObjetImg.m_sDraggable, 0);
//		}
//		else
//		{
//			oImg.removeAttribute("draggable", 0);
//		}
//		return true;
//	});
//	delete this.m_tabDraggable;

	// Et l'objet a deplacer
	delete this.m_oObjetDeplace;
	delete this.m_bSauvePosition;
	delete this.m_sIDDeplace;

	// Appel de la classe de base
	WDDrag.prototype._vOnMouseUp.apply(this, arguments);
};

// Classe representant une position
function WDPosition(tabElements, nType)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Tableau des indications
		if (tabElements)
		{
			this.m_tabElements = tabElements;
		}
		else
		{
			this.m_tabElements = [];
			this.__s_SetVersionCourante(this.m_tabElements, nType);
		}
	}
};

// GP 12/11/2013 : Passage � la version 1
// - 0 : Que la position des champs
// - 1 : Position des champs et ordre des colonnes de tables
// La version courante (= que l'on s�rialise)
WDPosition.prototype.ms_nVersionCourante = 1;
// La version que l'on accepte de lire : on relit la version 0
WDPosition.prototype.ms_nVersionMin = 0;
// La version requise pour nous lire : la version 0 ne sait pas nous relire
WDPosition.prototype.ms_nVersionMinReq = 1;

// Indice des donn�es dans la table
WDPosition.prototype.ms_nIndiceVersion = 0;
WDPosition.prototype.ms_nIndiceVersionMinReq = 1;
WDPosition.prototype.ms_nIndiceType = 2;
WDPosition.prototype.ms_nIndiceDebutSpecifique = 3;

// Type de positions
WDPosition.prototype.ms_nTypeXY = 0;
WDPosition.prototype.ms_nTypeColonnes = 1;

// Contenu du cookie
WDPosition.prototype.ms_sSeparateurIntraPosition = "|";

WDPosition.prototype.ms_cSeparateurIDPosition = ":";
WDPosition.prototype.ms_sSeparateurInterPositions = "&";
WDPosition.prototype.ms_sCookieName= "WDDeplace";

// Tableau global des positions : on ne fait pas un vrai tableau mais un objet pour avoir un tableau associatif via les proprietes
WDPosition.prototype.ms_tabPositions = {};

// Virtuelles pures :
//vSauve
//vbCharge

// Indique que la page est charg� et qu'il va falloir faire le chargement initial
// Mais ce sera fait apres les appels de Init
WDPosition.prototype.s_ChargementPrepare = function s_ChargementPrepare(sNomApplication, sNomPage)
{
	var oPrototype = WDPosition.prototype;

	oPrototype.ms_sPrefixeId = sNomApplication + "." + sNomPage + ".";

	clWDUtil.nSetTimeout(oPrototype.s_Chargement, clWDUtil.ms_oTimeoutImmediat);

	// On ne fait que une seule fois cette initialisation (si on a des pages internes on peut avoir plusieurs appels)
	oPrototype.s_ChargementPrepare = clWDUtil.m_pfVide;
};

// Charge le tableau des positions
WDPosition.prototype.s_Chargement = function s_Chargement()
{
	var oPrototype = WDPosition.prototype;
	var tabPositions = oPrototype.ms_tabPositions;

	// On a commenc� le chargement (a faire avant le return du cookie vide)
	oPrototype.ms_bCharge = true;

	// Recupere la valeur du cookie
	var sCookie = clWDUtil.m_oCookie.GetCookie(oPrototype.ms_sCookieName);
	if (sCookie.length == 0)
	{
		return;
	}

	// Decoupe le cookie
	var tabPositionsCookie = sCookie.split(oPrototype.ms_sSeparateurInterPositions);
	var nPositionCookie = 0;
	var nLimitePositionCookie = tabPositionsCookie.length;
	for (nPositionCookie = 0; nPositionCookie < nLimitePositionCookie; nPositionCookie++)
	{
		// Gere les cas d'erreurs
		if (tabPositionsCookie[nPositionCookie])
		{
			var tabPosition = tabPositionsCookie[nPositionCookie].split(oPrototype.ms_cSeparateurIDPosition);

			// Gere les cas d'erreurs
			if (tabPosition[0] && tabPosition[1])
			{
				// Et affecte les valeurs
				var oPosition = oPrototype.__s_ChargementUnePosition(tabPosition[1]);
				if (oPosition)
				{
					tabPositions[tabPosition[0]] = oPosition;
				}
			}
		}
	}

	// Restaure les positions
	clWDUtil.bForEachIn(tabPositions, function(sIDComplet, oPosition)
	{
		// Si l'id est dans notre application et dans la page courante
		if (clWDUtil.s_bCommencePar(sIDComplet, oPrototype.ms_sPrefixeId))
		{
			var sID = sIDComplet.substring(oPrototype.ms_sPrefixeId.length);
			if (!oPosition.vbCharge(sID))
			{
				// Si l'objet n'existe plus, on le supprime pour ne pas surchager le stockage
				delete oPrototype.ms_tabPositions[oPrototype.ms_sPrefixeId + sID];

				// Resauve les positions
				oPrototype.s_Sauvegarde();
			}
		}

		return true;
	});
};

// Si on bloque
WDPosition.prototype.s_bBloque = function s_bBloque()
{
	// Tant que l'on n'est pas charg�
	return !WDPosition.prototype.ms_bCharge;
};

// Sauve le tableau des positions
WDPosition.prototype.s_Sauvegarde = function s_Sauvegarde()
{
	var oPrototype = WDPosition.prototype;
	var tabPositions = oPrototype.ms_tabPositions;

	// Si pas d'elements : fini
	var nNbElements = 0;
	clWDUtil.bForEachIn(tabPositions, function(/*sID*//*, oPosition*/)
	{
		nNbElements++;
		return true;
	});

	// Si pas d'elements : fini
	if ((tabPositions.length == 0) || (nNbElements == 0))
	{
		// Supprime notre cookie au passage
		clWDUtil.m_oCookie.ClearCookie(oPrototype.ms_sCookieName);
		return;
	}

	// Cree un tableau avec les descriptions
	// Pour toutes les entrees du tableau des positions : recupere la chaine
	var tabChainePositions = [];
	clWDUtil.bForEachIn(tabPositions, function(sID, oPosition)
	{
		tabChainePositions.push(sID + oPrototype.ms_cSeparateurIDPosition + oPosition.__toString());
		return true;
	});

	// Cree la chaine du cookie
	var sValeur = tabChainePositions.join(oPrototype.ms_sSeparateurInterPositions);

	// Et le sauve
	clWDUtil.m_oCookie.SetCookie(oPrototype.ms_sCookieName, sValeur);
};

// Construit une position (deserialisation)
WDPosition.prototype.__s_ChargementUnePosition = function __s_ChargementUnePosition(sValeur)
{
	var oPrototype = WDPosition.prototype;

	// Explose la chaine
	var tabTmp = sValeur.split(oPrototype.ms_sSeparateurIntraPosition);

	// Si il y a un probleme avec les versions
	tabTmp[oPrototype.ms_nIndiceVersion] = parseInt(tabTmp[oPrototype.ms_nIndiceVersion], 10);
	if (tabTmp[oPrototype.ms_nIndiceVersion] < oPrototype.ms_nVersionMin)
	{
		return false;
	}
	tabTmp[oPrototype.ms_nIndiceVersionMinReq] = parseInt(tabTmp[oPrototype.ms_nIndiceVersionMinReq], 10);
	if (tabTmp[oPrototype.ms_nIndiceVersionMinReq] > oPrototype.ms_nVersionCourante)
	{
		return false;
	}

	// Si on relit une version 0 : ajoute un �l�ment dans la version
	if (0 == tabTmp[oPrototype.ms_nIndiceVersion])
	{
		tabTmp.splice(oPrototype.ms_nIndiceType, 0, [oPrototype.ms_nTypeXY]);
		oPrototype.__s_SetVersionCourante(tabTmp, oPrototype.ms_nTypeXY);
	}
	else
	{
		tabTmp[oPrototype.ms_nIndiceType] = parseInt(tabTmp[oPrototype.ms_nIndiceType], 10);
	}

	// Construit l'objet
	switch (tabTmp[oPrototype.ms_nIndiceType])
	{
		case oPrototype.ms_nTypeXY:
			return new WDPositionXY(tabTmp);
		case oPrototype.ms_nTypeColonnes:
			return new WDPositionColonnes(tabTmp);
		default:
			return undefined;
	}
};

// Ecrit la version courante
WDPosition.prototype.__s_SetVersionCourante =  function __s_SetVersionCourante(tabElements, nType)
{
	var oPrototype = WDPosition.prototype;

	tabElements[oPrototype.ms_nIndiceVersion] = oPrototype.ms_nVersionCourante;
	tabElements[oPrototype.ms_nIndiceVersionMinReq] = oPrototype.ms_nVersionMinReq;
	tabElements[oPrototype.ms_nIndiceType] = nType;
};

// Ajoute une position
WDPosition.prototype.s_Ajoute = function s_Ajoute(oPosition, sID)
{
	var oPrototype = WDPosition.prototype;

	oPrototype.ms_tabPositions[oPrototype.ms_sPrefixeId + sID] = oPosition;

	// Resauve les positions
	oPrototype.s_Sauvegarde();
};

// Type de la position
WDPosition.prototype.__nGetType = function __nGetType()
{
	return parseInt(this.m_tabElements[this.ms_nIndiceType], 10);
};

// Serialisation
WDPosition.prototype.__toString = function __toString()
{
	// Renvoie les valeurs separees par des |
	return this.m_tabElements.join(this.ms_sSeparateurIntraPosition);
};

// M�morise la position
WDPosition.prototype.vSauve = function vSauve()
{
	// Supprime les donn�es actuelles
	this.m_tabElements.length = this.ms_nIndiceDebutSpecifique;
};

// Ecriture d'une propriete
WDPosition.prototype.__Ecrit = function __Ecrit(sValeur)
{
	// Sauve la valeur
	this.m_tabElements.push(sValeur);
};

// Lecture d'une propriete
WDPosition.prototype.__sLit = function __sLit(nIndice)
{
	// Lit la valeur
	return this.m_tabElements[this.ms_nIndiceDebutSpecifique + nIndice];
};

// Classe representant la position X/Y d'un champ
function WDPositionXY(tabElements)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel du constructeur de la classe de base
		WDPosition.prototype.constructor.apply(this, [tabElements, this.ms_nTypeXY]);
	}
};
// Declare l'heritage
WDPositionXY.prototype = new WDPosition();
// Surcharge le constructeur qui a ete efface
WDPositionXY.prototype.constructor = WDPositionXY;

WDPositionXY.prototype.ms_nIndicePosX = 0;
WDPositionXY.prototype.ms_nIndicePosY = 1;

// Tableau des elements dont ont doit restaurer la position
WDPositionXY.prototype.ms_tabMemorise = [];
// Date de base pour le blocage
WDPositionXY.prototype.ms_oDeplace = new WDDeplace(true);

WDPositionXY.prototype.s_AjouteDeplacement = function s_AjouteDeplacement(tabMemorise)
{
	// Ajoute une serie d'element au tableau des elements memorise
	WDPositionXY.prototype.ms_tabMemorise = WDPositionXY.prototype.ms_tabMemorise.concat(tabMemorise);
};

// Sauve la position
WDPositionXY.prototype.vSauve = function vSauve(oObjet)
{
	// Supprime la position actuelle.
	WDPosition.prototype.vSauve.apply(this, arguments);
	this.__Ecrit(clWDUtil.GetStyleLeft(clWDUtil.oGetCurrentStyle(oObjet)));
	this.__Ecrit(clWDUtil.oGetCurrentStyle(oObjet).top);
};

// Restaure une position
WDPositionXY.prototype.vbCharge = function vbCharge(sID)
{
	if (clWDUtil.bDansTableau(this.ms_tabMemorise, sID))
	{
		// Restaure la position
		var oObjet = _JGE(sID, document, true, false);
		if (oObjet)
		{
			clWDUtil.SetStyleLeft(oObjet.style, parseInt(this.__sLit(this.ms_nIndicePosX), 10), 0);
			oObjet.style.top = this.__sLit(this.ms_nIndicePosY);
		}
		return true;
	}
	else
	{
		// Si l'objet n'existe plus, on le supprime pour ne pas surchager le stockage
		return false;
	}
};

// Classe representant l'ordre des colonnes d'une table AJAX
function WDPositionColonnes(tabElements)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel du constructeur de la classe de base
		WDPosition.prototype.constructor.apply(this, [tabElements, this.ms_nTypeColonnes]);
	}
};
// Declare l'heritage
WDPositionColonnes.prototype = new WDPosition();
// Surcharge le constructeur qui a ete efface
WDPositionColonnes.prototype.constructor = WDPositionColonnes;

// M�morise la position
WDPositionColonnes.prototype.vSauve = function vSauve(tabColonnes)
{
	// Supprime les colonnes actuelles.
	WDPosition.prototype.vSauve.apply(this, arguments);

	// Stocke l'ordre des colonnes
	clWDUtil.bForEachThis(tabColonnes, this, function(oColonne)
	{
		this.__Ecrit(oColonne.m_nPositionAffichage);
		return true;
	});
};

// Charge la position
WDPositionColonnes.prototype.vbCharge = function vbCharge(sID)
{
	// Si on trouve le champ de ce nom (l'ID est l'alias du champ)
	var oChamp = oGetObjetChamp(sID);
	// GP 19/11/2013 : Pour �viter les m�langue (changement du type d'une table : on test si la table a bien la m�thode
	if (oChamp && oChamp.SetColonnePositionAffichage)
	{
		// Extraction des indices de colonne et transformation en chaine des valeurs
		var tabTableauNew = [];
		clWDUtil.bForEachIn(this.m_tabElements, function(sMembre, oElement)
		{
			tabTableauNew.push(parseInt(oElement, 10));
			return true;
		});
		oChamp.SetColonnePositionAffichage(tabTableauNew.slice(this.ms_nIndiceDebutSpecifique));
		return true;
	}
	else
	{
		// Si l'objet n'existe plus, on le supprime pour ne pas surchager le stockage
		return false;
	}
};
