// WDDessin.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

//var dEffacer = 0;
var dSansEffacer = 1;
var dAvecOpacite = 2;
//var dQuadrillageOpacite = 4;
//var dSurGraphe = 8;
var dAffichageManuel = 16;
var nAffichageAsynchrone = 32;
var OPACITE_MAX = 255;
var FACTEUR_BLEU = 0x10000;
var FACTEUR_VERT = 0x100;
var SOULIGNE = " underline";
var TRANSPARENT = "transparent";

function oCreerCanvas()
{
	return document.createElement("canvas");
}

function oDCCanvas(oCanvas)
{
	return ((oCanvas==null)||(oCanvas.getContext==null))?null:oCanvas.getContext("2d");
}

var gTabDessin=new Array();
var goDessin=null;
var goDC=null;

var DessinDisponible = (function ()
{
	var ms_bDessinDispo = (function ()
	{
		var oCanvas = oCreerCanvas();
		var bDessinDispo = (null != oDCCanvas(oCanvas));
		delete oCanvas;
		return bDessinDispo;
	})();

	return function ()
	{
		return ms_bDessinDispo;
	};
})();

function RVB(nRouge,nVert,nBleu)
{
	return (nBleu*FACTEUR_BLEU)+(nVert*FACTEUR_VERT)+nRouge;
}

function RVBBleu(nCouleur)
{
	return (nCouleur&0xFF0000)/FACTEUR_BLEU;
}

function RVBVert(nCouleur)
{
	return (nCouleur&0xFF00)/FACTEUR_VERT;
}

function RVBRouge(nCouleur)
{
	return (nCouleur&0xFF);
}

function nWLVersOpacite(nOpacite)
{
	return nOpacite/OPACITE_MAX;
}

function WDDessin(oImg)
{
	this.m_oImg=oImg;
	this.m_oCanvas=oCreerCanvas();
	this.m_oDC=oDCCanvas(this.m_oCanvas);
	this.m_bOpacite=false;
	this.m_nOpaciteFond=OPACITE_MAX;
	this.m_nOpaciteTrait=OPACITE_MAX;
	if(oImg==null)
	{
		return;
	}
	// GP 02/03/2018 : QW296704 : Utilisation de clientXxx et pas de offsetXxx : pour ne pas avoir les bordures et avoir exactement l'image.
	var nLargeur = oImg.clientWidth;
	this.m_oCanvas.width = nLargeur;
	var nHauteur = oImg.clientHeight;
	this.m_oCanvas.height = nHauteur;
	this.m_dAffichageManuel = false;
	this.m_bAffichageAsynchrone = false;
	this.m_fAngle=0;
	try { this.m_oDC.drawImage(oImg, 0, 0, nLargeur, nHauteur); } catch (e) { };

	this.m_oObserver = (function()
	{
		var bAccepteMutations = true;
		function __CallbackMutations(tabMutations/*, oObserverLocal*/)
		{
			// On peut avoir 0 mutation dans le cas de l'appel depuis AffecteSrc
			clWDUtil.WDDebug.assert(tabMutations.length <= 1, "Nombre de mutation inattendu.");
			if (bAccepteMutations)
			{
				// On a un MutationObserver, donc le navigateur doit g�rer le JS r�cent.
				tabMutations.forEach(function(oMutation)
				{
					// On demande � n'avoir que les mutations sur "src"
					clWDUtil.WDDebug.assert("src" == oMutation.attributeName, "Mutation inattendue.");
				
					// On ne filtre que la mutation sur .src et uniquement hors d'une affecation
					if ("src" == oMutation.attributeName)
					{
						// Il y a eu une modification de l'image dans notre dos.
						__FinDessinImage(oMutation.target, false);
					}
				});
			}
		};
		function __AffecteSrc(oImg, sSrc)
		{
			oImg.src = sSrc;
		}

		if (window.MutationObserver)
		{
			var oObserver = new MutationObserver(__CallbackMutations);

			return {
				Connecte: function()
				{
					// Lance l'observation
					oObserver.observe(oImg, { attributes: true, attributeFilter: ["src"] });
				},
				Deconnecte: function()
				{
					// Arret de l'observation
					oObserver.disconnect();
				},
				AffecteSrc: function(oImg, sSrc)
				{
					// Traite les mutations en attente
					this.ForceMutation();
					try
					{
						// Bloque les mutations
						var bAccepteMutationsPrecedent = bAccepteMutations;
						bAccepteMutations = false;
						// Effectue l'affectation
						__AffecteSrc(oImg, sSrc);
						// Traite la mutation plac�e en attente (la mutation que l'on vient d'introduire (si oImg est le m�me oImg que le param�tre parent)).
						this.ForceMutation();
					}
					finally
					{
						// D�bloque les mutations
						bAccepteMutations = bAccepteMutationsPrecedent;
					}
				},
				ForceMutation: function ()
				{
					__CallbackMutations(oObserver.takeRecords(), oObserver);
				}
			};
		}
		else
		{
			return {
				Connecte: clWDUtil.m_pfVide,
				Deconnecte: clWDUtil.m_pfVide,
				AffecteSrc: __AffecteSrc,
				ForceMutation: clWDUtil.m_pfVide
			};
		}
	})();
	this.m_oObserver.Connecte();
}

// GP 29/11/2016 : TB100603 : Dessin en "asynchrone" si demand�
WDDessin.prototype.__AfficheCanvas = (function()
{
	function CImageFromBlob(oDessin, oImg)
	{
		this.m_bChargement = false;
		this.m_oCanvasSuivant = null;
		var oThis = this;
		clWDUtil.AttacheDetacheEvent(true, oImg, "load", function()
		{
			// - Lib�re l'URL courante
			URL.revokeObjectURL(oImg.src);
			// - Plus de chargement
			oThis.m_bChargement = false;
			// Et si il y a un nouveau dessin
			if (oThis.m_oCanvasSuivant)
			{
				oThis.__AfficheCanvas(oDessin, oImg, oThis.m_oCanvasSuivant);
				oThis.m_oCanvasSuivant = null;
			}
		});
	};

	CImageFromBlob.prototype.AfficheCanvas = function AfficheCanvas(oDessin, oImg, oCanvas)
	{
		// Si on est en chargement : m�morise le canvas pour l'affichage suivant
		if (this.m_bChargement)
		{
			this.m_oCanvasSuivant = oCanvas;
		}
		else
		{
			this.__AfficheCanvas(oDessin, oImg, oCanvas);
		}
	};
	CImageFromBlob.prototype.__AfficheCanvas = function __AfficheCanvas(oDessin, oImg, oCanvas)
	{
		// Passe en chargement
		this.m_bChargement = true;
		oCanvas.toBlob(function(oBlob)
		{
			oDessin.__AffecteSrc(oImg, URL.createObjectURL(oBlob));
		});
	};

	var ms_oImageFromBlob = {};
	return function(oImg, oCanvas)
	{
		var oImageFromBlob = ms_oImageFromBlob[oImg.id];
		if (!oImageFromBlob)
		{
			// This est un WDDessin
			oImageFromBlob = new CImageFromBlob(this, oImg);
			ms_oImageFromBlob[oImg.id] = oImageFromBlob;
		}
		// This est un WDDessin
		oImageFromBlob.AfficheCanvas(this, oImg, oCanvas);
	};
})();

WDDessin.prototype.__AffecteSrc = function __AffecteSrc(oImg, sSrc)
{
	// GP 15/10/2018 : QW304304 : Si on fait un dFinDessin, lib�re l'observeur ce qui force le dessin.
	// Donc on a le dessin bien d�ssin� et plus d'observeur. On ajoute donc un blindage ici.
	if (this.m_oObserver)
	{
		this.m_oObserver.AffecteSrc(oImg, sSrc);
	}
};

WDDessin.prototype.AfficheImage = function AfficheImage(oImg, bAffichageAsynchrone)
{
	var oCanvas = this.m_oCanvas;
	oImg = oImg || this.m_oImg;
	// GP 29/11/2016 : TB100603 : Dessin en "asynchrone" si demand�
	// Uniquement si on ne force pas le dessin dans un champ pr�cis (dSauveImage ou autre)
	// Et l'image doit avoir un id puisque l'on utilise id pour l'indexation
	if (bAffichageAsynchrone && ("" != oImg.id) && oCanvas.toBlob && window["URL"] && URL.createObjectURL)
	{
		this.__AfficheCanvas(oImg, oCanvas)
	}
	else
	{
		this.__AffecteSrc(oImg, oCanvas.toDataURL());
	}
};

WDDessin.prototype.MajImage = function MajImage(oImg, oCopie, bAffichageAsynchrone)
{
	if (oCopie)
	{
		var h=oDCCanvas(oCopie);
		h.drawImage(this.m_oCanvas,0,0);
		this.Effacer(true);
		this.m_oDC.drawImage(oCopie,0,0);
		delete oCopie;
	}
	if (!this.m_dAffichageManuel)
	{
		this.AfficheImage(oImg, bAffichageAsynchrone);
	}
};

WDDessin.prototype.destructor=function destructor()
{
	delete this.m_oCanvas;
	delete this.m_oDC;
	delete this.m_oObserver;
	delete this;
};

WDDessin.prototype.nLargeur=function nLargeur()
{
	return this.m_oCanvas.width;
};

WDDessin.prototype.nHauteur=function nHauteur()
{
	return this.m_oCanvas.height;
};

WDDessin.prototype.oImage=function oImage()
{
	return this.m_oDC.getImageData(0,0,goDessin.nLargeur(),goDessin.nHauteur());
};

WDDessin.prototype.ModifImage = function ModifImage(oImage, oImgDst, bAffichageAsynchrone)
{
	this.m_oDC.putImageData(oImage,0,0);
	delete oImage;
	this.MajImage(oImgDst, null, bAffichageAsynchrone);
};

WDDessin.prototype.nIndice=function nIndice(nInd)
{
	return nInd*4;
};

WDDessin.prototype.nIndiceXY=function nIndiceXY(nX,nY)
{
	return this.nIndice(nX+(this.nLargeur()*nY));
};

WDDessin.prototype.nIndiceRouge=function nIndiceRouge(nIndice)
{
	return nIndice;
};

WDDessin.prototype.nIndiceVert=function nIndiceVert(nIndice)
{
	return nIndice+1;
};

WDDessin.prototype.nIndiceBleu=function nIndiceBleu(nIndice)
{
	return nIndice+2;
};

WDDessin.prototype.nIndiceOpacite=function nIndiceOpacite(nIndice)
{
	return nIndice+3;
};

WDDessin.prototype.nCouleur=function nCouleur(oImage,nIndice)
{
	var d=oImage.data;
	return RVB(d[this.nIndiceRouge(nIndice)],d[this.nIndiceVert(nIndice)],d[this.nIndiceBleu(nIndice)]);
};
WDDessin.prototype.tabCouleurRVBA = function tabCouleurRVBA(oImage, nIndice)
{
	var d = oImage.data;
	return [d[this.nIndiceRouge(nIndice)], d[this.nIndiceVert(nIndice)], d[this.nIndiceBleu(nIndice)], d[this.nIndiceOpacite(nIndice)]];
};

WDDessin.prototype.nCouleurIndice=function nCouleurIndice(oImage,nIndice)
{
	return this.nCouleur(oImage,this.nIndice(nIndice));
};
WDDessin.prototype.tabCouleurRVBAIndice = function tabCouleurRVBAIndice(oImage, nIndice)
{
	return this.tabCouleurRVBA(oImage, this.nIndice(nIndice));
};

WDDessin.prototype.nCouleurXY=function nCouleurXY(oImage,nX,nY)
{
	return this.nCouleur(oImage,this.nIndiceXY(nX,nY));
};

WDDessin.prototype.nOpacite=function nOpacite(oImage,nIndice)
{
	return oImage.data[this.nIndiceOpacite(nIndice)];
};

WDDessin.prototype.nOpaciteXY=function nOpacite(oImage,nX,nY)
{
	return this.nOpacite(oImage,this.nIndiceXY(nX,nY));
};

WDDessin.prototype.ModifCouleur=function ModifCouleur(oImage,nIndice,nCouleur,nOpacite,bLaisseOpacite)
{
	var d=oImage.data;
	d[this.nIndiceRouge(nIndice)]=RVBRouge(nCouleur);
	d[this.nIndiceVert(nIndice)]=RVBVert(nCouleur);
	d[this.nIndiceBleu(nIndice)]=RVBBleu(nCouleur);
	if((!bLaisseOpacite)&&((nOpacite!=null)||(this.nOpacite(oImage,nIndice)==0)))
	{
		this.ModifOpacite(oImage,nIndice,(nOpacite!=null)?nOpacite:OPACITE_MAX);
	}
};

WDDessin.prototype.ModifCouleurIndice=function ModifCouleurIndice(oImage,nIndice,nCouleur,nOpacite,bLaisseOpacite)
{
	this.ModifCouleur(oImage,this.nIndice(nIndice),nCouleur,nOpacite,bLaisseOpacite);
};

WDDessin.prototype.ModifCouleurXY=function ModifCouleurXY(oImage,nX,nY,nCouleur,nOpacite,bLaisseOpacite)
{
	this.ModifCouleur(oImage,this.nIndiceXY(nX,nY),nCouleur,nOpacite,bLaisseOpacite);
};

WDDessin.prototype.PropageCouleur = function PropageCouleur(oImage, nX, nY, nCouleur, nCouleurStop)
{
	function __AjouteXY (tabTableauXY, nX, nY)
	{
		tabTableauXY.push(nX);
		tabTableauXY.push(nY);
	}

	var tabDejaFait = new Array();
	var tabTableauXY = new Array();
	__AjouteXY(tabTableauXY, nX, nY);
	var l = this.nLargeur();
	var h = this.nHauteur();
	var nCouleurDepart = null;
	// Inutile et faux : fait par l'appelant + nCouleur est une couleur num�rique pas CSS
	//	if(nCouleur==null)
	//	{
	//		nCouleur=this.m_oDC.fillStyle;
	//	}
	while (tabTableauXY.length)
	{
		var nY = tabTableauXY.pop();
		var nX = tabTableauXY.pop();
		var t = this.nIndiceXY(nX, nY);
		if (!tabDejaFait[t])
		{
			if ((nX >= 0) && (nX < l) && (nY >= 0) && (nY < h))
			{
				tabDejaFait[t] = true;
				var c = this.nCouleur(oImage, t);
				if ((nCouleurStop == null) && (nCouleurDepart == null))
				{
					nCouleurDepart = c;
				}
				if ((nCouleurStop != null) ? (c != nCouleurStop) : (c == nCouleurDepart))
				{
					// La couleur du point trait� est diff�rente de la couleur de remplissage, en tenant compte de l'opacit� (la couleur de remplissage a une opacit� maximale) ?
					if ((c != nCouleur) || (this.nOpacite(oImage, t) != OPACITE_MAX))
					{
						// Oui => on modifie la couleur du point trait� avec la couleur de remplissage
						this.ModifCouleur(oImage, t, nCouleur);
					}
					__AjouteXY(tabTableauXY, nX - 1, nY - 1);
					__AjouteXY(tabTableauXY, nX, nY - 1);
					__AjouteXY(tabTableauXY, nX + 1, nY - 1);
					__AjouteXY(tabTableauXY, nX - 1, nY);
					__AjouteXY(tabTableauXY, nX + 1, nY);
					__AjouteXY(tabTableauXY, nX - 1, nY + 1);
					__AjouteXY(tabTableauXY, nX, nY + 1);
					__AjouteXY(tabTableauXY, nX + 1, nY + 1);
				}
			}
		}
	}
};

WDDessin.prototype.ModifOpacite=function ModifOpacite(oImage,nIndice,nOpacite)
{
	oImage.data[this.nIndiceOpacite(nIndice)]=nOpacite;
};

WDDessin.prototype.nNbPixel=function nNbPixel()
{
	return this.m_oCanvas.width*this.m_oCanvas.height;
};

WDDessin.prototype.nFinTexteAffiche=function nLargeurTexteAffiche(sTexte,nDebut,nFin,nX,nY)
{
	var s=sTexte.substring(nDebut,nFin);
	this.m_oDC.textBaseline="top";
	//this.m_oDC.strokeText(s,nX,nY);
	this.m_oDC.fillText(s,nX,nY);
	return nX+this.m_oDC.measureText(s).width;
};

WDDessin.prototype.Texte=function Texte(nX,nY,sTexte,bSouligne)
{
	var s=(((bSouligne===undefined)||(!bSouligne))&&(this.m_oDC.font.indexOf(SOULIGNE)<0));
	var d=0;
	if(sTexte.length===undefined)
	{
		sTexte=sTexte.toString();
	}
	var l=sTexte.length;
	var f=l;
	this.m_oDC.save();
	this.m_oDC.translate(nX,nY);
	nX=nY=0;
	this.m_oDC.rotate(this.m_fAngle);
	while(d<l)
	{

		if(s)
		{
			f=sTexte.indexOf("&",d);
			if(f<0)
			{
				f=l;
			}
		}
		if(f>d)
		{
			nX=this.nFinTexteAffiche(sTexte,d,f,nX,nY);
			d=f+1;
			f=d+1;
		}
		if(d<l)
		{
			this.m_oDC.save();
			//this.m_oDC.font+=SOULIGNE;
			nX=this.nFinTexteAffiche(sTexte,d,f,nX,nY);
			this.m_oDC.restore();
			d=f;
			f=d+1;
		}
	}
	this.m_oDC.restore();
};

WDDessin.prototype.Effacer = function Effacer(bAvecEffacementComplet)
{
	if (this.m_oDC)
	{
		this.m_oDC.clearRect(0, 0, this.nLargeur(), this.nHauteur());
	}
	if (bAvecEffacementComplet)
	{
		// Par s�curit�, pas de dessin en synchrone sur l'effacement (en plus le dessin d'une image vide est super rapide donc on n'a pas besoin d'asynchrone dans ce cas)
		this.MajImage(null, null, false);
	}
};

function sWDComposanteCouleur(n)
{
	var s=n.toString(16);
	return (s.length<2)?("0"+s):s;
}

function sWDCouleurVersChaine(oCouleur)
{
	// Conversion de la couleur en une couleur HTML
	return clWDUtil.WDDinoCouleur.s_oGetDinoCouleur(oCouleur).toString();
}

function nWDCouleurVersEntier(nCouleur)
{
	if (null != nCouleur)
	{
		return clWDUtil.WDDinoCouleur.s_oGetDinoCouleur(nCouleur).toNumber();
	}
	else
	{
		return nCouleur;
	}
}

function nWDIndiceImage(oImg)
{
	var i=0;
	for(i=0;i<gTabDessin.length;i++)
	{
		if((gTabDessin[i]!=null)&&(gTabDessin[i].m_oImg==oImg))
		{
			break;
		}
	}
	return i;
}

function bWDIndiceOK(i)
{
	return i<gTabDessin.length;
}

function bWDTestFlag(nVal,nFlag)
{
	return (nVal&nFlag)==nFlag;
}

function oWDCreateGetDessin(oImg, nOption, bInit)
{
	if (!DessinDisponible())
	{
		return null;
	}

	// GP 02/03/2018 : QW296699 : Force le traitement des mutations.
	// Un appel de dCopieImage fait un dDebutDessin implicite. Si un second appel de dCopieImage est fait apr�s une affectation du champ, le dessin pr�c�dent est invalide.
	// Ceci peut modifier le contenu de gTabDessin (suppression d'�l�ments) <= donc a faire avant la recherche d'indice ou l'allocation.
	for (var i = 0; i < gTabDessin.length; i++)
	{
		if (gTabDessin[i])
		{
			gTabDessin[i].m_oObserver.ForceMutation();
		}
	};
	
	var i = nWDIndiceImage(oImg);
	if (!bWDIndiceOK(i))
	{
		for (i = 0; i < gTabDessin.length; i++)
		{
			if (gTabDessin[i] == null)
			{
				break;
			}
		}
		gTabDessin[i] = new WDDessin(oImg);
		bInit = true;
	}
	var oDessin = gTabDessin[i];

	oDessin.m_bOpacite = bWDTestFlag(nOption, dAvecOpacite);
	oDessin.m_dAffichageManuel = bWDTestFlag(nOption, dAffichageManuel);
	oDessin.m_bAffichageAsynchrone = bWDTestFlag(nOption, nAffichageAsynchrone);
	if (bInit)
	{
		var oDC = oDessin.m_oDC;
		oDC.fillStyle = oDC.strokeStyle = TRANSPARENT;
	}
	if (!bWDTestFlag(nOption, dSansEffacer))
	{
		oDessin.Effacer(true);
	}
	return oDessin;
}

function oWDInitDessin(oImg,nOption,bInit)
{
	var oDessin = oWDCreateGetDessin(oImg, nOption, bInit);
	if (oDessin)
	{
		goDessin = oDessin;
		goDC = oDessin.m_oDC;
		return goDC;
	}
	else
	{
		return null;
	}
}

function dDebutDessin(oImg,nOption)
{
	return oWDInitDessin(oImg,nOption,true);
}

function bWDDessinOK()
{
	return goDC!=null;
}

function WDInitCouleurTrait(nCouleur)
{
	if(nCouleur!=null)
	{
		goDC.strokeStyle=sWDCouleurVersChaine(nCouleur);
	}
}

function WDInitCouleurFond(nCouleur)
{
	if(nCouleur!=null)
	{
		goDC.fillStyle=sWDCouleurVersChaine(nCouleur);
	}
}

function WDInitEpaisseurTrait(nEpaisseur)
{
	if(nEpaisseur!=null)
	{
		goDC.lineWidth=nEpaisseur;
	}
}

function bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond,nEpaisseur)
{
	if(!bWDDessinOK())
	{
		return false;
	}
	goDC.save();
	WDInitCouleurTrait(nCouleurTrait);
	WDInitCouleurFond(nCouleurFond);
	WDInitEpaisseurTrait(nEpaisseur);
	goDC.beginPath();
	goDC.moveTo(nX1,nY1);
	return true;
}

function WDFinTrace(bStroke, bFill)
{
	function __bOperationAvecOpacite(bActive, nOpacite, pfOperation)
	{
		if (bActive)
		{
			var bActiveOpacite = goDessin.m_bOpacite && (nOpacite < OPACITE_MAX);
			if (bActiveOpacite)
			{
				goDC.save();
				goDC.globalAlpha = nWLVersOpacite(nOpacite);
			}

			pfOperation();

			if (bActiveOpacite)
			{
				goDC.restore();
			}
		}
	}

	// On fait le fill en premier sinon le fond masque la moiti� des cadres en cas d'�paisseur.
	__bOperationAvecOpacite(bFill
		, goDessin.m_nOpaciteFond
		, function ()
		{
			goDC.fill();
		});
	__bOperationAvecOpacite(bStroke
		, goDessin.m_nOpaciteTrait
		, function ()
		{
			goDC.stroke();
		});
	goDC.restore();
	goDessin.MajImage(null, null, goDessin.m_bAffichageAsynchrone);
}

function dAffiche()
{
	// L'appel de dAffiche force l'affichage synchrone
	goDessin.AfficheImage(undefined, false);
}

function nWDDistance(nX1,nX2)
{
	return Math.abs(nX2-nX1);
}

// GP 13/01/2016 : TB95977 : Calcul du centre sans passer par le rayon ou autre
function nWDCentre(nX1,nX2)
{
	return (nX1 + nX2) / 2;
}

function nWDAngle(nX1,nY1,nX2,nY2)
{
	return (Math.PI/2)-Math.atan2(nX2-nX1,nY2-nY1);
}

function WDArcEchelle(nX1,nX2,nY1,nY2,nAngle1,nAngle2,bSens,bLien)
{
	// GP 13/01/2016 : TB95977 : Calcul du centre sans passer par le rayon ou autre
	var dCentreX = nWDCentre(nX1, nX2);
	var dCentreY = nWDCentre(nY1, nY2);
	// Calcul des diametres et des rayons selon les deux axes
	var dDiametreX = nWDDistance(nX1, nX2);
	var dDiametreY = nWDDistance(nY1, nY2);
	var dDiametreMin = Math.min(dDiametreX, dDiametreY);
	var dEchelleX = dDiametreX / dDiametreMin;
	var dEchelleY = dDiametreY / dDiametreMin;

	goDC.beginPath();
	if(bLien)
	{
		goDC.moveTo(dCentreX, dCentreY);
	}
	goDC.save();
	goDC.scale(dEchelleX, dEchelleY);
	// dDiametreMin / 2 : rayon (utilise le diametre le plus petit pour correspondre � la valeur d'�chelle la plus petite (qui est 1))
	goDC.arc(dCentreX / dEchelleX, dCentreY / dEchelleY, dDiametreMin / 2, nAngle1, nAngle2, bSens);
	goDC.restore();
}

function WDArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,bLien)
{
	// GP 13/01/2016 : TB95977 : Calcul du centre sans passer par le rayon ou autre
	var dCentreX = nWDCentre(nX1, nX2);
	var dCentreY = nWDCentre(nY1, nY2);
	WDArcEchelle(nX1, nX2, nY1, nY2, nWDAngle(dCentreX, dCentreY, nX3, nY3), nWDAngle(dCentreX, dCentreY, nX4, nY4), true, bLien);
}

function dArc(nX1, nY1, nX2, nY2, nX3, nY3, nX4, nY4, nCouleur, nEpaisseur)
{
	if (!bWDInitTrace(nX1, nY1, nCouleur, null, nEpaisseur))
	{
		return;
	}
	WDArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4);
	WDFinTrace(true, false);
}

function dCercle(nX1,nY1,nX2,nY2,nCouleurFond,nCouleurTrait)
{
	if(!bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond))
	{
		return;
	}
	WDArcEchelle(nX1,nX2,nY1,nY2,0,Math.PI*2,false);
	WDFinTrace(true, true);
}

function dChangeMode(nMode)
{
	var dessinXOR = 7;
//	var dessinNormal = 13;

	if(!bWDDessinOK())
	{
		return;
	}
	goDC.globalCompositeOperation = (nMode == dessinXOR) ? "xor" : "source-over";
}

// GP 02/03/2018 : N'utilise plus que des variables locales (�vite l'appel de __bWDSwapImg/__WDRestaureImg et l'utilisation de goDessin/goDC)
// => Doit progressivement remplacer tous les appels de __bWDSwapImg/__WDRestaureImg.
function __oWDTemporaire(oImg)
{
	return oWDCreateGetDessin(oImg, dSansEffacer + ((bWDDessinOK() && goDessin.m_bOpacite) ? dAvecOpacite : 0), false);
}

// dCopie
function dCopie(oImgSrc, oImgDst, nSrcX_WL, nSrcY_WL, nSrcL_WL, nSrcH_WL, nDstX_WL, nDstY_WL, nDstL_WL, nDstH_WL)
{
	// Rebond vers dCopieImage avec :
	// - Mode de copie sp�cifique : -2
	// - Inverse nSrcL_WL avec nSrcH_WL et nDstL_WL et nDstH_WL car dCopieImage prend ces param�tres dans un autre sens.
	dCopieImage(oImgSrc, oImgDst, -2, nSrcX_WL, nSrcY_WL, nSrcH_WL, nSrcL_WL, nDstX_WL, nDstY_WL, nDstH_WL, nDstL_WL);
}

// dCopieImage : attention en WL, la hauteur est avant la largeur pour cette fonction.
function dCopieImage(oImgSrc, oImgDst, nMode, nSrcX_WL, nSrcY_WL, nSrcH_WL, nSrcL_WL, nDstX_WL, nDstY_WL, nDstH_WL, nDstL_WL)
{
	// GP 23/02/2018 : QW296661 : tout est modifi� en F+1 (�tait tout faux avant).

	// Code pour une op�ration de copie simple
	function __CopieSimple(oDC, sGlobalCompositeOperation)
	{
		oDC.save();
		// Clip la zone : important (en particulier pour "copy" qui sinon efface tout)
		oDC.beginPath();
		oDC.rect(nDstX, nDstY, nDstL, nDstH);
		oDC.clip();
		// Donne l'op�ration
		oDC.globalCompositeOperation = sGlobalCompositeOperation;
		// Et effectue la copie
		oDC.drawImage(oImgSrc, nSrcX, nSrcY, nSrcL, nSrcH, nDstX, nDstY, nDstL, nDstH);
		oDC.restore();
	}
	// Code pour une op�ration de copie qui effectue un remplissage uniforme
	function __CopieRemplissage(oDC, sCouleur)
	{
		oDC.save();
		oDC.fillStyle = sCouleur;
		oDC.fillRect(nDstX, nDstY, nDstL, nDstH);
		oDC.restore();
	}
	// Code pour une op�ration qui inverse la destination
	function __CopieInverse (oDC)
	{
		var oImageData = oDC.getImageData(nDstX, nDstY, nDstL, nDstH);
		var nNbPixels = oImageData.width * oImageData.width;
		// N'utilise pas ModifCouleurIndice/nCouleurIndice : fait un algo optimis�
		var oData = oImageData.data;
		for (var nPixel = 0; nPixel < nNbPixels; nPixel++)
		{
			var nIndice = nPixel * 4;
			var nCouleur;
			// Si le pixel est transparent, le code serveur consid�re que le pixel est blanc et l'inversion donne un pixel noir.
			if (0 == oData[nIndice + 3])
			{
				nCouleur = 0;
			}
			else
			{
				nCouleur = ~RVB(oData[nIndice], oData[nIndice + 1], oData[nIndice + 2]);
			}
			oData[nIndice] = RVBRouge(nCouleur);
			oData[nIndice + 1] = RVBVert(nCouleur);
			oData[nIndice + 2] = RVBBleu(nCouleur);
			oImageData.data[nIndice + 3] = OPACITE_MAX;
		}
		oDC.putImageData(oImageData, nDstX, nDstY);
	}

	function __nParamCoord (nVal)
	{
		return isNaN(nVal) ? 0 : nVal;
	}
	function __nParamLargeur (oImg, nVal)
	{
		// GP 01/03/2018 : QW296700 : Utilisation de clientXxx et pas de offsetXxx : pour ne pas avoir les bordures et avoir exactement l'image.
		// Et on ne peut pas (selon les navigateurs) cibl� plus que l'image.
		var nLargueurDisponible = oImg.clientWidth;
		return isNaN(nVal) ? nLargueurDisponible : Math.min(nVal, nLargueurDisponible);
	}
	function __nParamHauteur (oImg, nVal)
	{
		// GP 01/03/2018 : QW296700 : Utilisation de clientXxx et pas de offsetXxx : pour ne pas avoir les bordures et avoir exactement l'image.
		var nHauteurDisponible = oImg.clientHeight;
		return isNaN(nVal) ? nHauteurDisponible : Math.min(nVal, nHauteurDisponible);
	}

	// GP 02/03/2018 : N'utilise plus que des variables locales (�vite l'appel de __bWDSwapImg/__WDRestaureImg et l'utilisation de goDessin/goDC)
	var oDessin = __oWDTemporaire(oImgDst);
	if (!oDessin)
	{
		return;
	}
	var oDC = oDessin.m_oDC;

	// Pr�pare les coordonn�es
	var nSrcX = __nParamCoord(nSrcX_WL);
	var nSrcY = __nParamCoord(nSrcY_WL);
	var nSrcL = __nParamLargeur(oImgSrc, nSrcL_WL);
	var nSrcH = __nParamHauteur(oImgSrc, nSrcH_WL);
	var nDstX = __nParamCoord(nDstX_WL);
	var nDstY = __nParamCoord(nDstY_WL);
	var nDstL = __nParamLargeur(oImgDst, nDstL_WL);
	var nDstH = __nParamHauteur(oImgDst, nDstH_WL);

	// Selon l'op�ration demand�e
	switch (nMode)
	{
	case -2: // Pour dCopie
		// En WINDEV, le comportement est entre celui de copieImage et celui de copieSrcCopie.
		// => Il est comme copieImage car il conserve la transparence de la source
		// => Il est comment copieSrcCopie car il prend le fond du champ.
		// On fait un copieImage sans restrictions
		// => Copie l'image source au dessus de la destination. La ou l'image source est transparente, on peut voir l'image destination.
		__CopieSimple(oDC, "source-over");
		break;
	case -1: // copieImage
		// GP 01/03/2018 : QW296703 : Dans le cas "copieImage" : ignore la taille de la destination (= pas d'agrandissement)
		nDstL = Math.min(nSrcL, nDstL);
		nDstH = Math.min(nSrcH, nDstH);
		// Copie l'image source au dessus de la destination. La ou l'image source est transparente, on peut voir l'image destination.
		__CopieSimple(oDC, "source-over");
		break;
	case 0:		// copieToutNoir
		// Remplissage de la zone destination avec du noir (ignore le contenu de la source et de la destination)
		__CopieRemplissage(oDC, "#000");
		break;
	case 1:		// copieDstInverse
		// Inverse la zone destination (ignore le contenu de la source)
		__CopieInverse(oDC);
		break;
//	case 2:		// copieFusionCopie
//		break;
//	case 3:		// copieFusionPeint
//		break;
	case 4:		// copiePasSrcCopie
		// Inverse la source et remplace la destination (ignore le contenu de la destination). Impl�ment� comme une copie de la source puis une inversion du rectangle de destination.
		__CopieSimple(oDC, "copy");
		__CopieInverse(oDC);
		break;
//	case 5:		// copiePasSrcEfface
//		break;
//	case 6:		// copiePatCopie
//		break;
//	case 7:		// copiePatInverse
//		break;
//	case 8:		// copiePatPeint
//		break;
//	case 9:		// copieSrcEt
//		break;
	default:
	case 10:	// copieSrcCopie
		// Remplace la destination (ignore le contenu de la destination).
		__CopieSimple(oDC, "copy");
		break;
//	case 11:	// copieSrcEfface
//		break;
	case 12:	// copieSrcInverse
		// Il semble que l'op�ration �quivalente est xor + inverse
		__CopieSimple(oDC, "xor");
		__CopieInverse(oDC);
		break;
//	case 13:	// copieSrcPeint
//		break;
	case 14:	// copieToutBlanc
		// Remplissage de la zone destination avec du blanc.
		__CopieRemplissage(oDC, "#fff");
		break;
	}

	oDessin.MajImage(null, null, oDessin.m_bAffichageAsynchrone);
}

function WDTrait(nX1,nY1,nX2,nY2)
{
	goDC.moveTo(nX1,nY1);
	goDC.lineTo(nX2,nY2);
}

function dCorde(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,nCouleurFond,nCouleurTrait)
{
	if(!bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond))
	{
		return;
	}
	WDArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4);
	goDC.closePath();
	WDFinTrace(true, true);
}

function WDDetruit(i, bAvecEffacementComplet)
{
	if(gTabDessin[i]==null)
	{
		return;
	}
	gTabDessin[i].Effacer(bAvecEffacementComplet);
	gTabDessin[i].m_oObserver.Deconnecte();
	gTabDessin[i].destructor();
	gTabDessin[i]=null;
}

function dFinDessin(oImg)
{
	if (oImg)
	{
		__FinDessinImage(oImg, true)
	}
	else
	{
		for (var i = 0; i < gTabDessin.length; i++)
		{
			WDDetruit(i, true);
		}
	}
}

function __FinDessinImage(oImg, bAvecEffacementComplet)
{
	var nIndice = nWDIndiceImage(oImg);
	if (bWDIndiceOK(nIndice))
	{
		WDDetruit(nIndice, bAvecEffacementComplet);
	}
}

function dFond(nCouleur,nStyle,nHachure,nOpacite)
{
	if(!bWDDessinOK())
	{
		return;
	}
	WDInitCouleurFond((nStyle==1)?TRANSPARENT:nCouleur);
	if(nOpacite!=null)
	{
		goDessin.m_nOpaciteFond=nOpacite;
	}
}

function dInverseCouleur(oImage)
{
	return __oSwapActionRestaure(oImage, function ()
	{
		var d = goDessin.oImage();
		for (var i = 0; i < goDessin.nNbPixel(); i++)
		{
			goDessin.ModifCouleurIndice(d, i, ~goDessin.nCouleurIndice(d, i));
		}
		goDessin.ModifImage(d, oImage, goDessin.m_bAffichageAsynchrone);
		return true;
	});
}

function dLigne(nX1,nY1,nX2,nY2,nCouleur,nEpaisseur)
{
	if(!bWDInitTrace(nX1,nY1,nCouleur,null,nEpaisseur))
	{
		return;
	}
	goDC.lineTo(nX2,nY2);
	WDFinTrace(true, true);
}

function dModifieTSL(oImage, nTeinte, nSaturation, nLuminosite, oImgDst)
{
	return __oSwapActionRestaure(oImage, function ()
	{
		// En WL il y a une validation des nombres par un modulo (= si nSaturation => 102 => 2 etc)
		// - Pas besoin de valider la teinte, le % 360 lors du calcul va faire ce qu'il faut
		nSaturation = Math.max(-100, Math.min(100, nSaturation));
		nLuminosite = Math.max(-100, Math.min(100, nLuminosite));
		var nLuminosite255 = Math.max(-255, Math.min(255, nLuminosite * 255 / 100));

		var oDessinDestination = goDessin;
		if (oImgDst && (oImage != oImgDst))
		{
			oDessinDestination = oWDCreateGetDessin(oImgDst, 0);
		}

		var oImageSource = goDessin.oImage();
		var oImageCible = oDessinDestination.oImage();

		var tabRVBA;
		var tabTSLA;
		for (var i = 0; i < goDessin.nNbPixel(); i++)
		{
			// Trouve la couleur du point
			tabRVBA = goDessin.tabCouleurRVBAIndice(oImageSource, i);;
			tabTSLA = clWDUtil.tabRVBA2TSLA(tabRVBA);

			// On n'incr�mente pas la luminosit� ici, cela donne des distorsions. On calcule d'abord la nouvelle couleur avec la teinte et la saturation, et ensuite on ajoute la luminosit�
			tabTSLA[0] = (tabTSLA[0] + nTeinte) % 360;
			tabTSLA[1] = Math.max(0, Math.min(1, tabTSLA[1] + nSaturation / 100));

			// Conversion TSL => RVB (toujours sans toucher � la luminosit�)
			clWDUtil.TSLA2RVBA(tabTSLA, tabRVBA);

			// Luminosit� modifi�e ?
			if (nLuminosite != 0)
			{
				//Oui => modification composantes couleur RGB en fonction de la luminosit�
				for (var nIndiceCouleur = 0; nIndiceCouleur < 3; nIndiceCouleur++)
				{
					//Composante couleur RGB modifi�e en fonction de la luminosit�
					tabRVBA[nIndiceCouleur] = Math.max(0, Math.min(255, Math.floor(tabRVBA[nIndiceCouleur] + nLuminosite255)));
				}
			}

			// true : Conserve la transparence pr�c�dente.
			goDessin.ModifCouleurIndice(oImageCible, i, clWDUtil.nRVBA2Int(tabRVBA), tabRVBA[3], false);
		}
		oDessinDestination.ModifImage(oImageCible, oImgDst, oDessinDestination.m_bAffichageAsynchrone);
		return true;
	});
}

function dModifieLuminosite(oImg,nLuminosite,oImgDst)
{
	return dModifieTSL(oImg,0,0,nLuminosite,oImgDst);
}

function dModifieSaturation(oImg,nSaturation,oImgDst)
{
	return dModifieTSL(oImg,0,nSaturation,0,oImgDst);
}

function dModifieTeinte(oImg,nTeinte,oImgDst)
{
	return dModifieTSL(oImg,nTeinte,0,0,oImgDst);
}

function dPixelCouleur(oImage, nX, nY)
{
	return __dPixel(oImage, nX, nY, function (oImageSource, nX, nY)
	{
		return clWDUtil.WDDinoCouleur.s_oGetDinoCouleur(goDessin.nCouleurXY(oImageSource, nX, nY));
	});
}

function dPixelOpacite(oImage, nX, nY)
{
	return __dPixel(oImage, nX, nY, function (oImageSource, nX, nY)
	{
		return goDessin.nOpaciteXY(oImageSource, nX, nY);
	});
}

function __dPixel(oImage, nX, nY, pfAction)
{
	function __Action()
	{
		nX = Math.round(nX);
		nY = Math.round(nY);

		if (bWDDessinOK() && (nX >= 0) && (nY >= 0) && (nX < goDessin.nLargeur()) && (nY < goDessin.nHauteur()))
		{
			var oImageSource = goDessin.oImage();
			var sResultat = pfAction(oImageSource, nX, nY);
			delete oImageSource;
			return sResultat;
		}
		else
		{
			return 0;
		}
	};

	if (oImage)
	{
		return __oSwapActionRestaure(oImage, __Action);
	}
	else
	{
		return __Action();
	}
};

function dPoint(nX,nY,nCouleur/*,nOpacite*/)
{
	nX = Math.round(nX);
	nY = Math.round(nY);

	if(!bWDDessinOK())
	{
		return;
	}
	var d=goDessin.oImage();
	goDessin.ModifCouleurXY(d,nX,nY,nWDCouleurVersEntier((nCouleur!=null)?nCouleur:goDC.strokeStyle));
	goDessin.ModifImage(d, null, goDessin.m_bAffichageAsynchrone);
}

function dPolice(sPolice,nTaille,nAttrib,nAngle)
{
//	var iNormal = 1;
//	var iSouligne = 2;
	var iItalique = 4;
	var iGras = 8;
//	var iBarre = 16;

	function __AjoutAttributPolice(bAjout, sAttribut)
	{
		if (bAjout)
		{
			tabAttributPolice.push(sAttribut);
		}
	}


	if(!bWDDessinOK())
	{
		return;
	}
	var tabAttributPolice = [];
	__AjoutAttributPolice(bWDTestFlag(nAttrib, iItalique), "italic");
	__AjoutAttributPolice(bWDTestFlag(nAttrib, iGras), "bold");
//	__AjoutAttributPolice(bWDTestFlag(nAttrib, iBarre), "stroke");
//	__AjoutAttributPolice(bWDTestFlag(nAttrib, iSouligne), SOULIGNE);
	__AjoutAttributPolice(null != nTaille, String(nTaille) + "pt");
	__AjoutAttributPolice(null != sPolice, sPolice);
	goDC.font = tabAttributPolice.join(" ");
	goDessin.m_fAngle = -fWDDegreVersRadian(nAngle);
}

function dPolygone()
{
	if(arguments.length<1)
	{
		return;
	}
	var b=arguments.length<4;
	if(b&&(arguments[0].length<4))
	{
		return;
	}
	var t=b?arguments[0]:arguments;
	var n=b?(t.length/2):t[0];
	var c=(2*n)+1;
	if((b&&(!bWDInitTrace(t[0],t[1],arguments[2],arguments[1])))||((!b)&&((t.length<5)||(!bWDInitTrace(t[1],t[2],t[c+1],t[c])))))
	{
		return;
	}
	var d=b?0:1;
	for(var i=d;i<2*n;i+=2)
	{
		goDC.lineTo(t[i],t[i+1]);
	}
	goDC.closePath();
	WDFinTrace(true, true);
}

function dPortion(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,nCouleurFond,nCouleurTrait)
{
	if(!bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond))
	{
		return;
	}
	WDArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,true);
	goDC.closePath();
	WDFinTrace(true, true);
}

function dRectangle(nX1,nY1,nX2,nY2,nCouleurFond,nCouleurTrait)
{
	if(!bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond))
	{
		return;
	}
	goDC.rect(Math.min(nX1,nX2),Math.min(nY1,nY2),nWDDistance(nX1,nX2),nWDDistance(nY1,nY2));
	WDFinTrace(true, true);
}

function WDAjoutCouleurDegrade(oDegrade,nCouleur,nDistance)
{
	if(nCouleur!=null)
	{
		oDegrade.addColorStop(nDistance/100,sWDCouleurVersChaine(nCouleur));
	}
}

function fWDDegreVersRadian(nAngle)
{
	return nAngle*(Math.PI/180)
}

function dRectangleDegrade(nX1,nY1,nX2,nY2,nCouleurDebut,nCouleurFin,nAngle,nCouleur3,nDistance3,nCouleur4,nDistance4)
{
	if(!bWDInitTrace(nX1,nY1))
	{
		return;
	}
	var a=fWDDegreVersRadian(nAngle%360);
	var q=(a==(Math.PI/2))||(a==((3*Math.PI)/2));
	var c=q?0:Math.tan(a);
	var p=(a==0)||(a==Math.PI);
	var e=p?0:Math.tan(a+(Math.PI/2));
	var g=nX1;
	var f=nX2;
	if((a>(Math.PI/2))&&(a<=((3*Math.PI)/2)))
	{
		g=nX2;
		f=nX1;
	}
	var h=nY1;
	var b=nY2;
	if(a>Math.PI)
	{
		h=nY2;
		b=nY1;
	}
	var x=p?f:(q?g:(((c*g)-(e*f)+b-h)/(c-e)));
	var d=goDC.createLinearGradient(g,h,x,(c*(x-g))+(q?b:h));
	WDAjoutCouleurDegrade(d,nCouleurDebut,0);
	WDAjoutCouleurDegrade(d,nCouleurFin,100);
	WDAjoutCouleurDegrade(d,nCouleur3,nDistance3);
	WDAjoutCouleurDegrade(d,nCouleur4,nDistance4);
	goDC.fillStyle=d;
	goDC.rect(Math.min(nX1,nX2),Math.min(nY1,nY2),nWDDistance(nX1,nX2),nWDDistance(nY1,nY2));
	WDFinTrace(false, true);
}

function oWDCanvaCopie()
{
	var o=oCreerCanvas();
	o.width=goDessin.nLargeur();
	o.height=goDessin.nHauteur();
	return o;
}

function dRedimensionne(oImage, nLargeur, nHauteur)
{
	return __bSwapCopieActionRestaure(oImage, function (oDCCanvas)
	{
		oDCCanvas.scale(nLargeur / goDessin.nLargeur(), nHauteur / goDessin.nHauteur());
	});
}

function dRemplissage(nX,nY,nCouleur,nCouleurStop)
{
	nX = Math.round(nX);
	nY = Math.round(nY);

	if(!bWDDessinOK())
	{
		return;
	}
	var d=goDessin.oImage();
	goDessin.PropageCouleur(d, nX, nY, nWDCouleurVersEntier((nCouleur != null) ? nCouleur : goDC.fillStyle), nWDCouleurVersEntier(nCouleurStop));
	goDessin.ModifImage(d, null, goDessin.m_bAffichageAsynchrone);
}

function dRotation(oImage,nAngle)
{
	return __bSwapCopieActionRestaure(oImage, function (oDCCanvas)
	{
		var a = fWDDegreVersRadian(nAngle);
		var l = goDessin.nLargeur() / 2;
		var h = goDessin.nHauteur() / 2;
		var b = Math.atan(l / h);
		var c = b - a;
		var r = h / Math.cos(b);
		oDCCanvas.translate(l - (r * Math.sin(c)), h - (r * Math.cos(c)));
		oDCCanvas.rotate(a);
	});
}

function __bStrokeStyleTransparent()
{
	var tabRVBA = (new clWDUtil.WDDinoCouleur(goDC.strokeStyle)).m_tabRVBA;
	return (0 === tabRVBA[0]) && (0 === tabRVBA[1]) && (0 === tabRVBA[2]) && (0 === tabRVBA[3]);
}

function dTexte(nX,nY,sTexte,nCouleur,bSouligne)
{
	if(nCouleur==null)
	{
		nCouleur = __bStrokeStyleTransparent() ? 0 : goDC.strokeStyle;
	}
	if(!bWDInitTrace(nX,nY,nCouleur,nCouleur))
	{
		return;
	}
	goDessin.Texte(nX,nY,sTexte,bSouligne);
	WDFinTrace(true, true);
}

function dSauveImage(oImage, sMem, nNbCouleur, sFormat/*,nQualite*/)
{
	return __oSwapActionRestaure(oImage, function ()
	{
		try
		{
			return goDessin.m_oCanvas.toDataURL("image/" + sFormat.toLowerCase());
		}
		catch (e)
		{
			return "";
		};
	});
}

function dSauveImageBMP(oImg,sMem,nNbCouleur)
{
	return dSauveImage(oImg,sMem,nNbCouleur,"bmp");
}

function dSauveImageGIF(oImg,sMem,nNbCouleur)
{
	return dSauveImage(oImg,sMem,nNbCouleur,"gif");
}

function dSauveImageJPEG(oImg,sMem,nQualite/*,nMarqueur*/)
{
	return dSauveImage(oImg,sMem,null,"jpeg",((nQualite==null)?80:nQualite)/100);
}

function dSauveImagePNG(oImg,sMem/*,nCouleurTransparence*/)
{
	return dSauveImage(oImg,sMem,null,"png");
}

function dStylo(nCouleur,nStyle,nEpaisseur,nOpacite)
{
	if(!bWDDessinOK())
	{
		return;
	}
	WDInitCouleurTrait((nStyle==5)?TRANSPARENT:nCouleur);
	WDInitEpaisseurTrait(nEpaisseur);
	if(nOpacite!=null)
	{
		goDessin.m_nOpaciteTrait=nOpacite;
	}
}

function dSymetrieHorizontale(oImage)
{
	return __bSwapCopieActionRestaure(oImage, function (oDCCanvas)
	{
		oDCCanvas.transform(1, 0, 0, -1, 0, goDessin.nHauteur());
	});
}

function dSymetrieVerticale(oImage)
{
	return __bSwapCopieActionRestaure(oImage, function (oDCCanvas)
	{
		oDCCanvas.transform(-1, 0, 0, 1, goDessin.nLargeur(), 0);
	});
}

// Code commun au diverses op�rations (factorisation de code)
function __oSwapActionRestaure(oImage, pfAction)
{
	var oDessinSauv = null;

	function __bWDSwapImg(oImage)
	{
		if (!DessinDisponible())
		{
			return false;
		}
		oDessinSauv = goDessin;
		oWDInitDessin(oImage, dSansEffacer + ((bWDDessinOK() && goDessin.m_bOpacite) ? dAvecOpacite : 0));
		return bWDDessinOK();
	}
	function __WDRestaureImg()
	{
		if (oDessinSauv)
		{
			goDessin = oDessinSauv;
			goDC = goDessin.m_oDC;
		}
	}

	if (__bWDSwapImg(oImage))
	{
		var oResultat = pfAction();
		__WDRestaureImg();
		return oResultat;
	}
	else
	{
		return false;
	}
}
function __bSwapCopieActionRestaure(oImage, pfAction)
{
	return __oSwapActionRestaure(oImage, function ()
	{
		// Cr�ation d'un canvas avec le contenu du dessin
		var oCanvaCopie = oWDCanvaCopie();
		// Effectue l'action
		pfAction(oDCCanvas(oCanvaCopie));
		// MAJ du dessin
		goDessin.MajImage(null, oCanvaCopie, goDessin.m_bAffichageAsynchrone);
		return true;
	});
}

function InfoBitmap (sImage)
{
	var sBAD = "BAD";
	// Par d�faut r�sultat vide.
	var sResultat = sBAD + "\t\t\t";

	// Un test de bool�en sur une chaine teste le cas null et le cas vide (!!"" = false).
	if (sImage)
	{
		var oImage = new Image();
		oImage.src = sImage;
		var nPositionPoint = sImage.lastIndexOf(".");
		var sResultat;
		if ((0 < oImage.width) && (0 < oImage.height))
		{
			sResultat = ((Math.max(sImage.lastIndexOf("\\"), sImage.lastIndexOf("/")) < nPositionPoint) ? sImage.substr(nPositionPoint + 1) : sBAD) +
						"\t" + oImage.width +
						"\t" + oImage.height +
						"\t0";
		}
		// Sinon laisse sResultat avec le r�sultat vide;

		delete oImage;
	}
	// Sinon laisse sResultat avec le r�sultat vide;
	return sResultat;
}

// Fonction WL dPolyligne()
function dPolyligne()
{
	if (arguments.length < 1)
	{
		return;
	}

	var tabPoint;	
	var nNbPoint = 0;
	var nOffsetPoint = 0;
	var nIndiceCouleur = 0;

	// il faut d�terminer la syntaxe
	// le premier param�tre est soit un tableau de points
	// soit un entier avec le nombre de points

	// syntaxe avec le nombre de points puis les points
	// dPolyligne(<NbPoint> , <X1> , <Y1> , <X2> , <Y2> [, <Xn> [, <Yn> [, <Couleur du trait>]]])
	if (arguments[0].length === undefined)
	{
		tabPoint = arguments;
		nNbPoint = arguments[0];
		nOffsetPoint = 1;
		nIndiceCouleur = 1 + nNbPoint * 2;
	}
	// syntaxe avec tableau de points
	// dPolyligne(<Tableau de coordonn�es> [, <Couleur du trait>])
	else
	{
		tabPoint = arguments[0];
		nNbPoint = arguments[0].length / 2;
		nIndiceCouleur = 1;
	}

	// couleur du trait
	var nCouleur = undefined;
	if (arguments[nIndiceCouleur] !== undefined && typeof arguments[nIndiceCouleur] === "number")
	{
		nCouleur = arguments[nIndiceCouleur];
	}

	// d�but du trac�
	if (!bWDInitTrace(tabPoint[nOffsetPoint], tabPoint[nOffsetPoint + 1], nCouleur))
	{
		return;
	}

	// dessin les lignes
	var nIndicePoint;
	for (var i = 1; i < nNbPoint; i++)
	{
		nIndicePoint = (i * 2) + nOffsetPoint;
		goDC.lineTo(tabPoint[nIndicePoint], tabPoint[nIndicePoint + 1]);
	}
	// QW325347 : Il ne faut pas fermer la forme et ne pas faire le remplissage.
//	goDC.closePath();
//	WDFinTrace(true, true);
	WDFinTrace(true, false);
}

// Fonction WL dRectangleArrondi : elle est dans le framework V2.
// function __dRectangleArrondi (oCadreContenu: NSTypes.STRectangle, oStyleCadreContenu: NSTypes.STCadreContenu | undefined, oStyleFondContenuOuUndefined: NSTypes.STFondContenu | undefined): void
// NSTypes.STRectangle = { m_dX: number; m_dY: number; m_dLargeur: number; m_dHauteur: number; }
// NSTypes.STCadreContenu = { m_nBords: number; m_tabCoins: NSTypes.STCoins; m_tabTraits: NSTypes.STTraits; }
// NSTypes.STCoins = [ NSTypes.STCoinContenu, NSTypes.STCoinContenu, NSTypes.STCoinContenu, NSTypes.STCoinContenu ];
// NSTypes.STCoinContenu = { m_dLargeur: number; m_dHauteur: number; }
// NSTypes.STTraits = [ NSTypes.STTraitContenu, NSTypes.STTraitContenu, NSTypes.STTraitContenu, NSTypes.STTraitContenu ];
// NSTypes.STTraitContenu = { m_eType: ETraitType; m_dEpaisseur: number; m_oCouleur: STCouleurContenu; };
// NSTypes.STFondContenu = { m_eType: ETypeFond; m_oCouleur: STCouleurContenu; m_eHachure: ETypeHachures; m_oDegrade: STD�grad�Contenu; };
function __dRectangleArrondi(oCadreContenu, oStyleCadreContenuOuUndefined, oStyleFondContenuOuUndefined)
{
	function __DinoTrait (oTrait)
	{
		// Couleur.
		WDInitCouleurTrait(oTrait.m_oCouleur);

		// Epaisseur
		WDInitEpaisseurTrait(oTrait.m_dEpaisseur);

		// Style.
		switch (oTrait.m_eType)
		{
//		default:
//		case -1:	// Ind�fini
//		case 1:		// Continu
//			// Ne change rien
//			break;
		case 0:		// Aucun
			goDC.setLineDash([0, 10]);
			break;
		case 2:		// Tiret
			goDC.setLineDash([8, 4]);
			break;
		case 3:		// Pointille
			// GP 04/05/2020 : QW325254 : D�s que l'�paisseur est sup�rieure � 1, le code serveur fait un dessin par CPatternTraitPRN. Imite ce dessin.
			goDC.setLineDash((oTrait.m_dEpaisseur <= 1) ? [1, 1] : [oTrait.m_dEpaisseur, oTrait.m_dEpaisseur * 3]);
			break;
		case 4:		// Mixte
			goDC.setLineDash([8, 4, 2, 4]);
			break;
		}
	}
	function __DinoFond(oFond, dXGauche, dYHaut, dXDroite, dYBas)
	{
//		function __oGetStyleHachure(eHachure)
//		{
//			return xxx;
//		}
		function __oGetStyleDegrade(oDegrade, dXGauche, dYHaut, dXDroite, dYBas)
		{
			// Pr�pare l'angle en degr�s :
			// - Le place dans ]-360, 360[
			var dAngleDegrees = oDegrade.m_nAngle % 360;
			// - Le ram�ne dans [0, 360[
			if (dAngleDegrees < 0)
			{
				dAngleDegrees += 360;
			}

			// Pour le calcul des facteurs, on ram�ne l'angle initial dans [-45, 45[.
			var dAngleDegreesAutour0 = dAngleDegrees;
			while (45 <= dAngleDegreesAutour0)
			{
				dAngleDegreesAutour0 -= 90;
			}
			// Et on calcule sa tan (sera le facteur commun dans les calculs).
			var dTanAutour0 = Math.tan(dAngleDegreesAutour0 * Math.PI / 180);

			// Et ensuite le calcul sera de la forme :
			// <valeur> = <centre> +/- <coefficient> * <demi dimension>.
			var dCoefficentX;
			var dCoefficentY;

			if ((dAngleDegrees <= 45) || (315 < dAngleDegrees))
			{
				// De gauche � droite et Y varie.
				dCoefficentX = 1;
				dCoefficentY = dTanAutour0;
			}
			else if ((45 < dAngleDegrees) && (dAngleDegrees <= 135))
			{
				// De haut en bas et X varie.
				dCoefficentX = -dTanAutour0;
				dCoefficentY = 1;
			}
			else if ((135 < dAngleDegrees) && (dAngleDegrees < 225))
			{
				// De droite � gauche et Y varie.
				dCoefficentX = -1;
				dCoefficentY = -dTanAutour0;
			}
			else if ((225 < dAngleDegrees) && (dAngleDegrees <= 315))
			{
				// De bas en haut et X varie.
				dCoefficentX = dTanAutour0;
				dCoefficentY = -1;
			}

			var dXCentre = (dXGauche + dXDroite) / 2;
			var dYCentre = (dYHaut + dYBas) / 2;
			var dDemiLargeur = (dXDroite - dXGauche) / 2;
			var dDemiHauteur = (dYBas - dYHaut) / 2;
			// Math.hypot est Math.sqrt(v1 ^ 2, v2 ^ 2, ..., vn ^ 2) => Plus rapide et plus pr�cis (avec les tr�s grand et tr�s petit nombres).
			//var dRayon = Math.hypot(dXCentre - dXGauche, dYCentre - dYHaut);
			var dXDebut = dXCentre - dCoefficentX * dDemiLargeur;
			var dYDebut = dYCentre - dCoefficentY * dDemiHauteur;
			var dXFin = dXCentre + dCoefficentX * dDemiLargeur;
			var dYFin = dYCentre + dCoefficentY * dDemiHauteur;

			var oGradient = goDC.createLinearGradient(dXDebut, dYDebut, dXFin, dYFin);
			oGradient.addColorStop(0, oDegrade.m_oCouleurDebut);
			oGradient.addColorStop(1, oDegrade.m_oCouleurFin);
			if (0 !== oDegrade.m_nDistanceCouleur3)
			{
				oGradient.addColorStop(oDegrade.m_nDistanceCouleur3 / 100, oDegrade.m_oCouleur3);
			}
			if (0 !== oDegrade.m_nDistanceCouleur4)
			{
				oGradient.addColorStop(oDegrade.m_nDistanceCouleur4 / 100, oDegrade.m_oCouleur);
			}
			return oGradient;
		}

		// Selon le type.
		switch (oFond.m_eType)
		{
		case 2:		// Hachure
			// Non g�r�.
		case 0:		// Plein
			WDInitCouleurFond(oFond.m_oCouleur);
			break;
		case 1:		// Transparent
			goDC.fillStyle = "transparent";
			break;
//		case 2:		// Hachure
//			goDC.fillStyle = __oGetStyleHachure(oFond.m_eHachure);
//			break;
		case 3:		// Degrade
			goDC.fillStyle = __oGetStyleDegrade(oFond.m_oDegrade, dXGauche, dYHaut, dXDroite, dYBas);
			break;
		}
	}

	function __dGetLargeurCoin(nCoin)
	{
		return oStyleCadreContenuOuUndefined ? oStyleCadreContenuOuUndefined.m_tabCoins[nCoin].m_dLargeur : 0;
	}
	function __dGetHauteurCoin(nCoin)
	{
		return oStyleCadreContenuOuUndefined ? oStyleCadreContenuOuUndefined.m_tabCoins[nCoin].m_dHauteur : 0;
	}
	function __bBordDessine(nFlag)
	{
		return oStyleCadreContenuOuUndefined ? (nFlag === (oStyleCadreContenuOuUndefined.m_nBords & nFlag)) : true;
	}

	function __CoteEtCoinSimple (oCoin/*, nNumeroCoteEtCoin*/)
	{
		goDC.lineTo(oCoin.oD.dX, oCoin.oD.dY);
		goDC.quadraticCurveTo(oCoin.oC.dX, oCoin.oC.dY, oCoin.oF.dX, oCoin.oF.dY);
	}

	function __Dessin(__pfStyleInitial, __pfDessineUnCoteEtUnCoin, bStroke, bFill)
	{
		// D�but du trac� : commence au dernier point.
		if (!bWDInitTrace(tabCoins[3].oF.dX
			, tabCoins[3].oF.dY
			, null
			, null
			, null))
		{
			return;
		}

		// Pr�pare le style initial.
		__pfStyleInitial();

		// Dessin des cot�s et des coins.
		tabCoins.forEach(__pfDessineUnCoteEtUnCoin);

		// Fin du dessin : demande le cadre et/ou le fond.
		goDC.closePath();
		WDFinTrace(bStroke, bFill);
	}


	// Pour faire un rectangle arrondi, on fait 4 fois : trait et courbe (pour le coin).
	//		x1         x2
	//	y1	* /------\ *
	//		 /        \
	//		/          \
	//		|          |
	//		|          |
	//		\          /
	//		 \        /
	//	y2	* \------/ *
	var dX1 = oCadreContenu.m_dX;
	var dY1 = oCadreContenu.m_dY;
	var dX2 = dX1 + oCadreContenu.m_dLargeur;
	var dY2 = dY1 + oCadreContenu.m_dHauteur;

	// Pour chauque coin, on a 3 points : un avant le coin, un point de controle, un apr�s le coin (fin de l'arrondi).
	// On tourne sans le sens des aiguille d'une montre. Et on commencre au premier coin.
	var tabCoins = [
		// Haut gauche
		{ oD: { dX: dX1, dY: dY1 + __dGetHauteurCoin(0) }, oC: { dX: dX1, dY: dY1 }, oF: { dX: dX1 + __dGetLargeurCoin(0), dY: dY1 }, bD: __bBordDessine(4 /* Gauche */) },
		// Haut droite
		{ oD: { dX: dX2 - __dGetLargeurCoin(1), dY: dY1 }, oC: { dX: dX2, dY: dY1 }, oF: { dX: dX2, dY: dY1 + __dGetHauteurCoin(1) }, bD: __bBordDessine(1 /* Haut */) },
		// Bas gauche
		{ oD: { dX: dX2, dY: dY2 - __dGetHauteurCoin(2) }, oC: { dX: dX2, dY: dY2 }, oF: { dX: dX2 - __dGetLargeurCoin(2), dY: dY2 }, bD: __bBordDessine(8 /* Droite */) },
		// Bas droite
		{ oD: { dX: dX1 + __dGetLargeurCoin(3), dY: dY2 }, oC: { dX: dX1, dY: dY2 }, oF: { dX: dX1, dY: dY2 - __dGetHauteurCoin(3) }, bD: __bBordDessine(2 /* Base */) }
	];

	// Pour avoir le style du path correct, on fait le dessin en plusieurs fois : le fond puis le bord.

	// Le fond.
	if (oStyleFondContenuOuUndefined)
	{
		__Dessin(function ()
			{
				__DinoFond(oStyleFondContenuOuUndefined, dX1, dY1, dX2, dY2);
			}
			, __CoteEtCoinSimple
			, false
			, true);
	}

	// Le bord.
	if (oStyleCadreContenuOuUndefined)
	{
		__Dessin(function ()
			{
				// Place le style du premier trait.
				__DinoTrait(oStyleCadreContenuOuUndefined.m_tabTraits[0]);
			}
			, function (oCoin, nNumeroCoteEtCoin)
			{
				// Change la couleur et le style en fonction du trait.
				var oTrait = oStyleCadreContenuOuUndefined.m_tabTraits[nNumeroCoteEtCoin];
				var oTraitSuivant = oStyleCadreContenuOuUndefined.m_tabTraits[nNumeroCoteEtCoin == 3 ? 0 : nNumeroCoteEtCoin + 1];

				if (oCoin.bD)
				{
					// Dessine le trait.
					goDC.lineTo(oCoin.oD.dX, oCoin.oD.dY);
				}
				else
				{
					// Si le trait n'est pas dessin�
					goDC.moveTo(oCoin.oF.dX, oCoin.oF.dY);
				}

				// Si les couleur n'est pas identique.
				// On ne sait pas changer le style pendant l'angle.
				var bCouleurChange = String(oTrait.m_oCouleur) !== String(oTraitSuivant.m_oCouleur);
				if (bCouleurChange)
				{
					// Dessine le morceau de trait.
					// Et la transparence globale ?
					goDC.stroke();
//					goDC.closePath();
					goDC.beginPath();
					goDC.moveTo(oCoin.oD.dX, oCoin.oD.dY);
					// Puis passe en d�grad� pour faire la transition vers la nouvelle couleur.
					var oGradient = goDC.createLinearGradient(oCoin.oD.dX, oCoin.oD.dY, oCoin.oF.dX, oCoin.oF.dY);
					oGradient.addColorStop(0, oTrait.m_oCouleur);
					oGradient.addColorStop(1, oTraitSuivant.m_oCouleur);
					goDC.strokeStyle = oGradient;
				}

				// Dessine le coin.
				goDC.quadraticCurveTo(oCoin.oC.dX, oCoin.oC.dY, oCoin.oF.dX, oCoin.oF.dY);

				// Change le style si besoin.
				if (bCouleurChange || (oTrait.m_dEpaisseur !== oTraitSuivant.m_dEpaisseur) || (oTrait.m_eType !== oTraitSuivant.m_eType))
				{
					// Dessine le coin.
					// Et la transparence globale ?
					// Il faut faire le dessin dans le dernier coin car sinon le endPath de WDFinTrace fait un dessin parasite
					goDC.stroke();
//					goDC.closePath();
					goDC.beginPath();
					goDC.moveTo(oCoin.oF.dX, oCoin.oF.dY);
					// Place le style du trait suivant. Inutile si on est sur le dernier trait
					if (nNumeroCoteEtCoin < 3)
					{
						__DinoTrait(oTraitSuivant);
					}
				}
			}
			, true
			, false);
	}
	else if (!__bStrokeStyleTransparent())
	{
		__Dessin(function ()
			{
				// Rien laisse le style actuel.
			}
			, __CoteEtCoinSimple
			, true
			, false);
	}
}

// Fonction WL dCadre : elle est dans le framework V2.
function __dCadre(oCadreContenu, oStyleCadreContenuOuUndefined, oStyleFondContenuOuUndefined)
{
	__dRectangleArrondi(oCadreContenu, oStyleCadreContenuOuUndefined, oStyleFondContenuOuUndefined);
//	// Dessine le fond.
//	xxx;
//	// Dessine le cadre.
//	xxx;
}
