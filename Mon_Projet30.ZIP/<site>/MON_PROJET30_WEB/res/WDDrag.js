// WDDrag.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDutil.js
///#GLOBALS bIE bIEQuirks9Max bIEAvec11 bFF bTouchMobile bTouch

// Gestion commune du drag-drop
function WDDragBase ()
{
//	// Si on est pas dans l'init d'un protoype
//	if (arguments.length)
//	{
//	}
}

// Stop la propagation si demande
WDDragBase.prototype._bStopPropagation = function _bStopPropagation(oEvent)
{
	// GP 13/12/2016 : Il ne faut pas faire que le preventDefault, on veux arreter tout autre traitement
	var bStopPropagation = this._vbStopPropagation();
	return clWDUtil.bStopPropagationCond(oEvent, bStopPropagation, bStopPropagation);
};

// Par defaut stoppe la propagation
WDDragBase.prototype._vbStopPropagation = clWDUtil.m_pfVide;

// Recupere une position depuis un evenement
WDDragBase.prototype._nGetPosXEvent = function _nGetPosXEvent(oEvent)
{
	if (clWDUtil.bEventEstTouch(oEvent))
	{
		switch (oEvent.type)
		{
		case "touchend":
		case "touchcancel":
			break;
		default:
			this.m_nLastPosX = oEvent.touches.item(0).clientX;
			break;
		}
		return this.m_nLastPosX;
	}
	else
	{
		return oEvent.clientX;
	}
};
WDDragBase.prototype._nGetPosYEvent = function _nGetPosYEvent(oEvent)
{
	if (clWDUtil.bEventEstTouch(oEvent))
	{
		switch (oEvent.type)
		{
		case "touchend":
		case "touchcancel":
			break;
		default:
			this.m_nLastPosY = oEvent.touches.item(0).clientY;
			break;
		}
		return this.m_nLastPosY;
	}
	else
	{
		return oEvent.clientY;
	}
};

WDDragBase.prototype._oGetOriginalTarget = function _oGetOriginalTarget(oEvent)
{
	if (clWDUtil.bEventEstTouch(oEvent))
	{
		return document.elementFromPoint(this._nGetPosXEvent(oEvent), this._nGetPosYEvent(oEvent));
	}
	else
	{
		return clWDUtil.oGetOriginalTarget(oEvent);
	}
};

// Retourne la position du clic un objet
WDDragBase.prototype.oGetOffsetElementAutre = function oGetOffsetElementAutre(oEvent, oElement, bVertical)
{
	return bVertical ? this.oGetOffsetElementAutreY(oEvent, oElement) : this.oGetOffsetElementAutreX(oEvent, oElement);
};
WDDragBase.prototype.oGetOffsetElementAutreX = function oGetOffsetElementAutreX(oEvent, oElement)
{
	return clWDUtil.nGetBodyScrollLeft() + this._nGetPosXEvent(oEvent) - oElement.getBoundingClientRect().left;
};
WDDragBase.prototype.oGetOffsetElementAutreY = function oGetOffsetElementAutreY(oEvent, oElement)
{
	return clWDUtil.nGetBodyScrollTop() + this._nGetPosYEvent(oEvent) - oElement.getBoundingClientRect().top;
};

// Retourne la position du clic dans l'objet
WDDragBase.prototype.oGetOffsetElement = function oGetOffsetElement(oEvent, bVertical)
{
	return this.oGetOffsetElementAutre(oEvent, this._oGetOriginalTarget(oEvent), bVertical);
};
// GP 19/10/2012 : Utilis� uniquement par le DnD des champs
WDDragBase.prototype.oGetOffsetElementSiAutre = function oGetOffsetElementSiAutre(oEvent, oElement, bVertical)
{
	// GP 16/07/2012 : Utilisation de getBoundingClientRect()
	// GP 25/09/2012 : Et en rtl ? Il ne faut pas inverser ?
	// GP 27/09/2012 : Par compat pour ne pas tout changer je garde le oEvent.offsetX de IE
	if (oElement)
	{
		return this.oGetOffsetElementAutre(oEvent, oElement, bVertical);
	}
	else if (bIE)
	{
		return bVertical ? oEvent.offsetY : oEvent.offsetX;
	}
	else
	{
		return this.oGetOffsetElement(oEvent, bVertical);
	}
};

// Manipulation d'un element par Drag-Drop
function WDDrag(nDelaiAvantDeplacement, nDelaiEntreDeplacement)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDDragBase.prototype.constructor.apply(this, [true]);

		// Cree les fonctions de rappel
		var oThis = this;
		this.m_fMouseDown = function(oEvent) { return oThis.bOnMouseDown(oEvent || event) ? oThis._bStopPropagation(oEvent) : true; };
		this.m_fMouseMove = function(oEvent) { oThis.OnMouseMove(oEvent || event); return oThis._bStopPropagation(oEvent); };
		this.m_fMouseUp = function(oEvent) { return oThis.bOnMouseUp(oEvent || event) ? oThis._bStopPropagation(oEvent) : true; };
		this.m_fStopPropagation = function(oEvent) { return oThis._bStopPropagation(oEvent || event); };

		this.m_nDelaiAvantDeplacement = nDelaiAvantDeplacement;
		this.m_nDelaiEntreDeplacement = nDelaiEntreDeplacement;

		this.m_bPremierMouseMoveFiltre = false;

		this.m_bHookPoses = false;
	}
}

// Declare l'heritage
WDDrag.prototype = new WDDragBase();
// Surcharge le constructeur qui a ete efface
WDDrag.prototype.constructor = WDDrag;

WDDrag.prototype.ms_eDragDrop = 0;
WDDrag.prototype.ms_eDragRedimDebut = 1;
WDDrag.prototype.ms_eDragRedimFin = 2;
// + Droite + Gauche + Coins si besoin

// "passive" n'est pas disponible avec IE (disponible depuis Edge 16)
WDDrag.prototype.ms_oCaptureAvecPassiveSans = bIE ? true : { capture: true, passive: false };
WDDrag.prototype.ms_oCaptureSansPassiveSans = bIE ? false : { capture: false, passive: false };

// Liberation
WDDrag.prototype.Libere = function Libere()
{
//	this.m_fMouseDown = null;
	delete this.m_fMouseDown;
//	this.m_fMouseMove = null;
	delete this.m_fMouseMove;
//	this.m_fMouseUp = null;
	delete this.m_fMouseUp;
	delete this.m_fStopPropagation;
};

// Place/supprime un hook sur un �v�nement souris et/ou tactile
WDDrag.prototype.__AttacheDetacheMouseXxx = function __AttacheDetacheMouseXxx(bAttache, oElement, fFonction, sEventMouse, sEventTouch)
{
	if (bTouch)
	{
		// Il faut la phase de capture pour les �v�nements touch
		clWDUtil.AttacheDetacheEvent(bAttache, oElement, sEventTouch, fFonction, this.ms_oCaptureAvecPassiveSans);
	}
	if (!bTouchMobile)
	{
		// GP 22/02/2017 : TB100703 : Les machines desktop, il faut brancher souris + touch si disponible
		clWDUtil.AttacheDetacheEvent(bAttache, oElement, sEventMouse, fFonction, this.ms_oCaptureSansPassiveSans);
	}
};

// Place un hook sur mousedown/touchstart
WDDrag.prototype._AttacheDetacheMouseDown = function _AttacheDetacheMouseDown(bAttache, oElement, fFonction)
{
	this.__AttacheDetacheMouseXxx(bAttache, oElement, fFonction, "mousedown", "touchstart");
};

// Place un hook sur mousemove/touchmove et mouseup/touchend sur le document
WDDrag.prototype.__AttacheDetacheMouseMoveUp = function __AttacheDetacheMouseMoveUp(bAttache)
{
	if (this.m_bHookPoses !== bAttache)
	{
		this.m_bHookPoses = bAttache;
		this.__AttacheDetacheMouseXxx(bAttache, document, this.m_fMouseMove, "mousemove", "touchmove");
		this.__AttacheDetacheMouseXxx(bAttache, document, this.m_fMouseUp, "mouseup", "touchend");
		if (bFF)
		{
			// GP 12/02/2014 : TB85639 : Firefox part en DnD lors du d�placement
			clWDUtil.AttacheDetacheEvent(bAttache, document, "dragstart", this.m_fStopPropagation, this.ms_oCaptureSansPassiveSans);
		}
		if (bIE)//bIEQuirks ?
		{
			// Ne fonctionne que avec IE. On stoppe toujours la selection en cas de dragdrop sur un element cible
			clWDUtil.AttacheDetacheEvent(bAttache, document, "selectstart", this.m_fStopPropagation, this.ms_oCaptureSansPassiveSans);
		}
		if (bTouch)
		{
			// Il faut la phase de capture pour les �v�nements touch
			clWDUtil.AttacheDetacheEvent(bAttache, document, "touchcancel", this.m_fMouseUp, this.ms_oCaptureAvecPassiveSans);
		}
	}
};

// Indique si on est presentement en drag-drop
WDDrag.prototype.bEnDrag = function bEnDrag()
{
	return undefined !== this.nGetPosX();
};

// Recupere les positions
WDDrag.prototype.nGetPosX = function nGetPosX()
{
	return this.m_nPosX;
};
WDDrag.prototype.nGetPosY = function nGetPosY()
{
	return this.m_nPosY;
};

// Recupere la variation de la position
WDDrag.prototype.nGetOffsetPosX = function nGetOffsetPosX(oEvent)
{
	var nOffsetPosX = this._nGetPosXEvent(oEvent) - this.nGetPosX();
	// Prend en compte le mode ltr/rtl
	return clWDUtil.bRTL ? -nOffsetPosX : nOffsetPosX;
};
WDDrag.prototype.nGetOffsetPosY = function nGetOffsetPosY(oEvent)
{
	return this._nGetPosYEvent(oEvent) - this.nGetPosY();
};

// Appel lors du debut d'un click pour le redimensionnement
// Pose les hooks
WDDrag.prototype.bOnMouseDown = function bOnMouseDown(oEvent)
{
	// Uniquement sur le bouton gauche
	if (!clWDUtil.bValideBouton(oEvent))
	{
		return false;
	}

	// Appel de la methode surchargee
	if (this._vbOnMouseDown.apply(this, arguments))
	{
		document.body.unselectable = "on";
		document.body.style.webkitUserSelect = "none";
		document.body.style.MozUserSelect = "none";
		document.body.style.userSelect = "none";
		return !clWDUtil.bEventEstTouch(oEvent);
	}
	else
	{
		return false;
	}
};

// Appel lors du debut d'un click pour le redimensionnement
// Pose les hooks
WDDrag.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent)
{
	// Sauve la position souris (et initialise m_nLastPosX/m_nLastPosY);
	this.m_nPosX = this._nGetPosXEvent(oEvent);
	this.m_nPosY = this._nGetPosYEvent(oEvent);

	// Intercepte les evenements sur le document
	this.__AttacheDetacheMouseMoveUp(true);

	// Memorise pour le premier deplacement
	this.m_nDateMouseDown = (new Date()).getTime();

	return true;
};

// Appel lors du deplacement de la souris
WDDrag.prototype.OnMouseMove = function OnMouseMove(oEvent)
{
	// Si le bouton de la souris n'est plus enfonce (cas bizarre)
	// Annule le deplacement
	if (!clWDUtil.bValideBouton(oEvent))
	{
		// GP 03/07/2014 : Parfois on recoit des MouseMove sans bouton dans le redimensionnement du Tdb. Il doit y avoir un bug quelque part mais impossible de le trouver.
		// Contournement : On �crit une fonction qui filtre le premier mousemove
		if (this._vbFiltrePremierMouseMove() && !this.m_bPremierMouseMoveFiltre)
		{
			this.m_bPremierMouseMoveFiltre = true;
		}
		else
		{
			this.bOnMouseUp(oEvent);
		}
		return;
	}
	this.m_bPremierMouseMoveFiltre = false;

	// Si on demande un delai avant de lancer le deplacement
	var nMaintenant = (new Date()).getTime();
	if (this.m_nDelaiAvantDeplacement > 0)
	{
		if (this.m_nDateMouseDown)
		{
			if ((nMaintenant - this.m_nDateMouseDown) < this.m_nDelaiAvantDeplacement)
			{
				return;
			}
			else
			{
				delete this.m_nDateMouseDown;
			}
		}
	}

	// Si on demande un delai entre deux deplacement
	if (this.m_nDelaiEntreDeplacement > 0)
	{
		if (this.m_nDateMouseMove && ((nMaintenant - this.m_nDateMouseMove) < this.m_nDelaiEntreDeplacement))
		{
			return;
		}
		// On memorise pour le du rafraichissement
		this.m_nDateMouseMove = nMaintenant;
	}

	// Appel de la methode surchargee
	this._vOnMouseMove.apply(this, arguments);
};

// Si on active le filtrage du mousemove sans boutons
WDDrag.prototype._vbFiltrePremierMouseMove = clWDUtil.m_pfVideFalse;

// Appel lors du deplacement de la souris
//WDDrag.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
WDDrag.prototype._vOnMouseMove = clWDUtil.m_pfVide;

// Appel lors du relachement de la souris
// Restaure les fonctions hookees
WDDrag.prototype.bOnMouseUp = function bOnMouseUp(oEvent)
{
	// TB77936 : Annule sauf si on est en touch et que l'on n'a pas boug�
	// Il faut faire le calcul avant car _vOnMouseUp efface les membres
	var bAnnule = (!clWDUtil.bEventEstTouch(oEvent)) || (0 !== this.nGetOffsetPosX(oEvent)) || (0 !== this.nGetOffsetPosY(oEvent));

	// Appel de la methode surchargee
	this._vOnMouseUp.apply(this, arguments);

	document.body.unselectable = "off";
	document.body.style.userSelect = "text";
	document.body.style.MozUserSelect = "text";
	document.body.style.webkitUserSelect = "text";

	return bAnnule;
};

// Appel lors du relachement de la souris
// Restaure les fonctions hookees
WDDrag.prototype._vOnMouseUp = function _vOnMouseUp(/*oEvent*/)
{
	// Restaure les hook du document
	this.__AttacheDetacheMouseMoveUp(false);

	// Vire la limitation du rafriachissement
	if (this.m_nDateMouseMove !== undefined)
	{
		delete this.m_nDateMouseMove;
	}
	if (this.m_nDateMouseDown !== undefined)
	{
		delete this.m_nDateMouseDown;
	}

	// Vire la position souris
	delete this.m_nPosY;
	delete this.m_nPosX;
};

// Gestion du drag+drop HTML 5 (+ drag+drop natif)
// Ne fait pas de gestion de sources/cibles multiples
function WDDnDNatif(nSource, nCible, oElement, nOperationDefaut)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDDragBase.prototype.constructor.apply(this, [true]);

		// Cree les fonctions de rappel
		var oThis = this;
		if (0 < nSource)
		{
			this.m_nSource = nSource;
			this.m_fDragStart = function(oEvent) { oThis._OnDnDEvenement(oEvent || event, oThis._OnDragStart); };
//			this.m_fDrag = function(oEvent) { oThis._OnDnDEvenement(oEvent || event, oThis._OnDrag); };
			this.m_fDragEnd = function(oEvent) { oThis._OnDnDEvenement(oEvent || event, oThis._OnDragEnd); return oThis._bStopPropagation(oEvent); };
		}
		if (0 < nCible)
		{
			this.m_nCible = nCible;
			this.m_fDragEnter = function(oEvent) { oThis._OnDnDEvenement(oEvent || event, oThis._OnDragEnter); return oThis._bStopPropagation(oEvent); };
			this.m_fDragOver = function(oEvent) { oThis._OnDnDEvenement(oEvent || event, oThis._OnDragOver); return oThis._bStopPropagation(oEvent); };
			this.m_fDragExit = function(oEvent) { oThis._OnDnDEvenement(oEvent || event, oThis._OnDragExit); return oThis._bStopPropagation(oEvent); };
			this.m_fDrop = function(oEvent) { oThis._OnDnDEvenement(oEvent || event, oThis._OnDrop); return oThis._bStopPropagation(oEvent); };
		}
		// Par defaut accepte la copie
		this.m_nOperationDefaut = (nOperationDefaut !== undefined) ? nOperationDefaut : this.ms_nOperationCopie;

		if (this._vbEmuleIE9())
		{
			// On n'a que srcElement en mode quirks (pas target)
			this.m_fSelectStart = function(oEvent) { return oThis.__SelectStartIE(oEvent || event); };
		}

		// Si on un element HTML : liaison
		if (oElement)
		{
			this._InitElement(oElement);
			// GP 19/10/2012 : Si on est cible par programmation, on va peut-�tre utiliser _DnD.SourisPosX, _DnD.SourisPosY
			// M�morise l'�l�ment
			if (2 === nCible)
			{
				this.m_oElement = oElement;
			}
		}
	}
}

// Declare l'heritage
WDDnDNatif.prototype = new WDDragBase();
// Surcharge le constructeur qui a ete efface
WDDnDNatif.prototype.constructor = WDDnDNatif;

// Valeur de l'operation
// ms_nOperationDejaFait : pour la version par programmation qui indique que c'est deja fait par DNDAccepte et DNDCurseur
WDDnDNatif.prototype.ms_nOperationDejaFait = -1;
WDDnDNatif.prototype.ms_nOperationSans = 0;
WDDnDNatif.prototype.ms_nOperationCopie = 1;
WDDnDNatif.prototype.ms_nOperationDeplacement = 2;
WDDnDNatif.prototype.ms_nOperationLien = 4;
// Selon la combinaison de this.ms_nOperationXxx
WDDnDNatif.prototype.ms_tabEffectAllowed = ["none", "copy", "move", "copyMove", "link", "copyLink", "linkMove", "all"];
// copy > move > link
WDDnDNatif.prototype.ms_tabDropEffect = ["none", "copy", "move", "copy", "link", "copy", "Move", "copy"];

// Indice des operation (correspond aux parametres de DnDEvenements)
WDDnDNatif.prototype.ms_nDnDDebutGlisser = 5;
WDDnDNatif.prototype.ms_nDnDEntreeChamp = 2;
WDDnDNatif.prototype.ms_nDnDFinGlisser = 6;
WDDnDNatif.prototype.ms_nDnDLacher = 4;
WDDnDNatif.prototype.ms_nDnDSortieChamp = 3;
WDDnDNatif.prototype.ms_nDnDSurvol = 1;
// Type generaux de donnees
WDDnDNatif.prototype.ms_tabTypes = ["text/plain", "text/uri-list"];

// Hook pour lancer le DnD sous IE9
// Utilise srcElement car on est forc�ment dans IE dans un mode de compatibilit� compatible
WDDnDNatif.prototype.__SelectStartIE = function __SelectStartIE(oEvent)
{
	var oSrcElement = oEvent.srcElement;
	// GP 15/11/2013 : On recherche uniquement les �l�ments qui sont "draggable"
	var oBody = document.body;
	while (oSrcElement && (oSrcElement !== oBody))
	{
		// GP 17/11/2013 : hasAttribute n'est pas disponible en mode quirks
		if (oSrcElement.dragDrop && ((oSrcElement.hasAttribute && oSrcElement.hasAttribute("draggable")) || oSrcElement.draggable))
		{
			oSrcElement.dragDrop();
			return this._bStopPropagation(oEvent);
		}
		oSrcElement = oSrcElement.parentNode;
	}
};

// Association a un element HTML
WDDnDNatif.prototype._InitElement = function _InitElement(oElement)
{
	// Si on est source
	if (0 < this.m_nSource)
	{
		// Ajoute l'attribut draggable : comportement different selon les elements
		switch (clWDUtil.sGetTagName(oElement))
		{
		case "input":
			// Rien sur les "input" (bloque la saisie selon les navigateurs + le champ le gere nativement)
			break;
		case "select":
			// L'applique sur les options
			this._InitElementTab(oElement.getElementsByTagName("option"));
			break;
		default:
			oElement.setAttribute("draggable", "true", 0);
			break;
		}
		clWDUtil.AttacheDetacheEvent(true, oElement, "dragstart", this.m_fDragStart);
//		if (!bIE)
//		{
//			clWDUtil.AttacheDetacheEvent(true, oElement, "drag", this.m_fDrag);
//		}
		clWDUtil.AttacheDetacheEvent(true, oElement, "dragend", this.m_fDragEnd);
	}

	// Si on est cible
	if (0 < this.m_nCible)
	{
		clWDUtil.AttacheDetacheEvent(true, oElement, "dragenter", this.m_fDragEnter);
		clWDUtil.AttacheDetacheEvent(true, oElement, "dragover", this.m_fDragOver);
		// GP 27/05/2013 : TB82562 : Ce n'est pas dragexit mais dragleave
		// Pas les deux sinon on a deux appel de la sortie dans Firefox
//		clWDUtil.AttacheDetacheEvent(true, oElement, "dragexit", this.m_fDragExit);
		clWDUtil.AttacheDetacheEvent(true, oElement, "dragleave", this.m_fDragExit);
		clWDUtil.AttacheDetacheEvent(true, oElement, "drop", this.m_fDrop);
	}

	if (this.m_fSelectStart)
	{
		clWDUtil.AttacheDetacheEvent(true, document, "selectstart", this.m_fSelectStart);
	}
};
WDDnDNatif.prototype._InitElementTab = function _InitElementTab(tabElement)
{
	var i;
	var nLimiteI = tabElement.length;
	for (i = 0; i < nLimiteI; i++)
	{
		this._InitElement(tabElement[i]);
	}
};

// Liberation
WDDnDNatif.prototype._LibereElement = function _LibereElement(oElement)
{
	if (this.m_fSelectStart)
	{
		clWDUtil.AttacheDetacheEvent(false, document, "selectstart", this.m_fSelectStart);
	}

	// Si on est cible
	if (0 < this.m_nCible)
	{
		clWDUtil.AttacheDetacheEvent(false, oElement, "drop", this.m_fDrop);
		// GP 27/05/2013 : TB82562 : Ce n'est pas dragexit mais dragleave
		// Pas les deux sinon on a deux appel de la sortie dans Firefox
		clWDUtil.AttacheDetacheEvent(false, oElement, "dragleave", this.m_fDragExit);
//		clWDUtil.AttacheDetacheEvent(false, oElement, "dragexit", this.m_fDragExit);
		clWDUtil.AttacheDetacheEvent(false, oElement, "dragover", this.m_fDragOver);
		clWDUtil.AttacheDetacheEvent(false, oElement, "dragenter", this.m_fDragEnter);
	}
	// Si on est source
	if (0 < this.m_nSource)
	{
		clWDUtil.AttacheDetacheEvent(false, oElement, "dragend", this.m_fDragEnd);
//		if (!bIE)
//		{
//			clWDUtil.AttacheDetacheEvent(false, oElement, "drag", this.m_fDrag);
//		}
		clWDUtil.AttacheDetacheEvent(false, oElement, "dragstart", this.m_fDragStart);
		// Supprime l'attribut draggable : comportement different selon les elements
		switch (clWDUtil.sGetTagName(oElement))
		{
		case "input":
			// Rien sur les "input" (bloque la saisie selon les navigateurs + le champ le gere nativement)
			break;
		case "select":
			// L'applique sur les options
			this._LibereElementTab(oElement.getElementsByTagName("option"));
			break;
		default:
			oElement.removeAttribute("draggable", 0);
			break;
		}
	}
};
WDDnDNatif.prototype._LibereElementTab = function _LibereElementTab(tabElement)
{
	var i;
	var nLimiteI = tabElement.length;
	for (i = 0; i < nLimiteI; i++)
	{
		this._LibereElement(tabElement[i]);
	}
};

//////////////////////////////////////////////////////////////////////////
// Gestion des evenements

// Encapsulation des evenements
WDDnDNatif.prototype._OnDnDEvenement = function _OnDnDEvenement(oEvent, fFonction)
{
	try
	{
		// Pas besoin de pile, normalement il n'y a qu'un seul evenement possible a la fois (sauf en cas de breakpoint ou les evenements s'empilent)
		this.m_oEvent = oEvent;
		this._vSetDnDActif();

		// Appel du traitement de l'evenement
		fFonction.apply(this, []);
	}
	finally
	{
		// Libere les variables
		this._vClearDnDActif();
		this.m_oEvent = null;
		delete this.m_oEvent;
	}
};
// Acces au donnes de l'evenement courant
WDDnDNatif.prototype._oGetEvent = function _oGetEvent()
{
	return this.m_oEvent;
};
WDDnDNatif.prototype._oGetEventData = function _oGetEventData()
{
	return this.m_oEvent.dataTransfer;
};

// Acces au donnes de l'evenement courant : type : verifie si un type est dans les donnees
WDDnDNatif.prototype._bVerifieEventDataType = function _bVerifieEventDataType(sTypeDonnees)
{
	// Pas de membre types si le navigateur ne gere pas la fonctionnalite
	var oDonnees = this._oGetEventData();
	var tabTypes = oDonnees.types;
	if (tabTypes)
	{
		return clWDUtil.bDansTableau(tabTypes, sTypeDonnees);
	}
	else if (bIE)
	{
		var sDonnees = oDonnees.getData(sTypeDonnees);
		return sDonnees && (0 < sDonnees.length);
	}
};
WDDnDNatif.prototype._oGetEventDataSelonType = function _oGetEventDataSelonType(sTypeDonnees)
{
	if (this._bVerifieEventDataType(sTypeDonnees))
	{
		return this._oGetEventData().getData(sTypeDonnees);
	}
	else
	{
		return "";
	}
};
WDDnDNatif.prototype._SetEventDataSelonType = function _SetEventDataSelonType(sTypeDonnees, sDonnees)
{
	this._oGetEventData().setData(sTypeDonnees, sDonnees);
};

WDDnDNatif.prototype._sDataTypeAvecCorrectionNombre = function _sDataTypeAvecCorrectionNombre(sTypeDonnees)
{
	// CF_TEXT => text/plain
	if (sTypeDonnees === 1)
	{
		return this.ms_tabTypes[0];
	}
	return sTypeDonnees;
};


if (bIEAvec11)
{
	// Corrige le type de donnees pour IE
	WDDnDNatif.prototype.ms_tabTypesIE = ["Text", "URL"];
	WDDnDNatif.prototype._sDataTypeAvecCorrection = function _sDataTypeAvecCorrection(sTypeDonnees)
	{
		// Corrige pour CF_TEXT
		sTypeDonnees = this._sDataTypeAvecCorrectionNombre(sTypeDonnees);
		// Et recherche la valeur a convertir
		var nType = clWDUtil.nDansTableau(this.ms_tabTypes, sTypeDonnees);
		if (clWDUtil.nElementInconnu !== nType)
		{
			return this.ms_tabTypesIE[nType];
		}
		return sTypeDonnees;
	};
}
else
{
	WDDnDNatif.prototype._sDataTypeAvecCorrection = WDDnDNatif.prototype._sDataTypeAvecCorrectionNombre;
}
WDDnDNatif.prototype._bVerifieEventDataTypeAvecCorrection = function _bVerifieEventDataTypeAvecCorrection(sTypeDonnees)
{
	return this._bVerifieEventDataType(this._sDataTypeAvecCorrection(sTypeDonnees));
};
WDDnDNatif.prototype._oGetEventDataSelonTypeAvecCorrection = function _oGetEventDataSelonTypeAvecCorrection(sTypeDonnees)
{
	return this._oGetEventDataSelonType(this._sDataTypeAvecCorrection(sTypeDonnees));
};
WDDnDNatif.prototype._SetEventDataSelonTypeAvecCorrection = function _SetEventDataSelonTypeAvecCorrection(sTypeDonnees, sDonnees)
{
	this._SetEventDataSelonType(this._sDataTypeAvecCorrection(sTypeDonnees), sDonnees);
};

WDDnDNatif.prototype._vSetDnDActif = clWDUtil.m_pfVide;
WDDnDNatif.prototype._vClearDnDActif = clWDUtil.m_pfVide;

//////////////////////////////////////////////////////////////////////////
// Evenements

// Pendant le DnD
WDDnDNatif.prototype._OnDrag = function _OnDrag()
{
	this._oGetEventData().effectAllowed = "all";
};

// Debut de drag/drop
WDDnDNatif.prototype._OnDragStart = function _OnDragStart()
{
	// Se memorise comme source du DnD
	WDDnDNatif.prototype.ms_oDnDSource = this;

	this._OnDrag();

	// Ecrit la/les valeurs
	this._vSetDonneesDnD();
};
// Fin du drag/drop pour la source
WDDnDNatif.prototype._OnDragEnd = function _OnDragEnd()
{
	try
	{
		// Notifie de la fin
		this._vOnDragEnd();
	}
	finally
	{
		// Se supprime comme source du DnD (le test est normalement inutile)
		// Pour ce test WDDnDNatif.prototype est inutile, this suffit
		if (this.ms_oDnDSource === this)
		{
			WDDnDNatif.prototype.ms_oDnDSource = null;
			delete WDDnDNatif.prototype.ms_oDnDSource;
		}
	}
};

// Entree et survol : dragenter/dragover
WDDnDNatif.prototype._OnDragEnter = function _OnDragEnter()
{
	this._OnDragSurvol(this.ms_nDnDEntreeChamp);
};
WDDnDNatif.prototype._OnDragOver = function _OnDragOver()
{
	this._OnDragSurvol(this.ms_nDnDSurvol);
};
WDDnDNatif.prototype._OnDragSurvol = function _OnDragSurvol(nDnDOperation)
{
	// Se memorise comme cible du DnD (normalement inutile dans le cas dragover)
	WDDnDNatif.prototype.ms_oDnDCible = this;

	// Valide si le format est acceptable
	var nOperation = this._vnGetOperationSurDrop(nDnDOperation);

	if (nOperation !== this.ms_nOperationSans)
	{
		nOperation = this._vnOnDragSurvol(nDnDOperation, nOperation);
		if (nOperation !== this.ms_nOperationDejaFait)
		{
			// GP 24/05/2013 : Plante dans IE si non disponible
			try
			{
				this._oGetEventData().effectAllowed = this.ms_tabEffectAllowed[nOperation];
			}
			catch (e)
			{
			}
			// Si une operation est permise : appel de la methode virtuelle
			if ((nOperation !== this.ms_nOperationSans) && (!bIEQuirks9Max || this._vbEmuleIE9()))
			{
				this._oGetEventData().dropEffect = this.ms_tabDropEffect[nOperation];
			}
		}
	}
	else
	{
		// Force l'interdcition de l'effet
		try
		{
			this._oGetEventData().dropEffect = this.ms_tabDropEffect[nOperation];
		}
		catch (e)
		{
		}

		try
		{
			this._oGetEventData().effectAllowed = this.ms_tabEffectAllowed[nOperation];
		}
		catch (e)
		{
		}
	}
};
// Fin de survol : dragexit
WDDnDNatif.prototype._OnDragExit = function _OnDragExit()
{
	try
	{
		// Si une operation est permise : appel de la methode virtuelle
		if (this._vnGetOperationSurDrop(this.ms_nDnDSortieChamp) !== this.ms_nOperationSans)
		{
			this._vOnDragExit();
		}
	}
	finally
	{
		// Se supprime comme cible du DnD (le test est normalement inutile)
		if (WDDnDNatif.prototype.ms_oDnDCible === this)
		{
			WDDnDNatif.prototype.ms_oDnDCible = null;
			delete WDDnDNatif.prototype.ms_oDnDCible;
		}
	}
};
// Lacher : drop
WDDnDNatif.prototype._OnDrop = function _OnDrop()
{
	try
	{
		// Si une operation est permise : appel de la methode virtuelle
		if (this._vnGetOperationSurDrop(this.ms_nDnDLacher) !== this.ms_nOperationSans)
		{
			this._vOnDrop();
		}
	}
	finally
	{
		// Se supprime comme cible du DnD (le test est normalement inutile)
		// Pour ce test WDDnDNatif.prototype est inutile, this suffit
		if (this.ms_oDnDCible === this)
		{
			WDDnDNatif.prototype.ms_oDnDCible = null;
			delete WDDnDNatif.prototype.ms_oDnDCible;
		}
	}
};

//////////////////////////////////////////////////////////////////////////
// Traitement des evenements

// Ecrit la/les valeurs : par defaut pas de donnees
WDDnDNatif.prototype._vSetDonneesDnD = clWDUtil.m_pfVide;
// Fin du DnD (pour l'appelant) : par defaut rien en fin
WDDnDNatif.prototype._vOnDragEnd = clWDUtil.m_pfVide;
// Indique les operations sur le drop
WDDnDNatif.prototype._vnGetOperationSurDrop = function _vnGetOperationSurDrop(/*nDnDOperation*/)
{
	return this.m_nOperationDefaut;
};
// Indique l'operation par defaut pour le drop effet
WDDnDNatif.prototype._vnOnDragSurvol = function _vnOnDragSurvol(nDnDOperation, nOperation)
{
	// Si on arrive ici c'est que _vnGetOperationSurDrop a valider le contenu du drop
	return nOperation;
};
WDDnDNatif.prototype._vOnDragExit = clWDUtil.m_pfVide;
// Lacher sur l'element
WDDnDNatif.prototype._vOnDrop = clWDUtil.m_pfVide;

// Emule le DnDNatif avec IE9. Non par d�faut
WDDnDNatif.prototype._vbEmuleIE9 = function _vbEmuleIE9()
{
	return false;
};

// Gestion du drag+drop HTML 5 (+ drag+drop natif) sur un champ
// Ne fait pas de gestion de sources/cibles multiples
var WDDnDNatifChamp = (function ()
{
	"use strict";

	function __WDDnDNatifChamp(sAliasChamp, nSource, nCible, oElement, tabFonctionsGet, tabFonctionsSet)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			// Source/cible si on a une fonction
			// Conserve l'operation par defaut (copie)
			WDDnDNatif.prototype.constructor.apply(this, [nSource, nCible, oElement]);

			this.m_sAliasChamp = sAliasChamp;
			// Memorise les fonctions de get
			this.m_tabFonctionsGet = tabFonctionsGet;
			this.m_tabFonctionsSet = tabFonctionsSet;

			// Tableau des appels de DnDEvenement
			this.m_tabDnDEvenement = [];
		}
	}

	// Declare l'heritage
	__WDDnDNatifChamp.prototype = new WDDnDNatif();
	// Surcharge le constructeur qui a ete efface
	__WDDnDNatifChamp.prototype.constructor = __WDDnDNatifChamp;

	// Operations en WL
	var ms_nDnDInterdit = 0;
	var ms_nDnDCopier = 1;
	var ms_nDnDDeplacer = 2;
	var ms_nDnDDefaut = 3;
	// C'est un tableau construit comme un objet pour avoir les membres nommees simplement
	// copy > move > link
	var ms_tabEffectAllowedToWL =
	{
		"none": ms_nDnDInterdit,
		"copy": ms_nDnDCopier,
		"move": ms_nDnDDeplacer,
		"copyMove": ms_nDnDCopier,
		"link": ms_nDnDInterdit,		// N'existe pas en WL
		"copyLink": ms_nDnDCopier,
		"linkMove": ms_nDnDDeplacer,
		"all": ms_nDnDCopier
	};
	// Tableau des DnD activee
	var ms_tabDnDNatifChamp = [];
	// Champ en cours de DnD.
	var ms_oDnDActif = null;

	__WDDnDNatifChamp.prototype.s_DeclareChamp = function s_DeclareChamp(sAliasChamp, sAliasTableZRParent, nSource, nCible, oElement, tabFonctionsGet, tabFonctionsSet)
	{
		if ((0 < nSource) || (0 < nCible))
		{
			ms_tabDnDNatifChamp[sAliasChamp] = new __WDDnDNatifChamp(sAliasChamp, nSource, nCible, oElement, tabFonctionsGet, tabFonctionsSet);
		}
	};

	// Pour le DnD programme
	__WDDnDNatifChamp.prototype.pfGetDnDProgramme = function pfGetDnDProgramme(nDnDFonction)
	{
		// Cible si < ms_nDnDDebutGlisser
		var nDnD = (nDnDFonction < this.ms_nDnDDebutGlisser) ? this.m_nCible : this.m_nSource;
		// 0 = Sans, 1 = Automatique, 2 = Programme
		return (2 === nDnD) ? this.m_tabDnDEvenement[nDnDFonction] : null;
	};

	__WDDnDNatifChamp.prototype.__oGetVariable = function __oGetVariable(nVariable)
	{
		var oEvent = this._oGetEvent();
		switch (nVariable)
		{
		case 0:
			// _DND.Action
			return ms_tabEffectAllowedToWL[this._oGetEventData().effectAllowed];
		case 1:
			// _DND.ChampCible
			return this.__sGetAliasChamp(this.ms_oDnDCible);
		case 2:
			// _DND.ChampSource
			return this.__sGetAliasChamp(this.ms_oDnDSource);
		case 3:
			// _DND.CtrlEnfonce
			return oEvent.ctrlKey;
		case 4:
			// _DND.FenSource
			// Pour avoir l'element il faut forcement etre dans la meme page
			return this.ms_oDnDSource ? document.forms[0].name : "";
		case 5:
			// _DND.SourisPosX
			return this.oGetOffsetElementSiAutre(oEvent, this.ms_oDnDCible.m_oElement, false);
		case 6:
			// _DND.SourisPosY
			return this.oGetOffsetElementSiAutre(oEvent, this.ms_oDnDCible.m_oElement, true);
		}
	};

	// Conversion entre les valeurs internes et les valeurs WL
	__WDDnDNatifChamp.prototype.__SetEffectDepuisActionWL = function __SetEffectDepuisActionWL(nActionWL, bDropEffect)
	{
		var nOperation;
		switch (nActionWL)
		{
		default:
		case ms_nDnDInterdit:
			nOperation = this.ms_nOperationSans;
			break;
		case ms_nDnDCopier:
			nOperation = this.ms_nOperationCopie;
			break;
		case ms_nDnDDeplacer:
			nOperation = this.ms_nOperationDeplacement;
			break;
		case ms_nDnDDefaut:
			nOperation = this.m_nOperationDefaut;
			break;
		}
		if (bDropEffect)
		{
			if (!bIEQuirks9Max)
			{
				this._oGetEventData().dropEffect = this.ms_tabDropEffect[nOperation];
			}
		}
		else
		{
			this._oGetEventData().effectAllowed = this.ms_tabEffectAllowed[nOperation];
		}
	};

	__WDDnDNatifChamp.prototype.__sGetAliasChamp = function __sGetAliasChamp(oDnDChamp)
	{
		return oDnDChamp ? oDnDChamp.m_sAliasChamp : "";
	};

	__WDDnDNatifChamp.prototype._vSetDnDActif = function _vSetDnDActif()
	{
		ms_oDnDActif = this;
	};
	__WDDnDNatifChamp.prototype._vClearDnDActif = function _vClearDnDActif()
	{
		ms_oDnDActif = null;
	};

	// Ecrit la/les valeurs : lit le champs
	__WDDnDNatifChamp.prototype._vSetDonneesDnD = function _vSetDonneesDnD()
	{
		// Appel de la methode de la classe de base
		WDDnDNatif.prototype._vSetDonneesDnD.apply(this, arguments);

		// Si on est en DnD programme
		var pfDnDProgramme = this.pfGetDnDProgramme(this.ms_nDnDDebutGlisser);
		if (pfDnDProgramme)
		{
			pfDnDProgramme();
		}
		else
		{
			// Donne des donnees pour les types sur lequel on a une operation de get
			var tabFonctionsGet = this.m_tabFonctionsGet;
			var i;
			var nLimiteI = tabFonctionsGet.length;
			var bFonctionGet = false;
			for (i = 0; i < nLimiteI; i++)
			{
				if (tabFonctionsGet[i])
				{
					this._SetEventDataSelonTypeAvecCorrection(this.ms_tabTypes[i], tabFonctionsGet[i]());
					bFonctionGet = true;
				}
			}
			// Si on n'a pas une fonction de get : place le nom du champ. En effet sans valeur, certains navigateurs ne partent pas en DnD.
			if (false === bFonctionGet)
			{
				this._SetEventDataSelonTypeAvecCorrection(this.ms_tabTypes[0], this.m_sAliasChamp);
			}
		}
	};

	// Fin du DnD (pour l'appelant) : traite le cas deplacement
	__WDDnDNatifChamp.prototype._vOnDragEnd = function _vOnDragEnd()
	{
		// Appel de la methode de la classe de base
		WDDnDNatif.prototype._vOnDragEnd.apply(this, arguments);

		// Si on est en DnD programme
		var pfDnDProgramme = this.pfGetDnDProgramme(this.ms_nDnDFinGlisser);
		if (pfDnDProgramme)
		{
			pfDnDProgramme();
		}
		else
		{
			// Traite le deplacement des donnees pour les types sur lequel on a une operation de set
			if (this._oGetEventData().dropEffect === this.ms_tabEffectAllowed[this.ms_nOperationDeplacement])
			{
				// Interdit sur les listes car c'est ridicule de vider le texte de l'element
				if (!clWDUtil.bBaliseEstTag(this._oGetOriginalTarget(this._oGetEvent()), "option"))
				{
					var tabFonctionsSet = this.m_tabFonctionsSet;
					var i;
					var nLimiteI = tabFonctionsSet.length;
					for (i = 0; i < nLimiteI; i++)
					{
						if (tabFonctionsSet[i])
						{
							tabFonctionsSet[i]("");
						}
					}
				}
			}
		}
	};

	// Operation de mouvement de la sourie
	__WDDnDNatifChamp.prototype._vnGetOperationSurDrop = function _vnGetOperationSurDrop(nDnDOperation)
	{
		// Si on est en DnD programme
		var pfDnDProgramme = this.pfGetDnDProgramme(nDnDOperation);
		if (pfDnDProgramme)
		{
			// Le traitement lui meme doit faire un DnDAccepte
			return this.ms_nOperationCopie + this.ms_nOperationDeplacement + this.ms_nOperationLien;
		}
		else
		{
			// Verifie que l'on a bien des donnees sur un des types pour lequel on a une operation de set
			var tabFonctionsSet = this.m_tabFonctionsSet;
			var i;
			var nLimiteI = tabFonctionsSet.length;
			for (i = 0; i < nLimiteI; i++)
			{
				if (tabFonctionsSet[i] && this._bVerifieEventDataTypeAvecCorrection(this.ms_tabTypes[i]))
				{
					// Utilise l'operation par defaut definie
					return WDDnDNatif.prototype._vnGetOperationSurDrop.apply(this, arguments);
				}
			}

			// Navigateur incompatible ou donnees inavlides
			return this.ms_nOperationSans;
		}
	};

	// Indique l'operation par defaut pour le drop effet
	__WDDnDNatifChamp.prototype._vnOnDragSurvol = function _vnOnDragSurvol(nDnDOperation/*, nOperation*/)
	{
		// Si on est en DnD programme
		var pfDnDProgramme = this.pfGetDnDProgramme(nDnDOperation);
		if (pfDnDProgramme)
		{
			pfDnDProgramme();
			return this.ms_nOperationDejaFait;
		}
		else
		{
			// Utilise l'operation par defaut definie
			return WDDnDNatif.prototype._vnOnDragSurvol.apply(this, arguments);
		}
	};

	// Indique que l'on sort du survol
	__WDDnDNatifChamp.prototype._vOnDragExit = function _vOnDragExit()
	{
		var pfDnDProgramme = this.pfGetDnDProgramme(this.ms_nDnDSortieChamp);
		if (pfDnDProgramme)
		{
			pfDnDProgramme();
		}

		// Appel de la methode de la classe de base
		WDDnDNatif.prototype._vOnDragExit.apply(this, arguments);
	};

	// Lacher sur l'element
	__WDDnDNatifChamp.prototype._vOnDrop = function _vOnDrop()
	{
		// Appel de la methode de la classe de base
		WDDnDNatif.prototype._vOnDrop.apply(this, arguments);

		var pfDnDProgramme = this.pfGetDnDProgramme(this.ms_nDnDLacher);
		if (pfDnDProgramme)
		{
			pfDnDProgramme();
		}
		else
		{
			// Lit les donnees pour les types sur lequel on a une operation de get
			var tabFonctionsSet = this.m_tabFonctionsSet;
			var i;
			var nLimiteI = tabFonctionsSet.length;
			for (i = 0; i < nLimiteI; i++)
			{
				if (tabFonctionsSet[i])
				{
					var sDonnees = this._oGetEventDataSelonTypeAvecCorrection(this.ms_tabTypes[i]);
					if (0 < sDonnees.length)
					{
						tabFonctionsSet[i](sDonnees);
					}
				}
			}
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Interface pour le WL

	__WDDnDNatifChamp.prototype.s_DnDEvenement = function s_DnDEvenement(fProcedure, sAliasChamp, nEvenement)
	{
		ms_tabDnDNatifChamp[sAliasChamp].m_tabDnDEvenement[nEvenement] = fProcedure;
	};

	__WDDnDNatifChamp.prototype.s_DnDAccepte = function s_DnDAccepte(nActionWL)
	{
		// Sans blindage : erreur JS hors d'un DnD
		// DnDAccepte force dropEffect et effectAllowed car sinon il faut appeler DnDCurseur explictement
		ms_oDnDActif.__SetEffectDepuisActionWL(nActionWL, false);
		__WDDnDNatifChamp.prototype.s_DnDCurseur(nActionWL);
	};

	__WDDnDNatifChamp.prototype.s_DnDCurseur = function s_DnDCurseur(nActionWL)
	{
		// Sans blindage : erreur JS hors d'un DnD
		ms_oDnDActif.__SetEffectDepuisActionWL(nActionWL, true);
	};

	__WDDnDNatifChamp.prototype.s_DnDDonne = function s_DnDDonne(sTypeDonnees, sDonnees)
	{
		// Sans blindage : erreur JS hors d'un DnD
		ms_oDnDActif._SetEventDataSelonTypeAvecCorrection(sTypeDonnees, sDonnees);
	};

	__WDDnDNatifChamp.prototype.s_DnDDonneeDisponible = function s_DnDDonneeDisponible(sTypeDonnees)
	{
		// Sans blindage : erreur JS hors d'un DnD
		return ms_oDnDActif._bVerifieEventDataTypeAvecCorrection(sTypeDonnees);
	};

	__WDDnDNatifChamp.prototype.s_DnDRecupere = function s_DnDRecupere(sTypeDonnees)
	{
		// Sans blindage : erreur JS hors d'un DnD
		return ms_oDnDActif._oGetEventDataSelonTypeAvecCorrection(sTypeDonnees);
	};

	__WDDnDNatifChamp.prototype.s_oGetVariable = function s_oGetVariable(nVariable)
	{
		// Sans blindage : erreur JS hors d'un DnD
		return ms_oDnDActif.__oGetVariable(nVariable);
	};

	return __WDDnDNatifChamp;
})();

//////////////////////////////////////////////////////////////////////////
// Classe pour le d�placement au doigt dans les tables

var WDDragTouch = (function ()
{
	"use strict";

	// pfCallback : fonction a appeler sur le d�filement  : parametres : (nOffsetX, nOffsetY, oEvent) <= nOffsetX et nOffsetY ont d�j� �t� invers�.
	// oCible : objet du DOM sur lequel se brancher
	function __WDDragTouch(pfCallback, oCible)
	{
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDDrag.prototype.constructor.apply(this, [0, 100]);

			// Table liee a la requete
			this.m_pfCallback = pfCallback;
			this.m_oCible = oCible;
			this._AttacheDetacheMouseDown(true, oCible, this.m_fMouseDown);
		}
	}

	// Declare l'heritage
	__WDDragTouch.prototype = new WDDrag();
	// Surcharge le constructeur qui a ete efface
	__WDDragTouch.prototype.constructor = __WDDragTouch;

	// D�tachement (normalement inutile, le d�tachement est sur un objet du DOM qui va �tre liber� donc le garbage collector va faire le menage)
	__WDDragTouch.prototype.Detache = function Detache()
	{
		this._AttacheDetacheMouseDown(false, oCible, this.m_fMouseDown);
	};

	// GP 22/04/2013 : TB76700 : Gestion sp�cifique du d�filement en largeur
	__WDDragTouch.prototype._vbOnMouseDown = function _vbOnMouseDown(/*oEvent*/)
	{
		// Appel de la classe de base
		return WDDrag.prototype._vbOnMouseDown.apply(this, arguments);
	};

	// Defilement par le doigt
	__WDDragTouch.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
	{
		// Appel de la classe de base
		WDDrag.prototype._vOnMouseMove.apply(this, arguments);
		// D�filement de la table
		this.m_pfCallback(-this.nGetOffsetPosX(oEvent), -this.nGetOffsetPosY(oEvent), oEvent);
		// Force la nouvelle position pour avoir un offset
		this.m_nPosX = this._nGetPosXEvent(oEvent);
		this.m_nPosY = this._nGetPosYEvent(oEvent);
	};
	
	return __WDDragTouch;
})();

//////////////////////////////////////////////////////////////////////////
// Classe pour l'�mulation du DnD avec du touch

var WDDragDnDNatifEmule = (function ()
{
	"use strict";

	function __WDDragDnDNatifEmule(oDnDNatif)
	{
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDDrag.prototype.constructor.apply(this, [0, 100]);

			ms_tabEmulation.push(this);

			this.m_oDnDNatif = oDnDNatif;

			// Hook de _InitElement et _LibereElement
			var oThis = this;
			this.m_pfInitElement = oDnDNatif._InitElement;
			oDnDNatif._InitElement = function () { __WDDragDnDNatifEmule.prototype._InitElement.apply(oThis, arguments); };
			this.m_pfLibereElement = oDnDNatif._LibereElement;
			oDnDNatif._LibereElement = function () { __WDDragDnDNatifEmule.prototype._LibereElement.apply(oThis, arguments); };

			this.m_tabCibles = [];
			this.m_tabDragOver = [];
			this.m_oFantome = null;
			this.m_tabData = [];
		}
	}
	// Declare l'heritage
	__WDDragDnDNatifEmule.prototype = new WDDrag();
	// Surcharge le constructeur qui a ete efface
	__WDDragDnDNatifEmule.prototype.constructor = __WDDragDnDNatifEmule;

	var ms_tabEmulation = [];

	// Hook de _InitElement et _LibereElement
	__WDDragDnDNatifEmule.prototype._InitElement = function _InitElement(oElement)
	{
		// Si on est source : intercepte le onmousedown
		if (0 < this.m_oDnDNatif.m_nSource)
		{
			this._AttacheDetacheMouseDown(true, oElement, this.m_fMouseDown);
		}
		// Si on est cible : se place dans la liste (globale) des cibles
		if (0 < this.m_oDnDNatif.m_nCible)
		{
			this.m_tabCibles.push(oElement);
		}

		// Appel de la m�thode initiale
		this.m_pfInitElement.apply(this.m_oDnDNatif, arguments);
	};
	__WDDragDnDNatifEmule.prototype._LibereElement = function _LibereElement(oElement)
	{
		// Si on est source : fin de l'interception de onmousedown
		if (0 < this.m_oDnDNatif.m_nSource)
		{
			this._AttacheDetacheMouseDown(false, oElement, this.m_fMouseDown);
		}
		// Si on est cible : se retire de la liste (globale) des cibles
		if (0 < this.m_oDnDNatif.m_nCible)
		{
			var nIndice = clWDUtil.nDansTableau(this.m_tabCibles, oElement, true);
			if (clWDUtil.nElementInconnu !== nIndice)
			{
				this.m_tabCibles.splice(nIndice, 1);
			}
		}

		// Appel de la m�thode initiale
		this.m_pfLibereElement.apply(this.m_oDnDNatif, arguments);
	};

	// Gestion des ev�nements pour l'�mulation
	__WDDragDnDNatifEmule.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent)
	{
		// Appel de la classe de base
		if (!WDDrag.prototype._vbOnMouseDown.apply(this, arguments))
		{
			return false;
		}

		// Construit l'objet event
		var nXEvent = this._nGetPosXEvent(oEvent);
		var nYEvent = this._nGetPosYEvent(oEvent);
		var oEventDnD = this.__oConstruitEvent(oEvent, nXEvent, nYEvent);

		// Drag start
		this.m_oDnDNatif.m_fDragStart(oEventDnD);

		// Cr�ation du fantome
		var oFantome = document.createElement("div");
		oFantome.style.position = "absolute";
		oFantome.style.width = "50px";
		oFantome.style.height = "50px";
		oFantome.style.opacity = "0.5";
		oFantome.style.backgroundColor = "#808080";
		oFantome.style.left = clWDUtil.GetDimensionPxPourStyle(nXEvent + 10);
		oFantome.style.top = clWDUtil.GetDimensionPxPourStyle(nYEvent + 10);
		this.m_oFantome = document.body.appendChild(oFantome);
	};
	__WDDragDnDNatifEmule.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
	{
		// Appel de la classe de base
		WDDrag.prototype._vOnMouseMove.apply(this, arguments);

		// Construit l'objet event
		var nXEvent = this._nGetPosXEvent(oEvent);
		var nYEvent = this._nGetPosYEvent(oEvent);
		var oEventDnD = this.__oConstruitEvent(oEvent, nXEvent, nYEvent);

		// Notifie tous les objets
		clWDUtil.bForEach(ms_tabEmulation, function (oDnDNatifEmule)
		{
			// Calcule la liste des �l�ments survol�
			var tabDragOver = oDnDNatifEmule.__tabGetDragOver(oEvent, oEventDnD, nXEvent, nYEvent);

			// DragEnter
			// => El�ments qui n'�tait pas encore survol�s
			clWDUtil.bForEach(tabDragOver, function (oDragOver)
			{
				if (clWDUtil.nElementInconnu === clWDUtil.nDansTableau(oDnDNatifEmule.m_tabDragOver, oDragOver, true))
				{
					// @@@ Changer le target pour oDragOver ?
					oDnDNatifEmule.m_oDnDNatif.m_fDragEnter(oEventDnD);
				}

				return true;
			});

			// DragOver
			// => Tous les �l�ments survol�s
			clWDUtil.bForEach(tabDragOver, function (/*oDragOver*/)
			{
				// @@@ Changer le target pour oDragOver ?
				oDnDNatifEmule.m_oDnDNatif.m_fDragOver(oEventDnD);

				return true;
			});

			// DragExit
			// => El�ments qui ne sont plus survol�s
			clWDUtil.bForEach(oDnDNatifEmule.m_tabDragOver, function (oDragOver)
			{
				if (clWDUtil.nElementInconnu === clWDUtil.nDansTableau(tabDragOver, oDragOver, true))
				{
					// @@@ Changer le target pour oDragOver ?
					oDnDNatifEmule.m_oDnDNatif.m_fDragExit(oEventDnD);
				}

				return true;
			});

			// MAJ de la liste des �l�ments survol�s
			oDnDNatifEmule.m_tabDragOver = tabDragOver;

			return true;
		});

		// D�placement du fantome
		if (this.m_oFantome)
		{
			this.m_oFantome.style.left = clWDUtil.GetDimensionPxPourStyle(nXEvent + 10);
			this.m_oFantome.style.top = clWDUtil.GetDimensionPxPourStyle(nYEvent + 10);
		}
	};
	__WDDragDnDNatifEmule.prototype._vOnMouseUp = function _vOnMouseUp(oEvent)
	{
		// Construit l'objet event
		var nXEvent = this._nGetPosXEvent(oEvent);
		var nYEvent = this._nGetPosYEvent(oEvent);
		var oEventDnD = this.__oConstruitEvent(oEvent, nXEvent, nYEvent);

		// Notifie tous les objets
		clWDUtil.bForEach(ms_tabEmulation, function (oDnDNatifEmule)
		{
			// Drop
			// => Tous les �l�ments survol�s
			clWDUtil.bForEach(oDnDNatifEmule.m_tabDragOver, function (/*oDragOver*/)
			{
				// @@@ Changer le target pour oDragOver ?
				oDnDNatifEmule.m_oDnDNatif.m_fDrop(oEventDnD);

				return true;
			});

			// Vide la liste des �l�ments survol�s
			oDnDNatifEmule.m_tabDragOver = [];

			return true;
		});

		// Drag End
		this.m_oDnDNatif.m_fDragEnd(oEventDnD);

		// Suppression du fantome
		if (this.m_oFantome)
		{
			this.m_oFantome.parentNode.removeChild(this.m_oFantome);
			this.m_oFantome = null;
		}

		// Libere les data
		this.m_tabData = [];

		// Appel de la classe de base
		WDDrag.prototype._vOnMouseUp.apply(this, arguments);
	};

	// Conversion d'un �v�nement touch en �v�nement DnD
	__WDDragDnDNatifEmule.prototype.__oConstruitEvent = function __oConstruitEvent(oEvent, nXEvent, nYEvent)
	{
		var oThis = this;

		var oEventDnD = clWDUtil.oCloneObjet(oEvent);
		oEventDnD.target = oEventDnD.explicitOriginalTarget = oEventDnD.currentTarget = oEventDnD.srcElement = document.elementFromPoint(nXEvent, nYEvent);
		oEventDnD.dataTransfer =
		{
			types: this.m_oDnDNatif.ms_tabTypes,
			getData: function (sTypeDonnees) { return oThis.m_tabData[sTypeDonnees]; },
			setData: function (sTypeDonnees, sDonnees) { oThis.m_tabData[sTypeDonnees] = sDonnees; },
			effectAllowed: "all",
			dropEffect: "copy"
		};

		return oEventDnD;
	};

	// Calcule la liste des �l�ments survol�
	__WDDragDnDNatifEmule.prototype.__tabGetDragOver = function __tabGetDragOver(oEvent, oEventDnD/*, nXEvent, nYEvent*/)
	{
		var tabDragOver = [];

		clWDUtil.bForEach(this.m_tabCibles, function (oCible)
		{
			// Si la cible est sous le curseur
			if (clWDUtil.bEstFils(oEventDnD.target, oCible))
			{
				tabDragOver.push(oCible);
			}

			return true;
		});

		return tabDragOver;
	};
})();