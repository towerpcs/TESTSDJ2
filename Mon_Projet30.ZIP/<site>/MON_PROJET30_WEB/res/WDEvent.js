// WDEvent.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - La page
///#GLOBALS _PAGE_
// - WDUtil.js
///#GLOBALS HookOnXXX UnhookOnXXX


//////////////////////////////////////////////////////////////////////////
// Manipulation des evenements

// Manipulation de la liste des evenements (singleton)
var clWDEventMain = (function ()
{
	"use strict";

	// Manipulation d'un evenement
	var WDEvent = (function ()
	{
		function __WDEvent(fCallback, oCibleDOM, tabEvenementNom, bCapture)
		{
			// Memorise les parametres (pour la liberation)
			this.m_fCallback = fCallback;
			this.m_oCibleDOM = oCibleDOM;
			this.m_tabEvenementNom = tabEvenementNom;
			this.m_bCapture = bCapture;

			// Attache l'evement
			HookOnXXX(this.m_oCibleDOM, this.m_tabEvenementNom[0], this.m_tabEvenementNom[1], this.m_fCallback, this.m_bCapture);
		}

		// Supprime un evenement
		__WDEvent.prototype.Libere = function Libere()
		{
			// Detache l'evement
			UnhookOnXXX(this.m_oCibleDOM, this.m_tabEvenementNom[0], this.m_tabEvenementNom[1], this.m_fCallback, this.m_bCapture);
		};

		return __WDEvent;
	})();

	// Initialise le tableaux des evenements
	var ms_tabEvenements = {};
	var ms_nEvenementSuivant = 1;

	// Tableau des evenements predefinis
	// Format : [ "Nom IE", "Nom autres" ]
	var ms_tabEvenementsNom = [
		[ "onclick",				"click"				],	// 0 : onclick
		[ "ondblclick",				"dblclick"			],	// 1 : ondblclick (existe ?)
		[ "onmousedown",			"mousedown"			],	// 2 : onmousedown
		[ "onmouseup",				"mouseup"			],	// 3 : onmouseup
		[ "onmousemove",			"mousemove"			],	// 4 : onmousemove
		[ "onmouseout",				"mouseout"			],	// 5 : onmouseout
		[ "onmouseover",			"mouseover"			],	// 6 : onmouseover
		[ "onkeydown",				"keydown"			],	// 7 : onkeydown
		[ "onkeypress",				"keypress"			],	// 8 : onkeypress
		[ "onkeyup",				"keyup"				],	// 9 : onkeyup
		[ "onfocus",				"focus"				],	// 10 : onfocus
		[ "onblur",					"blur"				],	// 11 : onblur
		[ "onchange",				"change"			],	// 12 : onchange
		[ "onselect",				"select"			],	// 13 : onselect
		[ "onload",					"load"				],	// 14 : onload
		[ "onunload",				"unload"			],	// 15 : onunload
		[ "onreset",				"reset"				],	// 16 : onreset
		[ "onsubmit",				"submit"			],	// 17 : onsubmit
		[ "onresize",				"resize"			],	// 18 : onresize
		[ "onscroll",				"scroll"			],	// 19 : onscroll
		[ "onorientationchange",	"orientationchange"	],	// 20 : onorientationchange
		[ "ontouchstart",			"touchstart"		],	// 21 : ontouchstart
		[ "ontouchmove",			"touchmove"			],	// 22 : ontouchmove
		[ "ontouchend",				"touchend"			],	// 23 : ontouchend
		[ "ontouchcancel",			"touchcancel"		],	// 24 : ontouchcancel
		[ "ongesturestart",			"gesturestart"		],	// 25 : ongesturestart
		[ "ongesturechange",		"gesturechange"		],	// 26 : ongesturechange
		[ "ongestureend",			"gestureend"		],	// 27 : ongestureend
		[ "onbeforeunload",			"beforeunload"		],	// 28 : onbeforeunload
		[ "onmouseenter",			"mouseenter"		],	// 29 : onmouseenter
		[ "onmouseleave",			"mouseleave"		]	// 30 : onmouseleave
	//	[ "onhelp",					"help"				]	// ?? : onhelp
	];
	var ms_nOptionCapture = 1;
	var ms_nDOMWindow = 0;
	var ms_nDOMDocument = 1;
	var ms_nDOMBody = 2;
	var ms_nDOMForm = 3;
	var ms_nInterruptionAction = 1;
	var ms_nInterruptionPropagation = 2;

	// Traitement du parametre oCallback : recupere un pointeur de fonction
	function __fGetCallback (oCallback)
	{
		// Selon le type du parametre
		switch (typeof oCallback)
		{
		case "string":
			// Chaine, tente un eval
			try
			{
				var fCallback = eval(oCallback);
				if (fCallback && (typeof fCallback === "function"))
				{
					return fCallback;
				}
			}
			catch (e)
			{
			}
			// Non trouve
			return null;
		case "function":
			// Fonction : retourne directement la valeur
			return oCallback;
		default:
			// Autres (en particulier les objets) : erreur
			return null;
		}
	}

	// Traitement du parametre oCible : recupere un objet DOM
	function __oGetCibleDOM (oCible)
	{
		// Selon le type du parametre
		switch (typeof oCible)
		{
		case "string":
			// Chaine, tente un getElementById
			var oCibleDom = document.getElementById(oCible);
			if (oCibleDom)
			{
				return oCibleDom;
			}
			// Puis un getElementsByName
			var tabCibleDom = document.getElementsByName(oCible);
			if (tabCibleDom && tabCibleDom.length && tabCibleDom[0])
			{
				return tabCibleDom[0];
			}
			// Non trouve
			return null;
		case "number":
			switch (oCible)
			{
			case ms_nDOMWindow:
				return window;
			case ms_nDOMDocument:
				return window.document;
			case ms_nDOMBody:
				return window.document.body;
			case ms_nDOMForm:
				return _PAGE_;
			}
			// Non trouve
			return null;
		default:
			// Autres (en particulier les objets) : retourne directement la valeur
			return oCible;
		}
	}

	// Traitement du parametre oEvenement : recupere une description d'evement
	function __tabGetEvenementNom(oEvenement)
	{
		// Selon le type du parametre
		switch (typeof oEvenement)
		{
		case "number":
			// Entier, regarde dans le tableau des description
			return ms_tabEvenementsNom[oEvenement];
		case "string":
			// Chaine, retourne la valeur pour tous les navigateurs
			return [oEvenement, oEvenement];
		default:
			// Autres (en particulier les objets et les tableaux) : retourne directement la valeur
			return oEvenement;
		}
	}

	// Traitement du parametre oOptions : transforme en entier
	function __nGetOptions (oOptions)
	{
		// Selon le type du parametre
		switch (typeof oOptions)
		{
		case "number":
			// Entier, retourne directement sa valeur
			return oOptions;
		default:
			// Autres (en particulier les chaines) : tente une transformation
			// Si elle echoue on recoit NaN que l'on traite dans l'appelant
			return parseInt(oOptions, 10);
		}
	}

	return {
		nEvenement : function (oCallback, oCible, oEvenement, oOptions)
		{
			// oCallback : recupere un pointeur de fonction
			var fCallback = __fGetCallback(oCallback);

			// oCible : recupere un objet DOM
			var oCibleDOM = __oGetCibleDOM(oCible);

			// oEvenement : recupere une description d'evement
			var tabEvenementNom = __tabGetEvenementNom(oEvenement);

			// oOptions : transforme en entier
			var nOptions = __nGetOptions(oOptions);

			// Si les parametres sont valides, appel la version interne
			if (fCallback && oCibleDOM && tabEvenementNom && !isNaN(nOptions))
			{
				// Cree le nouvel evenement
				var bCapture = (nOptions & ms_nOptionCapture) != 0;
				var oWDEvent = new WDEvent(fCallback, oCibleDOM, tabEvenementNom, bCapture);

				// L'enregistre
				var nEvenementID = ms_nEvenementSuivant++;
				ms_tabEvenements[nEvenementID] = oWDEvent;

				// Et retourne son ID
				return nEvenementID;
			}
			else
			{
				// Erreur
				return 0;
			}
		},

		// Supprime un evenement de la liste des evenements
		bFinEvenement : function (nEvenementID)
		{
			// Le retrouve dans la liste
			var oEvenement = ms_tabEvenements[nEvenementID];

			// Si on l'a bien trouve
			if (oEvenement)
			{
				// Le detache
				oEvenement.Libere();

				// Le supprime de la liste
				delete ms_tabEvenements[nEvenementID];

				return true;
			}
			else
			{
				// Echec evenement inexistant ou deja libere
				return false;
			}
		},

		// Interruption de l'evenement en cours
		bInterruptionEvenement : function (oEvent, nOptions)
		{
			// Interruption de l'action
			// Interruption de la propagation
			return clWDUtil.bStopPropagationCond(oEvent, (nOptions & ms_nInterruptionAction) != 0, (nOptions & ms_nInterruptionPropagation) != 0);
		}
	};
})();
