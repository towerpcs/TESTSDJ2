// WDGeoLocalisation.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS WDTypeAvance WDErreur
// - WDChamp.js
///#GLOBALS WDChamp WDChampParametres
// - WDCarteAPI.js
///#GLOBALS WDCarteAPI WDCarteGoogleMaps
// - WDAJAX.js
///#GLOBALS clWDAJAXMain
// - WD.js
///#GLOBALS NSPCS
var gpsActive = 1;
var gpsDesactive = 2;
var gpsErreurOK = 0;
var gpsErreurDroit = 1;
var gpsErreurPosition = 2;
var gpsErreurTimeout = 3;
var gpsPCSSuivi = null;
var gpsPCSPosition = null;


//Converti degrees en radians
if (typeof (Number.prototype.toRad) === "undefined")
{
	//vers radians
	Number.prototype.toRad = function(bMod360)
	{
		return (bMod360 ? (this % 360) : this) * Math.PI / 180;
	};
	//vers degrees
	Number.prototype.toDeg = function(bMod360)
	{
		return (bMod360 ? (this % 360) : this) * (180 / Math.PI);
	};
}

function WDGeoPosition(oPosition)
{
	// Si on est pas dans l'init d'un prototype (pas de test dans le cas d'une classe dino finale car le framework appelle le constructeur sans param�tre pour cr�er un dino)
	//if (arguments.length)
	{
		WDTypeAvance.prototype.constructor.apply(this, [true]);
		if (!oPosition)
		{
			// Coordonn�es � 0 (comme en code serveur)
			oPosition = { coords: { latitude: 0, longitude: 0 } };
		}
		this.m_oPosition = oPosition;
	}
};

WDGeoPosition.prototype = new WDTypeAvance();

WDGeoPosition.prototype.constructor = WDGeoPosition;

//Indices propri�t�s dino G�oPosition
WDGeoPosition.prototype.ms_nIdPropLatitude = 0;
WDGeoPosition.prototype.ms_nIdPropLongitude = 1;
WDGeoPosition.prototype.ms_nIdPropAltitude = 2;
WDGeoPosition.prototype.ms_nIdPropAltitudeValide = 3;
WDGeoPosition.prototype.ms_nIdPropDirection = 4;
WDGeoPosition.prototype.ms_nIdPropDirectionValide = 5;
WDGeoPosition.prototype.ms_nIdPropPrecision = 6;
WDGeoPosition.prototype.ms_nIdPropPrecisionValide = 7;
WDGeoPosition.prototype.ms_nIdPropVitesse = 8;
WDGeoPosition.prototype.ms_nIdPropVitesseValide = 9;
WDGeoPosition.prototype.ms_nIdPropDateMesure = 10;
WDGeoPosition.prototype.ms_nIdPropPositionValide = 11;

function bValDef(v, n)
{
	return (v !== null) && (v !== undefined) && (v !== NaN) && (n || (v >= 0));
}

function sComplete0(s, n)
{
	s = "" + s;
	while (s.length < n)
	{
		s = "0" + s;
	}
	return s;
}

WDGeoPosition.prototype.GetLatitude = function()
{
	return this.m_oPosition.coords.latitude;
};
WDGeoPosition.prototype.GetLongitude = function()
{
	return this.m_oPosition.coords.longitude;
};
//rebond pour que les coordonn�es soient � plat dans le json
WDGeoPosition.prototype.SetLatitude = function(d)
{
	// GP 02/11/2016 : Vu par MF : Force la conversion en r�el.
	// Certains appels (en particulier WDCarte.prototype._oGetPositionFromLatLng) transmettent une chaine. Sauf que la valeur est ensuite stock�e comme chaine.
	// => Ajout de parseFloat
	this.m_oPosition.m_dLatitude = this.m_oPosition.coords.latitude = parseFloat(d);
};
WDGeoPosition.prototype.SetLongitude = function(d)
{
	// GP 02/11/2016 : Vu par MF : Force la conversion en r�el.
	// Certains appels (en particulier WDCarte.prototype._oGetPositionFromLatLng) transmettent une chaine. Sauf que la valeur est ensuite stock�e comme chaine.
	// => Ajout de parseFloat
	this.m_oPosition.m_dLongitude = this.m_oPosition.coords.longitude = parseFloat(d);
};

WDGeoPosition.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
		case this.ms_nIdPropLatitude:
			return this.GetLatitude();
		case this.ms_nIdPropLongitude:
			return this.GetLongitude();
		case this.ms_nIdPropAltitude:
			return bValDef(this.m_oPosition.coords.altitude, true) ? this.m_oPosition.coords.altitude : 0;
		case this.ms_nIdPropAltitudeValide:
			return bValDef(this.m_oPosition.coords.altitude, true);
		case this.ms_nIdPropDirection:
			return bValDef(this.m_oPosition.coords.heading) ? this.m_oPosition.coords.heading : 0;
		case this.ms_nIdPropDirectionValide:
			return bValDef(this.m_oPosition.coords.heading);
		case this.ms_nIdPropPrecision:
			return bValDef(this.m_oPosition.coords.accuracy) ? this.m_oPosition.coords.accuracy : 0;
		case this.ms_nIdPropPrecisionValide:
			return bValDef(this.m_oPosition.coords.accuracy);
		case this.ms_nIdPropVitesse:
			return bValDef(this.m_oPosition.coords.speed) ? this.m_oPosition.coords.speed : 0;
		case this.ms_nIdPropVitesseValide:
			return bValDef(this.m_oPosition.coords.speed);
		case this.ms_nIdPropDateMesure:
			var d = new Date(this.m_oPosition.timestamp);
			return sComplete0(d.getFullYear(), 4) + sComplete0(d.getMonth() + 1, 2) + sComplete0(d.getDate(), 2) + sComplete0(d.getHours(), 2) + sComplete0(d.getMinutes(), 2) + sComplete0(d.getSeconds(), 2) + sComplete0(Math.floor((this.m_oPosition.timestamp % 1000) / 10), 2);
		case this.ms_nIdPropPositionValide:
			return bValDef(this.GetLatitude()) && bValDef(this.GetLongitude());
		default:
			return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};

//vrai si le coordonn�es sont valides, faux sinon
WDGeoPosition.prototype.vbGetPositionValide = function vbGetPositionValide()
{
	return WDCarteAPI.bValideCoordonnees(this.m_dLatitude,this.m_dLongitude);
};

//Modification propri�t� dino G�oPosition
//Entr�e :	nPropri�t�	Indice propri�t� � modifier
//			oValeur		Valeur de la propri�t�
WDGeoPosition.prototype.SetProp = function SetProp(nPropriete, oValeur)
{
	//Position
	var oPosition = this.m_oPosition;
	//Position ?
	if (oPosition != null)
	{
		//Oui => coordonn�es
		var oCoord = oPosition.coords;
		//Coordonn�es ?
		if (oCoord != null)
		{
			//Oui => modification propri�t�
			switch (nPropriete)
			{
				case this.ms_nIdPropLatitude:
					this.SetLatitude(oValeur);
					break;
				case this.ms_nIdPropLongitude:
					this.SetLongitude(oValeur);
					break;
				case this.ms_nIdPropAltitude:
					oCoord.altitude = oValeur;
					break;
				case this.ms_nIdPropDirection:
					oCoord.heading = oValeur;
					break;
				case this.ms_nIdPropPrecision:
					oCoord.accuracy = oValeur;
					break;
				case this.ms_nIdPropVitesse:
					oCoord.speed = oValeur;
					break;
				case this.ms_nIdPropDateMesure:
					var oDate = new Date;
					clWDUtil.bSetDateHeureFromWL(oDate, oValeur, false, true, true);
					oPosition.timestamp = oDate.getTime();
					break;
				default:
					WDTypeAvance.prototype.SetProp.apply(this, arguments);
			}
		}
	}
};

// Fonctions WL GPS
function WDGPS() { }
//tableau des suivis et d�placements
WDGPS.gtabWatch = [];
//indice du seul watch branch� sur l'�coute du GPS du navigateur
WDGPS.gnIdSurveillancePosition = -1;

function GPSEtat()
{
	return ((navigator != null) && (navigator.geolocation != null)) ? gpsActive : gpsDesactive;
}

function GPSPCSAppelProcPosition(f, p)
{
	if (gpsPCSPosition != null)
	{
		//Position ?
		if (gpsPCSPosition.m_oPosition != null)
		{
			//Oui => coordonn�es ?
			if (gpsPCSPosition.m_oPosition.coords != null)
			{
				//Oui => lib�ration coordonn�es
				delete gpsPCSPosition.m_oPosition.coords;
			}
			//Lib�ration position
			delete gpsPCSPosition.m_oPosition;
		}
		delete gpsPCSPosition;
	}
	//Clonage position pour pouvoir modifier car objet syst�me non modifiable
	var oCopiePosition = clWDUtil.oCloneObjet(p, p);
	//Clonage coordonn�es pour pouvoir modifier car objet syst�me non modifiable
	oCopiePosition.coords = clWDUtil.oCloneObjet(oCopiePosition.coords, oCopiePosition.coords);
	//Cr�ation dino g�oposition � partir de position syst�me clon�e pour pouvoir modifier la position
	gpsPCSPosition = new WDGeoPosition(oCopiePosition);
	f(gpsPCSPosition, gpsErreurOK);
}

function GPSPCSAppelProcErreur(f, e)
{
	f(null, e.code);
}

function GPSRecuperePosition(f, nDelaiMs)
{
	if (GPSEtat() != gpsActive)
	{
		return;
	}
	navigator.geolocation.getCurrentPosition(function(p) { GPSPCSAppelProcPosition(f, p); }, function(e) { GPSPCSAppelProcErreur(f, e); }, { timeout: (undefined === nDelaiMs) ? 60000 : nDelaiMs });
}

function GPSSuitDeplacement(f, nDelai, nDistance)
{
	if (GPSEtat() != gpsActive)
	{
		return;
	}
	if (gpsPCSSuivi != null)
	{
		//retire du tablau de suivi car on ne peut pas suivre 2 d�placements
		WDGPS._RetireEcoute(gpsPCSSuivi);
		gpsPCSSuivi = null;
	}
	if (f == null)
	{
		return;
	}

	//rajoute l'�coute de la position
	gpsPCSSuivi = WDGPS._AjouteEcoute(
	{
		//proc�dure
		fCallback: f
		//infos en cas de d�tection de position
	, nDelai: nDelai
	, nDistance: nDistance
	});

	//retourne l'indice de l'�coute du suivi
	return gpsPCSSuivi;
}

//retire une ecoute de position/d�placement
WDGPS._RetireEcoute = function(nIndice)
{
	//supprimer du tableau
	WDGPS.gtabWatch[nIndice] = undefined;
	//retire la suiveillance de position si devenue inutile
	WDGPS._Term();
};
//ajoute une ecoute de position/d�placement
WDGPS._AjouteEcoute = function(oOptions)
{
	//d�marre la suiveillance de position
	WDGPS._Init();
	return WDGPS.gtabWatch.push(oOptions) - 1;
};

//lance l'�coute des positions
WDGPS._Init = function _Init()
{
	if (WDGPS.gnIdSurveillancePosition === -1)
	{
		WDGPS._SurveillancePosition();
	}
};
//apr�s un GPSTermine ou le dernier GPSArr�teD�tection
WDGPS._Term = function _Term(bForceTerm)
{
	if (WDGPS.gnIdSurveillancePosition > -1)
	{
		if (bForceTerm !== true)
		{
			//reste t il des watch valides ?
			for (var i = 0; i < WDGPS.gtabWatch.length; ++i)
			{
				if (WDGPS.gtabWatch[i] !== undefined)
				{
					return;
				}
			}
		}
		//raz le tableau
		WDGPS.gtabWatch = [];
		//on arr�te d'�couter car il n'y a plus de watch � rappeler
		navigator.geolocation.clearWatch(WDGPS.gnIdSurveillancePosition);
	}
};
WDGPS._SurveillancePosition = function _SurveillancePosition()
{
	WDGPS.gnIdSurveillancePosition = navigator.geolocation.watchPosition(
	//en cas de succ�s
		function(/*Position*/p)
		{
			WDGPS._SurveillancePositionSucces(p);
		}
	//en cas d'erreur
		, function(/*PositionError*/e)
		{
			WDGPS._SurveillancePositionErreur(e);
		}
	//pas d'options
	//,PositionOptions
	);
};


//source : http://www.movable-type.co.uk/scripts/latlong.html
WDGPS._gnDistanceEnMetreEntreDeuxPoints = function _nDistanceEnMetreEntreDeuxPoints(lat1, lon1, lat2, lon2)
{
	var R = 6371; // km
	var f1 = Number(lat1).toRad();
	var f2 = Number(lat2).toRad();
	var df = Number(lat2 - lat1).toRad();
	var dd = Number(lon2 - lon1).toRad();

	var a = Math.sin(df / 2) * Math.sin(df / 2) +
			Math.cos(f1) * Math.cos(f2) *
			Math.sin(dd / 2) * Math.sin(dd / 2);
	var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

	var d = R * c;
	return d;
};
WDGPS._gnAzimutEntreDeuxPoints = function _gnAzimutEntreDeuxPoints(lat1, lon1, lat2, lon2)
{
	var f1 = Number(lat1).toRad();
	var f2 = Number(lat2).toRad();
	var dd = Number(lon2 - lon1).toRad();

	var y = Math.sin(dd) * Math.cos(f2);
	var x = Math.cos(f1) * Math.sin(f2) -
		Math.sin(f1) * Math.cos(f2) * Math.cos(dd);

	return Math.atan2(y, x).toDeg();
};

//cas ok
WDGPS._SurveillancePositionSucces = function _SurveillancePositionSucces(p)
{
	//envoi l'info d'erreur aux callabcks
	for (var i = WDGPS.gtabWatch.length - 1; i > -1; --i)
	{
		var oSuivi = WDGPS.gtabWatch[i];
		if (!oSuivi)
		{
			continue;
		}
		//d�lai pr�cis� ?
		if ((oSuivi.nDelai || -1) > -1)
		{
			if (oSuivi.nPremierTimestamp)
			{
				//d�lai �coul� ?
				if (p.timestamp - oSuivi.nPremierTimestamp > (oSuivi.nDelai * 10))
				{
					WDGPS._RetireEcoute(i);
					continue;
				}
			}
			else
			{
				oSuivi.nPremierTimestamp = p.timestamp;
			}
		}

		//c'est une des d�tections
		if (oSuivi.nLatitude !== undefined)
		{
			//v�rifie si elle doit �tre notifi�e ou pas
			var nRayon = oSuivi.nRayon || 50;
			//latitude hors rayon
			//longitude hors rayon
			var bEstDansZone = nRayon >= WDGPS._gnDistanceEnMetreEntreDeuxPoints(
				p.coords.latitude, p.coords.longitude
			, oSuivi.nLatitude, oSuivi.nLongitude
			);
			//par d�faut on consid�re qu'on n'est pas dans la zone
			if (oSuivi.bEtaitDansZone === undefined)
			{
				oSuivi.bEtaitDansZone = false;
			}
			//n'appeler que si on rentre ou sort de la zone
			//pas si on est dans le m�me �tat
			if (bEstDansZone == oSuivi.bEtaitDansZone)
			{
				continue;
			}
			oSuivi.bEtaitDansZone = bEstDansZone;
		}
		//cas du suivi
		else
		{
			//gestion du distance
			var nDistance = oSuivi.nDistance || 5;
			if (oSuivi.oDernierePosition)
			{
				var nDistanceActuelle = WDGPS._gnDistanceEnMetreEntreDeuxPoints(
					p.coords.latitude, p.coords.longitude
				, oSuivi.oDernierePosition.latitude, oSuivi.oDernierePosition.longitude
				);
				//distance insuffisante?
				if (nDistanceActuelle < nDistance)
				{
					continue;
				}
			}
			oSuivi.oDernierePosition = p.coords;
		}
		//appelle la callback
		GPSPCSAppelProcPosition(oSuivi.fCallback, p);
	}
};
//cas erreur
WDGPS._SurveillancePositionErreur = function _SurveillancePositionErreur(e)
{
	//envoi l'info d'erreur aux callabcks
	for (var i = 0; i < WDGPS.gtabWatch.length; ++i)
	{
		var oSuivi = WDGPS.gtabWatch[i];
		if (!oSuivi)
		{
			continue;
		}
		GPSPCSAppelProcErreur(oSuivi.fCallback, e);
	}
};

//GPSArr�teD�tection
function GPSArreteDetection(nID)
{
	//retire la suiveillance de position devenue inutile
	WDGPS._RetireEcoute(nID);
}

//Indique la fin de l�utilisation des fonctions de g�olocalisation. En effet, les fonctions de g�olocalisation peuvent,
//selon le param�trage choisi et la fr�quence d�appel, consommer beaucoup de ressources sur le p�riph�rique
//(batterie, bande passante, etc.). La fonction GPSTermine doit �tre appel�e lorsque les fonctions de localisation
//ne sont plus utilis�es par l�application.
function GPSTermine()
{
	//retire la suiveillance de position devenue inutile
	WDGPS._Term(true);
}
//GPSD�tectePosition
//Demande � �tre notifi� lorsque le p�riph�rique arrive � proximit� d�une position donn�e.
//<R�sultat> = GPSD�tectePosition(<Nom de la proc�dure> , <Latitude> , <Longitude> [, <Rayon> [, <D�lai>]])
function GPSDetectePosition(fCallback, nLatitude, nLongitude, nRayon, nDelai)
{
	if (GPSEtat() != gpsActive)
	{
		return;
	}
	//rajoute l'�coute de la position
	return WDGPS._AjouteEcoute(
	{
		//proc�dure
		fCallback: fCallback
		//infos en cas de d�tection de position
	, nLatitude: nLatitude
	, nLongitude: nLongitude
	, nRayon: nRayon
	, nDelai: nDelai
	});
}

function GPSDernierePosition()
{
	return gpsPCSPosition;
}

// Fonction WL g�oAzimut()
function geoAzimut(oPosition1, oPosition2) 
{
	var oMarqueur1 = new WDDinoMarqueur(oPosition1);
	var oMarqueur2 = new WDDinoMarqueur(oPosition2);
	return WDGPS._gnAzimutEntreDeuxPoints(oMarqueur1.m_oPosition.GetLatitude(), oMarqueur1.m_oPosition.GetLongitude(), oMarqueur2.m_oPosition.GetLatitude(), oMarqueur2.m_oPosition.GetLongitude());
}

// Fonction WL geoDistance
function geoDistance(oPosition1, oPosition2, oUnite) 
{
	var geoMetre = 1;
	var geoKilometre = 2;
	var geoMile = 3;
	var KM_TO_MILES = 0.621371192;

	// calcul de la distance entre 2 points
	var oMarqueur1 = new WDDinoMarqueur(oPosition1);
	var oMarqueur2 = new WDDinoMarqueur(oPosition2);
	var DistanceEnKilometre = WDGPS._gnDistanceEnMetreEntreDeuxPoints(oMarqueur1.m_oPosition.GetLatitude(), oMarqueur1.m_oPosition.GetLongitude(), oMarqueur2.m_oPosition.GetLatitude(), oMarqueur2.m_oPosition.GetLongitude());

	// unit� � renvoyer
	var nUnite = geoMetre;
	if (typeof oUnite === "number")
	{
		nUnite = oUnite;
	}

	// retourne la distance dans la bonne unit�
	switch (nUnite)
	{
		case geoKilometre:
			return DistanceEnKilometre;

		case geoMile:
			return DistanceEnKilometre * KM_TO_MILES;

		default:
			return DistanceEnKilometre * 1000;
	}
}

// Fonction WL g�oR�cup�reZone
function geoRecupereZone(sDescription)
{
	// R�cup�ration objet JSON r�sultat r�qu�te r�cup�ration position
	var clJSON = WDCarteGoogleMaps.prototype.clJSONAppelRequeteRecupPositionAdresse(sDescription);
	// R�cup�ration r�sultats
	var tabResultat = clJSON.results;
	// R�sultats OK ?
	if (!tabResultat)
	{
		// Non => erreur
		throw new WDErreur(1300);
	}
	// R�cup�ration �tendue
	var clEtendue = tabResultat[0].geometry.viewport;
	// R�cup�ration position nord est
	var clPosNordEst = clEtendue.northeast;
	// R�cup�ration position sud ouest
	var clPosSudOuest = clEtendue.southwest;
	// Positions nord ouest et sud est
	return new NSPCS.NSValues.CValeursMultiples([new WDGeoPosition({ coords: { latitude: clPosNordEst.lat, longitude: clPosSudOuest.lng } }), new WDGeoPosition({ coords: { latitude: clPosSudOuest.lat, longitude: clPosNordEst.lng } })]);
}

// Dino base objet carte
function WDDinoBaseObjetCarte()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		WDTypeAvance.prototype.constructor.apply(this, [true]);
		this.m_sNom = this.sCreerIdentifiant();
		this.m_sDescription = '';
		this.m_sActionClic = '';
		//id interne
		this.m_czIDInterne = undefined;
		this.m_nAltitude = 0;
	}
};

WDDinoBaseObjetCarte.prototype = new WDTypeAvance();

WDDinoBaseObjetCarte.prototype.constructor = WDDinoBaseObjetCarte;

// R�cup�ration position objet
// clObjet			Objet dont on r�cup�re la position
// bDonneeServeur	Indique si l'objet est une donn�e serveur
WDDinoBaseObjetCarte.prototype.RecuperePosition = function (/*clObjet, bDonneeServeur*/)
{
};

// R�cup�ration position objet
// clObjet			Objet dont on r�cup�re la position
// bDonneeServeur	Indique si l'objet est une donn�e serveur
WDDinoBaseObjetCarte.prototype.RecuperePositionObjet = function (clObjet, bDonneeServeur)
{
	// L'objet est une donn�e serveur ?
	if (!bDonneeServeur)
	{
		// Non => rien � faire
		return;
	}
	// Indique si l'objet a des coordonn�es ?
	var bPosition = (clObjet.m_dLatitude !== undefined) && (clObjet.m_dLongitude !== undefined);
	// GP 24/10/2014 : Normalement toujours le cas
	clWDUtil.WDDebug.assert(bPosition);
	// L'objet a des coordonn�es ?
	if (bPosition)
	{
		// Oui => r�cup�ration coordonn�es
		this.SetLatitude(clObjet.m_dLatitude);
		this.SetLongitude(clObjet.m_dLongitude);
	}
};

//rebond pour que les coordonn�es soient � plat dans le json
WDDinoBaseObjetCarte.prototype.SetLatitudePosition = function (oPosition, d)
{
	oPosition.SetLatitude(d);
	this.m_dLatitude = d;
};
WDDinoBaseObjetCarte.prototype.SetLongitudePosition = function (oPosition, d)
{
	oPosition.SetLongitude(d);
	this.m_dLongitude = d;
};

// Clonage
// clSource			Objet � cloner
// bDonneeServeur	Indique si l'objet � copier est une donn�e serveur
WDDinoBaseObjetCarte.prototype.Clone = function (clSource, bDonneeServeur)
{
	// V�rification des propri�t�s
	for (var sPropriete in clSource)
	{
		// Propri�t� propre � l'objet ?
		if (clSource.hasOwnProperty(sPropriete))
		{
			// Oui => r�cup�ration valeur propri�t� objet source
			var clValeur = clSource[sPropriete];
			// Valeur propri�t� objet destination
			var clValeurDest = this[sPropriete];
			// Donn�e serveur ou propri�t� pas de m�me type que celle de l'objet source ?
			if (bDonneeServeur || ((typeof clValeurDest) != (typeof clValeur)))
			{
				// Indique si valeur trait�e
				var bTraite = false;
				// Donn�e serveur
				if (bDonneeServeur)
				{
					// Oui => valeur trait� par d�faut
					bTraite = true;
					// La propri�t� r�cup�r�e est un tableau de points non vide ?
					if (clWDUtil.isArray(clValeur) && clValeur.length && (clValeur[0].m_dLatitude !== undefined))
					{
						// Oui => on vide le tableau destination
						clValeurDest.length = 0;
						// R�cup�ration tableau points donn�e serveur
						clWDUtil.bForEach(clValeur, function (clPoint)
						{
							// Ajout point dans tableau destination
							clValeurDest.push(WDDinoBaseObjetCarte.clRecupPositionDonnerServeur(clPoint));
							// On continue le parcours
							return true;
						});
					}
					// La propri�t� affect�e est une couleur ?
					else if (clValeurDest instanceof clWDUtil.WDDinoCouleur)
					{
						// Oui => r�cup�ration couleur
						clValeurDest.SetProp(7, clValeur);
					}
					// La propri�t� destination est un dino mais pas la prori�t� source (cas ou la donn�e copi�e est une donn�e serveur dans objet � plat qui n'est pas une instance de classe) ?
					else if ((clValeurDest instanceof WDTypeAvance) && (!(clValeur instanceof WDTypeAvance)))
					{
						// Oui => on clone la propri�t� source
						WDDinoBaseObjetCarte.prototype.Clone.apply(clValeurDest, [clValeur, bDonneeServeur])
					}
					else
					{
						// Non => valeur non trait�e
						bTraite = false;
					}
				}
				// Valeur trait�e ?
				if (!bTraite)
				{
					// Non => on copie la propri�t� de l'objet source car si donn�e serveur le clonage d'objet ne fait rien et sinon le clonage de la classe de base peut provoquer une erreur
					this[sPropriete] = clValeur;
				}
			}
		}
	}
	// Clonage
	WDTypeAvance.prototype.Clone.apply(this, arguments);
};

// Copie
// clSource			Objet � copier
// bDonneeServeur	Indique si l'objet � copier est une donn�e serveur
WDDinoBaseObjetCarte.prototype.Copie = function (clSource, bDonneeServeur)
{
	// Objet source du bon type ou donn�es serveur ?
	if ((!clSource) || ((!bDonneeServeur) && (this.constructor != clSource.constructor)))
	{
		// Non => pas de copie
		return;
	}
	// M�morisation id interne
	var sId = this.m_czIDInterne;
	// Copie
	this.Clone(clSource, bDonneeServeur);
	// Restauration id interne
	this.m_czIDInterne = sId;
	// R�cup�ration position
	this.RecuperePosition(clSource, bDonneeServeur);
};

// Clone objet
WDDinoBaseObjetCarte.prototype.clClone = function ()
{
	// Cr�ation clone
	var clClone = new this.constructor();
	// Clonage
	clClone.Clone(this);
	// Objet clon�
	return clClone;
};

// ID interne pour le cas de Google maps
WDDinoBaseObjetCarte.prototype.SetIDInterne = function (pszID)
{
	this.m_czIDInterne = pszID;
};
WDDinoBaseObjetCarte.prototype.pszGetIDInterne = function ()
{
	return this.m_czIDInterne;
};

// Classe d'un objet
// Entr�e :	clObjet	Objet ddont on veut la classe
// Sortie : Classe objet
WDDinoBaseObjetCarte.clClasseObjet = function (clObjet)
{
	// Non => recherche classe objet � partir du type
	switch (clObjet.m_eType)
	{
		// Cercle
		case WDDinoCarteForme.eTypeFormeCercle:
			return WDDinoCarteCercle;
		// Polygone :
		case WDDinoCarteForme.eTypeFormePolygone:
			return WDDinoCartePolygone;
		// Polyligne :
		case WDDinoCarteForme.eTypeFormePolyligne:
			return WDDinoCartePolyligne;
		// Autre :
		default:
			break;
	}
};

// S�rialisation position objet pour json serveur
// Entr�e :	clObjet		Objet pour lequel on veut s�rialiser la position
//			clPosition	Position � s�rialiser
WDDinoBaseObjetCarte.SerialisePositionPourJsonServeur = function (clObjet, clPosition)
{
	// S�rialisation latitude (on n'appelle pas directement la m�thode car la position n'est pas un objet mais une copie avec juste les membres)
	clObjet.m_dLatitude = WDGeoPosition.prototype.GetLatitude.apply(clPosition);
	// S�rialisation longitude (on n'appelle pas directement la m�thode car la position n'est pas un objet mais une copie avec juste les membres)
	clObjet.m_dLongitude = WDGeoPosition.prototype.GetLongitude.apply(clPosition);
};

// R�cup�ration position objet donn�e serveur
// Entr�e :	clObjet		Objet donn�e serveur dont on r�cup�re la position
// Sortie :	Position r�cup�r�e
WDDinoBaseObjetCarte.clRecupPositionDonnerServeur = function (clObjet)
{
	// Cr�ation position
	var clPosition = new WDGeoPosition();
	// R�cup�ration latitude
	clPosition.SetLatitude(clObjet.m_dLatitude);
	// R�cup�ration longitude
	clPosition.SetLongitude(clObjet.m_dLongitude);
	// Position r�cup�r�e
	return clPosition;
};

// Nettoyage pour json serveur
WDDinoBaseObjetCarte.prototype.NettoyagePourJsonServeur = function ()
{
	delete this.m_czIDInterne;
};

// Clonage objet nettoy� pour json serveur
WDDinoBaseObjetCarte.prototype.clCloneNettoyePourJsonServeur = function ()
{
	// Clonage objet
	var clClone = this.clClone();
	// Nettoyage clone
	clClone.NettoyagePourJsonServeur();
	// Clone nettoy�
	return clClone;
};

// Indice propri�t� opacit� dino couleur
WDDinoBaseObjetCarte.nPropOpaciteCouleur = 3;

// Opacit� dino couleur
// Entr�e :	oDinoCouleur	Dino couleur dont on veut l'opacit�
// Sortie : Opacit� dino couleur
WDDinoBaseObjetCarte.nOpaciteDinoCouleur = function (oDinoCouleur)
{
	return oDinoCouleur.GetProp(WDDinoBaseObjetCarte.nPropOpaciteCouleur);
};

// Modification opacit� dino couleur
// Entr�e :	oDinoCouleur	Dino couleur dont on veut l'opacit�
//			nOpacite		Opacit�
WDDinoBaseObjetCarte.SetOpaciteDinoCouleur = function (oDinoCouleur, nOpacite)
{
	oDinoCouleur.SetProp(WDDinoBaseObjetCarte.nPropOpaciteCouleur, nOpacite);
};

// Opacit� maximale dino couleur
WDDinoBaseObjetCarte.nOpaciteMaxDinoCouleur = WDCarteAPI.nOpaciteCouleurWLMax;

// Couleur dino couleur sans opacit�
// Entr�e :	oDinoCouleur	Dino couleur dont on veut la couleur sans opacit�
// Sortie : Couleur sans opacit� dino couleur
WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur = function (oDinoCouleur)
{
	// R�cup�ration opacit�
	var nOpacite = WDDinoBaseObjetCarte.nOpaciteDinoCouleur(oDinoCouleur);
	// Indique si transparence
	var bTransparence = (nOpacite < WDDinoBaseObjetCarte.nOpaciteMaxDinoCouleur);
	// Transparence ?
	if (bTransparence)
	{
		// Oui => on enl�ve la transparence
		WDDinoBaseObjetCarte.SetOpaciteDinoCouleur(oDinoCouleur, WDDinoBaseObjetCarte.nOpaciteMaxDinoCouleur);
	}
	// On r�cup�re la couleur
	var sCouleur = oDinoCouleur.toString();
	// Transparence ?
	if (bTransparence)
	{
		// Oui => on remet la transparence
		WDDinoBaseObjetCarte.SetOpaciteDinoCouleur(oDinoCouleur, nOpacite);
	}
	// Couleur
	return sCouleur;
};

//dino objet carte avec image
function WDDinoCarteObjetAvecImage()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		WDDinoBaseObjetCarte.prototype.constructor.apply(this, arguments);

		this.m_sImage = '';
		this.m_eAlignement = WDCarteAPI.emqHaut;
		this.m_oPosition = new WDGeoPosition();
		this.m_nOpacite = 100;
	}
};

WDDinoCarteObjetAvecImage.prototype = new WDDinoBaseObjetCarte();

WDDinoCarteObjetAvecImage.prototype.constructor = WDDinoCarteObjetAvecImage;

// R�cup�ration position objet
// clObjet			Objet dont on r�cup�re la position
// bDonneeServeur	Indique si l'objet est une donn�e serveur
WDDinoCarteObjetAvecImage.prototype.RecuperePosition = function (clObjet, bDonneeServeur)
{
	this.RecuperePositionObjet(clObjet, bDonneeServeur);
};

WDDinoCarteObjetAvecImage.prototype.SetPosition = function SetPosition(oPosition)
{
	this.m_oPosition = oPosition;
	if (this.m_oPosition)
	{
		this.SetLatitude(this.m_oPosition.GetLatitude());
		this.SetLongitude(this.m_oPosition.GetLongitude());
	}
};
//rebond pour que les coordonn�es soient � plat dans le json
WDDinoCarteObjetAvecImage.prototype.SetLatitude = function (d)
{
	this.SetLatitudePosition(this.m_oPosition, d);
};
WDDinoCarteObjetAvecImage.prototype.SetLongitude = function (d)
{
	this.SetLongitudePosition(this.m_oPosition, d);
};

// Nettoyage pour json serveur
WDDinoCarteObjetAvecImage.prototype.NettoyagePourJsonServeur = function ()
{
	WDDinoBaseObjetCarte.prototype.NettoyagePourJsonServeur.apply(this, []);
	delete this.m_oPosition;
};

// Dino image marqueur
// Entr�e :	clSource	Objet � copier
function WDDinoMarqueurImage(clSource)
{
	// Si on est pas dans l'init d'un prototype (pas de test dans le cas d'une classe dino finale car le framework appelle le constructeur sans param�tre pour cr�er un dino)
	//if (arguments.length)
	{
		WDTypeAvance.prototype.constructor.apply(this, [true]);

		this.m_eForme = WDCarteAPI.nFormeRond;
		this.m_nTaille = 40;
		this.m_sTexte = "";
		this.m_clCouleur = new clWDUtil.WDDinoCouleur(0xffffff);
		this.m_clCouleurFond = new clWDUtil.WDDinoCouleur(0xe8731a);
		// Copie source
		this.Clone(clSource);
	}
}

WDDinoMarqueurImage.prototype = new WDTypeAvance();

WDDinoMarqueurImage.prototype.constructor = WDDinoMarqueurImage;

WDDinoMarqueurImage.prototype.ms_sNomPourParam = "MARQUEURIMAGE";

// Propri�t�s
WDDinoMarqueurImage.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
		case 0:
			return this.m_eForme;
		case 1:
			return this.m_nTaille;
		case 2:
			return this.m_sTexte;
		case 3:
			return this.m_clCouleur;
		case 4:
			return this.m_clCouleurFond;
		default:
			return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};
WDDinoMarqueurImage.prototype.SetProp = function SetProp(nPropriete, oValeur)
{
	switch (nPropriete)
	{
		case 0:
			this.m_eForme = oValeur;
			break;
		case 1:
			this.m_nTaille = oValeur;
			break;
		case 2:
			this.m_sTexte = oValeur;
			break;
		case 3:
			this.m_clCouleur = new clWDUtil.WDDinoCouleur(oValeur);;
			break;
		case 4:
			this.m_clCouleurFond = new clWDUtil.WDDinoCouleur(oValeur);;
			break;
	}
};

//dino Marqueur
function WDDinoMarqueur(oPosition)
{
	// Si on est pas dans l'init d'un prototype (pas de test dans le cas d'une classe dino finale car le framework appelle le constructeur sans param�tre pour cr�er un dino)
	//if (arguments.length)
	{
		WDDinoCarteObjetAvecImage.prototype.constructor.apply(this, [true]);

		this.m_bIsDeplacable = false;
		this.m_bClusteur = false;
		this.m_bAvecPopup = false;
		this.m_sActionClicPopup = '';
		this.m_sActionClicDeplacement = "";
		this.m_sNote = "";
		this.m_bMarqueurImage = false;
		this.m_clMarqueurImage = new WDDinoMarqueurImage();

		// GP 24/10/2014 : Attention "!x instanceof y" != "!(x instanceof y)" (le premier test si !x est une instance de y ce qui n'est pas possible !x est un bool�en...)
		if (!(oPosition instanceof WDGeoPosition))
		{
			//un POD �crit par le serveur
			//var oThis = this;
			if (clWDUtil.isObject(oPosition))
			{
				//clWDUtil.bForEachIn(oPosition, function(sMembre/*, oValeur*/)
				//{
				//	// On teste bien si c'est this a le membre (pour ne copier que des membres existant)
				//	if (oThis.hasOwnProperty(sMembre))
				//	{
				//		oThis[sMembre] = oPosition[sMembre];
				//	}
				//	return true;
				//});
				// Copie source
				this.Copie(oPosition, true);
				// R�cup�ration position marqueur source
				//this.RecuperePositionObjet(oPosition, true);
			}
			//[lat,lng]
			else if (clWDUtil.isArray(oPosition))
			{
				this.SetLatitude(oPosition[0]);
				this.SetLongitude(oPosition[1]);
			}
		}
		else
		{
			//r�cup�re la position (undefined, WDGeoPosition, [lat,lng])
			// GP 24/10/2014 : @@@ Il ne faut pas faire une copie de l'objet position ? Si on fait plusieurs CarteAjouteMarqueur a partir du m�me g�oPosition, tous les marqueurs seront d�plac�s
			// sur le dernier point.
			this.SetPosition(oPosition);
		}
	}
};

WDDinoMarqueur.prototype = new WDDinoCarteObjetAvecImage();

WDDinoMarqueur.prototype.constructor = WDDinoMarqueur;

WDDinoMarqueur.prototype.ms_sNomPourParam = "MARQUEUR";

// Cr�ation identifiant
WDDinoMarqueur.prototype.sCreerIdentifiant = function ()
{
	// Identifiant marqueur
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypeMarqueur);
};

// Modification dans api carte
// Entr�e :	oChampCarte	Champ carte
//			nId			Identifiant objet modifi�
WDDinoMarqueur.prototype.bModifApiCarte = function (oChampCarte, nId)
{
	// Modification dans carte
	return oChampCarte.m_oModele.MAP_ModifieMarqueur
		(
		nId,
		this.m_oPosition.GetLatitude(),
		this.m_oPosition.GetLongitude(),
		// GP 08/12/2017 : TB106285 : Le 4i�me param�tre de MAP_ModifieMarqueur est le "libell�". En ajout ce membre re�oit oMarqueur.m_sDescription.
		// Il faut faire pareil en modification sinon on perd la bulle.
		this.m_sDescription, // oMarqueur.m_sNom
		this.m_bMarqueurImage ? "" : clWDUtil.sGetCheminImage(this.m_sImage, clWDUtil.sGetCheminImage(oChampCarte.m_oParametres.m_sImage, '')),
		this.m_eAlignement,
		undefined,
		this.m_sActionClic,
		this.m_nOpacite,
		this.m_nAltitude,
		this.m_bIsDeplacable,
		this.m_sActionClicDeplacement,
		this.m_bAvecPopup,
		this.m_sNom,
		this.m_sActionClicPopup,
		this.m_bClusteur,
		this.m_bMarqueurImage ? this.m_clMarqueurImage.m_eForme : WDCarteAPI.nFormeNonDefini,
		this.m_bMarqueurImage ? this.m_clMarqueurImage.m_nTaille : 0,
		this.m_bMarqueurImage ? this.m_clMarqueurImage.m_sTexte : "",
		this.m_bMarqueurImage ? WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_clMarqueurImage.m_clCouleur) : "",
		this.m_bMarqueurImage ? WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_clMarqueurImage.m_clCouleur) : 0,
		this.m_bMarqueurImage ? WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_clMarqueurImage.m_clCouleurFond) : "",
		this.m_bMarqueurImage ? WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_clMarqueurImage.m_clCouleurFond) : 0,
		""
		);
};

// Propri�t�s
WDDinoMarqueur.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
		case 0:
			return this.m_sNom;
		case 1:
			return this.m_oPosition;
		case 2:
			return this.m_sDescription;
		case 3:
			return this.m_bMarqueurImage ? this.m_clMarqueurImage : this.m_sImage;
		case 4:
			return this.m_sActionClic;
		case 5:
			return this.m_eAlignement;
		case 6:
			return this.m_nOpacite;
		case 7:
			return this.m_bIsDeplacable;
		case 8:
			return this.m_nAltitude;
		case 9:
			return this.m_bClusteur;
		case 10:
			return this.m_bAvecPopup;
		case 11:
			return this.m_sActionClicPopup;
		case 12:
			return this.m_sActionClicDeplacement;
		case 13:
			return this.m_sNote;
		default:
			return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};
WDDinoMarqueur.prototype.SetProp = function SetProp(nPropriete, oValeur)
{
	switch (nPropriete)
	{
		case 0:
			this.m_sNom = oValeur;
			break;
		case 1:
			this.SetPosition(oValeur);
			break;
		case 2:
			this.m_sDescription = oValeur;
			break;
		case 3:
			//((this.m_bMarqueurImage = (oValeur instanceof WDDinoMarqueurImage)) ? this.m_clMarqueurImage : this.m_sImage) = oValeur;
			if ((this.m_bMarqueurImage = (oValeur instanceof WDDinoMarqueurImage)) == true)
			{
				this.m_clMarqueurImage = oValeur;
			}
			else
			{
				this.m_sImage = oValeur;
			}
			break;
		case 4:
			this.m_sActionClic = oValeur;
			break;
		case 5:
			this.m_eAlignement = oValeur;
			break;
		case 6:
			this.m_nOpacite = oValeur;
			break;
		case 7:
			this.m_bIsDeplacable = oValeur;
			break;
		case 8:
			this.m_nAltitude = oValeur;
			break;
		case 9:
			this.m_bClusteur = oValeur;
			break;
		case 10:
			this.m_bAvecPopup = oValeur;
			break;
		case 11:
			this.m_sActionClicPopup = oValeur;
			break;
		case 12:
			this.m_sActionClicDeplacement = oValeur;
		case 13:
			this.m_sNote = oValeur;
		default:
			WDTypeAvance.prototype.SetProp.apply(this, arguments);
	}
};


//dino Adresse

function WDDinoAdresse()
{
	// Si on est pas dans l'init d'un prototype (pas de test dans le cas d'une classe dino finale car le framework appelle le constructeur sans param�tre pour cr�er un dino)
	//if (arguments.length)
	{
		WDTypeAvance.prototype.constructor.apply(this, [true]);

		//Nom de la rue, route ou avenue. Cette propri�t� est optionnelle.
		this.m_czRue='';
		//Nom de la ville. Cette propri�t� est optionnelle.
		this.m_czVille='';
		//Code postal de l'adresse. Cette propri�t� est optionnelle.
		this.m_czCodePostal='';
		//R�gion associ�e � l'adresse (�tat pour une adresse aux Etats-Unis, land pour une adresse en Allemagne, Comt�, province, ...). Cette propri�t� est optionnelle.
		this.m_czRegion='';
		//Nom du pays. Cette propri�t� est optionnelle.
		this.m_czPays='';
		//Position g�ographique de l'adresse : latitude et longitude. Cette propri�t� est optionnelle.
		//Si la position g�ographique n�est pas sp�cifi�e, la propri�t� ..PositionValide de la variable g�oPosition vaut Faux.
		this.m_pclGeoPosition=undefined;
		
		//iOS et/ou Android uniquement : 
		//Etiquette pour les types d'adresses personnalis�es (optionnel).
		//Si la propri�t� ..Type ne correspond pas � la constante adressePersonnalis�e, la valeur de cette propri�t� sera ignor�e.
		//this.m_czEtiquette='';		
		//Etiquette pour les types d'adresses personnalis�es (optionnel).
		//Si la propri�t� ..Type ne correspond pas � la constante adressePersonnalis�e, la valeur de cette propri�t� sera ignor�e.
		//this.m_nType=adresseBureau;
	}
};

WDDinoAdresse.prototype = new WDTypeAvance();

WDDinoAdresse.prototype.constructor = WDDinoAdresse;

// Propri�t�s
WDDinoAdresse.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
		case 0:
			return this.m_czRue;
		case 1:
			return this.m_czVille;
		case 2:
			return this.m_czCodePostal;
		case 3:
			return this.m_czRegion;
		case 4:
			return this.m_czPays;
		case 5:
			if (!this.m_pclGeoPosition)
			{
				this.m_pclGeoPosition = new WDGeoPosition();
			}
			return this.m_pclGeoPosition;
		default:
			return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};

WDDinoAdresse.prototype.SetProp = function SetProp(nPropriete, oValeur)
{
	switch (nPropriete)
	{
		case 0:
			this.m_czRue = oValeur;			
			break;
		case 1:
			this.m_czVille = oValeur;			
			break;
		case 2:
			this.m_czCodePostal = oValeur;			
			break;
		case 3:
			this.m_czRegion = oValeur;			
			break;
		case 4:
			this.m_czPays = oValeur;			
			break;
		case 5:			
			if (!this.m_pclGeoPosition)
			{
				this.m_pclGeoPosition = new WDGeoPosition();
			}
			this.m_pclGeoPosition.Clone( oValeur );
			break;		
		default:
			WDTypeAvance.prototype.SetProp.apply(this, arguments);
	}
};
// Adresse compl�te
//cf. void CDinoAdresse::vGetAdresseComplete		(OUT CXString& rcszAdresseComplete) const
WDDinoAdresse.prototype.vGetAdresseComplete = function vGetAdresseComplete()
{
	var rcszAdresseComplete = '';

	// On concat�ne la valeur de tous les membres renseign�s (sauf la position), s�par�s par une virgule
	// (Code inspir� du code JAVA/Android)
	if (this.m_czRue)
	{
		rcszAdresseComplete += this.m_czRue;
	}
	if (this.m_czVille)
	{
		if (rcszAdresseComplete) 
		{
			rcszAdresseComplete += ", ";
		}
		rcszAdresseComplete += this.m_czVille;
	}
	if (this.m_czCodePostal)
	{
		if (rcszAdresseComplete) 
		{
			rcszAdresseComplete += ", ";
		}
		rcszAdresseComplete += this.m_czCodePostal;
	}
	if (this.m_czRegion)
	{
		if (rcszAdresseComplete) 
		{
			rcszAdresseComplete += ", ";
		}
		rcszAdresseComplete += this.m_czRegion;
	}
	if (this.m_czPays)
	{
		if (rcszAdresseComplete) 
		{
			rcszAdresseComplete += ", ";
		}
		rcszAdresseComplete += this.m_czPays;
	}
	// Etiquette ?
	return rcszAdresseComplete;
};

// Couleur par d�faut
WDDinoCarteForme.nCouleurDefaut = 0xe8731a;
// Opacit� fond par d�faut
WDDinoCarteForme.nOpaciteDefaut = 0x23;
// Types de forme
WDDinoCarteForme.eTypeFormeCercle = 0;
WDDinoCarteForme.eTypeFormePolygone = 1;
WDDinoCarteForme.eTypeFormePolyligne = 2;

//dino forme carte
function WDDinoCarteForme()
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		// Le type doit �tre le premier membre pour permettre � la d�s�rialisation c�t� serveur de cr�er le bon type d'objet avant de continuer � analyser le json de l'objet s�rialis�
		this.m_eType = WDDinoCarteForme.eTypeFormeCercle;

		WDDinoBaseObjetCarte.prototype.constructor.apply(this, arguments);

		this.m_sTrait = new clWDUtil.WDDinoCouleur(WDDinoCarteForme.nCouleurDefaut);
		this.m_eTrait = WDCarteAPI.nTypeTraitContinu;
		this.m_nEpaisseur = 2;
	}
};

WDDinoCarteForme.prototype = new WDDinoBaseObjetCarte();

WDDinoCarteForme.prototype.constructor = WDDinoCarteForme;

// Couleur de fond par d�faut
WDDinoCarteForme.prototype._oCouleurFondDefaut = function ()
{
	// Couleur par d�faut
	var oCouleur = new clWDUtil.WDDinoCouleur(WDDinoCarteForme.nCouleurDefaut);
	// Opacit� par d�faut
	WDDinoBaseObjetCarte.SetOpaciteDinoCouleur(oCouleur, WDDinoCarteForme.nOpaciteDefaut);
	// Couleur de find par d�faut
	return oCouleur;
};

//dino polyligne carte
//Entr�e :	bInitPrototypeOuObjetSource	Indique si init prototype (cas particulier classe dino dont constructeur appel� depuis framework sans param�tre, mais dont d�rive une autre classe), ou objet source
//			bDonneeServeur				Indique si l'objet source esr une donn�e serveur
function WDDinoCartePolyligne(bInitPrototypeOuObjetSource, bDonneeServeur)
{
	// Si on est pas dans l'init d'un prototype
	if (bInitPrototypeOuObjetSource !== true)
	{
		WDDinoCarteForme.prototype.constructor.apply(this, [true]);

		this.m_eType = WDDinoCarteForme.eTypeFormePolyligne;
		this.m_tabPoints = [];
		this.m_bGeodesique = false;
		// Objet source OK et on cr�e un dino polyligne ?
		if (bInitPrototypeOuObjetSource && (this.constructor == WDDinoCartePolyligne))
		{
			// Oui => copie source
			this.Copie(bInitPrototypeOuObjetSource, bDonneeServeur);
		}
	}
};

WDDinoCartePolyligne.prototype = new WDDinoCarteForme();

WDDinoCartePolyligne.prototype.constructor = WDDinoCartePolyligne;

WDDinoCartePolyligne.prototype.ms_sNomPourParam = "CARTEPOLYLIGNE";

// Cr�ation identifiant
WDDinoCartePolyligne.prototype.sCreerIdentifiant = function ()
{
	// Identifiant polyligne
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypePolyligne);
};

// Nettoyage pour json serveur
WDDinoCartePolyligne.prototype.NettoyagePourJsonServeur = function ()
{
	// Appel m�thode classe de base
	WDDinoCarteForme.prototype.NettoyagePourJsonServeur.apply(this, []);
	// Nettoyage tableau points
	clWDUtil.bForEach(this.m_tabPoints, function (clPoint)
	{
		// S�rialisation position pour serveur
		WDDinoBaseObjetCarte.SerialisePositionPourJsonServeur(clPoint, clPoint);
		// Nettoyage position
		delete clPoint.m_oPosition;
		// On continue le parcours
		return true;
	});
};

// Conversion tableau de points en tableau de points API
WDDinoCartePolyligne.prototype._tabPointApi = function ()
{
	//Tableau points API
	var tabPointApi = [];
	// Conversion tableau points en tableau points API
	clWDUtil.bForEach(this.m_tabPoints, function (oPoint)
	{
		// Ajout point API correspondant au point dans tableau points API
		tabPointApi.push([oPoint.GetLatitude(), oPoint.GetLongitude()]);
		// On continue le parcours
		return true;
	});
	//Tableau points API
	return tabPointApi;
};

// Ajout carte API
// Entr�e :	clCarte			Carte API
//			nIdOptionnel	Identifiant optionnel objet ajout�
// Sortie : Identifiant objet ajout�
WDDinoCartePolyligne.prototype.nAjoutApiCarte = function (clCarte, nIdOptionnel)
{
	return clCarte.MAP_AjoutePolyligne
		(
		this._tabPointApi(),
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sTrait),
		this.m_eTrait,
		this.m_nEpaisseur,
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sTrait),
		this.m_sDescription,
		this.m_sActionClic,
		this.m_nAltitude,
		this.m_bGeodesique,
		nIdOptionnel
		);
};

// Modification dans api carte
// Entr�e :	oChampCarte	Champ carte
//			nId			Identifiant objet modifi�
WDDinoCartePolyligne.prototype.bModifApiCarte = function (oChampCarte, nId)
{
	return oChampCarte.m_oModele.MAP_ModifiePolyligne
		(
		nId,
		this._tabPointApi(),
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sTrait),
		this.m_eTrait,
		this.m_nEpaisseur,
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sTrait),
		this.m_sDescription,
		this.m_sActionClic,
		this.m_nAltitude,
		this.m_bGeodesique
		);
};

// Propri�t�s
WDDinoCartePolyligne.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
		case 0:
			return this.m_sNom;
		case 1:
			return this.m_sDescription;
		case 2:
			return this.m_sTrait;
		case 3:
			return this.m_eTrait;
		case 4:
			return this.m_nAltitude;
		case 5:
			return this.m_sActionClic;
		case 6:
			return this.m_nEpaisseur;
		case 7:
			return this.m_bGeodesique;
		case 8:
			return this.m_tabPoints;
		default:
			return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};
WDDinoCartePolyligne.prototype.SetProp = function SetProp(nPropriete, oValeur)
{
	switch (nPropriete)
	{
		case 0:
			this.m_sNom = oValeur;
			break;
		case 1:
			this.m_sDescription = oValeur;
			break;
		case 2:
			this.m_sTrait = new clWDUtil.WDDinoCouleur(oValeur);
			break;
		case 3:
			this.m_eTrait = oValeur;
			break;
		case 4:
			this.m_nAltitude = oValeur;
			break;
		case 5:
			this.m_sActionClic = oValeur;
			break;
		case 6:
			this.m_nEpaisseur = oValeur;
			break;
		case 7:
			this.m_bGeodesique = oValeur;
			break;
		case 8:
			this.m_tabPoints = oValeur;
			break;
		default:
			WDTypeAvance.prototype.SetProp.apply(this, arguments);
	}
};

//dino polygone carte
// Entr�e :	clSource					Objet � copier
//			bDonneeServeur				Indique si l'objet source esr une donn�e serveur
function WDDinoCartePolygone(clSource, bDonneeServeur)
{
	// Si on est pas dans l'init d'un prototype (pas de test dans le cas d'une classe dino finale car le framework appelle le constructeur sans param�tre pour cr�er un dino)
	//if (arguments.length)
	{
		WDDinoCartePolyligne.prototype.constructor.apply(this, arguments);

		this.m_eType = WDDinoCarteForme.eTypeFormePolygone;
		this.m_sRemplissage = this._oCouleurFondDefaut();
		// Copie source
		this.Copie(clSource, bDonneeServeur);
	}
};

WDDinoCartePolygone.prototype = new WDDinoCartePolyligne(true);

WDDinoCartePolygone.prototype.constructor = WDDinoCartePolygone;

WDDinoCartePolygone.prototype.ms_sNomPourParam = "CARTEPOLYGONE";

// Cr�ation identifiant
WDDinoCartePolygone.prototype.sCreerIdentifiant = function ()
{
	// Identifiant polygone
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypePolygone);
};

// Ajout carte API
// Entr�e :	clCarte			Carte API
//			nIdOptionnel	Identifiant optionnel objet ajout�
// Sortie : Identifiant objet ajout�
WDDinoCartePolygone.prototype.nAjoutApiCarte = function (clCarte, nIdOptionnel)
{

	return clCarte.MAP_AjoutePolygone
		(
		this._tabPointApi(),
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sTrait),
		this.m_eTrait,
		this.m_nEpaisseur,
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sTrait),
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sRemplissage),
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sRemplissage),
		this.m_sDescription,
		this.m_sActionClic,
		this.m_nAltitude,
		this.m_bGeodesique,
		nIdOptionnel
		);
};

// Modification dans api carte
// Entr�e :	oChampCarte	Champ carte
//			nId			Identifiant objet modifi�
WDDinoCartePolygone.prototype.bModifApiCarte = function (oChampCarte, nId)
{
	return oChampCarte.m_oModele.MAP_ModifiePolygone
		(
		nId,
		this._tabPointApi(),
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sTrait),
		this.m_eTrait,
		this.m_nEpaisseur,
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sTrait),
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sRemplissage),
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sRemplissage),
		this.m_sDescription,
		this.m_sActionClic,
		this.m_nAltitude,
		this.m_bGeodesique
		);
};

// Propri�t�s
WDDinoCartePolygone.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
		case 0:
			return this.m_sNom;
		case 1:
			return this.m_sDescription;
		case 2:
			return this.m_sActionClic;
		case 3:
			return this.m_sTrait;
		case 4:
			return this.m_sRemplissage;
		case 5:
			return this.m_eTrait;
		case 6:
			return this.m_nEpaisseur;
		case 7:
			return this.m_nAltitude;
		case 8:
			return this.m_bGeodesique;
		case 9:
			return this.m_tabPoints;
		default:
			return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};
WDDinoCartePolygone.prototype.SetProp = function SetProp(nPropriete, oValeur)
{
	switch (nPropriete)
	{
		case 0:
			this.m_sNom = oValeur;
			break;
		case 1:
			this.m_sDescription = oValeur;
			break;
		case 2:
			this.m_sActionClic = oValeur;
			break;
		case 3:
			this.m_sTrait = new clWDUtil.WDDinoCouleur(oValeur);
			break;
		case 4:
			this.m_sRemplissage = new clWDUtil.WDDinoCouleur(oValeur);
			break;
		case 5:
			this.m_eTrait = oValeur;
			break;
		case 6:
			this.m_nEpaisseur = oValeur;
			break;
		case 7:
			this.m_nAltitude = oValeur;
			break;
		case 8:
			this.m_bGeodesique = oValeur;
			break;
		case 9:
			this.m_tabPoints = oValeur;
			break;
		default:
			WDTypeAvance.prototype.SetProp.apply(this, arguments);
	}
};

//dino cercle carte
// Entr�e :	clSource		Objet � copier
//			bDonneeServeur	Indique si l'objet source esr une donn�e serveur
function WDDinoCarteCercle(clSource, bDonneeServeur)
{
	// Si on est pas dans l'init d'un prototype (pas de test dans le cas d'une classe dino finale car le framework appelle le constructeur sans param�tre pour cr�er un dino)
	//if (arguments.length)
	{
		WDDinoCarteForme.prototype.constructor.apply(this, [true]);

		this.m_eType = WDDinoCarteForme.eTypeFormeCercle;
		this.m_sRemplissage = this._oCouleurFondDefaut();
		this.m_oCentre = new WDGeoPosition();
		this.m_dRayon = 100;
		// Copie source
		this.Copie(clSource, bDonneeServeur);
	}
};

WDDinoCarteCercle.prototype = new WDDinoCarteForme();

WDDinoCarteCercle.prototype.constructor = WDDinoCarteCercle;

WDDinoCarteCercle.prototype.ms_sNomPourParam = "CARTECERCLE";

// R�cup�ration position objet
// clObjet			Objet dont on r�cup�re la position
// bDonneeServeur	Indique si l'objet est une donn�e serveur
WDDinoCarteCercle.prototype.RecuperePosition = function (clObjet, bDonneeServeur)
{
	this.RecuperePositionObjet(clObjet, bDonneeServeur);
};

// Cr�ation identifiant
WDDinoCarteCercle.prototype.sCreerIdentifiant = function ()
{
	// Identifiant cercle
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypeCercle);
};

// Nettoyage pour json serveur
WDDinoCarteCercle.prototype.NettoyagePourJsonServeur = function ()
{
	// Appel m�thode classe de base
	WDDinoCarteForme.prototype.NettoyagePourJsonServeur.apply(this, []);
	// S�rialisation position pour serveur
	WDDinoBaseObjetCarte.SerialisePositionPourJsonServeur(this, this.m_oCentre);
	// Nettoyage position
	delete this.m_oCentre;
};

//rebond pour que les coordonn�es soient � plat dans le json
WDDinoCarteCercle.prototype.SetLatitude = function (d)
{
	this.SetLatitudePosition(this.m_oCentre, d);
};
WDDinoCarteCercle.prototype.SetLongitude = function (d)
{
	this.SetLongitudePosition(this.m_oCentre, d);
};

// Ajout carte API
// Entr�e :	clCarte			Carte API
//			nIdOptionnel	Identifiant optionnel objet ajout�
// Sortie : Identifiant objet ajout�
WDDinoCarteCercle.prototype.nAjoutApiCarte = function (clCarte, nIdOptionnel)
{

	return clCarte.MAP_AjouteCercle
		(
		this.m_oCentre.GetLatitude(),
		this.m_oCentre.GetLongitude(),
		this.m_dRayon,
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sTrait),
		this.m_eTrait,
		this.m_nEpaisseur,
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sTrait),
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sRemplissage),
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sRemplissage),
		this.m_sDescription,
		this.m_sActionClic,
		this.m_nAltitude,
		nIdOptionnel
		);
};

// Modification dans api carte
// Entr�e :	oChampCarte	Champ carte
//			nId			Identifiant objet modifi�
WDDinoCarteCercle.prototype.bModifApiCarte = function (oChampCarte, nId)
{
	return oChampCarte.m_oModele.MAP_ModifieCercle
		(
		nId,
		this.m_oCentre.GetLatitude(),
		this.m_oCentre.GetLongitude(),
		this.m_dRayon,
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sTrait),
		this.m_eTrait,
		this.m_nEpaisseur,
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sTrait),
		WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(this.m_sRemplissage),
		WDDinoBaseObjetCarte.nOpaciteDinoCouleur(this.m_sRemplissage),
		this.m_sDescription,
		this.m_sActionClic,
		this.m_nAltitude
		);
};

// Propri�t�s
WDDinoCarteCercle.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
		case 0:
			return this.m_sNom;
		case 1:
			return this.m_sDescription;
		case 2:
			return this.m_oCentre;
		case 3:
			return this.m_dRayon;
		case 4:
			return this.m_sTrait;
		case 5:
			return this.m_sRemplissage;
		case 6:
			return this.m_eTrait;
		case 7:
			return this.m_nAltitude;
		case 8:
			return this.m_nEpaisseur;
		case 9:
			return this.m_sActionClic;
		default:
			return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};
WDDinoCarteCercle.prototype.SetProp = function SetProp(nPropriete, oValeur)
{
	switch (nPropriete)
	{
		case 0:
			this.m_sNom = oValeur;
			break;
		case 1:
			this.m_sDescription = oValeur;
			break;
		case 2:
			this.m_oCentre = oValeur;
			break;
		case 3:
			this.m_dRayon = oValeur;
			break;
		case 4:
			this.m_sTrait = new clWDUtil.WDDinoCouleur(oValeur);
			break;
		case 5:
			this.m_sRemplissage = new clWDUtil.WDDinoCouleur(oValeur);
			break;
		case 6:
			this.m_eTrait = oValeur;
			break;
		case 7:
			this.m_nAltitude = oValeur;
			break;
		case 8:
			this.m_nEpaisseur = oValeur;
			break;
		case 9:
			this.m_sActionClic = oValeur;
			break;
		default:
			WDTypeAvance.prototype.SetProp.apply(this, arguments);
	}
};

//dino image carte
// Entr�e :	clSource					Objet � copier
//			bDonneeServeur				Indique si l'objet source esr une donn�e serveur
function WDDinoCarteImage(clSource, bDonneeServeur)
{
	// Si on est pas dans l'init d'un prototype (pas de test dans le cas d'une classe dino finale car le framework appelle le constructeur sans param�tre pour cr�er un dino)
	//if (arguments.length)
	{
		WDDinoCarteObjetAvecImage.prototype.constructor.apply(this, [true]);

		this.m_eAlignement = WDCarteAPI.emqCentre;
		this.m_dLargeur = 0;
		this.m_dHauteur = 0;
		this.m_nAngleDegres = 0;
		// Copie source
		this.Copie(clSource, bDonneeServeur);
	}
};

WDDinoCarteImage.prototype = new WDDinoCarteObjetAvecImage();

WDDinoCarteImage.prototype.constructor = WDDinoCarteImage;

WDDinoCarteImage.prototype.ms_sNomPourParam = "CARTEIMAGE";

// Cr�ation identifiant
WDDinoCarteImage.prototype.sCreerIdentifiant = function ()
{
	// Identifiant image
	return WDCarteAPI.CreerIdentifiant(WDCarteAPI.nTypeImage);
};

// Ajout carte API
// Entr�e :	clCarte			Carte API
//			nIdOptionnel	Identifiant optionnel objet ajout�
// Sortie : Identifiant objet ajout�
WDDinoCarteImage.prototype.nAjoutApiCarte = function (clCarte, nIdOptionnel)
{

	return clCarte.MAP_AjouteImage
		(
		this.m_oPosition.GetLatitude(),
		this.m_oPosition.GetLongitude(),
		clWDUtil.sGetCheminImage(this.m_sImage, ""),
		this.m_dLargeur,
		this.m_dHauteur,
		this.m_eAlignement,
		this.m_nOpacite,
		this.m_sDescription,
		this.m_sActionClic,
		this.m_nAltitude,
		this.m_nAngleDegres,
		nIdOptionnel
		);
};

// Modification dans api carte
// Entr�e :	oChampCarte	Champ carte
//			nId			Identifiant objet modifi�
WDDinoCarteImage.prototype.bModifApiCarte = function (oChampCarte, nId)
{
	return oChampCarte.m_oModele.MAP_ModifieImage
		(
		nId,
		this.m_oPosition.GetLatitude(),
		this.m_oPosition.GetLongitude(),
		clWDUtil.sGetCheminImage(this.m_sImage, ""),
		this.m_dLargeur,
		this.m_dHauteur,
		this.m_eAlignement,
		this.m_nOpacite,
		this.m_sDescription,
		this.m_sActionClic,
		this.m_nAltitude,
		this.m_nAngleDegres
		);
};

// Propri�t�s
WDDinoCarteImage.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
		case 0:
			return this.m_sNom;
		case 1:
			return this.m_sDescription;
		case 2:
			return this.m_oPosition;
		case 3:
			return this.m_eAlignement;
		case 4:
			return this.m_dLargeur;
		case 5:
			return this.m_dHauteur;
		case 6:
			return this.m_nAngleDegres;
		case 7:
			return this.m_sImage;
		case 8:
			return this.m_sActionClic;
		case 9:
			return this.m_nOpacite;
		case 10:
			return this.m_nAltitude;
		default:
			return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};
WDDinoCarteImage.prototype.SetProp = function SetProp(nPropriete, oValeur)
{
	switch (nPropriete)
	{
		case 0:
			this.m_sNom = oValeur;
			break;
		case 1:
			this.m_sDescription = oValeur;
			break;
		case 2:
			this.SetPosition(oValeur);
			break;
		case 3:
			this.m_eAlignement = oValeur;
			break;
		case 4:
			this.m_dLargeur = oValeur;
			break;
		case 5:
			this.m_dHauteur = oValeur;
			break;
		case 6:
			this.m_nAngleDegres = oValeur;
			break;
		case 7:
			// GP 30/09/2020 : QW329573 : Il y a un risque de confusion entre cette propri�t� qui est une image et le DINO MarqueurImage (qui est la description d'une image du dino marqueur).
			if (oValeur instanceof WDDinoMarqueurImage)
			{
				// "Un �l�ment de type '%2' ne peut pas �tre converti vers le type '%1'.",
				throw new WDErreur(903, "cha\xEEne/string", "type avanc\xE9/advanced type");
			}
			this.m_sImage = oValeur;
			break;
		case 8:
			this.m_sActionClic = oValeur;
			break;
		case 9:
			this.m_nOpacite = oValeur;
			break;
		case 10:
			this.m_nAltitude = oValeur;
			break;
		default:
			WDTypeAvance.prototype.SetProp.apply(this, arguments);
	}
};

//Champ carte

function WDCarte(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
{
	// Si on est pas dans l'init d'un prototype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChampParametres.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
		
		//mod�le vide par d�faut
		this.m_oModele = {};
		//param�tres de suivi de d�placement
		this.m_oSuitDeplacement = undefined;
		//par d�faut les donn�es n'ont pas encore �t� modifi�es sans avertir l'affichage
		this.m_bUpdateUI = false;
		
		//en cas de mise � jour de html par ajax sous IE HTML5
		if (window["clWDUtil"]!==undefined && ((document.documentMode!==undefined) && (document.compatMode!="BackCompat")))  
		{
			var oThis = this;
			clWDUtil.AttacheOnScrollResize(function(oEvent, bOnScroll)
			{
				if (bOnScroll)
				{
					return;
				}
				var domBalise = document.getElementById(oThis.__sGetHote());
				if (!domBalise)
				{
					return;
				}
				var nHauteur = domBalise.clientHeight;
				if (!oThis.m_nDerniereHauteur || oThis.m_nDerniereHauteur != nHauteur)
				{
					if (oThis.m_oModele.UpdateSize)
					{
						oThis.m_oModele.UpdateSize();
					}
				}
				oThis.m_nDerniereHauteur = nHauteur;
			});
		}
	}
}

// Declare l'heritage
WDCarte.prototype = new WDChampParametres();
// Surcharge le constructeur qui a ete efface
WDCarte.prototype.constructor = WDCarte;

// Passe en mode editable les barres affichees
WDCarte.prototype.OnDisplay = function OnDisplay(oElementRacine, bAffiche)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype.OnDisplay.apply(this, arguments);
	//cas o� le champ est masqu�
	if (!bAffiche)
	{
		return;
	}
	//champ d�j� affich� ?
	if (this.m_bUpdateUI!==true && this.oRecupereAPI())
	{
		return;
	}
	this.m_bUpdateUI=false;
	//1er affichage	
	var oHote = document.getElementById(this.__sGetHote());
	//v�rifie que oElementRacine qui vient d'�tre affich�, est parent de la carte
	if (oHote && clWDUtil.bEstFils(oHote, oElementRacine))
	{
		//init de la carte
		this.__Reinit();
	}
};


// Lit les proprietes
WDCarte.prototype.GetProp = function GetProp(eProp/*, oEvent, oValeur, oChamp*/)
{
	switch (eProp)
	{
		case this.XML_CHAMP_PROP_NUM_MODECARTE:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_eModeCarte : this.m_oModele.MAP_GetModeCarte();
		case this.XML_CHAMP_PROP_NUM_ZOOM:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_nZoom : this.m_oModele.MAP_GetZoom();
		case this.XML_CHAMP_PROP_NUM_IMAGE:
			return this.m_oParametres.m_sImage;
		case this.XML_CHAMP_PROP_NUM_INFOTRAFIC:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_bInfoTrafic : this.m_oModele.MAP_GetInfoTrafic();
		case this.XML_CHAMP_PROP_NUM_BOUSSOLE:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_bBoussole : this.m_oModele.MAP_GetBoussole();
		case this.XML_CHAMP_PROP_NUM_AVECZOOM:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_bAvecZoom : this.m_oModele.MAP_GetAvecZoom();
		case this.XML_CHAMP_PROP_NUM_AVECROTATION:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_bAvecRotation : this.m_oModele.MAP_GetAvecRotation();
		case this.XML_CHAMP_PROP_NUM_AVECSCROLL:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_bAvecScroll : this.m_oModele.MAP_GetAvecScroll();
		case this.XML_CHAMP_PROP_NUM_AVECINCLINAISON:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_bAvecInclinaison : this.m_oModele.MAP_GetAvecInclinaison();
		case this.XML_CHAMP_PROP_NUM_ANGLEROTATION:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_nAngleRotation : this.m_oModele.MAP_GetAngleRotation();
		case this.XML_CHAMP_PROP_NUM_ANGLEINCLINAISON:
			return (!this.oRecupereAPI()) ? this.m_oParametres.m_nInclinaison : this.m_oModele.MAP_GetInclinaison();
		default:
			// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
			return WDChampParametres.prototype.GetProp.apply(this, arguments);
	}
};

// Ecrit les proprietes
WDCarte.prototype.SetProp = function SetProp(eProp, oEvent, oValeur/*, oChamp*//*, oXMLAction*/)
{
	switch (eProp)
	{
		case this.XML_CHAMP_PROP_NUM_MODECARTE:
			this.m_oParametres.m_eModeCarte = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetModeCarte(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_ZOOM:
			this.m_oDonnees.m_nZoom = oValeur;
			if (this.oRecupereAPI())
			{
				if (oValeur == -1)//snZoomAdapteTaille
				{
					this.m_oModele.MAP_SetZoomAdapte();
				}
				else
				{
					this.m_oModele.MAP_SetZoom(oValeur);
				}
			}
			break;
		case this.XML_CHAMP_PROP_NUM_INFOTRAFIC:
			this.m_oParametres.m_bInfoTrafic = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetInfoTrafic(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_BOUSSOLE:
			this.m_oParametres.m_bBoussole = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetBoussole(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_AVECZOOM:
			this.m_oParametres.m_bAvecZoom = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetAvecZoom(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_AVECROTATION:
			this.m_oParametres.m_bAvecRotation = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetAvecRotation(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_AVECSCROLL:
			this.m_oParametres.m_bAvecScroll = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetAvecScroll(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_AVECINCLINAISON:
			this.m_oParametres.m_bAvecInclinaison = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetAvecInclinaison(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_ANGLEROTATION:
			this.m_oParametres.m_nAngleRotation = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetAngleRotation(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_ANGLEINCLINAISON:
			this.m_oParametres.m_nInclinaison = oValeur;
			if (this.oRecupereAPI())
			{
				this.m_oModele.MAP_SetInclinaison(oValeur);
			}
			break;
		case this.XML_CHAMP_PROP_NUM_IMAGE:
			this.m_oParametres.m_sImage = oValeur;
			break;
		case this.XML_CHAMP_PROP_NUM_ETAT:
			// GP 21/11/2016 : Activation/d�sactivation du champ par le code WL navigateur.
			if (this.m_oModele)
			{
				this.m_oModele.PasseEnLectureSeuleEx(0 != oValeur);
			}
			return oValeur;

		default:
			// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
			return WDChampParametres.prototype.SetProp.apply(this, arguments);
	}
	//met � jour le champ cach� avec les donn�es
	return this.__UpdateChampCache();
};

//..Valeur=
WDCarte.prototype.SetValeur = function SetValeur(oEvent, sValeur/*, oChamp*/)
{
	//affecte ..Valeur du champ
	var Retour = WDChamp.prototype.SetValeur.apply(this, arguments);
	//modifie la position courante sans animation
	this.AffichePosition(sValeur, undefined, false);
	//retourne la valeur du champ
	return Retour;
};
WDCarte.prototype.GetValeur = function GetValeur(/*oEvent, sValeur, oChamp*/) 
{ 
	//pas de carte ? pas d'action imm�diate
	if (!this.oRecupereAPI())
	{
		return undefined;
	}
	//retourne la position actuelle
	return this.RecuperePosition();
};

// Trouve les divers elements : liaison avec le HTML
WDCarte.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vLiaisonHTML.apply(this, arguments);

};

// GP 27/05/2015 : DeclarePCode n'existe plus (la JS d�clare tous les traitements de tous les champs)
// => Le code de WDCarte.prototype.__Reinit fait le branchement avec RecuperePCode
//// Declare des PCodes navigateur du champ
//WDCarte.prototype.DeclarePCode = function DeclarePCode(ePCodeNav)
//{
//	WDChamp.prototype.DeclarePCode.apply(this, arguments);
//	if (ePCodeNav==this.ms_nEventNavCarteChangePosition && this.oRecupereAPI())
//	{
//		//pcode de modification de position
//		var fChangementPosition = this.RecuperePCode(this.ms_nEventNavCarteChangePosition);
//		//branche l'�couteur de l'API sur le pcode
//		this.m_oModele.EcouteChangementPosition(fChangementPosition);		
//		//si le pcode existe et qu'il faut l'appeler au 1er affichage et que la carte est d�j� positionn�e 
//		//(cas de CarteAffichePosition avec des coordonn�es GPS, contrairement � la syntaxe avec un lieu qui demande une r�solution asynchrone, du coup ce code est ex�cut�e avant la cr�ation de la carte)
//		if (fChangementPosition && this.m_oParametres.m_bAppelPCodeModif)
//		{
//			//1er appel au pcode de changement de modif
//			if (this.m_oParametres.m_bAppelPCodeModif)
//			{
//				fChangementPosition();
//			}			
//		}
//	}
//};

// Initialisation
WDCarte.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	// Fait ici car on a besoin d'une partie de l'initalisation precedente
	WDChampParametres.prototype.Init.apply(this, arguments);

	this.__Reinit();
};
WDCarte.prototype.__sGetHote = function __sGetHote()
{
	return this.m_sAliasChamp + '_HTE';
};

// Ajout tableau objets
// Entr�e :	tabObjet			Tableau contenant les objets � ajouter
//			fnMethodeAjoutObjet	M�thode ajout objet
//			CClasseObjet		Classe objet
WDCarte.prototype.__AjoutTableauObjet = function (tabObjet, fnMethodeAjoutObjet, CClasseObjet)
{
	// Ajout objets tableau
	var oThis = this;
	clWDUtil.bForEach(tabObjet, function (oObjet, nIndiceObjet)
	{
		// Copie classe objet pour ne pas la modifier pour les autres objets du tableau
		var clClasseObjet = CClasseObjet;
		// Classe objet fournie ?
		if (!clClasseObjet)
		{
			// Non => recup�ration classe objet
			clClasseObjet = WDDinoBaseObjetCarte.clClasseObjet(oObjet)
		}
		// On remplace les donn�es de l'objet par une instance de l'objet dans le tableau
		oObjet = tabObjet[nIndiceObjet] = new clClasseObjet(oObjet, true);
		// Ajout objet
		fnMethodeAjoutObjet.apply(oThis, [oObjet]);
		return true;
	});
};

WDCarte.prototype.__Reinit = function __Reinit()
{
	//ignore si invisible
	if (!clWDUtil.bEstDisplay(document.getElementById(this.__sGetHote()),document,true))
	{
		this.m_bUpdateUI=true;
		return;
	}
	//raz api carte 
	if (this.oRecupereAPI())
	{
		this.m_oModele = undefined;
	}	
	//api de carte
	var oThis = this;
	WDCarteAPI.s_pclFactory(WDCarteGoogleMaps, this.__sGetHote(), true,
	//pre init
	function(oInstance)
	{
		//init du champ
		oInstance.m_nTypeCarte_Initial = oThis.m_oParametres.m_eModeCarte;
		oInstance.m_bAfficheControleZoom_Initial = oThis.m_oParametres.m_bControleZoom;
		oInstance.m_sImageMarqueur_Initial = oThis.m_oParametres.m_sImage;
		oInstance.m_bInfoTrafic_Initial = oThis.m_oParametres.m_bInfoTrafic;
		oInstance.m_bBoussole_Initial = oThis.m_oParametres.m_bBoussole;
		oInstance.m_bAvecZoom_Initial = oThis.m_oParametres.m_bAvecZoom;
		oInstance.m_bAvecRotation_Initial = oThis.m_oParametres.m_bAvecRotation;
		oInstance.m_bAvecScroll_Initial = oThis.m_oParametres.m_bAvecScroll;
		oInstance.m_bAvecInclinaison_Initial = oThis.m_oParametres.m_bAvecInclinaison;
		oInstance.m_nAngleRotation_Initial = oThis.m_oParametres.m_dAngleRotation;
		oInstance.m_nInclinaison_Initial = oThis.m_oParametres.m_dAngleInclinaison;

		//set les positions initiales
		oInstance.m_nLatitude_Initial = oThis.m_oDonnees.m_dLatitude;
		oInstance.m_nLongitude_Initial = oThis.m_oDonnees.m_dLongitude;

		//zoom
		oInstance.m_nZoom_Initial = oThis.m_oDonnees.m_nZoom;

		//adresse d�finie (au lieu de position)
		oInstance.m_sAdresse_Initial = oThis.m_oDonnees.m_sAdresse;

		//notification de changement de position ?
		//NON => car trop t�t, le DeclarePCode est fait apr�s l'init, et la carte Maps n'est pas encore cr��e par CreateMap
	}
	//post init
	,
	function(oInstance)
	{		
		oThis.m_bPendantReInit = true;
		//copie homonymique en plus de l'affectation afin de conserver les membres en plus d�j� dans oThis.m_oModele
		clWDUtil.bForEachIn(oThis.m_oModele, function(sMembre, oValeur)
		{
			oInstance[sMembre] = oValeur;
			return true;
		});
		oThis.m_oModele=oInstance;
		
		//associe le champ � l'api
		oInstance.m_oChamp = oThis;

		//..Etat
		var domChampCache = oThis.__domGetChampCache();
		var sContenuHTML = domChampCache.outerHTML.toLowerCase();
		oInstance.PasseEnLectureSeuleEx((domChampCache && ((sContenuHTML.indexOf("disabled")>-1) || (sContenuHTML.indexOf("readonly")>-1))));
		
		//set les marqueurs d�finis c�t� serveur
		for (var iMarqueur = 0; iMarqueur < oThis.m_oDonnees.m_tabMarqueurs.length; ++iMarqueur)
		{
			oThis.AjouteMarqueur(oThis.m_oDonnees.m_tabMarqueurs[iMarqueur]=new WDDinoMarqueur(oThis.m_oDonnees.m_tabMarqueurs[iMarqueur]));
		}

		//set les itin�raires d�finis c�t� serveur
		for (var iItineraire = 0; iItineraire < oThis.m_oDonnees.m_tabItineraires.length; ++iItineraire)
		{
			var oItineraire = oThis.m_oDonnees.m_tabItineraires[iItineraire];
			var tabPositions = [];
			//TODO m_sImage ?
			//transforme les { m_sImage, m_sAdresse, m_dLatitude, m_dLongitude} en array de positions
			for(var iElement=0; iElement<oItineraire.m_tabPositions.length; ++iElement)
			{
				var element = oItineraire.m_tabPositions[iElement];
				//cas de positions d�j� nettoy�es avant l'affichage de la carte, on le garde tel quel
				if (!clWDUtil.isObject(element))
				{
					tabPositions.push(element);
				}
				else if (element.m_sAdresse)
				{
					tabPositions.push(element.m_sAdresse);
				}
				else
				{
					tabPositions.push([element.m_dLatitude, element.m_dLongitude]);
				}
			}
			oThis.AjouteItineraire(tabPositions, oItineraire.m_nMode, oItineraire.m_cCouleur, oItineraire.m_nOpacite/2.55, oItineraire.m_nEpaisseur, oItineraire.m_nID);
		}

		//set les formes d�finies c�t� serveur
		oThis.__AjoutTableauObjet(oThis.m_oDonnees.m_tabFormes, oThis.AjouteForme);

		//set les images d�finies c�t� serveur
		oThis.__AjoutTableauObjet(oThis.m_oDonnees.m_tabImages, oThis.AjouteImage, WDDinoCarteImage);
		
		//suit d�placement ?
		if (oThis.m_oSuitDeplacement)
		{
			oThis.SuitDeplacement.apply(oThis,oThis.m_oSuitDeplacement);
		}
		//met � jour le champ cach� avec la valeur initiale de la carte
		oThis.__UpdateChampCache();		
		//si le pcode existe et qu'il faut l'appeler au 1er affichage et que la carte est d�j� positionn�e 
		//(cas de CarteAffichePosition avec lieu qui demande une r�solution asynchrone, du coup ce code est apr�s la cr�ation de la carte et apr�s la d�claration du pcode)		
		var fChangementPosition = oThis.RecuperePCode(oThis.ms_nEventNavCarteChangePosition);
		if (fChangementPosition)
		{
			oThis.m_oModele.EcouteChangementPosition(fChangementPosition);		
			//1er appel au pcode de changement de modif
			if (oThis.m_oParametres.m_bAppelPCodeModif)
			{
				fChangementPosition();
			}
		}
		// Init ecoute affichage cluster
		oThis.m_oModele.EcouteAffichageCluster(oThis.RecuperePCode(oThis.ms_nEventNavCarteCreationCluster));		

		oThis.m_bPendantReInit = false;
		
		if (oThis.m_oDonnees.m_nZoom == -1)//snZoomAdapteTaille
		{
			oThis.m_oModele.MAP_SetZoomAdapte();
		}
	}
	);
};

//met � jour le champ cach�
WDCarte.prototype.__domGetChampCache = function __domGetChampCache()
{
	return document.getElementById(this.m_sAliasChamp + '_DATA');
};

// Nettoyage tableau objet pour json � fournir au serveur
// Entr�e :	tabTableauObjet	Tableau des objets � nettoyer
//			CClasseObjet	Classe de l'objet
WDCarte.prototype.__NettoyageTableauPourJsonServeur = function (tabTableauObjet, CClasseObjet)
{
	// Nettoyage tableau objets
	tabTableauObjet && tabTableauObjet.length && clWDUtil.bForEach(tabTableauObjet, function (oObjet)
	{
		// Copie classe objet pour ne pas la modifier pour les autres objets du tableau
		var clClasseObjet = CClasseObjet;
		// L'objet est une forme ?
		if (clClasseObjet == WDDinoCarteForme)
		{
			// Oui => r�cup�ration classe objet
			clClasseObjet = WDDinoBaseObjetCarte.clClasseObjet(oObjet);
		}
		// Nettoyage objet (on ne peut pas appeler directement la m�thode sur l'objet car tableau d'objet issu du clonage par JSON.parse qui cr�e un objet de base en ne copiant que les membres)
		clClasseObjet.prototype.NettoyagePourJsonServeur.apply(oObjet);
		return true;
	});
};

// Clonage bas niveau d'un objet
// Entr�e :	clObjet	Objet � cloner
// Sortie : Clone bas niveau de l'objet
WDCarte.clCloneBasNiveau = function (clObjet)
{
	return JSON.parse(JSON.stringify(clObjet));
};

//met � jour le champ cach�
WDCarte.prototype.__UpdateChampCache = function __UpdateChampCache()
{
	//nettoie le json � fournir au serveur
	var oClone = WDCarte.clCloneBasNiveau(this.m_oDonnees);
	this.__NettoyageTableauPourJsonServeur(oClone.m_tabMarqueurs, WDDinoMarqueur);
	var i = 0;
	for(i=0;i<oClone.m_tabItineraires.length;++i)
	{
		var oItineraire=oClone.m_tabItineraires[i];
		for(var iElement=0; iElement<oItineraire.m_tabPositions.length; ++iElement)
		{			
			if (typeof oItineraire.m_tabPositions[iElement] == 'string')		
			{
				//{"m_tabPositions":["Montpellier","Paris"]
				//devient
				//{"m_tabPositions":[{m_sAdresse:"Montpellier"},{m_sAdresse:"Paris"}]
				oItineraire.m_tabPositions[iElement] = {m_sAdresse : oItineraire.m_tabPositions[iElement]};
			}
			else
			{
				delete oItineraire.m_tabPositions[iElement].m_oPosition;
			}
		}
	}
	//nettoyage formes
	this.__NettoyageTableauPourJsonServeur(oClone.m_tabFormes, WDDinoCarteForme);
	//nettoyage images
	this.__NettoyageTableauPourJsonServeur(oClone.m_tabImages, WDDinoCarteImage);
	return this.__domGetChampCache().value = JSON.stringify(oClone);
};

// Applique les parametres
WDCarte.prototype._vAppliqueParametres = function _vAppliqueParametres(/*oParametreFusion*/)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vAppliqueParametres.apply(this, arguments);

	// Recree la liaison HTML
	this._vLiaisonHTML();

	//TODO OPTIM : �viter de recr�er la carte d�j� pr"sente, juste faire les SetXXX
	this.__Reinit();
};

// Pour implementer ConstruitParam (accepte des parametres variables)
WDCarte.prototype._vsConstruitParam = function _vsConstruitParam()
{
	var tabParam = [];
	// Appel de la methode de la classe de base
	var sParam = WDChampParametres.prototype._vsConstruitParam.apply(this, arguments);
	if (sParam.length > 0)
	{
		tabParam.push(sParam);
	}

	//autres ?
	//tabParam.push( ... ));

	return tabParam.join(',');
};

// Fonctions WL Carte

// CarteAffichePosition() 1/2
// CarteAffichePosition() 2/2
WDCarte.prototype.AffichePosition = function(oGeoPositionOuLieu, fCallback, bAnimation)
{
	//cas d'un dino adresse
	if (oGeoPositionOuLieu instanceof WDDinoAdresse)
	{
		//en choisit le g�oposition ou l'adresse en cha�ne 
		//priorit� faite au g�oposition
		if (oGeoPositionOuLieu.m_pclGeoPosition && oGeoPositionOuLieu.m_pclGeoPosition.vbGetPositionValide())
		{
			//g�oPosition de l'adresse
			oGeoPositionOuLieu = oGeoPositionOuLieu.m_pclGeoPosition;
		}
		else
		{
			//cha�ne d�crivant l'adresse
			oGeoPositionOuLieu = oGeoPositionOuLieu.vGetAdresseComplete();
		}
	}
	
	//maj les donn�es
	//syntaxe avec dino geoPosition
	if (oGeoPositionOuLieu instanceof WDGeoPosition)
	{
		//set les positions initiales
		this.m_oDonnees.m_dLatitude = oGeoPositionOuLieu.GetLatitude();
		this.m_oDonnees.m_dLongitude = oGeoPositionOuLieu.GetLongitude();
	}
	else
	{
		//adresse d�finie (au lieu de position)
		this.m_oDonnees.m_sAdresse = ""+oGeoPositionOuLieu;	
	}
	//met � jour le champ cach� avec les donn�es
	this.__UpdateChampCache();
	
	//pas de carte ? pas d'action imm�diate
	if (!this.oRecupereAPI())
	{
		return true;
	}

	if (bAnimation === undefined)
	{
		bAnimation = this.m_oDonnees.m_bAnimation;
	}
	//syntaxe avec dino geoPosition
	if (clWDUtil.isObject(oGeoPositionOuLieu))
	{
		//r�cup�re les coordonn�es du g�oposition
		this.m_oModele.MAP_SetPosition(oGeoPositionOuLieu.GetLatitude(), oGeoPositionOuLieu.GetLongitude(), bAnimation, fCallback)
	}
	else
	{
		//syntaxe avec description du lieu
		this.m_oModele.MAP_SetPositionLieux(oGeoPositionOuLieu, bAnimation, fCallback);
	}
	return true;
};

//retourne un geoposition � partir d'une cha�ne "lat,lng"
WDCarte.prototype._oGetPositionFromLatLng = function(sLatLng)
{
	var oGeoPos = new WDGeoPosition();
	var nSep = (sLatLng || "").indexOf(",");
	if (nSep > 0)
	{
		oGeoPos.SetLatitude(sLatLng.substr(0, nSep));
		oGeoPos.SetLongitude(sLatLng.substr(nSep + 1));
	}
	return oGeoPos;
};

// CarteR�cup�rePosition()
WDCarte.prototype.RecuperePosition = function()
{
	//pas de carte ? pas d'action imm�diate
	if (!this.oRecupereAPI())
	{
		return undefined;
	}
	return this._oGetPositionFromLatLng(this.m_oModele.MAP_GetPosition());
};
// CarteInfoXY ()
WDCarte.prototype.InfoXY = function(x, y)
{
	//pas de carte ? pas d'action imm�diate
	if (!this.oRecupereAPI())
	{
		return undefined;
	}
	return this._oGetPositionFromLatLng(this.m_oModele.MAP_GetPositionFromPoint(x, y));
};
// CarteInfoPosition()
WDCarte.prototype.InfoPosition = function(oGeoPosition)
{
	//pas de carte ? pas d'action imm�diate
	if (!this.oRecupereAPI())
	{
		return undefined;
	}
	return this.m_oModele.MAP_GetPointFromPosition(oGeoPosition.GetLatitude(), oGeoPosition.GetLongitude()).replace(",","\t");
};

// Indique si ajout objet possible
// Entr�e :	tabObjet	Tableau dans lequel l'objet doit �tre ajout�
//			oObjet		Objet � ajouter
// Sortie :	true si l'objet peut �tre ajout�, false sinon
WDCarte.prototype.__bAjoutObjetPossible = function (tabObjet, oObjet)
{
	return this.m_bPendantReInit || (!this._oFindObjetParNom(tabObjet, oObjet.m_sNom));
};

// Indique si sortie apr�s mise � jour champ cach�
WDCarte.prototype.__bSortieApresMajChampCache = function ()
{
	//met � jour le champ cach� avec les donn�es
	this.__UpdateChampCache();
	//pas de carte ? pas d'action imm�diate
	return !this.oRecupereAPI();
};

// Mise � jour apr�s ajout objet et obtention identifiant objet ajout�
// Entr�e :	tabObjet		Tableau o� ajouter l'objet
//			oObjet			Objet ajout�
// Sortie :	oParam.bSortie	Indique si on doit sortir apr�s l'appel
//			oParam.oClone	Clone de l'objet
//			R�sultat		Identifiant de l'objet ajout�
WDCarte.prototype.__nIdMajApresAjoutObjet = function (tabObjet, oObjet, oParam)
{
	var nId;
	//�vite de noter les donn�es alors que justement on applique les donn�es d�j� not�es
	if (!this.m_bPendantReInit)
	{
		nId = undefined;//force un nouvel id pour ce nouvel objet oObjet.pszGetIDInterne();
		//maj les donn�es avec une copie
		oParam.oClone = oObjet.clClone();
		tabObjet.push(oParam.oClone);
		//met � jour le champ cach� avec les donn�es
		if (this.__bSortieApresMajChampCache())
		{
			//ID temporaire dans l'objet
			oParam.oClone.SetIDInterne(nId || oParam.oClone.sCreerIdentifiant());
			//On devra sortir apr�s l'appel
			oParam.bSortie = true;
			return nId;
		}
		else
		{
			//force un nouvel id pour ce nouvel objet
			oParam.oClone.SetIDInterne(nId);
		}
	}
	else
	{
		nId = oObjet.pszGetIDInterne();//force un nouvel id pour ce nouvel objet oObjet.pszGetIDInterne();
	}
	//Identifiant
	return nId;
};

// Init objet de carte avec image avant appel API carte
// Entr�e :	oObjet			Objet de carte avec image
// Sortie :	oImage.sImage	Image de l'objet
//			R�sultat		true si initialisation OK, false sinon
WDCarte.prototype.__bInitObjetAvecImageAvantAppelApiCarte = function (oObjet, oImage)
{
	//PAD le 3/10/2014 pour QW#249203 : cas ou l'objet a sa propre image
	if (oObjet.m_sImage && oObjet.m_sImage.length)
	{
		oImage.sImage = oObjet.m_sImage;
	}
	//cas d'erreur : pas de position
	return oObjet.m_oPosition != undefined//ou null
};

// Appel API carte pour ajout objet
// Entr�e :	nRetour		Valeur retour Api carte
//			tabObjet	Tableau contenant l'objet ajout�
//			oObjet		Objet ajout�
//			oClone		Clone de l'objet ajout�
//			nId			Identifant de l'objet ajout�
// Sortie :	true si ajout objet OK, false sinon
WDCarte.prototype.__bAjoutObjetApiCarte = function (nRetour, tabObjet, oObjet, oClone, nId)
{
	// �chec appel Api
	if (nRetour === false)
	{
		//retire l'objet des donn�es
		if (!this.m_bPendantReInit)
		{
			tabObjet.pop();
		}
		//impossible d'ajouter
		return false;
	}
	// modif id objet
	oObjet.SetIDInterne(nId || nRetour);
	// clone ?
	if (oClone)
	{
		// oui => modif id clone
		oClone.SetIDInterne(nId || nRetour);
	}
	return true;
};

// CarteAfficheZone
WDCarte.prototype.AfficheZone = function (clPositionNordOuest, clPositionSudEst)
{
	// Affichage zone
	return this.m_oModele.MAP_AfficheZone(clPositionNordOuest.GetLatitude(), clPositionNordOuest.GetLongitude(), clPositionSudEst.GetLatitude(), clPositionSudEst.GetLongitude());
};

// CarteLimiteZone
WDCarte.prototype.LimiteZone = function (clPositionNordOuest, clPositionSudEst)
{
	// Zone pr�cis�e ?
	if (clPositionNordOuest === undefined)
	{
		// Non => on enl�ve la limite
		return this.m_oModele.MAP_LimiteZone();
	}
	// Oui => Affichage zone
	return this.m_oModele.MAP_LimiteZone(clPositionNordOuest.GetLatitude(), clPositionNordOuest.GetLongitude(), clPositionSudEst.GetLatitude(), clPositionSudEst.GetLongitude());
};

// CarteChangeStyle
WDCarte.prototype.ChangeStyle = function (nIdStyle, sUrlJsonStylePerso)
{
	// style perso
	var tabStylePerso;
	// Url fichier json type perso ?
	if (sUrlJsonStylePerso)
	{
		// Oui => r�cup�ration style perso
		tabStylePerso = clWDAJAXMain.JSONExecute(sUrlJsonStylePerso);
	}
	// Changement style
	return this.m_oModele.MAP_ChangeStyle(nIdStyle, tabStylePerso);
};

// CarteR�cup�reStyle
WDCarte.prototype.RecupereStyle = function ()
{
	// R�cup�ration style
	return this.m_oModele.MAP_RecupereStyle();
};

// CarteAjouteMarqueur
WDCarte.prototype.AjouteMarqueur = function(dLatitude, dLongitude)
{
	var oMarqueur;
	//<R�sultat> = CarteAjouteMarqueur(<Nom du champ Carte> , <Marqueur>)
	if (dLatitude instanceof WDDinoMarqueur)
	{
		oMarqueur = dLatitude;
		if (!this.__bAjoutObjetPossible(this.m_oDonnees.m_tabMarqueurs, oMarqueur))
		{
			return false;
		}
	}
	//<R�sultat> = CarteAjouteMarqueur(<Nom du champ Carte> , <Position>)
	else if (dLatitude instanceof WDGeoPosition)
	{
		oMarqueur = new WDDinoMarqueur(dLatitude);
	}
	//<R�sultat> = CarteAjouteMarqueur(<Nom du champ Carte> , <Latitude> , <Longitude>)
	else
	{
		oMarqueur = new WDDinoMarqueur();
		oMarqueur.SetLatitude(dLatitude);
		oMarqueur.SetLongitude(dLongitude);
	}

	// Mise � jour et r�cup�ration identifiant
	var nIdOptionnel = this.__nIdMajApresAjoutObjet(this.m_oDonnees.m_tabMarqueurs, oMarqueur, oSortie = { bSortie: false });
	// Sortie ?
	if (oSortie.bSortie)
	{
		// Oui => OK
		return true;
	}
	
	// si on a chang� par ..Image (QW#247233)
	var oImage = { sImage: this.m_oParametres.m_sImage };
	if (!this.__bInitObjetAvecImageAvantAppelApiCarte(oMarqueur, oImage))
	{
		return false;
	}
	// on ex�cute le code JS qui ajoute un marqueur
	return this.__bAjoutObjetApiCarte
		(
		this.m_oModele.MAP_AjouteMarqueur
			(
			oMarqueur.m_oPosition.GetLatitude(),
			oMarqueur.m_oPosition.GetLongitude(),
			oMarqueur.m_sDescription,
			oMarqueur.m_sActionClic,
			this.m_bMarqueurImage ? "" : clWDUtil.sGetCheminImage(oImage.sImage, ''),
			nIdOptionnel,
			oMarqueur.m_eAlignement,
			undefined,
			oMarqueur.m_nOpacite,
			oMarqueur.m_nAltitude,
			oMarqueur.m_bIsDeplacable,
			oMarqueur.m_sActionClicDeplacement,
			oMarqueur.m_bAvecPopup,
			oMarqueur.m_sNom,
			oMarqueur.m_sActionClicPopup,
			oMarqueur.m_bClusteur,
			oMarqueur.m_bMarqueurImage ? oMarqueur.m_clMarqueurImage.m_eForme : WDCarteAPI.nFormeNonDefini,
			oMarqueur.m_bMarqueurImage ? oMarqueur.m_clMarqueurImage.m_nTaille : 0,
			oMarqueur.m_bMarqueurImage ? oMarqueur.m_clMarqueurImage.m_sTexte : "",
			oMarqueur.m_bMarqueurImage ? WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(oMarqueur.m_clMarqueurImage.m_clCouleur) : "",
			oMarqueur.m_bMarqueurImage ? WDDinoBaseObjetCarte.nOpaciteDinoCouleur(oMarqueur.m_clMarqueurImage.m_clCouleur) : 0,
			oMarqueur.m_bMarqueurImage ? WDDinoBaseObjetCarte.sCouleurSansOpaciteDinoCouleur(oMarqueur.m_clMarqueurImage.m_clCouleurFond) : "",
			oMarqueur.m_bMarqueurImage ? WDDinoBaseObjetCarte.nOpaciteDinoCouleur(oMarqueur.m_clMarqueurImage.m_clCouleurFond) : 0,
			""
			),
		this.m_oDonnees.m_tabMarqueurs,
		oMarqueur,
		oSortie.oClone,
		nIdOptionnel
		);
};

// Chercher un objet par son nom
// Entr�e :	tabObjet	Tableau des objets dans lequel on cherche
//			oObjet		Objet recherch� dans le tableau
// Sortie : objet trouv� dans le tableau, undefined si pas trouv�
WDCarte.prototype._oFindObjetParNom = function (tabObjet, sNom)
{
	// Recherche objet par nom
	for (var nObjet = 0; nObjet < tabObjet.length; ++nObjet)
	{
		// R�cup�ration objet
		var clObjet = tabObjet[nObjet];
		// Le nom est le bon ?
		if (clObjet.m_sNom == sNom)
		{
			// Oui => on a trouv� l'objet
			return clObjet;
		}
	}
	// Objet non trouv�
	return undefined;
};

// Chercher un objet
// Entr�e :	CTypeObjet	Type d'objet recherch�
//			tabObjet	Tableau des objets dans lequel on cherche
//			oObjet		Objet recherch� dans le tableau
// Sortie : objet trouv� dans le tableau, undefined si pas trouv�
WDCarte.prototype._oFindObjet = function (CTypeObjet, tabObjet, oObjet)
{
	//c'est d�j� un objet ?
	if (oObjet instanceof CTypeObjet)
	{
		//id valide ?
		if (oObjet.pszGetIDInterne() !== undefined)
		{
			return oObjet;
		}
		//poursuit par une recherche par nom
		oObjet = oObjet.m_sNom;
	}

	//par nom ?
	if (oObjet)
	{
		oObjet = this._oFindObjetParNom(tabObjet, oObjet);
	}

	//r�sultat
	return oObjet;
};

// Chercher un marqueur
// Entr�e :	clMarqueur		Marqueur recherch�
// Sortie : Marqueur trouv� , undefined si pas trouv�
WDCarte.prototype._oFindMarqueur = function (clMarqueur)
{
	// Recherche marqueur
	return this._oFindObjet(WDDinoMarqueur, this.m_oDonnees.m_tabMarqueurs, clMarqueur);
};

// Suppression objet
// Entr�e :	CTypeObjet							Type d'objet � supprimer
//			tabObjet							Tableau contenant l'objet
//			oObjet								Objet suprim�
//			fnMethodeModifTableau				M�thode modification tableau objets
//			fnMethodeCarteSuppressionObjet		M�thode objet carte de suppresion d'objet
//			fnMethodeCarteSuppressionToutObjet	M�thode objet carte de suppresion de tous les objets
// Sortie :	true si suppression OK, false sinon
WDCarte.prototype.__bSupprimeObjet = function (CTypeObjet, tabObjet, oObjet, fnMethodeModifTableau, fnMethodeCarteSuppressionObjet, fnMethodeCarteSuppressionToutObjet)
{
	//Si ce param�tre n'est pas sp�cifi�, tous les objets de la carte seront supprim�s (�quivalent � la fonction CarteSupprimeTout).
	if (!oObjet)
	{
		//applique l'action
		return this.__bSupprimeToutObjet(fnMethodeModifTableau, fnMethodeCarteSuppressionToutObjet);
	}
	//recherche l'objet � partir de son nom ou autre
	oObjet = this._oFindObjet(CTypeObjet, tabObjet, oObjet);
	//pas d'objet trouv�, pas d'action
	if (!oObjet)
	{
		return false;
	}
	//maj les donn�es
	var tabObjetMaj = [];
	//retire l'objet du tableau
	for (var iObjet = 0; iObjet < tabObjet.length; ++iObjet)
	{
		if (tabObjet[iObjet].pszGetIDInterne() != oObjet.pszGetIDInterne())
		{
			tabObjetMaj.push(tabObjet[iObjet]);
		}
	}
	fnMethodeModifTableau.apply(this, [tabObjetMaj]);
	//met � jour le champ cach� avec les donn�es
	if (this.__bSortieApresMajChampCache())
	{
		return true;
	}

	//applique l'action	
	return fnMethodeCarteSuppressionObjet.apply(this.m_oModele, [oObjet.pszGetIDInterne()]);
};

// Modification tableau marqueurs
WDCarte.prototype.SetTableauMarqueur = function (tabMarqueur)
{
	this.m_oDonnees.m_tabMarqueurs = tabMarqueur;
};

// CarteSupprimeMarqueur
WDCarte.prototype.SupprimeMarqueur = function(oMarqueur)
{
	return this.__bSupprimeObjet(WDDinoMarqueur, this.m_oDonnees.m_tabMarqueurs, oMarqueur, this.SetTableauMarqueur, this.m_oModele.MAP_SupprimeMarqueur, this.m_oModele.MAP_SupprimeToutMarqueur);
};

// Modification objet
// Entr�e :	CTypeObjet		Type d'objet recherch�
//			tabObjet		Tableau contenant l'objet
//			oObjet			Objet modifi�
// Sortie :	oParam.bSortie	Indique si on doit sortir apr�s l'appel
//			R�sultat		true si mofidication OK, false sinon
WDCarte.prototype.__bModifieObjet = function (CTypeObjet, tabObjet, oObjet)
{
	//recherche l'objet � partir de son nom ou autre
	var oObjetTrouve = this._oFindObjet(CTypeObjet, tabObjet, oObjet);
	if (!oObjetTrouve)
	{
		return false;
	}
	//copie l'id
	var nIdInterne = oObjetTrouve.pszGetIDInterne();

	//maj les donn�es
	clWDUtil.bForEach(tabObjet, function (oObjetTableau)
	{
		if (oObjetTableau.pszGetIDInterne() == nIdInterne)
		{
			//le nouvel objet remplace l'ancien et r�cup�re son ID
			oObjetTableau.Clone(oObjet);
			oObjetTableau.SetIDInterne(nIdInterne);
			return false;
		}
		return true;
	});
	//met � jour le champ cach� avec les donn�es
	if (this.__bSortieApresMajChampCache())
	{
		return true;
	}
	//modif des infos
	return oObjet.bModifApiCarte(this, nIdInterne);
};

// CarteModifieMarqueur
WDCarte.prototype.ModifieMarqueur = function(oMarqueur)
{
	return this.__bModifieObjet(WDDinoMarqueur, this.m_oDonnees.m_tabMarqueurs, oMarqueur);
};

// CarteSupprimeTout
WDCarte.prototype.SupprimeTout = function()
{
	return this.SupprimeToutItineraire() && this.SupprimeToutMarqueur() && this.SupprimeToutForme() && this.SupprimeToutImage();
};

// CarteAffichePopup
WDCarte.prototype.AffichePopup = function (clMarqueur)
{
	// Recherche marqueur dans carte
	var clMarqueurCarte = this._oFindMarqueur(clMarqueur);
	// Marqueur trouv� ?
	if (!clMarqueurCarte)
	{
		// Non => �chec
		return false;
	}
	// Affichage popup
	return this.m_oModele.MAP_AffichePopup(clMarqueurCarte.pszGetIDInterne());
};

// CarteFermePopup
WDCarte.prototype.FermePopup = function (clMarqueur)
{
	// Recherche marqueur dans carte
	var clMarqueurCarte = this._oFindMarqueur(clMarqueur);
	// Marqueur trouv� ?
	if (!clMarqueurCarte)
	{
		// Non => �chec
		return false;
	}
	// Fermeture popup
	return this.m_oModele.MAP_FermePopup(clMarqueurCarte.pszGetIDInterne());
};

// CarteFermePopupAffich�e
WDCarte.prototype.PopupAffichee = function (clMarqueur)
{
	// Recherche marqueur dans carte
	var clMarqueurCarte = this._oFindMarqueur(clMarqueur);
	// Marqueur trouv� ?
	if (!clMarqueurCarte)
	{
		// Non => �chec
		return false;
	}
	// Indique si popup affich�e
	return this.m_oModele.MAP_PopupAffichee(clMarqueurCarte.pszGetIDInterne());
};

// Suppression de tous les objets d'un type donn�
// Entr�e :	fnMethodeModifTableau				M�thode modification tableau objets
//			fnMethodeCarteSuppressionToutObjet	M�thode objet carte de suppresion dd tous les objet
// Sortie :	true si suppression OK, false sinon
WDCarte.prototype.__bSupprimeToutObjet = function (fnMethodeModifTableau, fnMethodeCarteSuppressionToutObjet)
{
	//maj les donn�es
	fnMethodeModifTableau.apply(this,[[]]);
	//met � jour le champ cach� avec les donn�es
	if (this.__bSortieApresMajChampCache())
	{
		return true;
	}
	//suppression dans api carte
	return fnMethodeCarteSuppressionToutObjet.apply(this.m_oModele);
};

// Pour CarteSupprimeTout
WDCarte.prototype.SupprimeToutMarqueur = function()
{
	return this.__bSupprimeToutObjet(this.SetTableauMarqueur, this.m_oModele.MAP_SupprimeToutMarqueur);
};

// CarteAjouteItin�raire()
WDCarte.prototype.AjouteItineraire = function(tabPositions, nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel)
{
	if (!clWDUtil.isArray(tabPositions))
	{
		return this.AjouteItineraireStr.apply(this, arguments);
	}
	
	//construit un tableau de cha�nes sans objet
	var tabPositionsPropre = [];
	for(var iElement=0; iElement<tabPositions.length; ++iElement)
	{
		var element = tabPositions[iElement];	

		//cas du dino Adresse ?
		if (element instanceof WDDinoAdresse)
		{
			//en choisit le g�oposition ou l'adresse en cha�ne 
			//priorit� faite au g�oposition
			if (element.m_pclGeoPosition && element.m_pclGeoPosition.vbGetPositionValide())
			{
				//g�oPosition de l'adresse
				element = element.m_pclGeoPosition;
			}
			else
			{
				//cha�ne d�crivant l'adresse
				element = element.vGetAdresseComplete();
			}
		}
		
		if (element instanceof WDDinoMarqueur)
		{
			tabPositionsPropre.push([element.m_oPosition.GetLatitude(), element.m_oPosition.GetLongitude()]);
		}	
		else if (element instanceof WDGeoPosition)
		{
			tabPositionsPropre.push([element.GetLatitude(), element.GetLongitude()]);
		}
		//[lat,lng]
		else if (clWDUtil.isArray(element))
		{
			tabPositionsPropre.push(element);
		}
		//cha�ne
		else
		{
			tabPositionsPropre.push(element);
		}
	}
	//�vite de noter les donn�es alors que justement on applique les donn�es d�j� not�es
	if (!this.m_bPendantReInit)
	{	
		var oItineraire;
		//maj les donn�es
		this.m_oDonnees.m_tabItineraires.push(oItineraire={
			m_tabPositions 	: tabPositionsPropre
		,	m_nMode			: nMode
		,	m_cCouleur		: sColor
		,	m_nOpacite		: nOpacite*2.55
		,	m_nEpaisseur	: nEpaisseur
		,	m_nID			: (nIdOptionnel||WDCarteAPI.CreerIdentifiant())
		});
		//met � jour le champ cach� avec les donn�es
		this.__UpdateChampCache();	
		//pas de carte ? pas d'action imm�diate
		if (!this.oRecupereAPI())
		{
			return oItineraire.m_nID;
		}
	}
	return this.m_oModele.MAP_AjouteItineraireArray(tabPositionsPropre, nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel);	
};
// CarteAjouteItin�raire()
WDCarte.prototype.AjouteItineraireStr = function(sLieuDepart, sLieuArrivee, nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel)
{
	//�vite de noter les donn�es alors que justement on applique les donn�es d�j� not�es
	if (!this.m_bPendantReInit)
	{
		var oItineraire;
		//maj les donn�es
		this.m_oDonnees.m_tabItineraires.push(oItineraire={
			m_tabPositions 	: [ sLieuDepart, sLieuArrivee ]
		,	m_nMode			: nMode
		,	m_cCouleur		: sColor
		,	m_nOpacite		: nOpacite*2.55
		,	m_nEpaisseur	: nEpaisseur	
		,	m_nID			: WDCarteAPI.CreerIdentifiant()
		});
		//met � jour le champ cach� avec les donn�es
		this.__UpdateChampCache();	
		//pas de carte ? pas d'action imm�diate
		if (!this.oRecupereAPI())
		{
			//id temporaire
			return oItineraire.m_nID;
		}
	}
	return this.m_oModele.MAP_AjouteItineraireArray([sLieuDepart, sLieuArrivee], nMode, sColor, nOpacite, nEpaisseur, nIdOptionnel);
};
// CarteSupprimeItineraire()
WDCarte.prototype.SupprimeItineraire = function(nID)
{
	//maj les donn�es
	var tabItineraires = [];
	//retire l'itin�raires du tableau
	for(var iItineraire=0; iItineraire<this.m_oDonnees.m_tabItineraires.length; ++iItineraire)
	{
		if (this.m_oDonnees.m_tabItineraires[iItineraire].m_nID != nID)
		{
			tabItineraires.push(this.m_oDonnees.m_tabItineraires[iItineraire]);
		}
	}
	this.m_oDonnees.m_tabItineraires = tabItineraires;	
	//met � jour le champ cach� avec les donn�es
	this.__UpdateChampCache();	
	//pas de carte ? pas d'action imm�diate
	if (!this.oRecupereAPI())
	{
		return true;
	}	
	return this.m_oModele.MAP_SupprimeItineraire(nID);
};
// Pour CarteSupprimeTout
WDCarte.prototype.SupprimeToutItineraire = function()
{
	//maj les donn�es
	this.m_oDonnees.m_tabItineraires = [];
	//met � jour le champ cach� avec les donn�es
	this.__UpdateChampCache();	
	//pas de carte ? pas d'action imm�diate
	if (!this.oRecupereAPI())
	{
		return true;
	}	
	return this.m_oModele.MAP_SupprimeToutItineraire();
};

// Ajout de dino
WDCarte.prototype.__bAjouteDino = function (tabDino, oDino)
{
	// Ajout possible ?
	if (!this.__bAjoutObjetPossible(tabDino, oDino))
	{
		// Non => �chec
		return false;
	}

	// Oui => mise � jour et r�cup�ration identifiant
	var nIdOptionnel = this.__nIdMajApresAjoutObjet(tabDino, oDino, oSortie = { bSortie: false });
	// Sortie ?
	if (oSortie.bSortie)
	{
		// Oui => OK
		return true;
	}

	// on ex�cute le code JS qui ajoute une forme
	return this.__bAjoutObjetApiCarte(oDino.nAjoutApiCarte(this.m_oModele, nIdOptionnel), tabDino, oDino, oSortie.oClone, nIdOptionnel);
};

// CarteAjouteForme
WDCarte.prototype.AjouteForme = function (oForme)
{
	return this.__bAjouteDino(this.m_oDonnees.m_tabFormes, oForme);
};

// Modification tableau formes
WDCarte.prototype.SetTableauForme = function (tabForme)
{
	this.m_oDonnees.m_tabFormes = tabForme;
};

// CarteSupprimeForme
WDCarte.prototype.SupprimeForme = function (oForme)
{
	return this.__bSupprimeObjet(WDDinoCarteForme, this.m_oDonnees.m_tabFormes, oForme, this.SetTableauForme, this.m_oModele.MAP_SupprimeForme, this.m_oModele.MAP_SupprimeToutForme);
};

// CarteModifieForme
WDCarte.prototype.ModifieForme = function (oForme)
{
	return this.__bModifieObjet(WDDinoCarteForme, this.m_oDonnees.m_tabFormes, oForme);
};

// Pour CarteSupprimeTout
WDCarte.prototype.SupprimeToutForme = function ()
{
	return this.__bSupprimeToutObjet(this.SetTableauForme, this.m_oModele.MAP_SupprimeToutForme);
};

// CarteAjouteImage
WDCarte.prototype.AjouteImage = function (oImage)
{
	return this.__bAjouteDino(this.m_oDonnees.m_tabImages, oImage);
};

// Modification tableau images
WDCarte.prototype.SetTableauImage = function (tabImage)
{
	this.m_oDonnees.m_tabImages = tabImage;
};

// CarteSupprimeImage
WDCarte.prototype.SupprimeImage = function (oImage)
{
	return this.__bSupprimeObjet(WDDinoCarteImage, this.m_oDonnees.m_tabImages, oImage, this.SetTableauImage, this.m_oModele.MAP_SupprimeImage, this.m_oModele.MAP_SupprimeToutImage);
};

// CarteModifieImage
WDCarte.prototype.ModifieImage = function (oImage)
{
	return this.__bModifieObjet(WDDinoCarteImage, this.m_oDonnees.m_tabImages, oImage);
};

// Pour CarteSupprimeTout
WDCarte.prototype.SupprimeToutImage = function ()
{
	return this.__bSupprimeToutObjet(this.SetTableauImage, this.m_oModele.MAP_SupprimeToutImage);
};

// CarteSuitD�placement
WDCarte.prototype.SuitDeplacement = function(Boussole, NomProcedure)
{
	//�vite de noter les donn�es alors que justement on applique les donn�es d�j� not�es
	if (!this.m_bPendantReInit)
	{
		//maj les donn�es
		this.m_oSuitDeplacement = arguments;
		//pas de carte ? pas d'action imm�diate
		if (!this.oRecupereAPI())
		{
			return true;
		}
	}
	return this.m_oModele.MAP_SuitDeplacement(Boussole, NomProcedure);
};
// CarteFinD�placement
WDCarte.prototype.FinDeplacement = function()
{
	//maj les donn�es
	this.m_oSuitDeplacement = undefined;
	//pas de carte ? pas d'action imm�diate
	if (!this.oRecupereAPI())
	{
		return true;
	}
	return this.m_oModele.MAP_FinDeplacement();
};
// CarteR�cup�reAPI
WDCarte.prototype.oRecupereAPI = function()
{
	return this.m_oModele.m_clCarte;
};
// CarteDistanceItin�raire
WDCarte.prototype.DistanceItineraire = function(nID)
{
	return this.m_oModele.MAP_DistanceItineraire(nID);
};

//source: https://github.com/douglascrockford/JSON-js/blob/master/json.js
/*
    json.js
    2014-02-04

    Public Domain

    No warranty expressed or implied. Use at your own risk.

    This file has been superceded by http://www.JSON.org/json2.js

    See http://www.JSON.org/js.html

    This code should be minified before deployment.
    See http://javascript.crockford.com/jsmin.html

    USE YOUR OWN COPY. IT IS EXTREMELY UNWISE TO LOAD CODE FROM SERVERS YOU DO
    NOT CONTROL.

    This file adds these methods to JavaScript:

        object.toJSONString(whitelist)
            This method produce a JSON text from a JavaScript value.
            It must not contain any cyclical references. Illegal values
            will be excluded.

            The default conversion for dates is to an ISO string. You can
            add a toJSONString method to any date object to get a different
            representation.

            The object and array methods can take an optional whitelist
            argument. A whitelist is an array of strings. If it is provided,
            keys in objects not found in the whitelist are excluded.

        string.parseJSON(filter)
            This method parses a JSON text to produce an object or
            array. It can throw a SyntaxError exception.

            The optional filter parameter is a function which can filter and
            transform the results. It receives each of the keys and values, and
            its return value is used instead of the original value. If it
            returns what it received, then structure is not modified. If it
            returns undefined then the member is deleted.

            Example:

            // Parse the text. If a key contains the string 'date' then
            // convert the value to a date.

            myData = text.parseJSON(function (key, value) {
                return key.indexOf('date') >= 0 ? new Date(value) : value;
            });

    This file will break programs with improper for..in loops. See
    http://yuiblog.com/blog/2006/09/26/for-in-intrigue/

    This file creates a global JSON object containing two methods: stringify
    and parse.

        JSON.stringify(value, replacer, space)
            value       any JavaScript value, usually an object or array.

            replacer    an optional parameter that determines how object
                        values are stringified for objects. It can be a
                        function or an array of strings.

            space       an optional parameter that specifies the indentation
                        of nested structures. If it is omitted, the text will
                        be packed without extra whitespace. If it is a number,
                        it will specify the number of spaces to indent at each
                        level. If it is a string (such as '\t' or '&nbsp;'),
                        it contains the characters used to indent at each level.

            This method produces a JSON text from a JavaScript value.

            When an object value is found, if the object contains a toJSON
            method, its toJSON method will be called and the result will be
            stringified. A toJSON method does not serialize: it returns the
            value represented by the name/value pair that should be serialized,
            or undefined if nothing should be serialized. The toJSON method
            will be passed the key associated with the value, and this will be
            bound to the object holding the key.

            For example, this would serialize Dates as ISO strings.

                Date.prototype.toJSON = function (key) {
                    function f(n) {
                        // Format integers to have at least two digits.
                        return n < 10 ? '0' + n : n;
                    }

                    return this.getUTCFullYear()   + '-' +
                         f(this.getUTCMonth() + 1) + '-' +
                         f(this.getUTCDate())      + 'T' +
                         f(this.getUTCHours())     + ':' +
                         f(this.getUTCMinutes())   + ':' +
                         f(this.getUTCSeconds())   + 'Z';
                };

            You can provide an optional replacer method. It will be passed the
            key and value of each member, with this bound to the containing
            object. The value that is returned from your method will be
            serialized. If your method returns undefined, then the member will
            be excluded from the serialization.

            If the replacer parameter is an array of strings, then it will be
            used to select the members to be serialized. It filters the results
            such that only members with keys listed in the replacer array are
            stringified.

            Values that do not have JSON representations, such as undefined or
            functions, will not be serialized. Such values in objects will be
            dropped; in arrays they will be replaced with null. You can use
            a replacer function to replace those with JSON values.
            JSON.stringify(undefined) returns undefined.

            The optional space parameter produces a stringification of the
            value that is filled with line breaks and indentation to make it
            easier to read.

            If the space parameter is a non-empty string, then that string will
            be used for indentation. If the space parameter is a number, then
            the indentation will be that many spaces.

            Example:

            text = JSON.stringify(['e', {pluribus: 'unum'}]);
            // text is '["e",{"pluribus":"unum"}]'


            text = JSON.stringify(['e', {pluribus: 'unum'}], null, '\t');
            // text is '[\n\t"e",\n\t{\n\t\t"pluribus": "unum"\n\t}\n]'

            text = JSON.stringify([new Date()], function (key, value) {
                return this[key] instanceof Date ?
                    'Date(' + this[key] + ')' : value;
            });
            // text is '["Date(---current time---)"]'


        JSON.parse(text, reviver)
            This method parses a JSON text to produce an object or array.
            It can throw a SyntaxError exception.

            The optional reviver parameter is a function that can filter and
            transform the results. It receives each of the keys and values,
            and its return value is used instead of the original value.
            If it returns what it received, then the structure is not modified.
            If it returns undefined then the member is deleted.

            Example:

            // Parse the text. Values that look like ISO date strings will
            // be converted to Date objects.

            myData = JSON.parse(text, function (key, value) {
                var a;
                if (typeof value === 'string') {
                    a =
/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
                    if (a) {
                        return new Date(Date.UTC(+a[1], +a[2] - 1, +a[3], +a[4],
                            +a[5], +a[6]));
                    }
                }
                return value;
            });

            myData = JSON.parse('["Date(09/09/2001)"]', function (key, value) {
                var d;
                if (typeof value === 'string' &&
                        value.slice(0, 5) === 'Date(' &&
                        value.slice(-1) === ')') {
                    d = new Date(value.slice(5, -1));
                    if (d) {
                        return d;
                    }
                }
                return value;
            });


    This is a reference implementation. You are free to copy, modify, or
    redistribute.
*/

/*jslint evil: true, regexp: true, unparam: true */

/*members "", "\b", "\t", "\n", "\f", "\r", "\"", JSON, "\\", apply,
    call, charCodeAt, getUTCDate, getUTCFullYear, getUTCHours,
    getUTCMinutes, getUTCMonth, getUTCSeconds, hasOwnProperty, join,
    lastIndex, length, parse, parseJSON, prototype, push, replace, slice,
    stringify, test, toJSON, toJSONString, toString, valueOf
*/


// Create a JSON object only if one does not already exist. We create the
// methods in a closure to avoid creating global variables.

if (typeof JSON !== 'object') {
    JSON = {};
}

(function () {
    'use strict';

    function f(n) {
        // Format integers to have at least two digits.
        return n < 10 ? '0' + n : n;
    }

    if (typeof Date.prototype.toJSON !== 'function') {

        Date.prototype.toJSON = function (/*key*/) {

            return isFinite(this.valueOf())
                ?     this.getUTCFullYear()   + '-' +
                    f(this.getUTCMonth() + 1) + '-' +
                    f(this.getUTCDate())      + 'T' +
                    f(this.getUTCHours())     + ':' +
                    f(this.getUTCMinutes())   + ':' +
                    f(this.getUTCSeconds())   + 'Z'
                : null;
        };

        String.prototype.toJSON      =
            Number.prototype.toJSON  =
            Boolean.prototype.toJSON = function (/*key*/) {
                return this.valueOf();
            };
    }

    var cx,
        escapable,
        gap,
        indent,
        meta,
        rep;


    function quote(string) {

// If the string contains no control characters, no quote characters, and no
// backslash characters, then we can safely slap some quotes around it.
// Otherwise we must also replace the offending characters with safe escape
// sequences.

        escapable.lastIndex = 0;
        return escapable.test(string) ? '"' + string.replace(escapable, function (a) {
            var c = meta[a];
            return typeof c === 'string'
                ? c
                : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
        }) + '"' : '"' + string + '"';
    }


    function str(key, holder) {

// Produce a string from holder[key].

        var i,          // The loop counter.
            k,          // The member key.
            v,          // The member value.
            length,
            mind = gap,
            partial,
            value = holder[key];

// If the value has a toJSON method, call it to obtain a replacement value.

        if (value && typeof value === 'object' &&
                typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }

// If we were called with a replacer function, then call the replacer to
// obtain a replacement value.

        if (typeof rep === 'function') {
            value = rep.call(holder, key, value);
        }

// What happens next depends on the value's type.

        switch (typeof value) {
        case 'string':
            return quote(value);

        case 'number':

// JSON numbers must be finite. Encode non-finite numbers as null.

            return isFinite(value) ? String(value) : 'null';

        case 'boolean':
        case 'null':

// If the value is a boolean or null, convert it to a string. Note:
// typeof null does not produce 'null'. The case is included here in
// the remote chance that this gets fixed someday.

            return String(value);

// If the type is 'object', we might be dealing with an object or an array or
// null.

        case 'object':

// Due to a specification blunder in ECMAScript, typeof null is 'object',
// so watch out for that case.

            if (!value) {
                return 'null';
            }

// Make an array to hold the partial results of stringifying this object value.

            gap += indent;
            partial = [];

// Is the value an array?

            if (Object.prototype.toString.apply(value) === '[object Array]') {

// The value is an array. Stringify every element. Use null as a placeholder
// for non-JSON values.

                length = value.length;
                for (i = 0; i < length; i += 1) {
                    partial[i] = str(i, value) || 'null';
                }

// Join all of the elements together, separated with commas, and wrap them in
// brackets.

                v = partial.length === 0
                    ? '[]'
                    : gap
                    ? '[\n' + gap + partial.join(',\n' + gap) + '\n' + mind + ']'
                    : '[' + partial.join(',') + ']';
                gap = mind;
                return v;
            }

// If the replacer is an array, use it to select the members to be stringified.

            if (rep && typeof rep === 'object') {
                length = rep.length;
                for (i = 0; i < length; i += 1) {
                    k = rep[i];
                    if (typeof k === 'string') {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            } else {

// Otherwise, iterate through all of the keys in the object.

                for (k in value) {
                    if (Object.prototype.hasOwnProperty.call(value, k)) {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            }

// Join all of the member texts together, separated with commas,
// and wrap them in braces.

            v = partial.length === 0 ? '{}'
                : gap
                ? '{\n' + gap + partial.join(',\n' + gap) + '\n' + mind + '}'
                : '{' + partial.join(',') + '}';
            gap = mind;
            return v;
        }
    }

// If the JSON object does not yet have a stringify method, give it one.

    if (typeof JSON.stringify !== 'function') {
        escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
        meta = {    // table of character substitutions
            '\b': '\\b',
            '\t': '\\t',
            '\n': '\\n',
            '\f': '\\f',
            '\r': '\\r',
            '"' : '\\"',
            '\\': '\\\\'
        };
        JSON.stringify = function (value, replacer, space) {

// The stringify method takes a value and an optional replacer, and an optional
// space parameter, and returns a JSON text. The replacer can be a function
// that can replace values, or an array of strings that will select the keys.
// A default replacer method can be provided. Use of the space parameter can
// produce text that is more easily readable.

            var i;
            gap = '';
            indent = '';

// If the space parameter is a number, make an indent string containing that
// many spaces.

            if (typeof space === 'number') {
                for (i = 0; i < space; i += 1) {
                    indent += ' ';
                }

// If the space parameter is a string, it will be used as the indent string.

            } else if (typeof space === 'string') {
                indent = space;
            }

// If there is a replacer, it must be a function or an array.
// Otherwise, throw an error.

            rep = replacer;
            if (replacer && typeof replacer !== 'function' &&
                    (typeof replacer !== 'object' ||
                    typeof replacer.length !== 'number')) {
                throw new Error('JSON.stringify');
            }

// Make a fake root object containing our value under the key of ''.
// Return the result of stringifying the value.

            return str('', {'': value});
        };
    }


// If the JSON object does not yet have a parse method, give it one.

    if (typeof JSON.parse !== 'function') {
        cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
        JSON.parse = function (text, reviver) {

// The parse method takes a text and an optional reviver function, and returns
// a JavaScript value if the text is a valid JSON text.

            var j;

            function walk(holder, key) {

// The walk method is used to recursively walk the resulting structure so
// that modifications can be made.

                var k, v, value = holder[key];
                if (value && typeof value === 'object') {
                    for (k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            v = walk(value, k);
                            if (v !== undefined) {
                                value[k] = v;
                            } else {
                                delete value[k];
                            }
                        }
                    }
                }
                return reviver.call(holder, key, value);
            }


// Parsing happens in four stages. In the first stage, we replace certain
// Unicode characters with escape sequences. JavaScript handles many characters
// incorrectly, either silently deleting them, or treating them as line endings.

            text = String(text);
            cx.lastIndex = 0;
            if (cx.test(text)) {
                text = text.replace(cx, function (a) {
                    return '\\u' +
                        ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }

// In the second stage, we run the text against regular expressions that look
// for non-JSON patterns. We are especially concerned with '()' and 'new'
// because they can cause invocation, and '=' because it can cause mutation.
// But just to be safe, we want to reject all unexpected forms.

// We split the second stage into 4 regexp operations in order to work around
// crippling inefficiencies in IE's and Safari's regexp engines. First we
// replace the JSON backslash pairs with '@' (a non-JSON character). Second, we
// replace all simple value tokens with ']' characters. Third, we delete all
// open brackets that follow a colon or comma or that begin the text. Finally,
// we look to see that the remaining characters are only whitespace or ']' or
// ',' or ':' or '{' or '}'. If that is so, then the text is safe for eval.

            if (/^[\],:{}\s]*$/
                    .test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
                        .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
                        .replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

// In the third stage we use the eval function to compile the text into a
// JavaScript structure. The '{' operator is subject to a syntactic ambiguity
// in JavaScript: it can begin a block or an object literal. We wrap the text
// in parens to eliminate the ambiguity.

                j = eval('(' + text + ')');

// In the optional fourth stage, we recursively walk the new structure, passing
// each name/value pair to a reviver function for possible transformation.

                return typeof reviver === 'function'
                    ? walk({'': j}, '')
                    : j;
            }

// If the text is not JSON parseable, then a SyntaxError is thrown.

            throw new SyntaxError('JSON.parse');
        };
    }

// Augment the basic prototypes if they have not already been augmented.
// These forms are obsolete. It is recommended that JSON.stringify and
// JSON.parse be used instead.
    // if (!Object.prototype.toJSONString) {
        // Object.prototype.toJSONString = function (filter) {
            // return JSON.stringify(this, filter);
        // };
        // Object.prototype.parseJSON = function (filter) {
            // return JSON.parse(this, filter);
        // };
    // }
	
}());