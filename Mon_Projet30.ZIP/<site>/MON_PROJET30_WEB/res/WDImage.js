// WDImage.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDChamp.js
///#GLOBALS WDChampParametres

// Manipulation d'un champ image (avec defilement ou vignette)
function WDImage(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChampParametres.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]

		var oThis = this;
		this.m_pfDefilement = function () { oThis.Defilement(); };
	}
};

// Declare l'heritage
WDImage.prototype = new WDChampParametres();
// Surcharge le constructeur qui a ete efface
WDImage.prototype.constructor = WDImage;

// Par defaut le defilement est inactif (= pas de timer)
WDImage.prototype.m_bDefilement = false;
WDImage.prototype.m_nImage = -1;

// Declare les fonction une par une

// Initialisation :
WDImage.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype.Init.apply(this, arguments);

	// Considere la premiere image comme affichee par le serveur) (si on a une image)
	if (0 < this.nGetNbImages())
	{
		this.m_nImage = this.m_oDonnees.m_nImage;
		this.m_sImageSrc = this.m_oImage.src;
	}
	// Si visible et demande actif, lance le defilement
	this.__DefilementActionSelonServeur();
};

// Trouve les divers elements : liaison avec le HTML
WDImage.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vLiaisonHTML.apply(this, arguments);

	// Trouve le champ image
	this.m_oImage = this.oGetElementById(document, "");
	// Trouve la fonction d'affectation de la valeur
	// (6 propriete image en JS)
	this.m_fSetImage = window["_SET_" + this.m_sAliasChamp + "_6_S"];
};

// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
WDImage.prototype.OnDisplay = function OnDisplay(oElementRacine/*, bAffiche*/)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype.OnDisplay.apply(this, arguments);

	// GP 22/10/2012 : QW224559 : On ne filtre pas sur bAffiche : si on masque il faut arreter l'animation
	if (this.m_oImage && clWDUtil.bEstFils(this.m_oImage, oElementRacine))
	{
		// Arrete/Lance le defilement selon la visibilite
		this._DefilementAction();
	}
};

// Applique les parametres
WDImage.prototype._vAppliqueParametres = function _vAppliqueParametres(/*oParametreFusion*/)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vAppliqueParametres.apply(this, arguments);

	// Recree la liaison HTML
	this._vLiaisonHTML();
	// Affiche l'image demandee (si l'image est deja affichee, ne fait rien)
	this.AfficheImageExterne(this.m_oDonnees.m_nImage);
	// MAJ de l'affichage en relancant le defilement si besoin
	this.__DefilementActionSelonServeur();
};

// Pour implementer ConstruitParam (accepte des parametres variables)
WDImage.prototype._vsConstruitParam = function _vsConstruitParam()
{
	var tabParam = [];
	// Appel de la methode de la classe de base
	var sParam = WDChampParametres.prototype._vsConstruitParam.apply(this, arguments);
	if (sParam.length > 0)
	{
		tabParam.push(sParam);
	}

	// Activite du defilement
	tabParam.push(this.bGetDefilement());
	// Position dans le defilement
	tabParam.push(this.nGetImage());

	return tabParam.join(',');
};

// - Champ image : d�but de de l'animation
WDImage.prototype._vAnimationDebut = function _vAnimationDebut(oAnimation)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vAnimationDebut.apply(this, arguments);

	// GP 22/10/2012 : QW224559 : M�morise l'animation
	this.m_oAnimation = oAnimation;
};

// - Champ image : fin de l'animation
WDImage.prototype._vAnimationFin = function _vAnimationFin(/*oAnimation*/)
{
	// GP 22/10/2012 : QW224559 : Normalement l'animation que l'on a m�moris�e est la m�me
	// this.m_oAnimation = oAnimation
	this.m_oAnimation = null;
	delete this.m_oAnimation;

	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vAnimationFin.apply(this, arguments);

	// Tente d'afficher une image en attente
	this.__AfficheImage();
};

// Lance arrete le defilement en fonction de l'action serveur
WDImage.prototype.__DefilementActionSelonServeur = function __DefilementActionSelonServeur()
{
	this.__DefilementModifie(this.m_oDonnees.m_bActif);
};

// Action sur le defilement
WDImage.prototype.__DefilementModifie = function __DefilementModifie(bDefilement)
{
	// Force l'etat
	this.m_bDefilement = bDefilement;

	// Et appel la methode interne
	this._DefilementAction();
	this.ConstruitParam();
};

// Action sur le defilement
WDImage.prototype._DefilementAction = function _DefilementAction()
{
	// Calcule le nouvel etat effectif : si le defilement effectif change, effectue l'action requise
	if (this._vbGetDefilementEffectif())
	{
		this.__DefilementLance();
	}
	else
	{
		this.__DefilementArrete();
	}
};

// Lance effectivement le defilement
WDImage.prototype.__DefilementLance = function __DefilementLance()
{
	// Seulement si on a pas deja un timer (le defilement inactif)
	if (!this.bGetTimeXXXExiste("Defilement"))
	{
		// Lance le defilement
		this.SetInterval("Defilement", this.m_pfDefilement, this.m_oParametres.m_nTemporisation * 10);
	}
};

// Arret du defilement
WDImage.prototype.__DefilementArrete = function __DefilementArrete()
{
	this.AnnuleTimeXXX("Defilement", true);
	// GP 22/10/2012 : QW224559 : Annule l'animation
	// GP 30/10/2012 : QW225168 : Sauf si on est en animation manuelle. Car alors on n'a jamais l'animation.
	if (this.m_oAnimation && this.bGetDefilement())
	{
		this.m_oAnimation.vAnnule();
	}
};

// Effectue le defilement
WDImage.prototype.Defilement = function Defilement()
{
	// Si le defilement est toujours actif
	// GP 22/10/2012 : QW224559 : Teste si le d�filement est encore actif (on ne sait pas si on a �t� masqu� entre temps)
	if (this.bGetTimeXXXExiste("Defilement") && this._vbGetDefilementEffectif())
	{
		// Affiche l'image suivante
		this._AfficheImage(this.nGetImage() + 1);
	}
};

// Calcule de defilement effectif
// Virtuel car surcharge par le champ vignette qui tient compte de l'ouverture
WDImage.prototype._vbGetDefilementEffectif = function _vbGetDefilementEffectif()
{
	// S'il n'y a pas de d�filement
	if (!this.bGetDefilement())
	{
		return false;
	}
	// Si on arrive ici c'est qu'il y a un d�filement : donc la r�ponse est plutot "true"

	// GP 17/09/2012 : TB79062 : Les d�filements jouent sur la visibilit� aussi
	// Il faut en tenir compte
	if (clWDUtil.bEstDisplay(this.m_oImage, document, true))
	{
		return true;
	}
	// Si on arrive ici c'est que l'image n'est pas visible : donc la r�ponse est plutot "false"

	// GP 26/09/2012 : QW223072 : Sauf que pour certaines animations le champ est invisible
	if (undefined !== window["WDAnimSurImage"])
	{
		var oAnimationSurLeChamp = WDAnimSurImage.prototype.ms_oAnimations[this.m_sAliasChamp];
		// Si on a une animation (pas sur) avec une image secondaire (normalement toujours)
		if (oAnimationSurLeChamp && oAnimationSurLeChamp.m_oBaliseImgTemp)
		{
			return clWDUtil.bEstDisplay(oAnimationSurLeChamp.m_oBaliseImgTemp, document, true);
		}
	}

	// Si on arrive ici c'est que l'image n'est pas visible : donc la r�ponse est "false"
	return false;
};

// Si le defilement est actif
WDImage.prototype.bGetDefilement = function bGetDefilement()
{
	return this.m_bDefilement;
};

// Position dans le defilement
WDImage.prototype.nGetImage = function nGetImage()
{
	return this.m_nImage;
};

// Affiche une image en relancant le defilement
WDImage.prototype.AfficheImageExterne = function AfficheImageExterne(nPosition)
{
	// Pour avoir un defilement avec le bon interval : arrete puis relance le defilement
	this.__DefilementArrete();
	this._AfficheImage(nPosition);
	this._DefilementAction();
};

// Affiche une image
WDImage.prototype._AfficheImage = function _AfficheImage(nImage)
{
	// Valide la position
	// => Si on n'a pas d'image, invalide la position et note que l'image est valide
	if (0 == this.nGetNbImages())
	{
		this.m_nImage = -1;
		delete this.m_sImageSrc;
	}
	else
	{
		if (nImage < 0)
		{
			nImage -= Math.floor(nImage / this.nGetNbImages()) * this.nGetNbImages();
		}
		else if (nImage >= this.nGetNbImages())
		{
			nImage = 0;
		}

		// Uniquement si l'image est deja affichee : ne fait rien
		if (this.nGetImage() != nImage)
		{
			this.m_nImage = nImage;
			// Invalide la position effective (force le reaffichage)
			delete this.m_sImageSrc;
		}
		// Regarde si l'image courante ne serait pas par hasard une image differente (changement de source sur le serveur)
		else if (this.m_sImageSrc && (this.m_sImageSrc != this.m_oImage.src))
		{
			delete this.m_sImageSrc;
		}

		// Affiche l'image si besoin
		this.__AfficheImage();
	}
	this.ConstruitParam();
};

// Affiche une image
WDImage.prototype.__AfficheImage = function __AfficheImage()
{
	// Si la position effective est differente de l'image affichee, l'affiche
	// Si on a une animation en cours, on n'affiche pas l'image on l'affichera a la fin de l'animation
	if ((undefined === this.m_sImageSrc) && !this.bAnimationsActives())
	{
		var oImage = this.m_oDonnees.m_tabImages[this.m_nImage];
		// Et affiche l'image (l'animation est faite automatiquement)
		this.m_fSetImage(oImage.m_sSrc);
		// Valide l'image
		this.m_sImageSrc = this.m_oImage.src;
	}
};

//////////////////////////////////////////////////////////////////////////
// Interface pour le WL

// ImageLanceDefilement
WDImage.prototype.LanceDefilement = function LanceDefilement()
{
	this.__DefilementModifie(true);
};

// ImageArreteDefilement
WDImage.prototype.ArreteDefilement = function ArreteDefilement()
{
	this.__DefilementModifie(false);
};

// ImagePremier
WDImage.prototype.AffichePremier = function AffichePremier()
{
	this.AfficheImageExterne(0);
};

// ImagePrecedent
WDImage.prototype.AffichePrecedent = function AffichePrecedent()
{
	this.AfficheImageExterne(this.nGetImage() - 1);
};

// ImageSuivant
WDImage.prototype.AfficheSuivant = function AfficheSuivant()
{
	this.AfficheImageExterne(this.nGetImage() + 1);
};

// ImageDernier
WDImage.prototype.AfficheDernier = function AfficheDernier()
{
	this.AfficheImageExterne(this.nGetNbImages() - 1);
};

// ImagePositionDefilement
WDImage.prototype.nGetPositionWL = function nGetPositionWL()
{
	return this.nGetImage() + 1;
};
WDImage.prototype.SetPositionWL = function SetPositionWL(nPositionWL)
{
	this.AfficheImageExterne(nPositionWL - 1);
};

// ImageOccurrence
WDImage.prototype.nGetNbImages = function nGetNbImages()
{
	return this.m_oDonnees.m_tabImages.length;
};
