// WDJSONScript.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - La page
///#GLOBALS _PAGE_
// - WDAJAX.js
///#GLOBALS clWDAJAXMain

// Objet global de suivi des appels JSONScript
var clWDJSONScriptMain = (function()
{
	"use strict";

	var ms_nID = 0;
	return {
		// JSONExecute :
		// - 1 param�tre (pas de callback) : syntaxe synchrone (bloquant)
		// - 2 param�tre (avec callback) : syntaxe asynchrone (non-bloquant)
		// Declenche un appel sur un URL autorise :
		// - Sur le m�me serveur
		// - Sur un serveur qui impl�mente le protcole CORS
		JSONExecute: function JSONExecute(sURL, pfCallback)
		{
			if (1 == arguments.length)
			{
				// Execute l'appel serveur le resultat de l'appel serveur
				var sRes = clWDAJAXMain.sRequeteSynchroneTexte(false, "", sURL, _PAGE_);

				// Traite le resultat SANS validation
				return clWDUtil.oEvalJSON(sRes, {});
			}
			else
			{
				// Execute l'appel serveur en donnant une callback
				clWDAJAXMain.sRequeteAsynchroneTexte(false, "", sURL, function(sResultat)
				{
					// Appele la callback utilisateur SANS validation
					pfCallback(clWDUtil.oEvalJSON(sResultat, {}));
				}, clWDAJAXMain.ms_nAJAXExecuteJSONExterne);
			}
		},

		// JSONExecuteExterne
		JSONExecuteExterne: function JSONExecuteExterne(sURL, sParamCallback, pfCallback)
		{
			// Init des valeurs a memoriser
			var sNomCallback = "Requete_" + ms_nID++;
			// Creation de la balise src
			var oScript = document.createElement("script");
			// Et cible de la balise
			oScript.src = sURL + ((sURL.indexOf('?') == -1) ? '?' : '&') + sParamCallback + '=' + sNomCallback;
			oScript.charset = "UTF-8";

			// Creation de la callback (cr�ation d'une closure qui r�f�rence les variables locales
			window[sNomCallback] = function(oValeur)
			{
				// Appele la callback utilisateur SANS validation
				pfCallback(oValeur);

				// Supprime la balise de la page
				clWDUtil.oSupprimeElement(oScript);

				// Supprime la callback globale intermediaire
				// On ne peut pas la supprimer donc on la met a null pour ne pas perdre trop de memoire
				// Normalement la callback contient la derniere r�f�rence vers this (enfin la derni�re en plus du contexte courant)
				window[sNomCallback] = null;
			};

			// Finalement, ajout de la balise dans la page cequi d�clenche le tel�chargement
			oScript = document.body.appendChild(oScript);
		}
	};
})();
// Par compatibilit� avec les pages 21-
clWDJSONScriptMain.JSONScriptExecute = clWDJSONScriptMain.JSONExecuteExterne;
