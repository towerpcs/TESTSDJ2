// WDJauge.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - StdAction.js
///#GLOBALS _JGE
// - WDUtil.js
///#GLOBALS bIEQuirks9Max
// - WDAJAX.js
///#GLOBALS clWDAJAXMain
// - WDChamp.js
///#GLOBALS WDChampParametres

// Manipulation d'un champ image (avec defilement ou vignette)
function WDJauge(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChampParametres.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
	}
};

// Declare l'heritage
WDJauge.prototype = new WDChampParametres();
// Surcharge le constructeur qui a ete efface
WDJauge.prototype.constructor = WDJauge;

//static
// Le fonctionnement par pourcentage fonctionne (et est obligatoire) en RWD.
// Id�e : L'activer aussi en HTML5 ? (sauf peut-�tre en IE)
WDJauge.ms_bOptimCalculeViaPourcentage = clWDUtil.bRWD || clWDUtil.bHTML5;

// Declare les fonction une par une

// Initialisation :
WDJauge.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype.Init.apply(this, arguments);

	// Force un test sur la validite de l'AJAX
	// Car sinon lors de la MAJ de l'etat du serveur on aura une page en cours de chargement :
	// this.m_bChargementTermine non defini + page en cours de chargement = pas d'AJAX alors que ce n'est pas vrai
	clWDAJAXMain.bWDAJAXMainValide();

	// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
	this.__AfficheMAJComplete();	
};

// Trouve les divers elements : liaison avec le HTML
WDJauge.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vLiaisonHTML.apply(this, arguments);

	// Lien avec la cellule externe (donne la taille totale), interne et le libelle
	this.m_oCelluleExterne = this.oGetIDElement("EXT");
	this.m_oCelluleInterne = this.oGetElementById(document, "");
	this.m_oLibelle = document.getElementById("lz" + this.m_sAliasChamp);
	this.m_oLibelleInterne = this.m_oLibelle.getElementsByTagName("td")[0];
};

// Applique les parametres
WDJauge.prototype._vAppliqueParametres = function _vAppliqueParametres(/*oParametreFusion*/)
{
	WDChampParametres.prototype._vAppliqueParametres.apply(this, arguments);

	// Arrete toute jauge navigateur
	this.__JaugeNavigateurArrete();

	// Notifie du changement de la valeur
	this.__OnMAJValeur(this.__oGetJaugeDonnees());
};

// Recupere la valeur
WDJauge.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp)
{
	// Conversion de la valeur en booleen
//	var nValeur = parseInt(sValeur, 10);
	var dValeur = this.__dGetValeur(this.__oGetJaugeDonnees());

	// Appel de la methode de la classe de base et retour de son resultat
	return WDChampParametres.prototype.GetValeur.apply(this, [oEvent, dValeur, oChamp]);
};

// Ecriture de la valeur du champ en programmation
WDJauge.prototype.SetValeur = function SetValeur(oEvent, sValeur/*, oChamp*/)
{
	// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
	WDChampParametres.prototype.SetValeur.apply(this, arguments);

	var oJaugeDonnees = this.__oGetJaugeDonnees();

	// Fixe la valeur
	this.__SetValeur(oJaugeDonnees, sValeur);

	// Dans tous les cas : retourne la vraie valeur
	return this.__dGetValeur(oJaugeDonnees);
};

// Lit les proprietes dont l'indication
WDJauge.prototype.GetProp = function GetProp(eProp/*, oEvent*//*, oValeur*//*, oChamp*/)
{
	switch (eProp)
	{
	case this.XML_CHAMP_PROP_NUM_COULEUR:
		return clWDUtil.oGetCurrentStyle(this.m_oLibelleInterne).color;
	case this.XML_CHAMP_PROP_NUM_COULEURFOND:
		return clWDUtil.oGetCurrentStyle(this.m_oCelluleExterne).backgroundColor;
	case this.XML_CHAMP_PROP_NUM_BORNEMIN:
		return this.__oGetJaugeDonnees().vdBorneMin();
	case this.XML_CHAMP_PROP_NUM_BORNEMAX:
		return this.__oGetJaugeDonnees().vdBorneMax(true);
	case this.XML_CHAMP_PROP_NUM_COULEURJAUGE:
		return clWDUtil.oGetCurrentStyle(this.m_oCelluleInterne).backgroundColor;
	default:
		// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
		return WDChampParametres.prototype.GetProp.apply(this, arguments);
	}
};


WDJauge.prototype.SetProp = function SetProp(eProp, oEvent, oValeur/*, oChamp*//*, oXMLAction*/)
{
	// Implementation de la classe de base
	oValeur = WDChampParametres.prototype.SetProp.apply(this, arguments);

	var oExterne = _JGE(this.m_sAliasChamp, document, true);

	switch (eProp)
	{
	case this.XML_CHAMP_PROP_NUM_HAUTEUR:
		// GP 25/03/2013 : TB81732 : @@@ Le calcul ne tient pas compte du mode de box sizing et de la bordure
		// Traite le cas de ..Hauteur : modifie les 3 hauteur
		this.m_oCelluleExterne.style.height = oValeur + "px";
		this.m_oCelluleInterne.style.height = oValeur + "px";
		this.m_oLibelle.style.height = oValeur + "px";
		return oValeur;
	case this.XML_CHAMP_PROP_NUM_LARGEUR:
		// GP 25/03/2013 : TB81732 : @@@ Le calcul ne tient pas compte du mode de box sizing et de la bordure
		// Traite le cas de ..Largeur : modifie la largeur des contenant et recalcule la largeur de la barre
		this.m_oCelluleExterne.style.width = oValeur + "px";
		this.m_oCelluleInterne.style.width = (oValeur * this.__dValeurPourcentage(this.__oGetJaugeDonnees())) + "px";
		this.m_oLibelle.style.width = oValeur + "px";
		// Il faut modifier la cellule interne
		// GP 25/03/2013 : TB81732 : On fait aussi la table externe
		oExterne.getElementsByTagName("table")[0].width = oValeur;
		oExterne.getElementsByTagName("td")[0].width = oValeur;
		// La cellule externe
		oExterne.style.width = oValeur + "px";
		return oValeur;
	case this.XML_CHAMP_PROP_NUM_COULEUR:
		this.m_oLibelleInterne.style.color = oValeur;
		return oValeur;
	case this.XML_CHAMP_PROP_NUM_COULEURFOND:
		this.m_oCelluleExterne.style.backgroundColor = oValeur;
		return oValeur;
	case this.XML_CHAMP_PROP_NUM_BULLE:
		this.m_oCelluleExterne.title = oValeur;
		return oValeur;
	case this.XML_CHAMP_PROP_NUM_OPACITE:
		// GP 15/05/2013 : TB81833 : C'est l'inverse, il faut mettre sur l'�l�ment le plus externe
		// On calcule qui est le plus externe entre oExterne et this.m_oCelluleExterne
		var oPlusExterne = oExterne;
		var oPlusInterne = this.m_oCelluleExterne;
		if (false == clWDUtil.bEstFils(this.m_oCelluleExterne, oExterne))
		{
			oPlusExterne = this.m_oCelluleExterne;
			oPlusInterne = oExterne;
		}
		// GP 21/11/2012 : QW226469 : Appel de clWDUtil.nSetOpacite
		clWDUtil.nSetOpacite(oValeur, oPlusExterne);
		// Uniquement si on est en mode quirks (sauf IE10+)
		// GP 15/05/2013 : TB81833 : Et si le externe n'est pas un DIV
		// - table : ne combine pas les opacite
		// - div : (si superposable) combine les opacit�
		if (bIEQuirks9Max && !clWDUtil.bBaliseEstTag(oPlusExterne, "div"))
		{
			clWDUtil.nSetOpacite(oValeur, oPlusInterne);
		}
		return oValeur;
	case this.XML_CHAMP_PROP_NUM_BORNEMIN:
		return this.__dSetBorne(oValeur, false);
	case this.XML_CHAMP_PROP_NUM_BORNEMAX:
		return this.__dSetBorne(oValeur, true);
	case this.XML_CHAMP_PROP_NUM_COULEURJAUGE:
		this.m_oCelluleInterne.style.backgroundColor = oValeur;
		return oValeur;
	default:
		// Retourne inchangee la valeur de la propriete
		return oValeur;
	}
};

// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
WDJauge.prototype.OnDisplay = function OnDisplay(oElementRacine, bAffiche)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype.OnDisplay.apply(this, arguments);

	if (bAffiche && this.m_oCelluleExterne && clWDUtil.bEstFils(this.m_oCelluleExterne, oElementRacine))
	{
		// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
		this.__AfficheMAJComplete();
	}
};

// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
// Le dessin par pourcentage rend inutile l'�coute de resize
WDJauge.prototype._vOnResize = WDJauge.ms_bOptimCalculeViaPourcentage ? clWDUtil.m_pfVide : function _vOnResize(/*oEvent*/)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vOnResize.apply(this, arguments);

	// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
	this.__AfficheMAJComplete();
};

// Notifie du changement de la valeur : MAJ de l'affichage + memorisation dans le formulaire
WDJauge.prototype.__OnMAJValeur = function __OnMAJValeur(oJaugeDonnees)
{
	// Ecrit la valeur dans le champ formulaire
	// Meme dans le cas du parcours navigateur car il tient compte des bornes
	this._vSetValeurChampFormulaire(this.__dGetValeur(oJaugeDonnees));

	// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
	this.__AfficheMAJComplete();
};

// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
WDJauge.prototype.__AfficheMAJComplete = function __AfficheMAJComplete()
{
	this.__AfficheInterne(true);
};

// MAJ de l'affichage
WDJauge.prototype.__Affiche = function __Affiche()
{
	this.__AfficheInterne(this.m_nLargeurExterne === undefined);
};

// Dessine la jauge
WDJauge.prototype.__AfficheInterne = function __AfficheInterne(bRecalculeTaille)
{
	// Choix des donnees
	var oJaugeDonnees = this.__oGetJaugeDonnees();

	// Inutile de recalculer la taille si le champ est a z�ro (_nGetOffsetWidth est parfois lent selon la page/la machine/l'OS avec IE8- en quirks)
	var dValeurPourcentage = this.__dValeurPourcentage(oJaugeDonnees);

	if (WDJauge.ms_bOptimCalculeViaPourcentage)
	{
		//inutile de redessiner si la valeur est d�j� celle dessin�e
		if (this.m_dValeurPourcentageDessine == dValeurPourcentage)
		{
			return;
		}
		//applique le pourcentage dans le dessin
		this.m_oCelluleInterne.style.width = (dValeurPourcentage*100) + "%";
		//note le dernier pourcentage dessin�
		this.m_dValeurPourcentageDessine = dValeurPourcentage;
	}
	else
	{
		var nLargeurInterne;
		if (0.0 < dValeurPourcentage)
		{
			// Trouve la taille de l'element externe
			if (bRecalculeTaille)
			{
				//�vite � cellule interne elle m�me de pousser
				this.m_oCelluleInterne.style.position = "absolute";
				this.m_nLargeurExterne = this._nGetOffsetWidth(this.m_oCelluleExterne);
				//replace la cellule interne afin qu'elle 
				this.m_oCelluleInterne.style.position = "static";
			}

			// Calcule la taille interne
			// GP 12/02/2015 : Limite la largeur � 100%
			nLargeurInterne = this.m_nLargeurExterne * Math.min(dValeurPourcentage, 1);
		}
		else
		{
			if (undefined !== this.m_nLargeurExterne)
			{
				delete this.m_nLargeurExterne;
			}
			nLargeurInterne = 0;
		}
		this.m_oCelluleInterne.style.width = nLargeurInterne + "px";
	}

	// Affiche le libelle
	this.__AfficheLibelle(oJaugeDonnees);
};

// Affiche le libelle
WDJauge.prototype.__AfficheLibelle = function __AfficheLibelle(oJaugeDonnees)
{
	var sLibelle = "";

	// Si on affiche le libelle
	if (this.m_oParametres.m_bAffichePourcentage)
	{
		// Uniquement si on affiche les 0 ou si la valeur n'est pas 0
		if ((!this.m_oParametres.m_bVideSiNull) || (oJaugeDonnees.vdValeur() != 0))
		{
			sLibelle = clWDUtil.sEncodeInnerHTML(oJaugeDonnees.vsValeurAffichee(this), true, false);
		}
	}

	this.m_oLibelleInterne.innerHTML = sLibelle;
};

// Arret des jauge serveur ET navigateur
WDJauge.prototype.__JaugeArrete = function __JaugeArrete()
{
	this.__JaugeServeurArrete();
	this.__JaugeNavigateurArrete();
};

// Trouve la jauge des donnees
WDJauge.prototype.__oGetJaugeDonnees = function __oGetJaugeDonnees()
{
	return this.m_oJaugeNavigateur ? this.m_oJaugeNavigateur : this;
};

// Indique la valeur effective du champ jauge en tenant compte des bornes serveur (pour les parcours navigateurs)
WDJauge.prototype.__dGetValeur = function __dGetValeur(oJaugeDonnees)
{
	// Si on est dans un parcours navigateur on prend la valeur de l'avancement ramene au bornes serveurs
	if (this != oJaugeDonnees)
	{
		return this.vdBorneMin() + this.__dValeurPourcentage(oJaugeDonnees) * (this.vdBorneMax() - this.vdBorneMin());
	}
	else
	{
		// Sinon on retourne directement la valeur (eviter les erreurs d'arrondi)
		return oJaugeDonnees.vdValeur();
	}
};

// Fixe la valeur du champ
WDJauge.prototype.__SetValeur = function __SetValeur(oJaugeDonnees, sValeur)
{
	// Cast en numerique
	var dValeur = parseFloat(sValeur);
	// Fixe dans les bornes
	if (oJaugeDonnees.vdBorneMin() > dValeur)
	{
		dValeur = oJaugeDonnees.vdBorneMin();
	}
	else if (oJaugeDonnees.vdBorneMax() < dValeur)
	{
		dValeur = oJaugeDonnees.vdBorneMax();
	}

	oJaugeDonnees.vSetValeur(dValeur);

	// Notifie du changement de la valeur
	this.__OnMAJValeur(oJaugeDonnees);
};

// Formate une valeur
WDJauge.prototype.sFormateValeur = function sFormateValeur(oJaugeDonnees)
{
	// @@@ Formate selon le masque de %

	return parseInt(100 * this.__dValeurPourcentage(oJaugeDonnees), 10) + "%";
};

// Valeur en pourcentage d'avancement
WDJauge.prototype.__dValeurPourcentage = function __dValeurPourcentage(oJaugeDonnees)
{
	if (oJaugeDonnees.vdBorneMax() > oJaugeDonnees.vdBorneMin())
	{
		return (oJaugeDonnees.vdValeur() - oJaugeDonnees.vdBorneMin()) / (oJaugeDonnees.vdBorneMax() - oJaugeDonnees.vdBorneMin());
	}
	else
	{
		return 0;
	}
};

//////////////////////////////////////////////////////////////////////////
// Jauge serveur

// Lance effectivement la jauge serveur
WDJauge.prototype.__JaugeServeurLance = function __JaugeServeurLance(nPeriodeMs, bArretAutomatique)
{
	// Annule une precedente jauge : navigateur ET serveur
	this.__JaugeArrete();

	// Memorise l'option d'erret
	this.m_bArretAutomatique = bArretAutomatique;

	// Lance la nouvelle jauge
	var oThis = this;
	this.SetInterval("JaugeServeur", function() { oThis.__JaugeServeur(); }, nPeriodeMs);
};

// Arret de la jauge serveur
WDJauge.prototype.__JaugeServeurArrete = function __JaugeServeurArrete()
{
	// Annule une precedente jauge (si elle existe)
	this.AnnuleTimeXXX("JaugeServeur", true);
	if (this.m_bArretAutomatique !== undefined)
	{
		delete this.m_bArretAutomatique;
	}
};

// Appel de la jauge serveur
WDJauge.prototype.__JaugeServeur = function __JaugeServeur()
{
	// Recupere les donnees du serveur
	if (this.__bJaugeServeurMAJ())
	{
		// Affiche simplement la jauge avec les donnees courantes
		this.__Affiche();
	}
};

// Recupere les donnees du serveur
WDJauge.prototype.__bJaugeServeurMAJ = function __bJaugeServeurMAJ()
{
	// Appel AJAX vers le serveur
	var oResultat = clWDAJAXMain.oAJAXRecupereJauge(this.m_sAliasChamp);
	switch (oResultat.m_eJauge)
	{
	case 1:
		// 1 = La jauge n'est pas encore MAJ : pas de MAJ
		return false;
	case 2:
		// 2 = Nouvelle donnees : MAJ
		var oDonnees = this.m_oDonnees;
		var oJauge = oResultat.m_oJauge;
		oDonnees.m_dValeur = oJauge.m_dValeur;
		oDonnees.m_dBorneMin = oJauge.m_dBorneMin;
		oDonnees.m_dBorneMax = oJauge.m_dBorneMax;
		oDonnees.m_sValeurAffichee = oJauge.m_sValeurAffichee;
		return true;
	case 0:
	default:
		// 0 = Pas de requete : pas de MAJ
		if (this.m_bArretAutomatique)
		{
			this.__JaugeServeurArrete();
		}
		return false;
	}
};

//////////////////////////////////////////////////////////////////////////
// Jauge navigateur

// Lance effectivement la jauge navigateur
WDJauge.prototype.__JaugeNavigateurLance = function __JaugeNavigateurLance(oJaugeNavigateur)
{
	// Annule une precedente jauge : navigateur ET serveur
	this.__JaugeArrete();

	// Si la jauge n'est pas deja finie
	if (!oJaugeNavigateur.vbFini())
	{
		// Memorise l'objet
		this.m_oJaugeNavigateur = oJaugeNavigateur;

		// Fixe la valeur dans la jauge
		this._vSetValeurChampFormulaire(this.__dGetValeur(oJaugeNavigateur));

		// Lance la nouvelle jauge
		var oThis = this;
		this.SetInterval("JaugeNavigateur", function () { oThis.__JaugeNavigateur(); }, 1);
	}
};

// Arret de la jauge navigateur
WDJauge.prototype.__JaugeNavigateurArrete = function __JaugeNavigateurArrete()
{
	// Annule une precedente jauge (si elle existe)
	this.AnnuleTimeXXX("JaugeNavigateur", true);
	// Et libere l'objet (s'il existe)
	if (this.m_oJaugeNavigateur)
	{
		delete this.m_oJaugeNavigateur;
	}
};

// Appel de la jauge navigateur
WDJauge.prototype.__JaugeNavigateur = function __JaugeNavigateur()
{
	// On reteste si la position est valide (cas de la jauge sur un tableau qui a evolue)
	var bFini = false;
	if (this.m_oJaugeNavigateur && !this.m_oJaugeNavigateur.vbFini())
	{
		// Effectue l'action
		bFini = this.m_oJaugeNavigateur.bAction();

		// Notifie du changement de la valeur
		this.__OnMAJValeur(this.m_oJaugeNavigateur);
	}
	else
	{
		// Objet invalide ou jauge finie
		bFini = true;
	}

	// Si la jauge est finie
	if (bFini)
	{
		this.__JaugeNavigateurArrete();
	}
};

// Pour l'�criture des propri�t�s
WDJauge.prototype.__dSetBorne = function __dSetBorne(dBorne, bMax)
{
	var oJaugeDonnees = this.__oGetJaugeDonnees();
	dBorne = parseFloat(dBorne);
	if (bMax)
	{
		oJaugeDonnees.vSetBorneMax(dBorne);
	}
	else
	{
		oJaugeDonnees.vSetBorneMin(dBorne);
	}

	// Force l'affectation de la valeur :
	// - Force le placement des valeurs dans les bornes.
	// - Force le redessin
	this.__SetValeur(oJaugeDonnees, this.__dGetValeur(oJaugeDonnees));
};

//////////////////////////////////////////////////////////////////////////
// Interface pour le WL

// JaugeActive
WDJauge.prototype.JaugeActive = function JaugeActive(nPeriodeMs, bArretAutomatique)
{
	// Lance la jauge serveur (+ validation des parametres)
	this.__JaugeServeurLance(nPeriodeMs, bArretAutomatique)
};

// JaugeDesactive
WDJauge.prototype.JaugeDesactive = function JaugeDesactive()
{
	// Annule une precedente jauge : navigateur ET serveur
	this.__JaugeArrete();
};

// JaugeExecute
// Parametres = <Borne min>, <Borne max>[, <Pas>]
// ou			<Tableau de valeur>
WDJauge.prototype.JaugeExecute = function JaugeExecute(/*fCallback*/)
{
	// Trouve l'objet d'enumeration
	var oJaugeNavigateur;
	switch (typeof arguments[1])
	{
	case "object":
		oJaugeNavigateur = new WDJaugeNavigateurTableau(arguments[0], arguments[1]);
		break;

	default:
		oJaugeNavigateur = new WDJaugeNavigateurBornes(arguments[0], arguments[1], arguments[2], (arguments.length >= 4) ? arguments[3] : 1);
		break;
	}

	// Lance la nouvelle jauge
	this.__JaugeNavigateurLance(oJaugeNavigateur);
};

//////////////////////////////////////////////////////////////////////////
// Donnees sur les jauges

// Objet de base pour les donnees sur une jauge
// vdValeur : valeur
// vdBorneMin : valeur minimale
// vdBorneMax : valeur maximale
// vsValeurAffichee : valeur affichee
// WDJaugeDonnees (c'est une interface donc on ne lui donne pas d'implementation en JS

//////////////////////////////////////////////////////////////////////////
// Donnees sur les jauges serveur

// On utilise le champ jauge lui meme comme source de donnees (car il recoit m_oParametres et m_oDonnees)
// On en fait pas d'heritage de WDJaugeDonnees :
// - WDJaugeDonnees n'existe pas (interface)
// - On en sait pas faire d'heritage multiple

// vdValeur : valeur
WDJauge.prototype.vdValeur = function vdValeur()
{
	return this.m_oDonnees.m_dValeur;
};
WDJauge.prototype.vSetValeur = function vSetValeur(dValeur)
{
	this.m_oDonnees.m_dValeur = dValeur;

	// Recalcule la valeur affichee
	this.m_oDonnees.m_sValeurAffichee = this.sFormateValeur(this);
};

// Fixe les valeurs minimale et maximales
WDJauge.prototype.vSetBorneMin = function vSetBorneMin(dBorneMin)
{
	this.m_oDonnees.m_dBorneMin = dBorneMin;
};
WDJauge.prototype.vSetBorneMax = function vSetBorneMax(dBorneMax)
{
	this.m_oDonnees.m_dBorneMax = dBorneMax;
};

// vdBorneMin : valeur minimale
WDJauge.prototype.vdBorneMin = function vdBorneMin()
{
	return this.m_oDonnees.m_dBorneMin;
};
// vdBorneMax : valeur maximale
WDJauge.prototype.vdBorneMax = function vdBorneMax(/*bPourValeurWL*/)
{
	return this.m_oDonnees.m_dBorneMax;
};
// vsValeurAffichee : valeur affichee
WDJauge.prototype.vsValeurAffichee = function vsValeurAffichee(/*oChampJauge*/)
{
	return this.m_oDonnees.m_sValeurAffichee;
};

//////////////////////////////////////////////////////////////////////////
// Donnees sur les jauges navigateur

// Objet de base pour les jauge navigateur
function WDJaugeNavigateur (fCallback)
{
	// Si on est pas dans l'init d'un protoype
	if (fCallback)
	{
		this.m_fCallback = fCallback;
	}
};

// Interface que doivent implementer les classes derives
// vdValeur (WDJaugeDonnees) : valeur
// vSetValeur (WDJaugeDonnees) : fixe la valeur
// vdBorneMin (WDJaugeDonnees) : valeur minimale
// vdBorneMax (WDJaugeDonnees) : valeur maximale
// _vSuivant : passe a la valeur suivante
// vbFini : indique si l'enumeration est finie
// _voArguement : argument pour la callback a la position courante

// bAction : effectue l'action, passe a la valeur suivante et indique si l'enumeration est finie
WDJaugeNavigateur.prototype.bAction = function bAction()
{
	// Effectue l'action
	this.m_fCallback(this._voArguement());

	// Element suivant
	this._vSuivant();

	// Indique si l'enumeration est finie
	return this.vbFini();
};

// vsValeurAffichee : valeur affichee
WDJaugeNavigateur.prototype.vsValeurAffichee = function vsValeurAffichee(oChampJauge)
{
	return oChampJauge.sFormateValeur(this);
};

// Fixe les valeurs minimale et maximales
WDJaugeNavigateur.prototype.vSetBorneMin = function vSetBorneMin(/*dBorneMin*/)
{
	// Ne fait rien on peut ne pas manipuler les bornes dans ce cas
};
WDJaugeNavigateur.prototype.vSetBorneMax = function vSetBorneMax (/*dBorneMax*/)
{
	// Ne fait rien on peut ne pas manipuler les bornes dans ce cas
};

// Objet d'enumeration entre deux bornes
function WDJaugeNavigateurBornes(fCallback, dBorneMin, dBorneMax, dPas)
{
	WDJaugeNavigateur.prototype.constructor.apply(this, [fCallback]);

	this.m_dBorneMaxBoucle = dBorneMax;
	// On calcule la borne max pour correspondre au pas et permettre que la jauge termine exactement sur 100%
	// sinon si la borne max n'est pas congruente a la borne min modulo le pas alors la jauge n'affiche pas 100% a la fin
	// Actuellement dIteration est faux de 1 (il n'inclus pas la valeur de borne min)
	var dIteration = (dBorneMax - dBorneMin) / dPas;
	// On utilise parseInt pour avoir un arrondi vers zero meme pour les nombre negatif
	var nIteration = parseInt(dIteration, 10);
	dBorneMax = dBorneMin + (nIteration + 1) * dPas;

	this.m_dBorneMin = dBorneMin;
	this.m_dBorneMax = dBorneMax;
	this.m_dPas = dPas;
	this.m_dValeur = dBorneMin;
};

// Declare l'heritage
WDJaugeNavigateurBornes.prototype = new WDJaugeNavigateur();
// Surcharge le constructeur qui a ete efface
WDJaugeNavigateurBornes.prototype.constructor = WDJaugeNavigateurBornes;

// vdValeur : valeur
WDJaugeNavigateurBornes.prototype.vdValeur = function vdValeur()
{
	return this.m_dValeur;
};
// vSetValeur fixe la valeur
WDJaugeNavigateurBornes.prototype.vSetValeur = function vSetValeur(dValeur)
{
	this.m_dValeur = dValeur;
};

// vdBorneMin : valeur minimale
WDJaugeNavigateurBornes.prototype.vdBorneMin = function vdBorneMin()
{
	return this.m_dBorneMin;
};
// vdBorneMax : valeur maximale
WDJaugeNavigateurBornes.prototype.vdBorneMax = function vdBorneMax(bPourValeurWL)
{
	// GP 09/03/2018 : TB107727 : Pour la valeur WL, il ne faut pas retourner m_dBorneMax (qui est une valeur modifi�e pour avoir 100% � la fin)
	// mais m_dBorneMaxBoucle qui est la valeur donn�e par programmation.
	return bPourValeurWL ? this.m_dBorneMaxBoucle : this.m_dBorneMax;
};
// _vSuivant : passe a la valeur suivante
WDJaugeNavigateurBornes.prototype._vSuivant = function _vSuivant()
{
	// Element suivant
	this.m_dValeur += this.m_dPas;
};
// vbFini : indique si l'enumeration est finie
WDJaugeNavigateurBornes.prototype.vbFini = function vbFini()
{
	// Selon le sens
	if (this.m_dBorneMaxBoucle >= this.m_dBorneMin)
	{
		return (this.m_dValeur > this.m_dBorneMaxBoucle);
	}
	else
	{
		return (this.m_dValeur < this.m_dBorneMaxBoucle);
	}
};
// _voArguement : argument pour la callback a la position courante
WDJaugeNavigateurBornes.prototype._voArguement = function _voArguement()
{
	return this.m_dValeur;
};

// Objet d'enumeration sur un tableau
function WDJaugeNavigateurTableau(fCallback, tabValeurs)
{
	WDJaugeNavigateur.prototype.constructor.apply(this, [fCallback]);

	this.m_tabValeurs = tabValeurs;
	// Se place sur le premier element
	this.m_nPosition = 0;
};

// Declare l'heritage
WDJaugeNavigateurTableau.prototype = new WDJaugeNavigateur();
// Surcharge le constructeur qui a ete efface
WDJaugeNavigateurTableau.prototype.constructor = WDJaugeNavigateurTableau;

// vdValeur : valeur
WDJaugeNavigateurTableau.prototype.vdValeur = function vdValeur()
{
	return this.m_nPosition;
};
// vSetValeur fixe la valeur
WDJaugeNavigateurTableau.prototype.vSetValeur = function vSetValeur(dValeur)
{
	this.m_nPosition = parseInt(dValeur, 10);
};
// vdBorneMin : valeur minimale
WDJaugeNavigateurTableau.prototype.vdBorneMin = function vdBorneMin()
{
	// Il faut retourner 0 => on a this.m_tabValeurs.length etapes
	return 0;
};
// vdBorneMax : valeur maximale
WDJaugeNavigateurTableau.prototype.vdBorneMax = function vdBorneMax()
{
	// Il faut retourner this.m_tabValeurs.length => on a this.m_tabValeurs.length etapes
	return this.m_tabValeurs.length;
};
// _vSuivant : passe a la valeur suivante
WDJaugeNavigateurTableau.prototype._vSuivant = function _vSuivant()
{
	this.m_nPosition++;
};
// vbFini : indique si l'enumeration est finie
WDJaugeNavigateurTableau.prototype.vbFini = function vbFini()
{
	return (this.m_nPosition >= this.m_tabValeurs.length);
};
// _voArguement : argument pour la callback a la position courante
WDJaugeNavigateurTableau.prototype._voArguement = function _voArguement()
{
	return this.m_tabValeurs[this.m_nPosition];
};
