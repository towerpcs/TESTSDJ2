// WDLangage.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDAJAX.js
///#GLOBALS WDTypeAvance WDErreur

//////////////////////////////////////////////////////////////////////////
// Gestion des tableaux
var clWDTableau = {};

clWDTableau.ms_tabEtats = [];

// R�cup�re l'�tat pour un tableau s'il existe
clWDTableau.__oGetEtat = function __oGetEtat(tabTableau)
{
	var oEtatResultat;
	clWDUtil.bForEach(this.ms_tabEtats, function(oEtat)
	{
		if (oEtat.m_tabTableau === tabTableau)
		{
			// Arret de la recherche
			oEtatResultat = oEtat;
			return false;
		}
		else
		{
			return true;
		}
	});
	return oEtatResultat;
};

// D�fini un �tat du tableau
clWDTableau.__SetEtat = function __SetEtat(tabTableau, pfFonctionComparaison, nIndiceRecherche)
{
	var oEtat = this.__oGetEtat(tabTableau);
	if (undefined === oEtat)
	{
		oEtat = { m_tabTableau: tabTableau, m_pfFonctionComparaison: undefined, m_nIndiceRecherche: undefined };
		this.ms_tabEtats.push(oEtat);
	}
	if (undefined !== pfFonctionComparaison)
	{
		oEtat.m_pfFonctionComparaison = pfFonctionComparaison;
	}
	if (undefined !== nIndiceRecherche)
	{
		oEtat.m_nIndiceRecherche = nIndiceRecherche;
	}
};

// Indique si un element est un tableau associatif
clWDTableau.__bEstAssociatif = function __bEstAssociatif(oTableau)
{
	return (oTableau instanceof WDTableauAssociatif);
};
// Indique si un element est un tableau (non associatif)
// GP 11/10/2012 : QW223931 : Gestion des pseudo tableaux natifs
clWDTableau.__bEstTableau = function __bEstTableau(oTableau, bAvecPseudoTableauxNatif)
{
	// GP 07/11/2013 : QW238558 : Algo de d�tection plus complexe :
	// 1) Utilisation de instanceOf (ne marche pas entre les frames)
	if (oTableau instanceof Array)
	{
		return true;
	}
	// 2) Utilisation de Array.isArray si disponible
	else if (Array.isArray)
	{
		return Array.isArray(oTableau);
	}
	// 3) Test de objet mais avec .length en plus
	else if (("object" == typeof oTableau) && (undefined !== oTableau.length))
	{
		return true;
	}
	// GP 22/10/2012 : QW224571 : Sauf qu'il faut ignore les chaines car .length existe dessus
	else if (bAvecPseudoTableauxNatif && ("string" != typeof oTableau))
	{
		return (undefined !== oTableau.length);
	}
	else
	{
		return false;
	}
};

// Gestion des indices speciaux
clWDTableau.__oCalculIndiceEffectif = function __oCalculIndiceEffectif(tabTableau, oCle)
{
	// Gestion des cas particulier
	switch (oCle)
	{
	case 0x00000001:
		// PremierElement
	default:
		// GP 22/10/2015 : QW263861 : Utilise __xnGetIndiceC pour avoir une erreur sur un indice invalide
//		return oCle - 1;
		return this.__xnGetIndiceC(tabTableau, oCle, false);
	case WDIterateur.prototype.ms_oElementCourant:
		// ElementCourant
		var oIterateur = WDIterateur.prototype.s_oGetIterateur(tabTableau);
		if (oIterateur)
		{
			return oIterateur.nGetCompteurDirect();
		}
		else
		{
			return undefined;
		}
		return 0;
	case 0x87654322:
	case -2023406814:
		// DernierElement
		return tabTableau.length - 1;
	}
};

// R�cup�re un indice C depuis un indice WL
clWDTableau.__xnGetIndiceC = function __xnGetIndiceC(tabTableau, nIndiceWL, bPourInsert)
{
	// GP 20/10/2015 : QW263427 : D�placement de "(bPourInsert ? 1 : 0)" de l'autre cot� de la comparaison
	if ((nIndiceWL < 1) || ((tabTableau.length + (bPourInsert ? 1 : 0)) < nIndiceWL))
	{
		throw new WDErreur(200, nIndiceWL, tabTableau.length);
	}
	return nIndiceWL - 1;
};
clWDTableau.__xnGetIndiceDepartC = function __xnGetIndiceDepartC(tabTableau, nIndiceWL, nIndiceCDefaut, bAcceptePositionCourante)
{
	if ((undefined === nIndiceWL) || (0 == nIndiceWL))
	{
		// Regarde si on une position courante
		if (bAcceptePositionCourante)
		{
			var oEtat = this.__oGetEtat(tabTableau);
			if (oEtat)
			{
				var nPositionCourante = oEtat.m_nIndiceRecherche;
				if (undefined !== nPositionCourante)
				{
					return nPositionCourante;
				}
			}
		}
		return nIndiceCDefaut;
	}
	if ((nIndiceWL < 1) || (tabTableau.length < nIndiceWL))
	{
		throw new WDErreur(200, nIndiceWL, tabTableau.length);
	}
	return nIndiceWL - 1;
};

// Autoagrandissement d'un tableau
clWDTableau.__AutoAgrandissementC = function __AutoAgrandissementC(tabTableauRacine, tabTableau, oDescription, nDimension, nIndiceC)
{
	var tabDimensions = oDescription.m_tabDimensions;
	var nTailleDimension = tabDimensions[nDimension];
	// Seulement si l'indice n'est pas encore valide
	if (nTailleDimension <= nIndiceC)
	{
		// Modifie la dimension du tableau
		tabDimensions[nDimension] = nIndiceC + 1;

		// Et r�applique l'initialisation sur TOUT le tableau
		this.__InitialiseTableau(tabTableauRacine, oDescription, 0);
	}
};

// Construit la description du tableau
// Version interne g�n�rale avec les trois param�tres : dimension, valeur par d�faut et fonction de cast
clWDTableau.__oConstruitDescriptionDVC = function __oConstruitDescriptionDVC(tabDimensions, oValeurDefaut, pfFonctionCast, bTypeInterneDynamique)
{
	return { m_tabDimensions: tabDimensions, m_oValeurDefaut: oValeurDefaut, m_pfFonctionCast: pfFonctionCast, m_bTypeInterneDynamique: bTypeInterneDynamique };
};
// Version avec deux param�tres (pour les tableaux externes) : dimension et valeur par d�faut. La fonction de cast devient une fonction identit�
clWDTableau.__oConstruitDescriptionDV = function __oConstruitDescriptionDV(tabDimensions, oValeurDefaut)
{
	// GP 23/02/2016 : TB89767 : Quatri�me param�tre : indique si l'objet point� est "dynamique". Comportement ant�rieur : non dynamique
	return this.__oConstruitDescriptionDVC(tabDimensions, oValeurDefaut, function() { return arguments[0]; }, false);
};
// Version avec un param�tre (pour les tableaux externes) : valeur par d�faut. Les dimensions sont initialises selon le nombre transmis. La fonction de cast devient une fonction identit�
clWDTableau.__oConstruitDescriptionV = function __oConstruitDescriptionV(tabTableauRacine, oValeurDefaut)
{
	var tabDimensions = [];
	var tabTableau = tabTableauRacine;
	while (this.__bEstTableau(tabTableau))
	{
		tabDimensions.push(tabTableau.length);

		// this.__bEstTableau g�re le cas de undefined
		tabTableau = tabTableau[0];
	}
	return this.__oConstruitDescriptionDV(tabDimensions, oValeurDefaut);
};

// R�cup�re la valeur d'un tableau
clWDTableau.__oPrepareUneValeur = function __oPrepareUneValeur(tabTableau, oDescription, oValeurDefautSiTableau, oValeur)
{
	if (undefined === oValeur)
	{
		oValeur = oValeurDefautSiTableau;
	}
	else if (oDescription)
	{
		// GP 30/10/2015 : QW263743 : Cast de la valeur
		var pfFonctionCast = oDescription.m_pfFonctionCast;
		if (pfFonctionCast)
		{
			oValeur = pfFonctionCast(oValeur);
		}
	}

	// GP 21/10/2015 : Vu avec QW263779 : Prend une copie du param�tre re�u.
	return this.__oCopieElement(oValeur, undefined);
};

//////////////////////////////////////////////////////////////////////////
// Gestion des tableaux : Cr�ation d'un tableau

// Cr�ation d'un tableau
clWDTableau.tabCreeTableau = function tabCreeTableau(tabDimensions, oValeurDefaut, pfFonctionCast, tabValeurInitiale, bTypeInterneDynamique)
{
	// On ne peut pas cr�er une class sp�cialis� qui d�rive de Array, car alors on casse certains comportement de Array. En particulier le .length en affectation ne fonctionne pas.
	// Voir : http://perfectionkills.com/how-ecmascript-5-still-does-not-allow-to-subclass-an-array/
	// GP 24/10/2015 : Test� ce jour et c'est encore d'actualit�.
	// => Ce qu l'on fait : on ajoute juste des propri�t�s sur Array.

	// Construit l'objet de description qui sera stock� dans le tableau et dans chacun des sous tableaux
	// Le tableau et les sous tableaux partages le m�me objet comme cela une seule modification suffit
	var oDescription = this.__oConstruitDescriptionDVC(tabDimensions, oValeurDefaut, pfFonctionCast, bTypeInterneDynamique);
	// Et cr�ation du tableau racine (qui lui m�me fera la cr�ation de ses sous �l�ments)
	var tabTableau = this.__tabCreeTableau(oDescription, 0);

	// Ajout de la valeur initiale.
	if (undefined !== tabValeurInitiale)
	{
		this.__InitialiseAvecValeur(tabTableau, tabTableau, oDescription, tabValeurInitiale, 0);
	}

	return tabTableau;
};
clWDTableau.__tabCreeTableau = function __tabCreeTableau(oDescription, nDimension)
{
	// Cr�ation du tableau. On alloue d�j� sa dimension
	var tabTableau = new Array(oDescription.m_tabDimensions[nDimension]);
	tabTableau.m_oDescription = oDescription;

	// Initialisation du tableau.
	this.__InitialiseTableau(tabTableau, oDescription, nDimension);

	return tabTableau;
};

// Initialisation d'un tableau.
// On recoit oDescription pour le cas de l'appel par Dimension sur un tableau qui n'est pas un tableau WL et qui n'a donc pas m_oDescription
clWDTableau.__InitialiseTableau = function __InitialiseTableau(tabTableau, oDescription, nDimension)
{
	var tabDimensions = oDescription.m_tabDimensions;
	var oValeurDefaut = oDescription.m_oValeurDefaut;

	var nTailleDimension = tabDimensions[nDimension];
	var nDimensionSuivante = nDimension + 1;
	var bDimensionIntermediaire = nDimensionSuivante < tabDimensions.length;
	var bPourConstructeur = (oValeurDefaut instanceof Function);

	// Fixe la taille du tableau (pour un appel de dimension)
	// GP 01/04/2016 : Vu avec QW271528 : Il ne faudrait pas interdire la r�duction du tableau ?
	// GP 15/11/2016 : QW280046 : Si il faut interdire la r�duction du tableau. Sinon un tableau modifi� depuis l'ext�rieur (par exemple le framework V2) n'est jamais pris en compte
	if (tabTableau.length < nTailleDimension)
	{
		tabTableau.length = nTailleDimension;
	}

	for (var nElement = 0; nElement < nTailleDimension; nElement++)
	{
		var oElement = tabTableau[nElement];
		if (undefined === oElement)
		{
			// On ne peut pas optimiser cette partie sinon toutes les lignes sont un alias du meme tableau
			if (bDimensionIntermediaire)
			{
				tabTableau[nElement] = this.__tabCreeTableau(oDescription, nDimensionSuivante);
			}
			else if (bPourConstructeur)
			{
				tabTableau[nElement] = new oValeurDefaut();
			}
			else
			{
				tabTableau[nElement] = oValeurDefaut;
			}
		}
		else
		{
			// L'�l�ment existe et est bien un tableau
			// Pour l'appel de dimension : il faut redimensionner les sous �l�ments.
			if (bDimensionIntermediaire)
			{
				if (this.__bEstTableau(oElement))
				{
					this.__InitialiseTableau(oElement, oDescription, nDimensionSuivante);
				}
			}
		}
	}
};

// Initialisation d'un tableau avec une valeur initiale
clWDTableau.__InitialiseAvecValeur = function __InitialiseAvecValeur(tabTableauRacine, tabTableau, oDescription, tabValeurInitiale, nDimension)
{
	var tabDimensions = oDescription.m_tabDimensions;
	var pfFonctionCast = oDescription.m_pfFonctionCast;

	var nDimensionSuivante = nDimension + 1;
	var bDimensionIntermediaire = nDimensionSuivante < tabDimensions.length;

	clWDUtil.bForEach(tabValeurInitiale, function(oValeurInitiale, nIndiceC)
	{
		// Si la valeur n'existe pas encore dans le tableau (auto agrandissement)
		clWDTableau.__AutoAgrandissementC(tabTableauRacine, tabTableau, oDescription, nDimension, nIndiceC);
		// A ce point de l'ex�cution, tabTableau[nIndiceC] est valide.

		if (bDimensionIntermediaire)
		{
			// Si on est dans un niveau interm�diaire de tabTableau
			if (clWDTableau.__bEstTableau(oValeurInitiale))
			{
				// Et que la valeur initiale est bien elle aussi un tableau : initialisation r�cursive
				clWDTableau.__InitialiseAvecValeur(tabTableauRacine, tabTableau[nIndiceC], oDescription, oValeurInitiale, nDimensionSuivante);
			}
			else
			{
				// La valeur initiale n'est pas un tableau : ne fait rien
			}
		}
		else
		{
			// L'�l�ment est une feuille du tableau source
			// GP 24/10/2015 : Contournment. Dans les versions pr�c�dentes de WEBDEV il �tait possible d'initialiser un tableau (sans aucune taille) avec un tableau multi dimensionnels.
			// On accepte donc ici de placer un tableau dans une feuille : en revanche on ne peut pas faire le cast sur le tableau (car sinon on perd sa forme de tableau)
			if (clWDTableau.__bEstTableau(oValeurInitiale))
			{
				// On duplique donc le tableau avec cast de chaque valeur individuelle
				tabTableau[nIndiceC] = clWDTableau.__InitialiseTableauCast(oValeurInitiale, pfFonctionCast);
			}
			else
			{
				// On est sur une feuille normale : �crit la valeur avec le bon cast.
				tabTableau[nIndiceC] = pfFonctionCast(oValeurInitiale);
			}
		}

		return true;
	});
};

clWDTableau.__InitialiseTableauCast = function __InitialiseTableauCast(tabValeurInitiale, pfFonctionCast)
{
	var tabResultat = [];
	clWDUtil.bForEach(tabValeurInitiale, function(oValeurInitiale)
	{
		tabResultat.push(clWDTableau.__bEstTableau(oValeurInitiale) ? clWDTableau.__InitialiseTableauCast(oValeurInitiale, pfFonctionCast) : pfFonctionCast(oValeurInitiale));
		return true;
	});
};

//////////////////////////////////////////////////////////////////////////
// Gestion des tableaux : Interface pour le WL


// TableauAjoute en WL
clWDTableau.nAjoute = function nAjoute(tabTableau, oValeurDefautSiTableau, oValeur)
{
	if (this.__bEstTableau(tabTableau))
	{
		var oDescription = tabTableau.m_oDescription;
		tabTableau.push(this.__oPrepareUneValeur(tabTableau, oDescription, oValeurDefautSiTableau, oValeur));
		// Modifie la taille du tableau
		if (oDescription)
		{
			oDescription.m_tabDimensions[0]++;
		}
		return tabTableau.length;
	}
	else
	{
		return 0;
	}
};
// TableauAjouteLigne en WL
// Attention fonction en ...
clWDTableau.nAjouteLigne = (function ()
{
	"use strict";

	function __nAjouteLigne(tabTableau, oValeurDefautSiTableau)
	{
		if (this.__bEstTableau(tabTableau))
		{
			var oDescription = tabTableau.m_oDescription;

			// Construit le tableau des valeurs ins�r�es
			var tabLigne = [];
			var nNbParametresTotal = arguments.length;
			for (var nValeur = __nAjouteLigne.length; nValeur < nNbParametresTotal; nValeur++)
			{
				tabLigne.push(this.__oPrepareUneValeur(tabTableau, oDescription, oValeurDefautSiTableau, arguments[nValeur]));
			}
			tabTableau.push(tabLigne);
			// Modifie la taille du tableau
			if (oDescription)
			{
				oDescription.m_tabDimensions[0]++;
			}

			return tabTableau.length;
		}
		else
		{
			return 0;
		}
	}

	return __nAjouteLigne;
})();

// TableauAjouteTrie en WL
clWDTableau.nAjouteTrie = function nAjouteTrie(tabTableau, oValeurDefautSiTableau, oValeur)
{
	var nResultatWL = 0;

	if (this.__bEstTableau(tabTableau))
	{
		// On doit avoir un tri pour le tableau
		var oEtat = this.__oGetEtat(tabTableau);
		if (oEtat)
		{
			var pfFonctionComparaison = oEtat.m_pfFonctionComparaison;
			if (pfFonctionComparaison)
			{
				nResultatWL = this.__nChercheDichotomiqueAjout(tabTableau, function(oElement) { return pfFonctionComparaison(oElement, oValeur); }, pfFonctionComparaison) + 1;

				// Insertion en nResultatWL
				// GP 20/10/2015 : QW263246 : Avec conversion d'indice C en indice WL car Insere attend un indice WL
				this.Insere(tabTableau, nResultatWL, oValeurDefautSiTableau, oValeur);
			}
			else
			{
				// "Un ajout tri� ne peut �tre effectu� que sur un tableau pr�alablement tri� par un appel � la m�thode Trie() ou � la m�thode TableauTrie().
				throw new WDErreur(207);
			}
		}
		else
		{
			// "Un ajout tri� ne peut �tre effectu� que sur un tableau pr�alablement tri� par un appel � la m�thode Trie() ou � la m�thode TableauTrie().
			throw new WDErreur(207);
		}
	}

	return nResultatWL;
};
// Retourne un indice C
// Attention trouve l'endroit de placement. N'indique pas si la position de placement correspond
clWDTableau.__nChercheDichotomiqueAjout = function __nChercheDichotomiqueAjout(tabTableau, pfFonctionComparaison, pfFonctionComparaisonPourVerificationTrie)
{
	// GP 20/10/2015 : QW263246 : R��criture de l'algo.
	var nTaille = tabTableau.length;
	var nBas = 0;
	var nHaut = nTaille - 1;
	var nPosition = 0;
	var nComparaison;
	while (nBas <= nHaut)
	{
		// V�rification de l'ordre du tableau
		if (pfFonctionComparaisonPourVerificationTrie && (0 < pfFonctionComparaisonPourVerificationTrie(tabTableau[nBas], tabTableau[nHaut])))
		{
			// Tableau mal tri�
			// "Un ajout tri� ne peut �EAtre effectu� que sur un tableau pr�alablement tri� par un appel � la m�thode Trie() ou � la m�thode TableauTrie().
			throw new WDErreur(207);
		}
		var nMoitie = Math.floor(nTaille / 2);
		if (0 != nMoitie)
		{
			var nMoitieImpaire = (nMoitie & 1) ? nMoitie : (nMoitie - 1);
			var nMilieu = nBas + nMoitieImpaire;
			nComparaison = pfFonctionComparaison(tabTableau[nMilieu]);
			if (0 == nComparaison)
			{
				nPosition += nMoitieImpaire;
				break;
			}
			else if (0 < nComparaison)
			{
				nHaut = nMilieu - 1;
				nTaille = nMoitieImpaire;
			}
			else
			{
				nPosition += nMoitieImpaire + 1;
				nBas = nMilieu + 1;
				nTaille = nMoitie;
			}
		}
		else
		{
			if ((0 < nTaille) && (pfFonctionComparaison(tabTableau[nBas]) < 0))
			{
				nPosition++;
			}
			break;
		}
	}
	return nPosition;
};

// TableauCherche en WL
// Attention fonction en ...
clWDTableau.nCherche = function nCherche(tabTableau, nTypeRecherche, oParametre)
{
	// La fonction a 5 syntaxes possibles :
	// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Valeur recherch�e> [, <Indice de d�part>])
	//		=> Tableau a une dimension
	// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Colonne>, <Valeur recherch�e>[, <Indice de d�part>])
	//		=> Tableau a deux dimensions sur une colonne
	// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Colonnes>, <Valeur recherch�e 1>[, <Valeur recherch�e 2>[ ...[, <Valeur recherch�e N>]]][, <Indice de d�part>])
	//		=> Tableau a deux dimensions sur plusieurs colonnes
	// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Membres recherch�s>, <Valeur recherch�e 1>, [ <Valeur recherch�e 2>[ ...[, <Valeur recherch�e N>]]][, <Indice de d�part>])
	//		=> Tableau a une dimension de structures
	// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Objet recherch�>)
	//		=> Tableau a une dimension de structures (la recherche est uniquement lin�aire)
	//
	// => tabTableau est <Nom du tableau>
	// => nTypeRecherche est <Type de recherche>
	// => oParametre est <Valeur recherch�e>/<Colonne>/<Colonnes>/<Membres recherch�s>/<Objet recherch�>
	// Le reste est dans arguments.

	var tabArguments = arguments;

	var nResultatWL = -1;

	if (this.__bEstTableau(tabTableau))
	{
		var nTypeParcours = nTypeRecherche & 0xF;
		var nOptionsCompare = nTypeRecherche & ~0xF;

		// GP 04/11/2015 : QW264734 : On demande bien sur le tri normal et pas le tri inverse...
		var pfFonctionComparaisonAvecOptions = this.__pfGetFonctionComparaisonAvecOptions(0, nOptionsCompare);
		var pfFonctionComparaison;
		var nNumeroArgumentIndiceDepart;
		// GP 20/10/2015 : QW263248 : Uniquement sur les tableaux a deux dimensions ou plus.
		if (2 <= this.__oInfo_ND_T(tabTableau))
		{
			// Tableau � deux dimensions ou plus :
			// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Colonne>, <Valeur recherch�e>[, <Indice de d�part>])
			//		=> Tableau a deux dimensions sur une colonne
			// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Colonnes>, <Valeur recherch�e 1>[, <Valeur recherch�e 2>[ ...[, <Valeur recherch�e N>]]][, <Indice de d�part>])
			//		=> Tableau a deux dimensions sur plusieurs colonnes

			var tabColonnes = [];
			// Transforme oParametre en chaine pour avoir un Colonne en format Colonnes
			clWDUtil.bForEach(String(oParametre).split(";"), function(sColonne, nColonne)
			{
				// GP 20/10/2015 : QW263248 : - 1 : Transforme la colonne d'indice WL en indice C
				// GP 20/10/2015 : QW263248 : Utilisation de tabArguments pour cibler les arguments de clWDTableau.nCherche
				tabColonnes.push([parseInt(sColonne, 10) - 1, tabArguments[3 + nColonne]]);
				return true;
			});
			pfFonctionComparaison = function(tabLigne)
			{
				var nResultatComparaison = 0;
				clWDUtil.bForEach(tabColonnes, function(tabUneColonne)
				{
					// tabColonne est de la forme : [ <Num�ro colonne, Valeur recherch�e ]
					nResultatComparaison = pfFonctionComparaisonAvecOptions(tabLigne[tabUneColonne[0]], tabUneColonne[1]);
					// Continue tant que la comparaison indique que les valeurs sont �gales
					return (0 == nResultatComparaison);
				});
				return nResultatComparaison;
			};
			nNumeroArgumentIndiceDepart = tabColonnes.length + 3;
		}
		else
		{
			// Tableau � une dimension :
			// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Valeur recherch�e> [, <Indice de d�part>])
			//		=> Tableau a une dimension
			// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Membres recherch�s>, <Valeur recherch�e 1>, [ <Valeur recherch�e 2>[ ...[, <Valeur recherch�e N>]]][, <Indice de d�part>])
			//		=> Tableau a une dimension de structures
			// <R�sultat> = TableauCherche(<Nom du tableau>, <Type de recherche>, <Objet recherch�>)
			//		=> Tableau a une dimension de structures (la recherche est uniquement lin�aire)
			if ((0 < tabTableau.length) && (tabTableau[0] instanceof Object))
			{
				// Distingue la cas membres du cas recherche par comparaison
				if (oParametre instanceof Object)
				{
					pfFonctionComparaison = function(oObjet)
					{
						return (oObjet === oParametre) ? 0 : -1;
					};
				}
				else
				{
					var tabMembres = [];
					// Transforme oParametre en chaine
					clWDUtil.bForEach(String(oParametre).split(";"), function(sMembre, nMembre)
					{
						// GP 20/10/2015 : QW263248 : Utilisation de tabArguments pour cibler les arguments de clWDTableau.nCherche
						tabMembres.push([sMembre, tabArguments[3 + nMembre]]);
						return true;
					});
					pfFonctionComparaison = function(oObjet)
					{
						var nResultatComparaison = 0;
						clWDUtil.bForEach(tabMembres, function(tabUnMembre)
						{
							// tabColonne est de la forme : [ <Num�ro colonne, Valeur recherch�e ]
							nResultatComparaison = pfFonctionComparaisonAvecOptions(oObjet[tabUnMembre[0]], tabUnMembre[1]);
							// Continue tant que la comparaison indique que les valeurs sont �gales
							return (0 == nResultatComparaison);
						});
						return nResultatComparaison;
					};
					nNumeroArgumentIndiceDepart = tabMembres.length + 3;
				}
			}
			else
			{
				// Recherche normale
				pfFonctionComparaison = function(oValeur)
				{
					return pfFonctionComparaisonAvecOptions(oValeur, oParametre);
				};
				nNumeroArgumentIndiceDepart = 3;
			}
		}

		var nIndiceDepartWL;
		if (undefined !== nNumeroArgumentIndiceDepart)
		{
			nIndiceDepartWL = arguments[nNumeroArgumentIndiceDepart];
		}

		// Effectue la recherche
		nResultatWL = this.__nRecherche(tabTableau, nTypeParcours, nIndiceDepartWL, pfFonctionComparaison);
	}

	// Retourne le r�sultat
	return nResultatWL;
};
// Factorisation entre nCherche et nCherche par proc�dure
clWDTableau.__nRecherche = function __nRecherche(tabTableau, nTypeParcours, nIndiceDepartWL, pfFonctionComparaison)
{
	var nResultatWL = -1;
	var nNbElements = tabTableau.length;

	// Trouve le sens, l'algo et la position de d�part
	var bDichotomique;
	var bCroissant;
	var bAcceptePositionCourante;
	switch (nTypeParcours)
	{
		case 1:
			// tcDichotomique/TABLEAU_CHERCHE_BINAIRE/0x00000001
			bDichotomique = true;
			// Ignore bCroissant et bAcceptePositionCourante
			break;
		case 2:
			// tcLin�airePremier/TABLEAU_CHERCHE_LINEAIRE_PREMIER/0x00000002 (et tcLin�aire !!!)
			bDichotomique = false;
			bCroissant = true;
			bAcceptePositionCourante = false;
			break;
		case 3:
			// tcLin�aireSuivant/TABLEAU_CHERCHE_LINEAIRE_SUIVANT/0x00000003
			bDichotomique = false;
			bCroissant = true;
			bAcceptePositionCourante = true;
			break;
		case 4:
			// tcLin�airePr�c�dent/TABLEAU_CHERCHE_LINEAIRE_PRECEDENT/0x00000004
			bDichotomique = false;
			bCroissant = false;
			bAcceptePositionCourante = true;
			break;
		case 5:
			// tcLin�aireDernier/TABLEAU_CHERCHE_LINEAIRE_DERNIER/0x00000005
			bDichotomique = false;
			bCroissant = false;
			bAcceptePositionCourante = false;
			break;
		default:
			throw new WDErreur(303, nTypeParcours);
	}

	// Effectue la recherche
	if (bDichotomique)
	{
		// Utilise le m�me algo que TableAjouteTrie.
		// Il donne la position d'ajout tri :
		// - Si la valeur existe la position est la position de la valeur existante.
		// - Si la valeur n'existe pas, il retourne la position la plus proche.
		// => Il suffit de v�rifier si l'indice re�ue est la bonne valeur
		var nPositionAjout = this.__nChercheDichotomiqueAjout(tabTableau, pfFonctionComparaison, undefined);
		if ((0 <= nPositionAjout) && (nPositionAjout < nNbElements) && (0 == pfFonctionComparaison(tabTableau[nPositionAjout])))
		{
			nResultatWL = nPositionAjout + 1;
		}
		// Sinon ne modifie pas nResultatWL (reste � -1)
	}
	else
	{
		var nIndice = this.__xnGetIndiceDepartC(tabTableau, nIndiceDepartWL, bCroissant ? 0 : nNbElements - 1, bAcceptePositionCourante);
		// Si on a un indice de d�part valide
		if ((0 <= nIndice) && (nIndice < nNbElements))
		{
			if (bCroissant)
			{
				for (; nIndice < nNbElements; nIndice++)
				{
					if (0 == pfFonctionComparaison(tabTableau[nIndice]))
					{
						break;
					}
				}
				// Si on a trouv�
				if (nIndice != nNbElements)
				{
					nResultatWL = nIndice + 1;
					clWDTableau.__SetEtat(tabTableau, undefined, nIndice + 1);
				}
				else
				{
					// Ne modifie pas le nResultatWL (-1)
					// Se place en "hors"
					clWDTableau.__SetEtat(tabTableau, undefined, -1);
				}
			}
			else
			{
				for (; 0 <= nIndice; nIndice--)
				{
					if (0 == pfFonctionComparaison(tabTableau[nIndice]))
					{
						break;
					}
				}
				// Si on a trouv�
				if (0 <= nIndice)
				{
					nResultatWL = nIndice + 1;
					clWDTableau.__SetEtat(tabTableau, undefined, nIndice - 1);
				}
				else
				{
					// Ne modifie pas le nResultatWL (-1)
					// Se place en "hors"
					clWDTableau.__SetEtat(tabTableau, undefined, -1);
				}
			}
		}
	}

	return nResultatWL;
};

// ChercheParProc�dure en WL
clWDTableau.nChercheProcedure = function nChercheProcedure(tabTableau, pfProcedure, nTypeRecherche, nIndiceDepart)
{
	var nResultatWL = -1;

	if (this.__bEstTableau(tabTableau))
	{
		// Construit le tableau pour l'appel de la proc�dure
		var tabParametresProcedure = [undefined];
		var nNbParametresRecus = arguments.length;
		for (var nParametreProcedure = 4; nParametreProcedure < nNbParametresRecus; nParametreProcedure++)
		{
			tabParametresProcedure.push(arguments[nParametreProcedure]);
		}
		var pfFonctionComparaison = function(oCellule)
		{
			// Ici this n'a aucun sens (c'est window ?)
			tabParametresProcedure[0] = oCellule;
			return pfProcedure.apply(this, tabParametresProcedure);
		};
		var nTypeParcours = nTypeRecherche & 0xF;
		nResultatWL = this.__nRecherche(tabTableau, nTypeParcours, nIndiceDepart, pfFonctionComparaison);
	}

	return nResultatWL;
};

// TableauCopie en WL
clWDTableau.Copie = function Copie(tabTableauSource, tabTableauDestination, nIndiceDebutWL, nTailleCopie)
{
	if (this.__bEstAssociatif(tabTableauSource) && this.__bEstAssociatif(tabTableauDestination))
	{
		// Ignore nIndiceDebutWL ni nTailleCopie

		// Vide la destination
		this.SupprimeTout(tabTableauDestination);

		// Effectue la copie en profondeur du tableau associatif
		this.__CopieAssociatif(tabTableauSource, tabTableauDestination, 0, tabTableauSource.GetProp(23));
	}
	else if (this.__bEstTableau(tabTableauSource) && this.__bEstTableau(tabTableauDestination))
	{
		// Valide les indices
		if (undefined === nIndiceDebutWL)
		{
			nIndiceDebutWL = 1;
		}
		var nIndiceDebutC = this.__xnGetIndiceC(tabTableauSource, nIndiceDebutWL, false);
		if (undefined == nTailleCopie)
		{
			nTailleCopie = tabTableauSource.length - nIndiceDebutC;
		}
		var nIndiceFinNonInclusC = nIndiceDebutC + nTailleCopie;
		if ((nIndiceFinNonInclusC < nIndiceDebutC) || (tabTableauSource.length < nIndiceFinNonInclusC))
		{
			throw new WDErreur(200, nTailleCopie, tabTableauSource.length - nIndiceDebutC);
		}

		// Vide la destination
		this.SupprimeTout(tabTableauDestination);

		// Copie en profondeur
		this.__CopieTableau(tabTableauSource, tabTableauDestination, undefined, nIndiceDebutC, nIndiceFinNonInclusC, true);
	}
};
// GP 23/02/2016 : TB89767 : Affectation de tableau en WL par copie
clWDTableau.Affectation = function Affectation(tabTableauDestination, tabTableauSource)
{
	// Inverse les param�tres et effectue la copie sur tout le tableau.
	this.Copie(tabTableauSource, tabTableauDestination);
};

// GP 21/10/2015 : Fusionner/completer avec WDTypeAvance.prototype.CloneXxx/WDTypeAvance.prototype.__CloneXxx ?

clWDTableau.__CopieAssociatif = function __CopieAssociatif(tabTableauSource, tabTableauDestination, nIndiceDebutC, nIndiceFinNonInclusC)
{
	for (var nIndice = nIndiceDebutC; nIndice < nIndiceFinNonInclusC; nIndice++)
	{
		// Inspir� de WDTableauAssociatif.prototype.SetContenu mais avec la copie en profondeur
		var oElement = tabTableauSource.oGetValeurDirect(nIndice, true);
		tabTableauDestination.SetValeur(this.__oCopieElement(oElement.m_oCle, undefined), this.__oCopieElement(oElement.m_oValeur, undefined));
	}
};
clWDTableau.__CopieTableau = function __CopieTableau(tabTableauSource, tabTableauDestination, oDescriptionDestination, nIndiceDebutC, nIndiceFinNonInclusC, bPremierNiveau)
{
	// Si on n'a pas encore de description et quelle existe dans la source : c'est que l'on est � la racine de la copie d'un tableau : copie la description du tableau
	// On ne le fait que sur la racine pour conserver le partage de la description entre les sous tableaux
	if (undefined === oDescriptionDestination)
	{
		var oDescriptionSource = tabTableauSource.m_oDescription;
		if (undefined !== oDescriptionSource)
		{
			oDescriptionDestination = this.__oConstruitDescriptionDVC(oDescriptionSource.m_tabDimensions, oDescriptionSource.m_oValeurDefaut, oDescriptionSource.m_pfFonctionCast, oDescriptionSource.m_bTypeInterneDynamique);
		}
	}
	if (undefined !== oDescriptionDestination)
	{
		tabTableauDestination.m_oDescription = oDescriptionDestination;
	}

	for (var nIndice = nIndiceDebutC; nIndice < nIndiceFinNonInclusC; nIndice++)
	{
		tabTableauDestination.push(this.__oCopieElement(tabTableauSource[nIndice], oDescriptionDestination));
	}

	// GP 01/04/2016 : QW271528 : Force la dimension dans la description au premier niveau
	if (bPremierNiveau)
	{
		var oDescriptionDestinationEffective = tabTableauDestination.m_oDescription;
		if (oDescriptionDestinationEffective)
		{
			var nDimensionRacine = oDescriptionDestinationEffective.m_tabDimensions[0];
			oDescriptionDestinationEffective.m_tabDimensions[0] = Math.max(nDimensionRacine, nIndiceFinNonInclusC);
		}
	}
};
clWDTableau.__oCopieElement = function __oCopieElement(oElement, oDescriptionDestination)
{
	var oCopie;
	if (this.__bEstTableau(oElement))
	{
		// Si c'est un tableau, effectue une copie en profondeur
		oCopie = [];
		this.__CopieTableau(oElement, oCopie, oDescriptionDestination, 0, oElement.length, false);
	}
	// GP 23/02/2016 : TB89767 : Sauf si la destination utilise des objets dynamiques (auquel cas on copie les r�f�rences)
	else if ((oElement instanceof WDTypeAvance) && (!(oDescriptionDestination && oDescriptionDestination.m_bTypeInterneDynamique)))
	{
		oCopie = new oElement.constructor();
		oCopie.Clone(oElement);
	}
	else
	{
		// Faire une duplication pour d'autres �l�ments ? Les num�riques, date, heure et autres ?
		oCopie = oElement;
	}
	return oCopie;
};

// GP 24/10/2015 : Lecture dans un tableau avec auto agrandissement et v�rification des indices :
// - Auto agrandissement : Cr�ation des indices manquant :
//	- Pour les tableaux de structures/de DINOs : avoir des objets valides pour la lecture
//	- Pour avoir la m�me taille dans les autres dimensions (sauf que l'auto agrandissement est uniquement sur la dimension racine en code serveur)
// - QW263859 : V�rification des indices : interdiction des indices n�gatifs.
// Fonction en ... (l'indice est dans les arguments) : oValeurDefaut, tabTableau, Indice 1, ..., Indice N, Valeur)
clWDTableau.CreeSetIndice = function CreeSetIndice(oValeurDefaut, tabTableau)
{
	// 3 : Pour oValeurDefaut, tabTableau et Valeur
	this.__oCreeXxxindice(oValeurDefaut, tabTableau, arguments, 3, arguments[arguments.length - 1]);
};
// GP 24/10/2015 : Lecture dans un tableau avec auto agrandissement et v�rification des indices :
// - Auto agrandissement : Cr�ation des indices manquant :
//	- Pour les tableaux de structures/de DINOs : avoir des objets valides pour la lecture
//	- Pour avoir la m�me taille dans les autres dimensions (sauf que l'auto agrandissement est uniquement sur la dimension racine en code serveur)
// - QW263859 : V�rification des indices : interdiction des indices n�gatifs.
// Fonction en ... (l'indice est dans les arguments) : oValeurDefaut, tabTableau, Indice 1, ..., Indice N)
clWDTableau.oCreeGetIndice = function oCreeGetIndice(oValeurDefaut, tabTableau)
{
	// 2 : Pour oValeurDefaut et tabTableau
	return this.__oCreeXxxindice(oValeurDefaut, tabTableau, arguments, 2, undefined);
};
// Calcul pr�paratoires pour xCreeXxxIndice
clWDTableau.__oCreeXxxindice = function __oCreeXxxindice(oValeurDefaut, tabTableauRacine, tabArguments, nNombreIgnore, oValeurSiBesoin)
{
	// Pr�pare la description
	var oDescription = tabTableauRacine.m_oDescription;
	if (undefined === tabTableauRacine.m_oDescription)
	{
		// Si le tableau n'est pas un tableau WL : construit une description
		oDescription = this.__oConstruitDescriptionV(tabTableauRacine, oValeurDefaut);
	}

	// Pr�pare le tableau des indices WL
	var tabIndicesWL = [];
	var nFin = tabArguments.length - nNombreIgnore + 2;
	for (var nArgument = 2; nArgument < nFin; nArgument++)
	{
		tabIndicesWL.push(tabArguments[nArgument]);
	}

	// Redimensionne le tableau pour accepter cet indice
	var nNbDimensions = Math.min(oDescription.m_tabDimensions.length, tabIndicesWL.length);
	var tabTableau = tabTableauRacine;
	for (var nDimension = 0; nDimension < nNbDimensions; nDimension++)
	{
		// Valide l'indice. Interdit uniquement les indices n�gatifs
		var nIndiceWL = tabIndicesWL[nDimension];
		if (nIndiceWL < 1)
		{
			throw new WDErreur(200, nIndiceWL, tabTableau.length);
		}
		var nIndiceC = nIndiceWL - 1;
		// Effectue l'auto agrandissement de ce tableau
		this.__AutoAgrandissementC(tabTableauRacine, tabTableau, oDescription, nDimension, nIndiceC);

		if (nDimension < nNbDimensions - 1)
		{
			// Et passe au tableau fils
			tabTableau = tabTableau[nIndiceC];
		}
		else
		{
			// On est sur le dernier niveau
			if (undefined !== oValeurSiBesoin)
			{
				tabTableau[nIndiceC] = this.__oCopieElement(oValeurSiBesoin, undefined);
			}
			return tabTableau[nIndiceC];
		}
	}
};

// TableauDeplace en WL
clWDTableau.Deplace = function Deplace(tabTableau, nIndiceWL1, nIndiceWL2, nEchange)
{
	if (this.__bEstTableau(tabTableau))
	{
		// Valide les indices
		var nIndiceC1 = this.__xnGetIndiceC(tabTableau, nIndiceWL1, false);
		var nIndiceC2 = this.__xnGetIndiceC(tabTableau, nIndiceWL2, false);

		if (4 == arguments.length)
		{
			// Le seul param�tre valide est tdEchange => TABLEAU_ECHANGE_ELEMENT => 0x80000000 => -2147483648 quand g�n�r� en d�cimal dans le JS
			if (-2147483648 != nEchange)
			{
				throw new WDErreur(303, nEchange);
			}
			var oTemp = tabTableau[nIndiceC2];
			tabTableau[nIndiceC2] = tabTableau[nIndiceC1];
			tabTableau[nIndiceC1] = oTemp;
		}
		else
		{
			tabTableau.splice(nIndiceC2, 0, tabTableau.splice(nIndiceC1, 1)[0]);
		}
	}
};

clWDTableau.Dimension = function Dimension(tabTableau, tabDimensions, oValeurDefaut)
{
	// Note : si l'argument n'est pas un tableau il n'est pas passe par valeur et ne peut donc pas etre transforme en tableau

	// GP 24/10/2015 : Pas de v�rification pour le moment
//	// GP 24/10/2015 : On redonne le type du tableau si on le connait :
//	// - Si on ne le connait pas :
//	//	- Le tableau est un tableau WL : la fonction utilise les donn�es du tableau.
//	//	- Le tableau n'est pas un tableau WL : la fonction donne les dimensions mais laisse undefined.
//	// - Si le connait :
//	//	- Le tableau est un tableau WL : la fonction v�rifie que le type est compatible
//	//	- Le tableau n'est pas un tableau WL : la fonction utilise le param�tre pour initialiser les membres
	var oDescription = tabTableau.m_oDescription;
	if (undefined !== tabTableau.m_oDescription)
	{
		if (undefined !== tabDimensions)
		{
			oDescription.m_tabDimensions = tabDimensions;
		}
		if (undefined !== oValeurDefaut)
		{
			oDescription.m_oValeurDefaut = oValeurDefaut;
		}
	}
	else
	{
		oDescription = this.__oConstruitDescriptionDV(tabDimensions, oValeurDefaut);
	}
	this.__InitialiseTableau(tabTableau, oDescription, 0);
};

// TableauEchangeLigne en WL
clWDTableau.EchangeLigne = function EchangeLigne(tabTableau, nIndiceWL1, nIndiceWL2)
{
	// Rebond sur TableauDeplaceLigne + tdEchange
	// Et comme la JS g�n�re des tableaux de tableaux pour les tableaux a deux dimensions, on peut faire un simple Deplace
	clWDTableau.Deplace(tabTableau, nIndiceWL1, nIndiceWL2, -2147483648);
};

// TableauInfo en WL
clWDTableau.oInfo = function oInfo(tabTableau, nInformation, oParametre)
{
	// Calcule le tableau des fonctions en fonctions de la constante
	// Format : [ Associatif : fonction (de this) ou constante, Tableau : fonction (de this) ou constante, Autre : constante ]
	var tabSelonType;
	switch (nInformation)
	{
	case 1:
		// tiNombreDimensions
		tabSelonType = [1, this.__oInfo_ND_T, 1];
		break;
	case 2:
		// tiDimension
		tabSelonType = [this.__oInfo_D_A, this.__oInfo_D_T, 1];
		break;
	case 7:
		// tiNombreTotal
		tabSelonType = [this.__oInfo_NT, this.__oInfo_NT, 0];
		break;
	case 8:
		// tiNombreLignes
		tabSelonType = [0, this.__oInfo_NL_T, 0];
		break;
	case 9:
		// tiNombreColonnes
		tabSelonType = [0, this.__oInfo_NC_T, 0];
		break;
	case 10:
		// tiAssociatifAvecDoublon
		tabSelonType = [this.__oInfo_AAD_A, false, false];
		break;
	case 11:
		// tiTypeCl�
		tabSelonType = [this.__oInfo_TC_A, 0, 0];
		break;
	default:
		// Interdit en WLJS : tiTypeEl�ment (3), tiTailleEl�ment (4), tiTailleTotale (5), tiDynamique (6) et tiD�finitionEl�ment (12)
		// Inconnu (Priv� ?) : TI_LOCAL (13), TI_AGRANDISSEMENT(15) et TI_ATTRIBUT_ELEMENT (0x01000001)
		throw new WDErreur(303, nInformation);
	}

	var oSelonType;
	if (this.__bEstAssociatif(tabTableau))
	{
		oSelonType = tabSelonType[0];
	}
	else if (this.__bEstTableau(tabTableau))
	{
		oSelonType = tabSelonType[1];
	}
	else
	{
		oSelonType = tabSelonType[2];
	}

	if (oSelonType instanceof Function)
	{
		return oSelonType.apply(this, [tabTableau, oParametre]);
	}
	else
	{
		return oSelonType;
	}
};
// tiNombreDimensions + Tableau
clWDTableau.__oInfo_ND_T = (function ()
{
	"use strict";

	function __oInfo_ND_T(tabTableau/*, oParametre*/)
	{
		if (this.__bEstTableau(tabTableau))
		{
			return 1 + __oInfo_ND_T.apply(this, [tabTableau[0]]);
		}
		else
		{
			return 0;
		}
	}

	return __oInfo_ND_T;
})();
// tiDimension + Associatif
clWDTableau.__oInfo_D_A = function __oInfo_D_A(tabTableau/*, oParametre*/)
{
	return this.nOccurrence(tabTableau);
};
// tiDimension + Tableau
clWDTableau.__oInfo_D_T = function __oInfo_D_T(tabTableau, oParametre)
{
	var nDimension = oParametre || 1;
	for (; (1 < nDimension); nDimension--)
	{
		tabTableau = tabTableau[0];
		// Fait apr�s car on est sur que le tabTableau est bien un tableau
		if (!this.__bEstTableau(tabTableau))
		{
			return 1;
		}
	}
	return tabTableau.length;
};
// tiNombreTotal + Associatif/Tableau
clWDTableau.__oInfo_NT = function __oInfo_NT(tabTableau/*, oParametre*/)
{
	return this.nOccurrenceRecursif(tabTableau, true);
};
// tiNombreLignes + Tableau
clWDTableau.__oInfo_NL_T = function __oInfo_NL_T(tabTableau/*, oParametre*/)
{
	// GP 20/10/2015 : QW263445 : Si le tableau n'est pas un tableau de tableau : retourne 0
	if (2 <= this.__oInfo_ND_T(tabTableau))
	{
		return this.__oInfo_D_T(tabTableau, 1);
	}
	else
	{
		return 0;
	}
};
// tiNombreColonnes + Tableau
clWDTableau.__oInfo_NC_T = function __oInfo_NC_T(tabTableau/*, oParametre*/)
{
	// GP 20/10/2015 : QW263444 : Appel de __oInfo_D_T (taille d'un dimension et sans param�tre = la premi�re) par __oInfo_ND_T (nombre de dimensions)
	if (2 <= this.__oInfo_ND_T(tabTableau))
	{
		return this.__oInfo_D_T(tabTableau, 2);
	}
	else
	{
		return 0;
	}
};
// tiAssociatifAvecDoublon + Associatif
clWDTableau.__oInfo_AAD_A = function __oInfo_AAD_A(tabTableau/*, oParametre*/)
{
	return tabTableau.m_bAvecDoublon;
};
// tiTypeCl� + Associatif
clWDTableau.__oInfo_TC_A = function __oInfo_TC_A(tabTableau/*, oParametre*/)
{
	return tabTableau.m_nTypeCle;
};

// TableauInsere en WL
clWDTableau.Insere = function Insere(tabTableau, oCle, oValeurDefautSiTableau, oValeur)
{
	// Si on re�oit undefined prend la valeur par d�faut
	if (undefined === oValeur)
	{
		oValeur = oValeurDefautSiTableau;
	}

	if (this.__bEstAssociatif(tabTableau))
	{
		tabTableau.SetValeur(oCle, oValeur);
	}
	else if (this.__bEstTableau(tabTableau))
	{
		// Interdit l'ajout sur un indice invalide
		var nCle = this.__xnGetIndiceC(tabTableau, oCle, true);
		var oDescription = tabTableau.m_oDescription;

		if (this.__bEstTableau(oValeur))
		{
			var nLimiteI = oValeur.length;
			for (var i = 0; i < nLimiteI; i++)
			{
				tabTableau.splice(nCle + i, 0, this.__oPrepareUneValeur(tabTableau, oDescription, oValeurDefautSiTableau, oValeur[i]));
				// Modifie la taille du tableau
				if (oDescription)
				{
					oDescription.m_tabDimensions[0]++;
				}
			}
		}
		else
		{
			tabTableau.splice(nCle, 0, this.__oPrepareUneValeur(tabTableau, oDescription, oValeurDefautSiTableau, oValeur));
			// Modifie la taille du tableau
			if (oDescription)
			{
				oDescription.m_tabDimensions[0]++;
			}
		}
	}
};

// TableauInsereLigne ligne en WL
// Attention fonction en ...
clWDTableau.InsereLigne = (function ()
{
	"use strict";

	function __InsereLigne(tabTableau, nIndiceWL, oValeurDefautSiTableau)
	{
		if (this.__bEstTableau(tabTableau))
		{
			// Interdit l'ajout sur un indice invalide
			var nIndice = this.__xnGetIndiceC(tabTableau, nIndiceWL, true);
			var oDescription = tabTableau.m_oDescription;

			// Construit le tableau des valeurs ins�r�es
			var tabLigne = [];
			var nNbParametresTotal = arguments.length;
			for (var nValeur = __InsereLigne.length; nValeur < nNbParametresTotal; nValeur++)
			{
				tabLigne.push(this.__oPrepareUneValeur(tabTableau, oDescription, oValeurDefautSiTableau, arguments[nValeur]));
			}
			tabTableau.splice(nIndice, 0, tabLigne);
			// Modifie la taille du tableau
			if (oDescription)
			{
				oDescription.m_tabDimensions[0]++;
			}
		}
	}

	return __InsereLigne;
})();

// TableauInverse en WL
clWDTableau.Inverse = function Inverse(tabTableau)
{
	// GP 19/10/2015 : QW263450 : gestion sur les tableaux associatifs (inverse l'ordre d'�num�ration)
	if (this.__bEstAssociatif(tabTableau))
	{
		tabTableau.Inverse();
	}
	else if (this.__bEstTableau(tabTableau))
	{
		tabTableau.reverse();
	}
};

// TableauMelange en WL
clWDTableau.Melange = function Melange(tabTableau, nNbDimensions)
{
	function __MiseAPlat(tabSousTableau, nNbDimensionsRestantes)
	{
		clWDUtil.bForEach(tabSousTableau, function(oElement)
		{
			if (1 == nNbDimensionsRestantes)
			{
				tabElements.push(oElement);
			}
			else
			{
				__MiseAPlat(oElement, nNbDimensionsRestantes - 1);
			}
			return true;
		});
	};
	function __Melange(tabSousTableau, nNbDimensionsRestantes)
	{
		clWDUtil.bForEach(tabSousTableau, function(oElement, nIndice)
		{
			if (1 == nNbDimensionsRestantes)
			{
				// nIndiceNouveau est dans [0, tabElements.length - 1] car clWDUtil.dHasard est dans [1, tabElements.length]
				var nIndiceNouveau = clWDUtil.dHasard(tabElements.length) - 1;
				// L'�l�ment dans tabSousTableau est r�f�rence dans tabElements (ou m�me d�j� d�plac�)
				tabSousTableau[nIndice] = tabElements.splice(nIndiceNouveau, 1)[0];
			}
			else
			{
				__Melange(oElement, nNbDimensionsRestantes - 1);
			}
			return true;
		});
	};

	if (this.__bEstTableau(tabTableau))
	{
		// Pour toutes les cellules "feuilles" du tableau, s�lectionne un �l�ment dans l'�l�ment et ses suivant pour allez dans la cellule.
		// - La premi�re cellule, la probabilit� de chaque �l�ment est 1/nNbElements
		// - Pour la cellule suivante, la probabilit� de chaque �l�ment est de 1/(nNbElements - 1) sachant que premier �l�ment est d�j� choisi mais sachant aussi que le premier �l�ment est une autre valeur
		// (nNbElements - 1)/nNbElements possibilit� => (nNbElements - 1)/(nNbElements - 1)/nNbElements => 1/nNbElements
		// - Etc.

		//	// On re�oit le nombres de dimensions pour ne pas m�langer les sous tableaux dans le cas des tableaux de tableaux.
		//	var nNbElements = this.nOccurrenceRecursif(tabTableau, false, nNbDimensions);
		// Pour faciliter le m�lange : on fait un tableau a plat des �l�ments.
		var tabElements = [];
		__MiseAPlat(tabTableau, nNbDimensions);
		__Melange(tabTableau, nNbDimensions);
	}
};

// Occurrence d'un tableau
clWDTableau.nOccurrence = function nOccurrence(tabTableau)
{
	if (this.__bEstAssociatif(tabTableau))
	{
		return tabTableau.GetProp(23);
	}
	// GP 11/10/2012 : QW223931 : Active bAvecPseudoTableauxNatif
	else if (this.__bEstTableau(tabTableau, true))
	{
		// Les tableaux sont passe par reference donc on manipule bien le tableau original
		return tabTableau.length;
	}
	else
	{
		return 1;
	}
};
// Occurrence d'un tableau en comptant les occurrences internes
clWDTableau.nOccurrenceRecursif = function nOccurrenceRecursif(tabTableau, bInterne, nLimiteProfondeur)
{
	// Si on est � la profondeur maximale demand�e
	if (0 === nLimiteProfondeur)
	{
		return 1;
	}
	else if (this.__bEstAssociatif(tabTableau))
	{
		// Que faire ici ?
		return this.nOccurrence(tabTableau);
	}
	// GP 11/10/2012 : QW223931 : Active bAvecPseudoTableauxNatif
	else if (this.__bEstTableau(tabTableau, true))
	{
		// Si on n'est pas � la racine et que l'on recoit un "vrai" objet : retourne 1 pour prendre en compte la cellule utilis� par l'objet
		if (bInterne && (undefined === tabTableau.length))
		{
			return 1;
		}

		var nOccurrence = 0;

		// Les tableaux sont passe par reference donc on manipule bien le tableau original
		var i;
		var nLimiteI = tabTableau.length;
		for (i = 0; i < nLimiteI; i++)
		{
			// GP 30/08/2012 : QW222072 : Indique de transformer les 0 occurrence en 1
			nOccurrence += this.nOccurrenceRecursif(tabTableau[i], true);
		}
		return nOccurrence;
	}
	else
	{
		return 1;
	}
};
// Etend le prototype de Array pour pouvoir g�n�rer tableau.nOccurrenceRecursif en g�n�ration
Array.prototype.nOccurrenceRecursif = function nOccurrenceRecursif()
{
	return clWDTableau.nOccurrenceRecursif(this);
};

// TableauSupprime et TableauSupprimeLigne en WL
clWDTableau.nSupprime = function nSupprime(tabTableau, oCle)
{
	if (this.__bEstAssociatif(tabTableau))
	{
		return tabTableau.nSupprime(oCle);
	}
	// GP 11/10/2012 : QW223931 : Je n'active pas bAvecPseudoTableauxNatif car certains ce ces tableaux sont en lecture seule
	else if (this.__bEstTableau(tabTableau))
	{
		// Les tableaux sont passe par reference donc on manipule bien le tableau original
		tabTableau.splice(this.__oCalculIndiceEffectif(tabTableau, oCle), 1);
		// Modifie la taille du tableau
		var oDescription = tabTableau.m_oDescription;
		if (oDescription)
		{
			oDescription.m_tabDimensions[0]--;
		}
		return 1;
	}

	return 0;
};

// TableauSupprimeDoublon en WL
clWDTableau.SupprimeDoublon = function SupprimeDoublon(tabTableau, nOptions, oParametres)
{
	// Pas de gestion des tableaux associatifs
	if (this.__bEstTableau(tabTableau))
	{
		// L'id�e est de faire un tri "indirect" :
		// - On cr�e un tableau des indices de tabTableau.
		// - On trie ce tableau des indices en fonction des valeurs associ�es dans tabTableau.
		// - On fait un parcours de ce tableau en comparant les valeurs et en trouvant les �l�ments qui ne sont pas des doublons.
		// - On trie ensuite le tableau des indices dans l'ordre (il ne contient plus que les indices des doublons et -1 pour les indices des uniques)
		// - Et on supprime les doublons en partant de la fin.

		// On ne peut pas faire la suppression directement des doublons a l'�tape 3 car cela d�calerai tabTableau et les indices dans la suite du tableau des indices serait invalides

		// R�cup�re la fonction de tri
		var pfFonctionComparaison = this.__pfGetFonctionComparaison(nOptions, oParametres);

		// - On cr�e un tableau des indices de tabTableau.
		var nNbIndices = tabTableau.length;
		var tabIndices = new Array(nNbIndices);
		var nIndice;
		for (nIndice = 0; nIndice < nNbIndices; nIndice++)
		{
			tabIndices[nIndice] = nIndice;
		};

		// - On trie ce tableau des indices en fonction des valeurs associ�es dans tabTableau.
		tabIndices.sort(function(nIndice1, nIndice2) { return pfFonctionComparaison(tabTableau[nIndice1], tabTableau[nIndice2]); });

		// - On fait un parcours de ce tableau en comparant les valeurs et en trouvant les �l�ments qui ne sont pas des doublons.
		// Pas d'incr�mentation de nIndice dans cette boucle, l'incr�mation est dans la boucle interne.
		for (nIndice = 0; nIndice < nNbIndices; )
		{
			// R�cup�re l'�l�ments (pour les comparaisons qui vont suivre)
			var oElement = tabTableau[tabIndices[nIndice]];
			// L'�l�ment n'est pas un doublon (ou si il a des doublons, c'est le premier donc c'est lui que l'on conserve)
			// => Supprime son indice de tabIndices
			tabIndices[nIndice] = -1;

			// On ignore ensuite les doublons
			for (nIndice++; (nIndice < nNbIndices) && (0 == pfFonctionComparaison(oElement, tabTableau[tabIndices[nIndice]])); nIndice++)
			{
				// Rien dans la boucle
			}
		}

		// - On trie ensuite le tableau des indices dans l'ordre (il ne contient plus que les indices des doublons et -1 pour les indices des uniques)
		// Il faut red�finir la fonction de tri sinon on a un tri lexicographique
		tabIndices.sort(function(nIndice1, nIndice2) { return nIndice1 - nIndice2; });

		var oDescription = tabTableau.m_oDescription;

		// - Et on supprime les doublons en partant de la fin.
		clWDUtil.bForEachInverse(tabIndices, function(nIndiceDansTableau)
		{
			if (-1 != nIndiceDansTableau)
			{
				tabTableau.splice(nIndiceDansTableau, 1);
				// Modifie la taille du tableau
				if (oDescription)
				{
					oDescription.m_tabDimensions[0]--;
				}
				// Continue
				return true;
			}
			else
			{
				// On arrive dans la zone des uniques : forc�ment au d�but (-1 est plus petit que tous les autres indices). Arret de la boucle.
				return false;
			}

		});
	}
};

// TableauSupprimeTout en WL
clWDTableau.SupprimeTout = function SupprimeTout(tabTableau)
{
	if (this.__bEstAssociatif(tabTableau))
	{
		tabTableau.SupprimeTout();
	}
	// GP 11/10/2012 : QW223931 : Je n'active pas bAvecPseudoTableauxNatif car certains ce ces tableaux sont en lecture seule
	else if (this.__bEstTableau(tabTableau))
	{
		// Les tableaux sont passe par reference donc on manipule bien le tableau original
		tabTableau.length = 0;
		// Modifie la taille du tableau
		var oDescription = tabTableau.m_oDescription;
		if (oDescription)
		{
			oDescription.m_tabDimensions[0] = 0;
		}
	}
};

// Pour TableauTrie en WL
clWDTableau.Trie = function Trie(tabTableau, nOptions, oParametres)
{
	// GP 19/10/2015 : gestion sur les tableaux associatifs (inverse l'ordre d'�num�ration)
	// => En WL cela change l'ordre pour les POUR TOUT sur le tableau
	if (this.__bEstAssociatif(tabTableau))
	{
		tabTableau.Trie(nOptions, oParametres);
	}
	else if (this.__bEstTableau(tabTableau))
	{
		// Trouve la fonction de trie en fonction des param�tres et ensuite effectue un simple tri avec la fonction native.
		var pfFonctionComparaison = this.__pfGetFonctionComparaison(nOptions, oParametres);
		tabTableau.sort(pfFonctionComparaison);

		// M�morise au passe le crit�re de tri pour le retrouver lors d'un projet TableauAjouteTri�
		// Inconv�nient de cette m�thode, c'est que pfFonctionComparaison est une closure et r�f�rence donc un certains nombre d'�l�ments tiers des appelants.
		this.__SetEtat(tabTableau, pfFonctionComparaison, undefined);
	}
};
clWDTableau.__pfGetFonctionComparaison = function __pfGetFonctionComparaison(nOptions, oParametres)
{
	if (undefined === nOptions)
	{
		// Si on n'a pas d'options : syntaxe 1 avec un seul param�tre : tri simple
		// tableau.sort(undefined) est �quivalent � tableau.sort()
		return undefined;
	}

	// S�pare les options
	var nOptionTri = nOptions & 0xF;
	var nOptionsCompare = nOptions & ~0xF;
	if (undefined === oParametres)
	{
		// Si on n'a pas de param�tres : syntaxe 1 avec deux param�tres
		return this.__pfGetFonctionComparaisonAvecOptions(nOptionTri, nOptionsCompare);
	}
	switch (nOptionTri)
	{
	case 3:
		// TABLEAU_TRI_COLONNE : Syntaxe 3
		// oParametres est une liste de num�ros de colonnes sp�ar�e par ; avec un possible +/- devant pour le sens de tri
		return this.__pfGetFonctionComparaisonColonnes(nOptionsCompare, oParametres);
	case 4:
		// TABLEAU_TRI_MEMBRE : Syntaxe 4
		return this.__pfGetFonctionComparaisonMembre(nOptionsCompare, oParametres);
	case 5:
		// TABLEAU_TRI_FONCTION : Syntaxe 5
		// Le param�tre est la fonction de comparaison que l'on retourne directement
		return oParametres;
	default:
		// Autres cas : Syntaxe 2
		// Tri selon la colonne dans oParametres
		// Si on a ttD�croissant dans nOptionTri => tri d�croissant
		return this.__pfGetFonctionComparaisonColonne(nOptionsCompare, [[oParametres, 2 != nOptionTri]]);
	}
};
clWDTableau.__pfGetFonctionComparaisonAvecOptions = function __pfGetFonctionComparaisonAvecOptions(nOptionTri, nOptionsCompare)
{
	function __oPrepare(oValeur)
	{
		// tccSansEspace			=> TABLEAU_CC_SANS_ESPACE			=> OWLO_SANS_ESPACE				=> OWLO_CUSTOM_01 => 0x00010000
		if (nOptionsCompare & 0x00010000)
		{
			oValeur = clWDUtil.sSupprimeEspacesDebutFin(oValeur);
		}
		// tccSansCasse				=> TABLEAU_CC_SANS_CASSE			=> OWLO_SANS_CASSE				=> OWLO_CUSTOM_10 => 0x00100000
		if (nOptionsCompare & 0x00100000)
		{
			oValeur = String(oValeur).toUpperCase();
		}
		// tccSansEspaceInt�rieur	=> TABLEAU_CC_SANS_ESPACE_INTERIEUR	=> OWLO_SANS_ESPACE_INTERIEUR	=> 0x01000000
		if (nOptionsCompare & 0x01000000)
		{
			oValeur = clWDUtil.sSupprimeEspacesInterieur(oValeur);
		}
		return oValeur;
	};

	// On peut avoir ttCroissant et ttDecroissant dans nOptionTri
	clWDUtil.WDDebug.assert((0 == nOptionTri) || (1 == nOptionTri) || (2 == nOptionTri));
	var pfCompare = (2 != nOptionTri) ? clWDUtil.__s_nCompareDivers : clWDUtil.__s_nCompareDiversInverse;
	return function(oValeur1, oValeur2)
	{
		return pfCompare(__oPrepare(oValeur1), __oPrepare(oValeur2));
	};
};
clWDTableau.__pfGetFonctionComparaisonColonnes = function __pfGetFonctionComparaisonColonnes(nOptionsCompare, sColonnes)
{
	// Pour TableauSupprimeDoublon on peut recevoir un entier dans sColonnes
	sColonnes = String(sColonnes);

	var tabCriteres = [];
	clWDUtil.bForEach(sColonnes.split(";"), function(sColonne)
	{
		var bCroissant = true;
		switch (sColonne.charAt(0))
		{
		case "-":
			bCroissant = false;
			// Pas de break;
		case "+":
			sColonne = sColonne.substr(1);
			break;
		}
		tabCriteres.push([parseInt(sColonne, 10), bCroissant]);
		return true;
	});
	return this.__pfGetFonctionComparaisonColonne(nOptionsCompare, tabCriteres);
};
clWDTableau.__pfGetFonctionComparaisonColonne = function __pfGetFonctionComparaisonColonne(nOptionsCompare, tabCriteres)
{
	return this.__pfGetFonctionComparaisonMultiple(nOptionsCompare, tabCriteres, function(tabLigne, nColonne)
	{
		// Les num�ros de colonnes sont en indices WL
		return tabLigne[nColonne - 1];
	});
};
clWDTableau.__pfGetFonctionComparaisonMembre = function __pfGetFonctionComparaisonMembre(nOptionsCompare, sMembres)
{
	// D�coupe sMembres
	var tabCriteres = [];
	clWDUtil.bForEach(sMembres.split(";"), function(sMembre)
	{
		var bCroissant = true;
		switch (sMembre.charAt(0))
		{
		case "-":
			bCroissant = false;
			// Pas de break;
		case "+":
			sMembre = sMembre.substr(1);
			break;
		}
		tabCriteres.push([sMembre.split("."), bCroissant]);
		return true;
	});

	return this.__pfGetFonctionComparaisonMultiple(nOptionsCompare, tabCriteres, function(oInstance, tabChainage)
	{
		var oValeur = oInstance;
		clWDUtil.bForEach(tabChainage, function(sNomMembre)
		{
			oValeur = oValeur[sNomMembre];
			return true;
		});
		return oValeur;
	});
};
// Code commun entre __pfGetFonctionComparaisonColonne et __pfGetFonctionComparaisonMembre
clWDTableau.__pfGetFonctionComparaisonMultiple = function __pfGetFonctionComparaisonMultiple(nOptionsCompare, tabCriteres, pfCritereVersValeur)
{
	var pfFonctionComparaisonAvecOptions = this.__pfGetFonctionComparaisonAvecOptions(0, nOptionsCompare);

	return function (oElement1, oElement2)
	{
		var nResultat = 0;
		clWDUtil.bForEach(tabCriteres, function (tabUnCritere)
		{
			var oCritere = tabUnCritere[0];
			nResultat = pfFonctionComparaisonAvecOptions(pfCritereVersValeur(oElement1, oCritere), pfCritereVersValeur(oElement2, oCritere));
			// On continue tant que l'on est a l'�galit�
			if (0 == nResultat)
			{
				return true;
			}
			else
			{
				// tabUnCritere[1] => bCroissant
				if (!tabUnCritere[1])
				{
					nResultat = -nResultat;
				}
				return false;
			}
		});
		return nResultat;
	};
};

// Pour TableauVersCha�ne en WL
clWDTableau.sVersChaine = function sVersChaine(tabTableau, sSeparateurLigne, sSeparateurColonne)
{
	if (this.__bEstTableau(tabTableau))
	{
		// Gestion des param�tres optionnels
		if (undefined == sSeparateurLigne)
		{
			sSeparateurLigne = "\r\n";
		}
		if (undefined == sSeparateurColonne)
		{
			sSeparateurColonne = "\t";
		}
		// Appel de la version interne r�cursive
		return clWDTableau.__sVersChaine(tabTableau, [sSeparateurLigne, sSeparateurColonne]);
	}
	else
	{
		return "";
	}
};
clWDTableau.sVersCSV = function sVersCSV(tabTableau, sSeparateurColonne)
{
	if (this.__bEstTableau(tabTableau))
	{
		// Gestion des param�tres optionnels
		if (undefined == sSeparateurColonne)
		{
			sSeparateurColonne = ";";
		}
		// Appel de sVersChaine (pour avoir le s�parateur de ligne par d�faut
		return this.sVersChaine(tabTableau, undefined, sSeparateurColonne);
	}
	else
	{
		return "";
	}
};
clWDTableau.__sVersChaine = function __sVersChaine(tabTableau, tabSeparateurs)
{
	var tabResultat = new Array(tabTableau.length);
	var tabSeparateursFils = tabSeparateurs.slice(1);
	clWDUtil.bForEach(tabTableau, function(oElement, nIndice)
	{
		// Si l'�l�ment est lui m�me un tableau
		if (clWDTableau.__bEstTableau(oElement))
		{
			// Et que l'on a un s�parateur
			if (0 < tabSeparateursFils.length)
			{
				// Appel r�cursif.
				tabResultat[nIndice] = clWDTableau.__sVersChaine(oElement, tabSeparateursFils);
			}
			else
			{
				// Erreur fatale WL :
				// Les fonctions TableauVersCha�ne() et TableauVersCSV() ne peuvent �tre utilis�es que sur un tableau � une ou deux dimensions.
				throw new WDErreur(205);
			}
		}
		// Si l'�l�ment est un objet
		else if (oElement instanceof Object)
		{
			// Et que l'on a un s�parateur
			if (0 < tabSeparateursFils.length)
			{
				var tabResultatInterne = [];
				// Appel sur les membres
				clWDUtil.bForEachIn(oElement, function(sMembre, oValeur)
				{
					// Si l'�l�ment est lui m�me un tableau ou un objet
					// Le test de l'objet suffit car un tableau est un objet
					//					if (clWDTableau.__bEstTableau(oValeur) || (oElement instanceof Object))
					if (oValeur instanceof Object)
					{
						// Erreur fatale WL :
						// Les fonctions TableauVersCha�ne() et TableauVersCSV() ne peuvent pas �tre utilis�es sur un tableau de structures, si la structure contient elle-m�me un tableau ou une structure.
						throw new WDErreur(206);
					}
					else
					{
						tabResultatInterne.push(oValeur);
					}
					return true;
				});
				tabResultat[nIndice] = tabResultatInterne.join(tabSeparateurs[1]);
			}
			else
			{
				// Erreur fatale WL :
				// Les fonctions TableauVersCha�ne() et TableauVersCSV() ne peuvent �tre utilis�es que sur un tableau � une ou deux dimensions.
				throw new WDErreur(205);
			}
		}
		else
		{
			// Sinon concat�nation dans tabResultat pour une concat�nation sous forme de chaine � la fin
			tabResultat[nIndice] = oElement;
		}
		return true;
	});
	return tabResultat.join(tabSeparateurs[0]);
};

// Test pour decaler l'iteration dans :
//	TableauSupprimeTout
//	TableauSupprime
//	Insere
//	Modification du tableau en direct (tableaux associatifs) ?
//	Modification du tableau en direct (tableaux normaux) => Comment faire ?

//////////////////////////////////////////////////////////////////////////
// Tableaux associatifs
function WDTableauAssociatif(nOptions, oValeurParDefaut, nTypeCle)
{
	if (arguments.length)
	{
		// Memorise les options
		this.m_bSansEspace = (0 != (nOptions & this.ms_nSansEspace));
//		this.m_bSansPonctuationNiEspace = (0 != (nOptions & this.ms_nSansSansPonctuationNiEspace))
//		this.m_bSansAccent = (0 != (nOptions & this.ms_nSansAccent))
		this.m_bSansCasse = (0 != (nOptions & this.ms_nSansCasse));
		this.m_bAvecDoublon = (0 != (nOptions & this.ms_nAvecDoublon));
		this.m_oValeurParDefaut = oValeurParDefaut;
		this.m_nTypeCle = nTypeCle;
		// Stocke les valeurs : tableau associatif de tableaux simples (limite a un element si le tableau est sans doublons)
		// GP 29/11/2013 : QW240068 : le stockage des valeurs est en fait un stockage objet
		this.m_oValeurs = {};
		this.m_tabElements = [];
	}
};

WDTableauAssociatif.prototype.ms_nSansEspace = 1;
//WDTableauAssociatif.prototype.ms_nSansSansPonctuationNiEspace = 2;
//WDTableauAssociatif.prototype.ms_nSansAccent = 4;
WDTableauAssociatif.prototype.ms_nSansCasse = 16;
WDTableauAssociatif.prototype.ms_nAvecDoublon = 1073741824;

// Calcule la cle d'un element
WDTableauAssociatif.prototype.__sGetCle = function __sGetCle(oCle)
{
	// Selon le type de la cle et les options
	switch (this.m_nTypeCle)
	{
	case 2:
		// Booleen
		return (false != oCle);
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	case 8:
	case 9:
	case 14:
		// Entiers
		var nCle = parseInt(oCle, 10);
		return isNaN(nCle) ? 0 : nCle;
	case 11:
	case 12:
		// Reels
		return parseFloat(oCle);
	case 16:
	case 19:
		// Chaines
		var sCle = "" + oCle;
		if (this.m_bSansEspace)
		{
			sCle = clWDUtil.sSupprimeEspaces(sCle);
		}
		if (this.m_bSansCasse)
		{
			sCle = sCle.toLowerCase();
		}
		return sCle;
	default:
		return oCle;
	}
};

// Retourne les valeurs pour une cle (limite a un element si on est sans doublons)
WDTableauAssociatif.prototype.__tabGetValeurs = function __tabGetValeurs(oCle)
{
	return this.m_oValeurs[this.__sGetCle(oCle)];
};

// Cree une valeur
WDTableauAssociatif.prototype.__tabCreeValeurs = function __tabCreeValeurs(oCle)
{
	// Cree un tableau simple
	var tabValeur = [];
	// L'ajoute avec la bonne cle dans le tableau principale
	this.m_oValeurs[this.__sGetCle(oCle)] = tabValeur;
	// Et retourne le tableau (c'est un alias de l'objet ajoute)
	return tabValeur;
};

// Indique si la cle est numerique
WDTableauAssociatif.prototype.__oCalculIndiceEffectif = function __oCalculIndiceEffectif(oCle)
{
	var nElement;
	switch (oCle)
	{
	case 0x00000001:
		// PremierElement : Ignore si la cle est numerique
		if (this.m_nTypeCle >= 15)
		{
			nElement = 0;
		}
		else
		{
			return oCle;
		}
		break;
	case WDIterateur.prototype.ms_oElementCourant:
		// ElementCourant
		var oIterateur = WDIterateur.prototype.s_oGetIterateur(this);
		if (oIterateur)
		{
			nElement = oIterateur.nGetCompteurDirect();
		}
		else
		{
			return undefined;
		}
		break;
	case 0x87654322:
	case -2023406814:
		// DernierElement
		nElement = this.m_tabElements.length - 1;
		break;
	default:
		// Si la cle est numerique et que les cles du tableau ne se le sont pas : considere que c'est un indice (indice WL qui commence a un)
		if (15 <= this.m_nTypeCle)
		{
			switch (clWDUtil.oGetTypeEntendu(oCle))
			{
			case "number":
				nElement = parseInt(oCle, 10) - 1;
				break;
			case 5: // WLT_UI8
			case 9: // WLT_I8
			case 13: // WLT_DECIMAL
			// oGetTypeEntendu retourne WLT_I8 pour WLT_UIX
//			case 14: // WLT_UIX
				nElement = parseInt(oCle.toNumber(), 10) - 1;
				break;
			default:
				return oCle;
			}
		}
		else
		{
			return oCle;
		}
		break;
	}
	return (((0 <= nElement) && (nElement < this.m_tabElements.length)) ? this.m_tabElements[nElement].m_oCle : undefined);
};

//////////////////////////////////////////////////////////////////////////
// Gestion des tableaux : Interface pour le WL

// Lire une propriete : a definir dans chaque type
WDTableauAssociatif.prototype.GetProp = function GetProp(nPropriete, oCle)
{
	switch (nPropriete)
	{
	case 23:
		// ..Occurrence
		if (undefined !== oCle)
		{
			var tabValeurs = this.__tabGetValeurs(oCle);
			return (undefined === tabValeurs) ? 0 : tabValeurs.length;
		}
		else
		{
			// ..Occurrence sur le tableau retourne le nombre total d'element et pas le nombre de cles.
			return this.m_tabElements.length;
		}
	case 24:
		// ..Vide
		return (0 == this.GetProp(23, oCle));
	case 43:
		// ..Existe
		return (0 < this.GetProp(23, oCle));
	default:
		return null;
	}
};

// TableauInverse en WL
WDTableauAssociatif.prototype.Inverse = function Inverse()
{
	// GP 19/10/2015 : QW263450 : gestion sur les tableaux associatifs (inverse l'ordre d'�num�ration)
	this.m_tabElements.reverse()
};

// TableauTrie en WL
WDTableauAssociatif.prototype.Trie = function Trie(nOptions, oParametres)
{
	// Normalement oParametres n'est pas d�fini
	clWDUtil.WDDebug.assert(undefined === oParametres, "oParametres n'est pas compatible avec cette syntaxe");

	// Trouve la fonction de trie en fonction des param�tres et ensuite effectue un simple tri avec la fonction native.
	// ttCl�/TABLEAU_TRI_CLE/0x00008000
	var bSurCle = !!(nOptions & 0x00008000);
	nOptions = nOptions & ~0x00008000;
	var nOptionTri = nOptions & 0xF;
	var nOptionsCompare = nOptions & ~0xF;
	// Normalement oParametres n'est pas d�fini
	var pfFonctionComparaisonAvecOptions = clWDTableau.__pfGetFonctionComparaisonAvecOptions(nOptionTri, nOptionsCompare);
	var pfGetValeur = bSurCle ? function(oElement) { return oElement.m_oCle; } : function(oElement) { return oElement.m_oValeur; };
	this.m_tabElements.sort(function(oElement1, oElement2)
	{
		return pfFonctionComparaisonAvecOptions(pfGetValeur(oElement1), pfGetValeur(oElement2));
	});
};

// Donne le contenu du tableau
WDTableauAssociatif.prototype.SetContenu = function SetContenu(oContenu)
{
	// Vide le tableau
	this.SupprimeTout();

	var i;
	var nLimiteI;
	if (clWDTableau.__bEstAssociatif(oContenu))
	{
		// Si le contenu est un autre tableau associatif : copie
		var tabElements = oContenu.m_tabElements;
		nLimiteI = tabElements.length;
		for (i = 0; i < nLimiteI; i++)
		{
			var oValeur = tabElements[i];
			this.SetValeur(oValeur.m_oCle, oValeur.m_oValeur);
		}
	}
	else if (clWDTableau.__bEstTableau(oContenu))
	{
		// Si le contenu est un tableau (normalement a double entree)
		nLimiteI = oContenu.length;
		for (i = 0; i < nLimiteI; i++)
		{
			var oUnContenu = oContenu[i];
			if (clWDTableau.__bEstTableau(oUnContenu) && (2 == oUnContenu.length))
			{
				this.SetValeur(oUnContenu[0], oUnContenu[1]);
			}
		}
	}
};

// Fixe la valeur d'un element : Tableau[Valeur] = Xxx
WDTableauAssociatif.prototype.SetValeur = function SetValeur(oCle, oValeur)
{
	// Recherche la cle existante
	var tabValeurs = this.__tabGetValeurs(oCle);
	// Si elle n'existe pas : la cree
	if (undefined === tabValeurs)
	{
		tabValeurs = this.__tabCreeValeurs(oCle);
	}
	if (this.m_bAvecDoublon || (undefined === tabValeurs[0]))
	{
		// Avec doublons ou ou viens de creer la valeur : ajoute
		var oValeurComplet = { m_oCle: oCle, m_oValeur: oValeur };
		tabValeurs.push(oValeurComplet);
		this.m_tabElements.push(oValeurComplet);
	}
	else
	{
		// Remplace la valeur existante
		// this.m_tabElements a un alias sur cet objet donc on modifie les deux
		tabValeurs[0].m_oCle = oCle;
		tabValeurs[0].m_oValeur = oValeur;
	}
};

// Fixe la valeur indice d'un element : Tableau[Valeur, Indice] = Xxx
WDTableauAssociatif.prototype.SetValeurIndice = function SetValeurIndice(oCle, nIndice, oValeur)
{
	// Recherche la cle existante (v�rifie les indice et lance une erreur WL en cas d'erreur)
	var oValeurIndice = this.oGetValeurIndiceComplet(oCle, nIndice, true);

	// Remplace l'element
	oValeurIndice.m_oCle = oCle;
	oValeurIndice.m_oValeur = oValeur;
};

// Lit la valeur d'un element : Tableau[Valeur]
WDTableauAssociatif.prototype.oGetValeur = function oGetValeur(oCle)
{
	if (this.m_bAvecDoublon)
	{
		// Avec doublons : syntaxe interdite
		// Erreur fatale WL :
		// "La lecture d'un �l�ment de tableau associatif avec doublon est interdit par cette syntaxe car plusieurs �l�ments peuvent �tre r�f�renc�s par une m�me cl�."
		throw new WDErreur(203);
	}
	else
	{
		// Recherche la cle existante
		var tabValeurs = this.__tabGetValeurs(oCle);
		if (undefined !== tabValeurs)
		{
			// Existe : retourne la valeur
			return tabValeurs[0].m_oValeur;
		}
		else
		{
			// N'existe pas : valeur par defaut
			return this.m_oValeurParDefaut;
		}
	}
};

// Lit la valeur d'un element avec indice : Tableau[Valeur, nIndice]
WDTableauAssociatif.prototype.oGetValeurIndice = function oGetValeurIndice(oCle, nIndice)
{
	var oCouple = this.oGetValeurIndiceComplet(oCle, nIndice, true);
	return ((undefined !== oCouple) ? oCouple.m_oValeur : this.m_oValeurParDefaut);
};

// Lit la valeur d'un element avec indice : Tableau[Valeur, nIndice] et retourne l'objet interne (Cle + Valeur)
WDTableauAssociatif.prototype.oGetValeurIndiceComplet = function oGetValeurIndiceComplet(oCle, nIndice, bAvecErreur)
{
	// Recherche la cle existante
	var tabValeurs = this.__tabGetValeurs(oCle);
	// Erreur si :
	// - La valeur n'existe pas
	// - Si l'indice n'existe pas (sans doublon cela couvre le cas de l'indice > 1)

	if (undefined === tabValeurs)
	{
		if (bAvecErreur)
		{
			// Erreur fatale WL :
			// "El�ment inexistant dans le tableau associatif."
			throw new WDErreur(201);
		}
		else
		{
			return undefined;
		}
	}
	else if ((nIndice < 0) || (tabValeurs.length <= nIndice))
	{
		if (bAvecErreur)
		{
			// Erreur fatale WL :
			// "Le tableau associatif poss�de %1 �l�ment(s) r�f�renc�(s) par cette cl� et vous tentez d'acc�der � l'�l�ment %2."
			throw new WDErreur(202, tabValeurs.length, nIndice + 1);
		}
		else
		{
			return undefined;
		}
	}

	// Existe : retourne la valeur
	return tabValeurs[nIndice];
};

// Lit la valeur d'un element par indice de creation
WDTableauAssociatif.prototype.oGetValeurDirect = function oGetValeurDirect(nElement, bAscendant)
{
	return this.m_tabElements[bAscendant ? nElement : (this.m_tabElements.length - 1 - nElement)];
};

// Supprime tout les elements du tableau
WDTableauAssociatif.prototype.SupprimeTout = function SupprimeTout()
{
	// Recree le tableau global des valeurs
	// GP 29/11/2013 : QW240068 : le stockage des valeurs est en fait un stockage objet
	this.m_oValeurs = {};
	this.m_tabElements.length = 0;
};

// Supprime un elements du tableau
WDTableauAssociatif.prototype.nSupprime = function nSupprime(oCle)
{
	// Gestion des indices speciaux
	var oCleEffective = this.__oCalculIndiceEffectif(oCle);

	var nNbCleOccurrence = 0;

	// Recherche la cle existante
	var tabValeurs = this.__tabGetValeurs(oCleEffective);
	if (undefined !== tabValeurs)
	{
		// Memorise sa taille
		nNbCleOccurrence = tabValeurs.length;
		// Et la supprime
		delete this.m_oValeurs[this.__sGetCle(oCleEffective)];
		// Supprime aussi les entrees dans m_tabElements
		var i;
		var nLimiteI = tabValeurs.length;
		for (i = 0; i < nLimiteI; i++)
		{
			clWDUtil.SupprimeDansTableau(this.m_tabElements, tabValeurs[i]);
		}
	}

	return nNbCleOccurrence;
};

//////////////////////////////////////////////////////////////////////////
// Iterateurs
function WDIterateur(oCible, nOptions)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		this.m_oCible = oCible;
		this.m_bAscendant = !!(nOptions & 0x2);
		this.m_bSelectionne = !!(nOptions & 0x4);
		// -1 : Permet de commencer par un appel a Suivant
		this.m_nCompteur = -1;

		// Cree l'association iterateur <-> tableau
		// this est un WDIterateur dont this.ms_tabIterateurs <=> WDIterateur.prototype.ms_tabIterateurs
//		WDIterateur.prototype.ms_tabIterateurs.push(oIterateur);
		this.ms_tabIterateurs.push(this);
	}
};
WDIterateur.prototype.ms_oElementCourant = {};
WDIterateur.prototype.ms_tabIterateurs = [];

// Methodes statiques

// Trouve le premier iterateur sur un element
WDIterateur.prototype.__s_bCompareCible = function __s_bCompareCible(oIterateur, oCible)
{
	return oIterateur.bSurCible(oCible);
};
WDIterateur.prototype.s_oGetIterateur = function s_oGetIterateur(oCible)
{
	return clWDUtil.oDansTableauFct(WDIterateur.prototype.ms_tabIterateurs, WDIterateur.prototype.__s_bCompareCible, oCible, null);
};

// Creation d'un iterateur
WDIterateur.prototype.s_oDeclareIterateur = function s_oDeclareIterateur(oCible, nOptions, oParametre, bPourPosition, nOptionsSpecifiques)
{
	var oIterateur;
	if (clWDTableau.__bEstAssociatif(oCible))
	{
		oIterateur = new WDIterateurTableauAssociatif(oCible, nOptions, oParametre);
	}
	// GP 14/11/2014 : QW251744 : D�plac� avant clWDTableau.__bEstTableau car en HTML4 (avec IE ?) clWDTableau.__bEstTableau retourne true sur une liste
	else if (undefined !== oCible.nodeType)
	{
		oIterateur = new WDIterateurListeCombo(oCible, nOptions);
	}
	else if (clWDTableau.__bEstTableau(oCible))
	{
		oIterateur = new WDIterateurTableau(oCible, nOptions, oParametre);
	}
	else if (window["WDTableZRNavigateur"] && oCible instanceof WDTableZRNavigateur)
	{
		oIterateur = new WDIterateurTableZRNavigateur(oCible, nOptions);
	}
	else if (typeof oCible == "string")
	{
		if (bPourPosition)
		{
			oIterateur = new WDIterateurChainePosition(oCible, nOptions, oParametre, nOptionsSpecifiques);
		}
		else
		{
			oIterateur = new WDIterateurChaine(oCible, nOptions, oParametre);
		}
	}
	else
	{
		// Utilise un iterateur qui ne fait rien
		oIterateur = new WDIterateur(oCible);
	}

	// Fait dans le constructeur de WDIterateur maintenant
//	// Cree l'association iterateur <-> tableau
//	WDIterateur.prototype.ms_tabIterateurs.push(oIterateur);

	// Commence l'iteration
	oIterateur.Suivant();

	return oIterateur;
};

// Libere un iterateur
WDIterateur.prototype.s_LibereIterateur = function s_LibereIterateur(oIterateur)
{
	oIterateur._vLibere();

	// Suprime l'association iterateur <-> cible (le recherche est stricte pour trouver uniquement l'iterateur)
	// Note : on ne lib�re pas explicitement Iterateur.m_oCible : le faire ?
	clWDUtil.SupprimeDansTableau(WDIterateur.prototype.ms_tabIterateurs, oIterateur, true);
};

// Test
WDIterateur.prototype.bSurCible = function bSurCible(oCible)
{
	return (oCible === this.m_oCible);
};

// Deplacement
WDIterateur.prototype.Suivant = function Suivant()
{
	this.m_nCompteur++;
	// En cas d'echec de l'avance
	(this.m_bFini = !this._vbSuivant());
};
WDIterateur.prototype.bEstFini = function bEstFini ()
{
	return this.m_bFini;
};
// Implementation par defaut
WDIterateur.prototype._vbSuivant = function _vbSuivant ()
{
	return false;
};
// Impl�mentation par d�faut
WDIterateur.prototype._vLibere = clWDUtil.m_pfVide;

//oGetValeur
//oGetCle
//SetValeur

WDIterateur.prototype.nGetCompteur = function nGetCompteur()
{
	// + 1 : Indice C vers WL
	return this.nGetCompteurDirect() + 1;
};
WDIterateur.prototype.nGetCompteurDirect = function nGetCompteurDirect()
{
	return this.m_nCompteur;
};

//OnInsere

function WDIterateurTableau(tabTableau/*, nOptions*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Pour les tableaux a plusieurs dimensions : rend le tableaux lin�raire
		while (this.__bEstTableauAPlusieursDimensions(tabTableau))
		{
			// Linearise le tableau
			tabTableau = this.__tabLineariseTableau(tabTableau);
		}

		// Appel le constructeur de la classe de base
		WDIterateur.prototype.constructor.apply(this, arguments);
	}
}

// Declare l'heritage
WDIterateurTableau.prototype = new WDIterateur();
WDIterateurTableau.prototype.constructor = WDIterateurTableau;

// Indique si le tableau est multidimensionnel
WDIterateurTableau.prototype.__bEstTableauAPlusieursDimensions = function __bEstTableauAPlusieursDimensions(tabTableau)
{
	return clWDUtil.bDansTableauFct(tabTableau, clWDTableau.__bEstTableau, undefined);
};
// Linearise le tableau
WDIterateurTableau.prototype.__tabLineariseTableau = function __tabLineariseTableau(tabTableau)
{
	var tabTableauFinal = [];

	var i;
	var nLimiteI = tabTableau.length;
	for (i = 0; i < nLimiteI; i++)
	{
		tabTableauFinal = tabTableauFinal.concat(tabTableau[i]);
	}

	return tabTableauFinal;
};

WDIterateurTableau.prototype.__nGetCompteurReel = function __nGetCompteurReel()
{
	return (this.m_bAscendant ? this.m_nCompteur : (this.m_oCible.length - this.m_nCompteur - 1));
};

WDIterateurTableau.prototype._vbSuivant = function _vbSuivant()
{
	return (this.m_nCompteur < this.m_oCible.length);
};

WDIterateurTableau.prototype.oGetValeur = function oGetValeur()
{
	return this.m_oCible[this.__nGetCompteurReel()];
};
WDIterateurTableau.prototype.oGetCle = function oGetCle()
{
	return this.__nGetCompteurReel() + 1;
};
WDIterateurTableau.prototype.SetValeur = function SetValeur(oValeur)
{
	this.m_oCible[this.__nGetCompteurReel()] = oValeur;
};

function WDIterateurTableauAssociatif(tabTableau, nOptions, oCleFiltre)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDIterateurTableau.prototype.constructor.apply(this, arguments);

		this.m_bFiltre = ((null !== oCleFiltre) && (undefined !== oCleFiltre));
		if (this.m_bFiltre)
		{
			this.m_oCleFiltre = oCleFiltre;
		}
	}
}

// Declare l'heritage
WDIterateurTableauAssociatif.prototype = new WDIterateurTableau();
WDIterateurTableauAssociatif.prototype.constructor = WDIterateurTableauAssociatif;

WDIterateurTableauAssociatif.prototype._vbSuivant = function _vbSuivant()
{
	if (this.m_bFiltre)
	{
		// Avec filtre : une seule cle
		// Ordre inverse ?
		// GP 27/06/2013 : QW233385 : Sans erreur.
		this.m_oValeurComplet = this.m_oCible.oGetValeurIndiceComplet(this.m_oCleFiltre, this.m_nCompteur, false);
	}
	else
	{
		this.m_oValeurComplet = this.m_oCible.oGetValeurDirect(this.m_nCompteur, this.m_bAscendant);
	}

	return this.m_oValeurComplet !== undefined;
};

WDIterateurTableauAssociatif.prototype.oGetValeur = function oGetValeur ()
{
	return this.m_oValeurComplet.m_oValeur;
};
WDIterateurTableauAssociatif.prototype.oGetCle = function oGetCle ()
{
	return this.m_oValeurComplet.m_oCle;
};
WDIterateurTableauAssociatif.prototype.SetValeur = function SetValeur(oValeur)
{
	// On a un alias sur l'objet interne du tableau associatif
	(this.m_oValeurComplet.m_oValeur = oValeur);
};

function WDIterateurChaine(sChaine, nOptions, sSeparateur)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Si on ne recoit pas de separateur : prend tab
		this.m_sSeparateur = (null === sSeparateur) ? "\t" : sSeparateur;

		// Appel le constructeur de la classe de base
		// GP 22/08/2012 : QW221911 : La chaine vide ne g�n�re aucun �l�ment et pas un �l�ment vide
		WDIterateurTableau.prototype.constructor.apply(this, [(sChaine.length > 0) ? sChaine.split(this.m_sSeparateur) : [], nOptions]);
	}
}

// Declare l'heritage
WDIterateurChaine.prototype = new WDIterateurTableau();
WDIterateurChaine.prototype.constructor = WDIterateurChaine;

// _vbSuivant

//oGetValeur
WDIterateurChaine.prototype.oGetCle = function oGetCle()
{
	// GP 22/08/2012 : QW221913 : La cl� (= position sur une chaine) est la position dans la chaine
	// Ce n'est pas le plus performant mais on reconstruit la chaine partielle
	var nCompteur = this.__nGetCompteurReel();
	if (0 == nCompteur)
	{
		// Premier �l�ment : chaine vide (et nCompteur - 1 est un indice invalide
		return 1;
	}
	else
	{
		return this.m_oCible.slice(0, nCompteur).join("").length + nCompteur * this.m_sSeparateur.length + 1;
	}
};
//oGetCle
//SetValeur

function WDIterateurChainePosition(sChaine, nOptions, sSeparateur, nOptionsSpecifiques)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Si on a des options dynamiques : POUR TOUTE POSITION xxx de yyy DANS zzz AVEC aaa
		// Une valeur dynamique est possible pour aaa
		if (0 != (nOptionsSpecifiques & this.ms_nDepuisFin))
		{
			if (nOptions & 0x2)
			{
				nOptions -= 0x2;
			}
		}

		// MotComplet
		var bMotComplet = (0 != (nOptionsSpecifiques & this.ms_nMotComplet));
		// SansCasse ?
		if (nOptionsSpecifiques & this.ms_nSansCasse)
		{
			sChaine = sChaine.toLowerCase();
			sSeparateur = sSeparateur.toLowerCase();
		}

		// Calcule le tableau des positions
		var tabPosition = [];
		var nPosition;
		for (nPosition = sChaine.indexOf(sSeparateur); -1 != nPosition; nPosition = sChaine.indexOf(sSeparateur, nPosition + 1))
		{
			// Si on demande avec mot complet : le v�rifie
			if (bMotComplet)
			{
				// Si on a un caract�re avant qui n'est pas un s�parateur
				var nPositionTest = nPosition - 1;
				if ((0 <= nPositionTest) && (null == sChaine.charAt(nPositionTest).match(this.ms_oDebutFinMot)))
				{
					continue;
				}
				nPositionTest = nPosition + sSeparateur.length;
				if ((nPositionTest < sChaine.length) && (null == sChaine.charAt(nPositionTest).match(this.ms_oDebutFinMot)))
				{
					continue;
				}
			}

			// Ajoute la position (en indice WL) au tableau
			tabPosition.push(nPosition + 1);
		}

		// Appel le constructeur de la classe de base
		WDIterateurTableau.prototype.constructor.apply(this, [tabPosition, nOptions]);
	}
}

// Declare l'heritage
WDIterateurChainePosition.prototype = new WDIterateurTableau();
WDIterateurChainePosition.prototype.constructor = WDIterateurChaine;

// Constantes
WDIterateurChainePosition.prototype.ms_nDepuisFin = 1;
WDIterateurChainePosition.prototype.ms_nMotComplet = 2;
WDIterateurChainePosition.prototype.ms_nSansCasse = 4;	// !!! Diff�rent du sans casse des tableaux associatifs (qui correspond a ccSansCasse)
WDIterateurChainePosition.prototype.ms_oDebutFinMot = new RegExp("\\W", "");

function WDIterateurTableZRNavigateur(/*oCible*//*, nOptions*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel de la classe de base
		WDIterateur.prototype.constructor.apply(this, arguments);

		this.m_nForceSelectionInitial = this.m_oCible.nGetForceSelection();
	}
};

// Declare l'heritage
WDIterateurTableZRNavigateur.prototype = new WDIterateur();
WDIterateurTableZRNavigateur.prototype.constructor = WDIterateurTableZRNavigateur;

WDIterateurTableZRNavigateur.prototype._vbSuivant = function _vbSuivant()
{
	var nLigne;
	// GP 12/11/2014 : QW251095
	if (this.m_bSelectionne)
	{
		if (this.m_nCompteur < this.m_oCible.SelectOccurrence())
		{
			// +1 et -1 pour passer de et vers les indices WL
			nLigne = this.m_oCible.Select(this.m_nCompteur + 1) - 1;
		}
	}
	else
	{
		// Le compteur est sur la ligne.
		if (this.m_nCompteur < this.m_oCible.Occurrence())
		{
			nLigne = this.m_nCompteur;
		}
	}
	if (undefined !== nLigne)
	{
		this.m_oCible.ForceSelection(nLigne);
		return true;
	}
	else
	{
		return false;
	}
};
WDIterateurTableZRNavigateur.prototype._vLibere = function _vLibere()
{
	// Libere la s�lection
	this.m_oCible.ForceSelection(this.m_nForceSelectionInitial);
};
WDIterateurTableZRNavigateur.prototype.oGetValeur = function oGetValeur()
{
	// Retourne la ligne s�l�ctionn� (que l'on a forc� dans _vbSuivant)
	return this.m_oCible.GetValeur();
};
// GP 12/11/2014 : QW251093 : Pour la syntaxe POUR TOUTE LIGNE nIndice, nCompteur1 DE Table_Navigateur
WDIterateurTableZRNavigateur.prototype.oGetCle = function oGetCle()
{
	return this.m_nCompteur + 1;
};
// Inutile : on n'ecrit pas le champ (la ligne n'a pas de valeur).
//WDIterateurTableZRNavigateur.prototype.SetValeur = function SetValeur()
//{
//	...
//};

function WDIterateurListeCombo(oCible/*, nOptions*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel de la classe de base
		WDIterateur.prototype.constructor.apply(this, arguments);

		// Sauve la s�lection, de la liste/combo.
		var nOccurrence = oCible.length;
		var tabSelection = [];
		clWDUtil.bForEach(oCible.options, function(oOption, nLigne)
		{
			if (oOption.selected)
			{
				tabSelection.push(nLigne);
				oOption.selected = false;
			}
			return true;
		});

		// M�morise
		this.m_tabSelection = tabSelection;
		this.m_nOccurrence = this.m_bSelectionne ? tabSelection.length : nOccurrence;
	}
};

// Declare l'heritage
WDIterateurListeCombo.prototype = new WDIterateur();
WDIterateurListeCombo.prototype.constructor = WDIterateurTableZRNavigateur;

WDIterateurListeCombo.prototype._vbSuivant = function _vbSuivant()
{
	if (this.m_nCompteur < this.m_nOccurrence)
	{
		// S�lectionne la ligne
		this.m_oCible.selectedIndex = this._oGetValeur();
		return true;
	}
	return false;
};
WDIterateurListeCombo.prototype._vLibere = function _vLibere()
{
	var oCible = this.m_oCible;
	var tabOptions = oCible.options;
	oCible.selectedIndex = -1;
	clWDUtil.bForEach(this.m_tabSelection, function(nLigne)
	{
		tabOptions[nLigne].selected = true;
		return true;
	});
};
WDIterateurListeCombo.prototype._oGetValeur = function _oGetValeur()
{
	// Retourne la ligne s�l�ctionn� (que l'on a forc� dans _vbSuivant)
	return this.m_bSelectionne ? this.m_tabSelection[this.m_nCompteur] : this.m_nCompteur;
};
WDIterateurListeCombo.prototype.oGetValeur = function oGetValeur()
{
	// Retourne la ligne s�l�ctionn� (que l'on a forc� dans _vbSuivant)
	return this._oGetValeur() + 1;
};
// GP 12/11/2014 : QW251093 : Pour la syntaxe POUR TOUTE LIGNE nIndice, nCompteur1 DE Table_Navigateur
WDIterateurListeCombo.prototype.oGetCle = function oGetCle()
{
	return this.m_nCompteur + 1;
};
// Inutile : on n'ecrit pas le champ (la ligne n'a pas de valeur).
//WDIterateurTableZRNavigateur.prototype.SetValeur = function SetValeur()
//{
//	...
//};

////////////////////////////////////////////////////////////////////////////
//// Enumeration
//// On ne cr�� par un unique tableau des �num�rations, car la port� d'une �numeration d�pend du lieu de sa d�claration (une �numeration dans une fonction est locale)
//// => On cr�� donc un tableau d'�num�rations que l'on instancie selon les besoins.
//// On a donc au maximum deux tableaux visibles : le tableau global et le tableau local
//function WDEnumeration (tabValeur, tabNom)
//{
//	// Le contenu de l'�num�ration index� par le nom (pour permettre de retrouver la valeur sur le serveur)
//	var tabEnumerationParNom = [];
//	// Le contenu de l'�num�ration index� dans l'ordre (pour lire la valeur permettre de retrouver la valeur sur le serveur)
//	var tabEnumerationParIndice = [];

//	var i;
//	var nLimiteI = tabValeur.length
//	for (i = 0; i < tabValeur; i++)
//	{
//		tabEnumerationParNom[tabNom[i]] = tabEnumerationParIndice[i] = new this.__WDEnumerationElement(tabValeur[i]);
//	}

//	this.m_tabEnumerationParNom = tabEnumerationParNom;
//	this.m_tabEnumerationParIndice = tabEnumerationParIndice;
//}
//// Cr�ation d'un nouvel �l�ment
//WDEnumeration.prototype.__WDEnumerationElement = function __WDEnumerationElement(sValeur)
//{
//	// Attention ici this = le nouvel �l�ment (un __WDEnumerationElement) et pas l'�num�ration (un WDEnumeration)
//	this.m_sValeur = sValeur;
//};
//WDEnumeration.prototype.__WDEnumerationElement.prototype.toString = function toString()
//{
//	// Attention ici this = le nouvel �l�ment (un __WDEnumerationElement) et pas l'�num�ration (un WDEnumeration)
//	return this.m_sValeur;
//};

//// Retrouve un element par nom
//WDEnumeration.prototype.oGetElementParNom = function oGetElementParNom(sNom)
//{
//	return this.m_tabEnumerationParNom[sNom];
//};
//// Retrouve un element par indice
//WDEnumeration.prototype.oGetElementParIndice = function oGetElementParIndice(nIndice)
//{
//	return this.m_tabEnumerationParIndice[nIndice];
//};

//////////////////////////////////////////////////////////////////////////
// M�thodes diverses du WL
var clWLangage = {};

// Concatenation optionnelle
clWLangage.sConcatSeparateur = function sConcatSeparateur(sExpression1, sSeparateur, sExpression2)
{
	// Force le cast en chaine du s�parateur
	sSeparateur = "" + sSeparateur;

	// Si on a une premi�re expression
	if (undefined !== sExpression1)
	{
		// Force le cast en chaine de l'expression
		sExpression1 = "" + sExpression1;
		// Si l'expression est vide : on ne concatene pas le s�parateur
		if (0 == sExpression1.length)
		{
			// "" + [x] + y => y, que y commence par x ou pas
			// Ce qui est �quivalent a ignorer le s�parateur
			sSeparateur = "";
		}
		else if ((sSeparateur.length <= sExpression1.length) && (sSeparateur == sExpression1.substring(sExpression1.length - sSeparateur.length)))
		{
			// Si sExpression 1 se termine par le s�parateur : on ne l'ajoute pas
			sSeparateur = "";
		}
	}
	else
	{
		// On ignore la premi�re expression
		sExpression1 = "";
	}

	// Si on a une seconde expression
	if (undefined !== sExpression2)
	{
		// Force le cast en chaine de l'expression
		sExpression2 = "" + sExpression2;
		// Si l'expression est vide : on ne concatene pas le s�parateur
		if (0 == sExpression2.length)
		{
			// "" + [x] + y => y, que y commence par x ou pas
			// Ce qui est �quivalent a ignorer le s�parateur
			sSeparateur = "";
		}
		else if ((sSeparateur.length <= sExpression2.length) && (sSeparateur == sExpression2.substring(0, sSeparateur.length)))
		{
			// Si sExpression 1 se termine par le s�parateur : on ne l'ajoute pas
			sSeparateur = "";
		}
	}
	else
	{
		// On ignore la seconde expression
		sExpression2 = "";
	}

	return sExpression1 + sSeparateur + sExpression2;
};

// SELON inline
// L'op�rateur en WL est de la forme :
// SELON (Valeur, "Xxx", "Yyy"[, ...][, SINON "Autre"])
// Si valeur = 1 => "Xxx"
// Si valeur = 2 => "Yyy"
// Etc.
// Si une autre valeur => "Autre"
//
// Les param�tres sont dans l'ordre
// Valeur, R�sultat si 1, R�sultat si 2, ..., R�sultat si n, R�sultat par d�faut
clWLangage.sSelonInline = function sSelonInline(oValeur)
{
	var nResultat;
	// -2 Pour la valeur et le r�sultat par d�faut
	var nNbResultat = arguments.length - 2;
	// On commence � 1 donc on a <= et pas <
	for (nResultat = 1; nResultat <= nNbResultat; nResultat++)
	{
		if (oValeur == nResultat)
		{
			return arguments[nResultat];
		}
	}
	// Valeur par d�faut
	var oValeurDefaut = arguments[arguments.length - 1];
	if (undefined !== oValeurDefaut)
	{
		return oValeurDefaut;
	}
	else
	{
		// Erreur fatale WL :
		// "Indice de valeur incorrect : acc�s � l'indice %1 alors qu'il n'y a que %2 valeur(s)."
		throw new WDErreur(200, oValeur, nNbResultat);
	}
};

//////////////////////////////////////////////////////////////////////////
// DateSys()/HeureSys()
clWLangage.sDateSys = function sDateSys()
{
	return clWDUtil.sGetDateHeureWL(new Date(), false, true, false);
};
clWLangage.sHeureSys = function sHeureSys()
{
	return clWDUtil.sGetDateHeureWL(new Date(), false, false, true);
};

//////////////////////////////////////////////////////////////////////////
// DateDifference, DateHeureDifference, HeureDifference
clWLangage.__xnDateHeureDifference = function __xnDateHeureDifference(oDebut, oFin, bDate, bHeure)
{
	// Diff�rence entre deux date/heure/dateheure : retourne une dur�e en milli�mes de secondes
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return this.__xnGetJSFromWL(oFin, bDate, bHeure) - this.__xnGetJSFromWL(oDebut, bDate, bHeure);
};
// Transforme une valeur WL en objet de type DateHeure
clWLangage.__xoGetDHFromWL = function __xoGetDHFromWL(oDateWL, bDate, bHeure)
{
	// GP 28/08/2018 : Dans le cas date, accepte aussi les DateHeure : Accepte : HHMM, HHMMSS, HHMMSSCC, HHMMSSLLL
	if (bDate && (!bHeure) && this.bDateValide(oDateWL))
	{
		if (8 < String(oDateWL).length)
		{
			oDateWL = String(oDateWL).substr(0, 8);
		}
	}

	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return new (this.WDDateHeure)(bDate, bHeure, oDateWL, undefined, false);
};
// Transforme une valeur WL en objet JS de type Date
clWLangage.__xoGetJSFromWL = function __xoGetJSFromWL(oDateWL, bDate, bHeure)
{
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return this.__xoGetDHFromWL(oDateWL, bDate, bHeure).m_oValeur;
};
// Transforme une valeur WL en entier JS
clWLangage.__xnGetJSFromWL = function __xnGetJSFromWL(oDateWL, bDate, bHeure)
{
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return this.__xoGetJSFromWL(oDateWL, bDate, bHeure).getTime();
};
clWLangage.nDateDifference = function nDateDifference(oDebut, oFin)
{
	// Diff�rence entre deux date : retourne une dur�e en jours
	// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	// GP 03/04/2018 : TB101699 : Cet algo est faux. Il ne marche pas si les deux dates entourent le passage � l'heure d'�t�. Dans ce cas __xnDateHeureDifference retourne (n-1) jours et 23 heures.
	// Deux solutions :
	// - Faire un setUTCHours(0, 0, 0, 0) � la place de setHours(0, 0, 0, 0). Le probl�me c'est que l'initialisation de l'heure �tant faite avec l'heure courante,
	// et pour des timezone extr�mes, il est peut-�tre possible de changer de jours et donc d'avoir un calcul faux.
	// - Faire un nArrondi en remplacement de nArrondiVersZero. Normalement l'erreur n'est que de 1 heure au maximum.
	// => On prend cette solution
	var nDifferenceJours = this.__xnDateHeureDifference(oDebut, oFin, true, false) / 86400000;
	var nDifferenceJoursArrondi = clWDUtil.oArrondi(nDifferenceJours);
	clWDUtil.WDDebug.assert(Math.abs(nDifferenceJours - nDifferenceJoursArrondi) <= 1/24, "TB101699 : Probleme de calcul dans nDateDifference.");
	return nDifferenceJoursArrondi;
//	return clWDUtil.nArrondiVersZero(this.__xnDateHeureDifference(oDebut, oFin, true, false) / 86400000);
};
clWLangage.nDateHeureDifference = function nDateHeureDifference(oDebut, oFin)
{
	// Diff�rence entre deux dateheures : retourne une dur�e en chaine (!!!)
	// GP 16/10/2014 : Le format est JJJJJJJ (7xJ) et pas JJJJJJJJ (8xJ)
	// GP 21/10/2014 : QW250237 : + indique de mettre uniquement le -. +/- indique de toujours le mettre (pour DateHeureDifference)
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return clWLangage.__sDureeVersChaine((new (this.WDDuree)(this.__xnDateHeureDifference(oDebut, oFin, true, true))), "+/-JJJJJJJHHMMSSLL");
};
clWLangage.nHeureDifference = function nHeureDifference(oDebut, oFin)
{
	// Diff�rence entre deux dateheures : retourne une dur�e en centi�mes de secondes
	// 10 = 1 centi�me de secondes en milli�mes de secondes
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return clWDUtil.nArrondiVersZero(this.__xnDateHeureDifference(oDebut, oFin, false, true) / 10);
};
clWLangage.sAge = function sAge(oNaissanceWL, oCalculWL) 
{	
	var oDateNaissance = this.__xoGetJSFromWL(oNaissanceWL, true, false);
	//Si on a pas pass� de date de calcul on prend "maintenant"
	var oDateCalcul = (oCalculWL === undefined) ? (new Date()) : this.__xoGetJSFromWL(oCalculWL, true, false);
	// Pas de test des erreurs : en cas d'erreur on a une exception.
	// Si la date de naissance est post�rieure � la date de calcul
	if (oDateCalcul.getTime() < oDateNaissance.getTime())
	{
		return "";
	}

	// GP 15/11/2019 : QW319928 : Utilisation du m�me algo que dans WDxxxStd. Un algo par diff�rence brute est faux car il ne tient pas compte des diff�rences de nombre de jours des mois.
	// Et aussi de l'effet du passage de l'heure d'hiver � l'heure d'�t� qui peut faire perdre ou gagner une ou deux heures (un gain dans l'age r�el, un gain dans la date ramen�e � 1970).
	// Ce qui peut d�caler de un jour en arri�re.

	// Ann�es.
	var nAnnee = oDateCalcul.getFullYear() - oDateNaissance.getFullYear();

	// Mois.
	var nMois = oDateCalcul.getMonth() - oDateNaissance.getMonth();
	// Cas du mois courant inf�rieur au mois de naissance
	if (nMois < 0)
	{
		nAnnee--;
		nMois += 12;
	}

	// Jours.
	var nJour = oDateCalcul.getDate() - oDateNaissance.getDate();
	// Cas du jour courant inf�rieur au jour de naissance
	if (nJour < 0)
	{
		// Trouve le nombre de jours du mois pr�c�dent.
		var oDateCalculPourMoisPrecedent = new Date(oDateCalcul);
		oDateCalculPourMoisPrecedent.setDate(0);
		var nDateCalculNbJoursMoisPrecedent = oDateCalculPourMoisPrecedent.getDate();

		//Nbre de jour entre le mois pr�cedant/jour anniversaise et le jour courant (-1 car 1=Jan. => indice 0 dans le tableau)
		//GF 03/12/10 Le calcul des jours de fin de mois s'applique au mois de la date de calcul et non la date de naissance
		var nNbJourJusquaFinDeMois = nDateCalculNbJoursMoisPrecedent - oDateNaissance.getDate();
		//GF 06/12/10 Cas des dates de naissances >= 29 dont le mois pr�c�dent la date de calcul (clNow) ne poss�de pas le num�ro du jour de naissance
		if (nNbJourJusquaFinDeMois < 0) //nNbJourJusquaFinDeMois = 0; // cas particulier de la naissance le 29 fev.
		{
			//GF 13/12/10 TB#69207 D�cision prise d'avoir un raisonnement favorisant la continuit� des �ges � la bijectivit� de la fonction
			//Concr�tement
			//Une personne n�e le			29 Janvier, aura au 28 F�vrier  un �ge de 30 Jours. Ce calcul est �vident.
			//par contre,
			//Cette m�me personne n�e le	29 Janvier, aura au 01 Mars		un �ge de ???
			//2 possibilit�s :
			// - soit : 1 Mois
			//car cette personne ne peut pas f�ter son 1 Mois car le 29 F�vrier n'existe pas cette ann�e ci.
			//inconv�nient : les personnes n�s le 29, 30 et 31 janvier on t donc le m�me �ge au 01 mars. La fonction n'est pas bijective.
			// - soit : 1 Mois et 2 jours
			//car on tient compte des jours "v�cus" fin Janvier, le 30 et le 31. (Remarque: Une personne n� le 30 aurait donc 1 Mois et 1 jour)
			//inconv�nient : la personne passe de l'�ge de 30 jors � 1 mois et 2 jours. les r�sultats ne sont pas contigues
			//
			//=> d�cision prise de respecter la suite logiques (contigues) des �ges, plut�t que la bijectivit�.

			//Dans la suite de l'exemple, la personne n�e le 29, 30 ou 31 Jan. aura 1 Mois (et 0 jours) le 1er Mars
			nJour = oDateCalcul.getDate() - 1;//-1 pour ne pas avoir 1 mois et 1 jour le 1er du mois mais bien 1mois pile
			//PAD le 6/06/2011 pour QW#206474 : 0 possible si n� le 31/01 et qu'on demande l'age le 01/03
			clWDUtil.WDDebug.assert(0 <= nJour);
		}
		else
		{
			//la partie "nombre de jours" de l'�ge correspond donc au nombre de jours restant du mois pr�c�dent le calcul + le num�ro du jour du mois de calcul
			nJour = nNbJourJusquaFinDeMois + oDateCalcul.getDate();
			clWDUtil.WDDebug.assert(1 <= nJour);
		}

		// Du coup on avait compt� un mois en trop, que l'on enl�ve maintenant
		if (0 < nMois)
		{
			nMois--;
		}
		else
		{
			clWDUtil.WDDebug.assert(0 < nAnnee);
			clWDUtil.WDDebug.assert(0 === nMois);
			nAnnee--;
			nMois = 11;
		}
	}

	return clWDUtil.sCompleteEntier(nAnnee, 4) + clWDUtil.sCompleteEntier(nMois, 2) + clWDUtil.sCompleteEntier(nJour, 2);
};
clWLangage.bAnneeBissextile = function bAnneeBissextile(oAnnee) 
{	
	var nAnnee;
	//Si on a re�u un entier, c'est l'ann�e demand�e
	switch (typeof oAnnee)
	{
	case "number":
		nAnnee = oAnnee;
		break;
	case "string":
		if (oAnnee.length <= 4)
		{
			nAnnee = parseInt(oAnnee, 10);
			break;
		}
		// Pas de break;
	default:
		nAnnee = ((oAnnee == undefined) ? new Date() : this.__xoGetJSFromWL(oAnnee, true, false)).getFullYear();
		break;
	}

	//Multiple dont l'ann�e doit �tre pour �tre bissextile
	var nBISSEXTILE_MULTIPLE = 4;
	//ann�e d'introduction de la r�gle des si�cle non bissextile (calendrier gr�gorien)
	var nBISSEXTILE_SIECLE_DEBUT = 1582;
	//Nombre d'ann�es dans un si�cle
	var nSIECLE = 100;
	//Nombre de si�cle pour multiple non bissextile
	var nBISSEXTILE_MULTIPLE_SIECLE = 4;

    //si ann�e multiple de nBISSEXTILE_MULTIPLE (4)
	if ((nAnnee % nBISSEXTILE_MULTIPLE) != 0)
	{
		//ann�e non bissextile
		return false;
	}
	//si ann�e sup�rieure � ann�e d'introduction de la r�gle des si�cle non bissextile
	if (nAnnee > nBISSEXTILE_SIECLE_DEBUT)
	{
		//si ann�e pas multiple de si�cle
		if ((nAnnee % nSIECLE) != 0)
		{
			//ann�e bissextile
			return true;
		}
		//si ann�e pas multiple de nBISSEXTILE_MULTIPLE_SIECLE si�cles (4 si�cles)
		if ((nAnnee % (nSIECLE * nBISSEXTILE_MULTIPLE_SIECLE)) != 0)
		{
			//ann�e non bissextile
			return false;
		}
	}
    //ann�e bissextile
	return true;
};

//////////////////////////////////////////////////////////////////////////
// DateValide

clWLangage.ms_tabNbJoursDansMois = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
clWLangage.bDateValide = (function ()
{
	// GP 28/08/2018 : Accepte aussi les DateHeure : Accepte : HHMM, HHMMSS, HHMMSSCC, HHMMSSLLL
//	var ms_oFormatDate = new RegExp("^\\d{8}$", "");
	var ms_oFormatDateAccepteHeure = /^\d{8}(?:(?:(?:[0-1]\d)|(?:2[0-3]))(?:[0-5]\d)(?:[0-5]\d(?:\d\d(?:\d)?)?)?)?$/;
	return function (oDate)
	{
		// V�rifications :
		// - Le paramete peut-�tre convertit en une chaine
		// GP 28/08/2018 : Accepte aussi les DateHeure : Accepte : HHMM, HHMMSS, HHMMSSCC, HHMMSSLLL
//		// - Cette chaine fait 8 caract�res
		// - Cette chaine fait 8 caract�res ou 8 caract�res + HHMM/HHMMSS/HHMMSSCC/HHMMSSLLL
		// - La chaine est uniquement compos� de chiffres
		// - La chaine est d�compos� en AAAAMMJJ avec :
		//	- AAAA entre 0001 et 9999 (automatiquement valid� par le contenu compos� de chiffres sauf pour le cas 0000).
		//	- MM est entre 01 et 12
		//	- JJ est entre 01 et 28/29/30/31 selon AAAA, MM, JJ
		//	- QW320092 : Recpecte le calendrier julien
		// - Refuse les dates entre le 05/10/1582 et 14/10/1582 (dates qui n'ont pas exister lors de la transition du calendrier Julien au calendrier Gr�gorien)


		// - Le paramete peut-�tre convertit en une chaine
		var sDate = String(oDate);
		// GP 28/08/2018 : Accepte aussi les DateHeure : Accepte : HHMM, HHMMSS, HHMMSSCC, HHMMSSLLL
//		// - Cette chaine fait 8 caract�res
		// - Cette chaine fait 8 caract�res ou 8 caract�res + HHMM/HHMMSS/HHMMSSCC/HHMMSSLLL
		// - La chaine est uniquement compos� de chiffres
//		if (null == ms_oFormatDate.exec(sDate))
		if (null == ms_oFormatDateAccepteHeure.exec(sDate))
		{
			return false;
		}

		// - La chaine est d�compos� en AAAAMMJJ avec :
		//	- AAAA entre 0001 et 9999 (automatiquement valid� par le contenu compos� de chiffres sauf pour le cas 0000).
		var nAnnee = parseInt(sDate.substr(0, 4), 10);
		if ((nAnnee < 1) || (9999 < nAnnee))
		{
			return false;
		}

		// - La chaine est d�compos� en AAAAMMJJ avec :
		//	- MM est entre 01 et 12
		var nMois = parseInt(sDate.substr(4, 2), 10);
		if ((nMois < 1) || (12 < nMois))
		{
			return false;
		}

		// - La chaine est d�compos� en AAAAMMJJ avec :
		//	- JJ est entre 01 et 28/29/30/31 selon AAAA, MM, JJ
		//	- QW320092 : Recpecte le calendrier julien
		var nJour = parseInt(sDate.substr(6, 2), 10);
		var nNbJoursDansMois = clWLangage.ms_tabNbJoursDansMois[nMois - 1];
		if ((2 === nMois) && (0 === (nAnnee % 4)) && ((nAnnee < 1582) || (0 !== (nAnnee % 100)) || (0 === (nAnnee % 400))))
		{
			nNbJoursDansMois++;
		}
		if ((nJour < 1) || (nNbJoursDansMois < nJour))
		{
			return false;
		}

		// - Refuse les dates entre le 05/10/1582 et 14/10/1582 (dates qui n'ont pas exister lors de la transition du calendrier Julien au calendrier Gr�gorien)
		if ((1582 === nAnnee) && (10 === nMois) && ((5 <= nJour) && (nJour <= 14)))
		{
			return false;
		}

		return true;
	};
})();

//////////////////////////////////////////////////////////////////////////
// DateHeureParD�faut
// La date et l'heure par d�faut : null pour la date courante
clWLangage.ms_oDateHeureDefaut = null;

clWLangage.DateHeureParDefaut = function DateHeureParDefaut(sDate, sHeure)
{
	// Passe par une chaine car l'utilisateur peur affecter une valeur invalide !!!
	if ((undefined !== sDate) && (undefined !== sHeure))
	{
		clWLangage.ms_oDateHeureDefaut = { m_sDate: String(sDate), m_sHeure: String(sHeure) };
	}
	else
	{
		clWLangage.ms_oDateHeureDefaut = null;
	}
};

//////////////////////////////////////////////////////////////////////////
// ChaineVersDur�e/Dur�eVersChaine
clWLangage.m_tabDureeVersChaineFormat = (function ()
{
	function __sGetSigneObligatoire(oDuree)
	{
		return (0 <= oDuree.m_nValeur) ? "+" : "-";
	};
	function __sGetSigneOptionnel(oDuree)
	{
		return (0 <= oDuree.m_nValeur) ? "" : "-";
	};
	function __sGetJourSur7(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 2, 7);
	};
	function __sGetJour(oDuree)
	{
		return __GetProprietePositif(oDuree, 2);
	};
	function __sGetHeure2(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 3, 2);
	};
	function __sGetHeure1(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 3, 1);
	};
	function __sGetMinute2(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 4, 2);
	};
	function __sGetMinute1(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 4, 1);
	};
	function __sGetSeconde2(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 5, 2);
	};
	function __sGetSeconde1(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 5, 1);
	};
	function __sGetMilliseconde3(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 6, 3);
	};
	function __sGetMilliseconde1(oDuree)
	{
		return __GetProprietePositifComplete(oDuree, 6, 1);
	};
	function __sGetCentiemeseconde(oDuree)
	{
		return clWDUtil.sCompleteEntier(Math.floor(__GetProprietePositif(oDuree, 6) / 10), 2);
	};
	function __GetProprietePositif(oDuree, nPropriete)
	{
		return Math.abs(oDuree.GetProp(nPropriete));
	};
	function __GetProprietePositifComplete(oDuree, nPropriete, nTailleMin)
	{
		return clWDUtil.sCompleteEntier(__GetProprietePositif(oDuree, nPropriete), nTailleMin);
	};

	function __xsDeformateSigne(sChaine, oDuree)
	{
		if (0 < sChaine.length)
		{
			switch (sChaine.charAt(sChaine.length - 1))
			{
			case "+":
				break;
			case "-":
				oDuree.m_nValeur = -oDuree.m_nValeur;
				break;
			default:
				throw new WDErreur(204);
			}
			return sChaine.substr(0, sChaine.length - 1);
		}
		return sChaine;
	};
	function __xsDeformateJourSur7(sChaine, oDuree)
	{
		// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
		return __xsDeformateNombre(sChaine, oDuree, 7, 86400000);
	};
	function __xsDeformateJour(sChaine, oDuree)
	{
		// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
		var nPas = 86400000;
		// Tant qu'il reste des caracteres
		while (0 < sChaine.length)
		{
			var nChiffre = parseInt(sChaine.charAt(sChaine.length - 1), 10);
			if (isNaN(nChiffre))
			{
				break;
			}
			else
			{
				oDuree.m_nValeur += nChiffre * nPas;
				nPas *= 10;
			}
			sChaine = sChaine.substr(0, sChaine.length - 1);
		}

		return sChaine;
	};
	function __xsDeformateHeure2(sChaine, oDuree)
	{
		// 3600000 = 60 * 60 * 1000 = 1 heure en milli�mes de secondes
		return __xsDeformateNombre(sChaine, oDuree, 2, 3600000);
	};
	function __xsDeformateHeure1(sChaine, oDuree)
	{
		// 3600000 = 60 * 60 * 1000 = 1 heure en milli�mes de secondes
		return __xsDeformateNombreMin(sChaine, oDuree, 2, 3600000);
	};
	function __xsDeformateMinute2(sChaine, oDuree)
	{
		// 60000 = 60 * 1000 = 1 minute en milli�mes de secondes
		return __xsDeformateNombre(sChaine, oDuree, 2, 60000);
	};
	function __xsDeformateMinute1(sChaine, oDuree)
	{
		// 60000 = 60 * 1000 = 1 minute en milli�mes de secondes
		return __xsDeformateNombreMin(sChaine, oDuree, 2, 60000);
	};
	function __xsDeformateSeconde2(sChaine, oDuree)
	{
		// 1000 = 1000 = 1 second en milli�mes de secondes
		return __xsDeformateNombre(sChaine, oDuree, 2, 1000);
	};
	function __xsDeformateSeconde1(sChaine, oDuree)
	{
		// 1000 = 1000 = 1 second en milli�mes de secondes
		return __xsDeformateNombreMin(sChaine, oDuree, 2, 1000);
	};
	function __xsDeformateMilliseconde3(sChaine, oDuree)
	{
		return __xsDeformateNombre(sChaine, oDuree, 3, 1);
	};
	function __xsDeformateMilliseconde1(sChaine, oDuree)
	{
		return __xsDeformateNombreMin(sChaine, oDuree, 3, 1);
	};
	function __xsDeformateCentiemeseconde(sChaine, oDuree)
	{
		// 10 = 1 centi�me de secondes en milli�mes de secondes
		return __xsDeformateNombre(sChaine, oDuree, 2, 10);
	};
	function __xsDeformateNombre(sChaine, oDuree, nLongueur, nPas)
	{
		sChaine = clWDUtil.sCompleteEntier(sChaine, nLongueur);
		oDuree.m_nValeur += parseInt(sChaine.substr(sChaine.length - nLongueur), 10) * nPas;
		return sChaine.substr(0, sChaine.length - nLongueur);
	};
	function __xsDeformateNombreMin(sChaine, oDuree, nLongueur, nPas)
	{
		sChaine = clWDUtil.sCompleteEntier(sChaine, nLongueur);
		// Extrait le nombre maximum de caract�re
		var nLongueurValide = 0;
		for (var nLongueurTest = 1; nLongueurTest <= nLongueur; nLongueurTest++)
		{
			if (String(parseInt(sChaine.substr(sChaine.length - nLongueurTest), 10)).length == nLongueurTest)
			{
				nLongueurValide = nLongueurTest;
			}
			else
			{
				// Plus un chiffre
				break;
			}
		}
		// Si aucun caract�res valides.
		if (0 == nLongueurValide)
		{
			throw new WDErreur(204);
		}
		oDuree.m_nValeur += parseInt(sChaine.substr(sChaine.length - nLongueurValide), 10) * nPas;
		return sChaine.substr(0, sChaine.length - nLongueurValide);
	};

	return [
		// GP 26/02/2018 : TB78755 : D�formatage des formats +1/+2/+3/+4/+5 (m�me si on les ignores, c'est mieux que de planter lamentablement).
		[["+1", "+2", "+3", "+4", "+5"], __sGetSigneOptionnel, __xsDeformateSigne],
		// GP 21/10/2014 : QW250237 : + indique de mettre uniquement le -. +/- indique de toujours le mettre (pour DateHeureDifference)
		// GP 25/10/2017 : QW292027 : Pour le formatage des champs : ajoute les masques des champs : H, M, S, CCC, 00C, CC
		[["+/-"], __sGetSigneObligatoire, __xsDeformateSigne],
		[["+"], __sGetSigneOptionnel, __xsDeformateSigne],
		// GP 16/10/2014 : Le format est JJJJJJJ (7xJ) et pas JJJJJJJJ (8xJ)
		[["JJJJJJJ"], __sGetJourSur7, __xsDeformateJourSur7],
		[["J", "D"], __sGetJour, __xsDeformateJour],
		[["HH"], __sGetHeure2, __xsDeformateHeure2],
		[["H"], __sGetHeure1, __xsDeformateHeure1],
		[["MM"], __sGetMinute2, __xsDeformateMinute2],
		[["M"], __sGetMinute1, __xsDeformateMinute1],
		[["SS"], __sGetSeconde2, __xsDeformateSeconde2],
		[["S"], __sGetSeconde1, __xsDeformateSeconde1],
		[["LLL", "CCC"], __sGetMilliseconde3, __xsDeformateMilliseconde3],
		[["00C"], __sGetMilliseconde1, __xsDeformateMilliseconde1],
		[["LL", "CC"], __sGetCentiemeseconde, __xsDeformateCentiemeseconde]
	];

})();

// Corrige le format
clWLangage.__sCorrigeFormatDureePourConstantes = function __sCorrigeFormatDureePourConstantes(sFormat)
{
	switch (sFormat)
	{
	case 0:
		// dur�eMilli�me
		return "+JHHMMSSLLL";
	case 1:
		// dur�eCenti�me
		return "+JHHMMSSLL";
	default:
		return sFormat;
	}
};

clWLangage.__sDureeVersChaine = function __sDureeVersChaine(oDuree, sFormat)
{
	// Tableau : pointeur de fonction vers le format ou caract�re de la chaine qui n'est pas un format
	var tabFormats = clWDUtil.__tabParseFormat(sFormat, this.m_tabDureeVersChaineFormat, false);

	// Construit le r�sultat
	var tabResultat = [];
	clWDUtil.bForEach(tabFormats, function(oUnFormat)
	{
		switch (typeof oUnFormat)
		{
		case "string":
			tabResultat.push(oUnFormat);
			break;
		case "function":
			// GP 27/06/2014 : QW245795 : Utilisation de clWDUtil au lieu de this (on est dans la callback le this n'est pas valide)
			tabResultat.push(oUnFormat(oDuree));
			break;
		default:
			clWDUtil.WDDebug.assert(false, "Format invalide");
			break;
		}
		return true;
	});


	return tabResultat.join("");
};
clWLangage.sDureeVersChaine = function sDureeVersChaine(oDureeWL, sFormat)
{
	// GP 21/10/2014 : QW250237 : Conversion du format pour le cas des constantes
	sFormat = this.__sCorrigeFormatDureePourConstantes(sFormat);

	// R�cup�re un objet dur�e depuis la dur�e re�ue du WL et effectue le formatage
	return this.__sDureeVersChaine(new (this.WDDuree)(oDureeWL), sFormat);
};
clWLangage.sChaineVersDuree = function sChaineVersDuree(oValeur, sFormat)
{
	// GP 12/03/2018 : QW297159 : La valeur n'est pas forc�ment une chaine (c'est une valeur re�ue du WL donc peut-�tre m�me une dur�e).
	if (oValeur instanceof this.WDDuree)
	{
		// OPTIM : si c'est une dur�e : retourne directement la valeur. On peut avoir ce ca si on utilise la syntaxe de dur�e j15h42min50s850ms
		return oValeur;
	}
	var sChaine = String(oValeur);

	// GP 21/10/2014 : QW250237 : Conversion du format pour le cas des constantes
	sFormat = this.__sCorrigeFormatDureePourConstantes(sFormat);

	// Tableau : pointeur de fonction vers le format ou caract�re de la chaine qui n'est pas un format
	// GP 26/02/2018 : TB78755 : Ignore les espaces du format
	var tabFormats = clWDUtil.__tabParseFormat(sFormat, this.m_tabDureeVersChaineFormat, true, true);

	// GP 26/02/2018 : TB78755 : Et ignore aussi les espaces du texte
	sChaine = clWDUtil.sSupprimeEspaces(sChaine);

	var oDuree = new (this.WDDuree)(undefined);

	// Le probl�me est le nombre de jours. On ne sait pas sur combien de chiffres on doit le lire.
	// Analyse depuis la fin
	for (var i = tabFormats.length - 1; 0 <= i; i--)
	{
		var oUnFormat = tabFormats[i];
		switch (typeof oUnFormat)
		{
		case "string":
			// Ignore ces caract�res de la sources.
			// En code serveur, ignore juste les caract�res (les m�mes ou d'autres)
			if (oUnFormat.length <= sChaine.length)
			{
				sChaine = sChaine.substr(0, sChaine.length - oUnFormat.length);
			}
			else
			{
				// Source invalide
				return null;
			}
			break;
		case "function":
			try
			{
				// GP 27/06/2014 : QW245795 : Utilisation de clWDUtil au lieu de this (on est dans la callback le this n'est pas valide)
				sChaine = oUnFormat(sChaine, oDuree);
			}
			catch (oErreur)
			{
				// GP 27/06/2014 : QW245795 : Utilisation de clWDUtil au lieu de this (on est dans la callback le this n'est pas valide)
				if (clWDUtil.bCatch(oErreur))
				{
					// On a une erreur : retourne la chaine vide
					return null;
				}
				else
				{
					// Erreur autre
					throw oErreur;
				}
			}
			break;
		default:
			// Format invalide
			clWDUtil.WDDebug.assert(false, "Format invalide");
			break;
		}
	}
	return oDuree;
};

// XxxVersEntier
clWLangage.nDateVersEntier = function nDateVersEntier(oDate)
{
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return this.__xoGetDHFromWL(oDate, true, false).toNumber();
};
clWLangage.nHeureVersEntier = function nHeureVersEntier(oDateWL)
{
	// 10 = 1 centi�me de secondes en milli�mes de secondes
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return this.__xoGetDHFromWL(oDateWL, false, true).toNumber();
};

// EntierVersXxx
clWLangage.sEntierVersDate = function sEntierVersDate(nEntier, sFormat)
{
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	var oDateHeure = this.__xoGetDHFromWL(nEntier, true, false);
	var oDateJS = oDateHeure.m_oValeur;
	switch (sFormat)
	{
	case "A":
	case "Y":
		return clWDUtil.sCompleteEntier(oDateJS.getFullYear(), 4);
	case "M":
		return clWDUtil.sCompleteEntier(oDateJS.getMonth() + 1, 2);
	case "J":
	case "D":
		return clWDUtil.sCompleteEntier(oDateJS.getDate(), 2);
	default:
		return oDateHeure.toString();
	}
};
clWLangage.sEntierVersHeure = function sEntierVersHeure(nEntier)
{
	// GP 28/10/2014 : QW250697 : Le format de EntierVersHeure est HHMMSSCC et pas HHMMSSCCC
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return this.__xoGetDHFromWL(nEntier, false, true).toString().substr(0, 8);
};
clWLangage.__xnEntierVersJour = function __xnEntierVersJour(nEntier)
{
	// GP 21/10/2014 : QW250230 : Accepte lee type date comme source
	// Et pour faire simple et accepter toutes les conversions, on convertit en type date
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return this.__xoGetJSFromWL(nEntier, true, false).getDay();
};
clWLangage.nEntierVersJour = function nEntierVersJour(nEntier)
{
	// On adapte le resultat au format du WL
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	var nJourJS = this.__xnEntierVersJour(nEntier);
	return nJourJS == 0 ? 7 : nJourJS;
};
clWLangage.sEntierVersJourEnLettres = function sEntierVersJourEnLettres(nEntier)
{
	// clWDUtil.sGetJourSemaine attend un jour au format JS (dimanche en 0)
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return clWDUtil.sGetJourSemaine(this.__xnEntierVersJour(nEntier));
};
clWLangage.nEntierVersMoisEnLettres = function nEntierVersMoisEnLettres(nEntier)
{
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	return clWDUtil.sGetMois(this.__xoGetJSFromWL(nEntier, true, false).getMonth());
};
clWLangage.nNumeroDeSemaine = function nNumeroDeSemaine(oDate)
{
	// GP 27/10/2014 : Utilise la conversion par WDDateHeure, donc accepte les chaines, les entiers et autres
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
	var oDateHeure = this.__xoGetDHFromWL(oDate, true, false);
	// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides car oDateHeure est logiquement valide (verifi� par __xoGetDHFromWL)
	var oDateHeureDebutAnnee = new (this.WDDateHeure)(true, false, oDateHeure, undefined, false);
	// GP 27/10/2014 : Jour puis mois
	oDateHeureDebutAnnee.SetProp(2, 1);
	oDateHeureDebutAnnee.SetProp(1, 1);
	var nDateDebutAnne = oDateHeureDebutAnnee.toNumber();
	var nNbJourAnnee = oDateHeure.toNumber() - nDateDebutAnne;
	var nNumeroPremierJour = (nDateDebutAnne + 657071) % 7;
	switch (nNumeroPremierJour)
	{
	case 0:
		nNumeroPremierJour = 7;
	case 5:
	case 6:
		var nDecalage = 8 - nNumeroPremierJour;
		return nNbJourAnnee >= nDecalage ? Math.floor((nNbJourAnnee - nDecalage) / 7) + 1 : 0;
	case 1:
	case 2:
	case 3:
	case 4:
		return Math.floor((nNbJourAnnee + nNumeroPremierJour - 1) / 7) + 1;
	}
};

// GP 27/11/2013 : QW239930 : Vu avec SYC : On conserve le comportement original (rebond sur HeureSys()) + On documente
// GP 18/11/2013 : QW234496 : Impossible de faire fonctionner Maintenant avec son nouveau type de retour
// Continue le rebond sur HeureSys() et ajout un message d'information
//
//// Calcule la valeur de maintenant pour la Fonction WL maintenant
//clWLangage.oMaintenant = function oMaintenant()
//{
//	// GP 18/11/2013 : QW234496 : Maintenant retourne un "multitype"
//
//	// On calcule une seule fois la date pour ne pas prendre le risque de changer de milliseconde au milieu du calcul.
//	var oMaintenant = new Date();
//	var oDate = new clWLangage.WDDateHeure(true, false, oMaintenant, undefined, false);
//	var oHeure = new clWLangage.WDDateHeure(false, true, oMaintenant, undefined, false);
//	var oDateHeure = new clWLangage.WDDateHeure(true, true, oMaintenant, undefined, false);
//
//	// 25 : WLT_TIMEW
//	var oValeur = new (this.WDMultiType)(25, oHeure);
//	// 24 : WLT_DATEW
//	oValeur.AddValeur(24, oDate);
//	// 26 : WLT_DATETIME
//	oValeur.AddValeur(26, oDateHeure);
//	return oValeur;
//};
//
//// Type WL "multitype"
//clWLangage.WDMultiType = function WDMultiType(nTypeWLDefaut, oValeurDefaut)
//{
//	// On stocke directement les valeurs dans notre objet
//	this[nTypeWLDefaut] = oValeurDefaut;
//	this.m_nTypeWLDefaut = nTypeWLDefaut;
//};
//clWLangage.WDMultiType.prototype.AddValeur = function AddValeur(nTypeWL, oValeur)
//{
//	this[nTypeWL] = oValeur;
//};
//clWLangage.WDMultiType.prototype.oGetValeur = function oGetValeur(nTypeGauche, oTypeGaucheEtendu)
//{
//	var oValeur = this[nTypeGauche];
//	if (undefined !== oValeur)
//	{
//		// La valeur existe dans ce type
//		return oValeur;
//	}
//	else
//	{
//		// La valeur n'existe pas dans ce type : retourne la valeur par d�faut cast�
//		// undefined : on ne g�re pas encore le cas des tableaux
//		return clWDUtil.oConversionType(this[this.m_nTypeWLDefaut], nTypeGauche, oTypeGaucheEtendu, this.m_nTypeWLDefaut, undefined);
//	}
//};

//////////////////////////////////////////////////////////////////////////
// Gestion des types Date, Heure, DateHeure
clWLangage.WDDateHeure = (function ()
{
	"use strict";
	var __WDDateHeure = function __WDDateHeure(bDate, bHeure, oValeurInitialeWL, oValeurInitialeReference, bAccepteInvalide)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			this.m_bDate = bDate;
			this.m_bHeure = bHeure;
			// GP 18/03/2015 : QW256095 : Il faut toujours le faire (en particulier si oValeurInitialeWL et oValeurInitialeReference sont undefined).
			this.m_sValeurInvalide = null;
			if (undefined !== oValeurInitialeReference)
			{
				// Si on recoit une valeur que l'on doit li� par r�f�rence, c'est que c'est une date valide
				clWDUtil.WDDebug.assert(undefined === oValeurInitialeWL);
				clWDUtil.WDDebug.assert(false === bAccepteInvalide);
				this.m_oValeur = oValeurInitialeReference;
				clWDUtil.WDDebug.assert(this.bDateValide());
			}
			else
			{
				this.m_oValeur = new Date();
				if (undefined === oValeurInitialeWL)
				{
					var oDateHeureDefaut = clWLangage.ms_oDateHeureDefaut;
					if (null !== oDateHeureDefaut)
					{
						oValeurInitialeWL = "";
						if (bDate)
						{
							oValeurInitialeWL += oDateHeureDefaut.m_sDate;
						}
						if (bHeure)
						{
							oValeurInitialeWL += oDateHeureDefaut.m_sHeure;
						}
					}
				}
				if (undefined !== oValeurInitialeWL)
				{
					this.__SetValeur(oValeurInitialeWL, bAccepteInvalide);
				}
				// GP 28/10/2014 : QW250691 : Corrige la valeur pour forcer les heures � z�ro
				if (!bHeure)
				{
					this.m_oValeur.setHours(0, 0, 0, 0);
				}

			}
		}
	};

	// Faire d�river de WDTypeAvance ?

	__WDDateHeure.prototype.__toString = function __toString()
	{
		return clWDUtil.sGetDateHeureWL(this.m_oValeur, false, this.m_bDate, this.m_bHeure);
	};
	// Surcharge toString pour avoir une conversion simple en chaine (AAAAMMJJ, HHMMSSLLL, AAAAMMJJHHMMSSLLL)
	__WDDateHeure.prototype.toString = function toString(/*nBase*/)
	{
		// GP 20/03/2015 : Autorise la valeur "" comme valeur valide en lecture
		if ("" === this.m_sValeurInvalide)
		{
			return this.m_sValeurInvalide;
		}
		// GP 19/03/2015 : QW256121 : Par d�faut on refuse les dates invalides
		this._xDateValide();
		return this.__toString();
	};
	// GP 19/03/2015 : QW256121 : Version de toString qui accepte les dates invalides
	__WDDateHeure.prototype.toStringAvecInvalide = function toStringAvecInvalide()
	{
		if (this.bDateValide())
		{
			return this.__toString();
		}
		else
		{
			return this.m_sValeurInvalide;
		}
	};

	// Conversion en entier
	__WDDateHeure.prototype.toNumber = function toNumber()
	{
		// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
		this._xDateValide();

		var oValeur = this.m_oValeur;
		if (this.m_bDate && this.m_bHeure)
		{
			// Pas de conversion des dateheures en entier
			return 0;
		}
		else if (this.m_bDate)
		{
			// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
			// 62092 : offset en jours entre le 01/01/1800 et le 01/01/1970
			// GP 28/10/2014 : QW250691 : corrige par l'offset de la timezone (getTimezoneOffset est en minutes)
			// GP 08/10/2018 : QW304281 : Chrome utilise maintenant une base historique des fuseau horaires. Pour les date anciennes (vers 1900 et avant) chaque pays avait son fuseau.
			// Et l'offset n'�tait un nombre entier de minutes. Comme getTimezoneOffset() retourne un entier, il y a un arrondi. Ce qui fait que l'on ne corrige pas assez.
			// On a au maximum une erreur de 1 minutes. Donc on ajoute la correction de une minute. Cela tient compte du fait que Math.floor va toujours vers la valeur n�gative.
			var nTimezoneOffset = oValeur.getTimezoneOffset();
			// On fait "- nTimezoneOffset", donc pour d�caler de 1, il faut faire -1 dans le cas d'un offset n�gatif
			nTimezoneOffset += (nTimezoneOffset < 0) ? -1 : 1;
			return Math.floor((oValeur.getTime() - nTimezoneOffset * 60000) / 86400000) + 62092;
		}
		else if (this.m_bHeure)
		{
			// Pour �viter un probl�me d'UTC, on ne prend pas oValeur.getTime() / 86400000 comme heure mais bien les heures effectives
			// 10 = 1 centi�me de secondes en milli�mes de secondes
			return clWDUtil.nArrondiVersZero((oValeur.getHours() * 3600000 + oValeur.getMinutes() * 60000 + oValeur.getSeconds() * 1000 + oValeur.getMilliseconds()) / 10);
		}
	};

	// GP 09/11/2016 : Ajout de toJSON
	__WDDateHeure.prototype.toJSON = __WDDateHeure.prototype.toString;

	// Indique si la valeur est marqu�e comme invalide
	__WDDateHeure.prototype.bDateValide = function bDateValide()
	{
		return (null === this.m_sValeurInvalide);
	};

	// Lance une erreur si la valeur n'est pas valide
	__WDDateHeure.prototype._xDateValide = function _xDateValide()
	{
		if (!this.bDateValide())
		{
			throw new WDErreur(204);
		}
	};

	__WDDateHeure.prototype.__oAdditionOffset = function __oAdditionOffset(nOffsetMs)
	{
		// La cr�ation d'un DateHeure depuis un entier est interdit
		if (this.m_bDate && this.m_bHeure)
		{
			// Ne change pas nOffset
		}
		else if (this.m_bDate)
		{
			// Filtre les heures
			// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
			nOffsetMs = clWDUtil.nArrondiVersZero(nOffsetMs / 86400000) * 86400000;
		}
		else if (this.m_bHeure)
		{
			// Filtre les jours
			nOffsetMs -= clWDUtil.nArrondiVersZero(nOffsetMs / 86400000) * 86400000;
		}

		var oResultat = new __WDDateHeure(this.m_bDate, this.m_bHeure);
		oResultat.m_oValeur.setTime(this.m_oValeur.getTime() + nOffsetMs);
		return oResultat;
	};

	// Factorisation de code entre oAdditionDuree et oSoustractionDuree
	__WDDateHeure.prototype.__xoAdditionOffset = function __xoAdditionOffset(nOffsetMs)
	{
		// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
		this._xDateValide();

		// Rebond sur la fonction sans validation
		return this.__oAdditionOffset(nOffsetMs);
	};

	// Addition entre un dateheure et une dur�e
	__WDDateHeure.prototype.oAdditionDuree = function oAdditionDuree(oDuree)
	{
		return this.__xoAdditionOffset(oDuree.m_nValeur);
	};
	// Diff�rence entre deux WDDateHeure : effectue this - oDateHeure
	__WDDateHeure.prototype.oSoustractionDate = function oSoustractionDate(oDateHeure)
	{
		// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
		this._xDateValide();
		oDateHeure._xDateValide();

		// La diff�rence est une dur�e

		// GP 22/10/2014 : QW250350 : Le javascript tient compte de l'heure d'hiver !!!
		// Donc si je prend 12:00 le semadi avant le passage de l'heure d'hiver et 12:00 le dimanche juste apr�s :
		// - Un calcul par diff�rence simple sur les composantes donne 24 heures
		//	<= c'est le code WL serveur
		// - Un calcul par conversion vers une r�f�rence en UTC donne 25 heures
		//	<= c'est le code avec getTime()
		// Pour contourner on tient compte de l'offset de time zone
		return new clWLangage.WDDuree(this.m_oValeur.getTime() - oDateHeure.m_oValeur.getTime() - (this.m_oValeur.getTimezoneOffset() - oDateHeure.m_oValeur.getTimezoneOffset()) * 60000);
	};
	// Diff�rence entre un WDDateHeure et une Duree : effectue this - oDuree
	__WDDateHeure.prototype.oSoustractionDuree = function oSoustractionDuree(oDuree)
	{
		return this.__xoAdditionOffset(-oDuree.m_nValeur);
	};

//	__WDDateHeure.prototype.valueOf = __WDDateHeure.prototype.toString;
	// Acc�s depuis le WL


	// Lire une propriete
	__WDDateHeure.prototype.GetProp = function GetProp(nPropriete)
	{
		// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides.
		// Note : ce n'est pas le cas en code serveur (retourne 0 si la valeur est invalide).
		this._xDateValide();

		switch (nPropriete)
		{
		case 0:
			// ..Ann�e
			clWDUtil.WDDebug.assert(this.m_bDate, "..Annee sur un type Heure");
			return this.m_bDate ? this.m_oValeur.getFullYear() : 0;
		case 1:
			// ..Mois : Le mois est entre 0 et 11
			clWDUtil.WDDebug.assert(this.m_bDate, "..Mois sur un type Heure");
			return this.m_bDate ? (this.m_oValeur.getMonth() + 1) : 0;
		case 2:
			// ..Jour
			clWDUtil.WDDebug.assert(this.m_bDate, "..Jour sur un type Heure");
			return this.m_bDate ? this.m_oValeur.getDate() : 0;
		case 3:
			// ..Heure
			clWDUtil.WDDebug.assert(this.m_bHeure, "..Heure sur un type Date");
			return this.m_bHeure ? this.m_oValeur.getHours() : 0;
		case 4:
			// ..Minute
			clWDUtil.WDDebug.assert(this.m_bHeure, "..Minute sur un type Date");
			return this.m_bHeure ? this.m_oValeur.getMinutes() : 0;
		case 5:
			// ..Seconde
			clWDUtil.WDDebug.assert(this.m_bHeure, "..Seconde sur un type Date");
			return this.m_bHeure ? this.m_oValeur.getSeconds() : 0;
		case 6:
			// ..Milliseconde
			clWDUtil.WDDebug.assert(this.m_bHeure, "..Milliseconde sur un type Date");
			return this.m_bHeure ? this.m_oValeur.getMilliseconds() : 0;
		case 7:
			// ..PartieDate : manipule un alias de la date courante
			// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides (mais d�j� test� au dessus)
			return new __WDDateHeure(true, false, undefined, this.m_oValeur, false);
		case 8:
			// ..PartieHeure : manipule un alias de l'heure courante
			// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides (mais d�j� test� au dessus)
			return new __WDDateHeure(false, true, undefined, this.m_oValeur, false);
		default:
			return null;
		}
	};

	// Ecrire une propriete
	__WDDateHeure.prototype.__SetProp = function __SetProp(nPropriete, oValeur, bAvecBornes)
	{
		// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides.
		// Note : ce n'est pas le cas en code serveur (retourne 0 si la valeur est invalide).
		this._xDateValide();

		var nJourPrecedent;
		var nMoisPrecedent;
		switch (nPropriete)
		{
		case 0:
			// ..Ann�e
			clWDUtil.WDDebug.assert(this.m_bDate, "SetAnnee sur un type Heure");
			// GP 21/10/2014 : QW250184 : Uniquement pour ..Mois et ..Ann�e
			nJourPrecedent = this.m_oValeur.getDate();
			// On g�re l'ann�e sur 2 en WL ici ?
			// Selon https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/setFullYear le JS g�re les valeurs hors plage (comme en WL)
			this.m_oValeur.setFullYear(__nGetValeurDansBornes(oValeur, 0, 9999, bAvecBornes));
			break;
		case 1:
			// ..Mois : Le mois est entre 0 et 11
			clWDUtil.WDDebug.assert(this.m_bDate, "SetMois sur un type Heure");
			// GP 21/10/2014 : QW250184 : Uniquement pour ..Mois et ..Ann�e
			nJourPrecedent = this.m_oValeur.getDate();
			// Selon https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/setMonth le JS g�re les valeurs hors plage (comme en WL)
			this.m_oValeur.setMonth(__nGetValeurDansBornes(oValeur, 1, 12, bAvecBornes) - 1);
			break;
		case 2:
			// ..Jour
			clWDUtil.WDDebug.assert(this.m_bDate, "SetJour sur un type Heure");
			// Selon https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/setDate le JS g�re les valeurs hors plage (comme en WL)
			nMoisPrecedent = this.m_oValeur.getMonth();
			this.m_oValeur.setDate(__nGetValeurDansBornes(oValeur, 1, 31, bAvecBornes));
			if (bAvecBornes && (nMoisPrecedent != this.m_oValeur.getMonth()))
			{
				this.m_oValeur.setDate(0)
			}
			break;
		case 3:
			// ..Heure
			clWDUtil.WDDebug.assert(this.m_bHeure, "SetHeure sur un type Date");
			// Selon https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/setHours le JS g�re les valeurs hors plage (comme en WL)
			this.m_oValeur.setHours(__nGetValeurDansBornes(oValeur, 0, 23, bAvecBornes));
			break;
		case 4:
			// ..Minute
			clWDUtil.WDDebug.assert(this.m_bHeure, "SetMinute sur un type Date");
			// Selon https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/setMinutes le JS g�re les valeurs hors plage (comme en WL)
			this.m_oValeur.setMinutes(__nGetValeurDansBornes(oValeur, 0, 59, bAvecBornes));
			break;
		case 5:
			// ..Seconde
			clWDUtil.WDDebug.assert(this.m_bHeure, "SetSeconde sur un type Date");
			// Selon https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/setSeconds le JS g�re les valeurs hors plage (comme en WL)
			this.m_oValeur.setSeconds(__nGetValeurDansBornes(oValeur, 0, 59, bAvecBornes));
			break;
		case 6:
			// ..Milliseconde
			clWDUtil.WDDebug.assert(this.m_bHeure, "SetMilliseconde sur un type Date");
			// Selon https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/setMilliseconds le JS g�re les valeurs hors plage (comme en WL)
			this.m_oValeur.setMilliseconds(__nGetValeurDansBornes(oValeur, 0, 999, bAvecBornes));
			break;
		case 7:
			// ..PartieDate : manipule un alias de la date courante
			// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides
			(new __WDDateHeure(true, false, undefined, this.m_oValeur, false)).SetValeur(oValeur);
			break;
		case 8:
			// ..PartieHeure : manipule un alias de l'heure courante
			// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides (mais d�j� test� au dessus)
			(new __WDDateHeure(false, true, undefined, this.m_oValeur, false)).SetValeur(oValeur);
			break;
		default:
			break;
		}

		// GP 20/10/2014 : QW250184 : Si on change le mois/l'ann�e et que le jour initial n'existe pas dans le mois+ann�e cible. Le JS se place au premier jour valide suivant.
		// Alors que le WL serveur se place sur le premier jour valide pr�c�dent.
		if ((undefined !== nJourPrecedent) && (this.m_oValeur.getDate() != nJourPrecedent))
		{
			// 0 pour repasser � la fin du mois pr�c�dent
			this.m_oValeur.setDate(0);
			clWDUtil.WDDebug.assert(this.m_oValeur.getDate() < nJourPrecedent, "Echec du replacement");
		}
	};
	function __nGetValeurDansBornes(oValeur, nBorneMinIncluse, nBorneMaxIncluse, bAvecBornes)
	{
		oValeur = parseInt(oValeur, 10);
		if (bAvecBornes)
		{
			if (oValeur < nBorneMinIncluse)
			{
				return nBorneMinIncluse;
			}
			else if (nBorneMaxIncluse < oValeur)
			{
				return nBorneMaxIncluse;
			}
		}

		return oValeur;
	};
	__WDDateHeure.prototype.SetProp = function SetProp(nPropriete, oValeur)
	{
		this.__SetProp(nPropriete, oValeur, true);
	};
	// Ecrire une propriete
	__WDDateHeure.prototype.SetPropCombine = function SetPropCombine(nPropriete, oValeur)
	{
		this.__SetProp(nPropriete, oValeur, false);
	};

	// Conversion d'une valeur du WL vers la valeur interne
	__WDDateHeure.prototype.SetValeur = function SetValeur(oDateWL)
	{
		this.__SetValeur(oDateWL, false);
	};

	// Version interne de SetValeur pour factorisation de code avec le constructeur
	__WDDateHeure.prototype.__SetValeur = function __SetValeur(oDateWL, bAccepteInvalide)
	{
		this.m_sValeurInvalide = null;

		var bValide = true;

		switch (typeof oDateWL)
		{
		case "string":
			bValide = this.__bSetValeurChaine(oDateWL);
			break;
		case "number":
			bValide = this.__bSetValeurNombre(oDateWL);
			break;
		case "object":
			switch (clWDUtil.oGetTypeEntendu(oDateWL))
			{
			case 5:		// WLT_UI8
			case 9:		// WLT_I8
			case 13:	// WLT_DECIMAL
			// oGetTypeEntendu retourne WLT_I8 pour WLT_UIX
	//		case 14:	// WLT_UIX
				bValide = this.__bSetValeurNombre(oDateWL.toNumber());
				break;
			case 24:	// WLT_DATEW
			case 25:	// WLT_TIMEW
			case 26:	// WLT_DATETIME
				bValide = this.__bSetValeurObjetDateHeure(oDateWL);
				break;
			default:
				bValide = this.__bSetValeurObjet(oDateWL);
				break;
			}
			break;
		}

		if (!bValide)
		{
			// GP 19/03/2015 : QW256111 : On accepte quand m�me toujours "" (utilisation de !== pour n'avoir que r�ellement "")
			if (!bAccepteInvalide && ("" !== oDateWL))
			{
				// Erreur
				throw new WDErreur(204);
			}
			else
			{
				this.m_sValeurInvalide = oDateWL + "";
			}
		}
	};

	// Conversion d'une valeur chaine du WL vers la valeur interne
	// Retourne si la conversion est r�ussie
	__WDDateHeure.prototype.__bSetValeurChaine = function __bSetValeurChaine(sDateWL)
	{
		// GP 16/10/2014 : QW249960 : En cas d'affectation directe depuis le WL : hHeure = "11" est valide
		// GP 22/10/2014 : QW250329 : On conserve le comportement idiot du WL serveur : accepte tout d�s que l'on a un caract�re... "0" => 00:00:00:000, "1" => 10:00:00:000
		if (clWDUtil.bSetDateHeureFromWL(this.m_oValeur, sDateWL, false, this.m_bDate, this.m_bHeure, 1))
		{
			// GP 17/10/2014 : Vu avec SYC : on est strict, la valeur pass�e depuis le WL doit �tre une date/heure valide (pas de jour < 1 ou > 31 etc)
			var sDateWLCorrigee = sDateWL;
			if (this.m_bHeure)
			{
				// On est une heure ou un dateheure.
				// On autorise les valeurs non completes sur la partie heure.
				sDateWLCorrigee = clWDUtil.sCompleteChaine(sDateWLCorrigee, this.m_bDate ? 17 : 9, "0");
			}

			// R�ussite seulement si la valeur source correspond � ce que l'on recr�e
			if (sDateWLCorrigee == this.toString())
			{
				return true;
			}
		}
		// Invalide
		return false;
	};

	// Conversion d'une valeur entier du WL vers la valeur interne
	// Retourne si la conversion est r�ussie
	__WDDateHeure.prototype.__bSetValeurNombre = function __bSetValeurNombre(nDateWL)
	{
		// Interpr�t�e selon le type :
		// - Date : Nombre de jours �coul�s depuis le 1er janvier 1800.
		// - Heure : L'heure correspondra alors au nombre de centi�mes de seconde �coul�s depuis minuit
		// - DateHeure : Interdit
		if (this.m_bDate && this.m_bHeure)
		{
			// - DateHeure : Interdit
			return false;
		}
		var oValeur = this.m_oValeur;
		if (this.m_bDate)
		{
			// - Date : Nombre de jours �coul�s depuis le 1er janvier 1800.
			// Pour �viter un probl�me d'UTC, on ne prend pas oValeur.getTime() / 86400000 comme heure mais bien les heures effectives
			var nHeure = oValeur.getHours() * 3600000 + oValeur.getMinutes() * 60000 + oValeur.getSeconds() * 1000 + oValeur.getMilliseconds();
			// 62092 : offset en jours entre le 01/01/1800 et le 01/01/1970
			// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
			oValeur.setTime((nDateWL - 62092) * 86400000 + nHeure);
			return true;
		}
		if (this.m_bHeure)
		{
			// Sur 24 heures seulement. et le temps est en centi�mes de secondes
			// 8640000 = 24 * 60 * 60 * 100 = 1 jour en centi�mes de secondes
			if (8640000 <= nDateWL)
			{
				return false;
			}
			oValeur.setHours(Math.floor(nDateWL / 360000), Math.floor((nDateWL % 360000) / 6000), Math.floor((nDateWL % 6000) / 100), (nDateWL % 100) * 10);
		}
		return true;
	};

	// Conversion d'une valeur objet du WL vers la valeur interne
	// Retourne si la conversion est r�ussie
	__WDDateHeure.prototype.__bSetValeurObjetDateHeure = function __bSetValeurObjetDateHeure(oDateWL)
	{
		// GP 22/08/2018 : QW301532 : G�re le cas du framework V2
		var iDateWLBase;
		if (window.NSPCS && (iDateWLBase = NSPCS.iGetAsBase(oDateWL)))
		{
			// Passe par la conversion en cha�ne
			return this.__bSetValeurChaine(iDateWLBase.toString());
		}
		else if (oDateWL instanceof __WDDateHeure)
		{
			// GP 20/03/2015 : QW256205 : Si la date source est invalide, on doit copier la partie invalide
			this.m_sValeurInvalide = oDateWL.m_sValeurInvalide;
			// On ne filtre pas selon les parties acceptables dans notre objet, elle ne seront jamais lues
			return this.__bSetValeurObjetDateNatif(oDateWL.m_oValeur);
		}
		else
		{
			return false;
		}
	};
	__WDDateHeure.prototype.__bSetValeurObjet = function __bSetValeurObjet(oDateWL)
	{
		if (oDateWL instanceof Date)
		{
			// C'est un objet date natif
			return this.__bSetValeurObjetDateNatif(oDateWL);
		}
		// Impossible : filtr� en amont et trait� dans __bSetValeurObjetDateHeure
//		else if (oDateWL instanceof __WDDateHeure)
//		{
//			// On ne filtre pas selon les parties acceptables dans notre objet, elle ne seront jamais lues
//			oDateNatif = oDateWL.m_oValeur;
//			// GP 20/03/2015 : QW256205 : Si la date source est invalide, on doit copier la partie invalide
//			this.m_sValeurInvalide = oDateWL.m_sValeurInvalide;
//		}
		else
		{
			return false;
		}
	};

	__WDDateHeure.prototype.__bSetValeurObjetDateNatif = function __bSetValeurObjetDateNatif(oDateNatif)
	{
		// Accepte selon le type :
		// - Date : accepte Date et DateHeure
		// - Heure : accepte Heure et DateHeure
		// - DateHeure : accepte Date, Heure (non document�) et DateHeure
		// GP 21/10/2014 : QW250222 : On ne doit bien �craser que la bonne partie.
		if (this.m_bDate && this.m_bHeure)
		{
			// Cr�er une copie de l'objet date natif !!! (pas de prise de r�f�rence !!!)
			// GP 16/10/2014 : QW249961 : new Date(Date()) perd les millisecondes !!!
			this.m_oValeur.setTime(oDateNatif.getTime());
		}
		else if (this.m_bDate)
		{
			this.m_oValeur.setFullYear(oDateNatif.getFullYear(), oDateNatif.getMonth(), oDateNatif.getDate());
		}
		else if (this.m_bHeure)
		{
			this.m_oValeur.setHours(oDateNatif.getHours(), oDateNatif.getMinutes(), oDateNatif.getSeconds(), oDateNatif.getMilliseconds());
		}

		// GP 20/03/2015 : QW256205 : Et on retourne si on est valide
		return this.bDateValide();
	};

	return __WDDateHeure;
})();

//////////////////////////////////////////////////////////////////////////
// Gestion des Dur�e
clWLangage.WDDuree = (function()
{
	"use strict";
	var __WDDuree = function __WDDuree(oValeurInitialeWL)
	{
		// GP 22/10/2014 : Sauf que l'on ne recoit pas forc�ment de param�tres en construction
//		// Si on est pas dans l'init d'un protoype
//		if (arguments.length)
//		{
			// La valeur est un nombre de millisecondes
			this.m_nValeur = 0;
			if (undefined !== oValeurInitialeWL)
			{
				this.SetValeur(oValeurInitialeWL);
			}
//		}
	};

	// Faire d�river de WDTypeAvance ?

	// Surcharge toString pour avoir une conversion simple en chaine
	__WDDuree.prototype.toString = function toString(/*nBase*/)
	{
		return clWLangage.__sDureeVersChaine(this, "+JHHMMSSLLL");
	};
	//__WDDuree.prototype.valueOf = __WDDuree.prototype.toString;
	// GP 09/11/2016 : Ajout de toJSON
	__WDDuree.prototype.toJSON = __WDDuree.prototype.toString;

	// Acc�s depuis le WL

	// Addition entre deux dur�es
	__WDDuree.prototype.oAdditionDuree = function oAdditionDuree(oDuree)
	{
		return new __WDDuree(this.m_nValeur + oDuree.m_nValeur);
	};
	// Addition entre une dur�e et un entier
	__WDDuree.prototype.oAdditionEntier = function oAdditionEntier(nEntier)
	{
		return new __WDDuree(this.m_nValeur + nEntier);
	};

	// Diff�rence entre deux Duree et une Duree : effectue this - oDuree
	__WDDuree.prototype.oSoustractionDuree = function oSoustractionDuree(oDuree)
	{
		return new __WDDuree(this.m_nValeur - oDuree.m_nValeur);
	};

	// Multiplication entre une dur�e et un nombre (entier ou r�el) : retourne une dur�e
	__WDDuree.prototype.oMultiplicationNombre = function oMultiplicationNombre(fNombre)
	{
		return new __WDDuree(this.m_nValeur * fNombre);
	};

	// Division entre une dur�e et une dur�e ! retourne un r�el
	__WDDuree.prototype.fDivisionDuree = function fDivisionDuree(oDuree)
	{
		return this.m_nValeur / oDuree.m_nValeur;
	};

	// Division entre une dur�e et un nombre : retourne une dur�e
	__WDDuree.prototype.oDivisionNombre = function oDivisionNombre(fNombre)
	{
		return new __WDDuree(this.m_nValeur / fNombre);
	};

	// Lire une propriete
	__WDDuree.prototype.GetProp = function GetProp(nPropriete)
	{
		// Factoriser comme dans SetProp
		// Et factoriser le switch ?

		switch (nPropriete)
		{
		case 2:
			// ..Jour
			return this.__GetPropComposante(0);
		case 3:
			// ..Heure
			return this.__GetPropComposante(1);
		case 4:
			// ..Minute
			return this.__GetPropComposante(2);
		case 5:
			// ..Seconde
			return this.__GetPropComposante(3);
		case 6:
			// ..Milliseconde
			return this.__GetPropComposante(4);
		case 28:
			// ..EnJours
			// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
			return this.__GetPropEnComposante(86400000);
		case 29:
			// ..EnHeures
			// 3600000 = 60 * 60 * 1000 = 1 heure en milli�mes de secondes
			return this.__GetPropEnComposante(3600000);
		case 30:
			// ..EnMinutes
			// 60000 = 60 * 1000 = 1 minute en milli�mes de secondes
			return this.__GetPropEnComposante(60000);
		case 31:
			// ..EnSecondes
			// 1000 = 1000 = 1 second en milli�mes de secondes
			return this.__GetPropEnComposante(1000);
		case 32:
			// ..EnMillisecondes
			// m_nValeur est en millisecondes
			return new clWLangage.WDI8(this.m_nValeur);
		default:
			// Autre : erreur ?
			return null;
		}
	};
	__WDDuree.prototype.__GetPropComposante = function __GetPropComposante(nIndice)
	{
		return this.__tabGetDecompose()[nIndice];
	};
	__WDDuree.prototype.__GetPropEnComposante = function __GetPropEnComposante(nDiviseur)
	{
		return (new clWLangage.WDNumerique(this.m_nValeur, 38, 0)).xoDivisionNumerique(new clWLangage.WDNumerique(nDiviseur, 38, 0));
	};

	// Ecrire une propriete
	__WDDuree.prototype.SetProp = function SetProp(nPropriete, oValeur)
	{
		var nIndiceDecomposeRecompose;
		var nUniteEnMilliseconde;

		switch (nPropriete)
		{
		case 2:
			// ..Jour
			nIndiceDecomposeRecompose = 0;
			break;
		case 3:
			// ..Heure
			nIndiceDecomposeRecompose = 1;
			break;
		case 4:
			// ..Minute
			nIndiceDecomposeRecompose = 2;
			break;
		case 5:
			// ..Seconde
			nIndiceDecomposeRecompose = 3;
			break;
		case 6:
			// ..Milliseconde
			nIndiceDecomposeRecompose = 4;
			break;
		case 28:
			// ..EnJours
			// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
			nUniteEnMilliseconde = 86400000;
			break;
		case 29:
			// ..EnHeures
			// 3600000 = 60 * 60 * 1000 = 1 heure en milli�mes de secondes
			nUniteEnMilliseconde = 3600000;
			break;
		case 30:
			// ..EnMinutes
			// 60000 = 60 * 1000 = 1 minute en milli�mes de secondes
			nUniteEnMilliseconde = 60000;
			break;
		case 31:
			// ..EnSecondes
			// 1000 = 1000 = 1 second en milli�mes de secondes
			nUniteEnMilliseconde = 1000;
			break;
		case 32:
			// ..EnMillisecondes
			// Le calcul commun fonctionne aussi
			nUniteEnMilliseconde = 1;
//			this.m_nValeur = nMillisecondes = parseInt(nMillisecondes, 10);
			break;
		default:
			// Autre : erreur ?
			break;
		}

		// Si on est dans les cas ..Prop
		if (undefined !== nIndiceDecomposeRecompose)
		{
			clWDUtil.WDDebug.assert(undefined === nUniteEnMilliseconde);
			var tabDecompose = this.__tabGetDecompose();
			tabDecompose[nIndiceDecomposeRecompose] = parseInt(oValeur, 10);
			// GP 23/10/2014 : QW250420 : On g�re les valeurs positives ou n�gatives. L'id�e est que ..Prop++ (ou -- ou autre) peut faire un overflow qui se r�percute sur les autres valeurs
			this.__Recompose(tabDecompose, false, false);
		}
		else if (undefined !== nUniteEnMilliseconde)
		{
			var dValeur = parseFloat(oValeur) * nUniteEnMilliseconde;
			this.m_nValeur = clWDUtil.nArrondiVersZero(dValeur);
		}
		else
		{
			// Autre : d�j� trait�
		}
	};
	__WDDuree.prototype.SetPropCombine = __WDDuree.prototype.SetProp;

	// Fonction utilitaire : d�compose la dur�e en [ jours, heures, minutes, secondes , millisecondes ]
	__WDDuree.prototype.__tabGetDecompose = function __tabGetDecompose()
	{
		var tabDecompose = [ 0, 0, 0, 0, 0 ];
		var nValeur = this.m_nValeur;

		// Si la valeur est n�gative, Math.floor va vers le bas au lieu de vers le haut : utilisation de nArrondiVersZero
		tabDecompose[4] = nValeur % 1000;
		nValeur = clWDUtil.nArrondiVersZero(nValeur / 1000);
		tabDecompose[3] = nValeur % 60;
		nValeur = clWDUtil.nArrondiVersZero(nValeur / 60);
		tabDecompose[2] = nValeur % 60;
		nValeur = clWDUtil.nArrondiVersZero(nValeur / 60);
		tabDecompose[1] = nValeur % 24;
		nValeur = clWDUtil.nArrondiVersZero(nValeur / 24);
		tabDecompose[0] = nValeur;

		return tabDecompose;
	};
	// Fonction utilitaire : recompose la dur�e depuis [ jours, heures, minutes, secondes , millisecondes ]
	__WDDuree.prototype.__Recompose = function __Recompose(tabDecompose, bInverse, bAvecErreur)
	{
		// V�rifie les valeurs
		if (bAvecErreur)
		{
			if ((tabDecompose[1] < 0) || (24 <= tabDecompose[1]) || (tabDecompose[2] < 0) || (60 <= tabDecompose[2]) || (tabDecompose[3] < 0) || (60 <= tabDecompose[3]) || (tabDecompose[4] < 0) || (1000 <= tabDecompose[4]))
			{
				throw new WDErreur(204);
			}
		}
		// 86400000 = 24 * 60 * 60 * 1000 = 1 jour en milli�mes de secondes
		// 3600000 = 60 * 60 * 1000 = 1 heure en milli�mes de secondes
		// 60000 = 60 * 1000 = 1 minute en milli�mes de secondes
		// 1000 = 1000 = 1 second en milli�mes de secondes
		this.m_nValeur = tabDecompose[0] * 86400000 + tabDecompose[1] * 3600000 + tabDecompose[2] * 60000 + tabDecompose[3] * 1000 + tabDecompose[4];

		if (bInverse)
		{
			this.m_nValeur = -this.m_nValeur;
		}
	};

	// Conversion d'une valeur du WL vers la valeur interne
	__WDDuree.prototype.SetValeur = function SetValeur(oDureeWL)
	{
		var bValide = true;

		switch (typeof oDureeWL)
		{
		case "string":
			bValide = this.__bSetValeurChaine(oDureeWL);
			break;
		case "number":
			bValide = this.__bSetValeurNombre(oDureeWL);
			break;
		case "object":
			switch (clWDUtil.oGetTypeEntendu(oDureeWL))
			{
			case 5: // WLT_UI8
			case 9: // WLT_I8
			case 13: // WLT_DECIMAL
			// oGetTypeEntendu retourne WLT_I8 pour WLT_UIX
//			case 14: // WLT_UIX
				bValide = this.__bSetValeurNombre(oDureeWL.toNumber());
				break;
			default:
				bValide = this.__bSetValeurObjet(oDureeWL);
				break;
			}
			break;
		}

		if (!bValide)
		{
			// Erreur
			throw new WDErreur(204);
		}
	};

	// Conversion d'une valeur chaine du WL vers la valeur interne
	// Retourne si la conversion est r�ussie
	__WDDuree.prototype.__bSetValeurChaine = function __bSetValeurChaine(sDureeWL)
	{
		// Chaine au format "+JHHMMSSLLL"

		// D�tecte le signe au d�but
		sDureeWL += "";
		var bNegatif = false;
		switch (sDureeWL.charAt(0))
		{
		case "+":
			sDureeWL = sDureeWL.substr(1);
			break;
		case "-":
			sDureeWL = sDureeWL.substr(1);
			bNegatif = true;
			break;
		}

		// La valeur doit �tre compos�e de chiffres (le +/- du d�but a �t� d�j� trait�)
		if (parseInt(sDureeWL, 10) != sDureeWL)
		{
			return false;
		}

		// Complete devant pour avoir au moins "JHHMMSSLLL"
		sDureeWL = clWDUtil.sCompleteEntier(sDureeWL, 10);

		// Chaine au format "+JHHMMSSLLL"
		var tabDecompose = [
			parseInt(sDureeWL.substr(0, sDureeWL.length - 9), 10),
			parseInt(sDureeWL.substr(sDureeWL.length - 9, 2), 10),
			parseInt(sDureeWL.substr(sDureeWL.length - 7, 2), 10),
			parseInt(sDureeWL.substr(sDureeWL.length - 5, 2), 10),
			parseInt(sDureeWL.substr(sDureeWL.length - 3), 10)
		];

		this.__Recompose(tabDecompose, bNegatif, true);
		return true;
	};

	// Conversion d'une valeur entier du WL vers la valeur interne
	// Retourne si la conversion est r�ussie
	__WDDuree.prototype.__bSetValeurNombre = function __bSetValeurNombre(nDureeWL)
	{
		this.SetProp(32, nDureeWL);
		return true;
	};

	// Conversion d'une valeur objet du WL vers la valeur interne
	// Retourne si la conversion est r�ussie
	__WDDuree.prototype.__bSetValeurObjet = function __bSetValeurObjet(oDureeWL)
	{
		if (oDureeWL instanceof __WDDuree)
		{
			// On ne filtre pas selon les parties acceptables dans notre objet, elle ne seront jamais lues
			this.m_nValeur = oDureeWL.m_nValeur;
		}
		else
		{
			return false;
		}

		return true;
	};

	return __WDDuree;
})();

//////////////////////////////////////////////////////////////////////////
// Gestion des Num�riques et des mon�taires qui sont des num�riques (23, 6) (24,6 ?) et des entiers sur 8 qui fonctionnent pas au dela de "53bits".

clWLangage.WDNumeriqueBase = (function()
{
	"use strict";
	//////////////////////////////////////////////////////////////////////////
	// Classe utilitaire (priv�e) : WDNumeriqueData
	var WDNumeriqueData = (function()
	{
		// Inutile ? La fonction parente est d�j� en mode strict
//		"use strict";
		var ms_nNbBitsParValeur = 16;
		var ms_nNbOctetsParElement = ms_nNbBitsParValeur / 8;
		var ms_nMaxPourBits = 0xFFFF;
		var ms_nMasquePourDecalageGauche = 0x7FFF;
		var ms_nHighBit = 0x8000;
		var ms_nHighBitIntermediaire = 0x80;
		// Puissance de 10 maximale acceptable par les op�ration sur les entiers (10000 est la division maximale en puissance de 10 qui tient dans 16 bits)
		var ms_nPuissance10Max = 4;

		function __WDNumeriqueData(nNbBitsTotal, bSigne, oValeurInitiale)
		{
			clWDUtil.WDDebug.assert(0 == (nNbBitsTotal % ms_nNbBitsParValeur), "__WDNumeriqueData : Taille invalide");
			this.m_bSigne = bSigne;
			this.m_tabData = new Array(Math.ceil(nNbBitsTotal / ms_nNbBitsParValeur));
			if (undefined !== oValeurInitiale)
			{
				// Copie les donn�es
				this.CopieDepuis(oValeurInitiale);
			}
			else
			{
				this.SetZero();
			}
		};

		//////////////////////////////////////////////////////////////////////////
		// M�thodes g�n�rales

		// Obtient une copie des donn�es
		__WDNumeriqueData.prototype.oGetCopie = function oGetCopie()
		{
			return new __WDNumeriqueData(this.nGetNbBitsTotal(), this.m_bSigne, this);
		};

		// Copie les donn�es
		__WDNumeriqueData.prototype.CopieDepuis = function CopieDepuis(oData, nPrecisionEnOctets)
		{
			var nPrecisionEnElements;
			if (undefined === nPrecisionEnOctets)
			{
				nPrecisionEnElements = oData.m_tabData.length;
			}
			else
			{
				nPrecisionEnElements = Math.floor(nPrecisionEnOctets / ms_nNbOctetsParElement);
			}
			// On a le droit de mettre une "petite" valeur dans une grande
			clWDUtil.WDDebug.assert(nPrecisionEnElements <= this.m_tabData.length, "__WDNumeriqueData : Initialisation avec perte de donn�es");

			// Mais si on place une valeur n�gative plus petite, il faut faire l'extension du signe
			if (oData.bEstNegatif(nPrecisionEnOctets))
			{
				this.SetMoins1();
			}
			else
			{
				this.SetZero();
			}

			// Copie les donn�es
			var nDataMax = Math.min(this.m_tabData.length, nPrecisionEnElements);
			for (var nData = 0; nData < nDataMax; nData++)
			{
				this.m_tabData[nData] = oData.m_tabData[nData];
			}
		};

		// Nombre total de bits de mantisse
		__WDNumeriqueData.prototype.nGetNbBitsTotal = function nGetNbBitsTotal()
		{
			return this.m_tabData.length * ms_nNbBitsParValeur;
		};

		//////////////////////////////////////////////////////////////////////////
		// Operateurs

		// - Addition : addition avec un entier (retourne la retenue finale si on a un d�passement de capacit�)
		__WDNumeriqueData.prototype.nAddEntier = function nAddEntier(nEntier)
		{
			var nRetenue = nEntier;
			for (var nData = 0; nData < this.m_tabData.length; nData++)
			{
				nRetenue = this.__nAffecteAvecRetenue(this.m_tabData[nData] + nRetenue, nData);
			}
			return nRetenue;
		};
		// - Addition : addition avec un autre num�rique (de m�me taille) (retourne la retenue finale si on a un d�passement de capacit�)
		__WDNumeriqueData.prototype.nAddData = function nAddData(oData)
		{
			clWDUtil.WDDebug.assert(this.m_tabData.length == oData.m_tabData.length, "nAddData : Donn�es de longueur diff�rentes");

			var nRetenue = 0;
			for (var nData = 0; nData < this.m_tabData.length; nData++)
			{
				nRetenue = this.__nAffecteAvecRetenue(this.m_tabData[nData] + oData.m_tabData[nData] + nRetenue, nData);
			}
			return nRetenue;
		};

		// - Soustraction : soustraction avec un entier (retourne la retenue finale si on a un d�passement de capacit�)
		__WDNumeriqueData.prototype.nSubEntier = function nSubEntier(nEntier)
		{
			// GP 17/09/2015 : C'est juste au niveau de la retenue ???
			return this.nAddEntier(-nEntier);
		};
		// - Soustraction : soustraction avec un autre num�rique (de m�me taille) (retourne la retenue finale si on a un d�passement de capacit�)
		__WDNumeriqueData.prototype.nSubData = function nSubData(oData)
		{
			clWDUtil.WDDebug.assert(this.m_tabData.length == oData.m_tabData.length, "nSubData : Donn�es de longueur diff�rentes");

			// GP 17/09/2015 : C'est juste au niveau de la retenue ???
			return this.nAddData(oData.oGetCopie().oOpposee());
		};

		// - Multiplication : multiplication par un entier (retourne false si on a un d�passement de capacit�)
		__WDNumeriqueData.prototype.bMulEntier = function bMulEntier(nEntier)
		{
			// Si le nombre est n�gatif, on le passe en positif
			var bNegatif = this.bEstNegatif();
			if (bNegatif)
			{
				this.oOpposee();
			}

			// On effectue l'op�ration
			var nRetenue = 0;
			for (var nData = 0; nData < this.m_tabData.length; nData++)
			{
				nRetenue = this.__nAffecteAvecRetenue(this.m_tabData[nData] * nEntier + nRetenue, nData);
			}

			// GP 30/09/2015 : QW262496 : ce qu'il faut tester est (false == this.bEstNegatif()) :
			// - Le nombre n'�tait pas n�gatif :
			//	- Soit on travaille en non signe : on ne se pr�occupe que de la retenue puisque l'on n'a pas de bit de signe.
			//	=> this.bEstNegatif() ne peut retourner false
			//	- Soit on travaille en signe : on regarde si on n'a pas un overflow sur le bit de signe.
			//	=> this.bEstNegatif() retourne true s'il y a overflow
			// - Le nombre �tait n�gatif :
			//	- Soit on travaille en non signe : impossible
			//	=> this.bEstNegatif() ne peut retourner false
			//	- Soit on travaille en signe : on a passer le nombre en positif, on regarde si on n'a pas un overflow sur le bit de signe.
			//	=> this.bEstNegatif() retourne true s'il y a overflow
			// => Il suffit donc de tester (bNegatif == this.bEstNegatif())
			var bSansDepassement = (0 == nRetenue) && (false == this.bEstNegatif());

			// Si le nombre d'origine �tait n�gatif, on le repasse en n�gatif
			if (bNegatif)
			{
				this.oOpposee();
			}

			// On renvoie le compte-rendu de d�passement
			return bSansDepassement;
		};
		// - Multiplication : multiplication par un autre num�rique (de m�me taille) (retourne le r�sultat sous forme d'une valeur avec la somme des deux longueurs)
		__WDNumeriqueData.prototype.oMulData = function oMulData(oData)
		{
			clWDUtil.WDDebug.assert(this.m_tabData.length == oData.m_tabData.length, "oMulData : Donn�es de longueur diff�rentes");

			// oResultat est initialis� � z�ro
			// this.nGetNbBitsTotal() + oData.nGetNbBitsTotal() est suffissant mais alors on n'est pas sur de pouvoir faire l'appel de oGetMoitie sereinement
			var oResultat = new __WDNumeriqueData(Math.max(this.nGetNbBitsTotal(), oData.nGetNbBitsTotal()) * 2, this.m_bSigne || oData.m_bSigne, undefined);

			// Pour chaque bloc de donn�es de oData
			for (var nDataData = oData.m_tabData.length - 1; 0 <= nDataData; nDataData--)
			{
				var nRetenue = 0;
				var nData;

				// On d�cale le contenu de oResultat (revient a faire une multiplication)
				// Lors du premier appel, logiquement oResultat est a z�ro et cela ne change pas la valeur
				oResultat.m_tabData.unshift(0);
				var nDBG = oResultat.m_tabData.pop();
				clWDUtil.WDDebug.assert(0 == nDBG, "Overflow");

				// Pour chaque bloc de donn�es de this
				for (nData = 0; nData < this.m_tabData.length; nData++)
				{
					// On fait la multiplication avec l'�l�ment courant de pBuff2, avec la retenue et la valeur existante de oResultat
					nRetenue = oResultat.__nAffecteAvecRetenue(this.m_tabData[nData] * oData.m_tabData[nDataData] + nRetenue + oResultat.m_tabData[nData], nData);
				}
				// On s'occuppe de la retenue tant qu'il y en a
				for (; (nData < oResultat.m_tabData.length) && (nRetenue != 0); nData++)
				{
					nRetenue = oResultat.__nAffecteAvecRetenue(nRetenue + oResultat.m_tabData[nData], nData);
				}
				// En r�alit� �a ne doit pas arriver (on a assert de place pour stocker tous les bits)
				clWDUtil.WDDebug.assert(0 == nRetenue, "d�passement");
			}

			return oResultat;
		};
		// - Multiplication : multiplication par une puissance de 10 (retourne false si on a un d�passement de capacit�)
		__WDNumeriqueData.prototype.bMulPuissance10 = function bMulPuissance10(nPuissance)
		{
			var bSansDepassement = true;
			while (0 < nPuissance)
			{
				var nPuissanceMultiplication = Math.min(nPuissance, ms_nPuissance10Max);
				// Si le r�sultat est diff�rent de z�ro c'est que l'on a fait un arrondi
				bSansDepassement = this.bMulEntier(Math.pow(10, nPuissanceMultiplication)) && bSansDepassement;
				nPuissance -= nPuissanceMultiplication;
			}
			return bSansDepassement;
		};
		// - Multiplication : multiplication par la puissance de 10 maximale sans perdre de donn�es. Retourne la puissance utilis� au final
		__WDNumeriqueData.prototype.nMulPuissance10Max = function nMulPuissance10Max()
		{
			// Pour avoir plus de pr�cision, augmente la puissance tant que l'on n'a pas de d�passement de capacit�
			// On ne sort jamais si on est z�ro mais c'est impossible car test� ci dessus.

			// D�but rapide : tant que la cellule de poid le plus fort de stockage des donn�es est vide, on peut faire la multiplication maximale
			var nPuissance10 = 0;
			while (0 == this.m_tabData[this.m_tabData.length - 1])
			{
				this.bMulPuissance10(ms_nPuissance10Max);
				nPuissance10 += ms_nPuissance10Max;
			}

			// Puis travaille par pas de 1
			var oTemp = this.oGetCopie();
			while (true)
			{
				if (oTemp.bMulPuissance10(1))
				{
					nPuissance10++;
					this.CopieDepuis(oTemp);
				}
				else
				{
					break;
				}
			}

			return nPuissance10;
		};

		// - Division : division par un entier (retourne le reste de la division)
		__WDNumeriqueData.prototype.nDivEntier = function nDivEntier(nEntier)
		{
			return this.nDivEntierAvecReste(nEntier, this.bEstNegatif() ? nEntier - 1 : 0);
		};
		__WDNumeriqueData.prototype.nDivEntierAvecReste = function nDivEntierAvecReste(nEntier, nReste)
		{
			for (var nData = this.m_tabData.length - 1; 0 <= nData; nData--)
			{
				var nNum = (nReste << ms_nNbBitsParValeur) + this.m_tabData[nData];
				nReste = nNum % nEntier;
				this.m_tabData[nData] = clWDUtil.nArrondiVersZero(nNum / nEntier);
			}
			return nReste;
		};
		// - Division : division par un autre num�rique (de m�me taille) (this est la somme des deux longueurs) (retourne le reste sous forme d'une valeur avec la longueur du diviseur)
		__WDNumeriqueData.prototype.oDivData = function oDivData(oData)
		{
			clWDUtil.WDDebug.assert(this.m_tabData.length == (2 * oData.m_tabData.length), "oDivData : Donn�es de longueur diff�rentes");

			var oReste = new __WDNumeriqueData(oData.nGetNbBitsTotal(), this.m_bSigne || oData.m_bSigne, undefined);
			var nNbBitsTotal = this.nGetNbBitsTotal();
			// GP 17/09/2015 : OPTIM : ne pas faire le calcul de l'oppos�e � chaque soustraction
			var oDataOpposee = oData.oGetCopie().oOpposee();

			for (var nBit = 0; nBit < nNbBitsTotal; nBit++)
			{
				// D�callage de 1 bit (multiplication par 2) de this et de oReste avec transfert du bit de poid fort de this vers le reste
				oReste.__nUnDecalageGauche(this.__nUnDecalageGauche(0));

				var bSoustractionPossible = true;
				for (var nData = oReste.m_tabData.length - 1; 0 <= nData; nData--)
				{
					if (oReste.m_tabData[nData] > oData.m_tabData[nData])
					{
						break;
					}
					else if (oReste.m_tabData[nData] < oData.m_tabData[nData])
					{
						bSoustractionPossible = false;
						break;
					}
					// Sinon c'est que (oReste.m_tabData[nData] == oData.m_tabData[nData]) => continue au niveau d'avant
				}
				if (bSoustractionPossible)
				{
					// GP 25/09/2015 : OPTIM : on peut faire this.m_tabData[0] += 1 car a cause du d�calage, on est sur d'avoir le bit de poid le plus faible � z�ro.
//					this.nAddEntier(1);
					this.m_tabData[0] += 1;
					// GP 17/09/2015 : OPTIM : ne pas faire le calcul de l'oppos�e � chaque soustraction
//					oReste.nSubData(oData);
					oReste.nAddData(oDataOpposee);
				}
			}
			return oReste;
		};
		// - Division : division par une puissance de 10 (retourne false si on a perdu des donn�es)
		__WDNumeriqueData.prototype.bDivPuissance10 = function bDivPuissance10(nPuissance)
		{
			var bSansArrondi = true;
			while (0 < nPuissance)
			{
				var nPuissanceDivision = Math.min(nPuissance, ms_nPuissance10Max);
				// Si le r�sultat est diff�rent de z�ro c'est que l'on a fait un arrondi
				bSansArrondi = (0 == this.nDivEntier(Math.pow(10, nPuissanceDivision))) && bSansArrondi;
				nPuissance -= nPuissanceDivision;
			}
			return bSansArrondi;
		};

		//////////////////////////////////////////////////////////////////////////
		// Op�rations sp�cifiques

		// Op�rations sp�cifiques : prend l'oppos�e d'un nombre (retourne this pour permettre le chainage des appels)
		__WDNumeriqueData.prototype.oOpposee = function oOpposee()
		{
			for (var nData = this.m_tabData.length - 1; 0 <= nData; nData--)
			{
				this.m_tabData[nData] ^= ms_nMaxPourBits;
			}
			this.nAddEntier(1);
			// Retourne this (permet le chainage)
			return this;
		};

		// Op�rations sp�cifiques : prend la valeur absolue (retourne this pour permettre le chainage des appels)
		__WDNumeriqueData.prototype.oAbsolue = function oAbsolue()
		{
			if (this.bEstNegatif())
			{
				this.oOpposee();
			}
			return this;
		};

		// Op�rations sp�cifiques : place la valeur 0
		__WDNumeriqueData.prototype.SetZero = function SetZero()
		{
			this.__SetValeurUniforme(0);
		};
		// Op�rations sp�cifiques : place la valeur -1
		__WDNumeriqueData.prototype.SetMoins1 = function SetMoins1()
		{
			this.__SetValeurUniforme(ms_nMaxPourBits);
		};

		// Op�rations sp�cifiques : changement d'�chelle (retourne false si on a un d�passement de capacit�)
		__WDNumeriqueData.prototype.bConvert = function bConvert(nEchelleActuelle, nEchelleNouvelle)
		{
			if (nEchelleActuelle == nEchelleNouvelle)
			{
				return true;
			}

			if (nEchelleNouvelle < nEchelleActuelle)
			{
				this.bDivPuissance10(nEchelleActuelle - nEchelleNouvelle);
				// Jamais de d�passement de capacit�
				return true;
			}
			else
			{
				return this.bMulPuissance10(nEchelleNouvelle - nEchelleActuelle);
			}
		};

		// Op�rations sp�cifiques : retourne la moitie du nombre
		__WDNumeriqueData.prototype.oGetMoitie = function oGetMoitie(bPartieDePoidFort)
		{
			clWDUtil.WDDebug.assert(0 == (this.m_tabData.length % 2), "Taille qui n'est pas un multiple de 2");

			// oResultat est initialis� � z�ro
			var oMoitie = this.oGetCopie();
			var nMoitie = Math.floor(oMoitie.m_tabData.length / 2);
			oMoitie.m_tabData.splice(bPartieDePoidFort ? 0 : nMoitie, nMoitie);

			return oMoitie;
		};

		// Op�rations sp�cifiques : place 10^x dans le tableau (retourne this pour permettre le chainage des appels)
		__WDNumeriqueData.prototype.oSet10Puissance = function oSet10Puissance(nPuissance)
		{
			// Comme on g�re des longueurs variables (64 pour les entiers 128 pour les num�riques), on ne peut pas faire l'initialisation en dur.
			this.SetZero();
			// GP 25/09/2015 : OPTIM : on peut faire this.m_tabData[0] += 1 car a cause du SetZero, on est sur d'avoir le bit de poid le plus faible � z�ro.
//			this.nAddEntier(1);
			this.m_tabData[0] += 1;
			this.bMulPuissance10(nPuissance);
//			this.m_tabData[0] = 0;
//			this.m_tabData[1] = 0;
//			this.m_tabData[2] = 0x2240;
//			this.m_tabData[3] = 0x098A;
//			this.m_tabData[4] = 0xC47A;
//			this.m_tabData[5] = 0x5A86;
//			this.m_tabData[6] = 0x4CA8;
//			this.m_tabData[7] = 0x4B3B;
			return this;
		};

		// Op�rations sp�cifiques : r�ajuste la valeur du buffer (retourne la nouvelle echelle)
		// nDecNess : Je n'ai pas reproduis ce probl�me. Ignore le param�tre car on perd un chiffre en pr�cision
		__WDNumeriqueData.prototype.nAjusteEchelle = function nAjusteEchelle(nEchelle, /*nDecNess, */nPrecisionMaximale)
		{
			clWDUtil.WDDebug.assert(0 == (this.m_tabData.length % 2), "Taille qui n'est pas un multiple de 2");

			// Nouvel algo : tant que l'on a des bits au dela de la moitie, on divise
			var nMoitie = Math.floor(this.m_tabData.length / 2);
			for (var nData = this.m_tabData.length - 1; nData >= nMoitie; nData--)
			{
				// On est toujours dans une valeur positive donc on vise la valeur 0.
				while (this.m_tabData[nData] && (0 < nEchelle))
				{
					// Si on n'est pas sur l'�lement � la moitie : division par la valeur maximale
					if (nData > nMoitie)
					{
						this.bDivPuissance10(ms_nPuissance10Max);
						nEchelle -= ms_nPuissance10Max;
					}
					else
					{
						this.bDivPuissance10(1);
						nEchelle--;
					}
				}
			}
			// Si on le bit de poid le plus fort � 1 ce qui est �quivalent a avoir une valeur sign�e, on divise encore une fois.
			// Normalement on a suffissament d'�chelle
			if ((0 != (this.m_tabData[nMoitie - 1] & ms_nHighBit)) && (0 < nEchelle))
			{
				this.bDivPuissance10(1);
				nEchelle--;
			}

			if (nPrecisionMaximale < nEchelle)
			{
				this.bDivPuissance10(nEchelle - nPrecisionMaximale);
				nEchelle = nPrecisionMaximale;
			}

			return nEchelle;
		};

		//////////////////////////////////////////////////////////////////////////
		// Op�rations de test

		// Op�rations de test : indique si la valeur est 0
		__WDNumeriqueData.prototype.bEstZero = function bEstZero()
		{
			return this.__bEstValeurUniforme(0);
		};

		// Op�rations de test : indique si la valeur est -1
		__WDNumeriqueData.prototype.bEstMoins1 = function bEstMoins1()
		{
			return this.__bEstValeurUniforme(ms_nMaxPourBits);
		};

		// Op�rations de test : indique si la valeur est n�gative en testant le bit de poid fort (= de signe) sur un octets particulier
		__WDNumeriqueData.prototype.bEstNegatif = function bEstNegatif(nSurOctet)
		{
			// Jamais n�gatif si on demande sans signe
			if (!this.m_bSigne)
			{
				return false;
			}
			var nMasque = ms_nHighBit;
			if (undefined === nSurOctet)
			{
				nSurOctet = this.m_tabData.length - 1;
			}
			else
			{
				if (0 == (nSurOctet % ms_nNbOctetsParElement))
				{
					nMasque = ms_nHighBitIntermediaire;
				}
				nSurOctet = Math.floor(nSurOctet / ms_nNbOctetsParElement);
			}
			return !!(this.m_tabData[nSurOctet] & nMasque);
		};

		// Op�rations de test : indique si la valeur est paire (on ne tient donc pas compte de la situation des d�cimales)
		__WDNumeriqueData.prototype.bEstPair = function bEstPair()
		{
			// On teste le nombre de poid le plus faible
			return clWDUtil.bEstPair(this.m_tabData[0]);
		};

		// Op�rations de test : taille r�elle n�cessaire pour la valeur contenue
		__WDNumeriqueData.prototype.nGetNeededNbOctets = function nGetNeededNbOctets()
		{
			var nNbOctets = this.m_tabData.length * ms_nNbOctetsParElement;
			var i;

			if (this.bEstNegatif())
			{
				for (i = nNbOctets - 1; 0 <= i; i--)
				{
					var nUneValeur = this.m_tabData[Math.floor(i / ms_nNbOctetsParElement)];
					if (0xFF00 != (nUneValeur & 0xFF00))
					{
						break;
					}
					i--;
					if (0xFF != (nUneValeur & 0xFF))
					{
						break;
					}
				}
				if ((0 == i) || (0 == (this.m_tabData[Math.floor(i / ms_nNbOctetsParElement)] & (0x80 << (16 * (i % 2))))))
				{
					i++;
				}
			}
			else
			{
				for (i = nNbOctets - 1; 0 <= i; i--)
				{
					// Tant qu'on a des 0 : on ne compte pas l'octet
					var nUneValeur = this.m_tabData[Math.floor(i / ms_nNbOctetsParElement)];
					if (0x0000 != (nUneValeur & 0xFF00))
					{
						break;
					}
					i--;
					if (0x00 != (nUneValeur & 0xFF))
					{
						break;
					}
				}
				// Si l'octet commence par 1, le calcul conduisant � ce buffer a �t� fait en valeur ABS, non sign�
				// mais le buffer final doit �tre sign� : il faut donc que le digit de poids le plus fort soit � 0
				if (0 != (this.m_tabData[Math.floor(i / ms_nNbOctetsParElement)] & (0x80 << (16 * (i % 2)))))
				{
					// Ici on compte donc 1 octet � retirer en plus - rien que �a: un octet complet !
					i++;
				}
			}
			// Pour le i-- qui a �t� fait avant l'�valuation du contenu du buffer
			i++;
			return i;
		};

		//////////////////////////////////////////////////////////////////////////
		// Op�rations internes (factorisation de code)
		__WDNumeriqueData.prototype.__SetValeurUniforme = function __SetValeurUniforme(nEntier)
		{
			// Boucle pour le cas ou un jour un objet externe r�f�rence le tableau (tab = [] perd la r�f�rence)
			for (var nData = this.m_tabData.length - 1; 0 <= nData; nData--)
			{
				this.m_tabData[nData] = nEntier;
			}
		};
		__WDNumeriqueData.prototype.__bEstValeurUniforme = function __bEstValeurUniforme(nEntier)
		{
			for (var nData = this.m_tabData.length - 1; 0 <= nData; nData--)
			{
				if (this.m_tabData[nData] != nEntier)
				{
					return false;
				}
			}
			return true;
		};
		__WDNumeriqueData.prototype.__nUnDecalageGauche = function __nUnDecalageGauche(nRetenuePrecedente)
		{
			// Pour chacune des valeurs
			for (var nData = 0; nData < this.m_tabData.length; nData++)
			{
				var nRetenueSuivante = (0 != (this.m_tabData[nData] & ms_nHighBit)) ? 1 : 0;
				this.m_tabData[nData] = ((this.m_tabData[nData] & ms_nMasquePourDecalageGauche) << 1) + nRetenuePrecedente;
				nRetenuePrecedente = nRetenueSuivante;
			}
			return nRetenuePrecedente;
		};

		// Op�rations internes (factorisation de code) : affecte dans un �l�ment du tableau et retourne le d�passement
		__WDNumeriqueData.prototype.__nAffecteAvecRetenue = function __nAffecteAvecRetenue(nValeur, nData)
		{
			this.m_tabData[nData] = nValeur & ms_nMaxPourBits;
			return nValeur >>> ms_nNbBitsParValeur;
		};

		return __WDNumeriqueData;
	})();

	// nEchelle : Nombre de chiffres apr�s la virgules : entre 0 et 38 (c'est une puissance de 10)
	function __WDNumeriqueBase(oValeurInitialeWL, nPrecision, nEchelle, bSigne)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Nombre de chiffres significatifs : entre 0 (1 plus raisonnablement) et 38 (c'est une puissance de 10)
			this.m_nPrecision = nPrecision;
			// Nombre de chiffres apr�s la virgules : entre 0 et 38 (c'est une puissance de 10)
			this.m_nEchelle = nEchelle;
			// Les donn�es dans un tableau
			var oDataInitiale;
			var bValeurInitialeWLEstNumerique = (oValeurInitialeWL instanceof clWLangage.WDNumeriqueBase);
			if ((undefined !== oValeurInitialeWL) && bValeurInitialeWLEstNumerique)
			{
				// On ne re�oit pas forc�ment des donn�es avec le bon signe car dans le cas d'une op�ration entre entiers sans signe le r�sultat est un num�rique marqu� comme avec signe.
//				clWDUtil.WDDebug.assert(this.m_bSigne == oValeurInitialeWL.m_bSigne, "Type de signe invalide");

				// Mise � l'�chelle de la valeur re�ue.
				oDataInitiale = oValeurInitialeWL.m_oData.oGetCopie();
				// Sauf si on est en mode pr�cision "automatique"
				if (0 != nPrecision)
				{
					if (nEchelle < oValeurInitialeWL.m_nEchelle)
					{
						oDataInitiale.bDivPuissance10(oValeurInitialeWL.m_nEchelle - nEchelle);
					}
					else if (oValeurInitialeWL.m_nEchelle < nEchelle)
					{
						oDataInitiale.bMulPuissance10(nEchelle - oValeurInitialeWL.m_nEchelle);
					}
				}
				else
				{
					// Et si on est en pr�cision automatique, prend la pr�cision et l'�chelle re�ue
					this.m_nPrecision = oValeurInitialeWL.m_nPrecision;
					this.m_nEchelle = oValeurInitialeWL.m_nEchelle;
				}
			}
			this.m_oData = new WDNumeriqueData(this.vnGetNbBitsTotal(), bSigne, oDataInitiale);

			if ((undefined !== oValeurInitialeWL) && !bValeurInitialeWLEstNumerique)
			{
				// Code "simple" : passe par une conversion en chaine
				var sValeurInitialeWL;
				switch (typeof oValeurInitialeWL)
				{
				case "boolean":
					sValeurInitialeWL = oValeurInitialeWL ? "1" : "0";
					break;
				default:
					sValeurInitialeWL = oValeurInitialeWL.toString();
					break;
				}
				this.__SetValeurChaine(sValeurInitialeWL);
			}
		}
	};

	// Les classes d�riv�es doivent impl�menter :
	// vnGetNbBitsTotal
	// vnGetPrecisionMaximale
	// vnGetEchelleMaximale

	//////////////////////////////////////////////////////////////////////////
	// Interface publique

	var ms_sBase = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	// Conversion en chaine
	__WDNumeriqueBase.prototype.toString = function toString(nBase)
	{
		nBase = nBase || 10;
		var tabResultat = [];

		// On travaille sur une copie du nombre
		var oDataTemp = this.m_oData.oGetCopie();
		var nEchelle = this.m_nEchelle;
		// Emp�che l'�criture des z�ros inutiles
		var bZero = true;
		// Compteur d'�tapes
		var nCompteur = 0;

		// Cas des nombres entiers : supprime la partie d�cimale
		if (10 != nBase)
		{
			oDataTemp.bDivPuissance10(nEchelle);
			nEchelle = 0;
		}

		// On prend la valeur absolue du buffer (sauf pour les modes binaire)
		if (this.bEstNegatif() && (10 == nBase))
		{
			oDataTemp.oOpposee();
		}

		// Tant qu'on a quelque chose � afficher
		while ((nCompteur <= nEchelle) || (!oDataTemp.bEstZero()))
		{
			// Si on est � l'endroit de la virgule, on la place
			if (nCompteur == nEchelle)
			{
				if (!bZero && (nEchelle != 0))
				{
					tabResultat.push(".");
				}
				// A partir d'ici, tous les z�ros seront utiles
				bZero = false;
			}
			// Remplissage avec les chiffres
			else
			{
				var bDernier = (10 != nBase) && oDataTemp.bEstMoins1();
				var nValeur = oDataTemp.nDivEntier(nBase);
				if ((0 != nValeur) || (!bZero))
				{
					// Ajout du caract�re
					tabResultat.push(ms_sBase.charAt(nValeur));
					bZero = false;
				}

				// Cas du dernier caract�re du mode binaire en n�gatif
				if (bDernier)
				{
					// Si ce n'est pas le seul caract�re
					if (1 < tabResultat.length)
					{
						var sCaractere = tabResultat[tabResultat.length - 2];
						var nCaractere = 0;
						// Si le caract�re pr�c�dent �tait suffisant pour d�terminer le signe (>=nBase/2)
						for (var nCaractere = 0; nCaractere < nBase; nCaractere++)
						{
							if (sCaractere == ms_sBase.charAt(nCaractere))
							{
								if (nBase <= nCaractere * 2)
								{
									// On annule le caract�re qu'on vient de mettre
									tabResultat.pop();
								}
								break;
							}
						}
					}

					// Dans tous les cas on arr�te en fixant tTemp � 0
					oDataTemp.SetZero();
				}
			}
			// On passe au digit suivant (n est incr�ment� � chaque fois qu'on divise par 10 (ou nBase))
			nCompteur++;
		}

		if (10 == nBase)
		{
			// S'il n'y a pas de partie enti�re
			if (nCompteur == nEchelle + 1)
			{
				// On ajoute au moins un 0 devant le '.'
				tabResultat.push("0");
			}

			// Ajoute le signe
			if (this.bEstNegatif())
			{
				tabResultat.push("-");
			}
		}

		// Inverse le r�sultat et conversion en chaine
		tabResultat.reverse();
		return tabResultat.join("");
	};

	__WDNumeriqueBase.prototype.toNumber = function toNumber()
	{
		return parseFloat(this.toString());
	};
	// GP 09/11/2016 : Ajout de toJSON
	__WDNumeriqueBase.prototype.toJSON = __WDNumeriqueBase.prototype.toNumber;

	__WDNumeriqueBase.prototype.bEstEntier = function bEstEntier()
	{
		if (0 == this.m_nEchelle)
		{
			return true;
		}
		else
		{
			// Si on peux faire la division sans perte c'est que l'on est un entier. Comme la virgule est fixe :
			// Avec une virgule est fixe : on a xxxxxx.yyyy avec "this.m_nEchelle" y.
			// Si on divise par 10^this.m_nEchelle, on d�cale le nombre (on garde la virgule fixe mais on l'ignore) : on arrive a xx.xxxx
			// Si on fait ce d�calage sans perte c'est que yyyy �tait des z�ros.
			return this.m_oData.oGetCopie().bDivPuissance10(this.m_nEchelle);
		}
	};

	__WDNumeriqueBase.prototype.bEstNegatif = function bEstNegatif()
	{
		return this.m_oData.bEstNegatif();
	};

	__WDNumeriqueBase.prototype.oAdditionNumerique = function oAdditionNumerique(oValeur)
	{
		// oX pointera vers le d�cimal qui a la plus gros scale (le plus de chiffers derri�re la virgule), oY pointera vers l'autre op�rande
		var oX, oY;
		if (this.m_nEchelle > oValeur.m_nEchelle)
		{
			oX = this;
			oY = oValeur;
		}
		else
		{
			oX = oValeur;
			oY = this;
		}
		var nEchelleMaximale = oX.m_nEchelle;
		var oDataTemp2;

		// On recopie et convertit Y
		var oDataTemp = oY.m_oData.oGetCopie();
		if (!oDataTemp.bConvert(oY.m_nEchelle, nEchelleMaximale))
		{
			// On calcule l'�chelle � utiliser
			nEchelleMaximale = oY.__nGetEchelleMaximale(oX);

			// On reconvertit Y
			oDataTemp = oY.m_oData.oGetCopie();
			oDataTemp.bConvert(oY.m_nEchelle, nEchelleMaximale);

			// On convertit X
			oDataTemp2 = oX.m_oData.oGetCopie();
			oDataTemp2.bConvert(oX.m_nEchelle, nEchelleMaximale);
		}
		else
		{
			// On y ajoute X
			oDataTemp2 = oX.m_oData;
		}

		// On ajoute
		var bNegatif = oDataTemp.bEstNegatif();
		var nRetenue = oDataTemp.nAddData(oDataTemp2);
		// Il y a overflow si on a 2 op�rantes de m�me signe qui donnent un r�sultat de signe diff�rent
		if ((oDataTemp2.bEstNegatif() == bNegatif) && (oDataTemp.bEstNegatif() != bNegatif))
		{
			// Si, comble de la loose, il y a eu un overflow ici
			// On va perdre une unit� de valeur: on divise par 10
			if (0 < nEchelleMaximale)
			{
				nEchelleMaximale--;
				if (0 != oDataTemp.nDivEntierAvecReste(10, nRetenue ? 9 : 0))
				{
					// Informations de perdue
				}
			}
			// Sinon on est dans la merde, on ressort avec l'overflow
		}

		// On recopie le r�sultat dans une nouvelle valeur
		return this.__oCreeResultat(oValeur).__oSetData(this.vnGetPrecisionMaximale(), nEchelleMaximale, oDataTemp);
	};

	__WDNumeriqueBase.prototype.oSoustractionNumerique = function oSoustractionNumerique(oValeur)
	{
		// Effectue A + (-B)
		// Attention, faire oValeur.m_oData.oOpposee(), l'addition et oValeur.m_oData.oOpposee() est tentant mais c'est faux car si this === oValeur alors on modifie les deux.
		var oValeurCopie;
		if (oValeur instanceof clWLangage.WDI8)
		{
			oValeurCopie = new clWLangage.WDI8(oValeur);
		}
		else if (oValeur instanceof clWLangage.WDUI8)
		{
			oValeurCopie = new clWLangage.WDUI8(oValeur);
		}
		else
		{
			clWDUtil.WDDebug.assert(oValeur instanceof clWLangage.WDNumerique, "Type autre que WDNumerique, WDUI8 ou WDI8");
			// GP 30/09/2015 : QW262496 : Il faut prendre la pr�cision et l'�chelle de oValeur pas de this
			oValeurCopie = new clWLangage.WDNumerique(oValeur, oValeur.m_nPrecision, oValeur.m_nEchelle);
		}
		// Inverse la valeur
		oValeurCopie.m_oData.oOpposee();
		return this.oAdditionNumerique(oValeurCopie);
	};

	__WDNumeriqueBase.prototype.oMultiplicationNumerique = function oMultiplicationNumerique(oValeur)
	{
		var oResultat = this.__oCreeResultat(oValeur);

		// Si A ou B = 0; alors le produit = 0
		if (this.m_oData.bEstZero() || oValeur.m_oData.bEstZero())
		{
			// Ne modifie pas oResultat
		}
		else
		{
			// bNegatif : vrai si le r�sultat est n�gatif
			var bNegatif = this.bEstNegatif() != oValeur.bEstNegatif();

			var oDataAbsA = this.m_oData.oGetCopie().oAbsolue();
			var oDataAbsB = oValeur.m_oData.oGetCopie().oAbsolue();

			// Le r�sultat de oMulData est une valeur deux fois plus longue, on convertit apr�s
			// abs(C) = abs(A) * abs(B)
			var oDataResultat = oDataAbsA.oMulData(oDataAbsB);

			// nDecNess : Je n'ai pas reproduis ce probl�me. Ignore le param�tre car on perd un chiffre en pr�cision
//			// YB 05/05/2010, TB 66404 : Erreur de calcul sur les num�riques
//			//	Le code suivant donne un r�sultat erron�
//			//		v1 est un num�rique = 1
//			//		v2 est un num�rique = 30000
//			//		v3 est un num�rique = (v1/v1)*v2
//			//	Le probl�me provient de la division qui commence par faire une multiplication par 10^38 mais qui ne r�duit pas l'�chelle apr�s l'op�ration
//			//	Dans ce cas, une simple r�duction d'�chelle de 10 suffit � retomber sur nos pattes
//			//	Pour �viter tout risque de r�gression dans la multiplication, je passe la r�duction d'�chelle par d�faut en param�tre
//			//	pour le laisser � 0 pour la multiplication et le passer � 1 pour la division
			var nEchelle = oDataResultat.nAjusteEchelle(this.m_nEchelle + oValeur.m_nEchelle/*, 0*/, this.vnGetPrecisionMaximale());

			oResultat.__oSetData(this.vnGetPrecisionMaximale(), nEchelle, oDataResultat.oGetMoitie(false));
			if (bNegatif)
			{
				oResultat.m_oData.oOpposee();
			}
		}
		return oResultat;
	};

	__WDNumeriqueBase.prototype.xoDivisionNumerique = function xoDivisionNumerique(oValeur)
	{
		// bForceNumerique : force le num�rique pour la division
		var oResultat = this.__oCreeResultat(oValeur, true);

		if (oValeur.m_oData.bEstZero())
		{
			// YB 08/11/2011, TB 73817 : La division avec un diviseur num�rique qui vaut 0 ne provoque pas d'erreur
			// Il faut traiter le cas du diviseur �gal � 0 en premier ici

			// GP 28/10/2017 : QW288820 : Gestion de la division par z�ro
			throw new WDErreur(216);
		}
		else if (this.m_oData.bEstZero())
		{
			// Ne modifie pas oResultat
		}
		else
		{
			// bNegatif : vrai si le r�sultat est n�gatif
			var bNegatif = (this.bEstNegatif() != oValeur.bEstNegatif());

			var oDataAbsA = this.m_oData.oGetCopie().oAbsolue();
			var oDataAbsB = oValeur.m_oData.oGetCopie().oAbsolue();

			// oDataDividendeDecalePuisResultat = abs(A) * 10^x, ou x est le d�calage maximum possible sans perdre de donn�es (permet de conserver le maximum de pr�cision pour la division)
			var oDataDividendeDecalePuisResultat = (new WDNumeriqueData(this.vnGetNbBitsTotal() * 2, oDataAbsA.m_bSigne, oDataAbsA));
			var nPuissance10 = oDataDividendeDecalePuisResultat.nMulPuissance10Max();

			// oDataDividendeDecale = oDataDividendeDecale / abs(B) = abs(A) * 10^PrecisionMax / abs(B)
			// oReste = oDataDividendeDecale % abs(B) = abs(A) * 10^PrecisionMax % abs(B)
			var oReste = oDataDividendeDecalePuisResultat.oDivData(oDataAbsB);

			// nDecNess : Je n'ai pas reproduis ce probl�me. Ignore le param�tre car on perd un chiffre en pr�cision
//			// YB 05/05/2010, TB 66404 : Erreur de calcul sur les num�riques
//			//	Le code suivant donne un r�sultat erron�
//			//		v1 est un num�rique = 1
//			//		v2 est un num�rique = 30000
//			//		v3 est un num�rique = (v1/v1)*v2
//			//	Le probl�me provient de la division qui commence par faire une multiplication par 10^38 mais qui ne r�duit pas l'�chelle apr�s l'op�ration
//			//	Dans ce cas, une simple r�duction d'�chelle de 10 suffit � retomber sur nos pattes
//			//	Pour �viter tout risque de r�gression dans la multiplication, je passe la r�duction d'�chelle par d�faut en param�tre
//			//	pour le laisser � 0 pour la multiplication et le passer � 1 pour la division
			var nEchelle = oDataDividendeDecalePuisResultat.nAjusteEchelle(nPuissance10 + this.m_nEchelle - oValeur.m_nEchelle/*, 1*/, this.vnGetPrecisionMaximale());

			oResultat.__oSetData(this.vnGetPrecisionMaximale(), nEchelle, oDataDividendeDecalePuisResultat.oGetMoitie(false));
			if (bNegatif)
			{
				oResultat.m_oData.oOpposee();
				if (!oReste.bEstZero())
				{
					oResultat.m_oData.nSubEntier(1);
				}
			}
		}
		return oResultat;
	};

	__WDNumeriqueBase.prototype.xoModuloNumerique = function xoModuloNumerique(oValeur)
	{
		var oResultat = this.__oCreeResultat(oValeur);

		if (oValeur.m_oData.bEstZero())
		{
			// YB 08/11/2011, TB 73817 : La division avec un diviseur num�rique qui vaut 0 ne provoque pas d'erreur
			// Il faut traiter le cas du diviseur �gal � 0 en premier ici

			// GP 28/10/2017 : QW288820 : Gestion de la division par z�ro
			throw new WDErreur(216);
		}
		else if (this.m_oData.bEstZero())
		{
			// Ne modifie pas oResultat
		}
		else
		{
			// oDivData divise le buffer temporaire du double de la longueur par la valeur

			// R�gles bas�es sur le modulo WL habituel:
			var bNegatif = this.bEstNegatif();

			// oDataAbsA = abs(A) / 10^A.Scale
			var oDataAbsA = (new WDNumeriqueData(this.vnGetNbBitsTotal() * 2, this.m_oData.m_bSigne, this.m_oData)).oAbsolue();
			oDataAbsA.bDivPuissance10(this.m_nEchelle);

			// oDataAbsB = abs(B) / 10^B.Scale
			var oDataAbsB = (new WDNumeriqueData(this.vnGetNbBitsTotal(), oValeur.m_oData.m_bSigne, oValeur.m_oData)).oAbsolue();
			oDataAbsB.bDivPuissance10(oValeur.m_nEchelle);

			// Reste de la division
			var oReste = oDataAbsA.oDivData(oDataAbsB);

			oResultat.__oSetData(this.vnGetPrecisionMaximale(), 0, oReste);

			// Selon les signes des valeurs de d�part, le r�sultat sera n�gatif
			if (bNegatif)
			{
				oResultat.m_oData.oOpposee();
			}
		}
		return oResultat;
	};

	__WDNumeriqueBase.prototype.oAbsolue = function oAbsolue()
	{
		// Attention : le nPrecision de l'arrondi n'est pas la m�me pr�cision que celle du num�rique. La pr�cision de l'arrondi et plus proche de l'�chelle.
		return this.__oCreeResultat().__oSetData(this.vnGetPrecisionMaximale(), this.m_nEchelle, this.m_oData.oGetCopie().oAbsolue());
	};

	__WDNumeriqueBase.prototype.oArrondi = function oArrondi(nPrecision)
	{
		// Attention : le nPrecision de l'arrondi n'est pas la m�me pr�cision que celle du num�rique. La pr�cision de l'arrondi est plus proche de l'�chelle.
		var oData = this.m_oData.oGetCopie();
		var nEchelleFinale;
		if (nPrecision < this.m_nEchelle)
		{
			// Trop de d�cimales : les supprimes

			// Arrondi en WL serveur fait : -1.9 => -2, -1.5 => -2, -1.1 => -1, 1.1 => 1, 1.5 => 2, 1.9 => 2
			// On fait donc la division avec la d�tection du signe et une utilisation du reste
			oData.oAbsolue();

			if (nPrecision + 1 < this.m_nEchelle)
			{
				// Division pour la partie pour laquelle le reste n'est pas important
				oData.bDivPuissance10(this.m_nEchelle - nPrecision - 1);
			}

			// Derni�re division
			var nReste = oData.nDivEntier(10);
			if (5 <= nReste)
			{
				oData.nAddEntier(1);
			}

			// Et replace la valeur n�gative
			if (this.bEstNegatif())
			{
				oData.oOpposee();
			}
			nEchelleFinale = nPrecision;
		}
		else
		{
			// Si on n'a pas assez de d�cimale : ne rien faire mais il faut quand m�me renvoyer une valeur qui n'est pas this.
			nEchelleFinale = this.m_nEchelle;
		}
		return this.__oCreeResultat().__oSetData(this.vnGetPrecisionMaximale(), nEchelleFinale, oData);
	};

	__WDNumeriqueBase.prototype.nArrondiVersZero = function nArrondiVersZero()
	{
		// Se contente simplement de mettre la pr�cision � z�ro
		var oData = this.m_oData.oGetCopie();
		var bSansArrondi = oData.bDivPuissance10(this.m_nEchelle);
		// Et de corriger le r�sultat de la division
		if (!bSansArrondi && this.bEstNegatif())
		{
			oData.nAddEntier(1);
		}
		return this.__oCreeResultat().__oSetData(this.vnGetPrecisionMaximale(), 0, oData);
	};

	__WDNumeriqueBase.prototype.bEstPair = function bEstPair()
	{
		// GP 30/09/2015 : QW262457 : Un simple nDivEntier(2) ne donne pas le bon r�sultat, cela indique si le dernier chiffre (le moins significatif) est pair
		// Mais rien ne dit que ce chiffre n'est pas dans la partie d�cimale.
//		return (0 == this.m_oData.oGetCopie().nDivEntier(2));
//		return (0 == this.oPartieEntiere().nDivEntier(2));
		return this.oPartieEntiere().m_oData.bEstPair();
	};

	__WDNumeriqueBase.prototype.nLog10Arrondi = function nLog10Arrondi()
	{
		// On suppose que le nombre est strictement sup�rieur � 0.
		var nLog10;

		// Si 1 <= valeur : on fait des divisions par 10
		var oPartieEntiere = this.m_oData.oGetCopie();
		oPartieEntiere.bDivPuissance10(this.m_nEchelle);
		if (oPartieEntiere.bEstZero())
		{
			// La partie enti�re du nombre est 0.
			// On a donc un nombre de la forme 0,xyz
			// => On le multiple par 10 jusqu'a avoir une partie entiere
			nLog10 = 0;
			do
			{
				nLog10--;
				oPartieEntiere = this.m_oData.oGetCopie();
				oPartieEntiere.bDivPuissance10(this.m_nEchelle - (-nLog10));

			} while (oPartieEntiere.bEstZero());
		}
		else
		{
			// La partie enti�re du nombre n'est pas z�ro.
			// On a donc un nombre de la forme abc,xyz
			// => On divise par 10 qu'a ne plus rien avoir
			nLog10 = -1;
			// -1 : on va faire une division de trop. Et comme on a tester le cas oPartieEntiere.bEstZero(), on sait que l'on entre au moins une fois dans la boucle
			while (!oPartieEntiere.bEstZero())
			{
				oPartieEntiere.bDivPuissance10(1);
				nLog10++;
			}
		}

		return nLog10;
	};

	__WDNumeriqueBase.prototype.oPartieEntiere = function oPartieEntiere()
	{
		// Attention, la partie enti�re d'un nombre n�gatif est le nombre n�gatif en dessous : PartieEntiere(-1.2) => -2

		// Se contente simplement de mettre la pr�cision � z�ro et de d�tecter le cas nombre n�gatif avec retenue
		var oData = this.m_oData.oGetCopie();
		oData.bDivPuissance10(this.m_nEchelle);
		return this.__oCreeResultat().__oSetData(this.vnGetPrecisionMaximale(), 0, oData);
	};

	//////////////////////////////////////////////////////////////////////////
	// M�thodes internes

	// Retourne un objet pour le r�sultat
	// bForceNumerique : force le num�rique pour la division
	__WDNumeriqueBase.prototype.__oCreeResultat = function __oCreeResultat(oValeur, bForceNumerique)
	{
		if (bForceNumerique || (this instanceof clWLangage.WDNumerique) || (oValeur && (oValeur instanceof clWLangage.WDNumerique)))
		{
			// Si une des deux valeurs est un num�rique => Numerique
			// Normalement le cast lors de l'appel fait que l'on effectivement deux num�riques
			clWDUtil.WDDebug.assert(bForceNumerique || ((this instanceof clWLangage.WDNumerique) && ((!oValeur) || (oValeur instanceof clWLangage.WDNumerique))), "Si on a un numerique, l'autre l'est aussi");
			return new clWLangage.WDNumerique(undefined, 0, 0);
		}
		else if ((this instanceof clWLangage.WDI8) || (oValeur && (oValeur instanceof clWLangage.WDI8)))
		{
			// Si une des deux valeurs est un entier sign� => entier sign� (par compatibilit� avec le WL qui fait int8 * int8 dans un int8 et pas dans un num�rique)
			return new clWLangage.WDI8(undefined);
		}
		else
		{
			clWDUtil.WDDebug.assert((this instanceof clWLangage.WDUI8) && ((!oValeur) || (oValeur instanceof clWLangage.WDUI8)), "Type autre que WDNumerique, WDUI8 ou WDI8");
			return new clWLangage.WDUI8(undefined);
		}
	};

	// Fixe les donn�es en fin de calcul
	__WDNumeriqueBase.prototype.__oSetData = function __oSetData(nPrecision, nEchelle, oData)
	{
		this.__SetPrecision(nPrecision);
		var nPerteEchelle = this.__nSetEchelle(nEchelle);
		if (this.vnGetPrecisionMaximale() == this.m_nPrecision)
		{
			// Copie les donn�es.
			this.m_oData.CopieDepuis(oData);
		}
		else if (0 < this.m_nPrecision)
		{
			// Copie jusqu'a la pr�cision
			this.m_oData.CopieDepuis(oData, Math.ceil(this.m_nPrecision / (8 * Math.LOG10E / Math.LOG2E)));
		}
		else
		{
			this.m_oData.SetZero();
		}

		var bDBG = this.m_oData.bDivPuissance10(nPerteEchelle);
		clWDUtil.WDDebug.assert(bDBG, "Perte de donn�es");

		// Retourne this (permet le chainage)
		return this;
	};

	// Fixer la pr�cision (manipuler avec pr�caution)
	__WDNumeriqueBase.prototype.__SetPrecision = function __SetPrecision(nPrecision)
	{
		clWDUtil.WDDebug.assert((0 <= nPrecision) && (nPrecision <= this.vnGetPrecisionMaximale()), "Pr�cision invalide : " + nPrecision);
		this.m_nPrecision = nPrecision;
	};
	// Fixer l'�chelle (manipuler avec pr�caution) (retourne le d�calage a faire sur les donn�es)
	__WDNumeriqueBase.prototype.__nSetEchelle = function __nSetEchelle(nEchelle)
	{
		return this.__nSetEchelleAvecMax(nEchelle, this.vnGetEchelleMaximale());
	};

	__WDNumeriqueBase.prototype.__nSetEchelleAvecMax = function __nSetEchelleAvecMax(nEchelle, nEchelleMaximale)
	{
		clWDUtil.WDDebug.assert((0 <= nEchelle) && (nEchelle <= this.vnGetPrecisionMaximale()), "Pr�cision invalide : " + nEchelle);

		var nPerteEchelle = 0;

		if (nEchelleMaximale < nEchelle)
		{
			// Il faut alors modifier la valeur
			nPerteEchelle = nEchelle - nEchelleMaximale;
			nEchelle = nEchelleMaximale;
		}

		if (this.m_nPrecision < nEchelle)
		{
			this.__SetPrecision(nEchelle);
		}
		this.m_nEchelle = nEchelle;

		return nPerteEchelle;
	};

	// Calcule l'�chelle maximale utilisable sans perte de pr�cision
	__WDNumeriqueBase.prototype.__nGetEchelleMaximale = function __nGetEchelleMaximale(oReference)
	{
		// L'�chelle de r�f�rence doit forc�ment �tre sup�rieure
		clWDUtil.WDDebug.assert(this.m_nEchelle < oReference.m_nEchelle, "__nGetEchelleMaximale");
		// YB 06/01/2009, TB 59657 : certaines op�rations aux limites des �chelles donnaient des r�sultats erron�s
		//		n1 est un num�rique (5,33)
		//		n2 est un num�rique (2,36) = 1
		//		n1 = 339
		//		Trace(n1+n2)	// -> OK
		//		n1 = 340
		//		Trace(n1+n2)	// -> erreur de calcul
		//		n1 = 664
		//		Trace(n1+n2)	// -> erreur de calcul
		//		n1 = 665
		//		Trace(n1+n2)	// -> OK
		// Il vaut �videment mieux risquer de perdre un peu plus de pr�cision sur les d�cimales que d'avoir un r�sultat faux
		// On utilise donc ici s_nGetPrecisionMinPourNOctet() plut�t que s_nGetPrecisionMaxDansNOctet()
		var nEchelleMax = this.m_nEchelle + this.vnGetPrecisionMaximale() - __s_nGetPrecisionMinPourNOctet(this.m_oData.nGetNeededNbOctets());
		// YB 06/01/2009 : qui � faire la correction pour la fiche TB 59657, je blinde le cas pour essayer d'avoir le meilleur r�sultat possible
		if (nEchelleMax < this.m_nEchelle)
		{
			nEchelleMax = this.m_nEchelle;
		}
		// L'�chelle � utiliser doit abosulument �tre strictement inf�rieure � l'�chelle la plus gande (pclReference)
		clWDUtil.WDDebug.assert(nEchelleMax < oReference.m_nEchelle, "Perte de precision sur la partie entiere : GRAVE");
		// YB 06/01/2009 : qui � faire la correction pour la fiche TB 59657, je blinde le cas pour �viter les r�sultats erron�s
		if (oReference.m_nEchelle <= nEchelleMax)
		{
			nEchelleMax = oReference.m_nEchelle - 1;
		}

		// On renvoie l'�chelle calcul�e
		return Math.min(nEchelleMax, this.vnGetEchelleMaximale());
	};
	// Renvoie le nombre de chiffres significatifs (pr�cision) n�cessaire pour �crire tout nombre cod� sur N octet
	//	ex : 2 octets -> 32767 -> 5
	var ms_tabNToP_Signe = [0, 2, 4, 6, 9, 11, 14, 16, 18, 21, 23, 26, 28, 31, 33, 35, 38];
	function __s_nGetPrecisionMinPourNOctet(nNbOctets)
	{
		clWDUtil.WDDebug.assert(nNbOctets <= 16);
		return ms_tabNToP_Signe[nNbOctets] + 1;
	};

	// Conversion d'une valeur du WL vers la valeur interne
	__WDNumeriqueBase.prototype.__SetValeurChaine = function __SetValeurChaine(sValeurWL)
	{
		// Code "simple" : passe par une conversion en chaine
		var nPositionDansChaine = 0;
		var nCharCode0 = "0".charCodeAt(0);
		var bValNegatif = false;
		var nPrecision = 0;
		var nEchelle = 0;

		// Supprime tous les espaces de la chaine
		sValeurWL = sValeurWL.replace(/\s/g, "");

		// On commence par chercher le signe dans la cha�ne
		switch (sValeurWL.charAt(nPositionDansChaine))
		{
		case "-":
			bValNegatif = true;
			// Pas de break;
		case "+":
			nPositionDansChaine++;
			break;
		}

		// On traite la partie enti�re
		while (true)
		{
			var nChiffre = sValeurWL.charCodeAt(nPositionDansChaine) - nCharCode0;
			if (isNaN(nChiffre) || (nChiffre < 0) || (9 < nChiffre))
			{
				break;
			}
			this.m_oData.bMulPuissance10(1);
			this.m_oData.nAddEntier(nChiffre);
			nPrecision++;

			nPositionDansChaine++;
		}

		// Est-ce qu'on a une partie d�cimale ?
		switch (sValeurWL.charAt(nPositionDansChaine))
		{
		case ".":
		case ",":
			nPositionDansChaine++;
			// On traite la partie d�cimale
			while (true)
			{
				var nChiffre = sValeurWL.charCodeAt(nPositionDansChaine) - nCharCode0;
				if (isNaN(nChiffre) || (nChiffre < 0) || (9 < nChiffre))
				{
					break;
				}
				// Ignore la partie d�cimale au dela de l'�chelle maximale (en partie sur les entiers ou l'�chelle maximale est de z�ro)
				if (nEchelle < this.vnGetEchelleMaximale())
				{
					this.m_oData.bMulPuissance10(1);
					this.m_oData.nAddEntier(nChiffre);
					nPrecision++;
					nEchelle++;
				}

				nPositionDansChaine++;
			}
			break;
		}

		// GP 23/09/2015 : Calcule la pr�cision demand�e
		var nPrecisionMaximaleAutorise = this.vnGetPrecisionMaximale();
		var nEchelleMaximale = nPrecisionMaximaleAutorise;
		// 0 = pr�cision automatique
		if (0 < this.m_nPrecision)
		{
			nPrecisionMaximaleAutorise = Math.min(nPrecisionMaximaleAutorise, this.m_nPrecision);
			nEchelleMaximale = this.m_nEchelle;
		}
		else if (0 < this.m_nEchelle)
		{
			nEchelleMaximale = this.m_nEchelle;
		}
		// Si la pr�cision est trop importante, on la r�duit
		if (nPrecisionMaximaleAutorise < nPrecision)
		{
			nPrecision = nPrecisionMaximaleAutorise;
		}

		if (nPrecisionMaximaleAutorise < nEchelle)
		{
			this.m_oData.bDivPuissance10(nEchelle - nPrecisionMaximaleAutorise);
			nEchelle = nPrecisionMaximaleAutorise;
		}

		// Est-ce qu'on a une partie exponentielle ?
		switch (sValeurWL.charAt(nPositionDansChaine))
		{
		case "D":
		case "E":
		case "d":
		case "e":
			nPositionDansChaine++;
			// On cherche le signe de l'exponentielle
			var bExpNegatif = false;
			switch (sValeurWL.charAt(nPositionDansChaine))
			{
			case "-":
				bExpNegatif = true;
				// Pas de break;
			case "+":
				nPositionDansChaine++;
				break;
			}

			// On traite l'exposant
			var nExposant = 0;
			while (true)
			{
				var nChiffre = sValeurWL.charCodeAt(nPositionDansChaine) - nCharCode0;
				if (isNaN(nChiffre) || (nChiffre < 0) || (9 < nChiffre))
				{
					break;
				}
				nExposant *= 10;
				nExposant += nChiffre;
				nPositionDansChaine++;
			}
			// Gestion de this.vnGetEchelleMaximale() per __nSetEchelle + bDivPuissance10
			// Est-ce que l'exposant est n�gatif
			if (bExpNegatif)
			{
				// On d�termine le nouveau nombre de d�cimales
				nEchelle += nExposant;
				// Si le nombre de d�cimales d�passe nPrecisionMaximaleAutorise, on s'arr�te � nPrecisionMaximaleAutorise
				if (nPrecisionMaximaleAutorise < nEchelle)
				{
					nEchelle = nPrecisionMaximaleAutorise;
				}
				// Si le nombre de d�cimales d�passe la pr�cision, on adapte la pr�cision
				if (nPrecision < nEchelle)
				{
					nPrecision = nEchelle;
				}
			}
			else
			{
				// Si l'exponentielle est plus grande que le nombre de d�cimal
				if (nEchelle < nExposant)
				{
					// On adapte la pr�cision
					nPrecision += nExposant - nEchelle;
					// Si la pr�cision est trop importante, on la r�duit
					if (nPrecisionMaximaleAutorise < nPrecision)
					{
						nPrecision = nPrecisionMaximaleAutorise;
					}
					// On multiplie le contenu en cons�quence
					this.m_oData.bMulPuissance10(nExposant - nEchelle);
					// Plus de d�cimales
					nEchelle = 0;
				}
				else
				{
					// On r�duit l'�chelle
					nEchelle -= nExposant;
				}
			}
			break;
		}

		// On renseigne la pr�cision et l'�chelle
		this.__SetPrecision(nPrecision);
		var bDBG = this.m_oData.bDivPuissance10(this.__nSetEchelleAvecMax(nEchelle, nEchelleMaximale));
		clWDUtil.WDDebug.assert(bDBG, "Perte de donn�es");

		// Si le nombre est n�gatif, on prend son oppos�
		if (bValNegatif)
		{
			this.m_oData.oOpposee();
		}
	};

	return __WDNumeriqueBase;
})();

clWLangage.WDNumerique = (function()
{
	"use strict";
	function __WDNumerique(oValeurInitialeWL, nPrecision, nEchelle)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel de la classe de base
			clWLangage.WDNumeriqueBase.prototype.constructor.apply(this, [oValeurInitialeWL, nPrecision, nEchelle, true]);
		}
	};
	// Declare l'heritage
	__WDNumerique.prototype = new clWLangage.WDNumeriqueBase();
	// Surcharge le constructeur qui a ete efface
	__WDNumerique.prototype.constructor = __WDNumerique;

	// Les classes d�riv�es doivent impl�menter :
	__WDNumerique.prototype.vnGetNbBitsTotal = function vnGetNbBitsTotal()
	{
		return 128;
	};
	__WDNumerique.prototype.vnGetPrecisionMaximale = function vnGetPrecisionMaximale()
	{
		return 38;
	};
	__WDNumerique.prototype.vnGetEchelleMaximale = function vnGetEchelleMaximale()
	{
		return 38;
	};

	return __WDNumerique;
})();

clWLangage.WDI8Base = (function()
{
	"use strict";
	function __WDI8Base(oValeurInitialeWL, bSigne)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel de la classe de base
			clWLangage.WDNumeriqueBase.prototype.constructor.apply(this, [oValeurInitialeWL, 19, 0, bSigne]);
		}
	};
	// Declare l'heritage
	__WDI8Base.prototype = new clWLangage.WDNumeriqueBase();
	// Surcharge le constructeur qui a ete efface
	__WDI8Base.prototype.constructor = __WDI8Base;

	// Les classes d�riv�es doivent impl�menter :
	__WDI8Base.prototype.vnGetNbBitsTotal = function vnGetNbBitsTotal()
	{
		return 64;
	};
	__WDI8Base.prototype.vnGetPrecisionMaximale = function vnGetPrecisionMaximale()
	{
		return 19;
	};
	__WDI8Base.prototype.vnGetEchelleMaximale = function vnGetEchelleMaximale()
	{
		return 0;
	};

	return __WDI8Base;
})();


clWLangage.WDI8 = (function()
{
	"use strict";
	function __WDI8(oValeurInitialeWL)
	{
		// On ne recoit pas forc�ment de param�tres en construction
//		// Si on est pas dans l'init d'un protoype
//		if (arguments.length)
//		{
			// Appel de la classe de base
			clWLangage.WDI8Base.prototype.constructor.apply(this, [oValeurInitialeWL, true]);
//		}
	};
	// Declare l'heritage
	__WDI8.prototype = new clWLangage.WDI8Base();
	// Surcharge le constructeur qui a ete efface
	__WDI8.prototype.constructor = __WDI8;

	return __WDI8;
})();

clWLangage.WDUI8 = (function()
{
	"use strict";
	function __WDUI8(oValeurInitialeWL)
	{
		// On ne recoit pas forc�ment de param�tres en construction
//		// Si on est pas dans l'init d'un protoype
//		if (arguments.length)
//		{
			// Appel de la classe de base
			clWLangage.WDI8Base.prototype.constructor.apply(this, [oValeurInitialeWL, false]);
//		}
	};
	// Declare l'heritage
	__WDUI8.prototype = new clWLangage.WDI8Base();
	// Surcharge le constructeur qui a ete efface
	__WDUI8.prototype.constructor = __WDUI8;

	return __WDUI8;
})();


clWLangage.nDateVersJour = function nDateVersJour(oDate)
{
    return this.nEntierVersJour(this.nDateVersEntier(oDate));
};

clWLangage.sDateVersJourEnLettre = function sDateVersJourEnLettre(oDate)
{
	var sJourEnLettre = this.sEntierVersJourEnLettres(this.nDateVersEntier(oDate));
	return sJourEnLettre.toLowerCase();
};

clWLangage.sDateVersMoisEnLettre = function sDateVersMoisEnLettre(oDate)
{
    var sMoisEnLettre = this.nEntierVersMoisEnLettres(this.nDateVersEntier(oDate));
	return sMoisEnLettre.toLowerCase();
};

clWLangage.nDateVersNumeroDeSemaine = function nDateVersNumeroDeSemaine(oDate)
{
    return this.nNumeroDeSemaine(oDate);
};

clWLangage.sDernierJourDeLaSemaine = function sDernierJourDeLaSemaine(oDate)
{
	var nJourEntier = this.nDateVersEntier(oDate);
	var nJourSemaine = (nJourEntier + 657071) % 7;

	// jour de la semaine ?
	// (0 = dimanche, 1=Lundi, ...)
	if(nJourSemaine === 0) 
	{
		nJourSemaine = 7;
	}

	// on renvoie le lundi   (toujours inf�rieur ou �gal la date courante)
	return this.sEntierVersDate(nJourEntier + 7 - nJourSemaine);
};

clWLangage.sPremierJourDeLaSemaine = function sPremierJourDeLaSemaine(oDate)
{
	var nJourEntier = this.nDateVersEntier(oDate);
	var nJourSemaine = (nJourEntier + 657071) % 7;

	// jour de la semaine ?
	// (0 = dimanche, 1=Lundi, ...)
	if (nJourSemaine === 0) 
	{
		nJourSemaine = 7;
	}

	// on renvoie le lundi   (toujours inf�rieur ou �gal la date courante)
	return this.sEntierVersDate(nJourEntier + 1 - nJourSemaine);
};

clWLangage.sPremierJourDeLAnnee = function sPremierJourDeLAnnee(oDate)
{
	// r�cup�ration de l'ann�e
	var nAnnee;

	// Extrait une ann�e d'une date
	// La date peut �ter soit un entier contenant juste l'ann�e
	// soit une chaine de type date heure
	// soit rien du tout, dans ce cas, on prend l'ann�e en cours
	switch (typeof oDate)
	{
		case "number":
			nAnnee = oDate;
			break;

		case "string":
			if (oDate.length >= 4)
			{
				var sAnnee = oDate.substr(0, 4);
				nAnnee = parseInt(sAnnee, 10);
				break;
			}
			// Pas de break :  valeur invalide prend l'ann�e courante.

		case "undefined":
			nAnnee = (new Date()).getFullYear();
			break;

		default:
			nAnnee = this.__xoGetJSFromWL(oDate, true, false).getFullYear();
	}

	// cr�ation de la date au 1er janvier de l'ann�e
	var oDateResultat = new Date();
	oDateResultat.setMonth(0);
	oDateResultat.setDate(1);
	oDateResultat.setFullYear(nAnnee);

	return new (this.WDDateHeure)(true, false, oDateResultat, undefined, false);
};


clWLangage.sPremierJourDuMois = function sPremierJourDuMois(oDate, oMois)
{
	var oDatePremierJour;

	// si la date est de type date heure
	switch (typeof oDate)
	{
		case "number":
			var nMois = parseInt(oMois, 10) - 1;
			if(nMois < 0 || nMois > 11)
			{
				// Erreur WL :
				// "Le mois doit �tre une valeur comprise entre 1 et 12."
				throw new WDErreur(219);
			}
			
			oDatePremierJour = new Date();
			// GP 30/04/2021 : QW337822 : Il faut donner le jours avant le mois, sinon on a le mauvais r�sultat.
			// Explications : on part de la date courante, si on change le mois en premier et que le jour courant n'existe pas dans le mois demand�, le JS passe au premier jours du mois suivant.
			// Cela arrive si on est le 31 et que le mois cible n'a que 30 jours, ou si on est le (29,) 30, 31 et que le mois cible est f�vrier.
			oDatePremierJour.setDate(1);
			oDatePremierJour.setMonth(nMois);
			oDatePremierJour.setFullYear(oDate);
			break;

		case "undefined":
			oDatePremierJour = new Date();
			oDatePremierJour.setDate(1);
			break;

		default:
			oDatePremierJour = this.__xoGetJSFromWL(oDate, true, false);
			oDatePremierJour.setDate(1);
	}

	return new (this.WDDateHeure)(true, false, oDatePremierJour, undefined, false);
};

// Retourne le dernier la date du jour du mois
clWLangage.sDernierJourDuMois = function sDernierJourDuMois(oDate, oMois)
{
	var nAnnee;
	var nMois;
	// si la date est de type date heure
	switch (typeof oDate)
	{
	default:
		var oDateJS = this.__xoGetJSFromWL(oDate, true, false);
		nAnnee = oDateJS.getFullYear();
		nMois = oDateJS.getMonth();
		break;

	case "number":
		nAnnee = oDate;
		nMois = parseInt(oMois, 10) - 1;
		if (nMois < 0 || nMois > 11)
		{
			// Erreur WL :
			// "Le mois doit �tre une valeur comprise entre 1 et 12."
			throw new WDErreur(219);
		}
		break;
	}

	var nJour;
	// pour le mois de f�vrier des ann�es bissextiles
	if (nMois === 1 && this.bAnneeBissextile(nAnnee))
	{
		nJour = 29;
	}
	// pour les autrs mois
	else
	{
		nJour = this.ms_tabNbJoursDansMois[nMois];
	}

	// construit la date finale
	var oDateDernierJour = new Date();
	oDateDernierJour.setFullYear(nAnnee);
	oDateDernierJour.setMonth(nMois);
	oDateDernierJour.setDate(nJour);

	return new (this.WDDateHeure)(true, false, oDateDernierJour, undefined, false);
};


clWLangage.sDateHeureSys = function sDateHeureSys()
{
	return clWDUtil.sGetDateHeureWL(new Date(), false, true, true);
};

clWLangage.bDateHeureValide = function bDateHeureValide(oDateHeure)
{
	var sDateHeure = String(oDateHeure);
	if (sDateHeure.length > 16)
	{
		sDateHeure = sDateHeure.substr(0, 16);
	}
	return this.bDateValide(sDateHeure);
};

clWLangage.nMoisEnCours = function nMoisEnCours()
{
	return (new Date()).getMonth() + 1;
};

clWLangage.sNumeroDeMoisVersLettre = function sNumeroDeMoisVersLettre(nNumMois)
{
	return clWDUtil.sGetMois(parseInt(nNumMois, 10) - 1).toLowerCase();
};

clWLangage.sNumeroDeJourVersLettre = function sNumeroDeJourVersLettre(nNumJour)
{
	var nJour = parseInt(nNumJour, 10);
	
	// cas particulier pour le dimande
	switch (nJour)
	{
		case 0:
			return "";
		case 7:
			nJour = 0;
	}
	return clWDUtil.sGetJourSemaine(nJour).toLowerCase();
};

clWLangage.nPoidsFaible = function nPoidsFaible(oValeur)
{
	var nValeur = parseInt(oValeur, 10);
	var nRes = nValeur & 0xFFFF;
	return (nValeur < 0) ? (nRes - 65536) : nRes;
};

clWLangage.nPoidsFort = function nPoidsFort(oValeur)
{
	var nValeur = parseInt(oValeur, 10);
	var nRes = (nValeur >> 16) & 0xFFFF;
	return (nValeur < 0) ? (nRes - 65536) : nRes;
};

clWLangage.nConstruitEntier = function nConstruitEntier(nPoidsFort, nPoidsFaible)
{
	return (parseInt(nPoidsFort, 10) << 16) + this.nPoidsFaible(parseInt(nPoidsFaible, 10));
};

// Fonction WL Factorielle()
clWLangage.Factorielle = function Factorielle(n)
{
	if (n < 0)
	{
		// Erreur WL :
		// "Factorielle d'un nombre n�gatif."
		throw new WDErreur(218);
	}

	if (n <= 1) 
	{
		return 1;
	}

	// 33! = 8683317618811886495518194401280000000
	// => c'est la valeur la plus grande qui rentre dans un num�rique.
	if (n <= 33)
	{
		var oResultat = new this.WDNumerique(n, 38, 0);
		while (1 < --n)
		{
			oResultat = oResultat.oMultiplicationNumerique(new this.WDNumerique(n, 38, 0));
		}
		return oResultat;
	}

	var dResultat = n;
	while (1 < --n)
	{
		dResultat *= n;
	}
	return dResultat;
};

// Fonctions Chronos
(function ()
{
	"use strict";

	var TabChrono = {};	

	// Retourne le num�ro du chrono � utiliser
	function __nGetNumChrono(oNumChrono)
	{
		if (typeof oNumChrono === "number")
		{
			return oNumChrono;
		}

		return 1;
	}
	
	clWLangage.ChronoDebut = function ChronoDebut(oNumChrono)
	{
		// num�ro du chrono
		var nNumChrono = __nGetNumChrono(oNumChrono);

		// initialise un nouvel objet
		var oChronoInfo = {};
		oChronoInfo.oChronoDebut = Date.now();
		oChronoInfo.oChronoDuree = 0;
		oChronoInfo.bEnMarche = true;

		// stocke les infos du chrono
		TabChrono[nNumChrono] = oChronoInfo;
	};

	clWLangage.ChronoFin = function ChronoFin(oNumChrono)
	{
		// num�ro du chrono
		var nNumChrono = __nGetNumChrono(oNumChrono);
		if (TabChrono[nNumChrono] === undefined)
		{
			// Erreur fatale WL :
			// Le Chrono n'est pas d�marr�
			throw new WDErreur(220, nNumChrono);
		}

		// si le chrono est marche, il faut modifier la dur�e
		if (TabChrono[nNumChrono].bEnMarche)
		{
			// calcul de la dur�e
			var oChronoFin = Date.now();
			TabChrono[nNumChrono].oChronoDuree += oChronoFin - TabChrono[nNumChrono].oChronoDebut;

			// stop le chrono mais conserve ses valeurs pour ChronoValeur
			TabChrono[nNumChrono].bEnMarche = false;
		}

		return new (this.WDDuree)(TabChrono[nNumChrono].oChronoDuree);
	};

	clWLangage.ChronoPause = function ChronoPause(oNumChrono)
	{
		return this.ChronoFin(oNumChrono);
	};

	clWLangage.ChronoReprend = function ChronoReprend(oNumChrono)
	{
		// num�ro du chrono
		var nNumChrono = __nGetNumChrono(oNumChrono);
		if (TabChrono[nNumChrono] === undefined)
		{
			// Erreur fatale WL :
			// Le Chrono n'est pas d�marr�
			throw new WDErreur(220, nNumChrono);
		}

		// r�initialise le d�but et relance
		TabChrono[nNumChrono].oChronoDebut = Date.now();
		TabChrono[nNumChrono].bEnMarche = true;
	};

	clWLangage.ChronoRAZ = function ChronoRAZ(oNumChrono)
	{
		this.ChronoDebut(oNumChrono);
	};

	clWLangage.ChronoValeur = function ChronoValeur(oNumChrono)
	{
		// num�ro du chrono
		var nNumChrono = __nGetNumChrono(oNumChrono);
		if (TabChrono[nNumChrono] === undefined)
		{
			// Erreur fatale WL :
			// Le Chrono n'est pas d�marr�
			throw new WDErreur(220, nNumChrono);
		}

		// si le chrono est arret�, retourne la dur�e enregistr�e au moment du ChronoFin
		if (!TabChrono[nNumChrono].bEnMarche)
		{
			return new (this.WDDuree)(TabChrono[nNumChrono].oChronoDuree);
		}
		
		// retourne de la dur�e courante
		var oChronoFin = Date.now();
		return new (this.WDDuree)(TabChrono[nNumChrono].oChronoDuree + oChronoFin - TabChrono[nNumChrono].oChronoDebut);
	};

})();

// Fonctions R�elVersDateHeure() et DateHeureVersR�el()
// Fonctions EpochVersDateHeure() et DateHeureVersEpoch()
(function ()
{
	"use strict";

	// Nombre de jours erreur
	var nNB_JOUR_ERREUR = - 1;
	var nNB_JOUR_29021900_EXCEL = 60;
	// Ann�e de d�part des dates Excel
	var nANNEE_DEPART_DATE_EXCEL = 1900;
	// Num�ro mois f�vrier
	var nMOIS_FEVRIER = 2;
	//Dernier jour de f�vrier en ann�e bissextile
	var nDERNIER_JOUR_FEVRIER_BISSEXTILE = 29;
	// 01/01/1800
	var nBaseNumJour = 657071;

	var MILLI_PAR_SECONDE = 1000;
	var SECONDE_PAR_MINUTE = 60;
	var MINUTE_PAR_HEURE = 60;
	var HEURE_PAR_JOUR = 24;
	var MILLI_PAR_MINUTE = MILLI_PAR_SECONDE * SECONDE_PAR_MINUTE;
	var MILLI_PAR_HEURE = MILLI_PAR_MINUTE * MINUTE_PAR_HEURE;
	var MILLI_PAR_JOUR = MILLI_PAR_HEURE * HEURE_PAR_JOUR;

	// Nombre de jour de chaque mois d'une ann�e non bissextile
	var INITJOURMOIS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
	// Nombre de jour cumul�s depuis le d�but de l'ann�e en d�but de chaque mois
	var INITJOURCUMUL = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

	// Options conversion format Epoch
	var eOptionEpochUnixSeconde = 0x00000000;		//Date-heure en milli-secondes
	var eOptionEpochUnixMilliseconde = 0x00000001;	//Date-heure en secondes

	// V�rificiation de la validit�
	function __bNB_JOUR_DATE_EXCEL_ERREUR(dNbJour, bDepuis1904)
	{
		return (dNbJour < (bDepuis1904 ? 0 : 1));
	};

	// Nombre de jours entre le 01/01/1800 (jour 1 en WLangage) et la date de d�part Excel
	function nNB_JOUR_DATE_DEPART_EXCEL(bDepuis1904)
	{
		return (bDepuis1904 ? 37985 : 36524);
	}

	// Savoir si une ann�e est bissextile
	// Retourne 0 si l'ann�e n'est pas bissextile
	// 1 si elle l'est
	function __bBissextille(nAnnee)
	{
		if (nAnnee % 4)
		{
			return false;
		}
		// la r�gle des si�cle non bisextile � �t� introduite au
		// 16eme si�cle (calendrier gr�gorien)
		if (nAnnee > 1582)
		{
			if (nAnnee % 100)
			{
				return true;
			}
			if (nAnnee % 400)
			{
				return false;
			}
		}
		return true;
	};

	// nombre de jour �coule dans le calendrier par rapport au 1/1/1800.
	// Retourne -1 si echec
	function __nNbJourGregorien(nJour, nMois, nAnnee)
	{
		var nNbrJourMois = INITJOURMOIS;
		var nJourCumule = INITJOURCUMUL;
		var nbDecalageJulien = 0;

		var bi = __bBissextille(nAnnee) ? 1 : 0;
		var bb = nAnnee - 1;

	    var nNbJour=0;
		// avant le 4/11/1582
		// on est sous le r�gne du calendrier Julien.
		if (nAnnee <= 1582 && nMois <= 11 && nJour <= 4)
		{
			// on calcule le d�calage par rapport au calendrier gr�gorien
			// plus 1 jour tous les siecle (sauf 400)
			var nNbSiecle = Math.floor((nAnnee - 1500) / 100); // nombre de siecle (dans le pass�) depuis la fin du calendrier Julien.
			nbDecalageJulien = Math.floor(10 - (nNbSiecle - nNbSiecle / 4));
		}

		if (nAnnee < 0)
		{
			return -1;
		}
		if (nMois < 1 || nMois > 12)
		{
			return -1;
		}
		nNbrJourMois[1] = 28 + bi;
		if (nJour < 1 || nJour > nNbrJourMois[nMois - 1])
		{
			return -1;
		}

		nNbJour = 365 * bb + Math.floor(bb / 4) - Math.floor(bb / 100) + Math.floor(bb / 400) + nJour + nJourCumule[nMois - 1] + (nMois > 2 ? bi : 0) - nBaseNumJour + nbDecalageJulien;
		return nNbJour;
	};

	// Retourne une dat JS
	// En cas d'echec retournr null
	function __NumEnDate(nNumJour)
	{
		var nNbrJourMois = INITJOURMOIS;

		var nAnnee = Math.floor((nNumJour + nBaseNumJour) / 365);
		var h2 = __nNbJourGregorien(1, 1, nAnnee);
		if (h2 === -1)
		{
			return null;
		}

		while (h2 > nNumJour)
		{
			nAnnee--;
			var h2 = __nNbJourGregorien(1, 1, nAnnee);
			if (h2 === -1)
			{
				return null;
			}
		}
		
		var nJour = nNumJour - h2;
		var bi = __bBissextille(nAnnee);
		var nMois = 1;
		var i = 0;
		nNbrJourMois[1] = 28 + bi;
		while (nJour >= nNbrJourMois[i])
		{
			nJour -= nNbrJourMois[i];
			nMois++;
			i++;
		}
		nJour++;

		var oDate = new Date();
		oDate.setFullYear(nAnnee);
		oDate.setMonth(nMois - 1);
		oDate.setDate(nJour);

		return oDate;
	};

	//// Retourne la date sous forme du nombre de millisecondes depuis 01/01/1970 
	//// (c'est le format utilis� par le JS et c'est une valeur interm�diaire pour VersTime32)
	//function __nVersMsDepuis1Janvier1970(oDateHeure)
	//{
	//	// r�cup�re le nombre de jours �coul�s
	//	var nNbJour1 = clWLangage.nDateVersEntier(oDateHeure) - 1;
	//	// calcule le nombre total de millisecondes pour la date 1
	//	var nHeureEnMs = oDateHeure.getMilliseconds() + oDateHeure.getSeconds() * 1000 + oDateHeure.getMinutes() * MILLI_PAR_MINUTE + oDateHeure.getHours() * MILLI_PAR_HEURE;
	//	var nNbMs1 = nNbJour1 * MILLI_PAR_JOUR + nHeureEnMs;
	//	// calcule le nombre total de millisecondes pour la date epoch 01/01/1970
	//	var nNbMs2 = 62092 * MILLI_PAR_JOUR;
	//	// calcule la diff�rence absolue
	//	return (nNbMs1 - nNbMs2);
	//};

	// Fonction WL R�elVersDateHeure()
	clWLangage.ReelVersDateHeure = function ReelVersDateHeure(oValeur, oDepuis1904)
	{
		// param�tres
		var fValeur = parseFloat(String(oValeur));
		var bDepuis1904 = false;
		if (typeof oDepuis1904 === "boolean")
		{
			bDepuis1904 = oDepuis1904;
		}

		// r�sultat
		// nombre de jours Excel erron� ?
		if (__bNB_JOUR_DATE_EXCEL_ERREUR(fValeur, bDepuis1904))
		{
			throw new WDErreur(204);
		}

		// nombre de jours
		var nNbJour = Math.floor(fValeur);

		var oDateResultat;

		// 29/02/1900 sans option depuis 1904 ?
		if ((!bDepuis1904) && (nNbJour == nNB_JOUR_29021900_EXCEL))
		{
			// force jour mois et ann�e car 29/02/1900 pas reconnu en WLangage
			oDateResultat = new Date();
			oDateResultat.setFullYear(nANNEE_DEPART_DATE_EXCEL);
			oDateResultat.setMonth(nMOIS_FEVRIER - 1);
			oDateResultat.setDate(nDERNIER_JOUR_FEVRIER_BISSEXTILE);
		}
		// r�cup�ration jour, mois ann�e OK (si date apr�s le 21/02/1900, on enl�ve 1 jour car 29/02/1900 pas reconnu par Excel mais pas en WLangage) ?
		else
		{
			oDateResultat = __NumEnDate(nNbJour + nNB_JOUR_DATE_DEPART_EXCEL(bDepuis1904) - (((!bDepuis1904) && (nNbJour > nNB_JOUR_29021900_EXCEL)) ? 1 : 0));
			if (oDateResultat === null)
			{
				throw new WDErreur(204);
			}
		}

		// initialise l'heure
		oDateResultat.setHours(0);
		oDateResultat.setMinutes(0);
		oDateResultat.setSeconds(0);
		oDateResultat.setMilliseconds((fValeur - nNbJour) * MILLI_PAR_JOUR);
		var oDateHeureRes = new (this.WDDateHeure)(true, true, oDateResultat, undefined, false);
		return oDateHeureRes;
	};

	// Fonction WL DateHeureVersR�el()
	clWLangage.DateHeureVersReel = function DateHeureVersReel(oDate, oDepuis1904)
	{
		var oDateHeure = this.__xoGetJSFromWL(oDate, true, true);
		var bDepuis1904 = false;
		if (typeof oDepuis1904 === "boolean")
		{
			bDepuis1904 = oDepuis1904;
		}

		// r�sultat
		var fResultat = nNB_JOUR_ERREUR;
		// nombre de jours
		var nNbJour = nNB_JOUR_ERREUR;
		// 29/02/1900 sans option depuis 1904 ?
		if ((!bDepuis1904) && (oDateHeure.getFullYear() == nANNEE_DEPART_DATE_EXCEL) && (oDateHeure.getMonth() + 1 == nMOIS_FEVRIER) && (oDateHeure.getDay() == nDERNIER_JOUR_FEVRIER_BISSEXTILE))
		{
			// renvoie le nombre de jours du 29/02/1900 en Excel (cette date est valide pour Excel mais pas en WLangage)
			return nNB_JOUR_29021900_EXCEL;
		}
		// r�cup�ration nombre jours WLangage OK ?
		nNbJour = this.nDateVersEntier(oDateHeure);
		// enl�ve le nombre de la date de d�part Excel et on ajoute la fraction de jour que repr�sente l'heure
		var nHeureEnMs = oDateHeure.getMilliseconds() + oDateHeure.getSeconds() * 1000 + oDateHeure.getMinutes() * MILLI_PAR_MINUTE + oDateHeure.getHours() * MILLI_PAR_HEURE;
		fResultat = (nNbJour - nNB_JOUR_DATE_DEPART_EXCEL(bDepuis1904)) + (nHeureEnMs / MILLI_PAR_JOUR);
		// date post�rieure au 29/02/1900 sans option depuis 1904 ?
		if ((!bDepuis1904) && ((oDateHeure.getFullYear() > nANNEE_DEPART_DATE_EXCEL) || ((oDateHeure.getFullYear() == nANNEE_DEPART_DATE_EXCEL) && oDateHeure.getMonth() + 1 > nMOIS_FEVRIER)))
		{
			// ajoute 1 au r�sultat car Excel compte le 29/02/1900 contrairement au WLangage
			fResultat++;
		}

		// v�rification
		if (__bNB_JOUR_DATE_EXCEL_ERREUR(fResultat, bDepuis1904))
		{
			//Oui => erreur
			return nNB_JOUR_ERREUR;
		}

		return fResultat;
	};

	// Fonction WL DateHeureVersEpoch(<DateHeure>[,<Options>])
	clWLangage.DateHeureVersEpoch = function DateHeureVersEpoch(oDateHeureWL, oOption)
	{
		// param�tres de la fonction
		var oDateHeure = this.__xoGetJSFromWL(oDateHeureWL, true, true);
		var nOption = eOptionEpochUnixSeconde;
		if (typeof oOption === "number")
		{
			nOption = oOption;
		}

		// r�cup�ration du timestamp
		var timestamp = Date.UTC(
			oDateHeure.getUTCFullYear(),
			oDateHeure.getUTCMonth(),
			oDateHeure.getUTCDate(),
			oDateHeure.getUTCHours(),
			oDateHeure.getUTCMinutes(),
			oDateHeure.getUTCSeconds(),
			oDateHeure.getUTCMilliseconds()
		);

		// calcul du r�sultat selon l'option
		var nRes = 0;
		if ((nOption & eOptionEpochUnixMilliseconde) !== 0)
		{
			nRes = timestamp;
		}
		else
		{
			nRes = Math.floor(timestamp / MILLI_PAR_SECONDE);
		}

		if (nRes < 0)
		{
			return -1;
		}

		return nRes;
	};

	// Fonction WL EpochVersDateHeure(<Date-heure au format Epoch>[,<Options>])
	clWLangage.EpochVersDateHeure = function EpochVersDateHeure(oDateHeureEpoch, oOption)
	{
		// param�tres de la fonction
		var nDateHeureEpoch = parseInt(String(oDateHeureEpoch), 10);
		if (nDateHeureEpoch < 0)
		{
			return "";
		}
		var nOption = eOptionEpochUnixSeconde;
		if (typeof oOption === "number")
		{
			nOption = oOption;
		}

		// date Epoch de d�part
		var nDateEpoch = Date.UTC(1970, 0, 1, 0, 0, 0);
		var oDateHeure = new Date(nDateEpoch);

		// calcul du r�sultat en UTC selon l'option
		if ((nOption & eOptionEpochUnixMilliseconde) !== 0)
		{
			oDateHeure.setUTCMilliseconds(oDateHeure.getMilliseconds() + nDateHeureEpoch);
		}
		else
		{
			oDateHeure.setUTCMilliseconds(oDateHeure.getMilliseconds() + nDateHeureEpoch * MILLI_PAR_SECONDE);
		}

		return new (this.WDDateHeure)(true, true, oDateHeure, undefined, false);
	};
}) ();

// Fonctions DateHeureFuseauVersLocale() et DateHeureLocaleVersFuseau()
(function ()
{
	"use strict";

	// Conversion d'une date locale vers un fuseau horaire
	function __DateHeureLocaleVersFuseau(oDateHeure, oFuseau)
	{
		// conversion en dans l'heure du fuseau demand�
		var oDateHeureFuseau = new Date(oDateHeure.toLocaleString("en-US", { timeZone: String(oFuseau) }));

		// on a perdu les ms, il faut les remettre
		oDateHeureFuseau.setMilliseconds(oDateHeure.getMilliseconds());

		return oDateHeureFuseau;
	}

	// Fonction WL DateHeureFuseauVersLocale(<DateHeure> , <Fuseau>)
	clWLangage.DateHeureFuseauVersLocale = function DateHeureFuseauVersLocale(oDateHeureWL, oFuseau)
	{
		// param�tres de la fonction
		var oDateHeure = this.__xoGetJSFromWL(oDateHeureWL, true, true);

		// conversion en dans l'heure du fuseau demand�
		var oDateHeureFuseau = __DateHeureLocaleVersFuseau(oDateHeure, oFuseau);

		// calcul de l'offset en minutes
		var offsetTimeZone = oDateHeureFuseau - oDateHeure;

		// d�cale l'heure
		oDateHeure.setMilliseconds(oDateHeure.getMilliseconds() - offsetTimeZone);
		return new (this.WDDateHeure)(true, true, oDateHeure, undefined, false);
	};

	// Fonction WL DateHeureLocaleVersFuseau(<DateHeure> , <Fuseau>)
	clWLangage.DateHeureLocaleVersFuseau = function DateHeureLocaleVersFuseau(oDateHeureWL, oFuseau)
	{
		// param�tres de la fonction
		var oDateHeure = this.__xoGetJSFromWL(oDateHeureWL, true, true);

		// conversion en dans l'heure du fuseau demand�
		var oDateHeureFuseau = __DateHeureLocaleVersFuseau(oDateHeure, oFuseau);
		return new (this.WDDateHeure)(true, true, oDateHeureFuseau, undefined, false);
	};
})();

// Fonctions TexteVersHTML()
(function ()
{
	"use strict";

	// Constantes d'encodage des caract�res
	var HTML_NBSP			= "&nbsp;";
	var HTML_QUOTE			= "&quot;";
	var HTML_AMPERSAND		= "&amp;";
	var HTML_LESSTHAN		= "&lt;";
	var HTML_GREATERTHAN	= "&gt;";
	var HTML_TRADEMARK		= "&trade;";
	var HTML_EACUTE			= "&eacute;";
	var HTML_EGRAVE			= "&egrave;";
	var HTML_ECIRC			= "&ecirc;";
	var HTML_CCEDIL			= "&ccedil;";
	var HTML_AGRAVE			= "&agrave;";
	var HTML_UGRAVE			= "&ugrave;";
	var HTML_DEG			= "&deg;";
	var HTML_EURO			= "&euro;";
	var HTML_BR				= "<br />";


	// Conversion des carat�res sp�ciaux HTML
	function __sCaract2Html(sCaract)
	{
		switch (sCaract.charCodeAt(0))
		{
			case 128: return HTML_EURO;
			case 127: return HTML_TRADEMARK;
			case 0xE9: return HTML_EACUTE;
			case 0xE8: return HTML_EGRAVE;
			case 0xEA: return HTML_ECIRC;
			case 0xE7: return HTML_CCEDIL;
			case 0xE0: return HTML_AGRAVE;
			case 0xF9: return HTML_UGRAVE;
			case 0xB0: return HTML_DEG;
			case 0x0D:
			case 0x0A:
			case 11: return HTML_BR;

			default:
				// caract�re sp�cial
				if (sCaract.charCodeAt(0) > 127)
				{
					return "&#" + sCaract.charCodeAt(0).toString() + ";"
				}
		}

		switch (sCaract.charAt(0))
		{
			case '\"': return HTML_QUOTE;
			case '&': return HTML_AMPERSAND;
			case '<': return HTML_LESSTHAN;
			case '>': return HTML_GREATERTHAN;

			default:
				return sCaract;
		}
	}

	// Fonctions WL TexteVersHTML()
	clWLangage.sTexteVersHTML = function sTexteVersHTML(oTexte)
	{
		var sTexte = String(oTexte);
		var sHTML = "";
		var nConsecutiveSpaceNbr = 0;

		// parcours des caract�res
		for (var i = 0; i < sTexte.length; i++)
		{
			// si c'est un espace 
			// et si on a d�j� eu un espace avant ou si le prochain caract�re est un espace,
			if ((sTexte.charAt(i) === ' ') && ((nConsecutiveSpaceNbr > 0) || ((i + 1) < sTexte.length && sTexte.charAt(i + 1) === ' ')))
			{
				// incr�menter le compteur d'espaces successifs
				nConsecutiveSpaceNbr++;
				if ((nConsecutiveSpaceNbr % 2) == 1)
				{
					// il faut convertir le premier espace en espace ins�cable
					sHTML += HTML_NBSP;
				}
				else
				{
					// on ajoute simplement un espace
					sHTML += " ";
				}
			}
			// sinon si on a "\r\n" -> on ne met qu'une seule balise "br"
			else if (sTexte.charCodeAt(i) == 0x0d && (i + 1) < sTexte.length && sTexte.charCodeAt(i + 1) == 0x0a)
			{
				// avaler le '\r' : la balise "br" sera mis au prochain passage dans la boucle pour \n
			}
			else
			{
				// r�initialiser le compteur d'espaces successifs
				nConsecutiveSpaceNbr = 0;

				// convertir le caract�re
				var sCaract = __sCaract2Html(sTexte.charAt(i), true);

				// ajouter le caract�re au texte converti
				sHTML += sCaract;
			}
		}

		return sHTML;
	}
})();

// Fonctions CaractType() et CaractOccurrenceType()
(function ()
{
	"use strict";

	// expression r�guli�re pour trouver les caract�res de ponctuation
	var sERPonctuation = /[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,\-.\/:;<=>?@\[\]^_`{|}~]/g;
	// expression r�guli�re pour trouver les caract�res accentu�s
	// ������������������������������������������������ܟ���������
	var sERAccent = /[\xE0\xE8\xEC\xF2\xF9\xC0\xC8\xCC\xD2\xD9\xE1\xE9\xED\xF3\xFA\xFD\xC1\xC9\xCD\xD3\xDA\xDD\xE2\xEA\xEE\xF4\xFB\xC2\xCA\xCE\xD4\xDB\xE3\xF1\xF5\xC3\xD1\xD5\xE4\xEB\xEF\xF6\xFC\xFF\xC4\xCB\xCF\xD6\xDC\x178\xE7\xC7\xDF\xD8\xF8\xC5\xE5\xC6\xE6\x153]/g;
	//[\u00C0 - \u00FF]
	// expression r�guli�re pour trouver les num�riques
	var sERNumerique = /[0-9]/g;
	//// expression r�guli�re pour trouver les caract�res alphab�tiques
	//var sERAlphabetique = /[a-z]/g;
	//var sEREspace = /\s/g;

	// constantes des fonctions
	var CT_AUCUN = 0x00000000;
	var CT_ESPACE = 0x00000001;
	var CT_PONCTUATION = 0x00000002;
	var CT_NUMERIQUE = 0x00000010;
	var CT_ALPHA = 0x00000100;
	var CT_MINUSCULE = 0x00000200;
	var CT_MAJUSCULE = 0x00000400;
	var CT_ACCENT = 0x00000800;

	// Fonctions WL CaractType()
	clWLangage.nCaractType = function nCaractType(oCaract)
	{
		// r�cup�ration du caract�re
		var sCaract = String(oCaract);
		if (sCaract.length != 1)
		{
			return CT_AUCUN;
		}

		// si c'est un espace
		if (sCaract === " ")
		{
			return CT_ESPACE;
		}

		// si c'est un num�rique
		if (sCaract.replace(sERNumerique, "").length === 0)
		{
			return CT_NUMERIQUE;
		}

		var nRes = CT_AUCUN;

		// si c'est un caract�re alpha majuscule
		if (sCaract.toLowerCase() !== sCaract)
		{
			nRes |= (CT_ALPHA | CT_MAJUSCULE);
		}

		// si c'est un caract�re alpha minuscule
		if (sCaract.toUpperCase() !== sCaract)
		{
			nRes |= (CT_ALPHA | CT_MINUSCULE);
		}

		// si il y a des accents
		if (sCaract.replace(sERAccent, "").length === 0)
		{
			nRes |= (CT_ALPHA | CT_ACCENT);
		}

		// si il y a des caract�res de ponctuation
		if (sCaract.replace(sERPonctuation, "").length === 0)
		{
			nRes |= CT_PONCTUATION;
		}

		return nRes;
	};

	// Fonctions WL CaractType()
	clWLangage.nCaractOccurrenceType = function nCaractOccurrenceType(oChaine, oType)
	{
		// les param�tres
		var sChaine = String(oChaine);
		var nType = parseInt(String(oType), 10);

		// comptage des caract�res
		var nCpt = 0;
		for (var i = 0; i < sChaine.length; i++)
		{
			if ((this.nCaractType(sChaine.charAt(i)) & nType) === nType)
			{
				nCpt++;
			}
		}
		return nCpt;
	};
})();

// Fonction WL Paques()
clWLangage.Paques = function Paques(oAnnee)
{
	// R�cup�ration de l'ann�e
	if ("" === oAnnee)
	{
		return "";
	}
	// GP 05/10/2020 : TB119196 : Il faut faire le substr(0, 4) dans tous les cas.
	var nAnnee = parseInt(String(oAnnee).substr(0, 4), 10);

	//Le calcul suivant n'est valable qu'� partir du calendrier gr�gorien  (15 octobre 1582)
	//On ne g�re pas non plus les date stupides >9999
	if (nAnnee <= 1582 || nAnnee > 9999)
	{
		return "";
	}

	var year2 = nAnnee + 5700000;
	var a = year2 % 19;
	var b = Math.floor(year2 / 100);
	var c = year2 % 100;
	var d = Math.floor(b / 4);
	var e = b % 4;
	var f = Math.floor((b + 8) / 25);
	var g = Math.floor((b - f + 1) / 3);
	var h = (19 * a + b - d - g + 15) % 30;
	var i = Math.floor(c / 4);
	var k = c % 4;
	var l = (32+ e + e + i + i - h - k) % 7;
	var m = Math.floor((a + 11 * h + 22 * l) / 451);
	var tval = h + l - 7 * m + 114;

	var nMois = Math.floor(tval / 31);
	var nJour = Math.floor(tval % 31) + 1;

	// construit la date finale
	var oDate = new Date();
	oDate.setFullYear(nAnnee);
	oDate.setMonth(nMois - 1);
	oDate.setDate(nJour);

	return new (this.WDDateHeure)(true, false, oDate, undefined, false);
}