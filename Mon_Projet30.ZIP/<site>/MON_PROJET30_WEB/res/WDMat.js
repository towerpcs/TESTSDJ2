// WDMat.js
/*! 26.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// !!!! Ne pas mettre d'espace dans les intructions ci dessus. Tous les commentaires sans espaces au début du fichier sont conservées par Typescript !!!!
// Attention a ne pas mettre d'accent dans le code, chaines incluses
///#DEBUG=clWDUtil.WDDebug
///#GLOBALS WDStd NSPCS WDErreur
var WDMat;
(function (WDMat) {
    //Valeur erreur
    var nVALEUR_ERREUR = 0;
    //Paramètre décomposion LU
    var CParamDecompositionLU = /** @class */ (function () {
        // Constructeur
        function CParamDecompositionLU() {
            this.m_clTabIndice = [];
        }
        return CParamDecompositionLU;
    }());
    //Matrice
    var CMatrice = /** @class */ (function () {
        // Constructeur
        //Entrée :	sNom	Nom
        function CMatrice(sNom) {
            if (sNom === void 0) { sNom = ""; }
            this.m_sNom = sNom;
            this.m_nNbLigne = 0;
            this.m_nNbColonne = 0;
            this.m_clContenu = [];
            this.RAZErreur();
        }
        // RAZ erreur
        CMatrice.prototype.RAZErreur = function () {
            this.m_nErreur = WDStd.nERREUR_AUCUNE;
        };
        // Nom
        CMatrice.prototype.sGetNom = function () {
            return this.m_sNom;
        };
        // Modification nom
        CMatrice.prototype.SetNom = function (sNom) {
            this.m_sNom = sNom;
        };
        // Erreur
        CMatrice.prototype.nGetErreur = function () {
            return this.m_nErreur;
        };
        // Modification erreur
        CMatrice.prototype.SetErreur = function (nErreur) {
            this.m_nErreur = nErreur;
        };
        // Nombre de lignes
        CMatrice.prototype.nGetNbLigne = function () {
            return this.m_nNbLigne;
        };
        // Modiifcation nombre de lignes
        CMatrice.prototype.SetNbLigne = function (nNbLigne) {
            this.m_nNbLigne = nNbLigne;
        };
        // Nombre de colonnes
        CMatrice.prototype.nGetNbColonne = function () {
            return this.m_nNbColonne;
        };
        // Modiifcation nombre de colonnes
        CMatrice.prototype.SetNbColonne = function (nNbColonne) {
            this.m_nNbColonne = nNbColonne;
        };
        // Indique si erreur
        // Sortie :	true si erreur, false sinon
        CMatrice.prototype.bErreur = function () {
            //Test erreur
            return WDStd.bErreur(this.m_nErreur);
        };
        // Indique si erreur autre matrice à récupérer
        // Entrée :	pclMatrice	Matrice dont on veut savoir si elle est en erreur
        // Sortie :	true si erreur (on a récupéré l'erreur), false sinon
        CMatrice.prototype.bErreurRecupere = function (pclMatrice) {
            //Matrice à tester OK ?
            if (pclMatrice === undefined) {
                //Non => pas d'erreur
                return false;
            }
            //Erreur ?
            if (pclMatrice.bErreur()) {
                //Oui => on la récupère
                this.m_nErreur = pclMatrice.nGetErreur();
                //Erreur
                return true;
            }
            //Pas d'erreur
            return false;
        };
        // Test erreur
        // Entrée :	bTestErreur	Indique si erreur
        //			eErreur		Erreur à positionner en cas d'erreur
        // Sortie : true si erreur, false sinon
        CMatrice.prototype._bTesteErreur = function (bTestErreur, eErreur) {
            //Erreur ?
            if (bTestErreur) {
                //Oui => positionnemnt erreur
                this.m_nErreur = eErreur;
            }
            //Indique si erreur
            return bTestErreur;
        };
        // Test erreur dimension
        // Entrée :	bTestErreur	Indique si erreur de dimension
        // Sortie : true si erreur, false sinon
        CMatrice.prototype._bTesteErreurDimensions = function (bTestErreur) {
            //Indique si erreur
            return this._bTesteErreur(bTestErreur, 1206 /* eErreurDimension */);
        };
        // Mise à jour dimension pour gérer un indice donné
        // Entrée :	nIndice		Indice désiré dans la dimenson
        //			nDimension	Dimension actuelle de la dimension
        // Sortie :	Dimension de la dimension pour pouvoir gérer l'indice désiré
        CMatrice.prototype._nMajDimension = function (nIndice, nDimension) {
            //La dimension de la dimension est suffisante ?
            if (nIndice >= nDimension) {
                //Non => on agrandit la dimension
                nDimension = nIndice + 1;
            }
            //Dimension permettant de gérer l'indice
            return nDimension;
        };
        // Création d'une ligne (si elle n'existe pas déjà)
        // Entrée :	nIndice	Indice de la ligne à créer
        CMatrice.prototype._CreeLigne = function (nIndice) {
            //La ligne existe ?
            if (this.m_clContenu[nIndice] === undefined) {
                //Non => on la crée
                this.m_clContenu[nIndice] = [];
            }
        };
        // Mise à jour d'un élément dans la matrice
        // Entrée :	nValeur		Valeur de l'élément à intégrer
        //			nLigne		Indice ligne (commence à 0)
        //			nColonne	Indice colonne (commence à 0)
        CMatrice.prototype.MajElem = function (nValeur, nLigne, nColonne) {
            //RAZ erreur
            this.RAZErreur();
            //Création ligne si besoin
            this._CreeLigne(nLigne);
            //Mise à jour nombre de lignes
            this.m_nNbLigne = this._nMajDimension(nLigne, this.m_nNbLigne);
            //Mise à jour nombre de colonnes
            this.m_nNbColonne = this._nMajDimension(nColonne, this.m_nNbColonne);
            //Mise à jour élément
            this.m_clContenu[nLigne][nColonne] = nValeur;
        };
        // Mise à jour d'un élément dans la matrice avec test erreur
        // Entrée :	nValeur		Valeur de l'élément à intégrer
        //			nLigne		Indice ligne (commence à 0)
        //			nColonne	Indice colonne (commence à 0)
        // Sortie : true si mise à jour OK, false en cas d'erreur
        CMatrice.prototype.bMajElem = function (nValeur, nLigne, nColonne) {
            //Mise à jour élément
            this.MajElem(nValeur, nLigne, nColonne);
            //Test erreur
            return !this.bErreur();
        };
        // Indique si un indice est hors bornes
        // Entrée :	nIndice		Indice à tester
        //			nDimension	Dimension de la dimension de l'indice
        // Sortie :	true si l'indice est hors borne, false sinon
        CMatrice.prototype._bIndiceHorsBorne = function (nIndice, nDimension) {
            // Test indice
            return (nIndice < 0) || (nIndice >= nDimension);
        };
        // Valeur d'un élément de la matrice
        // Entrée :	nLigne		Indice ligne (commence à 0)
        //			nColonne	Indice colonne (commence à 0)
        // Sortie :	Valeur de l'élément (valeur erreur en cas d'échec)
        CMatrice.prototype.nValeurElem = function (nLigne, nColonne) {
            //RAZ erreur
            this.RAZErreur();
            //Coordonnées correctes ?
            if (this._bTesteErreur(this._bIndiceHorsBorne(nLigne, this.m_nNbLigne) || this._bIndiceHorsBorne(nColonne, this.m_nNbColonne), 1205 /* eErreurDehors */)) {
                //Non => erreur
                return nVALEUR_ERREUR;
            }
            //Création ligne si nécessaire
            this._CreeLigne(nLigne);
            //Recupération valeur
            var uValeur = this.m_clContenu[nLigne][nColonne];
            //Valeur définie ?
            if (uValeur === undefined) {
                //Non => valeur erreur
                return nVALEUR_ERREUR;
            }
            //Oui => valeur
            return uValeur;
        };
        // Compression
        // Sortie : Copie compressée de la matrice (indéfini en cas d'erreur)
        CMatrice.prototype.pclCompresse = function () {
            //RAZ erreur
            this.RAZErreur();
            //On crée une nouvelle matrice
            var pclNouvMat = new CMatrice(this.m_sNom);
            //Visiteur compression
            var CVisiteurCompression = /** @class */ (function (_super) {
                __extends(CVisiteurCompression, _super);
                function CVisiteurCompression() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                // Visite cellule
                // Sortie :	true pour continuer , false pour l'arrêter
                CVisiteurCompression.prototype._bVisiteCellule = function (nLigne, nColonne) {
                    //Récupération valeur
                    var nValeur = this.m_pclMatrice.nValeurElem(nLigne, nColonne);
                    //Valeur OK ?
                    if (nValeur != nVALEUR_ERREUR) {
                        //Oui => on la recopie dans la nouvelle matrice
                        pclNouvMat.MajElem(nValeur, nLigne, nColonne);
                        //Erreur à récupérer ?
                        if (this.m_pclMatrice.bErreurRecupere(pclNouvMat)) {
                            //Oui => échec
                            pclNouvMat = undefined;
                            //Fin de parcours
                            return false;
                        }
                    }
                    //Le parcours continue
                    return true;
                };
                return CVisiteurCompression;
            }(CVisiteurMatrice));
            //Visisteur compression
            var clVisiteurCompression = new CVisiteurCompression();
            //Compression
            clVisiteurCompression.VisiteMatrice(this);
            //Copie matrice compressée
            return pclNouvMat;
        };
        // Opération avec un réel
        // Entrée :	nValeur	Valeur avec laquelle on effectue l'opération
        CMatrice.prototype.ReelOperation = function (nValeur, eOperation) {
            //RAZ erreur
            this.RAZErreur();
            //Visiteur Opération
            var CVisiteurOperation = /** @class */ (function (_super) {
                __extends(CVisiteurOperation, _super);
                function CVisiteurOperation() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                // Visite cellule
                // Sortie :	true pour continuer , false pour l'arrêter
                CVisiteurOperation.prototype._bVisiteCellule = function (nLigne, nColonne) {
                    //Récupération ancienne valeur
                    var nNouvelleValeur = this.m_pclMatrice.nValeurElem(nLigne, nColonne);
                    //Si l'opération est
                    switch (eOperation) {
                        //Addition :
                        case 0 /* eAddition */:
                            //On ajoute la valeur
                            nNouvelleValeur += nValeur;
                            break;
                        //Multiplication :
                        case 1 /* eMultiplication */:
                            //On multiplie par la valeur
                            nNouvelleValeur *= nValeur;
                            break;
                        //Autre :
                        default:
                            //On arrête le parcours
                            return false;
                    }
                    //Récupération valeur après opération
                    return this.m_pclMatrice.bMajElem(nNouvelleValeur, nLigne, nColonne);
                };
                return CVisiteurOperation;
            }(CVisiteurMatrice));
            //Visisteur opération
            var clVisiteurOperation = new CVisiteurOperation();
            //Opération
            clVisiteurOperation.VisiteMatrice(this);
        };
        // Multiplication par un réel
        // Entrée :	nValeur	Valeur par laquelle on multiplie
        CMatrice.prototype.ReelMultiplie = function (nValeur) {
            //Multiplication
            this.ReelOperation(nValeur, 1 /* eMultiplication */);
        };
        // Addition avec un réel
        // Entrée :	nValeur	Valeur ajoutée
        CMatrice.prototype.ReelAjoute = function (nValeur) {
            //Addition
            this.ReelOperation(nValeur, 0 /* eAddition */);
        };
        // Copie d'une matrice
        // Entrée :	pclMatrice	Matrice à copier
        CMatrice.prototype.Copie = function (pclMatrice) {
            //Matrice à copie OK ?
            if (pclMatrice === undefined) {
                //Non => on sort
                return;
            }
            //RAZ Erreur
            this.RAZErreur();
            //Matrice destination
            var pclMatriceDst = this;
            //Visiteur copie
            var CVisiteurCopie = /** @class */ (function (_super) {
                __extends(CVisiteurCopie, _super);
                function CVisiteurCopie() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                // Visite cellule
                // Sortie :	true pour continuer , false pour l'arrêter
                CVisiteurCopie.prototype._bVisiteCellule = function (nLigne, nColonne) {
                    //Récupération valeur à copier
                    var nValeur = this.m_pclMatrice.nValeurElem(nLigne, nColonne);
                    //Erreur à récupérer ?
                    if (pclMatriceDst.bErreurRecupere(this.m_pclMatrice)) {
                        //Oui => fin de parcours
                        return false;
                    }
                    //Copie valeur
                    return pclMatriceDst.bMajElem(nValeur, nLigne, nColonne);
                };
                return CVisiteurCopie;
            }(CVisiteurMatrice));
            //Visisteur copie
            var clVisiteurCopie = new CVisiteurCopie();
            //Copie
            clVisiteurCopie.VisiteMatrice(pclMatrice);
        };
        // Addition d'une matrice
        // Entrée :	pclMatrice	Matrice ajoutée
        // Sortie : Matrice résultat (indéfini en cas d'erreur)
        CMatrice.prototype.pclAdditionne = function (pclMatrice) {
            //Matrice ajoutée OK ?
            if (pclMatrice === undefined) {
                //Non => échec
                return undefined;
            }
            //RAZ erreur
            this.RAZErreur();
            //Dimensions OK ?
            if (this._bTesteErreurDimensions(this.m_nNbLigne != pclMatrice.nGetNbLigne()) || (this.m_nNbColonne != pclMatrice.nGetNbColonne())) {
                //Non => erreur
                return undefined;
            }
            //Oui => création matrice résultat
            var pclMatriceRes = new CMatrice();
            //Visiteur addition
            var CVisiteurAddition = /** @class */ (function (_super) {
                __extends(CVisiteurAddition, _super);
                function CVisiteurAddition() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                // Visite cellule
                // Sortie :	true pour continuer , false pour l'arrêter
                CVisiteurAddition.prototype._bVisiteCellule = function (nLigne, nColonne) {
                    //Addition valeur dans matrice résultat
                    pclMatriceRes.MajElem(this.m_pclMatrice.nValeurElem(nLigne, nColonne) + pclMatrice.nValeurElem(nLigne, nColonne), nLigne, nColonne);
                    //Erreur à récupérer ?
                    if (this.m_pclMatrice.bErreurRecupere(pclMatrice)) {
                        //Oui => échec
                        pclMatriceRes = undefined;
                        //On arrête le parcours;
                        return false;
                    }
                    //Le parcours continue
                    return true;
                };
                return CVisiteurAddition;
            }(CVisiteurMatrice));
            //Visisteur addition
            var clVisiteurAddition = new CVisiteurAddition();
            //Addition
            clVisiteurAddition.VisiteMatrice(this);
            //Matrice résultat
            return pclMatriceRes;
        };
        // Transposition
        // Sortie : Matrice résultat (indéfini en cas d'erreur)
        CMatrice.prototype.pclTranspose = function () {
            //RAZ erreur
            this.RAZErreur();
            //Création matrice résultat
            var pclMatriceRes = new CMatrice();
            //Visiteur transposition
            var CVisiteurTransposition = /** @class */ (function (_super) {
                __extends(CVisiteurTransposition, _super);
                function CVisiteurTransposition() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                // Visite cellule
                // Sortie :	true pour continuer , false pour l'arrêter
                CVisiteurTransposition.prototype._bVisiteCellule = function (nLigne, nColonne) {
                    //Addition valeur dans matrice résultat
                    pclMatriceRes.MajElem(this.m_pclMatrice.nValeurElem(nLigne, nColonne), nColonne, nLigne);
                    //Erreur à récupérer ?
                    if (this.m_pclMatrice.bErreurRecupere(pclMatriceRes)) {
                        //Oui => échec
                        pclMatriceRes = undefined;
                        //On arrête le parcours;
                        return false;
                    }
                    //Le parcours continue
                    return true;
                };
                return CVisiteurTransposition;
            }(CVisiteurMatrice));
            //Visiteur transposition
            var clVisiteurTransposition = new CVisiteurTransposition();
            //Transposition
            clVisiteurTransposition.VisiteMatrice(this);
            //Matrice résultat
            return pclMatriceRes;
        };
        // Calsul somme intermédiaire pour décomposition LU
        // Entrée :	nLigne		Ligne
        //			nColonne	Colonne
        //			nLimite		Limite parcours colonne
        //			clSomme		Somme
        // Sortie :	clSomme		Somme mise à jour
        //			Résultat	true si calcul OK, false sinon
        CMatrice.prototype._bCalculSommmeIntermediairePourLUDecompose = function (nLigne, nColonne, nLimite, clSomme) {
            //Récupération valeur
            clSomme.m_Valeur = this.nValeurElem(nLigne, nColonne);
            //Calcul somme
            for (var nIndice = 0; nIndice < nLimite; nIndice++) {
                clSomme.m_Valeur -= this.nValeurElem(nLigne, nIndice) * this.nValeurElem(nIndice, nColonne);
            }
            //Récupération somme
            return this.bMajElem(clSomme.m_Valeur, nLigne, nColonne);
        };
        // Décomposition LU d'une matrice carrée
        // Entrée :	clParam	Paramètres décomposaition
        // Sortie :	true si décomposition OK, false sinon
        CMatrice.prototype._bLUDecompose = function (clParam) {
            //RAZ erreur
            this.RAZErreur();
            //Initialisation du signe
            clParam.m_nSigne = 1;
            //Plus grand élément
            var nMax;
            //Vecteur
            var clVecteur = [];
            //Remplissage du vecteur avec l'inverse du plus grand élément en valeur absolue de chaque colonne
            for (var nLigne = 0; nLigne < this.m_nNbLigne; nLigne++) {
                //Recherche du plus grand élément en valeur absolue de la colonne
                nMax = 0;
                for (var nColonne = 0; nColonne < this.m_nNbColonne; nColonne++) {
                    //Valeur absolue
                    var nValAbs = Math.abs(this.nValeurElem(nLigne, nColonne));
                    if (nValAbs > nMax) {
                        nMax = nValAbs;
                    }
                }
                //Le plus grand élément de la colonne est nul ?
                if (nMax == 0) {
                    //Oui => Erreur
                    this.m_nErreur = 1208 /* eErreurSinguliere */;
                    //Echec
                    return false;
                }
                //Non => stockage de l'élément dans le vecteur
                clVecteur[nLigne] = 1 / nMax;
            }
            //Transformation de la matrice
            for (var nColonne = 0; nColonne < this.m_nNbColonne; nColonne++) {
                //Somme
                var clSomme = new WDStd.CParamNum();
                //Calcul pour lignes d'indice inférieur à l'indice de la colonne
                for (var nLigne = 0; nLigne < nColonne; nLigne++) {
                    //Calcul somme intermédiaire OK ?
                    if (!this._bCalculSommmeIntermediairePourLUDecompose(nLigne, nColonne, nLigne, clSomme)) {
                        //Non => échec
                        return false;
                    }
                }
                //Oui => recherche du plus grand élément pivot
                nMax = 0;
                //Indice de la ligne permutée
                var nIndLignePermut = 0;
                //Valeur de travail
                var nTravail = void 0;
                for (var nLigne = nColonne; nLigne < this.m_nNbLigne; nLigne++) {
                    //Calcul somme intermédiaire OK ?
                    if (!this._bCalculSommmeIntermediairePourLUDecompose(nLigne, nColonne, nColonne, clSomme)) {
                        //Non => échec
                        return false;
                    }
                    //Oui => calcul pivot
                    nTravail = clVecteur[nLigne] * Math.abs(clSomme.m_Valeur);
                    //C'est le plus grand pivot ?
                    if (nTravail >= nMax) {
                        //Oui => mémorisation pivot max
                        nMax = nTravail;
                        //Mémorisation ligne permutation
                        nIndLignePermut = nLigne;
                    }
                }
                //Faut-il faire un échange ?
                if (nColonne != nIndLignePermut) {
                    //Oui => échange d'éléments
                    for (var nIndice = 0; nIndice < this.m_nNbLigne; nIndice++) {
                        //Récupération valeur
                        nTravail = this.nValeurElem(nIndLignePermut, nIndice);
                        //Mise à jour valeur OK ?
                        if (!this.bMajElem(this.nValeurElem(nColonne, nIndice), nIndLignePermut, nIndice)) {
                            //Non => échec
                            return false;
                        }
                        //Oui => récupération valeur OK ?
                        if (!this.bMajElem(nTravail, nColonne, nIndice)) {
                            //Non => échec
                            return false;
                        }
                    }
                    //Il y a eu une permutation donc on inverse le signe
                    clParam.m_nSigne = -clParam.m_nSigne;
                    //On met à jour le vecteur
                    clVecteur[nIndLignePermut] = clVecteur[nColonne];
                }
                //Mise à jour du tableau d'indices
                clParam.m_clTabIndice[nColonne] = nIndLignePermut;
                //Elément pivot nul ?
                if (this.nValeurElem(nColonne, nColonne) == 0) {
                    //Oui => erreur
                    this.m_nErreur = 1208 /* eErreurSinguliere */;
                    //Echec
                    return false;
                }
                //Non => on est sur le dernier élément ?
                if (nColonne != this.m_nNbColonne - 1) {
                    //Non => division par l'élément pivot
                    nTravail = 1 / this.nValeurElem(nColonne, nColonne);
                    //Mise à jour ligne
                    for (var nLigne = nColonne + 1; nLigne < this.m_nNbLigne; nLigne++) {
                        //Mise à jour OK ?
                        if (!this.bMajElem(this.nValeurElem(nLigne, nColonne) * nTravail, nLigne, nColonne)) {
                            //Non => échec
                            return false;
                        }
                    }
                }
            }
            //OK
            return true;
        };
        // Indique si matrice singulière
        // Sortie :	true si matrice singulière, false sinon
        CMatrice.prototype.bSinguliere = function () {
            //Indique si matrice singulière
            return this.m_nErreur == 1208 /* eErreurSinguliere */;
        };
        // Calcul du determinant d'une matrice carrée
        // Sortie: determinant de la matrice (valeur erreur en cas d'échec)
        CMatrice.prototype.nDeterminant = function () {
            //Déterminant de la matrice
            var nDeterminant = 1;
            //RAZ erreur
            this.RAZErreur();
            //Dimensions OK ?
            if (this._bTesteErreurDimensions((this.m_nNbLigne != this.m_nNbColonne) || (this.m_nNbLigne == 0))) {
                //Non => erreur
                return nVALEUR_ERREUR;
            }
            //Matrice d'ordre 1 ?
            if (this.m_nNbLigne == 1) {
                //Le déterminant est l'unique valeur de la matrice
                return this.nValeurElem(0, 0);
            }
            //Matrice de calcul
            var pclMatrice = new CMatrice();
            //Copie de la matrice
            pclMatrice.Copie(this);
            //Paramètres décomposition LU
            var clParamDecompostion = new CParamDecompositionLU();
            //Décomposition LU OK ?
            if (!pclMatrice._bLUDecompose(clParamDecompostion)) {
                //Non => Matrice singulière ?
                if (pclMatrice.bSinguliere()) {
                    //Oui => pas d'erreur
                    this.RAZErreur();
                }
                //Déterminant nul
                return 0;
            }
            //Calcul du déterminant   
            for (var nIndice = 0; nIndice < this.m_nNbLigne; nIndice++) {
                nDeterminant *= pclMatrice.nValeurElem(nIndice, nIndice);
            }
            if (clParamDecompostion.m_nSigne == -1) {
                nDeterminant = -nDeterminant;
            }
            //Déterminant
            return nDeterminant;
        };
        // Mise à jour somme intermédiaire pour LU équation
        // Entrée :	Somme		Somme	
        //			nLigne		Ligne
        //			nColonne	Colonne
        //			clVecteur	Vecteur
        // Sortie :	Somme mise à jour
        CMatrice.prototype._MAJSommePourCalculLUEquation = function (nSomme, nLigne, nColonne, clVecteur) {
            //Mise à jour somme
            return nSomme - this.nValeurElem(nLigne, nColonne) * clVecteur[nColonne];
        };
        // Résolution d'un système d'équation A.X=B à partir d'une matrice LU (doit être appelé après avoir fait la décomposition LU)
        // Entrée :	clTabIndLignePermut	Indices des lignes permutées récupérées de la fonction de décomposition LU
        //			clVecteur			Vecteur B
        // Sortie :	clVecteur			Vecteur résultat
        CMatrice.prototype._LUEquation = function (clTabIndLignePermut, clVecteur) {
            //Récupération somme
            var nSomme;
            //Indice ligne précédente
            var nIndicePrec;
            //Parcours lignes
            for (var nLigne = 0; nLigne < this.m_nNbLigne; nLigne++) {
                //Récupération indice permutation
                var nIndice = clTabIndLignePermut[nLigne];
                //Récupération somme
                nSomme = clVecteur[nIndice];
                //Récupération valeur dans vecteur
                clVecteur[nIndice] = clVecteur[nLigne];
                //Indice OK ?
                if (nIndicePrec != undefined) {
                    //Oui => mise à jour somme
                    for (var nColonne = nIndicePrec; nColonne < nLigne; nColonne++) {
                        nSomme = this._MAJSommePourCalculLUEquation(nSomme, nLigne, nColonne, clVecteur);
                    }
                }
                //Non => somme nulle ?
                else if (nSomme != 0) {
                    //Non => mise à jour indice ligne précédente
                    nIndicePrec = nLigne;
                }
                //Récupération somme
                clVecteur[nLigne] = nSomme;
            }
            //Parcours lignes
            for (var nLigne = this.m_nNbLigne; nLigne >= 0; nLigne--) {
                //Récupération somme
                nSomme = clVecteur[nLigne];
                //Mise à jour somme
                for (var nColonne = nLigne + 1; nColonne < this.m_nNbColonne; nColonne++) {
                    nSomme = this._MAJSommePourCalculLUEquation(nSomme, nLigne, nColonne, clVecteur);
                }
                //Mise à jour vecteur
                clVecteur[nLigne] = nSomme / this.nValeurElem(nLigne, nLigne);
            }
        };
        // Calcule la matrice inverse,
        // Sortie : Matrice résultat (indéfini en cas d'erreur)
        CMatrice.prototype.pclInverse = function () {
            //RAZ erreur
            this.RAZErreur();
            //Matrice carrée ?
            if (this._bTesteErreurDimensions(this.m_nNbLigne != this.m_nNbColonne)) {
                //Non => erreur
                return undefined;
            }
            //Oui => Matrice résultat
            var pclMatriceRes = new CMatrice();
            //Matrice de calcul
            var pclMatrice = new CMatrice();
            //Copie de la matrice dans la matrice de calcul
            pclMatrice.Copie(this);
            //Paramètres décomposition LU
            var clParamDecompostion = new CParamDecompositionLU();
            //Décomposition LU OK ?
            if (!pclMatrice._bLUDecompose(clParamDecompostion)) {
                //Non => récupération erreur
                this.bErreurRecupere(pclMatrice);
                //Matrice singulière ?
                if (this.bSinguliere()) {
                    //Oui => erreur déterminant nul
                    this.m_nErreur = 1209 /* eErreurDeterminantNul */;
                }
                //Echec
                return undefined;
            }
            //Vecteur
            var clVecteur = [];
            //Parcours colonnes
            for (var nColonne = 0; nColonne < this.m_nNbLigne; nColonne++) {
                //RAZ vecteur
                for (var nLigne = 0; nLigne < this.m_nNbLigne; nLigne++) {
                    clVecteur[nLigne] = 0;
                }
                //Init entrée vecteur correspondant à colonne parcourue
                clVecteur[nColonne] = 1;
                //Calcul LU équation
                pclMatrice._LUEquation(clParamDecompostion.m_clTabIndice, clVecteur);
                //Mise à jour matrice résultat
                for (var nLigne = 0; nLigne < this.m_nNbLigne; nLigne++) {
                    //Récupération résultat
                    pclMatriceRes.MajElem(clVecteur[nLigne], nLigne, nColonne);
                    //Erreur ?
                    if (this.bErreurRecupere(pclMatriceRes)) {
                        //Oui => échec
                        return undefined;
                    }
                }
            }
            //Matrice inversée
            return pclMatriceRes;
        };
        return CMatrice;
    }());
    //Paramètre matrice modifiable
    var CParamMatrice = /** @class */ (function (_super) {
        __extends(CParamMatrice, _super);
        function CParamMatrice() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return CParamMatrice;
    }(WDStd.CParam));
    WDMat.CParamMatrice = CParamMatrice;
    ;
    //Visiteur matrice
    var CVisiteurMatrice = /** @class */ (function () {
        function CVisiteurMatrice() {
        }
        // Visite matrice
        // Entrée :	pclMatrice	Matrice visitée
        //			nNbLigne	Nombre lignes visitées (nombre de lignes de la matrice si non précisé)
        //			nNbColonne	Nombre colonnes visitées (nombre de colonnes de la matrice si non précisé)
        CVisiteurMatrice.prototype.VisiteMatrice = function (pclMatrice, nNbLigne, nNbColonne) {
            //Récupération matrice
            this.m_pclMatrice = pclMatrice;
            //Matrice OK ?
            if (this.m_pclMatrice === undefined) {
                //Non => rien à faire
                return;
            }
            //Nombre lignes précisé ?
            if (nNbLigne === undefined) {
                //Non => on parcourt toutes les lignes
                nNbLigne = this.m_pclMatrice.nGetNbLigne();
            }
            //Nombre colonnes précisé ?
            if (nNbColonne === undefined) {
                //Non => on parcourt toutes les colonnes
                nNbColonne = this.m_pclMatrice.nGetNbColonne();
            }
            //Parcours des lignes
            for (var nLigne = 0; nLigne < nNbLigne; nLigne++) {
                //Parcours des colonnes
                for (var nColonne = 0; nColonne < nNbColonne; nColonne++) {
                    //Visite cellule OK ?
                    if (!this._bVisiteCellule(nLigne, nColonne)) {
                        //Non => fin de la visite
                        return;
                    }
                }
            }
        };
        return CVisiteurMatrice;
    }());
    //Matrices
    var gpclTabMatrice = [];
    //Valeur erreur
    var nVALEUR_WL_ERREUR = -1;
    // Identifiant de matrice correspondant à un nom
    // Entrée :	sNomMat	Nom de la matrice
    // Sortie : Identifiant matrice correspondant au nom
    function sNomVersIdMatrice(sNomMat) {
        //Identifiant indépendant de la casse
        return sNomMat.toUpperCase();
    }
    // Identifiant matrice à partir de son nom
    // Entrée :	sNomMat	Nom de la matrice
    // Sortie : Identifiant matrice correspondant au nom, indéfini en cas d'échec (pas de matrice avec le nom recherché)
    function uGetIdMatrice(sNomMat) {
        //Identifiant correspondantg au nom
        var sIdMatrice = sNomVersIdMatrice(sNomMat);
        //L'identifiant est un identifiant de matrice ?
        if (gpclTabMatrice[sIdMatrice] === undefined) {
            //Non => matrice non trouvée
            return undefined;
        }
        //Oui => identifiant matrice recherchée
        return sIdMatrice;
    }
    // Libération d'une matrice
    // Entrée :	sNom	Nom de la matrice à libérer
    // Sortie :	true si libération OK, false sinon
    function bLibereMatrice(sNom) {
        //Identifiant de la matrice avec le nom recherché
        var uIdMatrice = uGetIdMatrice(sNom);
        //La matrice existe ?
        if (uIdMatrice === undefined) {
            //Non => échec
            return false;
        }
        //Oui => suppression de la matrice dans le tableau
        delete gpclTabMatrice[uIdMatrice];
        //OK
        return true;
    }
    // Stockage nouvelle matrice
    // Entrée :	pclMatrice	Nouvelle matrice à stocker
    // Sortie :	true si stockage OK, false sinon
    function bNouvelleMatrice(pclMatrice) {
        //Matrice OK ?
        if (pclMatrice === undefined) {
            //Non => échec
            return false;
        }
        //Oui => Stockage matrice
        gpclTabMatrice[sNomVersIdMatrice(pclMatrice.sGetNom())] = pclMatrice;
        //OK
        return true;
    }
    // Stockage nouvelle matrice en lui donnant un nom
    // Entrée :	pclMatrice	Nouvelle matrice à stocker
    //			sNom		Nom de la matrice
    // Sortie :	true si stockage OK, false sinon
    function bNouvelleMatriceNom(pclMatrice, sNom) {
        //Matrice OK ?
        if (pclMatrice === undefined) {
            //Non => échec
            return false;
        }
        //Oui => affectation nom 
        pclMatrice.SetNom(sNom);
        //Stockage matrice
        return bNouvelleMatrice(pclMatrice);
    }
    // Test erreur et lève erreur si erreur
    // Entrée :	bTestErreur	Indique si erreur
    //			nErreur		Erreur à lever en cas d'erreur
    //			tabParam	Paramètres optionnels
    // Sortie : true si erreur, false sinon
    function bTesteErreur(bTestErreur, nErreur) {
        var tabParam = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            tabParam[_i - 2] = arguments[_i];
        }
        //Erreur ?
        if (bTestErreur) {
            //Oui => on lève l'erreur
            WDStd.LeveErreur(nErreur, tabParam);
        }
        //Indique si erreur
        return bTestErreur;
    }
    // Indique si matrice en erreur (lève l'erreur si c'est le cas)
    // Entrée :	pclMatrice	Matrice dont on veut savoir s'i elle est en erreur
    // Sortie :	true si matrice en erreur, false sinon
    function bMatriceEnErreur(pclMatrice) {
        //Matrice OK ?
        if (pclMatrice === undefined) {
            //Non => la matrice n'est pas en erreur
            return false;
        }
        //Test erreur
        return bTesteErreur(pclMatrice.bErreur(), pclMatrice.nGetErreur());
    }
    // Création de matrice
    // Entrée :	sNom	Nom de la matrice
    // Sortie :	true si matrice créée, false sinon
    function MatCree(sNom) {
        //Libération de la matrice si elle existe déjà
        bLibereMatrice(sNom);
        //Création de la matrice
        var pclMatrice = new CMatrice(sNom);
        //Matrice en erreur ?
        if (bMatriceEnErreur(pclMatrice)) {
            //Oui => échec
            return false;
        }
        //Non => Stockage de la matrice
        return bNouvelleMatrice(pclMatrice);
    }
    WDMat.MatCree = MatCree;
    // Test existence matrice
    // Entrée :	sNom	Nom de la matrice
    // Sortie :	true si matrice existe, false sinon
    function MatExiste(sNom) {
        //Test existence matrice
        return uGetIdMatrice(sNom) != undefined;
    }
    WDMat.MatExiste = MatExiste;
    // Suppression matrice
    // Entrée :	sNom	Nom de la matrice
    function MatSupprime(sNom) {
        //Suppression matrice
        bLibereMatrice(sNom);
    }
    WDMat.MatSupprime = MatSupprime;
    // Indique si indice ou dimension WLangage valide
    // Entrée :	nIndice	Indice ou dimension WLangage
    // Sortie :	true si indice ou dimension valide, false sinon
    function bIndiceDimensionWLValide(nIndice) {
        //Test validité indice ou dimension
        return (nIndice >= WDStd.nPREMIER_INDICE_WL);
    }
    // Indique si indice WLangage valide (lève une erreur si indice invalide)
    // Entrée :	nIndice	Indice WLangage
    // Sortie :	true si indice valide, false sinon
    function bIndiceWLValide(nIndice) {
        //Test Indice
        return !bTesteErreur(!bIndiceDimensionWLValide(nIndice), 1201 /* eErreurIndiceInvalide */, nIndice);
    }
    // Indique si coordonnées WLangage valides (lève une erreur si coordonnée invalide)
    // Entrée :	nLigne		Indice ligne WLangage
    //			nColonne	Indice colonne WLangage
    // Sortie :	true si coordonnées valides, false sinon
    function bCoordValide(nLigne, nColonne) {
        //Vérification coordonnées
        return bIndiceWLValide(nLigne) && bIndiceWLValide(nColonne);
    }
    // Indique si dimension valide (lève une erreur si dimension invalide)
    // Entrée :	nDimension	Dimension
    // Sortie :	true si dimension valide, false sinon
    function bDimensionValide(nDimension) {
        //Test dimension
        return !bTesteErreur(!bIndiceDimensionWLValide(nDimension), 1207 /* eErreurDimensionInvalide */);
    }
    // Indique si dimensions valides (lève une erreur si dimension invalide)
    // Entrée :	nNbLigne	Nombre de lignes
    //			nNbColonne	Nombre de colonnes
    // Sortie :	true si dimensions valides, false sinon
    function bTouteDimensionValide(nNbLigne, nNbColonne) {
        //Vérification dimensions
        return bDimensionValide(nNbLigne) && bDimensionValide(nNbColonne);
    }
    // Récupération matrice par nom (lève une erreur en cas d'échec)
    // Entrée :	sNom	Nom de la matrice
    // Sortie :	Matrice recherchée, indéfini en cas d'échec (une erreur est levée)
    function pclGetMatrice(sNom) {
        //Récupération matrice
        var pclMatrice = gpclTabMatrice[uGetIdMatrice(sNom)];
        //Test matrice
        bTesteErreur(pclMatrice === undefined, 1200 /* eErreurMauvaiseMatrice */);
        //Matrice recherchée
        return pclMatrice;
    }
    // Récupération matrice par nom et vérification coordonnées (lève une erreur en cas d'échec)
    // Entrée :	sNom	Nom de la matrice
    //			nLigne		Indice ligne WLangage
    //			nColonne	Indice colonne WLangage
    // Sortie :	Matrice recherchée, indéfini en cas d'échec (une erreur est levée)
    function pclGetMatriceVerifCoord(sNom, nLigne, nColonne) {
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe et les coordonnées sont correctes ?
        if ((pclMatrice === undefined) || (!bCoordValide(nLigne, nColonne))) {
            //Non => échec
            return undefined;
        }
        //Oui => matrice recherchée
        return pclMatrice;
    }
    // Récupération matrice par nom et vérification dimensions (lève une erreur en cas d'échec)
    // Entrée :	sNom		Nom de la matrice
    //			nNbLigne	Nombre de lignes
    //			nNbColonne	Nombre de colonnes
    // Sortie :	Matrice recherchée, indéfini en cas d'échec (une erreur est levée)
    function pclGetMatriceVerifDimension(sNom, nNbLigne, nNbColonne) {
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe et les coordonnées sont correctes ?
        if ((pclMatrice === undefined) || (!bTouteDimensionValide(nNbLigne, nNbColonne))) {
            //Non => échec
            return undefined;
        }
        //Oui => matrice recherchée
        return pclMatrice;
    }
    // Ectiture d'une valeur dans une matrice
    // Entrée :	sNom		Nom de la matrice
    //			nValeur		Valeur écrite
    //			nLigne		Ligne de l'élément (indice WLangage)
    //			nColonne	Colonne de la matrice (indice WLangage)
    // Sortie :	true si valeur écrite, false sinon
    function MatEcrit(sNom, nValeur, nLigne, nColonne) {
        //Récupération matrice et vérifications coordonnées
        var pclMatrice = pclGetMatriceVerifCoord(sNom, nLigne, nColonne);
        //La matrice existe et les coordonnées sont correctes ?
        if (pclMatrice === undefined) {
            //Non => échec
            return false;
        }
        //Oui => Mise à jour élément
        pclMatrice.MajElem(nValeur, WDStd.nIndiceWLVersC(nLigne), WDStd.nIndiceWLVersC(nColonne));
        //Test erreur
        return !bMatriceEnErreur(pclMatrice);
    }
    WDMat.MatEcrit = MatEcrit;
    // Lecture d'une valeur dans une matrice
    // Entrée :	sNom		Nom de la matrice
    //			nLigne		Ligne de l'élément (indice WLangage)
    //			nColonne	Colonne de la matrice (indice WLangage)
    // Sortie :	Valeur lue (valeur erreur en cas d'échec)
    function MatLit(sNom, nLigne, nColonne) {
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => échec
            return nVALEUR_ERREUR;
        }
        //Récupération valeur
        var nValeur = pclMatrice.nValeurElem(WDStd.nIndiceWLVersC(nLigne), WDStd.nIndiceWLVersC(nColonne));
        //Erreur ?
        if (bMatriceEnErreur(pclMatrice)) {
            //Oui => valeur erreur
            return nVALEUR_WL_ERREUR;
        }
        //Non => valeur
        return nValeur;
    }
    WDMat.MatLit = MatLit;
    // Compression d'une matrice
    // Entrée :	sNom		Nom de la matrice
    function MatCompresse(sNom) {
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => échec
            return;
        }
        //Récupération matrice compressé
        var pclNewMat = pclMatrice.pclCompresse();
        //Problème pendant la compression ?
        if (pclMatrice.bErreur()) {
            //Oui => on sort
            return;
        }
        //Non => libération ancienne matrice
        bLibereMatrice(sNom);
        //Stockage de la matrice compressée
        bNouvelleMatrice(pclNewMat);
    }
    WDMat.MatCompresse = MatCompresse;
    // Nombre de lignes d'une matrice
    // Entrée :	sNom		Nom de la matrice
    // Sortie : Nombre de lignes de la matrice (valeur erreur en cas d'échec)
    function MatNbLigne(sNom) {
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => échec
            return nVALEUR_WL_ERREUR;
        }
        //Oui => nombre de lignes de la matrice
        return pclMatrice.nGetNbLigne();
    }
    WDMat.MatNbLigne = MatNbLigne;
    // Nombre de colonnes d'une matrice
    // Entrée :	sNom		Nom de la matrice
    // Sortie : Nombre de colonnes de la matrice (valeur erreur en cas d'échec)
    function MatNbColonne(sNom) {
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => échec
            return nVALEUR_WL_ERREUR;
        }
        //Oui => nombre de lignes de la matrice
        return pclMatrice.nGetNbColonne();
    }
    WDMat.MatNbColonne = MatNbColonne;
    // Multiplie deux matrices
    // Entrée :	sNom1	Nom de la première matrice à multiplier
    //			sNom2	Nom de la deuxième matrice à multiplier
    //			sNomRes	Nom de la matrice résultat
    function MatMultiplie(sNom1, sNom2, sNomRes) {
        //Suppression de la matrice résultat si elle existe déjà
        bLibereMatrice(sNomRes);
        //Récupération première matrice
        var pclMatrice1 = pclGetMatrice(sNom1);
        //Récupération deuxième matrice
        var pclMatrice2 = pclGetMatrice(sNom2);
        //Les deux matrices existent ?
        if ((pclMatrice1 === undefined) || (pclMatrice2 === undefined)) {
            //Non => échec
            return false;
        }
        //Oui => Nombre colonnes matrice 1
        var nNbColonne1 = pclMatrice1.nGetNbColonne();
        //Dimension des matrices correcte ?
        if (bTesteErreur(pclMatrice2.nGetNbLigne() != nNbColonne1, 1206 /* eErreurDimension */)) {
            //Non => échec
            return false;
        }
        //Oui => création matrice résultat
        var pclMatriceRes = new CMatrice(sNomRes);
        //La matrices résultat a le même nombre de lignes que la première matrice
        pclMatriceRes.SetNbLigne(pclMatrice1.nGetNbLigne());
        //La matrices résultat a le même nombre de colonnes que la deuxième matrice
        pclMatriceRes.SetNbColonne(pclMatrice2.nGetNbColonne());
        //Visiteur multiplication
        var CVisiteurMultiplication = /** @class */ (function (_super) {
            __extends(CVisiteurMultiplication, _super);
            function CVisiteurMultiplication() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            // Visite cellule
            // Sortie :	true pour continuer , false pour l'arrêter
            CVisiteurMultiplication.prototype._bVisiteCellule = function (nLigne, nColonne) {
                //Valeur
                var nValeur = 0;
                //Parcours colonnes matrice 1
                for (var nColonne1 = 0; nColonne1 < nNbColonne1; nColonne1++) {
                    //Calcul valeur
                    nValeur += pclMatrice1.nValeurElem(nLigne, nColonne1) * pclMatrice2.nValeurElem(nColonne1, nColonne);
                }
                //Affectation valeur dans matrice résultat
                this.m_pclMatrice.MajElem(nValeur, nLigne, nColonne);
                //Le parcours continue
                return true;
            };
            return CVisiteurMultiplication;
        }(CVisiteurMatrice));
        //Visisteur multiplication
        var clVisiteurMultiplication = new CVisiteurMultiplication();
        //Multiplication
        clVisiteurMultiplication.VisiteMatrice(pclMatriceRes);
        //Stockage de la matrice résultat
        return bNouvelleMatrice(pclMatriceRes);
    }
    WDMat.MatMultiplie = MatMultiplie;
    // Remplissage d'une matrice avec une valeur donnée
    // Entrée :	sNom		Nom de la matrice
    //			nValeur		Valeur de remplissage
    //			nNbLigne	Nombre de lignes à remplir
    //			nNbColonne	Nombre de colonnes à remplir
    // Sortie :	true si remplissage OK, false sinon
    function MatRemplit(sNom, nValeur, nNbLigne, nNbColonne) {
        //Récupération matrice et vérifications coordonnées
        var pclMatrice = pclGetMatriceVerifDimension(sNom, nNbLigne, nNbColonne);
        //La matrice existe et les coordonnées sont correctes ?
        if (pclMatrice === undefined) {
            //Non => échec
            return false;
        }
        //Visiteur remplissage
        var CVisiteurRemplissage = /** @class */ (function (_super) {
            __extends(CVisiteurRemplissage, _super);
            function CVisiteurRemplissage() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            // Visite cellule
            // Sortie :	true pour continuer , false pour l'arrêter
            CVisiteurRemplissage.prototype._bVisiteCellule = function (nLigne, nColonne) {
                //Remplissage avec valeur
                pclMatrice.MajElem(nValeur, nLigne, nColonne);
                //Une erreur est survenue ?
                if (bMatriceEnErreur(pclMatrice)) {
                    //Oui => fin du parcours
                    return false;
                }
                //Le parcours continue
                return true;
            };
            return CVisiteurRemplissage;
        }(CVisiteurMatrice));
        //Visisteur remplissage
        var clVisiteurRemplissage = new CVisiteurRemplissage();
        //Remplisage
        clVisiteurRemplissage.VisiteMatrice(pclMatrice, nNbLigne, nNbColonne);
        //Test erreur
        return !pclMatrice.bErreur();
    }
    WDMat.MatRemplit = MatRemplit;
    // Opération d'une matrice avec un réel
    // Entrée :	sNom		Nom de la matrice
    //			nValeur		Valeur par laquelle on multiplie la matrice
    //			eOperation	Opération
    function MatReelOperation(sNom, nValeur, eOperation) {
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => on sort
            return;
        }
        //Opération
        pclMatrice.ReelOperation(nValeur, eOperation);
        //Test erreur
        bMatriceEnErreur(pclMatrice);
    }
    // Multiplication d'une matrice par un réel
    // Entrée :	sNom		Nom de la matrice
    //			nValeur		Valeur par laquelle on multiplie la matrice
    function MatReelMultiplie(sNom, nValeur) {
        //Multiplpication
        MatReelOperation(sNom, nValeur, 1 /* eMultiplication */);
    }
    WDMat.MatReelMultiplie = MatReelMultiplie;
    // Addition d'une matrice avec un réel
    // Entrée :	sNom		Nom de la matrice
    //			nValeur		Valeur ajoutée à la matrice
    function MatReelAdditionne(sNom, nValeur) {
        //Addition
        MatReelOperation(sNom, nValeur, 0 /* eAddition */);
    }
    WDMat.MatReelAdditionne = MatReelAdditionne;
    // Copie d'une matrice dans une autre
    // Entrée :	sNomSrc		Nom de la matrice source
    //			sNomDst		Nom de la matrice destination
    // Sortie :	true si copie réussie, false sinon
    function MatCopie(sNomSrc, sNomDst) {
        //Suppression de la matrice destination si elle existe déjà
        bLibereMatrice(sNomDst);
        //Récupération matrice source
        var pclMatriceSrc = pclGetMatrice(sNomSrc);
        //La matrice source existe ?
        if (pclMatriceSrc === undefined) {
            //Non => échec
            return false;
        }
        //Matrice destination
        var pclMatriceDst = new CMatrice(sNomDst);
        //Copie de la matrice
        pclMatriceDst.Copie(pclMatriceSrc);
        //Erreur pendant la copie ?
        if (bMatriceEnErreur(pclMatriceSrc)) {
            //Oui => échec
            return false;
        }
        //Stockage de la matrice copiée
        return bNouvelleMatrice(pclMatriceDst);
    }
    WDMat.MatCopie = MatCopie;
    // Addition deux matrices
    // Entrée :	sNom1	Nom de la première matrice à ajouter
    //			sNom2	Nom de la deuxième matrice à ajouter
    //			sNomRes	Nom de la matrice résultat
    // Sortie :	true si addition réussie, false sinon
    function MatAdditionne(sNom1, sNom2, sNomRes) {
        //Suppression de la matrice résultat si elle existe déjà
        bLibereMatrice(sNomRes);
        //Récupération première matrice
        var pclMatrice1 = pclGetMatrice(sNom1);
        //Récupération deuxième matrice
        var pclMatrice2 = pclGetMatrice(sNom2);
        //Les deux matrices existent ?
        if ((pclMatrice1 === undefined) || (pclMatrice2 === undefined)) {
            //Non => échec
            return false;
        }
        //Oui => addition
        var pclMatriceRes = pclMatrice1.pclAdditionne(pclMatrice2);
        //Erreur ?
        if (bMatriceEnErreur(pclMatrice1)) {
            //Oui => échec
            return false;
        }
        //Non => stockage de la matrice résultat
        return bNouvelleMatriceNom(pclMatriceRes, sNomRes);
    }
    WDMat.MatAdditionne = MatAdditionne;
    // Transposition de matrice
    // Entrée :	sNom	Nom de la matrice à transposer
    //			sNomRes	Nom de la matrice résultat
    // Sortie :	true si transposition réussie, false sinon
    function MatTranspose(sNom, sNomRes) {
        //Suppression de la matrice résultat si elle existe déjà
        bLibereMatrice(sNomRes);
        //Récupération matrice à transposer
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => échec
            return false;
        }
        //Oui => transposition
        var pclMatriceRes = pclMatrice.pclTranspose();
        //Erreur ?
        if (bMatriceEnErreur(pclMatrice)) {
            //Oui => échec
            return false;
        }
        //Non => stockage de la matrice résultat
        return bNouvelleMatriceNom(pclMatriceRes, sNomRes);
    }
    WDMat.MatTranspose = MatTranspose;
    // Déterminant d'une matrice
    // Entrée :	sNom	Nom de la matrice
    // Sortie :	Déterminant de la matrice (valeur erreur en cas d'échec)
    function MatDeterminant(sNom) {
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => erreur
            return nVALEUR_WL_ERREUR;
        }
        //Oui => calcul déterminant
        var nDeterminant = pclMatrice.nDeterminant();
        //Matrice singulière ?
        if (pclMatrice.bSinguliere()) {
            //Oui => déterminant nul
            return 0;
        }
        //Non => erreur ?
        if (bMatriceEnErreur(pclMatrice)) {
            //Oui => échec
            return nVALEUR_WL_ERREUR;
        }
        //Non => déterminnant
        return nDeterminant;
    }
    WDMat.MatDeterminant = MatDeterminant;
    // Inverse d'une matrice
    // Entrée :	sNom	Nom de la matrice à inverser
    //			sNomRes	Nom de la matrice résultat
    // Sortie :	true si inversion réussie, false sinon
    function MatInverse(sNom, sNomRes) {
        //Suppression de la matrice résultat si elle existe déjà
        bLibereMatrice(sNomRes);
        //Récupération matrice à inverser
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => échec
            return false;
        }
        //Oui => inversion
        var pclMatriceRes = pclMatrice.pclInverse();
        //Matrice singulière ou déterminant nul ou autre erreur ?
        if (pclMatrice.bSinguliere() || (pclMatrice.nGetErreur() == 1209 /* eErreurDeterminantNul */) || bMatriceEnErreur(pclMatrice)) {
            //Oui => échec
            return false;
        }
        //Non => stockage de la matrice résultat
        return bNouvelleMatriceNom(pclMatriceRes, sNomRes);
    }
    WDMat.MatInverse = MatInverse;
    // Erreur matrice
    // Entrée :	sNom	Nom de la matrice dont on veut l'erreur
    // Sortie :	numéro d'erreur de la matrice, erreur invalide en cas d'échec
    function MatErreur(sNom) {
        //Récupération matrice à inverser
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => échec
            return nVALEUR_WL_ERREUR;
        }
        //Oui => erreur
        return pclMatrice.nGetErreur();
    }
    WDMat.MatErreur = MatErreur;
    //Valeur à ignorer
    var nVALEUR_IGNORE = -1;
    // Extraction type de chaîne de format
    // Entrée : sFormat	chaîne de format
    // Sortie :	Type
    function sTypeFormat(sFormat) {
        //Type
        return sFormat[sFormat.length - 1];
    }
    //Type flottant
    var sTYPE_FLOT = "f";
    //Type étendu minuscule
    var sTYPE_ETENDU_MIN = "e";
    //Type étendu majuscule
    var sTYPE_ETENDU_MAJ = "E";
    //Type entier
    var sTYPE_ENTIER = "d";
    //Séparateur déciml
    var sSEP_DECIMAL = ".";
    // Entrée :	sFormatWL	Format chaine WLangage (de la forme [Taille][.Nombre décimales]Type)
    // Sortie:  clTaille	Taille de la chaine (valeur à ignorer si pas de taille)
    //			clNbDecimal	Nombre de décimales (valeur à ignorer si pas de décimales)
    //			clType		Type de la chaine
    //			Résulat		true si analyse réussie, false sinon
    function bAnalyseFormat(sFormatWL, clTaille, clNbDecimal, clType) {
        //Format OK ?
        if ((sFormatWL === undefined) || (sFormatWL.length > 10) || (sFormatWL == "")) {
            //Non => échec
            return false;
        }
        //Oui => types
        var sTYPE = sTYPE_FLOT + sTYPE_ETENDU_MIN + sTYPE_ETENDU_MAJ + sTYPE_ENTIER;
        //Récupération type
        var sType = sTypeFormat(sFormatWL);
        //Type OK ?
        if (sTYPE.indexOf(sType) < 0) {
            //Non => échec
            return false;
        }
        //Oui => récupération type
        clType.m_Valeur = sType;
        //Position type
        var nPosType = sFormatWL.length - clType.m_Valeur.length;
        //Récupération position séparateur décimales
        var nPosSepDecimal = sFormatWL.indexOf(sSEP_DECIMAL);
        //Indique si séparateur décimal
        var bSepDecimal = (nPosSepDecimal >= 0);
        //Décimales ?
        if ((!bSepDecimal) || (clType.m_Valeur == sTYPE_ENTIER)) {
            //Non => pas décimales
            clNbDecimal.m_Valeur = nVALEUR_IGNORE;
        }
        else {
            //Oui => récupération du nombre de écimales sous forme de chaine
            var sNbDecimal = sFormatWL.substring(nPosSepDecimal + 1, nPosType);
            //Récupération nombre décimales
            clNbDecimal.m_Valeur = parseInt(sNbDecimal);
        }
        //Récupération chaine taille
        var sTaille = sFormatWL.substring(0, bSepDecimal ? nPosSepDecimal : nPosType);
        //Taille ?
        if (sTaille == "") {
            //Non => pas de taille
            clTaille.m_Valeur = nVALEUR_IGNORE;
        }
        else {
            //Oui => récupération taille
            clTaille.m_Valeur = Math.min(parseInt(sTaille), 254);
        }
        //OK
        return true;
    }
    // Calcul chaine de formatage chaine de format WLangage
    // Entrée :	sFormatWL	Format chaine WLangage (de la forme [Taille][.Nombre décimales]Type)
    // Sortie :	clFormat	Format résultat
    //			Résultat	true si calcul format OK, false sinon
    function bChaineFormat(sFormatWL, clFormat) {
        //Paramètres OK ?
        if ((sFormatWL === undefined) || (clFormat === undefined)) {
            //Non => erreur
            return false;
        }
        //Taille
        var clTaille = new WDStd.CParamNum();
        //Nombre de décimales
        var clNbDecimal = new WDStd.CParamNum();
        //Type
        var clType = new WDStd.CParamChaine();
        //Format OK ?
        if (!bAnalyseFormat(sFormatWL, clTaille, clNbDecimal, clType)) {
            //Non => échec
            return false;
        }
        //Oui => taille en chaine
        var sTaille = "";
        //Taille précisée ?
        if (clTaille.m_Valeur != nVALEUR_IGNORE) {
            //Oui => récupération taille
            sTaille = String(clTaille.m_Valeur);
        }
        //Nombre de décimales en chaine
        var sNbDecimal = "";
        //Nombre décimales précisée ?
        if (clNbDecimal.m_Valeur != nVALEUR_IGNORE) {
            //Oui => récupération nombre décimales
            sNbDecimal = sSEP_DECIMAL + String(clNbDecimal.m_Valeur);
        }
        //Récupération valeur
        clFormat.m_Valeur = sTaille + sNbDecimal + clType.m_Valeur;
        //OK
        return true;
    }
    // Lecture ligne ou colonne matrice
    // Entrée :	sNom			Nom de la matrice dont on veut la ligne
    //			nLigneOuColonne	Indice ligne à lire
    //			sFormat			Format
    //			bLigne			Indique si on lit une ligne
    // Sortie :	Ligne ou colonne lue, chaine vide en cas d'erreur
    function MatLitLigneOuColonne(sNom, nLigneOuColonne, sFormat, bLigne) {
        if (sFormat === void 0) { sFormat = sTYPE_FLOT; }
        if (bLigne === void 0) { bLigne = true; }
        //Résultat
        var sResultat = "";
        //Récupération matrice
        var pclMatrice = pclGetMatrice(sNom);
        //La matrice existe ?
        if (pclMatrice === undefined) {
            //Non => échec
            return sResultat;
        }
        //Chaine de formatage
        var clFormat = new WDStd.CParamChaine();
        //Chaine formatage OK ?
        if (bTesteErreur(!bChaineFormat(sFormat, clFormat), 1210 /* eErreurFormat */)) {
            //Non => échec
            return sResultat;
        }
        //Ligne ou colonne OK ?
        if (nLigneOuColonne > (bLigne ? pclMatrice.nGetNbLigne() : pclMatrice.nGetNbColonne)) {
            //Non => tentative d'accès à une ligne en dehors de la matrice
            pclMatrice.SetErreur(1205 /* eErreurDehors */);
            //On lève l'erreur
            bMatriceEnErreur(pclMatrice);
            //Echec
            return sResultat;
        }
        //Récupération nombre colonnes ou lignes
        var nNbColonneOuLigne = bLigne ? pclMatrice.nGetNbColonne() : pclMatrice.nGetNbLigne();
        //Récupération ligne ou colonne C++
        var nLigneOuColonneC = WDStd.nIndiceWLVersC(nLigneOuColonne);
        //Construction de la chaine résultat
        for (var nColonneOuLigne = 0; nColonneOuLigne < nNbColonneOuLigne; nColonneOuLigne++) {
            //Récupération valeur
            var nValeur = pclMatrice.nValeurElem(bLigne ? nLigneOuColonneC : nColonneOuLigne, bLigne ? nColonneOuLigne : nLigneOuColonneC);
            //Chaine contenant un élément
            var sElem = void 0;
            //Récupération type
            var sType = sTypeFormat(sFormat);
            //Type entier ?
            if (sType == sTYPE_ENTIER) {
                //Oui => récupération valeur entier (car NumériqueVersChaine fait un arrondi)
                nValeur = clWDUtil.nArrondiVersZero(nValeur);
            }
            //Oui => indique si valeur nulle format étendu
            var bValeurNulEtendu = (nValeur == 0) && ((sTYPE_ETENDU_MIN + sTYPE_ETENDU_MAJ).indexOf(sType) >= 0);
            //Valeur nulle format étendu ?
            if (bValeurNulEtendu) {
                //Oui => on met la valeur à 1 (puis on remplacera 1 par 0) car bug NumeriqueVersChaine dans ce cas
                nValeur = 1;
            }
            //Oui => récupération valeur formatée
            sElem = clWDUtil.sNumeriqueVersChaine(nValeur, clFormat.m_Valeur);
            //Valeur nulle format étendu ?
            if (bValeurNulEtendu) {
                //Oui => on remplace 1 par 0
                sElem = sElem.replace("1", "0");
            }
            //Dernier élément ?
            if (nColonneOuLigne < nNbColonneOuLigne - 1) {
                //Nom => ajout séparateur
                sElem += "\t";
            }
            //Récupération élément 
            sResultat += sElem;
        }
        //Ligne
        return sResultat;
    }
    // Lecture ligne matrice
    // Entrée :	sNom	Nom de la matrice dont on veut la ligne
    //			nLigne	Indice ligne à lire
    //			sFormat	Format
    // Sortie :	Ligne lue, chaine vide en cas d'erreur
    function MatLitLigne(sNom, nLigne, sFormat) {
        //Lecture ligne
        return MatLitLigneOuColonne(sNom, nLigne, sFormat);
    }
    WDMat.MatLitLigne = MatLitLigne;
    // Lecture colonne matrice
    // Entrée :	sNom		Nom de la matrice dont on veut la ligne
    //			nColonne	Indice colone à lire
    //			sFormat		Format
    // Sortie :	Colone lue, chaine vide en cas d'erreur
    function MatLitColonne(sNom, nColonne, sFormat) {
        //Lecture colonne
        return MatLitLigneOuColonne(sNom, nColonne, sFormat, false);
    }
    WDMat.MatLitColonne = MatLitColonne;
    //Erreur fonction statistique
    var geErreurStat = 0 /* eAucune */;
    // Test erreur statistiques et lève erreur si erreur
    // Entrée :	bTestErreur	Indique si erreur
    //			eErreur		Erreur à lever en cas d'erreur
    // Sortie : true si erreur, false sinon
    function bTesteErreurStat(bTestErreur, eErreur) {
        //Erreur ?
        if (bTestErreur) {
            //Oui => on lève l'erreur
            geErreurStat = eErreur;
        }
        //Indique si erreur
        return bTestErreur;
    }
    // Indique si erreur statistiques
    // Sortie :	true si erreur statistiques, false sinon
    function bErreurStat() {
        //Indique si erreur
        return geErreurStat != 0 /* eAucune */;
    }
    // Récupération matrice statistiques par nom (lève une erreur en cas d'échec)
    // Entrée :	sNom	Nom de la matrice
    // Sortie :	Matrice recherchée, indéfini en cas d'échec (une erreur est levée)
    function pclGetMatriceStat(sNom) {
        //Récupération matrice
        var pclMatrice = gpclTabMatrice[uGetIdMatrice(sNom)];
        //Test matrice
        bTesteErreurStat(pclMatrice === undefined, 5 /* eLimiteOuMatrice */);
        //Matrice recherchée
        return pclMatrice;
    }
    // Récupération des infos d'une matrice
    // Entrée :	sNom		Nom de la matrice
    //			bColonne	Indique si opération sur colonne
    // Sortie:	pclMatrice	Matrice
    //			clNbElem	Nombre d'éléments à traiter
    //			Résultat	true si infos récupérées, false sinon
    function bGetInfoMatrice(sNom, bColonne, clMatrice, clNbElem) {
        //Paramètres OK ?
        if ((sNom === undefined) || (clNbElem === undefined) || (clMatrice === undefined)) {
            //Non => échec
            return false;
        }
        //Oui => récupération matrice
        clMatrice.m_Valeur = pclGetMatriceStat(sNom);
        //La matrice existe ?
        if (clMatrice.m_Valeur === undefined) {
            //Non => échec
            return false;
        }
        //Oui => récupération du nombre d'élément à parcourir
        clNbElem.m_Valeur = bColonne ? clMatrice.m_Valeur.nGetNbLigne() : clMatrice.m_Valeur.nGetNbColonne();
        //Test nombre éléments
        return !bTesteErreurStat(clNbElem.m_Valeur == 0, 1 /* eMatriceVide */);
    }
    // Exécution d'une fonction statistique
    // Entrée :	fnStat		Fonction statistique à executer
    //			sNom		Nom matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			uParamOpt	Paramètre optionnel
    // Sortie :	Résultat exécution fonction
    function nExecuteFoncStat(fnFoncStat, sNom, nIndice, bColonne, uParamOpt) {
        if (uParamOpt === void 0) { uParamOpt = undefined; }
        //Résultat
        var nResult = 0;
        //Fonction OK ?
        if (fnFoncStat === undefined) {
            //Non => échec
            return nResult;
        }
        //RAZ erreur
        geErreurStat = 0 /* eAucune */;
        //Matrice
        var clMatrice = new CParamMatrice();
        //Nombre d'éléments
        var clNbElem = new WDStd.CParamNum();
        //Récupération des infos de la matrice OK ?
        if (!bGetInfoMatrice(sNom, bColonne, clMatrice, clNbElem)) {
            //Non => échec
            return nResult;
        }
        //Oui => calcul
        return fnFoncStat(clMatrice.m_Valeur, nIndice, bColonne, clNbElem.m_Valeur, uParamOpt);
    }
    // Récupération valeur matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice1	Indice ligne ou colonne
    //			bColonne	Indique si nInidice1 est un indice de colonne
    //			nIndice2	Indice de ligne si nIndice1 est un indice de colonne, de colonne sinon
    // Sortue :	Valeur élément désiré
    function nValeurElemMatrice(clMatrice, nIndice1, bColonne, nIndice2) {
        return clMatrice.nValeurElem(bColonne ? nIndice2 : nIndice1, bColonne ? nIndice1 : nIndice2);
    }
    // Somme ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    // Sortie:	Somme ligne ou colonne
    function nStatSomme(clMatrice, nIndice, bColonne, nNbElem) {
        //Résultat
        var nResult = 0;
        //Calcul de la somme de la ligne ou de la colonne
        for (var nLigneOuColonne = 0; nLigneOuColonne < nNbElem; nLigneOuColonne++) {
            //Ajout valeur cellule
            nResult += nValeurElemMatrice(clMatrice, nIndice, bColonne, nLigneOuColonne);
        }
        //Résultat
        return nResult;
    }
    // Somme ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    // Sortie :	Somme ligne ou colonne matrice
    function StatSomme(sNom, nIndice, bColonne) {
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Somme
        return nExecuteFoncStat(nStatSomme, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne);
    }
    WDMat.StatSomme = StatSomme;
    // Min ou max ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    //			bMin		Indique si on calcule le min
    // Sortie:	Min ou max ligne ou colonne
    function nStatMinMax(clMatrice, nIndice, bColonne, nNbElem, bMin) {
        //Résultat
        var nResult = 0;
        //Calcul du min ou max de la ligne ou de la colonne
        for (var nLigneOuColonne = 0; nLigneOuColonne < nNbElem; nLigneOuColonne++) {
            //Récupération valeur cellule
            var nValeur = nValeurElemMatrice(clMatrice, nIndice, bColonne, nLigneOuColonne);
            //Première valeur ou valeur min ou max?
            if ((nLigneOuColonne == 0) || (bMin ? (nValeur < nResult) : (nValeur > nResult))) {
                //Oui => on la récupère
                nResult = nValeur;
            }
        }
        //Résultat
        return nResult;
    }
    // Min ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    // Sortie :	Min ligne ou colonne matrice
    function StatMin(sNom, nIndice, bColonne) {
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Min
        return nExecuteFoncStat(nStatMinMax, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne, true);
    }
    WDMat.StatMin = StatMin;
    // Max ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    // Sortie :	Max ligne ou colonne matrice
    function StatMax(sNom, nIndice, bColonne) {
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Max
        return nExecuteFoncStat(nStatMinMax, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne);
    }
    WDMat.StatMax = StatMax;
    // Moyenne ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    // Sortie:	Moyenne ligne ou colonne
    function nStatMoyenne(clMatrice, nIndice, bColonne, nNbElem) {
        //Moyenne
        return nStatSomme(clMatrice, nIndice, bColonne, nNbElem) / nNbElem;
    }
    //Teste si valeur en dépassement de capcité (lève une erreur si c'est le cas)
    // Entrée :	nValeur	Valeur à tester
    // Sortie : true si dépassement de capacité, false sinon
    function bTesteErreurStatDepassementCapacite(nValeur) {
        //Test dépassement capacité
        return bTesteErreurStat(nValeur == Infinity, 5 /* eLimiteOuMatrice */);
    }
    // Moyenne géométrique ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    // Sortie:	Moyenne géométrique ligne ou colonne
    function nStatMoyenneGeometrique(clMatrice, nIndice, bColonne, nNbElem) {
        //Résultat
        var nResult = 0;
        //Calcul de la moyenne géométrique de la ligne ou de la colonne
        for (var nLigneOuColonne = 0; nLigneOuColonne < nNbElem; nLigneOuColonne++) {
            //Récupération valeur cellule
            var nValeur = nValeurElemMatrice(clMatrice, nIndice, bColonne, nLigneOuColonne);
            //Valeur négative ?
            if (bTesteErreurStat(nValeur < 0, 3 /* eMoyenneGeoNegative */)) {
                //Oui => échec
                return nVALEUR_ERREUR;
            }
            //Non => ajout log valeur
            nResult += Math.log(nValeur);
            //Dépassement capacité ?
            if (bTesteErreurStatDepassementCapacite(nResult)) {
                //Oui => échec
                return nVALEUR_ERREUR;
            }
        }
        //Résultat
        return Math.exp(nResult / nNbElem);
    }
    // Moyenne géométrique C21 ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    // Sortie:	Moyenne géométrique C21 ligne ou colonne
    function nStatMoyenneGeometriqueC21(clMatrice, nIndice, bColonne, nNbElem) {
        //Résultat
        var nResult = 0;
        //Calcul de la moyenne géométrique de la ligne ou de la colonne
        for (var nLigneOuColonne = 0; nLigneOuColonne < nNbElem; nLigneOuColonne++) {
            //Multiplication par valeur cellule
            nResult *= nValeurElemMatrice(clMatrice, nIndice, bColonne, nLigneOuColonne);
            //Dépassement capacité ?
            if (bTesteErreurStatDepassementCapacite(nResult)) {
                //Oui => échec
                return nVALEUR_ERREUR;
            }
        }
        //Résultat strictement positif ?
        if (bTesteErreurStat(nResult <= 0, 3 /* eMoyenneGeoNegative */)) {
            //Non => échec
            return nVALEUR_ERREUR;
        }
        //Résultat
        return Math.exp(Math.log(nResult) / nNbElem);
    }
    // Moyenne harmonique ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    // Sortie:	Moyenne harmonique ligne ou colonne
    function nStatMoyenneHarmonique(clMatrice, nIndice, bColonne, nNbElem) {
        //Résultat
        var nResult = 0;
        //Calcul de la moyenne géométrique de la ligne ou de la colonne
        for (var nLigneOuColonne = 0; nLigneOuColonne < nNbElem; nLigneOuColonne++) {
            //Récupération valeur cellule
            var nValeur = nValeurElemMatrice(clMatrice, nIndice, bColonne, nLigneOuColonne);
            //Valeur nulle ?
            if (bTesteErreurStat(nValeur == 0, 4 /* eDivisionPar0 */)) {
                //Oui => échec
                return nVALEUR_ERREUR;
            }
            //Ajout inverse valeur
            nResult += (1 / nValeur);
        }
        //Résultat
        return nNbElem / nResult;
    }
    // Moyenne ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			eType		TYep moyenne
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    function StatMoyenne(sNom, eType, nIndice, bColonne) {
        if (eType === void 0) { eType = 0 /* eArithmetique */; }
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Fonction calcul moyenne
        var fnMoyenne;
        //Le type de moyenne désirée est
        switch (eType) {
            //Inconnu :
            default:
            //Pas de break : moyenne arithmétique par défaut
            //Arithmétique :
            case 0 /* eArithmetique */:
                //Moyenne arithmétique
                fnMoyenne = nStatMoyenne;
                break;
            //Géométrique :
            case 1 /* eGeometrique */:
                //Moyenne géométrique
                fnMoyenne = nStatMoyenneGeometrique;
                break;
            //Géométrique C21 :
            case 3 /* eGeometrique_C21 */:
                //Moyenne géométrique C21
                fnMoyenne = nStatMoyenneGeometriqueC21;
                break;
            //Harmonique :
            case 2 /* eHarmonique */:
                //Moyenne harmonique
                fnMoyenne = nStatMoyenneHarmonique;
                break;
        }
        //Moyenne
        return nExecuteFoncStat(fnMoyenne, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne);
    }
    WDMat.StatMoyenne = StatMoyenne;
    // Variance ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    //			bVarianceP	Indique si variance P
    // Sortie:	Variance ligne ou colonne
    function nStatVariance(clMatrice, nIndice, bColonne, nNbElem, bVarianceP) {
        if (bVarianceP === void 0) { bVarianceP = false; }
        //Résultat
        var nResult = 0;
        //Au moins deux éléments ?
        if (bTesteErreurStat(nNbElem < 2, 2 /* e2ValeursMin */)) {
            //Non => échec
            return nResult;
        }
        //Oui => Somme
        var nSomme = 0;
        //Somme carrés
        var nSommeCarre = 0;
        //Calcul de la variance de la ligne ou de la colonne
        for (var nLigneOuColonne = 0; nLigneOuColonne < nNbElem; nLigneOuColonne++) {
            //Récupération valeur cellule
            var nValeur = nValeurElemMatrice(clMatrice, nIndice, bColonne, nLigneOuColonne);
            //Ajout valeur
            nSomme += nValeur;
            //Ajout carré valeur
            nSommeCarre += (nValeur * nValeur);
        }
        //Somme au carré
        nSomme *= nSomme;
        //Dépassement capacité ?
        if (bTesteErreurStatDepassementCapacite(nSomme)) {
            //Oui => échec
            return nResult;
        }
        //Résultat
        return ((nNbElem * nSommeCarre) - nSomme) / (nNbElem * (nNbElem - (bVarianceP ? 0 : 1)));
    }
    // Variance ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    // Sortie :	Variance ligne ou colonne matrice
    function StatVariance(sNom, nIndice, bColonne) {
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Variance
        return nExecuteFoncStat(nStatVariance, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne);
    }
    WDMat.StatVariance = StatVariance;
    // Variance P ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    // Sortie :	Variance P ligne ou colonne matrice
    function StatVarianceP(sNom, nIndice, bColonne) {
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Variance P
        return nExecuteFoncStat(nStatVariance, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne, true);
    }
    WDMat.StatVarianceP = StatVarianceP;
    // Ecart type ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    //			bEcartTypeP	Indique si écart type P
    // Sortie:	Ecart type ligne ou colonne
    function nStatEcartType(clMatrice, nIndice, bColonne, nNbElem, bEcartTypeP) {
        if (bEcartTypeP === void 0) { bEcartTypeP = false; }
        //Calcul variance
        var nResult = nStatVariance(clMatrice, nIndice, bColonne, nNbElem, bEcartTypeP);
        // ne doit pas être négatif
        //Résultat strictement négatif ?
        if (bTesteErreurStat(nResult < 0, 3 /* eMoyenneGeoNegative */)) {
            //Oui => échec
            return nVALEUR_ERREUR;
        }
        //Non => racine carrée variance
        return Math.sqrt(nResult);
    }
    // Ecart type ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    // Sortie :	Ecart type ligne ou colonne matrice
    function StatEcartType(sNom, nIndice, bColonne) {
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Variance
        return nExecuteFoncStat(nStatEcartType, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne);
    }
    WDMat.StatEcartType = StatEcartType;
    // Ecart type P ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    // Sortie :	Ecart type P ligne ou colonne matrice
    function StatEcartTypeP(sNom, nIndice, bColonne) {
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Variance
        return nExecuteFoncStat(nStatEcartType, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne, true);
    }
    WDMat.StatEcartTypeP = StatEcartTypeP;
    // Ecart moyen ligne ou colonne matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    // Sortie:	Ecart moyen ligne ou colonne
    function nStatEcartMoyen(clMatrice, nIndice, bColonne, nNbElem) {
        //Au moins deux éléments ?
        if (bTesteErreurStat(nNbElem < 2, 2 /* e2ValeursMin */)) {
            //Non => échec
            return nVALEUR_ERREUR;
        }
        //Oui => calul moyenne
        var nMoyenne = nStatMoyenne(clMatrice, nIndice, bColonne, nNbElem);
        //Somme écarts par rapport à moyenne
        var nSommeEcart = 0;
        //Calcul de la somme des écarts
        for (var nLigneOuColonne = 0; nLigneOuColonne < nNbElem; nLigneOuColonne++) {
            //Ajout écart cellule
            nSommeEcart += Math.abs(nValeurElemMatrice(clMatrice, nIndice, bColonne, nLigneOuColonne) - nMoyenne);
        }
        //Moyenne écarts par rapport à la moyenne
        return nSommeEcart / nNbElem;
    }
    // Ecart moyen ligne ou colonne matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice		Indice ligne ou colonne
    //			bColonne	Indique si indice colonne
    // Sortie :	Ecart moyen ligne ou colonne matrice
    function StatEcartMoyen(sNom, nIndice, bColonne) {
        if (nIndice === void 0) { nIndice = WDStd.nPREMIER_INDICE_WL; }
        if (bColonne === void 0) { bColonne = true; }
        //Variance
        return nExecuteFoncStat(nStatEcartMoyen, sNom, WDStd.nIndiceWLVersC(nIndice), bColonne);
    }
    WDMat.StatEcartMoyen = StatEcartMoyen;
    // Covariance lignes ou colonnes matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice1	Indice première ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    //			nIndice2	Indice deuxième ligne ou colonne
    // Sortie:	Covariance ligne ou colonne
    function nStatCovariance(clMatrice, nIndice1, bColonne, nNbElem, nIndice2) {
        //Au moins un élément ?
        if (nNbElem == 0) {
            //Non => 0
            return 0;
        }
        //Oui => calcul moyenne première ligne ou colonne
        var nMoyenne1 = nStatMoyenne(clMatrice, nIndice1, bColonne, nNbElem);
        //calcul moyenne deuxième ligne ou colonne
        var nMoyenne2 = nStatMoyenne(clMatrice, nIndice2, bColonne, nNbElem);
        //Somme des produits des écarts par rapport à moyenne
        var nSommeProduitEcart = 0;
        //Calcul de la somme des produits des écarts par rapport aux moyennes
        for (var nLigneOuColonne = 0; nLigneOuColonne < nNbElem; nLigneOuColonne++) {
            //Ajout produits écarts valeurs cellules
            nSommeProduitEcart += (nValeurElemMatrice(clMatrice, nIndice1, bColonne, nLigneOuColonne) - nMoyenne1) * (nValeurElemMatrice(clMatrice, nIndice2, bColonne, nLigneOuColonne) - nMoyenne2);
        }
        //Moyenne somme produits écarts par rapport à la moyenne
        return nSommeProduitEcart / nNbElem;
    }
    // Covariance lignes ou colonnes matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice1	Indice preùière ligne ou colonne
    //			nIndice2	Indice deuxième ligne ou colonne
    //			bColonne	Indique si indices colonnes
    // Sortie :	Covariance lignes ou colonnes matrice
    function StatCovariance(sNom, nIndice1, nIndice2, bColonne) {
        if (nIndice1 === void 0) { nIndice1 = WDStd.nPREMIER_INDICE_WL; }
        if (nIndice2 === void 0) { nIndice2 = WDStd.nPREMIER_INDICE_WL + 1; }
        if (bColonne === void 0) { bColonne = true; }
        //Variance
        return nExecuteFoncStat(nStatCovariance, sNom, WDStd.nIndiceWLVersC(nIndice1), bColonne, WDStd.nIndiceWLVersC(nIndice2));
    }
    WDMat.StatCovariance = StatCovariance;
    // Corrélation lignes ou colonnes matrice
    // Entrée :	clMatrice	Matrice
    //			nIndice1	Indice première ligne ou colonne
    //			bColonne	Indique si indice colonne
    //			nNbElem		Nombre d'éléments
    //			nIndice2	Indice deuxième ligne ou colonne
    // Sortie:	Covariance ligne ou colonne
    function nStatCorrelation(clMatrice, nIndice1, bColonne, nNbElem, nIndice2) {
        //Calcul covariance
        var nCovariance = nStatCovariance(clMatrice, nIndice1, bColonne, nNbElem, nIndice2);
        //Erreur ?
        if (bErreurStat()) {
            //Oui => échec
            return nVALEUR_ERREUR;
        }
        //Non => calcul écart type première ligne ou colonne
        var nEcartType1 = nStatEcartType(clMatrice, nIndice1, bColonne, nNbElem, true);
        //Erreur ?
        if (bErreurStat()) {
            //Oui => échec
            return nVALEUR_ERREUR;
        }
        //Non => calcul écart type deuxième ligne ou colonne
        var nEcartType2 = nStatEcartType(clMatrice, nIndice2, bColonne, nNbElem, true);
        //Erreur ou écart type nul ?
        if (bErreurStat() || bTesteErreurStat((nEcartType1 == 0) || (nEcartType2 == 0), 4 /* eDivisionPar0 */)) {
            //Oui => échec
            return nVALEUR_ERREUR;
        }
        //Non => corrélation
        return nCovariance / (nEcartType1 * nEcartType2);
    }
    // Corrélation lignes ou colonnes matrice
    // Entrée :	sNom		Nom de la matrice
    //			nIndice1	Indice preùière ligne ou colonne
    //			nIndice2	Indice deuxième ligne ou colonne
    //			bColonne	Indique si indices colonnes
    // Sortie :	Corrélation lignes ou colonnes matrice
    function StatCorrelation(sNom, nIndice1, nIndice2, bColonne) {
        if (nIndice1 === void 0) { nIndice1 = WDStd.nPREMIER_INDICE_WL; }
        if (nIndice2 === void 0) { nIndice2 = WDStd.nPREMIER_INDICE_WL + 1; }
        if (bColonne === void 0) { bColonne = true; }
        //Variance
        return nExecuteFoncStat(nStatCorrelation, sNom, WDStd.nIndiceWLVersC(nIndice1), bColonne, WDStd.nIndiceWLVersC(nIndice2));
    }
    WDMat.StatCorrelation = StatCorrelation;
    // Numéro dernière erreur statistiques
    // Sortie :	Numéro dernière erreur statistiques
    function StatErreur() {
        // Numéro de la dernière erreur
        return geErreurStat;
    }
    WDMat.StatErreur = StatErreur;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    var COperation = /** @class */ (function () {
        // Constructeur
        function COperation(m_dValeur2, m_pfInverse) {
            this.m_dValeur2 = m_dValeur2;
            this.m_pfInverse = m_pfInverse;
        }
        // Notifie d'inverser l'opération.
        COperation.prototype.oInverse = function () {
            return new this.m_pfInverse(this.m_dValeur2);
        };
        return COperation;
    }());
    var CAddition = /** @class */ (function (_super) {
        __extends(CAddition, _super);
        function CAddition(dValeur2) {
            return _super.call(this, dValeur2, CSoustraction) || this;
        }
        // Effectue l'opération
        CAddition.prototype.voOperation = function (oValeur1) {
            // L'addition est commutative : ignore this.m_bSwap;
            return clWDUtil.oAddition(oValeur1, this.m_dValeur2);
        };
        return CAddition;
    }(COperation));
    var CSoustraction = /** @class */ (function (_super) {
        __extends(CSoustraction, _super);
        function CSoustraction(dValeur2) {
            return _super.call(this, dValeur2, CAddition) || this;
        }
        // Effectue l'opération
        CSoustraction.prototype.voOperation = function (oValeur1) {
            return clWDUtil.oSoustraction(oValeur1, this.m_dValeur2);
        };
        return CSoustraction;
    }(COperation));
    var CMultiplication = /** @class */ (function (_super) {
        __extends(CMultiplication, _super);
        function CMultiplication(dValeur2) {
            return _super.call(this, dValeur2, CDivision) || this;
        }
        // Effectue l'opération
        CMultiplication.prototype.voOperation = function (oValeur1) {
            // La multiplication est commutative : ignore this.m_bSwap;
            return clWDUtil.oMultiplication(oValeur1, this.m_dValeur2);
        };
        return CMultiplication;
    }(COperation));
    var CDivision = /** @class */ (function (_super) {
        __extends(CDivision, _super);
        function CDivision(dValeur2) {
            return _super.call(this, dValeur2, CMultiplication) || this;
        }
        // Effectue l'opération
        CDivision.prototype.voOperation = function (oValeur1) {
            return clWDUtil.oDivision(oValeur1, this.m_dValeur2);
        };
        return CDivision;
    }(COperation));
    var CDivisionInverse = /** @class */ (function (_super) {
        __extends(CDivisionInverse, _super);
        function CDivisionInverse(dValeur2) {
            // L'opération inverse ne change pas, car c'est pour les unitées qui n'ont pas les mêmes grandeurs physiques : a/b et b/a.
            return _super.call(this, dValeur2, CDivisionInverse) || this;
        }
        // Effectue l'opération
        CDivisionInverse.prototype.voOperation = function (oValeur1) {
            return clWDUtil.oDivision(this.m_dValeur2, oValeur1);
        };
        return CDivisionInverse;
    }(COperation));
    // Opération de conversion
    var CConversionUnite = /** @class */ (function () {
        // Constructeur
        function CConversionUnite(m_eUniteSortie, m_ePrecision, m_tabOperations) {
            this.m_eUniteSortie = m_eUniteSortie;
            this.m_ePrecision = m_ePrecision;
            this.m_tabOperations = m_tabOperations;
        }
        return CConversionUnite;
    }());
    ;
    var CUnite = /** @class */ (function () {
        // Constructeur
        function CUnite(m_eType, m_eUnite, m_tabConversions) {
            this.m_eType = m_eType;
            this.m_eUnite = m_eUnite;
            this.m_tabConversions = m_tabConversions;
            // La première conversion est la conversion principale.
        }
        // Trouve la conversion.
        CUnite.prototype.tabGetOperations = function (oUniteSortie) {
            // Si les 2 unités sont identiques, on ne retourne une liste d'opérations vide.
            if (this === oUniteSortie) {
                return [];
            }
            var eUniteSortie = oUniteSortie.m_eUnite;
            // Recherche les opérations directe puis les opérations indirectes exacte puis avec aproximation.
            return this.__tabGetOperationsDirecte(eUniteSortie, false)
                || oUniteSortie.__tabGetOperationsInverse(this.m_eUnite)
                || this.__tabGetOperationsIndirectes(eUniteSortie, true)
                || this.__tabGetOperationsIndirectes(eUniteSortie, false);
        };
        // Trouve une conversion directe.
        CUnite.prototype.__tabGetOperationsDirecte = function (eUniteSortie, bExact) {
            // Recherche une conversion directe.
            var tabConversions = this.m_tabConversions;
            var nNbConversions = tabConversions.length;
            for (var nConversion = 0; nConversion < nNbConversions; nConversion++) {
                var oConversion_1 = tabConversions[nConversion];
                if (oConversion_1.m_eUniteSortie == eUniteSortie) {
                    if (bExact && (1 /* Approchée */ === oConversion_1.m_ePrecision)) {
                        // Ignore les calculs nons exact si demandé.
                        // Comme on a trouvé une conversion non exacte, on sait qu'il n'y a pas une autre.
                        break;
                    }
                    return oConversion_1.m_tabOperations;
                }
            }
            // Pas de conversion directe.
            return undefined;
        };
        // Trouve l'opération inverse
        CUnite.prototype.__tabGetOperationsInverse = function (eUniteEntree) {
            var tabOperations = this.__tabGetOperationsDirecte(eUniteEntree, true);
            if (tabOperations) {
                return tabOperations.map(function (oOperation) { return oOperation.oInverse(); }).reverse();
            }
            return undefined;
        };
        // Trouve une opération indirecte.
        CUnite.prototype.__tabGetOperationsIndirectes = function (eUniteSortie, bExact) {
            // Passer en revue toutes les conversions possibles.
            var tabUnites = __tabGetUnites();
            var oUniteTestee;
            for (var sNomUnite in tabUnites) {
                if (tabUnites.hasOwnProperty(sNomUnite)) {
                    var oUnite = tabUnites[sNomUnite];
                    // Ignore :
                    // - this(déjà testé par __tabGetOperationsDirecte).
                    // - la dernière unité déjà testé (une même unité a plusieurs noms possibles).
                    // - les éléments du mauvais type.
                    if ((this === oUnite) || (oUniteTestee === oUnite) || (oUnite.m_eType != this.m_eType)) {
                        continue;
                    }
                    // On tente la conversion entrée (this) -> intermédiaire -> sortie.
                    var tabOperationsEntreeVersIntermediaire = this.__tabGetOperationsDirecte(oUnite.m_eUnite, bExact);
                    var tabOperationsIntermediaireVersSortie = oUnite.__tabGetOperationsDirecte(eUniteSortie, bExact);
                    if ((undefined !== tabOperationsEntreeVersIntermediaire) && (undefined !== tabOperationsIntermediaireVersSortie)) {
                        return tabOperationsEntreeVersIntermediaire.concat(tabOperationsIntermediaireVersSortie);
                    }
                }
            }
            return undefined;
        };
        return CUnite;
    }());
    ;
    // Allocation du tableau de conversion en lazy.
    var __tabGetUnites = (function () {
        // On stocke les unités dans un tableau associatif. La déclaration n'est pas statique car une même unité peut-être déclaré selon plusieurs noms.
        // Note : l'index est un nom au format standard.
        var ms_oUnites;
        return function __tabGetUnites() {
            function __oDeclareUnite(eType, eUnite, tabNoms, tabConversions) {
                var oUnite = new CUnite(eType, eUnite, tabConversions);
                tabNoms.forEach(function (sNom) {
                    clWDUtil.WDDebug.assert(NSPCS.NSUtil.sGetFormatLogique(sNom) === sNom, "Le nom n'est pas déjà au format standard");
                    ms_oUnites[sNom] = oUnite;
                });
            }
            if (undefined === ms_oUnites) {
                ms_oUnites = {};
                // Aire : 14  unités.
                __oDeclareUnite(0 /* e_aire */, 0 /* e_acre */, ["ACRE"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(4046873e-3)]),
                    new CConversionUnite(12 /* e_square_yard */, 0 /* Exacte */, [new CMultiplication(4840)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 1 /* e_are */, ["ARE"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(1e2)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 2 /* e_barn */, ["B", "BARN"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(1e-28)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 3 /* e_hectare */, ["HA", "HECTARE"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(1e4)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 4 /* e_square_centimeter */, ["CENTIMETRE CARRE", "CM2", "SQUARE CENTIMETER"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(1e-4)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 5 /* e_square_decimeter */, ["DECIMETRE CARRE", "DM2", "SQUARE DECIMETER"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(1e-2)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 6 /* e_square_foot */, ["FT2", "SQ FT", "SQUARE FOOT"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(9290304e-8)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 7 /* e_square_inch */, ["IN2", "SQ IN", "SQUARE INCH"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(64516e-8)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 8 /* e_square_kilometer */, ["KILOMETRE CARRE", "KM2", "SQUARE KILOMETER"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(1e6)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 9 /* e_square_meter */, ["M2", "METRE CARRE", "SQUARE METER"], [
                //					new CConversionUnite(EUnitéAire.e_acre, EPrécision.Approchée, 247105381e-12),
                //					new CConversionUnite(EUnitéAire.e_are, EPrécision.Exacte, 1e-2),
                //					new CConversionUnite(EUnitéAire.e_barn, EPrécision.Exacte, 1e28),
                //					new CConversionUnite(EUnitéAire.e_hectare, EPrécision.Exacte, 1e-4),
                //					new CConversionUnite(EUnitéAire.e_square_centimeter, EPrécision.Exacte, 1e4),
                //					new CConversionUnite(EUnitéAire.e_square_decimeter, EPrécision.Exacte, 1e2),
                //					new CConversionUnite(EUnitéAire.e_square_foot, EPrécision.Approchée, 10763911e-6),
                //					new CConversionUnite(EUnitéAire.e_square_inch, EPrécision.Approchée, 15500031e-4),
                //					new CConversionUnite(EUnitéAire.e_square_kilometer, EPrécision.Exacte, 1e-6),
                //					new CConversionUnite(EUnitéAire.e_square_mile, EPrécision.Approchée, 38610215e-14),
                //					new CConversionUnite(EUnitéAire.e_square_millimeter, EPrécision.Exacte, 1e6),
                //					new CConversionUnite(EUnitéAire.e_square_yard, EPrécision.Approchée, 1195990e-6),
                //					new CConversionUnite(EUnitéAire.e_us_square_mile, EPrécision.Approchée, 38610215e-14)
                ]);
                __oDeclareUnite(0 /* e_aire */, 10 /* e_square_mile */, ["MI2", "SQ MI", "SQUARE MILE", "UK SQ MI", "UK SQUARE MILE"], [
                    new CConversionUnite(9 /* e_square_meter */, 1 /* Approchée */, [new CMultiplication(258998811e-2)]),
                    new CConversionUnite(0 /* e_acre */, 0 /* Exacte */, [new CMultiplication(640)]),
                    new CConversionUnite(12 /* e_square_yard */, 0 /* Exacte */, [new CMultiplication(3097600)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 11 /* e_square_millimeter */, ["MILLIMETRE CARRE", "MM2", "SQUARE MILLIMETER"], [
                    new CConversionUnite(9 /* e_square_meter */, 0 /* Exacte */, [new CMultiplication(1e-6)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 12 /* e_square_yard */, ["SQ YD", "SQUARE YARD", "YD2"], [
                    new CConversionUnite(6 /* e_square_foot */, 0 /* Exacte */, [new CMultiplication(9)]),
                    new CConversionUnite(7 /* e_square_inch */, 0 /* Exacte */, [new CMultiplication(1296)]),
                    new CConversionUnite(9 /* e_square_meter */, 1 /* Approchée */, [new CMultiplication(83612736e-2)])
                ]);
                __oDeclareUnite(0 /* e_aire */, 13 /* e_us_square_mile */, ["US SQ MI", "US SQUARE MILE"], [
                    new CConversionUnite(9 /* e_square_meter */, 2 /* SansObjet */, [new CMultiplication(2589988110336e-6)])
                ]);
                // Angles : 5 unités.
                // => Conversion vers les secondes pour dégrées/minutes/secondes/gard.
                __oDeclareUnite(1 /* e_angle */, 0 /* e_degree */, ["DEGRE", "DEGREE", "\XB0"], [
                    new CConversionUnite(2 /* e_minute */, 0 /* Exacte */, [new CMultiplication(60)]),
                    new CConversionUnite(3 /* e_radian */, 2 /* SansObjet */, [new CMultiplication(Math.PI), new CDivision(180)]),
                    new CConversionUnite(4 /* e_second */, 0 /* Exacte */, [new CMultiplication(36e2)])
                ]);
                __oDeclareUnite(1 /* e_angle */, 1 /* e_grad */, ["GON", "GRAD", "GRADE"], [
                    new CConversionUnite(0 /* e_degree */, 0 /* Exacte */, [new CMultiplication(9e-1)])
                ]);
                __oDeclareUnite(1 /* e_angle */, 2 /* e_minute */, ["'", "MINUTE"], [
                    new CConversionUnite(4 /* e_second */, 0 /* Exacte */, [new CMultiplication(6e1)])
                ]);
                __oDeclareUnite(1 /* e_angle */, 3 /* e_radian */, ["RAD", "RADIAN"], [
                    new CConversionUnite(0 /* e_degree */, 2 /* SansObjet */, [new CMultiplication(18e1), new CDivision(Math.PI)])
                ]);
                __oDeclareUnite(1 /* e_angle */, 4 /* e_second */, ["''", "SECOND", "SECONDE"], []);
                // Consommation : 2 unités.
                // C'est la même formule pour les deux conversions. En effet l'un est une distance par volume et l'autre un volume par distance.
                // Donc il faut faire deux inversions (une pour avoir le coéfficient de la conversion inverse, l'autre car l'unité est dans l'autre sens) => ce que l'on peut simplifier en aucune.
                __oDeclareUnite(2 /* e_consommation */, 0 /* e_liter_per_100_kilometer */, ["L/100 KM", "LITER PER 100 KILOMETER", "LITRE AU CENT KILOMETRE"], [
                    new CConversionUnite(1 /* e_mile_per_gallon */, 2 /* SansObjet */, [new CDivisionInverse(235.215)])
                ]);
                __oDeclareUnite(2 /* e_consommation */, 1 /* e_mile_per_gallon */, ["MI/GAL", "MILE PER GALLON", "MPG"], [
                    new CConversionUnite(0 /* e_liter_per_100_kilometer */, 2 /* SansObjet */, [new CDivisionInverse(235.215)])
                ]);
                // Énergie : 6 unités.
                // L'unité centrale est le joule.
                __oDeclareUnite(3 /* e_energie */, 0 /* e_calorie */, ["CAL", "CALORIE", "CALORIEIT", "IT CAL"], [
                    new CConversionUnite(3 /* e_joule */, 0 /* Exacte */, [new CMultiplication(41868e-4)])
                ]);
                __oDeclareUnite(3 /* e_energie */, 1 /* e_calorieth */, ["CALORIETH", "TH CAL"], [
                    new CConversionUnite(3 /* e_joule */, 0 /* Exacte */, [new CMultiplication(4184e-3)])
                ]);
                __oDeclareUnite(3 /* e_energie */, 2 /* e_electronvolt */, ["ELECTRONVOLT", "EV"], [
                    new CConversionUnite(3 /* e_joule */, 2 /* SansObjet */, [new CMultiplication(16021773e-26)])
                ]);
                __oDeclareUnite(3 /* e_energie */, 3 /* e_joule */, ["J", "JOULE"], []);
                __oDeclareUnite(3 /* e_energie */, 4 /* e_watt_hour */, ["W.H", "WATT HEURE", "WATT HOUR"], [
                    new CConversionUnite(3 /* e_joule */, 0 /* Exacte */, [new CMultiplication(36e2)])
                ]);
                __oDeclareUnite(3 /* e_energie */, 5 /* e_watt_second */, ["W.S", "WATT SECOND", "WATT SECONDE"], [
                    new CConversionUnite(3 /* e_joule */, 0 /* Exacte */, [ /*Liste d'opération optimisé à vide : new CMultiplication(1e0)*/])
                ]);
                // Force : 5 unités.
                // L'unité centrale est le newton.
                __oDeclareUnite(4 /* e_force */, 0 /* e_dyne */, ["DYN", "DYNE"], [
                    new CConversionUnite(3 /* e_newton */, 0 /* Exacte */, [new CMultiplication(1e-5)])
                ]);
                __oDeclareUnite(4 /* e_force */, 1 /* e_kilogram_force */, ["KGF", "KILOGRAM-FORCE"], [
                    new CConversionUnite(3 /* e_newton */, 2 /* SansObjet */, [new CMultiplication(980665e-5)])
                ]);
                // ?????
                __oDeclareUnite(4 /* e_force */, 2 /* e_kilopound */, ["KILOPOUND", "KP"], [
                    new CConversionUnite(3 /* e_newton */, 2 /* SansObjet */, [new CMultiplication(980665e-5)])
                ]);
                __oDeclareUnite(4 /* e_force */, 3 /* e_newton */, ["N", "NEWTON"], []);
                __oDeclareUnite(4 /* e_force */, 4 /* e_pound_force */, ["LBF", "POUND-FORCE"], [
                    new CConversionUnite(3 /* e_newton */, 2 /* SansObjet */, [new CMultiplication(444822162e-8)])
                ]);
                // Longueur : 24 unités.
                __oDeclareUnite(5 /* e_longueur */, 0 /* e_angstrom */, ["ANGSTROM"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(1e-10)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 1 /* e_astronomical_unit */, ["ASTRONOMICAL UNIT", "AU", "UNITE ASTRONOMIQUE"], [
                    new CConversionUnite(10 /* e_meter */, 2 /* SansObjet */, [new CMultiplication(1495978707e2)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 2 /* e_centimeter */, ["CENTIMETER", "CENTIMETRE", "CM"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(1e-2)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 3 /* e_chain */, ["CH", "CHAIN", "GUNTER'S CHAIN"], [
                    new CConversionUnite(5 /* e_foot */, 0 /* Exacte */, [new CMultiplication(66)]),
                    new CConversionUnite(10 /* e_meter */, 1 /* Approchée */, [new CMultiplication(201168396e-7)]),
                    new CConversionUnite(20 /* e_rod */, 0 /* Exacte */, [new CMultiplication(4)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 4 /* e_decimeter */, ["DECIMETER", "DECIMETRE", "DM"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(1e-1)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 5 /* e_foot */, ["FOOT", "FT", "INTERNATIONAL FOOT", "PIED", "UK FOOT", "UK FT"], [
                    new CConversionUnite(7 /* e_inch */, 0 /* Exacte */, [new CMultiplication(12)]),
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(3048e-4)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 6 /* e_french_mile */, ["FRENCH MILE", "MILLE"], [
                    new CConversionUnite(10 /* e_meter */, 2 /* SansObjet */, [new CMultiplication(1949)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 7 /* e_inch */, ["IN", "INCH", "POUCE"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(254e-4)]),
                    new CConversionUnite(11 /* e_mil */, 0 /* Exacte */, [new CMultiplication(1e3)]),
                    new CConversionUnite(16 /* e_pica */, 0 /* Exacte */, [new CMultiplication(6)]),
                    new CConversionUnite(17 /* e_point */, 0 /* Exacte */, [new CMultiplication(72)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 8 /* e_kilometer */, ["KILOMETER", "KILOMETRE", "KM"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(1e3)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 9 /* e_light_year */, ["ANNEE LUMIERE", "L.Y.", "LIGHT YEAR"], [
                    new CConversionUnite(10 /* e_meter */, 2 /* SansObjet */, [new CMultiplication(946073e10)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 10 /* e_meter */, ["M", "METER", "METRE"], [
                    new CConversionUnite(16 /* e_pica */, 0 /* Exacte */, [new CMultiplication(6), new CDivision(254e-4)]),
                    new CConversionUnite(17 /* e_point */, 0 /* Exacte */, [new CMultiplication(72), new CDivision(254e-4)]),
                    new CConversionUnite(21 /* e_us_foot */, 0 /* Exacte */, [new CMultiplication(3937), new CDivision(12e2)]),
                    new CConversionUnite(22 /* e_us_mile */, 0 /* Exacte */, [new CMultiplication(3937), new CDivision(6336e3)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 11 /* e_mil */, ["MIL"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(254e-7)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 12 /* e_mile */, ["MI", "MILE", "UK MI", "UK MILE"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(1609344e-3)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 13 /* e_millimeter */, ["MILLIMETER", "MILLIMETRE", "MM"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(1e-3)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 14 /* e_nautical_mile */, ["MILLE NAUTIQUE", "NAUTICAL MILE", "NMI"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(1852)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 15 /* e_paris_foot */, ["FRENCH MEASURE FOOT", "PARIS FOOT", "PIED DE ROI"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(3248406e-7)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 16 /* e_pica */, ["COMPUTER PICA", "PICA ECRAN", "PICA"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(254e-4), new CDivision(6)]),
                    new CConversionUnite(17 /* e_point */, 0 /* Exacte */, [new CMultiplication(12)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 17 /* e_point */, ["COMPUTER POINT", "POINT ECRAN", "POINT"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(254e-4), new CDivision(72)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 18 /* e_printer_pica */, ["PICA IMPRIMANTE", "PRINTER PICA"], [
                    new CConversionUnite(10 /* e_meter */, 1 /* Approchée */, [new CMultiplication(4217518e-9)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 19 /* e_printer_point */, ["POINT IMPRIMANTE", "PRINTER POINT"], [
                    new CConversionUnite(10 /* e_meter */, 1 /* Approchée */, [new CMultiplication(3514598e-10)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 20 /* e_rod */, ["ROD"], [
                    new CConversionUnite(10 /* e_meter */, 1 /* Approchée */, [new CMultiplication(5029210e-6)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 21 /* e_us_foot */, ["SURVEY FOOT", "US FOOT", "US FT"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(12e2), new CDivision(3937)]),
                    new CConversionUnite(22 /* e_us_mile */, 0 /* Exacte */, [new CDivision(528e1)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 22 /* e_us_mile */, ["US MI", "US MILE"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(6336e3), new CDivision(3937)]),
                    new CConversionUnite(21 /* e_us_foot */, 0 /* Exacte */, [new CMultiplication(528e1)])
                ]);
                __oDeclareUnite(5 /* e_longueur */, 23 /* e_yard */, ["YARD", "YD"], [
                    new CConversionUnite(10 /* e_meter */, 0 /* Exacte */, [new CMultiplication(9144e-4)])
                ]);
                // Magnétisme : 2 unités.
                __oDeclareUnite(6 /* e_magnetisme */, 0 /* e_gauss */, ["GAUSS", "GS"], [
                    new CConversionUnite(1 /* e_tesla */, 0 /* Exacte */, [new CMultiplication(1e-4)])
                ]);
                __oDeclareUnite(6 /* e_magnetisme */, 1 /* e_tesla */, ["TESLA"], [
                    new CConversionUnite(0 /* e_gauss */, 0 /* Exacte */, [new CMultiplication(1e4)])
                ]);
                // Masse : 11 unités.
                __oDeclareUnite(7 /* e_masse */, 0 /* e_carat */, ["CARAT"], [
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(2e-4)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 1 /* e_grain */, ["GR", "GRAIN"], [
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(6479891e-11)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 2 /* e_gram */, ["G", "GRAM", "GRAMME"], [
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(1e-3)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 3 /* e_kilogram */, ["KG", "KILOGRAM", "KILOGRAMME"], [
                    new CConversionUnite(5 /* e_ounce */, 0 /* Exacte */, [new CMultiplication(16), new CDivision(453592437e-9)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 4 /* e_milligram */, ["MG", "MILLIGRAM", "MILLIGRAMME"], [
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(1e-6)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 5 /* e_ounce */, ["AVOIRDUPOIS OUNCE", "ONCE", "OUNCE", "OZ"], [
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(453592437e-9), new CDivision(16)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 6 /* e_pennyweight */, ["DWT", "PENNYWEIGHT"], [
                    new CConversionUnite(1 /* e_grain */, 0 /* Exacte */, [new CMultiplication(24)]),
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(155517384e-11)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 7 /* e_pound */, ["AVOIRDUPOIS POUND", "LB", "LIVRE", "POUND"], [
                    new CConversionUnite(1 /* e_grain */, 0 /* Exacte */, [new CMultiplication(7e3)]),
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(453592437e-9)]),
                    new CConversionUnite(5 /* e_ounce */, 0 /* Exacte */, [new CMultiplication(16)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 8 /* e_ton */, ["T", "TON", "TONNE"], [
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(1e3)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 9 /* e_troy_ounce */, ["TROY OUNCE"], [
                    new CConversionUnite(1 /* e_grain */, 0 /* Exacte */, [new CMultiplication(48e1)]),
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(311034768e-10)]),
                    new CConversionUnite(6 /* e_pennyweight */, 0 /* Exacte */, [new CMultiplication(2e1)])
                ]);
                __oDeclareUnite(7 /* e_masse */, 10 /* e_troy_pound */, ["TROY POUND"], [
                    new CConversionUnite(1 /* e_grain */, 0 /* Exacte */, [new CMultiplication(576e1)]),
                    new CConversionUnite(3 /* e_kilogram */, 0 /* Exacte */, [new CMultiplication(373241722e-9)]),
                    new CConversionUnite(9 /* e_troy_ounce */, 0 /* Exacte */, [new CMultiplication(12)])
                ]);
                // Pression : 18 unités.
                __oDeclareUnite(8 /* e_pression */, 0 /* e_atmosphere */, ["ATM", "ATMOSPHERE"], [
                    new CConversionUnite(15 /* e_pascal */, 0 /* Exacte */, [new CMultiplication(101325)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 1 /* e_bar */, ["BAR"], [
                    new CConversionUnite(15 /* e_pascal */, 0 /* Exacte */, [new CMultiplication(1e5)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 2 /* e_centimeter_of_mercury */, ["CENTIMETER OF MERCURY", "CENTIMETRE DE MERCURE", "CMHG"], [
                    new CConversionUnite(13 /* e_millimeter_of_mercury */, 0 /* Exacte */, [new CMultiplication(1e1)]),
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(1333224e-3)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 3 /* e_centimeter_of_water */, ["CENTIMETER OF WATER", "CENTIMETRE D'EAU", "CMH2O"], [
                    new CConversionUnite(14 /* e_millimeter_of_water */, 0 /* Exacte */, [new CMultiplication(1e1)]),
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(980665e-4)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 4 /* e_dyne_per_square_centimeter */, ["DYN/ CM 2", "DYNE PER SQUARE CENTIMETER"], [
                    new CConversionUnite(15 /* e_pascal */, 0 /* Exacte */, [new CMultiplication(1e-1)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 5 /* e_foot_of_mercury */, ["FOOT OF MERCURY", "FTHG", "PIED DE MERCURE"], [
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(4063666e-2)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 6 /* e_foot_of_water */, ["FOOT OF WATER", "FTH2O", "PIED D'EAU"], [
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(2989067e-3)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 7 /* e_inch_of_mercury */, ["INCH OF MERCURY", "INHG", "POUCE DE MERCURE"], [
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(3386389e-3)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 8 /* e_inch_of_water */, ["INCH OF WATER", "INH2O", "POUCE D'EAU"], [
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(2490889e-4)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 9 /* e_kilogram_force_per_square_centimeter */, ["KGF/CM2", "KILOGRAM-FORCE PER SQUARE CENTIMETER"], [
                    new CConversionUnite(15 /* e_pascal */, 0 /* Exacte */, [new CMultiplication(980665e-1)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 10 /* e_kilogram_force_per_square_meter */, ["KGF/M2", "KILOGRAM-FORCE PER SQUARE METER"], [
                    new CConversionUnite(15 /* e_pascal */, 0 /* Exacte */, [new CMultiplication(980665e-5)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 11 /* e_kilogram_force_per_square_millimeter */, ["KGF/MM2", "KILOGRAM-FORCE PER SQUARE MILLIMETER"], [
                    new CConversionUnite(15 /* e_pascal */, 0 /* Exacte */, [new CMultiplication(980665e1)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 12 /* e_millibar */, ["MBAR", "MILLIBAR"], [
                    new CConversionUnite(15 /* e_pascal */, 0 /* Exacte */, [new CMultiplication(1e2)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 13 /* e_millimeter_of_mercury */, ["MILLIMETER OF MERCURY", "MILLIMETRE DE MERCURE", "MMHG"], [
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(1333224e-4)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 14 /* e_millimeter_of_water */, ["MILLIMETER OF WATER", "MILLIMETRE D'EAU", "MMH2O"], [
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(980665e-5)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 15 /* e_pascal */, ["PA", "PASCAL"], []);
                __oDeclareUnite(8 /* e_pression */, 16 /* e_pound_force_per_square_inch */, ["LBF/IN2", "POUND-FORCE PER SQUARE INCH", "PSI"], [
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(6894757e-3)])
                ]);
                __oDeclareUnite(8 /* e_pression */, 17 /* e_torr */, ["TORR"], [
                    new CConversionUnite(15 /* e_pascal */, 1 /* Approchée */, [new CMultiplication(1333224e-4)])
                ]);
                // Puissance: 2 unités.
                __oDeclareUnite(9 /* e_puissance */, 0 /* e_horsepower */, ["CHEVAL", "HORSEPOWER", "HP"], [
                    new CConversionUnite(1 /* e_watt */, 2 /* SansObjet */, [new CMultiplication(746)])
                ]);
                __oDeclareUnite(9 /* e_puissance */, 1 /* e_watt */, ["W", "WATT"], [
                    new CConversionUnite(0 /* e_horsepower */, 2 /* SansObjet */, [new CDivision(746)])
                ]);
                // Température : 5 unités.
                __oDeclareUnite(10 /* e_temperature */, 0 /* e_degree_celsius */, ["DEGRE CELSIUS", "DEGREE CELSIUS", "\XB0C"], [
                    new CConversionUnite(2 /* e_degree_fahrenheit */, 0 /* Exacte */, [new CMultiplication(18e-1), new CAddition(32)]),
                    new CConversionUnite(4 /* e_kelvin */, 0 /* Exacte */, [new CAddition(27315e-2)])
                ]);
                __oDeclareUnite(10 /* e_temperature */, 1 /* e_degree_centigrade */, ["DEGRE CENTIGRADE", "DEGREE CENTIGRADE"], [
                    new CConversionUnite(0 /* e_degree_celsius */, 1 /* Approchée */, []),
                    new CConversionUnite(4 /* e_kelvin */, 1 /* Approchée */, [new CAddition(27315e-2)])
                ]);
                __oDeclareUnite(10 /* e_temperature */, 2 /* e_degree_fahrenheit */, ["DEGRE FAHRENHEIT", "DEGREE FAHRENHEIT", "\XB0F"], [
                    new CConversionUnite(0 /* e_degree_celsius */, 0 /* Exacte */, [new CSoustraction(32), new CDivision(18e-1)]),
                    new CConversionUnite(4 /* e_kelvin */, 0 /* Exacte */, [new CAddition(45967e-2), new CDivision(18e-1)])
                ]);
                __oDeclareUnite(10 /* e_temperature */, 3 /* e_degree_rankine */, ["DEGRE RANKINE", "DEGREE RANKINE", "\XB0R"], [
                    new CConversionUnite(4 /* e_kelvin */, 0 /* Exacte */, [new CDivision(18e-1)])
                ]);
                __oDeclareUnite(10 /* e_temperature */, 4 /* e_kelvin */, ["K", "KELVIN"], [
                    new CConversionUnite(0 /* e_degree_celsius */, 0 /* Exacte */, [new CSoustraction(27315e-2)]),
                    new CConversionUnite(1 /* e_degree_centigrade */, 1 /* Approchée */, [new CSoustraction(27315e-2)]),
                    new CConversionUnite(2 /* e_degree_fahrenheit */, 0 /* Exacte */, [new CMultiplication(18e-1), new CSoustraction(45967e-2)]),
                    new CConversionUnite(3 /* e_degree_rankine */, 0 /* Exacte */, [new CMultiplication(18e-1)])
                ]);
                // Vitesse : 8 unités.
                __oDeclareUnite(11 /* e_vitesse */, 0 /* e_foot_per_minute */, ["FOOT PER MINUTE", "FT/MIN"], [
                    new CConversionUnite(5 /* e_meter_per_second */, 0 /* Exacte */, [new CMultiplication(508e-5)])
                ]);
                __oDeclareUnite(11 /* e_vitesse */, 1 /* e_foot_per_second */, ["FOOT PER SECOND", "FT/S"], [
                    new CConversionUnite(5 /* e_meter_per_second */, 0 /* Exacte */, [new CMultiplication(3048e-4)])
                ]);
                __oDeclareUnite(11 /* e_vitesse */, 2 /* e_inch_per_second */, ["IN/S", "INCH PER SECOND"], [
                    new CConversionUnite(5 /* e_meter_per_second */, 0 /* Exacte */, [new CMultiplication(254e-4)])
                ]);
                __oDeclareUnite(11 /* e_vitesse */, 3 /* e_kilometer_per_hour */, ["KILOMETER PER HOUR", "KILOMETRE PAR HEURE", "KM/H"], [
                    new CConversionUnite(5 /* e_meter_per_second */, 0 /* Exacte */, [new CDivision(36e-1)])
                ]);
                __oDeclareUnite(11 /* e_vitesse */, 4 /* e_knot */, ["KNOT", "NMI/H", "NOEUD"], [
                    new CConversionUnite(5 /* e_meter_per_second */, 0 /* Exacte */, [new CMultiplication(1852), new CDivision(36e2)])
                ]);
                __oDeclareUnite(11 /* e_vitesse */, 5 /* e_meter_per_second */, ["M/S", "METER PER SECOND", "METRE PAR SECONDE"], [
                    new CConversionUnite(3 /* e_kilometer_per_hour */, 0 /* Exacte */, [new CMultiplication(36e-1)]),
                    new CConversionUnite(4 /* e_knot */, 0 /* Exacte */, [new CMultiplication(36e2), new CDivision(1852)])
                ]);
                __oDeclareUnite(11 /* e_vitesse */, 6 /* e_mile_per_hour */, ["MI/H", "MILE PER HOUR", "MILLE PAR HEURE"], [
                    new CConversionUnite(5 /* e_meter_per_second */, 0 /* Exacte */, [new CMultiplication(44704e-5)])
                ]);
                __oDeclareUnite(11 /* e_vitesse */, 7 /* e_mile_per_second */, ["MI/S", "MILE PER SECOND", "MILLE PAR SECONDE"], [
                    new CConversionUnite(5 /* e_meter_per_second */, 0 /* Exacte */, [new CMultiplication(1609344e-3)])
                ]);
                // Volume : 26 unités.
                __oDeclareUnite(12 /* e_volume */, 0 /* e_barrel */, ["BARREL", "BBL", "TONNEAU"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(1589873e-7)]),
                    new CConversionUnite(24 /* e_us_gallon */, 0 /* Exacte */, [new CMultiplication(42)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 1 /* e_british_imperial_pint */, ["BRITISH IMPERIAL PINT", "PINTE"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(5682610e-10)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 2 /* e_bushel */, ["BOISSEAU", "BUSHEL"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(3523907e-8)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 3 /* e_cord */, ["CORD"], [
                    new CConversionUnite(6 /* e_cubic_foot */, 0 /* Exacte */, [new CMultiplication(128)]),
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(3624556e-6)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 4 /* e_cubic_centimeter */, ["CENTIMETRE CUBE", "CM3", "CUBIC CENTIMETER"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 0 /* Exacte */, [new CMultiplication(1e-6)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 5 /* e_cubic_decimeter */, ["CUBIC DECIMETER", "DECIMETRE CUBE", "DM3"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 0 /* Exacte */, [new CMultiplication(1e-3)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 6 /* e_cubic_foot */, ["CUBIC FOOT", "FT3", "PIED CUBE"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(2831685e-8)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 7 /* e_cubic_inch */, ["CUBIC INCH", "IN3", "POUCE CUBE"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 0 /* Exacte */, [new CMultiplication(16387064e-12)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 8 /* e_cubic_kilometer */, ["CUBIC KILOMETER", "KILOMETRE CUBE", "KM3"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 0 /* Exacte */, [new CMultiplication(1e9)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 9 /* e_cubic_meter */, ["CUBIC METER", "M3", "METRE CUBE"], []);
                __oDeclareUnite(12 /* e_volume */, 10 /* e_cubic_mile */, ["CUBIC MILE", "MI3", "MILLE CUBE"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(4168182e3)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 11 /* e_cubic_millimeter */, ["CUBIC MILLIMETER", "MILLIMETRE CUBE", "MM3"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 0 /* Exacte */, [new CMultiplication(1e-9)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 12 /* e_cubic_yard */, ["CUBIC YARD", "YD3"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(7645549e-7)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 13 /* e_cup */, ["CUP", "TASSE"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(2365882e-10)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 14 /* e_dry_pint */, ["DRY PINT", "DRY PT"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(5506105e-10)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 15 /* e_dry_quart */, ["DRY QT", "DRY QUART"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(1101221e-9)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 16 /* e_gallon */, ["GAL", "GALLON", "IMPERIAL GALLON", "UK GAL", "UK GALLON"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 0 /* Exacte */, [new CMultiplication(454609e-8)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 17 /* e_gill */, ["GI", "GILL", "UK GI", "UK GILL"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(1420653e-10)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 18 /* e_liquid_pint */, ["LIQ PT", "LIQUID PINT"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(4731765e-10)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 19 /* e_liquid_quart */, ["LIQ QT", "LIQUID QUART"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(9463529e-10)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 20 /* e_liter */, ["L", "LITER", "LITRE"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 0 /* Exacte */, [new CMultiplication(1e-3)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 21 /* e_stere */, ["ST", "STERE"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 0 /* Exacte */, [ /*Liste d'opération optimisé à vide : new CMultiplication(1e0)*/])
                ]);
                __oDeclareUnite(12 /* e_volume */, 22 /* e_tablespoon */, ["CUILLERE A SOUPE", "TABLESPOON"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(1478676e-11)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 23 /* e_teaspoon */, ["CUILLERE A CAFE", "TEASPOON"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(4928922e-12)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 24 /* e_us_gallon */, ["US GAL", "US GALLON"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(3785412e-9)])
                ]);
                __oDeclareUnite(12 /* e_volume */, 25 /* e_us_gill */, ["US GI", "US GILL"], [
                    new CConversionUnite(9 /* e_cubic_meter */, 1 /* Approchée */, [new CMultiplication(1182941e-10)])
                ]);
            }
            return ms_oUnites;
        };
    })();
    function __xoGetUnite(sUnite) {
        // L'index est un nom au format standard.
        var oUnite = __tabGetUnites()[NSPCS.NSUtil.sGetFormatLogique(sUnite)];
        if (undefined !== oUnite) {
            return oUnite;
        }
        // Erreur WL :
        // "Unité inconnue : <%1>."
        throw new WDErreur(1204, sUnite);
    }
    // Fonction WL "Conversion".
    function oConversion(oValeur, oUniteEntree, oUniteSortie) {
        var sUniteEntree = String(oUniteEntree);
        var sUniteSortie = String(oUniteSortie);
        // On recherche les unités d'entrée et de sortie.
        var oUniteEntreeDescription = __xoGetUnite(sUniteEntree);
        var oUniteSortieDescription = __xoGetUnite(sUniteSortie);
        // Vérifie que les deux unités sont compatibles.
        if (oUniteEntreeDescription.m_eType !== oUniteSortieDescription.m_eType) {
            // Erreur WL :
            // "Les unités <%1> et <%2> ne sont pas de même type.\nConversion impossible."
            throw new WDErreur(1202, sUniteEntree, sUniteSortie);
        }
        // Trouve la conversion.
        var tabOperations = oUniteEntreeDescription.tabGetOperations(oUniteSortieDescription);
        if (undefined !== tabOperations) {
            // Effectue les opérations.
            return tabOperations.reduce(function (oValeurCourante, oOperation) { return oOperation.voOperation(oValeurCourante); }, oValeur);
        }
        else {
            // Erreur WL :
            // "Erreur interne : un ou plusieurs coefficients de conversion nécessaires à la conversion de <%1> vers <%2> n'ont pas été trouvés."
            throw new WDErreur(1203, sUniteEntree, sUniteSortie);
        }
    }
    WDMat.oConversion = oConversion;
})(WDMat || (WDMat = {}));
