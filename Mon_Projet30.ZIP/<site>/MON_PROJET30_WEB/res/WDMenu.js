// WDMenu.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// Définition des globales définies dans :
// - La page
///#GLOBALS _PAGE_ _PU_
// - StdAction.js
///#GLOBALS _JCL _JSL _JGE
// - WDutil.js
///#GLOBALS bIE bIEAvec11 bSfr bTouch bTouchMobile AppelMethode
// - WDChamp.js
///#GLOBALS WDChamp

// Manipulation des menus
function WDMenu(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChamp.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ bOnglet, tabMenusPopup ]
		var bOnglet = tabParametresSupplementaires[0];
		var tabMenusPopup = tabParametresSupplementaires[1];

		this.m_bOnglet = bOnglet;
		// De la forme { "ID sous option 1": { m_sPopup : "ALIAS Popup 1", m_ePosition : x }, "ID sous option 2": { m_sPopup : "ALIAS Popup 2", m_ePosition : y }, ..., "ID sous option n": { m_sPopup : "ALIAS Popup n", m_ePosition : z } }
		// GP 17/06/2015 : tabMenusPopup est maintenant toujours present
		this.m_tabMenusPopup = tabMenusPopup;
		this.m_oRacine = null;

		//par defaut pas css
		this.m_bMenuGenerationCSS = false;
		//accès rapide au <nav>
		this.m_jqNav = undefined;
	}
};

// Declare l'heritage
WDMenu.prototype = new WDChamp();
// Surcharge le constructeur qui a ete efface
WDMenu.prototype.constructor = WDMenu;

WDMenu.prototype.ms_nPositionBasGauche = 0;
WDMenu.prototype.ms_nPositionHautDroite = 1;
WDMenu.prototype.ms_nPositionBasCentreGlobal = 2;
WDMenu.prototype.ms_nPositionBasDroite = 3;
WDMenu.prototype.ms_nPositionHautGauche = 4;

// Initialisation
WDMenu.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChamp.prototype.Init.apply(this, arguments);

	// Si le menu n'existe pas (menu invisible avec l'option ne pas generer les champ hidden)
	if (this.m_oRacine)
	{
		// Initialise le flag menucss ainsi que le comportement du menucss si necessaire
		this.__InitMenuCSS();		
		// Applique le changement de style et l'affichage des sous menus en survol d'option
		if (this.m_bOnglet)
		{
			// Traite les onglets
			this.__AjouteJSSurvol_Onglets();
		}
		// Traite les sous menus normaux
		this.__AjouteJSSurvol_SousMenus();
	}
};
// Passe en mode editable les barres affichees
WDMenu.prototype.OnDisplay = function(oElementRacine, bAffiche)
{
	// Appel de la methode de la classe de base
	WDChamp.prototype.OnDisplay.apply(this, arguments);

	//relance le calcul d'overflow du menu en cas d'affichage d'un parent
	if (bAffiche && this.fMajMenuOverflow && this.m_jqNav && this.m_jqNav.get(0) && clWDUtil.bEstFils(this.m_jqNav.get(0),oElementRacine))
	{
		this.fMajMenuOverflow();	
	}
};
// Initialise le flag menucss ainsi que le comportement du menucss si necessaire
WDMenu.prototype.__InitMenuCSS = function __InitMenuCSS()
{
	var jqRacine; //la racine peut être le noeud div dww superposable	
	this.m_bMenuGenerationCSS = window.$ && (jqRacine = $(this.m_oRacine)) && (this.m_jqNav = jqRacine.add(jqRacine.children().first()).filter("nav")).length;
	if (!this.m_bMenuGenerationCSS)
	{
		return;
	}
	var clMenu = this;
	var jqNavMenu = this.m_jqNav;
	//- Menu popup
	var sAliasPopup;
	for (sAliasPopup in this.m_tabMenusPopup)
	{
		var jqMenuPopup = jqNavMenu.find("#" + sAliasPopup).closest(".wbMenuOption");
		if (!jqMenuPopup || jqMenuPopup.length == 0)
		{
			continue;
		}
		//comportement au survol et hors survol des options menu popup dans le menu css
		this.__AjouteJSSurvol_OptionGenerique(jqMenuPopup.get(0), this.m_tabMenusPopup[sAliasPopup], "WDMenuOption", "WDMenuOptionSelect", this.__s_MouseOverOptionAffichePopup, this.__s_MouseOverOptionMasquepopup);
	}
	//- Comportement du menu adaptatif  
	var jqUlMenu = jqNavMenu.children("ul.WDOngletMain");
	//info 
	this.m_bEstFilsDeFixed = (jqUlMenu.parents().filter(function() { return $(this).css("position") == "fixed" || $(this).hasClass("fixedcoulisse") }).length);
	//- Deroule 
	jqUlMenu.bind("click", function(event)
	{
		var jqThis = $(event.target).closest(".wbMenuOption");
		if (jqThis && jqThis.closest(".wbMenuMain").hasClass("wbMenuMobile") && jqThis.hasClass("wbAvecSousMenu"))
		{
			var bAffiche = jqThis.hasClass("wbCollapse");
			var jqThisUL = jqThis.toggleClass("wbCollapse").addClass("wbCollapsing").find(".WDSousMenu").first();
			if (bAffiche)
			{
				//vérifie que le menu déroulé ne rentre pas avant de provoquer un scroll inutile
				var nHautVisible = (jqThis.offset().top - $(window).scrollTop());
				var bRentreSansScroller =
					(nHautVisible>0)
				&&	((nHautVisible+jqThis.height()) < (window.innerHeight || $(window).height()))					
				;
				jqThisUL.css("display", "none"); //pour que slideToggle s'y retoruve
				//scroll pour avoir l'option deroulee en haut de l'ecran
				//mais pas si l'élément est dans un épinglé vu que le scroll ne changera rien
				if (!bRentreSansScroller)
				{
					//le menu lui même défile
					if (jqNavMenu.css("overflow") == "auto")
					{
						jqNavMenu.animate({ scrollTop: jqThis.offset().top - jqNavMenu.offset().top + jqNavMenu.scrollTop() }, 300);
					}
					else if (!clMenu.m_bEstFilsDeFixed)
					{
						$(document.documentElement).add(document.body).animate({ scrollTop: jqThis.offset().top }, 300);
					}
				}
			};
			jqThisUL.css("transition", "none").slideToggle(400, function()
			{
				jqThis.removeClass("wbCollapsing");
				//l'overflow hidden n'applique pas vraiment de débordement vu qu'il n'a pas de dimensions
				//cela permet juste que la bordure placé sur ce ul soit visible
				jqThisUL.css("overflow", "hidden").css("display", "").css("transition", ""); //pour que les regles css par @media puisse appliquer un display            
				//recalcule l'overflow car le menu dépasse peut être désormais
				clMenu.fMajMenuOverflow();				
			});
			event.stopPropagation();
		}
	});
	//- Scroll dans le menu
	//Mise e jour du debordement sur le nav
	this.fMajMenuOverflow = function()
	{
		//informations de position du document
		var nScrollTop = window.nBordHautNavigateur!==undefined ? window.nBordHautNavigateur : $(document).scrollTop();
		var nScrollBottom = (window.nHauteurNavigateur!==undefined ? window.nHauteurNavigateur : $(window).height()) + nScrollTop;
		var nScrollLeft = window.nBordGaucheNavigateur!==undefined ? window.nBordGaucheNavigateur : $(document).scrollLeft();
		var nScrollRight = (window.nLargeurNavigateur!==undefined ? window.nLargeurNavigateur : $(window).width()) + nScrollLeft;

		//informations de position du menu
		var nHauteurMenu = jqUlMenu.height();
		var nLargeurMenu = jqUlMenu.width();

		var nNavTop = jqNavMenu.offset().top;
		var nNavBottom = nNavTop + nHauteurMenu;
		var nNavLeft = jqNavMenu.offset().left;
		var nNavRight = nNavLeft + nLargeurMenu;

		//raz le style du nav
		jqNavMenu.css("height", "auto");
		jqNavMenu.css("width", "100%");
		jqNavMenu.css("overflow", "visible");
		jqNavMenu.css("display", "");

		//applique le style sur le nav selon le cas d'affichage
		//overflow uniquement pour le menu mobile sur un écran tactile, ou si la page ne pourra pas être scrollée pour afficher le bas du menu
		if (!(jqNavMenu.hasClass("wbMenuMobile") && (bTouch||clMenu.m_bEstFilsDeFixed) ) || nNavBottom < nScrollTop || nNavRight < nScrollLeft)
		{
			//hors cadre
		}
		else
		{
			//le bas depasse
			if (nNavBottom > nScrollBottom)
			{
				jqNavMenu.css("display", "block").css("height", (nHauteurMenu - (nNavBottom - nScrollBottom)) + "px").css("overflow", "auto");
			}
			//la droite depasse (et n'est pas dans un volet qui s'anime depuis la droite hors écran)
			if (nNavRight > nScrollRight && !jqNavMenu.closest(".wbBarreNavigationVoletAsideDepuisDroite").length)
			{
				jqNavMenu.css("display", "block").css("width", (nLargeurMenu - (nNavRight - nScrollRight)) + "px").css("overflow", "auto");
			}
		}
	};
	//recalcule e chaque modification de la partie affichee dans le navigateur
	$(window).bind("resize scroll", this.fMajMenuOverflow);
	//1er appel
	this.fMajMenuOverflow();
	//TODO OPTIM ? window.requestAnimationFrame ? window.requestAnimationFrame(this.fMajMenuOverflow) : this.fMajMenuOverflow();
	
	//listener de media query
	var fListener = function fListenerMenu(oListener, bMatches, sData, sNouvelleValeur)
	{
		//ne traite que le class=
		if (sData !== "class")
		{
			return sNouvelleValeur;
		}
		jqNavMenu.attr("class", sNouvelleValeur);

		//bloque le cas vertical.souris sur un mobile
		if (jqNavMenu.hasClass("wbMenuSouris") && bTouch && jqNavMenu.hasClass("wbMenuVertical"))//horizontal.mobile non supporté
		{
			jqNavMenu.removeClass("wbMenuSouris").addClass("wbMenuMobile");
		}
		return jqNavMenu.attr("class");
	};
	//1er appel
	jqNavMenu.attr("class", fListener(undefined, true, "class", jqNavMenu.attr("class")));
	//callback donnée pour les futurs appels
	jqNavMenu.data("wbMediaAttrCallback", fListener);

	//init des effets
	this.__InitMenuCSSEffet();

	//repositionne les sous menus selon l'espace disponible pour le menu souris
	if (jqNavMenu.hasClass("wbMenuSouris"))
	{
		var fMajPositionSousMenuQuiDepasse = function()
		{
			//Borne droite
			var nBorneDroite = window.nLargeurNavigateur ? window.nLargeurNavigateur : $(window.document.body).width();
			jqNavMenu.find(".WDSousMenu").each(function()
			{
				var jqSousMenu = $(this);
				//raz 
				jqSousMenu.css({ left: '', right: '' });
				//le sous menu dépasse à droite ?
				if (jqSousMenu.offset().left + jqSousMenu.width() > nBorneDroite)
				{
					//dans le cas du premier sous menu
					//cadre le sous menu à droite

					//1er sous menu de menu hrizontal ?
					if (jqNavMenu.hasClass("wbMenuSouris") && jqSousMenu.closest(".wbMenuOption").parent().hasClass("WDOngletMain"))
					{
						//cadrage à droite du parent
						jqSousMenu.css({ left: 'auto', right: 0 });
					}
					else
					{
						//cadrage du bord droite à gauche du parent
						jqSousMenu.css({ left: 'auto', right: '100%' });
					}
				}
				//sans le faire dépasser à gauche
				if (jqSousMenu.offset().left < 0)
				{
					jqSousMenu.css({ left: 'auto', right: 0 });
				}
			});
		};
		//1er appel d'init
		window.requestAnimationFrame ? window.requestAnimationFrame(fMajPositionSousMenuQuiDepasse) : fMajPositionSousMenuQuiDepasse();
		//et appels lors de redimensionnement
		$(window).bind("resize", fMajPositionSousMenuQuiDepasse);
	}

	//force l'état survol des parents
	jqNavMenu.find(".wbOptionAvecSousMenu").each(function(){
		var jqLien = $(this);
		var jqLienParent = jqLien.closest(".wbOptionAvecSousMenu").children(".wbOptionLien").children(".wbLienMenu");
		if (jqLienParent && jqLienParent.length)
		{
			jqLien.hover(function(){
				//survol
				jqLienParent.addClass("wbSurvol");
		 	},function(){
				//fin survol
				jqLienParent.removeClass("wbSurvol");
		 	});			
		}
	});

};
WDMenu.prototype.__InitMenuCSSEffet = function __InitMenuCSSEffet()
{
    //lecture des effets
    try {
    	var oEffet = JSON.parse((this.m_jqNav.data("effet-menucss")||"").replace(/'/g,'"'));
    }
    catch(__e)
    {
    	oEffet = undefined;
    }
    if (!oEffet)
    {
    	return;
    }
    if (oEffet.type == "store")
    {
    	this.__InitMenuCSSEffetStore(oEffet);
    }
};
WDMenu.prototype.__InitMenuCSSEffetStore = function __InitMenuCSSEffetStore(oEffet)
{
	var reset = function(jqNoeudParent)
	{
		//Sous FF le hover() quitté est appelé avant application du CSS
		//le setTimeout permet de passer après application du CSS 
		//En quittant le survol le CSS appliquera une opacité de 0
		setTimeout(function()
		{
			if (jqNoeudParent.parents("nav").hasClass("wbMenuMobile"))
			{
				return;
			}
			if (jqNoeudParent.find(".WDSousMenu").first().css("opacity") != 0)
			{
				return;
			}
			var nDelai = 0;
			jqNoeudParent.find(".wbOptionSousMenu").find("a").each(function()
			{
				var jqCible = $(this);
				//lien avec sous menu
				if (jqCible.parent(".wbOptionLien").length == 1)
				{
					jqCible = jqCible.closest(".wbOptionAvecSousMenu");
				}
				jqCible
					.stop(true, false)
					.css({ "opacity": 0 })
					.css({ "display": "block" })
					.css("transform", "rotateY(90deg)")
					.css("transition", "none")
				;
				$(this).next("i").stop(true, false).css({ "opacity": 0 });
				//délai entre chaque store
				nDelai += 100;
			});
		}
		, 1);
	};
	this.m_jqNav.find(".wbAvecSousMenu").each(function()
	{
		var jqNoeudParent = $(this);
		jqNoeudParent.find(".wbOptionLien").hover(
		function()
		{
			if (jqNoeudParent.parent("nav").hasClass("wbMenuMobile"))
			{
				return;
			}
			//début
			var nDelai = 0;
			jqNoeudParent.find(".WDSousMenu").first().children().css("perspective", "150px").each(function()
			{
				var jqCible = $(this).find("a").first();
				//jqCible.parent().css("perspective","150px");
				//lien avec sous menu
				if (jqCible.parent(".wbOptionLien").length == 1)
				{
					jqCible.next("i").stop(true, false).delay(oEffet.duree * 1.1).animate({ "opacity": 1 }, 400);
					jqCible = jqCible.closest(".wbOptionAvecSousMenu");
				}

				jqCible
					.css({ "display": "block" })
					.css("transition", "opacity " + (0.75 * oEffet.duree) + "ms ease " + nDelai + "ms, transform " + oEffet.duree + "ms ease " + nDelai + "ms")
					.css("transform", "none")
					.stop(true, false)
					.css({ "opacity": 1 })
				;
				nDelai += (0.25 * oEffet.duree);
			});

		}
		, function()
		{
			//fin
			reset(jqNoeudParent);

		});

		jqNoeudParent.find(".WDSousMenu").first().hover(
		function()
		{
			//rien
		}
		, function()
		{
			//fin
			reset(jqNoeudParent);

		});


		//init
		reset(jqNoeudParent);
	});
};
// Trouve les divers elements : liaison avec le HTML
WDMenu.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
{
	// Appel de la methode de la classe de base
	WDChamp.prototype._vLiaisonHTML.apply(this, arguments);

	// Trouve la racine du menu
	this.m_oRacine = _JGE(this.m_sAliasChamp, document, true, false);
};

// Applique le changement de style et l'affichage des onglets
WDMenu.prototype.__AjouteJSSurvol_Onglets = function __AjouteJSSurvol_Onglets()
{
	// Les options sont les TD avec WDOngletOption comme class
	clWDUtil.bForEachThis(this.m_oRacine.getElementsByTagName("td"), this, function(oOnglet)
	{
		if (this.__bAvecClasseSelect(oOnglet, "WDOngletOption"))
		{
			this.__AjouteJSSurvol_UnOnglet(oOnglet, "WDOngletOption", "WDOngletOptionSelect");
		}
		return true;
	});
};
WDMenu.prototype.__AjouteJSSurvol_UnOnglet = function __AjouteJSSurvol_UnOnglet(oOnglet, sClasse, sClasseSelect)
{
	// Regarde si l'option a un sous menu
	if (clWDUtil.bForEachThis(oOnglet.getElementsByTagName("table"), this, function(oSousMenu)
	{
		// GP 23/03/2015 : TB91864 : Sauf que maintenant la generaion HTML genere toujours la table pour le sous menu on valide le nombre d'options dans le sous menu
		if (oSousMenu.getElementsByTagName("tr").length && clWDUtil.bAvecClasse(oSousMenu.parentNode, "WDSousOnglet"))
		{
			this.__AjouteJSSurvol_OptionSousMenu(oOnglet, oSousMenu, sClasse, sClasseSelect);
			// Il n'y a qu'un sous onglet par onglet
			return false;
		}
		return true;
	}))
	{
		// Si on a pas de sous menu : mettre le code de survol
		this.__AjouteJSSurvol_OptionSimpleOuPopup(oOnglet, sClasse, sClasseSelect);
	}
};

// Applique le changement de style et l'affichage des sous menus en survol d'option
WDMenu.prototype.__AjouteJSSurvol_SousMenus = function __AjouteJSSurvol_SousMenus()
{
	// Liste les fils de la balise et trouve la balise TR si elle existe
	clWDUtil.bForEachThis(this.m_oRacine.getElementsByTagName("tr"), this, function(oOptionMenu)
	{
		// Applique le changement de style et l'affichage des sous menus en survol d'un option
		this.__AjouteJSSurvol(oOptionMenu);
		return true;
	});
};

// Applique le changement de style et l'affichage des sous menus en survol d'un option
WDMenu.prototype.__AjouteJSSurvol = function __AjouteJSSurvol(oOptionMenu)
{
	// Tente avec les style de ligne qui sont des style d'options
	if (this.__bAvecClasseSelect(oOptionMenu, "WDMenuOption"))
	{
		// Regarde si l'option a un sous menu
		var tabSousMenus = oOptionMenu.getElementsByTagName("table");
		// GP 23/03/2015 : TB91864 : Sauf que maintenant la generaion HTML genere toujours la table pour le sous menu on valide le nombre d'options dans le sous menu
		if (tabSousMenus.length && tabSousMenus[0].getElementsByTagName("tr").length)
		{
			this.__AjouteJSSurvol_OptionSousMenu(oOptionMenu, tabSousMenus[0], "WDMenuOption", "WDMenuOptionSelect");
		}
		else
		{
			this.__AjouteJSSurvol_OptionSimpleOuPopup(oOptionMenu, "WDMenuOption", "WDMenuOptionSelect");
		}
	}
};

// Ajoute les fonctions JS en survol pour une option avec un sous menu
WDMenu.prototype.__AjouteJSSurvol_OptionSousMenu = function __AjouteJSSurvol_OptionSousMenu(oOptionMenu, oSousMenu, sClasse, sClasseSelect)
{
	this.__AjouteJSSurvol_OptionGenerique(oOptionMenu, oSousMenu, sClasse, sClasseSelect, this.__s_MouseOverOptionAfficheMenu, this.__s_MouseOverOptionMasqueMenu);
};
WDMenu.prototype.__s_MouseOverOptionAfficheMenu = function __s_MouseOverOptionAfficheMenu(oJSSurvol)
{
	// oJSSurvol.m_oParametres est le sous menu.
	var oSousMenu = oJSSurvol.m_oParametres;
	var oDocument = oSousMenu.ownerDocument;
	var nScrollAvant = clWDUtil.__nGetBodyPropriete(oDocument, "scrollWidth");

	clWDUtil.SetDisplay(oSousMenu, true);

	// GP 01/12/2014 : TB72571 : Si le menu s'ouvre a droite et que l'on n'a pas la place
	var nScrollApres = clWDUtil.__nGetBodyPropriete(oDocument, "scrollWidth");
	if (nScrollAvant < nScrollApres)
	{
		var nLeft = parseInt(clWDUtil.oGetCurrentStyle(oSousMenu).left, 10);
		oSousMenu.style.left = (nLeft - (nScrollApres - nScrollAvant)) + "px";
	}
};
WDMenu.prototype.__s_MouseOverOptionMasqueMenu = function __s_MouseOverOptionMasqueMenu(oJSSurvol)
{
	// oJSSurvol.m_oParametres est le sous menu.
	var oSousMenu = oJSSurvol.m_oParametres;

	clWDUtil.SetDisplay(oJSSurvol.m_oParametres, false);

	// GP 01/12/2014 : TB72571 : Supprime le style ajoute (pour le prochain affichage)
	if ("" != oSousMenu.style.left)
	{
		oSousMenu.style.left = "";
	}
};

// Ajoute les fonctions JS en survol pour une option sans sous menu (mais avec un possible menu popup)
WDMenu.prototype.__AjouteJSSurvol_OptionSimpleOuPopup = function __AjouteJSSurvol_OptionSimpleOuPopup(oOptionMenu, sClasse, sClasseSelect)
{
	// Si on est dans un menu popup
	var tabLiens = oOptionMenu.getElementsByTagName("a");
	if (tabLiens && tabLiens[0] && tabLiens[0].id.length && this.m_tabMenusPopup[tabLiens[0].id])
	{
		// On est sur une option popup
		this.__AjouteJSSurvol_OptionGenerique(oOptionMenu, this.m_tabMenusPopup[tabLiens[0].id], sClasse, sClasseSelect, this.__s_MouseOverOptionAffichePopup, this.__s_MouseOverOptionMasquepopup);
	}
	else
	{
		// On est vraiment sur une option simple
		this.__AjouteJSSurvol_OptionGenerique(oOptionMenu, null, sClasse, sClasseSelect, null, null);
	}
};
WDMenu.prototype.__s_MouseOverOptionAffichePopup = function __s_MouseOverOptionAffichePopup(oJSSurvol)
{
	// Affiche la cellule sans GFI visible
	var oOptionMenu = oJSSurvol.m_oOptionMenu;
	var nX = clWDUtil.nGetBoundingClientRectLeft(oOptionMenu, false);
	var nY = clWDUtil.nGetBoundingClientRectTop(oOptionMenu, false);
	var oPopup = _JGE(oJSSurvol.m_oParametres.m_sPopup, document, true);
	// GP 07/05/2013 : QW232243 : Si la popup est en display:none : impossible de connaitre sa taille
	if (clWDUtil.oGetCurrentStyle(oPopup).display == "none")
	{
		// Ne montre pas la cellule (pour ne pas la voir se deplacer e l'ecran)
		oPopup.style.visibility = "hidden";
		clWDUtil.SetDisplay(oPopup, true);
	}

	switch (oJSSurvol.m_oParametres.m_ePosition)
	{
	case WDMenu.prototype.ms_nPositionBasGauche:
		// Bas gauche
		nY += oOptionMenu.offsetHeight;
		break;
	case WDMenu.prototype.ms_nPositionHautDroite:
		// Haut droite
		nX += oOptionMenu.offsetWidth;
		break;
	case WDMenu.prototype.ms_nPositionBasCentreGlobal:
		// Bas centre par rapport au menu
		nX = clWDUtil.nGetBoundingClientRectLeft(oOptionMenu.parentNode.parentNode, false) + (oOptionMenu.parentNode.parentNode.offsetWidth - oPopup.offsetWidth) / 2;
		nY += oOptionMenu.offsetHeight;
		break;
	case WDMenu.prototype.ms_nPositionBasDroite:
		// Bas droite (oriente vers la gauche)
		nX += oOptionMenu.offsetWidth - oPopup.offsetWidth;
		nY += oOptionMenu.offsetHeight;
		break;
	case WDMenu.prototype.ms_nPositionHautGauche:
		nX -= oPopup.offsetWidth;
		break;
	}
	// Place le style sur la popup
	clWDUtil.RemplaceClassName(oPopup, undefined, "WDMenuPopupVisible");

	// GP 12/11/2012 : QW225710 : Si la cellule est deje affichee (par une autre option de menu ?)
	// Alors on la masque (sinon CelluleAfficheDialogue ne fait rien)
	// GP 13/12/2017 : TB105526 : L'mulation du mouseout avec safari mobile a besoin d'une cellule qui couvre la page page avec une zone de clic.
	if (true === clWDUtil.CelluleAfficheDialogue(oJSSurvol.m_oParametres.m_sPopup, document, 0, bSfr && bTouchMobile ? true : undefined, 0, nX, nY, undefined, oJSSurvol))
	{
		// Uniquement si on a affichee la popup

		// Ajoute un hook sur la popup pour avoir l'entree de la souris
		// Attention, la popup a ete deplacee !!! Il faut recalculer l'objet
		oPopup = _JGE(oJSSurvol.m_oParametres.m_sPopup, document, true);
		clWDUtil.AttacheDetacheEvent(true, oPopup, "mouseover", oJSSurvol.m_pfMouseOver);
		clWDUtil.AttacheDetacheEvent(true, oPopup, "mouseout", oJSSurvol.m_pfMouseOut);
	}
};
WDMenu.prototype.__s_MouseOverOptionMasquepopup = function __s_MouseOverOptionMasquepopup(oJSSurvol)
{
	// Supprime le hook sur la popup
	var oPopup = _JGE(oJSSurvol.m_oParametres.m_sPopup, document, true);
	clWDUtil.AttacheDetacheEvent(false, oPopup, "mouseout", oJSSurvol.m_pfMouseOut);
	clWDUtil.AttacheDetacheEvent(false, oPopup, "mouseover", oJSSurvol.m_pfMouseOver);

	// Appel de CelluleFermeDialogue
	clWDUtil.CelluleFermeDialogue(oJSSurvol.m_oParametres.m_sPopup);

	// Supprime le style sur la popup
	// Attention, la popup a ete deplacee !!! Il faut recalculer l'objet
	oPopup = _JGE(oJSSurvol.m_oParametres.m_sPopup, document, true);
	clWDUtil.RemplaceClassName(oPopup, "WDMenuPopupVisible", undefined);
};

// Code commun de __AjouteJSSurvol_OptionSousMenu et __AjouteJSSurvol_OptionSimpleOuPopup
WDMenu.prototype.__AjouteJSSurvol_OptionGenerique = function __AjouteJSSurvol_OptionGenerique(oOptionMenu, oParametres, sClasse, sClasseSelect, pfAffiche, pfMasque)
{
	// Declare un nouveau survol
	var oJSSurvol =
	{
		m_oOptionMenu: oOptionMenu,
		m_oRacine: this.m_oRacine,
		m_oParametres: oParametres,
		m_sClasse: sClasse,
		m_sClasseSelect: sClasseSelect,
		m_pfAffiche: pfAffiche,
		m_pfMasque: pfMasque,
		m_nTimeoutMouseOut: -1,
		m_pfMouseOver: function() { WDMenu.prototype.__s_MouseOverOption(oJSSurvol); },
		m_pfMouseOut: function() { WDMenu.prototype.__s_MouseOutOption(oJSSurvol); }
	};

	// GP 23/03/2015 : TB91864 : bSfr && bTouchMobile : detecte safari sous iOS
	// La documentation Apple indique : https://developer.apple.com/library/mac/documentation/AppleApplications/Reference/SafariWebContent/HandlingEvents/HandlingEvents.html#//apple_ref/doc/uid/TP40006511-SW6
	// Sauf que cela ne nfonctionne pas. En effet on a plusieurs niveau de survol et on doit garder le click sur le lien.
	// => Filtre et ne place pas le survol sur les elements terminaux sans action (= les vraies entrees de menu sans sous menu et sans popup)
	if (!bSfr || !bTouchMobile || pfAffiche || pfMasque)
	{
		oOptionMenu.onmouseover = oJSSurvol.m_pfMouseOver;
		oOptionMenu.onmouseout = oJSSurvol.m_pfMouseOut;
	}
};
WDMenu.prototype.__s_MouseOverOption = function __s_MouseOverOption(oJSSurvol)
{
	// Annule les mouseout existant sur l'option
	if (-1 !== oJSSurvol.m_nTimeoutMouseOut)
	{
		clWDUtil.ClearTimeout(oJSSurvol.m_nTimeoutMouseOut);
		oJSSurvol.m_nTimeoutMouseOut = -1;
		// Et ne fait rien de plus
		return;
	}

	// GP 25/02/2015 : TB65975 : Maintenant la classe peut changer en survol dans le cas d'une MAJ en AJAX : donc on teste les deux classes possibles mais on ne remplace que celle existante
	clWDUtil.RemplaceClassNameSiExiste(oJSSurvol.m_oOptionMenu, oJSSurvol.m_sClasse, oJSSurvol.m_sClasse + "Hover");
	clWDUtil.RemplaceClassNameSiExiste(oJSSurvol.m_oOptionMenu, oJSSurvol.m_sClasseSelect, oJSSurvol.m_sClasseSelect + "Hover");

	// Remplace la classe
	if (oJSSurvol.m_pfAffiche)
	{
		// Seulement si le menu n'est pas desactive
		// La norme indique que les elements sont retournes dans l'ordre => On demand le premier donc [0]
		var tabLiens = oJSSurvol.m_oOptionMenu.getElementsByTagName("a");
		if (!(tabLiens && (bIE ? tabLiens[0].disabled : tabLiens[0].attributes.getNamedItem("disabled"))))
		{
			oJSSurvol.m_pfAffiche(oJSSurvol);
		}
	}

	// GP 25/02/2015 : TB91450 : Force une reflow avec IE
	WDMenu.prototype.__s_ReflowMenuPourIE(oJSSurvol.m_oRacine);

	// GP 13/12/2017 : TB105526 : Gestion de l'émulation du touch par safari sous mobile
	WDMenu.prototype.__s_TouchMobileSafari(true, oJSSurvol);
};
WDMenu.prototype.__s_MouseOutOption = function __s_MouseOutOption(oJSSurvol)
{
	// S'il n'y a pas deje un timeout existant sur l'option
	if (-1 === oJSSurvol.m_nTimeoutMouseOut)
	{
		// Declare un nouveau mouseout
		oJSSurvol.m_nTimeoutMouseOut = clWDUtil.nSetTimeout(function() { WDMenu.prototype.__s_MouseOutOptionInterne(oJSSurvol); }, clWDUtil.ms_oTimeoutImmediat);
	}

	// GP 13/12/2017 : TB105526 : Gestion de l'émulation du touch par safari sous mobile
	WDMenu.prototype.__s_TouchMobileSafari(false, oJSSurvol);
};
WDMenu.prototype.__s_MouseOutOptionInterne = function __s_MouseOutOptionInterne(oJSSurvol)
{
	// Supprime la marque du timeout
	oJSSurvol.m_nTimeoutMouseOut = -1;

	// GP 25/02/2015 : TB65975 : Maintenant la classe peut changer en survol dans le cas d'une MAJ en AJAX : donc on teste les deux classes possibles mais on ne remplace que celle existante
	clWDUtil.RemplaceClassNameSiExiste(oJSSurvol.m_oOptionMenu, oJSSurvol.m_sClasse + "Hover", oJSSurvol.m_sClasse);
	clWDUtil.RemplaceClassNameSiExiste(oJSSurvol.m_oOptionMenu, oJSSurvol.m_sClasseSelect + "Hover", oJSSurvol.m_sClasseSelect);
	// Et masque le menu
	if (oJSSurvol.m_pfMasque)
	{
		oJSSurvol.m_pfMasque(oJSSurvol);
	}

	// GP 25/02/2015 : TB91450 : Force une reflow avec IE
	WDMenu.prototype.__s_ReflowMenuPourIE(oJSSurvol.m_oRacine);
};

// GP 25/02/2015 : TB91450 (et autres) : Force une reflow avec IE en HTML5
WDMenu.prototype.__s_ReflowMenuPourIE = function __s_ReflowMenuPourIE(oElement)
{
	if (clWDUtil.bHTML5 && bIEAvec11)
	{
		var sLargeur = oElement.style.width;
		oElement.style.width = "";
		oElement.offsetWidth;
		oElement.style.width = sLargeur;
	}
};
// GP 13/12/2017 : TB105526 : Gestion de l'émulation du touch par safari sous mobile
WDMenu.prototype.__s_TouchMobileSafari = bSfr && bTouchMobile ? (function()
{
	// L'idée est que tout clic hors de la popup ferme la popup.
	// ON perd l'accès direct à un champ hors de la popup mais on arrive à fermer celle-ci.
	var oJSSurvolLocal = null;
	function __OnTouchStart()
	{
		if (oJSSurvolLocal)
		{
			WDMenu.prototype.__s_MouseOutOption(oJSSurvolLocal);
			oJSSurvolLocal = null;
			document.body.focus();
		}
	}
	return function(bSurvol, oJSSurvol)
	{

		if (bSurvol)
		{
			if (oJSSurvol.m_oParametres && oJSSurvol.m_oParametres.m_sPopup)
			{
				var oDialogue = clWDUtil.m_oDialogues[oJSSurvol.m_oParametres.m_sPopup];
				if (oDialogue && oDialogue.m_oCelluleGFI)
				{
					$(oDialogue.m_oCelluleGFI).one("click", __OnTouchStart);
					oJSSurvolLocal = oJSSurvol;
				}
			}
		}
		else
		{
			oJSSurvolLocal = null;
		}
	};
})() : clWDUtil.m_pfVide;

// Indique si un element est avec une classe donnee : "Classe" ou "ClasseSelect"
WDMenu.prototype.__bAvecClasseSelect = function __bAvecClasseSelect(oElement, sClasse)
{
	return clWDUtil.bAvecClasse(oElement, sClasse) || clWDUtil.bAvecClasse(oElement, sClasse + "Select");
};

// Execute le clic sur le fond d'une option
WDMenu.prototype.OnClick = function OnClick(oEvent)
{
	if (this.m_bDansOnClick)
	{
		return;
	}

	// Filtre les clics qui sont sur la zone du lien
	var oSource = clWDUtil.oGetOriginalTarget(oEvent);

	// On ne fait l'action que si le clic n'est pas sur la zone du lien
	// GP 11/06/2020 : QW326744 : Remonte les parent pour voir si on n'est pas dans un lien de menu. Permet de gérer le cas des libellés CSS (on n'est forcément pas directement sur le lien).
	// Avec certaines version de firefox, on recoit la balise texte a l'interieur du lien
	if (!oSource || ($ && $(oSource).closest("a.wbLienMenu")) || clWDUtil.bBaliseEstTag(oSource, "a") || (oSource.parentNode && clWDUtil.bBaliseEstTag(oSource.parentNode, "a")))
	{
		return;
	}

	// On trouve maintenant l'action en consultant le href du lien
	var oTR = oSource;
	while (oTR && !clWDUtil.bBaliseEstTag(oTR, "tr"))
	{
		// Ne remonte pas jusqu'au document
		if (oTR == document.body || clWDUtil.bAvecClasse(oTR,"wbOptionFleche"))
		{
			return;
		}

		oTR = oTR.parentNode;
	}

	// Recupere la balise A
	var tabA = oTR.getElementsByTagName("a");
	if (tabA && tabA.length)
	{
		var oA = tabA[0];
		if (oA)
		{
			var sAction = oA.href;
			if (sAction && sAction.length)
			{
				// Ancien code : pour etre sur que cela fonctionne si les nouveau appels ne fonctionne pas
				if (sAction.substring(0, "javascript:".length) == "javascript:")
				{
					sAction = sAction.substring("javascript:".length);
					eval(sAction);
				}
				else
				{
					try
					{
						// GP 04/03/2013 : Nouveau code qui fonctionne aussi si on n'est pas sur un lien
						// Sauf que on part en boucle avec Firefox
						this.m_bDansOnClick = true;
						if (document.createEvent && oA.dispatchEvent)
						{
							// Methode WC3 (ne fonctionne pas avec Firefox)
							var oEventLocal = document.createEvent("MouseEvents");
							oEventLocal.initMouseEvent("click", true, false, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
							oA.dispatchEvent(oEventLocal);
						}
						else if (bIE && oA.click)
						{
							// Methode pour IE en quirks
							oA.click();
						}
						else
						{
							// Ancien code au cas ou
							eval(sAction);
						}
					}
					finally
					{
						this.m_bDansOnClick = false;
					}
				}
			}
		}
	}
};

// Appel depuis le JS
//WDMenu.prototype.s_ExecuteMenu = function s_ExecuteMenu(sAliasOption, sCible, sOptions)
function _JEM(sAliasOption, sTarget, sNomBlank, sOptions, bSubmit)
{
	// GP 03/12/2012 : Avec submit ?
	if (bSubmit)
	{
		_JSL(_PAGE_, sAliasOption, sTarget, sNomBlank, sOptions, "MENU_SUBMIT");
	}
	else
	{
		// YB 25/07/2003 :	On ne peut pas faire back apres avoir utiliser un menu
		// -> on utiliser FONCNAME_CHANGELOCATION au lieu de FONCNAME_REPLACELOCATION
		// GP 24/03/2016 : TB97244 : Tente de repousser les paramètres de la page en ignorant les paramètres d'une précédente action
		// Note : il faudrait faire ce code dans le moteur sur le traitement de URL()
		// substring(1) : ignore le ? au début
		var tabParametres = ((window.location.search && window.location.search.substring(1).split("&")) || []);
		clWDUtil.bForEachInverse(tabParametres, function(sParametre, nParametre)
		{
			var sParametreDebut = sParametre.substr(0, 3);
			if (("WD_" == sParametreDebut) || ("ID=" == sParametreDebut))
			{
				tabParametres.splice(nParametre, 1);
			}
			return true;
		});
		tabParametres.unshift("ID=" + sAliasOption);
		tabParametres.unshift("WD_ACTION_=MENU");
		_JCL(_PU_ + "?" + tabParametres.join("&"), sTarget, sNomBlank, sOptions);
	}
};

// Manipulation des barres de navigation .wbChampBarreNavigation
function WDBarreNavigation(/*sAliasChamp,sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires,tabParametresSupplementaires*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChamp.prototype.constructor.apply(this, arguments);
		this.m_oBarreNavigation = undefined;
		this.m_jqBarreNavigation = undefined;
		this.m_jqAside = undefined;
	}
};

// Declare l'heritage
WDBarreNavigation.prototype = new WDChamp();
// Surcharge le constructeur qui a ete efface
WDBarreNavigation.prototype.constructor = WDBarreNavigation;

// Initialisation
WDBarreNavigation.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChamp.prototype.Init.apply(this, arguments);
};
// Trouve les divers elements : liaison avec le HTML
WDBarreNavigation.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
{
	// Appel de la methode de la classe de base
	WDChamp.prototype._vLiaisonHTML.apply(this, arguments);

	// Trouve la racine de la barre de naviation et son bouton burger
	this.m_oBarreNavigation = _JGE(this.m_sAliasChamp, document, true, false);

	this.m_jqBarreNavigation = $(this.m_oBarreNavigation).closest(".wbChampBarreNavigation");
	this.m_jqAside = this.m_jqBarreNavigation.find("aside").first();

	//par defaut n'est pas visible dans l'affichage compacte
	//note : ajouter cette classe par JS fait que jqAside sera temporairement visible alors qu'il faut (peut-�tre) le masquer
	//mais tant que l'etat de la barre elle m�me wbBarreCompacte/wbBarreEtendue ne sera pas en dur dans un @media il y aura toujours ce clignottement du au data-media de la barre
	this.m_jqAside.addClass("wbCollapse");

	//listener de media query
	var oWDBarreNavigation = this;
	var fListener = function fListenerMenu(oListener, bMatches, sData, sNouvelleValeur)
	{
		//ne traite que le class=
		if (sData !== "class")
		{
			return sNouvelleValeur;
		}
		if (oListener.balise.hasClass("wbCollapse") != (sNouvelleValeur.indexOf('wbCollapse') > -1))
		{
			oWDBarreNavigation.__EnrouleDeroule(true);
		}
		return sNouvelleValeur;
	};
	//callback donnÃ©e pour les futurs appels
	this.m_jqAside.data("wbMediaAttrCallback", fListener);

	//active le touch ?
	var oThis = this;
	var jqAside = this.m_jqAside;
	//esc pour fermer
	$(window).on("keyup.wb.effet.barrenav.ferme",function(jqEvent){
		if (jqEvent.keyCode === 27 && oThis.m_jqBarreNavigation.hasClass("wbBarreCompacte") && !oThis.m_jqAside.hasClass("wbCollapse"))
		{
			oThis.__EnrouleDeroule();
		}
	});
	//maj effet init pour permettre le fonctionnement des swipes
	this.__MajEffet();

	//click en dehors referme
	this.fFermeAuClicEnDehors = function(jqEvent){

		//attention que clientX semble être dans la vue et donc relatif au bord haut du navigateur
		var X = (jqEvent.touches && jqEvent.touches.length && jqEvent.touches[0].clientX) ? jqEvent.touches[0].clientX : jqEvent.clientX;
//		var Y = (jqEvent.touches && jqEvent.touches.length && jqEvent.touches[0].clientY) ? jqEvent.touches[0].clientY : jqEvent.clientY;
		var bClicSousBarre = true;//quel intérêt ? en plus c'est difficile sachant que la barre peut être épinglée ou pas Y>jqAside.closest(".wbChampBarreNavigation").offset().top+jqAside.closest(".wbChampBarreNavigation").height();
		//click à droite du volet de la barre de navigation
		if 
		(	bClicSousBarre
		&&	(!jqAside.hasClass("wbCollapse"))//jqAside[0].contains(jqEvent.target)
		&&	(	(oThis.oEffet.sens==0 && X > jqAside.width())
				//click Ã  gauche du volet de la barre de navigation
			||	(oThis.oEffet.sens==1 && X < jqAside.offset().left))
		 )
		{
			//ferme
			oThis.__EnrouleDeroule();
			$(window).off("click.wb.effet.barrenav.ferme");
		}
	};

	this.m_jqDocument = $(document.documentElement);
	$(document.getElementById("page")).swipe(
	{	
		preventDefaultEvents:false,  //à gérer au cas par cas
		swipeStatus : function(event, phase, direction, distance) 
    	{
    		//que pour barre de navigation avec volet amovible coulissant
    		if (!event.touches || !oThis.oEffet || !oThis.oEffet.coulisse || !oThis.m_jqBarreNavigation.hasClass("wbBarreCompacte"))
			{
				return;
			}
    		if (phase=="start")
    		{
    			if (event.touches.length!==1)
				{
					return;
				}
    			this.bAutoriseDrag = false;
	    		if (event && event.touches && event.touches.length===1 && (oThis.oEffet.sens==0 ? (event.touches[0].clientX<10) : (($(window).width()-event.touches[0].clientX)<10) ) )
    			{
    				//permet l'ouverture
    				oThis.__EnrouleDeroule(true);
    				jqAside[0].nLargeurAside = jqAside.width();
    				oThis.m_jqDocument.css("transition","");
    				jqAside.css("transition","").css("transform","translateX(" + (oThis.oEffet.sens==0  ? -jqAside[0].nLargeurAside : jqAside[0].nLargeurAside) + "px)");					
    				this.bAutoriseDrag = true;
    			}
    			else
				{
					//voir même cela pourrait être un simple clic
					//$(window).trigger("click.wb.effet.barrenav.ferme",event);//peut être que le click a eu lieu hors panneau
					//oThis.fFermeAuClicEnDehors(event);	
					//event.stopPropagation();
				}
			}
			if (!this.bAutoriseDrag)
			{
				return;
			}
			event.preventDefault();
			function annule()
			{
				oThis.__EnrouleDeroule(false,function(){
					jqAside[0].dTranslateX=undefined;
				});
			}
			function ouvre()
			{ 				
				if (oThis.oEffet.pousse)
				{
					oThis.m_jqDocument.css("transition","transform " + (oThis.oEffet.duree||400) + "ms");
					if (oThis.oEffet.sens==0)
					{
						oThis.m_jqDocument.css("transform","translateX(" +jqAside[0].nLargeurAside + "px)");	
					}
					else 
					{
						oThis.m_jqDocument.css("transform","translateX(" + -jqAside[0].nLargeurAside + "px)");	
					}
				}				
				else 
				{
					jqAside.css("transition","transform " + (oThis.oEffet.duree||400) + "ms").css("transform","");
				}
			}
			function deplace() 
			{
				if (oThis.oEffet.pousse)
				{
					if (oThis.oEffet.sens==0)
					{
						oThis.m_jqDocument.css("transform","translateX(" + (jqAside[0].dTranslateX =Math.min(dOffset,jqAside[0].nLargeurAside)) + "px)"); 
					}
					else 
					{
						oThis.m_jqDocument.css("transform","translateX(" + (jqAside[0].dTranslateX =Math.max(dOffset,-jqAside[0].nLargeurAside)) + "px)"); 
					}					
				}
				else
				{
					if (oThis.oEffet.sens==0)
					{
						jqAside.css("transform","translateX(" + (jqAside[0].dTranslateX =Math.min(dOffset-jqAside[0].nLargeurAside,0)) + "px)");
					}
					else 
					{
						jqAside.css("transform","translateX(" + (jqAside[0].dTranslateX =Math.max(jqAside[0].nLargeurAside+dOffset,0)) + "px)");
					}
				}	
			}
			var d = (direction=="left" ? -distance : distance);
			var dOffset = oThis.oEffet.sens==0 
				? Math.max(d,0)
				: Math.min(d,0)
			;
			this.bAutoriseDrag=false;
			if (this.timerRafDeplace)
			{
				cancelAnimationFrame(this.timerRafDeplace);
				this.timerRafDeplace=undefined;
			}
			if (phase == "end")
			{
				if ((oThis.oEffet.sens==0 ? direction == "left" : direction == "right"))
				{
					annule();
				}
				else 
				{
					ouvre();
				}
			}
			else if (phase == "cancel")
			{				
				annule();				
			}
			else 
			{
				this.bAutoriseDrag=true;
				this.timerRafDeplace = requestAnimationFrame(function(){
					deplace(distance);
				});
			}				
    	}
    });
	jqAside.swipe(
	{
		preventDefaultEvents : false,
		swipeStatus : function(event, phase, direction, distance) 
		{

			//que pour barre de navigation avec volet amovible coulissant
			if (!event.touches || !oThis.oEffet || !oThis.oEffet.coulisse || !oThis.m_jqBarreNavigation.hasClass("wbBarreCompacte"))
			{
				return;
			}
			function annule()
			{ 
				if (distance===0)//si 0 rien à annuler
				{		
					if (jqAside[0].eventStart)
					{
						//voir même cela pourrait être un simple clic
						//$(window).trigger("click.wb.effet.barrenav.ferme",event);//peut être que le click a eu lieu hors panneau
						oThis.fFermeAuClicEnDehors(jqAside[0].eventStart);	
						event.stopPropagation();								
					}
					return;
				}
				if (oThis.oEffet.pousse)
				{
					if (oThis.oEffet.sens==0)
					{
						oThis.m_jqDocument.css("transition","transform " + (oThis.oEffet.duree||400) + "ms").css("transform","translateX(" + (jqAside[0].nLargeurAside) + "px)"); 
					}
					else 
					{
						oThis.m_jqDocument.css("transition","transform " + (oThis.oEffet.duree||400) + "ms").css("transform","translateX(" + (-jqAside[0].nLargeurAside) + "px)"); 
					}					
				}
				else
				{
					jqAside.css("transition","transform " + (oThis.oEffet.duree||400) + "ms").css("transform",""); 
				}				
			}
			function ferme(/*d*/)
			{
				oThis.__EnrouleDeroule(false,function(){
					jqAside[0].dTranslateX=undefined;
				});
			}
			function deplace() 
			{ 
				if (oThis.oEffet.pousse)
				{
					if (oThis.oEffet.sens==0)
					{
						oThis.m_jqDocument.css("transform","translateX(" + (jqAside[0].dTranslateX =Math.max(0,jqAside[0].nLargeurAside+dOffset)) + "px)"); 
					}
					else 
					{
						oThis.m_jqDocument.css("transform","translateX(" + (jqAside[0].dTranslateX =(-jqAside[0].nLargeurAside+dOffset)) + "px)"); 
						jqAside[0].dTranslateX = -jqAside[0].dTranslateX ;
					}					
				}
				else
				{
					jqAside.css("transform","translateX(" + (jqAside[0].dTranslateX =(dOffset)) + "px)");
				}	
			}
			event.preventDefault();
			var d = (direction=="left" ? -distance : (direction=="right" ? distance : 0));
			var dOffset = oThis.oEffet.sens==0 
				? Math.min(d,0)
				: Math.max(d,0)
			;				
			if (this.timerRafDeplace)
			{
				cancelAnimationFrame(this.timerRafDeplace);
				this.timerRafDeplace=undefined;
			}
			if (phase == "start")
			{
				if (event.touches.length!==1)
				{
					return;
				}
				jqAside.css("transition","");
				oThis.m_jqDocument.css("transition","");				
				jqAside[0].dTranslateX = undefined;		
				jqAside[0].eventStart = event;		
				return;
			}
			
			if (!jqAside[0].eventStart)
			{
				return;
			}

			if (phase == "end")
			{				
				if (dOffset!==0 && (oThis.oEffet.sens==0 ? direction == "left" : direction == "right"))
				{
					ferme();
				}
				else 
				{
					annule();
				}
			}
			else if (phase == "cancel")
			{
				annule();
			}
			else 
			{
				this.timerRafDeplace = requestAnimationFrame(function(){
					deplace(distance);
				});
			}
		}		    
	});	
};

// Lit les proprietes
WDBarreNavigation.prototype.GetProp = function GetProp(eProp/*, oEvent, oValeur, oChamp*/)
{
	switch (eProp)
	{
	case this.XML_CHAMP_PROP_NUM_ENROULE:
		return this.m_jqAside.hasClass("wbCollapse");
	default:
		// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
		return WDChamp.prototype.GetProp.apply(this, arguments);
	}
};

// Ecrit les proprietes
WDBarreNavigation.prototype.SetProp = function SetProp(eProp, oEvent, oValeur/*, oChamp, oXMLAction*/)
{
	// Implementation de la classe de base
	oValeur = WDChamp.prototype.SetProp.apply(this, arguments);
	switch (eProp)
	{
	case this.XML_CHAMP_PROP_NUM_ENROULE:
		if (this.m_jqBarreNavigation.hasClass("wbBarreCompacte") && (this.m_jqAside.hasClass("wbCollapse") != !!oValeur))
		{
			this.__EnrouleDeroule(true);
		}
	default:
		return oValeur;
	}
};

//Appel suite Ã  l'action d'enroule/deroule
WDBarreNavigation.prototype.OnEnrouleDeroule = function OnEnrouleDeroule()
{
	this.__EnrouleDeroule();
	//event.stopPropagation(); //empeche l'action WL ?  il faudrait l'event
	//reprend l'event
	if (arguments.callee && arguments.callee.caller && arguments.callee.caller.arguments && arguments.callee.caller.arguments[0])
	{
		arguments.callee.caller.arguments[0].stopPropagation();
	}
};
WDBarreNavigation.prototype.__MajEffet = function __MajEffet()
{
    //lecture des effets
    try {
    	this.oEffet = JSON.parse((this.m_jqBarreNavigation.attr("data-effet-barrenav")||"").replace(/'/g,'"'));
    }
    catch(__e)
    {
    	this.oEffet = undefined;
    }
    return this.oEffet;
};
//enroule/deroule
WDBarreNavigation.prototype.__EnrouleDeroule = function __EnrouleDeroule(bForce,fCallbackApresEffet)
{
	var oThis = this;
	//blindage des pre conditions
	if (!this.m_jqAside.length)
	{
		return;
	}
	
	//place dans le contexte pour les closures
	var jqAside = this.m_jqAside;
	var jqBarre = this.m_jqBarreNavigation;

	//faut il afficher? 
    var bAffiche = jqAside.hasClass("wbCollapse");

	//var jqBurger = $(this.m_oBoutonBurger);
	//- Comportement

	//peut on l'afficher?
	//refuse d'ouvrir le volet sur une barre étendue
	if ( (bForce!==true || bAffiche) && !jqBarre.hasClass("wbBarreCompacte"))
	{
		return;
	}
    //bascule et note que c'est en cours
    jqAside.toggleClass("wbCollapse").addClass("wbCollapsing");            
    if (bAffiche)
    {
		//en attendant l'attribut Btn On/off, le bouton bascule son etat actif
		//NON => mieux vaut attendre le bouton On/Off
		//jqBurger.addClass("wbActif");	        	
    	jqAside.css("display","none");//pour que slideToggle s'y retrouve
    }
    else
    {
		//en attendant l'attribut Btn On/off, le bouton bascule son etat actif
		//NON => mieux vaut attendre le bouton On/Off
		//jqBurger.removeClass("wbActif");     	
		jqAside.css("display","block");//pour que slideToggle s'y retrouve
    }
    jqAside.css("transition","none").stop(true,false);/*blindage clics rapides*/

    //lecture des effets
    var oEffet = this.__MajEffet();

	$(window).off("click.wb.effet.barrenav.ferme");	
	if (bAffiche && oEffet && oEffet.bMobileLike)//à faire avec ou sans bForce
	{
	    if (oEffet && oEffet.bACoteBarreNav)
		{
			jqAside.addClass("wbBarreNavigationVoletAsideLateral").add(jqBarre);//.css("marginTop",$(window).scrollTop());	margin inutile non?		
		}		
		else 
		{
			jqAside.css("height","calc(100vh - " +   (jqBarre.height() + jqBarre.offset().top - $(window).scrollTop() ) +"px)" );
		}
		//et empêche le scroll de page 
		//mais pas en desktop car retirer l'ascenseur change la largeur
		oThis.m_jqDocument.add(document.body)/*.add(document.getElementById("page"))*/.addClass("wbOverflowHiddenX") ;
		
		//en effet mobile like l aside fait la pleine largeur avec un gfi ombré 
		jqAside.addClass("wbBarreNavigationVoletAsideGFI");
		

		//if (!bTouch)//inutile pour le tactile car sera traité par le touchstart levé plus tôt
		{
			//décalé 1ms pour ne pas prendre le clic qui vient d'afficher le volet
			setTimeout(function(){$(window).on("click.wb.effet.barrenav.ferme",oThis.fFermeAuClicEnDehors);},1);
		}
	}
    if (oEffet && oEffet.largeur!==undefined)
    {
    	if (!oEffet.largeur || parseInt(oEffet.largeur[0])===0)
		{
			jqAside.css("max-width","").css("width","auto");
		}
		else
		{
    		jqAside.css("max-width",oEffet.largeur).css("width","");
		}
    }

    var oAnimation = {};
    if (oEffet && oEffet.coulisse)
    {
    	var dLargeurPourcentage = parseFloat(oEffet.largeur) * 0.01;
	    jqAside[0].nLargeurAside = dLargeurPourcentage==0 ? jqAside.width() : (dLargeurPourcentage * window.nLargeurNavigateur);

    	//class pour appliquer le GFI 
    	//note : je remarque qu'au premier affichage aucune transition n'est faite sur l'ombre de GFI
    	//		l'aside est display:none initialement
    	switch(oEffet.sens)
    	{
    		default:
    		case 0://gauche
    			jqAside.removeClass("wbBarreNavigationVoletAsideDepuisDroite");
    		break;
    		case 1://droite
				jqAside.addClass("wbBarreNavigationVoletAsideDepuisDroite");
    		break;
    	}
	    oAnimation = 
    	{
			duration : (oEffet.duree||400)
		,	easing : "linear"
		, 	complete : function()
	        {
	        	jqAside	        	
	        		.removeClass("wbCollapsing")
	        		.css("overflow","visible").css("display","").css("transition","")
	        		.css("opacity",bAffiche ? "1" : "")
	        	;
	        	//retire la transformation uniquement si on masque le volet
	        	if (!bAffiche) 
	        	{
	        		jqAside.css("transform","");
	        	}

				if (oEffet.bMobileLike)
				{
					if (bAffiche)
					{
						
					}
					else
					{
						jqAside.removeClass("wbBarreNavigationVoletAsideGFI").css("height","").add(jqBarre).css("marginTop","");
						oThis.m_jqDocument.add(document.body)/*.add(document.getElementById("page"))*/.removeClass("wbOverflowHiddenX");
						oThis.m_jqDocument.css("transform","");
					}
				}

	        	!fCallbackApresEffet || fCallbackApresEffet();
	        	AppelMethode(WDChamp.prototype.ms_sOnDisplay, [jqAside[0], bAffiche]);
	        }    		
	    ,	progress : function(animation/*, progress, remainingMs*/)
		    {
				function tween(dAvant,dApres,dNow) 
				{
					//return dAvant + (dApres-dAvant) * dNow;	
					//comme en java	
					var retour = dApres * dNow + (1-dNow) * dAvant;
					if (Math.abs(retour) < 0.1)//évite de tomber dans l'écritue scientifique Xe-Y
					{
						return Math.round(retour*10000000000)/10000000000;
						}
					return retour;
				}  		    	

				//prend le now linéaire
		    	var now = bAffiche ? animation.tweens[0].now : (1-animation.tweens[0].now);
		    	//applique un cubic bezier
		    	var oBezier = new clWDUtil.WDBezier(0,0,0.3,1);	
		    	now = oBezier.dCalcule( now, animation.duration );

			    //cas de  translation amorcée par le doigt
		    	var dDecalageCourant = jqAside[0].dTranslateX||0;
				if (oEffet.pousse)
				{	
					var dDecalageAvant = bAffiche ? 0 : (dDecalageCourant||jqAside[0].nLargeurAside);
					var dDecalageApres = bAffiche ? jqAside[0].nLargeurAside : 0;
			    								
		    		var d = tween(dDecalageAvant,dDecalageApres,now);

		    		var nTranslateXAside = (oEffet.sens==0 ? -jqAside[0].nLargeurAside : jqAside[0].nLargeurAside);
		    		if (bIEAvec11)
					{
						//sous IE la translation appliquée sur <html> ne répercute psa de décalage de l'aside, donc le calcul est différent

						nTranslateXAside =
						 oEffet.sens==0 
						 ? tween(dDecalageAvant,dDecalageApres,now)+nTranslateXAside
						 : tween(dDecalageApres,dDecalageAvant,now)
					}
					
					jqAside.css("transform","translateX(" + nTranslateXAside + "px)");
					oThis.m_jqDocument.css("transform","translateX(" + (oEffet.sens==0 ? d : -d) + "px)");
				}
				else 
				{
					var dDecalageAvant = bAffiche ? (oEffet.sens==0 ? -jqAside[0].nLargeurAside : jqAside[0].nLargeurAside) : dDecalageCourant;
					var dDecalageApres = bAffiche ? 0 : (oEffet.sens==0 ? -jqAside[0].nLargeurAside : jqAside[0].nLargeurAside);
			    					
					var d = tween(dDecalageAvant,dDecalageApres,now);
					jqAside.css("transform","translateX(" + d + "px)");
				}
		    }
    	};
    }
    else if (oEffet && !oEffet.coulisse)
    {
    	//comme un tiroir
	    oAnimation = {
	    	duration : (oEffet.duree||400)
	    , 	complete : function()
	        {
	        	jqAside	        	
	        		.removeClass("wbCollapsing")
	        		.css("overflow","visible").css("display","").css("transition","").css("opacity",bAffiche ? "1" : "")
	        	;
	        	!fCallbackApresEffet || fCallbackApresEffet();
	        	AppelMethode(WDChamp.prototype.ms_sOnDisplay, [jqAside[0], bAffiche]);
	        }
	    ,	progress : function(animation, progress/*, remainingMs*/)
		    {
		    	var dNow = progress;
		    	var dAvant = bAffiche ? -15 : 0;//petit parallax
		    	var dApres = !bAffiche ? -15 : 0;
		    	var dTop = dApres * dNow + (1-dNow) * dAvant;
		    	jqAside.css("marginTop", dTop);
		    	jqAside.css("opacity", bAffiche ? dNow : 1-dNow);
		    	if (oEffet.pousse)
				{
					jqBarre.css("marginBottom",jqAside.height());
					//rmq : cas où la barre est (ou est dans) une épingle => impossible de pousser ainsi (sugg : pousser en décalant le top du frère?)
				}
		    }
		};
    }

    //raz les transitions
	jqAside.css("transition","");
	if (oEffet && oEffet.pousse)
	{
		oThis.m_jqDocument.css("transition","");
	}

    if (!oEffet || bForce)//pas d'anim pour le mode forcé car cela n'est pas cohérent avec l'affichage appliqué sur le positionnement par les @media
    {
    	//affichage simple
    	if (bAffiche)
		{
			jqAside.css("opacity",1).show();//le masquage en édition place un opacity:0
		}
		else
		{
			jqAside.css("display","");	
			jqBarre.css("marginBottom",0);//raz le style qui pousse
		}
		// GP 26/02/2018 : TB107502 : La modification de la révision 193595 n'est vraiment pas claire.
		// => Temporairement, ajout d'un blindage pour essayer d'améliorer (au moins de ne pas faire planter).
		if (oEffet)
		{
			oEffet.duration = 0;
		}
		else
		{
			// GP 26/02/2018 : TB107502 : Sortie ici dans ce cas. Sinon au premier clic le menu se referme (= l'animation semble être l'inverse de l'état du menu).
			return;
		}
    	// //appelle la fin d'animation
    	// !oAnimation.complete || oAnimation.complete.apply(jqAside[0],[]);		
    	// return;	
    }

    if (oEffet.coulisse)
    {
    	//comme une fenêtre coulissante
    	jqAside.css("display","block").animate({opacity : bAffiche }, oAnimation );     	
    }
    else
    {
    	//comme un tiroir
	    jqAside.slideToggle(oAnimation); 
	}

	if (bAffiche)
	{
  		if (oAnimation.progress)
		{
			$(window).on("resize.wb.effet.barrenav",function(){
				jqAside[0].nLargeurAside = jqAside.width();
				oAnimation.progress.apply(jqAside[0],[ {duration : oAnimation.duration , tweens : [{now : 1}]  }  ]);
			});	
		}		
	}
	else 
	{
		$(window).off("resize.wb.effet.barrenav");
	}

};