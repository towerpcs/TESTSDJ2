// WDOnglet.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - StdAction.js
///#GLOBALS _JGE
// - WDUtil.js
///#GLOBALS bIE AppelMethode
// - WDChamp.js
///#GLOBALS WDChamp WDChampParametres
// - Autres
///#GLOALS $

//////////////////////////////////////////////////////////////////////////
// Manipulation des onglets

var WDOnglet = (function ()
{
	"use strict";

	var WDVolet = (function ()
	{
		"use strict";

		// Manipule un volet

		function __WDVolet(oOnglet, nIndiceVolet)
		{
			// + 1 car les volets sont avec les indices WL donc qui commencent a 1
			var sAlias = oOnglet.m_sAliasChamp + '_' + (nIndiceVolet + 1);
			// Trouve les elements : titre et corps
			this.m_oTitre = document.getElementById(sAlias);
			this.m_oCorps = document.getElementById('dww' + sAlias);
			this.m_oLien = this.m_oTitre.getElementsByTagName("a")[0];
			// Memorise notre indice
			this.m_nIndiceVolet = nIndiceVolet;

			if (this.m_oTitre)
			{
				// Hook le clic dans le titre
				var oThis = this;
				var oTmpOnglet = oOnglet;
				this.m_fOnClick = this.m_oTitre.onclick;
				this.m_oTitre.onclick = function (oEvent) { oThis.OnClick(oEvent || event, oTmpOnglet); };
			}
		}

		// Membres statiques
		var ms_ePosVolet_Haut = 0;
		var ms_ePosVolet_Bas = 1;
		var ms_ePosVolet_Gauche = 2;
		var ms_ePosVolet_Droite = 3;

		// Clic sur un onglet
		__WDVolet.prototype.OnClick = function OnClick(oEvent, oOnglet)
		{
			// Filtre le cas de l'onglet desactive
			if (this.m_oLien)
			{
				// IE : regarde la propriete disabled
				if (bIE)
				{
					if (this.m_oLien.disabled)
					{
						return;
					}
				}
				else
				{
					// Parcours les attributs de this.m_oLien pour voir si l'attribut disabled existe
					var tabAttributs = this.m_oLien.attributes;
					var i;
					var nLimiteI = tabAttributs.length;
					for (i = 0; i < nLimiteI; i++)
					{
						var oAttribut = tabAttributs.item(i);

						// Si l'attribut existe => on ne change pas l'onglet
						if (oAttribut.nodeName.toLowerCase() === "disabled")
						{
							return;
						}
					}
				}
			}

			// Indique le clic au parent
			oOnglet.OnClick(oEvent, this.m_nIndiceVolet);

			// Puis execute le code de click existant
			if (this.m_fOnClick)
			{
				this.m_fOnClick.apply(this.m_oTitre, [oEvent]);
			}
		};

		__WDVolet.prototype.Affiche = function Affiche(bAffiche, oOnglet)
		{
			// GP 22/10/2012 : Uniquement si la visibilit� change
			if ((undefined !== this.m_bAffiche) && (bAffiche == this.m_bAffiche))
			{
				return;
			}

			// Affiche ou masque le volet
			clWDUtil.SetDisplay(this.m_oCorps, bAffiche);

			if (bAffiche)
			{
				// GP 08/01/2016 : TB89341 : GF indique que c'est ce qu'il faut faire
				clWDUtil.m_oNotificationsImagesVisibles.LanceNotifications(this, this.m_oCorps);
			}

			// Change le style du volet
			// GP 07/05/2013 : TB82261 : Remplace la classe existante (pour ne pas perdre le reste des classes car la g�n�ration HTML place plus de une classe)
			var tabStyle = bAffiche ? oOnglet.m_tabStyleAffiche : oOnglet.m_tabStyleMasque;
			clWDUtil.RemplaceClassName(this.m_oTitre, tabStyle[0], tabStyle[1]);

			// Supprime ou affiche la barre de separation
			// GP 23/03/2015 : TB73819 : "0px" est invalide en particulier ne HTML5
			var sEpaisseur = bAffiche ? "0" : "1px";
			switch (oOnglet.m_ePosition)
			{
			case ms_ePosVolet_Haut:
				this.m_oTitre.style.borderBottomWidth = sEpaisseur;
				break;
			case ms_ePosVolet_Bas:
				this.m_oTitre.style.borderTopWidth = sEpaisseur;
				break;
			case ms_ePosVolet_Gauche:
				this.m_oTitre.style.borderRightWidth = sEpaisseur;
				break;
			case ms_ePosVolet_Droite:
				this.m_oTitre.style.borderLeftWidth = sEpaisseur;
				break;
			}

			if (!bIE)
			{
				this.m_oTitre.style.borderCollapse = bAffiche ? "separate" : "collapse";
			}

			// Force la MAJ des champs dans l'onglet (on n'exclus aucun champ)
			AppelMethode(WDChamp.prototype.ms_sOnDisplay, [this.m_oCorps, bAffiche]);

			// Relance le calcul des champs dispositions (pour le cas ou un champ est dans le volet)
			if (window.$)
			{
				$(window).trigger("trigger.wb.disposition.visible.maj");
			}
		};

		// Calcule si le lien est actif
		__WDVolet.prototype.bActif = function bActif()
		{
			// Si le lien est grise
			if (this.m_oLien.disabled)
			{
				return false;
			}

			// Si le lien est desactive
			if (this.m_oLien.readOnly || this.m_oLien.attributes['READONLY'])
			{
				return false;
			}
			return true;
		};

		// Change la hauteur du volet
		__WDVolet.prototype.SetHauteur = function SetHauteur(nHauteur)
		{
			this.m_oCorps.firstElementChild.firstElementChild.firstElementChild.height = clWDUtil.GetDimensionPxPourStyle(nHauteur);
		};

		return __WDVolet;
	})();

	// Manipulation des onglets
	function __WDOnglet(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChamp.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ nNbOnglets, ePosition, tabStyle ]
			var nNbOnglets = tabParametresSupplementaires[0];
			var ePosition = tabParametresSupplementaires[1];
			var tabStyle = tabParametresSupplementaires[2];

			this.m_nNbOnglets = nNbOnglets;
			this.m_tabOnglets = [];
			this.m_ePosition = ePosition;
			this.m_tabStyleMasque = tabStyle;
			// On ne fait pas Array.reverse car la modification est "inplace"
			this.m_tabStyleAffiche = [];
			var nStyle;
			for (nStyle = tabStyle.length - 1; 0 <= nStyle; nStyle--)
			{
				this.m_tabStyleAffiche.push(tabStyle[nStyle]);
			}
		}
	}

	// Declare l'heritage
	__WDOnglet.prototype = new WDChamp();
	// Surcharge le constructeur qui a ete efface
	__WDOnglet.prototype.constructor = __WDOnglet;

	// Initialisation
	__WDOnglet.prototype.Init = function Init()
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype.Init.apply(this, arguments);

		// Construit le tableau des onglets
		var i;
		var nLimiteI = this.m_nNbOnglets;
		for (i = 0; i < nLimiteI; i++)
		{
			// Construit un onglet
			this.m_tabOnglets.push(new WDVolet(this, i));
		}
	};

	// Affiche un volet sur un clic utilisateur
	__WDOnglet.prototype.OnClick = function OnClick(oEvent, nIndiceVolet)
	{
		// N'active le volet que s'il est actif
		if (this.m_tabOnglets[nIndiceVolet].bActif())
		{
			// Active le volet
			this.AfficheVolet(nIndiceVolet);
		}

		// Appel le PCode navigateur de modification
		this.RecuperePCode(this.ms_nEventNavModifSimple)(oEvent);
	};

	// Recupere la valeur
	__WDOnglet.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp)
	{
		// Conversion de la valeur en booleen
		var nValeur = parseInt(sValeur, 10);

		// Appel de la methode de la classe de base et retour de son resultat
		return WDChamp.prototype.GetValeur.apply(this, [oEvent, nValeur, oChamp]);
	};


	// Changement du volet selectionne
	__WDOnglet.prototype.SetValeur = function SetValeur(oEvent, sValeur/*, oChamp*/)
	{
		// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
		WDChamp.prototype.SetValeur.apply(this, arguments);

		var nValeur = parseInt(sValeur, 10);
		if (!isNaN(nValeur) && (nValeur >= 1))
		{
			// On force la selection car la valeur renvoie par le serveur est forcement valide et
			// Que la commande sur el ..Etat des volets peut ne pas encore etre execute
			this.AfficheVolet(nValeur - 1);
		}

		return nValeur;
	};

	// Lit les proprietes
	__WDOnglet.prototype.GetProp = function GetProp(eProp/*, oEvent*//*, oValeur*//*, oChamp*/)
	{
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_OCCURRENCE:
			// Traite le cas de ..Occurrence
			return this.m_nNbOnglets;
		default:
			// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
			return WDChamp.prototype.GetProp.apply(this, arguments);
		}
	};

	// Affiche un volet
	__WDOnglet.prototype.AfficheVolet = function AfficheVolet(nIndiceVolet)
	{
		// Masque tous les volets sauf le volet a activer
		var i;
		var nLimiteI = this.m_nNbOnglets;
		for (i = 0; i < nLimiteI; i++)
		{
			// Masque le volet
			if (i != nIndiceVolet)
			{
				this.m_tabOnglets[i].Affiche(false, this);
			}
		}
		this.m_tabOnglets[nIndiceVolet].Affiche(true, this);

		// Change la valeur du champ cache qui donne l'onglet affiche
		// + 1 car l'indice est WL pour :
		//	- La lecture en JS
		//	- Le submit au serveur qui prend un indice WL
		this._vSetValeurChampFormulaire(nIndiceVolet + 1);
	};

	// Change la hauteur des onglets (pour l'AJAX)
	__WDOnglet.prototype.HauteurVolet = function HauteurVolet(nHauteur)
	{
		// Applique la methode sur tous les volets
		var i;
		var nLimiteI = this.m_nNbOnglets;
		for (i = 0; i < nLimiteI; i++)
		{
			// Change la taille
			this.m_tabOnglets[i].SetHauteur(nHauteur);
		}
	};

	// Notifie l'affichage / masquage
	__WDOnglet.prototype.OnDisplay = function OnDisplay(oElementRacine, bAffiche)
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype.OnDisplay.apply(this, arguments);
		//cas o� le champ est masqu�
		if (!bAffiche)
		{
			return;
		}
		if (window.$)
		{
			$(window).trigger("wbOngletVisible");
		}
	};

	return __WDOnglet;
})();

// Champ bandeau d�filant : le but n'est pas de faire un vrai champ mais de faire un wrapper autour des fonctions qui g�rent le champ
var WDBandeauDefilant = (function()
{
	"use strict";

	// Manipulation d'un champ image (avec defilement ou vignette)
	function __WDBandeauDefilant(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChampParametres.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
		}
	}

	// Declare l'heritage
	__WDBandeauDefilant.prototype = new WDChampParametres();
	// Surcharge le constructeur qui a ete efface
	__WDBandeauDefilant.prototype.constructor = __WDBandeauDefilant;

	// Trouve les divers elements : liaison avec le HTML
	__WDBandeauDefilant.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
	{
		// Appel de la methode de la classe de base
		WDChampParametres.prototype._vLiaisonHTML.apply(this, arguments);

		this.m_oChampJQuery = $(_JGE(this.m_sAliasChamp, document));
	};

	// Applique les parametres
	__WDBandeauDefilant.prototype._vAppliqueParametres = function _vAppliqueParametres(/*oParametreFusion*/)
	{
		WDChampParametres.prototype._vAppliqueParametres.apply(this, arguments);

		var oChampJQuery = this.m_oChampJQuery;

		// Analyse this.m_oParametres
		// m_bDefilementActive Si il le d�filement est activ�
		oChampJQuery.wbDefilementSet(this.m_oParametres.m_bDefilementActive);

		// Analyse this.m_oDonnees
		// m_tabPlans			D�tails des propri�t�s des plans
		clWDUtil.bForEach(this.m_oDonnees.m_tabPlans, function(oPlan, nPlanC)
		{
			oChampJQuery.wbPlanVisibleSet(nPlanC + 1, oPlan.m_bVisible);
			return true;
		});
	};

	__WDBandeauDefilant.prototype.SetValeur = function SetValeur(oEvent, sValeur/*, oChamp*/)
	{
		sValeur = WDChampParametres.prototype.SetValeur.apply(this, arguments);

		// wbPlanSet accepte des indices WL
		return this.m_oChampJQuery.wbPlanSet(sValeur);
	};
	__WDBandeauDefilant.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp)
	{
		sValeur = WDChampParametres.prototype.GetValeur.apply(this, arguments);

		// GP 07/11/2016 : QW279533 : Utilise le champ formulaire pour avoir la valeur furture (sinon on a la valeur avant animation)
//		return this.m_oChampJQuery.wbPlanGet();
		return parseInt(oChamp.value, 10);
	};

	__WDBandeauDefilant.prototype.__SetDefilement = function __SetDefilement(bDefilement)
	{
		this.m_oParametres.m_bDefilementActive = bDefilement;
		this.m_oChampJQuery.wbDefilementSet(bDefilement);
	};

	// Pour le WL

	// BandeauLanceD�filement
	__WDBandeauDefilant.prototype.Lance = function Lance()
	{
		this.__SetDefilement(true);
	};
	// BandeauArr�teD�filement
	__WDBandeauDefilant.prototype.Arrete = function Arrete()
	{
		this.__SetDefilement(false);
	};

	// BandeauPremier
	__WDBandeauDefilant.prototype.Premier = function Premier()
	{
		// wbPlanSet accepte des indices WL
		this.m_oChampJQuery.wbPlanSet(1, { bBoucle: true, bSensCorrectionIncrement: true });
	};

	// BandeauPr�c�dent
	__WDBandeauDefilant.prototype.Precedent = function Precedent()
	{
		// false, true : recule en bouclant
		this.m_oChampJQuery.wbPlanAvanceRecule(false, true);
	};

	// BandeauSuivant
	__WDBandeauDefilant.prototype.Suivant = function Suivant()
	{
		// true, true : avance en bouclant
		this.m_oChampJQuery.wbPlanAvanceRecule(true, true);
	};

	// BandeauDernier
	__WDBandeauDefilant.prototype.Dernier = function Dernier()
	{
		this.m_oChampJQuery.wbPlanSet(this.m_oChampJQuery.wbPlanOccurrenceGet(), { bBoucle: true, bSensCorrectionIncrement: false });
	};

	return __WDBandeauDefilant;
})();