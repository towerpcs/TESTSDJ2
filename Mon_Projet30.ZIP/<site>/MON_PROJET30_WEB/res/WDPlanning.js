// WDPlanning.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - StdAction.js
///#GLOBALS _JGE
// - WDUtil.js
///#GLOBALS bIE nIE bIEQuirks bIEQuirks9Max bIEAvec11 bIE11Plus bEdge bFF bWK bTouch WDTypeAvance WDPopupSaisie WDStyleCache
// AppelMethode
// - WDChamp.js
///#GLOBALS WDChamp WDChampParametresHote
// - WDDrag.js
///#GLOBALS WDDrag WDDragTouch
// - WDLangage.js
///#GLOBALS clWLangage
// - jQuery
///#GLOBALS $

// Manipulation des champs agenda et planning
function WDAPBase(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChampParametresHote.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]

		// Pas encore de vue
		this.m_oVue = null;
		this.m_bBloqueClicSuivant = false;

		this.m_oParametresResizeVisible = null;

		// GP 10/02/2016 : Plus de valeur undefined
		this.m_nBloqueOnResize = 0;

		// GP 24/07/2017 : C'est inutile, en cas de changement de tranche on re�oit un "resize" et donc le champ est redessin�
//		// S'abonne � la notification de changement de tranche (dans le framework V2)
//		// => Temporaire : dans le framework v2, les champs recoivent la notification par vOnChangementTranche
//		// Si la page est RWD, on inclus syst�matiquement le framework V2. Donc plus besoin de tester NSPCS.
//		if (clWDUtil.bRWD)
//		{
//			var oThis = this;
//			NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(function()
//			{
//				oThis.vOnChangementTranche.apply(oThis, arguments);
//			});
//		}

		// GP 09/05/2018 : TB98609 : Bloque le dessin tant que le premier ancrage vertical pour IE n'a pas �t� fait.
		// Sinon, si notre contenu est trop grand, il va s'appliquer avant les ancrages et d�finir une taille trop grande.
		// !clWDUtil.bRWD <= Car je ne suis pas sur du comportement des ancrages en responsive.
		this.m_bTB98609BloqueDessin = false;
		if (bIEAvec11 && (!clWDUtil.bRWD) && window.$ && document.getElementById("wbStyleAncrageIE11"))
		{
			this.m_bTB98609BloqueDessin = true;
			var oThis = this;
			$(window).on("trigger.wb.ancrage.ie.1erAffichageApresAncrage", function(/*jqEvent*//*, bAncrageFait*/)
			{
				oThis.m_bTB98609BloqueDessin = false;
			});
		}

		this.m_bCreeConteneurs = false;
		this.m_tabConteneurs = [];
	}
}

// Declare l'heritage
WDAPBase.prototype = new WDChampParametresHote();
// Surcharge le constructeur qui a ete efface
WDAPBase.prototype.constructor = WDAPBase;

//////////////////////////////////////////////////////////////////////////
// Membres statiques

// Commandes pour les champs agenda/planning
//WDAPBase.prototype.ms_sActionAgendaRdvSelection = "AGENDARDVSEL";
WDAPBase.prototype.ms_sActionAgendaRdvDeplacement = "AGENDARDVDEP";
WDAPBase.prototype.ms_sActionAgendaRdvRedim = "AGENDARDVRED";
//WDAPBase.prototype.ms_sActionAgendaPeriodeSelect = "AGENDAPERSEL";
WDAPBase.prototype.ms_sActionAgendaRdvSupprime = "AGENDARDVSUP";
WDAPBase.prototype.ms_sActionAgendaRdvAjoute = "AGENDARDVAJO";
//WDAPBase.prototype.ms_sActionAgendaRdvEdition = "AGENDARDVEDI";
WDAPBase.prototype.ms_sActionAgendaRdvModifTitre = "AGENDARDVEDT";
WDAPBase.prototype.ms_sActionAgendaPeriodeAffiche = "AGENDAPERAFF";
//WDAPBase.prototype.ms_sActionAgendaPlanningDeplacementRessource = "PLANNINGRDVDES";

//////////////////////////////////////////////////////////////////////////
// Methodes virtuelles generales

// Initialisation
WDAPBase.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype.Init.apply(this, arguments);

	// Reconstruit le HTML
	this.__Reinit(false, true, undefined);

	// Pour le mode AWP on refixe dans le champ formulaire la selection
	this.ConstruitParam();
};

// Ecrit les proprietes
WDAPBase.prototype.SetProp = function SetProp(eProp, oEvent, oValeur/*, oChamp*//*, oXMLAction*/)
{
	switch (eProp)
	{
	case this.XML_CHAMP_PROP_NUM_ETAT:
		// GP 21/11/2016 : QW278487 : MAJ du flag m_bActif. Ce flag est consult� a chaque action donc pas besoin de faire une MAJ.
		this.m_oParametres.m_bActif = (0 == oValeur);
		return oValeur;
	default:
		// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
		return WDChampParametresHote.prototype.SetProp.apply(this, arguments);
	}
};

// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
WDAPBase.prototype.OnDisplay = function OnDisplay(oElementRacine, bAffiche)
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype.OnDisplay.apply(this, arguments);

	if (bAffiche && this.m_oHote && clWDUtil.bEstFils(this.m_oHote, oElementRacine))
	{
		// Reaffiche le contenu du champ
		// GP 14/02/2013 : TB81010 : Si le champ n'a jamais �t� affichee
		var bPremierAffichage = (null == this.m_oVue);
		this.__Reinit(false, bPremierAffichage, undefined);
	}
};

// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
// Version interne de WDAPBase qui a deja filtre sur les conditions
WDAPBase.prototype._vOnResize = function _vOnResize(/*oEvent*/)
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype._vOnResize.apply(this, arguments);

	// GP 10/02/2016 : TB96435 : uniquement si on a �t� affich�
	if (!this.m_oVue)
	{
		return;
	}

	// GP 12/03/2014 : QW242847 : Pas de rentrance
	if (this.m_oVue.m_bDansGetDefilement)
	{
		return;
	}

	// GP 25/03/2015 : QW256413 : Bloque les messages de redimensionnement pendant quelques instant (pour l'ouverture du clavier)
	if (((new Date()).getTime() - this.m_nBloqueOnResize) < 750)
	{
		return;
	}

	// GP 14/02/2013 : TB81010 : Uniquement si on est visible et si on a �t� affiche (test� ci dessus maintenant)
	if (clWDUtil.bEstDisplay(this.m_oHote, document, true))
	{
		this.__OnResizeVisible();
	}
};

// GP 01/12/2015 : QW266611 : Version sp�cifique de du OnResize si on est visible
WDAPBase.prototype.__OnResizeVisible = function __OnResizeVisible()
{
	// Pr�paration (uniquement sur le premier appel)
	// - Noter les dimensions du parent du _HTE
	// - "position:relative" sur le parent du _HTE
	// - "position:absolute" sur le _HTE
	// - "left:0" et "top:0" sur _HTE (pour le cas ou il a un ascenseur car la partie masqu� fait d�filer)
	// - Ne supprime plus le HTML
	// Sur les appel suivant :
	// - "opacity:0.5" sur le _HTE
	var oHote = this.m_oHote;
	if (!this.bGetTimeXXXExiste("__ReinitSurOnResize"))
	{
		var oParametresResizeVisible = {};

		var oHote = this.m_oHote;
		var oHoteParent = oHote.parentNode;
		if (!oHoteParent)
		{
			return;
		}

		// - Noter les dimensions du parent du _HTE
		var oDimensionsHoteParent = oHoteParent.getBoundingClientRect();
		oParametresResizeVisible.m_nLargeur = (oDimensionsHoteParent.right - oDimensionsHoteParent.left);
		oParametresResizeVisible.m_nHauteur = (oDimensionsHoteParent.bottom - oDimensionsHoteParent.top);
		// GP 25/02/2016 : TB92261 : Il y a un probl�me de d�tection du redimensionnement en cas de passage en maximis�. Il n'y a que un seul onresize de lanc� et apr�s le redimensionnement
		// Donc le code ne d�tecte plus de redimensionnement (la taille s'est d�j� agrandie) : donc si on d�tecte une modification : on force un redimensionnement (par
		var oDimensionsHoteParentOld = this.m_oVue.m_oDimensionsHoteParent;
		if (oDimensionsHoteParentOld)
		{
			if (oParametresResizeVisible.m_nLargeur != (oDimensionsHoteParentOld.right - oDimensionsHoteParentOld.left))
			{
				oParametresResizeVisible.m_nLargeur = 0;
			}
			if (oParametresResizeVisible.m_nHauteur != (oDimensionsHoteParentOld.bottom - oDimensionsHoteParentOld.top))
			{
				oParametresResizeVisible.m_nHauteur = 0;
			}
		}
		
		// - "position:relative" sur le parent du _HTE
		oParametresResizeVisible.m_sParentHotePosition = oHoteParent.style.position;
		oHoteParent.style.position = "relative";
		// - "position:absolute" sur le _HTE
		oParametresResizeVisible.m_sHotePosition = oHote.style.position;
		oHote.style.position = "absolute";
		// - "opacity:0.5" sur le _HTE <= pr�pare pour les appels suivants
		oParametresResizeVisible.m_sHoteOpacity = oHote.style.opacity;
//		oHote.style.opacity = "0.5";
		// - "left:0" et "top:0" sur _HTE (pour le cas ou il a un ascenseur car la partie masqu� fait d�filer)
		oParametresResizeVisible.m_sHoteLeft = oHote.style.left;
		oHote.style.left = "0";
		oParametresResizeVisible.m_sHoteTop = oHote.style.top;
		oHote.style.top = "0";


		// GP 25/02/2016 : TB92261 : Supprime le HTML dans IE en cas d'ancrage en hauteur car sinon il y a interf�rence en ce code et le code des ancrages
		// Ne supprime plus le HTML dans les autres cas.
		var bVideContenu = bIEAvec11 && clWDUtil.bAvecClasse(oHote, "h100");
		oParametresResizeVisible.m_bVideContenu = bVideContenu;
		if (bVideContenu)
		{
			this.m_oVue.HTMLVideContenuSurOnResize(this.m_oParametres, this.m_oOldDonnees);
		}

		oParametresResizeVisible.m_oParametres = this.m_oParametres;
		oParametresResizeVisible.m_oOldDonnees = this.m_oOldDonnees;

		// GP 25/02/2016 : TB92261 : Sauve la valeur pr�c�dente de vnGetDimensionPxGraduation
		oParametresResizeVisible.m_nDimensionPxGraduation = this.m_oVue.vnGetDimensionPxGraduation(this.m_oParametres);

		// M�morise les parametres
		// On ne peut pas faire une closure car lors d'un appel suivant on ne pourra pas retrouver les param�tres
		this.m_oParametresResizeVisible = oParametresResizeVisible;
	}
	else
	{
		oHote.style.opacity = "0.5";
	}
	this.nSetTimeoutUnique("__ReinitSurOnResize", clWDUtil.ms_nTimeoutNonImmediat100);
};

// GP 01/12/2015 : QW266611 : Version sp�cifique de __Reinit pour le cas du r�affichage en redimensionnement
WDAPBase.prototype.__ReinitSurOnResize = function __ReinitSurOnResize()
{
	// En terminaison (uniquement sur le premier appel)
	// - Noter les dimensions du parent du _HTE
	// - Replace le position original sur le parent du _HTE
	// - Replace le position original sur le _HTE
	// - Replace le opacity original sur le _HTE
	// - Replace les left et op originaux sur le _HTE (pour le cas ou il a un ascenseur car la partie masqu� fait d�filer)
	// - Si la dimension a �t� modifi�e :
	//	- Supprime le HTML
	//	- R�initialisation

	// Trouve les param�tres
	var oParametresResizeVisible = this.m_oParametresResizeVisible;
	this.m_oParametresResizeVisible = null;

	var oHote = this.m_oHote;
	var oHoteParent = oHote.parentNode;
	if (!oHoteParent)
	{
		return;
	}
	// - Noter les dimensions du parent du _HTE
	var oDimensionsHoteParent = oHoteParent.getBoundingClientRect();

	// - Replace le position original sur le parent du _HTE
	oHoteParent.style.position = oParametresResizeVisible.m_sParentHotePosition;
	// - Replace le position original sur le _HTE
	oHote.style.position = oParametresResizeVisible.m_sHotePosition;
	// - Replace le opacity original sur le _HTE
	oHote.style.opacity = oParametresResizeVisible.m_sHoteOpacity;
	// - Replace les left et op originaux sur le _HTE (pour le cas ou il a un ascenseur car la partie masqu� fait d�filer)
	oHote.style.left = oParametresResizeVisible.m_sHoteLeft;
	oHote.style.top = oParametresResizeVisible.m_sHoteTop;

	// GP 14/06/2016 : TB98610 : Si on a supprimer le contenu, il faut le remettre
	// - Si la dimension a �t� modifi�e :
	if (oParametresResizeVisible.m_bVideContenu || ((oDimensionsHoteParent.right - oDimensionsHoteParent.left) != oParametresResizeVisible.m_nLargeur) || ((oDimensionsHoteParent.bottom - oDimensionsHoteParent.top) != oParametresResizeVisible.m_nHauteur))
	{
		// GP 25/02/2016 : TB92261 : Supprime le HTML dans IE en cas d'ancrage en hauteur car sinon il y a interf�rence en ce code et le code des ancrages
		// => Donc d�j� fait dans IE
		if (!oParametresResizeVisible.m_bVideContenu)
		{
			//	- Supprime le HTML
			this.m_oVue.HTMLVideContenuSurOnResize(oParametresResizeVisible.m_oParametres, oParametresResizeVisible.m_oOldDonnees);
		}
		//	- R�initialisation
		this.__Reinit(true, false, oParametresResizeVisible.m_nDimensionPxGraduation);
	}
	// GP 11/02/2016 : QW269587 : Probl�me de dessin dans IE d'un champ planning superposable dans une page avec certains ancrage.
	// Symptomes : on a un dessin partiel. C'est un probl�me de reflow car un des manips simples d�clenchent l'affichage correct du champ.
	// Contournement : l'id�e est de d�clencher un reflow uniquement avec IE + champ superposable
	else if (bIEAvec11 && !bIEQuirks)
	{
		var oBaliseExterne = _JGE(this.m_sAliasChamp, document, true, false);
		if (oBaliseExterne && ("absolute" == clWDUtil.oGetCurrentStyle(oBaliseExterne).position) && clWDUtil.bEstDisplay(oBaliseExterne, document))
		{
			var oThis = this;
			clWDUtil.nSetTimeout(function()
			{
				// GP 12/02/2016 : QW269610 : Evite de perdre le scroll.
				var oHoteCorps = oThis.m_oVue.m_oHoteCorps;
				var nScrollLeft = oHoteCorps.scrollLeft;
				var nScrollTop = oHoteCorps.scrollTop;
				clWDUtil.SetDisplay(oBaliseExterne, false);
				oBaliseExterne.getBoundingClientRect();
				clWDUtil.SetDisplay(oBaliseExterne, true);
				oHoteCorps.scrollLeft = nScrollLeft;
				oHoteCorps.scrollTop = nScrollTop;
			}, clWDUtil.ms_nTimeoutNonImmediat100);
		}
	}
};

//// GP 24/07/2017 : C'est inutile, en cas de changement de tranche on re�oit un "resize" et donc le champ est redessin�
//// Changement de tranche
//WDAPBase.prototype.vOnChangementTranche = function vOnChangementTranche(oEvent, nTrancheDepuisDefautBase1)
//{
//	// En cas de changement de tranche, le style du bouton de suppression peut changer
//	// C'est inutile, 
//	if (this.m_oVue)
//	{
//		this.m_oVue.OnChangementTranche(oEvent, nTrancheDepuisDefautBase1);
//	}
//};

// Pour implementer ConstruitParam (accepte des parametres variables)
WDAPBase.prototype._vsConstruitParam = function _vsConstruitParam()
{
	var tabParam = [];
	// Appel de la methode de la classe de base
	var sParam = WDChampParametresHote.prototype._vsConstruitParam.apply(this, arguments);
	// Inutile de tester .length : "" s'�value a faux et "<Contenu>" s'�value � vrai.
	if (sParam)
	{
		tabParam.push(sParam);
	}

	// Ajoute la position du debut du champ
	tabParam.push(this.m_oParametres.m_oDateDebut.getTime() + "");
	// Ajoute la position de scrolling dans le sens du temps (donc parallele au sens des ressources)
	if (this.m_oVue && this.m_oVue.m_nDefilementPrincipal)
	{
		// GP 13/02/2015 : QW254289 : Sans alignement sur la grille
		var oDateDebutDefilementJour = this.m_oVue.oGetDateFromPosAlignResolution(this.m_oParametres, this.m_oVue.m_nDefilementPrincipal, false, 0, 0, false);
		tabParam.push(oDateDebutDefilementJour.getTime() + "");
	}
	else
	{
		tabParam.push(this.m_oParametres.m_oDateDebut.getTime() + "");
	}

	// Si on a recu un argument : c'est le rendez-vous
	var oRendezVous = (arguments.length >= 1) ? arguments[0] : this.oGetRendezVousSelection();

	// Les details du rendez-vous (au format urlencode)
	if (oRendezVous)
	{
		tabParam.push(this._sConstruitParamObjet(oRendezVous));
	}
	else
	{
		tabParam.push("");
	}

	return tabParam.join(',');
};

// Fusionne les donnes
WDAPBase.prototype._voFusionneDonne = function _voFusionneDonne(oDonnees)
{
	WDChampParametresHote.prototype._voFusionneDonne.apply(this, arguments);

	// Modifie les champs fusionnees
	var tabConteneurModifFusion = [];

	var tabRendezVous = this.m_oDonnees.m_tabRendezVous;
	var tabRendezVousModif = oDonnees.m_tabRendezVous;

	var nRendezVousModif;
	var nNbRendezVousModif = tabRendezVousModif.length;
	var oRendezVousModif;
	var oRendezVousPrecedent;
	var nConteneurPrecedentPrecedent;
	for (nRendezVousModif = 0; nRendezVousModif < nNbRendezVousModif; nRendezVousModif++)
	{
		oRendezVousModif = tabRendezVousModif[nRendezVousModif];
		var nConteneurModif = this.nGetRendezVousConteneur(oRendezVousModif);
		var nIndicePrecedent = this.__nTrouveRendezVous(oRendezVousModif);
		if (clWDUtil.nElementInconnu != nIndicePrecedent)
		{
			// Copie pour ne pas perdre les membres m_oDiv, m_fXxx du rendezvous
			oRendezVousPrecedent = tabRendezVous[nIndicePrecedent];
			oRendezVousModif.m_oRendezVousPrecedent = oRendezVousPrecedent;

			var nConteneurPrecedent = this.nGetRendezVousConteneur(oRendezVousPrecedent);
			if (nConteneurModif != nConteneurPrecedent)
			{
				// Si le rendez-vous change de ressource sur le serveur
				tabConteneurModifFusion[nConteneurPrecedent] = true;
			}
			nConteneurPrecedentPrecedent = this.nGetRendezVousConteneurPrecedent(oRendezVousPrecedent);
			// GP 28/03/2013 : Il faut tester s'il n'y a pas de "pr�c�dent au pr�c�dent" sinon on modifie tabConteneurModifFusion a l'indice "undefined"
			if ((undefined !== nConteneurPrecedentPrecedent) && (nConteneurModif != nConteneurPrecedentPrecedent))
			{
				// Si le rendez-vous a change de ressource lors du deplacement par l'utilisateur
				tabConteneurModifFusion[nConteneurPrecedentPrecedent] = true;
			}
			// Supprime l'ancien rendez-vous
			tabRendezVous.splice(nIndicePrecedent, 1);
			// GP 28/03/2013 : Les rendez-vous de tabRendezVousModif sont dans l'ordre des indices croissant, mais si il y a une inversion :
			// - Rdv en 30 passe en 25
			// - Rdv en 20 passe en 40
			// On d�place 30 en 25 puis 20 en 40 : ce qui est faux : ex-30 se retrouve en 24 � la fin
			// => On note les insersions (en fait le contenu de tabRendezVousModif). Et on les fait � la fin apr�s un tri des indices.
			// Ce code a un second avantage, c'est que si un �v�nement a plusieurs "instances", on trouve les instances dans l'ordre
//			// Ajoute le nouveau rendez-vous (a la bonne place)
//			// L'indice recu est selon la liste serveur donc apres suppression de l'element precedent
//			tabRendezVous.splice(oRendezVousModif.m_nIndice, 0, oRendezVousModif);
		}
		else
		{
//			tabRendezVous.push(oRendezVousModif);
		}
		tabConteneurModifFusion[nConteneurModif] = true;
	}

	// GP 28/03/2013 : Supprime les instances suivantes des rendez-vous (rendez-vous sur plusieurs jours qui perd un ou plusieurs jours)
	for (nRendezVousModif = 0; nRendezVousModif < nNbRendezVousModif; nRendezVousModif++)
	{
		while (clWDUtil.nElementInconnu != (nIndicePrecedent = this.__nTrouveRendezVous(tabRendezVousModif[nRendezVousModif])))
		{
			oRendezVousPrecedent = tabRendezVous[nIndicePrecedent];
			tabConteneurModifFusion[this.nGetRendezVousConteneur(oRendezVousPrecedent)] = true;
			nConteneurPrecedentPrecedent = this.nGetRendezVousConteneurPrecedent(oRendezVousPrecedent);
			if (undefined != nConteneurPrecedentPrecedent)
			{
				tabConteneurModifFusion[nConteneurPrecedentPrecedent] = true;
			}
			this.m_oVue.__HTMLVideUnRendezVous(oRendezVousPrecedent);
			tabRendezVous.splice(nIndicePrecedent, 1);
		}
	}

	// GP 28/03/2013 : Tri de tabRendezVousModif pour faire les ajouts dans l'ordre
	tabRendezVousModif.sort(this.__s_TriSelonIndice);
	for (nRendezVousModif = 0; nRendezVousModif < nNbRendezVousModif; nRendezVousModif++)
	{
		oRendezVousModif = tabRendezVousModif[nRendezVousModif];
		tabRendezVous.splice(oRendezVousModif.m_nIndice, 0, oRendezVousModif);
	}

	return tabConteneurModifFusion;
};
WDAPBase.prototype.__s_TriSelonIndice = function __s_TriSelonIndice(oRendezVous1, oRendezVous2)
{
	return oRendezVous1.m_nIndice - oRendezVous2.m_nIndice;
};

// Applique les parametres
WDAPBase.prototype._vAppliqueParametres = function _vAppliqueParametres(oParametreFusion)
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype._vAppliqueParametres.apply(this, arguments);

	// Recharge le champ (en particulier le calcul tailles etc)
	this.__Reinit(false, true, undefined, oParametreFusion);

	// Pour le mode AWP on refixe dans le champ formulaire la selection
	this.ConstruitParam();
};

//////////////////////////////////////////////////////////////////////////
// Initialisations

// Construit tous le HTML si besoin
WDAPBase.prototype.__Reinit = function __Reinit(bRAZDejaFait, bChangementParametres, nDimensionPxGraduationSiResize, oParametreFusion)
{
	// On effectue la laison avec la selection
	this.__TrouveSelection();

	var bCreeConteneurs = bChangementParametres && !oParametreFusion;

	// Si l'element n'est pas visible : fini
	// GP 09/05/2018 : TB98609 : Bloque le dessin tant que le premier ancrage vertical pour IE n'a pas �t� fait.
	if ((!clWDUtil.bEstDisplay(this.m_oHote, document)) || this.m_bTB98609BloqueDessin)
	{
		// GP 09/03/2018 : TB107728 : M�morise bCreeConteneurs. Sinon si on change le contenu du champ (en AJAX) et que le champ n'est pas affich�,
		// alors lors du prochain affichage (par changement de visibilit�, on ne passera pas dans l'appel de _vtabCreeConteneurs.
		this.m_bCreeConteneurs |= bCreeConteneurs;
		return;
	}

	// Apr�s le test de visibilit� pour ne pas avoir une affectation sans affichage
	// Non effectue dans le cas d'une fusion pour ne pas perdre le tableau actuel qui n'a pas chang� et qui contient le pointeur vers les DIV des conteneurs
	if (bCreeConteneurs || this.m_bCreeConteneurs)
	{
		this.m_bCreeConteneurs = false;
		// Calcule le tableaux des conteneurs (pour qu'il soit disponible dans le dessin)
		(this.m_tabConteneurs = this._vtabCreeConteneurs());
	}

	// Si c'est le premier affichage
	if (null == this.m_oVue)
	{
		// Initialise les differents evenements
		this.__InitEvents();

		// Allocation de la vue et construction initiale
		this.__AlloueVue();

		// Force des valeurs
		bRAZDejaFait = true;
	}
	// GP 21/02/2018 : TB99673 : Si le mode d'affichage � chang� (possible lors d'un appel AJAX) : il faut changer la vue.
	// Le test de instanceof ne fonctionne pas car WDVueAgendaSemaine d�rive de WDVueAgendaJournee. Donc "(new WDVueAgendaSemaine()) instanceof WDVueAgendaJournee" retourne true.
//	else if (!(this.m_oVue instanceof this._voGetClasseVue()))
	else if (this.m_oVue.constructor != this._voGetClasseVue())
	{
		// Detache les �v�nements de l'ancienne vue
		this.m_oVue.DetacheEvenement();

		// GP 21/02/2018 : TB99673 : Si le mode d'affichage � chang� (possible lors d'un appel AJAX) : il faut changer la vue.
		this.m_oVue.__HTMLVideContenu(this.m_oParametres, this.m_oOldDonnees, false);

		// Allocation de la vue et construction initiale
		this.__AlloueVue();

		// Force des valeurs
		bRAZDejaFait = true;
	}

	// Affiche le contenu
	this.m_oVue.HTMLAfficheContenu(bRAZDejaFait, bChangementParametres, nDimensionPxGraduationSiResize, oParametreFusion, this.m_oParametres, this.m_oDonnees.m_tabRendezVous, this.m_oOldDonnees, this.m_oHote);

	// GP 27/05/2013 : TB77603 : Recalcule la taille sinon on n'a la largeur sans les ascenseur
	this.m_oVue.__CalculeDimensionClientCorps();

	// Sauve les donn�es et les conteneurs (pour avoir le tableau des anciens rendez-vous lors du reaffichage)
	(this.m_oOldDonnees = this.m_oDonnees);
	(this.m_tabOldConteneurs = this.m_tabConteneurs);

	// GP 26/03/2015 : QW256544 : Si on a eu un allez retour serveur long, bloque le prochain clic
	if (oParametreFusion)
	{
		this.BloqueClicSuivant();
	}
};

// Initialise les differents evenements
WDAPBase.prototype.__InitEvents = function __InitEvents()
{
	// Evenements :
	//	- Generiques :
	//		- Redimensionnement : fait pas le champ (appel de _vOnResize)
	//		- Defilement : rien a faire
	// => Vide
	//	- Specifiques :
	//		- Drag drop des rendez-vous
	(this.m_oDragRendezVous = new WDDragRendezVous(this));
	//		- Drag-drop dans le fond d'une ressource (selection d'une periode pour creation d'un rendez-vous)
	(this.m_oDragPeriodeSelect = new WDDragPeriodeSelect(this));
	//		- Entree en saisie dans un champ
	(this.m_oPopupSaisie = new WDPopupSaisiePlanning(this));
};

// Allocation de la vue et construction initiale
WDAPBase.prototype.__AlloueVue = function __AlloueVue()
{
	// Alloue la vue
	this.m_oVue = new (this._voGetClasseVue())(this, null);

	// Declenche la construction du HTML de base de l'application en indiquant que c'est l'affichage initial
	this.m_oVue.HTMLAfficheBase(this.m_oHote, true, this.m_oParametres);
};

//////////////////////////////////////////////////////////////////////////
// Evenements

// Selectionne une rendez-vous
WDAPBase.prototype.bOnRendezVousSelection = function bOnRendezVousSelection(oEvent, oRendezVous)
{
	// Si deja selectionne
	var bAvecPCode;
	switch (this.__eMemeRendezVous(this.oGetRendezVousSelection(), oRendezVous))
	{
	case 2:
		// Si c'est le m�me rendez-vous mais aussi la m�me zone affich�e : un rendez-vous sur plusieurs jours est parfois affich� en plusieurs rendez-vous s�par�s.
		bAvecPCode = false;
		break;
	case 1:
		// Reforce la selection (pour le cas ou les pointeurs sont differents)
		this.m_oRendezVousSelection = oRendezVous;
		return true;
	case 0:
		bAvecPCode = true;
		break;
	}

	// Valide avec le PCode (+ construit les parametres)
	if (bAvecPCode)
	{
		if (!this.__bAppelPCodeConstruitParam(this.ms_nEventNavAgendaRdvSelection, undefined, oEvent, oRendezVous))
		{
			return false;
		}
	}

	// Le rendez-vous selectionne ne l'est plus
	this.m_oVue.__HTMLVideRendezVousSelection(this.m_oParametres);

	// Memorise la selection
	(this.m_oRendezVousSelection = oRendezVous);

	// Affiche le nouveau rendez-vous selectionne
	this.m_oVue.__HTMLAfficheRendezVousSelection(oEvent, this.m_oParametres, true);
	this.m_oVue.__HTMLAfficheRendezVousSelectionApresAffichage(oEvent, this.m_oParametres);

	return true;
};

// Entre en edition dans un rendez-vous
// Retourne true si on entre en �dition
WDAPBase.prototype.__bEditionRendezVous = function __bEditionRendezVous(oEvent, oRendezVous)
{
	var oParametres = this.m_oParametres;

	// Valide que l'on a le droit d'edition
	// GP 21/11/2016 : QW278487 : S�pare le flag bActif des autres options
	if (oParametres.m_bEditionRendezVous && oParametres.m_bActif)
	{
		// Valide avec le PCode (le rendez-vous est normalement deja selectionne par le clic)
		if (this.__bAppelPCode(this.ms_nEventNavAgendaRdvEdition, undefined, oEvent, oRendezVous))
		{
			// GP 28/10/2014 : QW250676 : On prend le titre ou le contenu si on n'affiche pas les titres
			// GP 10/11/2014 : QW251411 : Pour le cas PHP traite m_bAfficherTitreRendezVous absent comme un true
			var sValeurInitiale = (false !== oParametres.m_bAfficherTitreRendezVous) ? oRendezVous.m_sTitre : oRendezVous.m_sContenu;

			// Entre en saisie en forcant la valeur initiale
			this.m_oPopupSaisie.Debut(oEvent, oRendezVous.m_oDiv, oRendezVous.m_oDiv, (oParametres.m_oStyleRendezVousSelect.m_nBordureV || 0) * 2, false, sValeurInitiale, null, undefined, [oRendezVous]);

			return true;
		}
	}

	return false;
};

// Double clic sur un rendez-vous
WDAPBase.prototype.bOnRendezVousDoubleClic = function bOnRendezVousDoubleClic(oEvent, oRendezVous)
{
	if (this.__bEditionRendezVous(oEvent, oRendezVous))
	{
		// GP 15/04/2014 : TB78328 : Si on est en mobile, bloque le comportement par d�faut du double clic (zoom)
		if (bTouch)
		{
			return clWDUtil.bStopPropagation(oEvent);
		}
	}

	return true;
};

// Fin de la modification d'un rendez-vous (= fin du double clic)
WDAPBase.prototype.OnRendezVousValideSaisie = function OnRendezVousValideSaisie(oEvent, oRendezVous, sValeur)
{
	var sOldTitre = oRendezVous.m_sTitre;
	// Uniquement si la valeur change (pas d'appel serveur inutile)
	if (sValeur != sOldTitre)
	{
		oRendezVous.m_sTitre = sValeur;

		// Valide avec le PCode (le rendez-vous est normalement deja selectionne par le clic)
		if (!this.__bAppelPCodeConstruitParam(this.ms_nEventNavAgendaRdvModifTitre, this.ms_sActionAgendaRdvModifTitre, oEvent, oRendezVous))
		{
			// Refus de la modification
			oRendezVous.m_sTitre = sOldTitre;
		}
	}
};

// Supprime le rendez-vous selectionn
WDAPBase.prototype.OnRendezVousSupprime = function OnRendezVousSupprime(oEvent)
{
	// Appel le code navigateur
	var oRendezVous = this.oGetRendezVousSelection();
	this.__bAppelPCodeConstruitParam(this.ms_nEventNavAgendaRdvSupprime, this.ms_sActionAgendaRdvSupprime, oEvent, oRendezVous);
};

// Changement de periode
// - Precedente
WDAPBase.prototype.__OnAffichePeriodePrecedente = function __OnAffichePeriodePrecedente(oEvent)
{
	// Affiche la periode precedente (normalement elle est disponible sinon le bouton n'est pas affiche)
	if (this.m_oParametres.m_oDateDebutPrecedente)
	{
		this.__OnAffichePeriode(oEvent, this.m_oParametres.m_oDateDebutPrecedente);
	}
};
// - Suivante
WDAPBase.prototype.__OnAffichePeriodeSuivante = function __OnAffichePeriodeSuivante(oEvent)
{
	// Affiche la periode suivante (normalement elle est disponible sinon le bouton n'est pas affiche)
	if (this.m_oParametres.m_oDateDebutSuivante)
	{
		this.__OnAffichePeriode(oEvent, this.m_oParametres.m_oDateDebutSuivante);
	}
};
// - Methode commune
WDAPBase.prototype.__OnAffichePeriode = function __OnAffichePeriode(oEvent, oDateDebutPeriode)
{
	// Force la date de debut (pour la construction des parametres)
	var oOldDateDebut = this.m_oParametres.m_oDateDebut;
	(this.m_oParametres.m_oDateDebut = oDateDebutPeriode);

	this.__bAppelPCodeConstruitParam(this.ms_nEventNavAgendaPeriodeAffiche, this.ms_sActionAgendaPeriodeAffiche, oEvent);

	// Restaure la date de debut (pour garder la coherence le temps du retour serveur)
	(this.m_oParametres.m_oDateDebut = oOldDateDebut);
};

// Notifie du redimensionnement de la selection
WDAPBase.prototype.OnRendezVousRedimensionne = function OnRendezVousRedimensionne(oEvent, nDebut, nLongueur)
{
	this.__bOnRendezVousDeplacement(oEvent, nDebut, nLongueur);
};

// Notifie du deplacement (et/ou du changement de ressources)
WDAPBase.prototype.OnRendezVousDeplacement = function OnRendezVousDeplacement(oEvent, nDebut, nLongueur, nConteneur)
{
	this.__bOnRendezVousDeplacement(oEvent, nDebut, nLongueur, nConteneur);
};

// Notifie du deplacement/redimensionnement (et/ou du changement de ressources)
// nConteneur != undefined => Deplacement (meme si la ressource ne change pas)
WDAPBase.prototype.__bOnRendezVousDeplacement = function __bOnRendezVousDeplacement(oEvent, nDebut, nLongueur, nConteneur)
{
	var oRendezVous = this.oGetRendezVousSelection();
	var nPCode;
	var sAction;
	var nOldConteneur = this.nGetRendezVousConteneur(oRendezVous);
	if (nConteneur !== undefined)
	{
		// Deplacement
		nPCode = this.ms_nEventNavAgendaRdvDeplacement;
		sAction = this.ms_sActionAgendaRdvDeplacement;
	}
	else
	{
		// Redimensionnement
		nPCode = this.ms_nEventNavAgendaRdvRedim;
		sAction = this.ms_sActionAgendaRdvRedim;
		// GP 31/10/2012 : En cas de redimensionnement on n'a pas le pr�c�dent conteneur (et on en a besoin pour les calculs de la vue � la semaine de l'agenda)
		nConteneur = nOldConteneur;
	}

	// Calcule la nouvelle position du rendez-vous
	var oOldDateDebut = oRendezVous.m_oDateDebut;
	var oOldDateFin = oRendezVous.m_oDateFin;
	// GP 13/02/2015 : QW254289 : Avec alignement sur la grille
	oRendezVous.m_oDateDebut = this.m_oVue.oGetDateFromPosAlignResolution(this.m_oParametres, nDebut, true, nConteneur, clWDUtil.nGetHeureJour(oOldDateDebut), true);
	oRendezVous.m_oDateFin = this.m_oVue.oGetDateFromPosAlignResolution(this.m_oParametres, nDebut + nLongueur, false, nConteneur, clWDUtil.nGetHeureJour(oOldDateFin), true);

	// GP 26/03/2013 : QW231471 : Si le rendez-vous ets � la journ�e : on garde la m�me heure de d�but
	// (Si on fait une s�lection globale dans la zone � la journ�e compl�te, on n'aura normalement plus besoin de ce code)
	// GP 31/05/2013 : QW231536 : En fait il faut le faire pour tous les rendez-vous � la journ�e enti�re
	if (oRendezVous.m_bJourneeEntiere)
//	if (this.m_oVue._bRendezVousTitreSeul(this.m_oParametres, oRendezVous))
	{
		var nDateDebutAvantCorrection = oRendezVous.m_oDateDebut.getTime();
		oRendezVous.m_oDateDebut.setUTCHours(oOldDateDebut.getUTCHours());
		oRendezVous.m_oDateDebut.setUTCMinutes(oOldDateDebut.getUTCMinutes());
		oRendezVous.m_oDateDebut.setUTCSeconds(oOldDateDebut.getUTCSeconds());
		oRendezVous.m_oDateDebut.setUTCMilliseconds(oOldDateDebut.getUTCMilliseconds());
		oRendezVous.m_oDateFin.setTime(oRendezVous.m_oDateFin.getTime() - (nDateDebutAvantCorrection - oRendezVous.m_oDateDebut.getTime()));
	}

	// Change (ou reforce) le conteneur du rendez-vous
	// Toujours fait pour le cas du champ planning ou oGetDateFromPosAlignResolution retourne une date dans le premier jour affiche
	this._vChangeRendezVousConteneur(oRendezVous, nConteneur, 0);

	// Si il y a changement de ressource
	if (nConteneur != nOldConteneur)
	{
		if (!this.__bAppelPCode(this.ms_nEventNavPlanningRdvDeplacementRessource, undefined, oEvent, oRendezVous))
		{
			// Replace les anciennes valeurs
			oRendezVous.m_oDateDebut = oOldDateDebut;
			oRendezVous.m_oDateFin = oOldDateFin;
			this._vChangeRendezVousConteneur(oRendezVous, nOldConteneur, nConteneur);
			return false;
		}
		else
		{
			// Pour la MAJ partielle : il faut redessiner la precedente ressource
			oRendezVous.m_nConteneurPrecedent = nOldConteneur;
		}
	}

	// Valide avec le PCode
	if (!this.__bAppelPCodeConstruitParam(nPCode, sAction, oEvent, oRendezVous))
	{
		oRendezVous.m_oDateDebut = oOldDateDebut;
		oRendezVous.m_oDateFin = oOldDateFin;
		if (nConteneur !== undefined)
		{
			// Replace les anciennes valeurs
			this._vChangeRendezVousConteneur(oRendezVous, nOldConteneur, nConteneur);
			delete oRendezVous.m_nConteneurPrecedent;
		}
		return false;
	}
	return true;
};

// Ajoute un rendez-vous a la position de la selection
WDAPBase.prototype.OnRendezVousAjoute = function OnRendezVousAjoute(oEvent, nDebut, nLongueur, nConteneur, bTitreSeul)
{
	var oDateDebut = this.m_oVue.oGetDateFromPosAlignResolution(this.m_oParametres, nDebut, true, nConteneur, 0, true);
	var oDateFin = this.m_oVue.oGetDateFromPosAlignResolution(this.m_oParametres, nDebut + nLongueur, false, nConteneur, 0, true);

	this.OnRendezVousAjouteDate(oEvent, oDateDebut, oDateFin, nConteneur, bTitreSeul);
};
// Ajoute un rendez-cous sur une heure � la position du clic
WDAPBase.prototype.OnRendezVousAjouteSur1Heure = function OnRendezVousAjouteSur1Heure(oEvent, nPosition, nConteneur, bTitreSeul)
{
	// GP 04/12/2015 : TB95378 : On doit aussi cr�e le rendez-vous sur la journ�e enti�re si on est dans un mode dont chaque cellule affiche une journ�e
	// => Utilisation de _vbJourneeEntiere
	var bJourneeEntiere = this.m_oVue._vbJourneeEntiere(this.m_oParametres, bTitreSeul);

	// GP 26/03/2015 : QW256569 : Sans alignement sur la grille sinon un clic en fin d'heure et plac� dans l'heure suivante
	// L'arrondi � l'heure est faite dans le setMinutes ensuite
	// GP 26/03/2015 : Et si la grille est sur plus de une heure ?
	var oDateDebut = this.m_oVue.oGetDateFromPosAlignResolution(this.m_oParametres, nPosition, true, nConteneur, 0, false);
	oDateDebut.setMinutes(0, 0, 0);
	if (bJourneeEntiere)
	{
		oDateDebut.setUTCHours(0);
	}

	// Pas de new Date(getTime()) car sinon on perd les millisecondes (qui ici sont normalement 0)
	var oDateFin = new Date();
	// 86399999 = 24 * 3600 * 1000 - 1 = 1 jour - 1 en ms
	// 3600000 = 3600 * 1000 = 1 heure en ms
	oDateFin.setTime(oDateDebut.getTime() + (bJourneeEntiere ? 86399999 : Math.max(3600000, this.m_oParametres.m_nResolutionTaille)));

	this.OnRendezVousAjouteDate(oEvent, oDateDebut, oDateFin, nConteneur, bTitreSeul);
};
WDAPBase.prototype.OnRendezVousAjouteDate = function OnRendezVousAjouteDate(oEvent, oDateDebut, oDateFin, nConteneur, bTitreSeul)
{
	// Creation du rendez-vous
	var oRendezVous =
	{
		// GP 13/02/2015 : QW254289 : Avec alignement sur la grille
		m_oDateDebut: oDateDebut,
		m_oDateFin: oDateFin,
		m_sTitre: "",
		m_sContenu: "",
		m_bJourneeEntiere: bTitreSeul && !!this.m_oParametres.m_nHauteurZoneJourneeComplete
	};
	this._vChangeRendezVousConteneur(oRendezVous, nConteneur, 0);

	// Appel le code navigateur
	this.__bAppelPCodeConstruitParam(this.ms_nEventNavAgendaRdvAjoute, this.ms_sActionAgendaRdvAjoute, oEvent, oRendezVous);
};

// Notifie de la selection
WDAPBase.prototype.bOnPeriodeSelect = function bOnPeriodeSelect(oEvent/*, nDebut*//*, nLongueur*//*, oConteneur*/)
{
	// @@@ Place les valeurs pour le code navigateur
//	...

	// Appel le code navigateur
	if (!this.__bAppelPCode(this.ms_nEventNavAgendaPeriodeSelect, undefined, oEvent))
	{
		// @@@ Retablie les valeurs originales
//		...
		return false;
	}

	return true;
};

// Defilement
WDAPBase.prototype.__OnDefilementCorps = function __OnDefilementCorps()
{
	return this.m_oVue.__OnDefilementCorps.apply(this.m_oVue, arguments);
};

// Bloque la cr�ation de rendez-vous suivante
WDAPBase.prototype.BloqueClicSuivant = function BloqueClicSuivant()
{
	this.m_bBloqueClicSuivant = true;
	this.nSetTimeoutUnique("__DebloqueClicSuivant", clWDUtil.ms_nTimeoutNonImmediat100);
};
WDAPBase.prototype.__DebloqueClicSuivant = function __DebloqueClicSuivant()
{
	clWDUtil.WDDebug.assert(this.m_bBloqueClicSuivant, "this.m_bBloqueClicSuivant doit �tre a vrai");
	this.m_bBloqueClicSuivant = false;
};
WDAPBase.prototype.bGetBloqueClicSuivant = function bGetBloqueClicSuivant()
{
	return this.m_bBloqueClicSuivant;
};

//////////////////////////////////////////////////////////////////////////
// Conteneurs

// Indique les conteneurs
WDAPBase.prototype._tabGetConteneurs = function _tabGetConteneurs(bOldConteneurs)
{
	return (bOldConteneurs ? this.m_tabOldConteneurs : this.m_tabConteneurs);
};

// Indique le nombre de conteneurs
WDAPBase.prototype._nGetNbConteneurs = function _nGetNbConteneurs(bOldConteneurs)
{
	return this._tabGetConteneurs(bOldConteneurs).length;
};

// Trouve un conteneur
WDAPBase.prototype._oGetConteneur = function _oGetConteneur(bOldConteneurs, nConteneur)
{
	return this._tabGetConteneurs(bOldConteneurs)[nConteneur];
};

// Nom d'une ressource par index
WDAPBase.prototype._sGetNomConteneur = function _sGetNomConteneur(nConteneur)
{
	return this._oGetConteneur(false, nConteneur).m_sNomAffiche;
};

// Trouve le conteneur d'un rendez-vous
WDAPBase.prototype.nGetRendezVousConteneur = function nGetRendezVousConteneur(oRendezVous)
{
	// S'il n'y a pas de cache : calcule le cache
	if (undefined === oRendezVous.m_nConteneur)
	{
		oRendezVous.m_nConteneur = this._vnGetRendezVousConteneur(oRendezVous);
	}
	// Retourne le cache
	return oRendezVous.m_nConteneur;
};

// Trouve le conteneur precedent d'un rendez-vous
WDAPBase.prototype.nGetRendezVousConteneurPrecedent = function nGetRendezVousConteneurPrecedent(oRendezVous)
{
	return oRendezVous.m_nConteneurPrecedent;
};

// Notifie du changement de conteneur d'un rendez-vous
WDAPBase.prototype._vChangeRendezVousConteneur = function _vChangeRendezVousConteneur(oRendezVous, nConteneur/*, nOldConteneur*/)
{
	// Maj du cache
	oRendezVous.m_nConteneur = nConteneur;
};

//////////////////////////////////////////////////////////////////////////
// Gestion de la selection

// Rendez-vous selectionne
WDAPBase.prototype.oGetRendezVousSelection = function oGetRendezVousSelection()
{
	if (this.m_oRendezVousSelection && this.m_oRendezVousSelection.m_oRendezVousPrecedent)
	{
		return this.m_oRendezVousSelection.m_oRendezVousPrecedent;
	}
	else
	{
		return this.m_oRendezVousSelection;
	}
};

// Liaison entre les parametres et la selection
WDAPBase.prototype.__TrouveSelection = function __TrouveSelection()
{
	// Supprime le rendez-vous selectionne actuel (s'il n'est pas affiche il n'existe pas)
	(this.m_oRendezVousSelection = null);
	delete this.m_oRendezVousSelection;

	// Trouve le rendez-vous selectionne
	var nIndice = this.__nTrouveRendezVousID(this.m_oParametres.m_sIDSelection);
	if (clWDUtil.nElementInconnu != nIndice)
	{
		// Si on est dans la fusion : il faut avoir le DIV precedent
		this.m_oRendezVousSelection = this.m_oDonnees.m_tabRendezVous[nIndice];
	}
};

WDAPBase.prototype.__nTrouveRendezVous = function __nTrouveRendezVous(oRendezVous)
{
	return this.__nTrouveRendezVousID(oRendezVous.m_sID);
};
WDAPBase.prototype.__nTrouveRendezVousID = function __nTrouveRendezVousID(sID)
{
	return clWDUtil.nDansTableauFct(this.m_oDonnees.m_tabRendezVous, this.__s_bCompareRendezVous, sID);
};
WDAPBase.prototype.__s_bCompareRendezVous = function __s_bCompareRendezVous(oRendezVous, sID)
{
	return (oRendezVous.m_sID == sID);
};

// Indique si si deux rendez-vous sont identiques
// 0 : Ce n'est pas le m�me rendez-vous
// 1 : C'est le m�me rendez-vous
// 2 : Ce sont deux �l�ments affich� du m�me rendez-vous
WDAPBase.prototype.__eMemeRendezVous = function __eMemeRendezVous(oRendezVous1, oRendezVous2)
{
	// Compare :
	// - Les pointeurs (rapide)
	// - Les IDs (lent) pour le cas ou c'est le meme rendez-vous mais retourne par le serveur
	if (oRendezVous1 == oRendezVous2)
	{
		return 1;
	}
	else if (oRendezVous1 && oRendezVous2 && (oRendezVous1.m_sID == oRendezVous2.m_sID))
	{
		if (oRendezVous1.m_oDateDebut.getTime() == oRendezVous2.m_oDateDebut.getTime())
		{
			return 1;
		}
		else
		{
			return 2;
		}
	}
	else
	{
		return 0;
	}
};

//////////////////////////////////////////////////////////////////////////
// Gestion de l'heure/position

// Recupere la ressource en fonction de la position
// nConteneurPrecedent : ressource "actuelle"/par defaut
// => valeur retournee si on n'est pas dans une ressource
// => valeur recherche en premier (valeur la plus probable : accelere le calcul
WDAPBase.prototype.nGetConteneurDepuisPosition = function nGetConteneurDepuisPosition(oOriginalTarget, nConteneurPrecedent, bTitreSeul)
{
	// Si on n'a pas change de ressource
	if (clWDUtil.bEstFils(oOriginalTarget, this.m_oVue.oGetConteneurDiv(this.m_oParametres, nConteneurPrecedent, bTitreSeul)))
	{
		return nConteneurPrecedent;
	}

	// On n'est plus dans la meme ressource : trouve la nouvelle ressource
	var i;
	var nLimiteI = this._nGetNbConteneurs(false);
	for (i = 0; i < nLimiteI; i++)
	{
		if (clWDUtil.bEstFils(oOriginalTarget, this.m_oVue.oGetConteneurDiv(this.m_oParametres, i, bTitreSeul)))
		{
			return i;
		}
	}

	// Non trouve (on est hors de la zone des conteneurs)
	return nConteneurPrecedent;
};

//////////////////////////////////////////////////////////////////////////
// Lien avec le WL

// Appel d'un PCode navigateur avec transmission d'un rendezvous + creation des parametres serveurs
WDAPBase.prototype.__bAppelPCodeConstruitParam = function __bAppelPCodeConstruitParam(ePCodeNav, sActionServeur, oEvent, oRendezVous)
{
	// Construit les parametres pour le serveur
	if (oRendezVous)
	{
		this.ConstruitParam(oRendezVous);
	}
	else
	{
		this.ConstruitParam();
	}

	return this.__bAppelPCode(ePCodeNav, sActionServeur, oEvent, oRendezVous);
};

// Appel d'un PCode navigateur avec transmission (optionnelle) d'un rendezvous
WDAPBase.prototype.__bAppelPCode = function __bAppelPCode(ePCodeNav, sActionServeur, oEvent, oRendezVous)
{
	// Si on a un rendezvous, construit le type avance correspondant et le transmet au PCode
	var oRes = this.RecuperePCode(ePCodeNav)(oEvent, sActionServeur, oRendezVous ? new WDRendezVous(this, oRendezVous) : undefined);
	// Aucun retour ou Retour = (exactement) true
	if ((oRes === undefined) || (oRes === true))
	{
		return true;
	}
	// Retour = (exactement) false
	if (oRes === false)
	{
		// GP 20/12/2013 : TB85162 : Il faut bien retourner false pour bloquer l'action
		return false;
	}
	// Sinon comparaison souple
	return (oRes != false);
};

//////////////////////////////////////////////////////////////////////////
// WL


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// Vues

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// Classe de base des vues du champ planning
function WDVueAPBase (oChampAP, oVuePrecedente)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		this.m_oChampAP = oChampAP;

		// Objet pour le style
		this.m_oStyle = oVuePrecedente ? oVuePrecedente.m_oStyle : new WDStyleCache(true);

		this.m_nQW237036 = 0;
		this.m_nQW237036Max = bIEAvec11 ? 2 : 0;

		// Init initiale (si besoin)
		this._vInitInitiale();

		// Les callbacks : logiquement c'est dans le controleur mais il n'y a pas encore de controleur
		var oThis = this;
		this.m_fOnRendezVousSupprime = function(oEvent) { oThis.m_oChampAP.OnRendezVousSupprime(oEvent || event); };
		this.m_fOnDefilementCorps = function(oEvent) { oThis.__OnDefilementCorps(oEvent || event); };
		this.m_fOnDefilementCorpsMolette = function(oEvent) { oThis.__OnDefilementCorpsMolette(oEvent || event); };
		if (bTouch)
		{
			this.m_fOnDefilementTouchTitreH = function(nOffsetX, nOffsetY, oEvent) { oThis.__OnDefilementTouchTitre(nOffsetX, 0, oEvent); };
			this.m_fOnDefilementTouchTitreV = function(nOffsetX, nOffsetY, oEvent) { oThis.__OnDefilementTouchTitre(0, nOffsetY, oEvent); };
		}
	}
}

// Zone generale et ses 4 zones filles
WDVueAPBase.prototype.ms_sNomGeneral = "WDPLN-ZoneGenerale";
WDVueAPBase.prototype.ms_sNomBoutonsPeriode = "WDPLN-ZoneBoutonsPeriode";
WDVueAPBase.prototype.ms_sNomTitresHorizontal = "WDPLN-ZoneTitresHorizontal";
WDVueAPBase.prototype.ms_sNomTitresVertical = "WDPLN-ZoneTitresVertical";
WDVueAPBase.prototype.ms_sNomCorps = "WDPLN-ZoneCorps";
WDVueAPBase.prototype.ms_sNomCorpsTitreSeulIndependant = "WDPLN-ZoneCorpsTitreSeulIndependant";

// Titres
// - Titre "conteneur" : titre pour lequel les rendez-vous penvent se d�placer dans la zone
//	Agenda : jour de la semaine
//	Planning : ressources
WDVueAPBase.prototype.ms_sNomTitresConteneurs = "WDPLN-TitresConteneurs";
// - Titre "d�placement" (= "non conteneur") : titre qui servent d'indice pour les d�placements
//	Agenda : heures/semaines
//	Planning : heures/jours/semaines/mois
WDVueAPBase.prototype.ms_sNomTitresSecondaires = "WDPLN-TitresSecondaires";
// Ressources/Jours
// Attention :
// - WDPLN-Conteneur est utilis� pour le style du conteneur, mais c'est WDPLN-ConteneurConteneur qui contient les rendez-vous
// - WDPLN-Conteneur est utilis� comme ID pour l'�lement avec le style WDPLN-ConteneurConteneur
// On fait de m�me avec WDPLN-ConteneurTitreSeul :
// - WDPLN-Conteneur + WDPLN-ConteneurTitreSeul est utilis� comme classe suppl�mentaire mais c'est WDPLN-ConteneurConteneur + WDPLN-ConteneurTitreSeul qui contient les rendez-vous
// - WDPLN-ConteneurTitreSeul est utilis� comme ID pour l'�lement avec le style WDPLN-ConteneurConteneur
WDVueAPBase.prototype.ms_sNomConteneur = "WDPLN-Conteneur";
WDVueAPBase.prototype.ms_sNomConteneurTitreSeul = "WDPLN-ConteneurTitreSeul";
WDVueAPBase.prototype.ms_sNomConteneurRendezVous = "WDPLN-ConteneurRendezVous";
WDVueAPBase.prototype.ms_sNomJour = "WDPLN-Jour";
WDVueAPBase.prototype.ms_sNomJourLigneSupplementaire = "WDPLN-JourLigneSupplementaire";
WDVueAPBase.prototype.ms_sNomJourneeComplete = "WDPLN-JourneeComplete";
WDVueAPBase.prototype.ms_sNomJourneeNonComplete = "WDPLN-JourneeNonComplete";
WDVueAPBase.prototype.ms_sPaddingCompatible = "WDPLN-PaddingCompatible";
// Le premier element
WDVueAPBase.prototype.ms_sNomPremier = "WDPLN-Premier";

// Zone d'affichage des donnees
WDVueAPBase.prototype.ms_sNomCorpsQuadrillage = "WDPLN-ZoneCorpsQuadrillage";
WDVueAPBase.prototype.ms_sNomCorpsDimensionTotale = "WDPLN-ZoneCorpsDimensionTotale";
// Rendez-vous
// - Plac� sur le div externe.
WDVueAPBase.prototype.ms_sNomRendezVousExterne = "WDPLN-RendezVousExterne";
// - Plac� sur le div externe
WDVueAPBase.prototype.ms_sNomRendezVous = "WDPLN-RendezVous";
WDVueAPBase.prototype.ms_sNomRendezVousSelect = "WDPLN-RendezVousSelect";
WDVueAPBase.prototype.ms_sNomRendezVousImage = "WDPLN-RendezVousImage";
WDVueAPBase.prototype.ms_sNomRendezVousTitre = "WDPLN-RendezVousTitre";
WDVueAPBase.prototype.ms_sNomRendezVousTitreSeul = "WDPLN-RendezVousTitreSeul";
WDVueAPBase.prototype.ms_sNomRendezVousSupprime = "WDPLN-RendezVousSupprime";
WDVueAPBase.prototype.ms_sNomRendezVousRepetition = "WDPLN-RendezVousRepetition";
WDVueAPBase.prototype.ms_sNomRendezVousImportance = "WDPLN-RendezVousImportance";
WDVueAPBase.prototype.ms_sNomRendezVousRedimDebut = "WDPLN-RendezVousRedimDebut";
WDVueAPBase.prototype.ms_sNomRendezVousRedimDebutBefore = WDVueAPBase.prototype.ms_sNomRendezVousRedimDebut + ":before";
WDVueAPBase.prototype.ms_sNomRendezVousRedimFin = "WDPLN-RendezVousRedimFin";
WDVueAPBase.prototype.ms_sNomRendezVousRedimFinAfter = WDVueAPBase.prototype.ms_sNomRendezVousRedimFin + ":after";
// Les heures
WDVueAPBase.prototype.ms_sNomFondCouleur = "WDPLN-FondCouleur";
WDVueAPBase.prototype.ms_sNomFondBordure = "WDPLN-FondBordure";
WDVueAPBase.prototype.ms_sNomHeure = "WDPLN-Heure";
WDVueAPBase.prototype.ms_sNomHeureDemi = "WDPLN-HeureDemi";
WDVueAPBase.prototype.ms_sNomHeureLibelle = "WDPLN-HeureLibelle";
WDVueAPBase.prototype.ms_tabHeureSuffixe = ["Normal", "HorsBornes", "Aujourdhui", "Samedi", "Dimanche", "Ferie", "HorsMois"];
WDVueAPBase.prototype.ms_sSuffixePair = "Pair";

// Les z-Index du champ
// 0 : Fond des �l�ments secondaires
WDVueAPBase.prototype.ms_nZIndexFondSecondaire = 0;
// 1 : Fond des conteneur
WDVueAPBase.prototype.ms_nZIndexFondConteneur = 1;
// 2 : Bordure des heures
WDVueAPBase.prototype.ms_nZIndexFondBordureSecondaire = 2;
// 3 : Date et heure (libelles)
// 4 : Rendez-vous
WDVueAPBase.prototype.ms_nZIndexRendezVous = 4;
// 5 : Rendez-vous selectionne
WDVueAPBase.prototype.ms_nZIndexRendezVousSelection = 5;
// 6 : Rupture sur les jours (si applicable : specifique au plannings avec ressources en colonnes)
WDVueAPBase.prototype.ms_nZIndexFondRupture = 6;
// 7 : Bouton de suppression
WDVueAPBase.prototype.ms_nZIndexRendezVousSupprime = 7;
// 8 : Fantome en deplacement
WDVueAPBase.prototype.ms_nZIndexFantome = 8;

// Paddings
WDVueAPBase.prototype.ms_nPaddingTitre = 2;
WDVueAPBase.prototype.ms_nPaddingTitreCalcul = bIEQuirks9Max ? 0 : 2 * WDVueAPBase.prototype.ms_nPaddingTitre;
WDVueAPBase.prototype.ms_nPaddingRendezVous = 3;
WDVueAPBase.prototype.ms_nPaddingLateralDebut = 1;
WDVueAPBase.prototype.ms_nPaddingLateralFin = 5;

// Superposition
WDVueAPBase.prototype.ms_eSuperpositionCoteACote = 0;
WDVueAPBase.prototype.ms_eSuperpositionDecalage = 1;

WDVueAPBase.prototype.ms_sSeparateurFormatLigne = "|";

// Images par defaut
WDVueAPBase.prototype.ms_tabImageDefaut = ({
	ms_sImageVide: "vide.gif",
	ms_sImageSupprime: "pl_delete.gif",
	ms_sImageRepetition: "pl_rdvrepete.gif",
	ms_sImageImportance: "pl_rdvimportant.png",
	ms_sImagePeriodePrecedente: "MoisP.gif",
	ms_sImagePeriodeSuivante: "MoisS.gif"
});

// Si on a une zone de "TitreSeul" ind�pedante, est-elle externe ou dans chaque ligne (ou autres ?)
WDVueAPBase.prototype.ms_bZoneTitreSeulIndependanteExterne = false;
WDVueAPBase.prototype.ms_bZoneTitreSeulIndependanteParLigne = false; // Equivalent � ms_bTableTrParRessource ?
// Si on affiche un libell� dans chaque graduation
WDVueAPBase.prototype.ms_bLibelleParGraduation = false;
// Si on r�ordonne les graduations en affichage
WDVueAPBase.prototype.ms_bReordonneGraduationAffichage = false;

//////////////////////////////////////////////////////////////////////////
// Methodes virtuelles

// Methode d'initialisation generale de la classe (ne s'execute que lors de l'init de la premi�re instance de ce type)
WDVueAPBase.prototype._vInitInitiale = function _vInitInitiale()
{
	// Creation de la feuille de style globale
	WDVueAPBase.prototype.ms_oFeuilleStyleGlobale = clWDUtil.oCreeFeuilleStyle();

	// Regles communes aux champs agendas et plannings (dans les deux orientations)
	// - General
	this.__StyleCreeGlobal("." + this.ms_sNomBoutonsPeriode, ["overflow:hidden"]);
	this.__StyleCreeGlobal("." + this.ms_sNomTitresHorizontal, ["overflow:hidden"]);
	// Le dessin avec clipping ne marche pas dans IE en mode quirks, on fait l'ancien mode avec overflow-x/overflow-y
	if (bIEQuirks9Max)
	{
		// Pour permettre la surcharge de overflow-x dans certains cas
		this.__StyleCreeGlobal("." + this.ms_sNomTitresVertical, ["overflow-x:hidden", "overflow-y:hidden", "z-index:" + this.ms_nZIndexFondRupture, "position:relative"]);
	}
	else
	{
		this.__StyleCreeGlobal("div." + this.ms_sNomTitresVertical, ["overflow:hidden", "z-index:" + this.ms_nZIndexFondRupture]);
	}
	// - Titre
	var tabStyleTitre = ["padding-left:" + this.ms_nPaddingTitre + "px", "padding-right:" + this.ms_nPaddingTitre + "px", "text-overflow:ellipsis", "white-space:nowrap", "overflow:hidden"];
	this.__StyleCreeGlobal("." + this.ms_sNomTitresHorizontal + " div", tabStyleTitre);
	// GP 13/11/2017 : QW292861 : Pour avoir un centrage vertical correct, passe par un display table.
	// GP 06/11/2018 : QW304791 : Passage en "box-sizing: border-box" pour les titres verticaux sur les navigateurs modernes.
	this.__StyleCreeGlobal("." + this.ms_sNomTitresVertical + " div", tabStyleTitre.concat(["display:table", "border-collapse:separate"]).concat(this.ms_tabStyleBoxSizingTitresVerticaux));
	this.__StyleCreeGlobal("." + this.ms_sNomTitresVertical + " span", ["display: table-cell"]);
	// - Rendez-vous
	// GP 09/11/2017 : QW292788 : Si le style contient un padding cela r�duit la zone cliente et les �l�ments en 100% (la zone sensible en d�but et en fin) d�bordement : place l'overflow dans les deux sens.
//	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousExterne, ["overflow-y:hidden", "box-sizing:border-box"]);
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousExterne, ["overflow:hidden", "box-sizing:border-box"]);
	// list-style:none : plac� uniquement sur le ul : il est inutile de le placer sur le li car h�rit� par CSS
	// GP 22/11/2017 : QW293554 : retour vers un display:table pour avoir l'alignement vertical correct
	var tabStyleUL = ["list-style:none", "padding:0", "margin:0", "display:table", "position:relative"];
	if (bEdge)
	{
		// Avec Edge : cela ne fonctionne pas. Il faut mettre le curseur sur tout le conteneur et supprimer le curseur du fils
		tabStyleUL.push("cursor:default");
	}
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousExterne + " ul", tabStyleUL);
	// Le premier li n'a pas besoin de l'alignement vertical. Et si on le laisse en table-cell, les deux li deviennent cote � cote.
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousExterne + " ul li:first-child", ["display:table-row"]);
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousExterne + " ul li", ["display:table-cell"]);
	// GP 22/11/2017 : QW293554 : "!important" pour prendre le pas sur le "display:table-cell" ci dessus qui a un s�lecteur plus pr�cis.
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousTitreSeul, ["display:flex !important", "flex-direction:column", "justify-content:center"]);
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousExterne + " div", ["overflow:hidden"]);
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousImage, ["background-position:bottom left", "background-repeat:no-repeat"]);
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousTitre + " div", ["text-overflow:ellipsis", "white-space:nowrap"]);
	this.__StyleCreeGlobal("." + this.ms_sPaddingCompatible + " ." + this.ms_sNomRendezVousTitre + " div", ["padding-bottom:2px"]);
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousSupprime, ["z-index:" + this.ms_nZIndexRendezVousSupprime, "position:absolute"]);
	var tabRedim = ["content:''", "display: block", "position: absolute", "z-index:1"];
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousRedimDebutBefore, tabRedim);
	this.__StyleCreeGlobal("." + this.ms_sNomRendezVousRedimFinAfter, tabRedim);

	// Ajout des regles
	this.__StyleCreeGlobal("." + this.ms_sNomCorps + " div." + this.ms_sNomConteneur, ["z-index:" + this.ms_nZIndexFondConteneur, "position:absolute"]);
	this.__StyleCreeGlobal("." + this.ms_sNomConteneurTitreSeul, ["z-index:" + this.ms_nZIndexRendezVous, "position:relative"]);
	this.__StyleCreeGlobal("." + this.ms_sNomConteneurRendezVous, ["z-index:" + this.ms_nZIndexRendezVous, "position:relative"]);
	this.__StyleCreeGlobal("." + this.ms_sNomFondCouleur, ["z-index:" + this.ms_nZIndexFondSecondaire, "position:absolute"]);
	this.__StyleCreeGlobal("." + this.ms_sNomFondCouleur + " div", ["z-index:0"]);
	this.__StyleCreeGlobal("." + this.ms_sNomFondBordure, ["z-index:" + this.ms_nZIndexFondBordureSecondaire, "position:absolute"]);
	this.__StyleCreeGlobal("." + this.ms_sNomHeureDemi, ["position:absolute"]);

	// Prechargement des images
	for (var sImage in this.ms_tabImageDefaut)
	{
		if (this.ms_tabImageDefaut.hasOwnProperty(sImage))
		{
			// GP 18/07/2012 : Factorisation du pr�chargement
			WDVueAPBase.prototype[sImage] = clWDUtil.sCheminImageRes(undefined, this.ms_tabImageDefaut[sImage]);
		}
	}

	// S'auto efface pour ne plus etre appele
	WDVueAPBase.prototype._vInitInitiale = clWDUtil.m_pfVide;
};

//////////////////////////////////////////////////////////////////////////
// Manipulation du HTML

WDVueAPBase.prototype.__oGetElementById = function oGetElementById(sSuffixe)
{
	return this.m_oChampAP.oGetElementById(document, sSuffixe);
};
WDVueAPBase.prototype.__sGetSuffixeIDElement = function sGetSuffixeIDElement()
{
	return this.m_oChampAP.sGetSuffixeIDElement.apply(this.m_oChampAP, arguments);
};
WDVueAPBase.prototype.__sGetNomElement = function sGetNomElement(sSuffixe)
{
	return this.m_oChampAP.sGetNomElement(sSuffixe);
};

// Touve le conteneur des rendez-vous d'une ressource
WDVueAPBase.prototype.oGetConteneurDiv = function oGetConteneurDiv(oParametres, nConteneur, bTitreSeul)
{
	return this.__oGetElementById(this._sGetIDConteneur(oParametres, nConteneur, bTitreSeul));
};
WDVueAPBase.prototype._sGetIDConteneur = function _sGetIDConteneur(oParametres, nConteneur, bTitreSeul)
{
	return this.__sGetSuffixeIDElement((bTitreSeul && (0 < this._vnGetHauteurZoneTitreSeulIndependante(oParametres))) ? this.ms_sNomConteneurTitreSeul : this.ms_sNomConteneur, nConteneur);
};
// Si on a une zone pour les titres seul
WDVueAPBase.prototype._vnGetHauteurZoneTitreSeulIndependante = function _vnGetHauteurZoneTitreSeulIndependante(oParametres)
{
	return (!!oParametres.m_nHauteurZoneJourneeComplete ? oParametres.m_nHauteurZoneJourneeComplete : 0);
};
WDVueAPBase.prototype._vnGetReductionLateraleRendezVousPourZoneTitreSeulIndependante = function _vnGetReductionLateraleRendezVousPourZoneTitreSeulIndependante(oParametres)
{
	return this._vnGetHauteurZoneTitreSeulIndependante(oParametres);
};

//////////////////////////////////////////////////////////////////////////
// Construction du HTML

WDVueAPBase.prototype.DetacheEvenement = function DetacheEvenement()
{
	// Supprime l'evenement sur le defilement
	clWDUtil.AttacheDetacheEvent(false, this.m_oHoteCorps, "scroll", this.m_fOnDefilementCorps);
	// Dans le cas touch, c'est g�r� par m_oDragTouchV
	if (this.m_oHoteTitresVertical && !bTouch)
	{
		clWDUtil.AttacheDetacheEvent(false, this.m_oHoteTitresVertical, bFF ? 'DOMMouseScroll' : 'mousewheel', this.m_fOnDefilementCorpsMolette, false);
	}
	if (bTouch)
	{
		if (this.m_oDragTouchH)
		{
			this.m_oDragTouchH.Detache();
		}
		if (this.m_oDragTouchV)
		{
			this.m_oDragTouchV.Detache();
		}
	}
};

// Construit le HTML de base
WDVueAPBase.prototype.HTMLAfficheBase = function HTMLAfficheBase(oHote, bAffichageInitial, oParametres)
{
	if (bAffichageInitial)
	{
		// GP 07/02/2014 : QW242399/TB83681 : Passer en relative a ce moment interf�re avec le script d'ancrage en 100% pour IE10+ en HTML5.
		// => Ces styles sont ajout�s par la HTML en g�n�ration (= assez t�t). On n'a donc plus besoin de le faire ici.
//		// Pour ne pas avoir de problemes en cas d'agrandissement du contenu en AJAX
//		oHote.style.overflow = "hidden";
//		oHote.style.position = "relative";

		this.m_oHote = oHote;
	}
	else
	{
		this.DetacheEvenement();

		// Supprime le contenu
		clWDUtil.SupprimeFils(oHote);
	}

	// Initialise les styles
	this.m_oStyle.Creation();
	this._vInitCSS(oParametres);
	this.m_oStyle.CreationFlush();

	// Construit le HTML
	this.__HTMLAfficheBase(oParametres);
	// Initialisation du style des libelle des jours (qui a besoin de la dimension des elements)
	this.__CalculeDimensionClientCorps();
	this._vInitCSS_LibJour(oParametres);
	this.m_oStyle.CreationFin();

	// Synchronise le scroll des differentes parties
	if (this.m_oHoteTitresHorizontal && bTouch)
	{
		this.m_oDragTouchH = new WDDragTouch(this.m_fOnDefilementTouchTitreH, this.m_oHoteTitresHorizontal);
	}
	if (this.m_oHoteTitresVertical)
	{
		if (bTouch)
		{
			this.m_oDragTouchV = new WDDragTouch(this.m_fOnDefilementTouchTitreV, this.m_oHoteTitresVertical);
		}
		else
		{
			clWDUtil.AttacheDetacheEvent(true, this.m_oHoteTitresVertical, bFF ? 'DOMMouseScroll' : 'mousewheel', this.m_fOnDefilementCorpsMolette, false);
		}
	}

	clWDUtil.AttacheDetacheEvent(true, this.m_oHoteCorps, "scroll", this.m_fOnDefilementCorps);
};

// Construit le HTML de base
WDVueAPBase.prototype.__HTMLAfficheBase = function __HTMLAfficheBase(oParametres)
{
	// Genere la table externe
	var tabHTML = [];
	tabHTML.push("<table class=\"");
	tabHTML.push(this.ms_sNomGeneral);
	tabHTML.push(" ");
	tabHTML.push(this.ms_sNomGeneralSpecifique);
	tabHTML.push("\">");
	tabHTML.push("<tr>");
	var sIDZoneBoutonsPeriode;
	if (0 < oParametres.m_nLargeurTitresVertical)
	{
		sIDZoneBoutonsPeriode = this.__sHTMLAfficheBaseTD(tabHTML, null, this.ms_sNomBoutonsPeriode);
	}
	var sIDZoneTitresHorizontal = this.__sHTMLAfficheBaseTD(tabHTML, this._oGetStyleHorizontalDernier(oParametres), this.ms_sNomTitresHorizontal);
	tabHTML.push("</tr><tr>");
	var sIDZoneCorpsTitreSeulIndependant;
	if (this.ms_bZoneTitreSeulIndependanteExterne && this._vnGetHauteurZoneTitreSeulIndependante(oParametres))
	{
		this.__sHTMLAfficheBaseTD(tabHTML, this._voGetStyleVertical(oParametres), this.ms_sNomTitresVertical + "_");
		sIDZoneCorpsTitreSeulIndependant = this.__sHTMLAfficheBaseTD(tabHTML, null, this.ms_sNomCorpsTitreSeulIndependant);
		tabHTML.push("</tr><tr>");
	}
	var sIDZoneTitresVertical;
	if (0 < oParametres.m_nLargeurTitresVertical)
	{
		sIDZoneTitresVertical = this.__sHTMLAfficheBaseTD(tabHTML, this._voGetStyleVertical(oParametres), this.ms_sNomTitresVertical);
	}
	var sIDZoneCorps = this.__sHTMLAfficheBaseTD(tabHTML, null, this.ms_sNomCorps);
	tabHTML.push("</tr></table>");
	(this.m_oHote.innerHTML = tabHTML.join(""));

	// Recupere les conteneurs
	(this.m_oHoteTitresHorizontal = this.__oGetElementById(sIDZoneTitresHorizontal));
	(this.m_oHoteCorps = this.__oGetElementById(sIDZoneCorps));
	if (0 < oParametres.m_nLargeurTitresVertical)
	{
		(this.m_oHoteBoutonsPeriode = this.__oGetElementById(sIDZoneBoutonsPeriode));
		(this.m_oHoteTitresVertical = this.__oGetElementById(sIDZoneTitresVertical));
	}
	if (sIDZoneCorpsTitreSeulIndependant)
	{
		this.m_oHoteCorpsTitreSeulIndependant = this.__oGetElementById(sIDZoneCorpsTitreSeulIndependant);
	}
};

WDVueAPBase.prototype.__sHTMLAfficheBaseTD = function __sHTMLAfficheBaseTD(tabHTML, oStyle, sSuffixe)
{
	var sIDZone = this.__sGetSuffixeIDElement(sSuffixe);

	// Ajoute le style sur le td pour avoir la couleur de fond sur le petit espaces au dessus des ascenseurs
	tabHTML.push("<td");
	if (oStyle && oStyle.m_cFond)
	{
		tabHTML.push(" style=\"background-color:");
		tabHTML.push(oStyle.m_cFond);
		tabHTML.push("\"");
	}
	tabHTML.push(">");
	this.__HTMLAfficheDiv(tabHTML, sSuffixe, this.__sGetNomElement(sIDZone));
	tabHTML.push("</td>");

	return sIDZone;
};

// Construit un div simple (avec une class et un contenu optionnel)
// tabHTML est mdofie en sortie
WDVueAPBase.prototype.__HTMLAfficheDiv = function __HTMLAfficheDiv(tabHTML, sClass, sId, sContenu, sCouleurFond, sStyle)
{
	// GP 27/10/2021 : QW445810 : Retour en arri�re : Cela ne fonctionne pas car il faut tenir compte du padding dans les calculs de largeur. Et ces padding ne sont pas dans les informations.
//	// Vu par l'applicatif, si un padding est d�fini en �dition, c'est sur ce div qu'il faut l'appliquer.
//	if (sContenu)
//	{
//		if (sClass && sClass.length)
//		{
//			sClass += " padding";
//		}
//		else
//		{
//			sClass = "padding";
//		}
//	}

	tabHTML.push("<div");
	if (sClass)
	{
		tabHTML.push(" class=\"");
		tabHTML.push(sClass);
		tabHTML.push("\"");
	}
	if (sId)
	{
		tabHTML.push(" id=\"");
		tabHTML.push(sId);
		tabHTML.push("\"");
	}
	if (sCouleurFond || sStyle)
	{
		tabHTML.push(" style=\"");
		if (sCouleurFond)
		{
			tabHTML.push("background-color:");
			tabHTML.push(sCouleurFond);
			tabHTML.push(";");
		}
		if (sStyle)
		{
			tabHTML.push(sStyle);
		}
		tabHTML.push("\"");
	}
	tabHTML.push(">");
	// Inutile de tester .length : "" s'�value a faux et "<Contenu>" s'�value � vrai.
	if (sContenu)
	{
		tabHTML.push(sContenu);
	}
	else if (bIEQuirks9Max)
	{
		tabHTML.push("<!-- -->");
	}
	tabHTML.push("</div>");
};
// Pour les libell� multilignes : autorise l'affichage du libell� en modifiant le line-height
WDVueAPBase.prototype.__HTMLAfficheDivLibelle = function __HTMLAfficheDivLibelle(tabHTML, sClass, sLibelle, nLineHeightBase)
{
	var sStyle;
	if (!isNaN(nLineHeightBase))
	{
		var nNbLignes = 1;
		var nDebut = 0;
		// A cause du + 1 on transforme le -1 de non trouv� en 0
		while (0 < (nDebut = sLibelle.indexOf("\n", nDebut) + 1))
		{
			nNbLignes++;
		}
		if (1 < nNbLignes)
		{
			sStyle = "line-height:" + (nLineHeightBase / nNbLignes) + "px";
		}
	}
	this.__HTMLAfficheDiv(tabHTML, sClass, undefined, clWDUtil.sEncodeInnerHTML(sLibelle, true, false), undefined, sStyle);
};

// Calcule la largeur et la hauteur du corps
WDVueAPBase.prototype.__CalculeDimensionCorps = function __CalculeDimensionCorps(oParametres, nLargeur, nHauteur)
{
	(this.m_nLargeurCorps = nLargeur - oParametres.m_nLargeurTitresVertical);
	(this.m_nHauteurCorps = nHauteur - oParametres.m_nHauteurTitresHorizontal);
	// GP 25/02/2016 : TB92261 : M�morise la taille du parent pour le cas de maximisation
	if (this.m_oHote && this.m_oHote.parentNode)
	{
		this.m_oDimensionsHoteParent = this.m_oHote.parentNode.getBoundingClientRect();
	}
};
WDVueAPBase.prototype.__CalculeDimensionClientCorps = function __CalculeDimensionClientCorps()
{
	// this.m_nXxxCorps != this.m_nXxxClientCorps de par la pr�sence de l'ascenseur
	// GP 20/11/2012 : QW224138 : S'il manque une dimension : relance un calcul en forcant la taille
	(this.m_nLargeurClientCorps = this.__nGetClientWidth(this.m_oHoteCorps));
	(this.m_nHauteurClientCorps = this.__nGetClientHeight(this.m_oHoteCorps));
	// GP 20/11/2012 : QW224138 : S'il manque une dimension : relance un calcul en forcant la taille avec la taille de l'ascenseur
	if ((this.m_nLargeurClientCorps <= 1) || (this.m_nHauteurClientCorps <= 1))
	{
		// Force la taille du corps
		this.m_oHoteCorps.style.width = "50px";
		this.m_oHoteCorps.style.height = "50px";

		// Et en d�duit la place de l'ascenseur
		// GP 20/11/2012 : Il semble que dans certains cas le calcul est faux de 1 (�paisseur de la bordure ?) en mode non quriks
		this.m_nLargeurClientCorps = Math.max(0, this.m_nLargeurCorps - (this.m_oHoteCorps.offsetWidth - this.__nGetClientWidth(this.m_oHoteCorps)));
		this.m_nHauteurClientCorps = Math.max(0, this.m_nHauteurCorps - (this.m_oHoteCorps.offsetHeight - this.__nGetClientHeight(this.m_oHoteCorps)));

		// Lib�re la taille du corps
		this.m_oHoteCorps.style.width = "";
		this.m_oHoteCorps.style.height = "";
	}
};

// Initialise les styles
WDVueAPBase.prototype._vInitCSS = function _vInitCSS(oParametres)
{
	// Et initialise les styles du champ
	var nLargeur = this.__nGetLargeur();
	var nHauteur = this.__nGetHauteur();
	this.__CalculeDimensionCorps(oParametres, nLargeur, nHauteur);
	// On n'a pas encore this.m_oHoteCorps
	//	this.__CalculeDimensionClientCorps();

	// Zone generale : taille
	this.__StyleCree(this.__sGetSelecteur(undefined, "", this.ms_sNomGeneral), ["width:" + nLargeur + "px", "height:" + nHauteur + "px"]);
	if (0 < oParametres.m_nLargeurTitresVertical)
	{
		// Zone des boutons en haut
		this.__StyleCree(this.__sGetSelecteur(undefined, "div", this.ms_sNomBoutonsPeriode), ["width:" + oParametres.m_nLargeurTitresVertical + "px", "height:" + oParametres.m_nHauteurTitresHorizontal + "px"]);
		// GP 20/11/2017 : QW292858 : Ne plus mettre la bordure.
//		var tabStyleBoutonsPeriode = this.__tabInitCSS_BorduresMoitie([], oParametres.m_oStyleNormal, "left", oParametres.m_oStyleNormal, "top", false);
//		if (tabStyleBoutonsPeriode.length)
//		{
//			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomBoutonsPeriode, "td", undefined), tabStyleBoutonsPeriode);
//		}
	}
	// Zone de titres : taille
	// - Largeur des titres horizontal = largeur du corps
	this.__StyleCree(this.__sGetSelecteur(undefined, "div", this.ms_sNomTitresHorizontal), ["width:" + this.m_nLargeurCorps + "px", "height:" + oParametres.m_nHauteurTitresHorizontal + "px"]);
	this.__StyleCree(this.__sGetSelecteur(undefined, "table", this.ms_sNomTitresHorizontal), ["height:" + oParametres.m_nHauteurTitresHorizontal + "px"]);

	// Si la zone de "TitreSeule" est independante et externe, on d�cale
	var nHauteurCorps = this.m_nHauteurCorps;
	if (this.ms_bZoneTitreSeulIndependanteExterne)
	{
		nHauteurCorps -= this._vnGetHauteurZoneTitreSeulIndependante(oParametres);
	}
	if (0 < oParametres.m_nLargeurTitresVertical)
	{
		// - Hauteur des titres vertical = hauteur du corps
		this.__StyleCree(this.__sGetSelecteur(undefined, "div", this.ms_sNomTitresVertical), ["width:" + oParametres.m_nLargeurTitresVertical + "px", "height:" + nHauteurCorps + "px"]);
		// Le dessin avec clipping ne marche pas dans IE en mode quirks, on fait l'ancien mode avec overflow-x/overflow-y
		var tabStyle = ["width:" + oParametres.m_nLargeurTitresVertical + "px"];
		if (!bIEQuirks9Max)
		{
			tabStyle.push("position:absolute");
		}
		this.__StyleCree(this.__sGetSelecteur(undefined, "table", this.ms_sNomTitresVertical), tabStyle);
	}
	// Hauteur du bloc de corps
	this.__StyleCree(this.__sGetSelecteur(undefined, "", this.ms_sNomCorps), ["width:" + this.m_nLargeurCorps + "px", "height:" + nHauteurCorps + "px"]);

	// Style des titres horizontaux et verticaux
	this.__StyleCree(this.__sGetSelecteur(this.ms_sNomTitresHorizontal, "div", undefined), ["height:" + oParametres.m_nHauteurTitresHorizontal + "px"]);
	// GP 08/04/2019 : Vu avec TB111341 : C'est m_nLargeurTitresVertical et pas m_nHauteurTitresVertical.
	this.__StyleCree(this.__sGetSelecteur(this.ms_sNomTitresVertical, " div", undefined), ["width:" + (oParametres.m_nLargeurTitresVertical - this.ms_nPaddingTitreCalcul) + "px"]);

	// Style specifique des titres
	this._vInitCSS_TitresConteneurs(oParametres);
	this._vInitCSS_TitresHeures(oParametres);

	// Initialisation du style des conteneurs
	this.__InitCSS_Conteneurs(oParametres);
	// L'init du style des heures est decale pour avoir this.m_nDimensionPxZoneHeures

	// Styles des rendez-vous
	this.__InitCSS_RendezVous(oParametres);
};

// Initialise les styles
WDVueAPBase.prototype.__InitCSS_Resize = function __InitCSS_Resize(oParametres)
{
	// Et initialise les styles du champ
	var nLargeur = this.__nGetLargeur();
	var nHauteur = this.__nGetHauteur();
	this.__CalculeDimensionCorps(oParametres, nLargeur, nHauteur);
	this.__CalculeDimensionClientCorps();

	this.m_oStyle.CreationAjout();
	// Zone generale : taille
	this.__StyleComplete(this.__sGetSelecteur(undefined, "", this.ms_sNomGeneral), ["width:" + nLargeur + "px", "height:" + nHauteur + "px"]);

	// Zone de titres : taille
	// - Largeur des titres horizontal = largeur du corps
	this.__StyleComplete(this.__sGetSelecteur(undefined, "div", this.ms_sNomTitresHorizontal), ["width:" + this.m_nLargeurCorps + "px"]);
	// - Hauteur des titres vertical = hauteur du corps
	this.__StyleComplete(this.__sGetSelecteur(undefined, "div", this.ms_sNomTitresVertical), ["height:" + this.m_nHauteurCorps + "px"]);
	// Hauteur du bloc de corps
	this.__StyleComplete(this.__sGetSelecteur(undefined, "", this.ms_sNomCorps), ["width:" + this.m_nLargeurCorps + "px", "height:" + this.m_nHauteurCorps + "px"]);
	this.m_oStyle.CreationFin();
};

// GP 28/07/2017 : TB104545 : En cas de MAJ AJAX
WDVueAPBase.prototype.__InitCSS_MAJ_AJAX = function __InitCSS_MAJ_AJAX(oParametres)
{
	// Zone generale : taille
	if (0 < oParametres.m_nLargeurTitresVertical)
	{
		// Zone des boutons en haut
		this.__StyleComplete(this.__sGetSelecteur(undefined, "div", this.ms_sNomBoutonsPeriode), ["width:" + oParametres.m_nLargeurTitresVertical + "px", "height:" + oParametres.m_nHauteurTitresHorizontal + "px"]);

	}
	// Zone de titres : taille
	// - Largeur des titres horizontal = largeur du corps
	this.__StyleComplete(this.__sGetSelecteur(undefined, "div", this.ms_sNomTitresHorizontal), ["height:" + oParametres.m_nHauteurTitresHorizontal + "px"]);
	this.__StyleComplete(this.__sGetSelecteur(undefined, "table", this.ms_sNomTitresHorizontal), ["height:" + oParametres.m_nHauteurTitresHorizontal + "px"]);

	// Si la zone de "TitreSeule" est independante et externe, on d�cale
	if (0 < oParametres.m_nLargeurTitresVertical)
	{
		// - Hauteur des titres vertical = hauteur du corps
		this.__StyleComplete(this.__sGetSelecteur(undefined, "div", this.ms_sNomTitresVertical), ["width:" + oParametres.m_nLargeurTitresVertical + "px"]);
		// Le dessin avec clipping ne marche pas dans IE en mode quirks, on fait l'ancien mode avec overflow-x/overflow-y
		this.__StyleComplete(this.__sGetSelecteur(undefined, "table", this.ms_sNomTitresVertical), ["width:" + oParametres.m_nLargeurTitresVertical + "px"]);
	}

	// Style des titres horizontaux et verticaux
	this.__StyleComplete(this.__sGetSelecteur(this.ms_sNomTitresHorizontal, "div", undefined), ["height:" + oParametres.m_nHauteurTitresHorizontal + "px"]);
	// GP 08/04/2019 : Vu avec TB111341 : C'est m_nLargeurTitresVertical et pas m_nHauteurTitresVertical.
	this.__StyleComplete(this.__sGetSelecteur(this.ms_sNomTitresVertical, " div", undefined), ["width:" + (oParametres.m_nLargeurTitresVertical - this.ms_nPaddingTitreCalcul) + "px"]);

};

// Affiche le contenu
// bRAZ : indique s'il faut supprimer le precedent contenu
WDVueAPBase.prototype.HTMLAfficheContenu = function HTMLAfficheContenu(bRAZDejaFait, bChangementParametres, nDimensionPxGraduationSiResize, oParametreFusion, oParametres, tabRendezVous, oOldDonnees, oHote)
{
	var bFusion = !!oParametreFusion;
	if (!bFusion)
	{
		if (!bRAZDejaFait)
		{
			this.__HTMLVideContenu(oParametres, oOldDonnees, false);
		}
	}

	if (undefined !== nDimensionPxGraduationSiResize)
	{
		// Normalement on n'a pas bFusion
		if (!bFusion)
		{
			clWDUtil.SetDisplay(this.m_oHoteCorps, true);
		}
		// MAJ du CSS
		this.__InitCSS_Resize(oParametres);
		if (!bFusion)
		{
			clWDUtil.SetDisplay(this.m_oHoteCorps, false);
		}
	}

	this.__CorrigeParametres(oParametres);

	if (!bFusion)
	{
		// Initialise le tableau des positions des heures
		this.__InitPositionsHeures(oParametres);

		// Decale pour avoir this.m_nDimensionPxZoneHeures (intialise par __InitPositionsHeures)
		// On ne peut calculer ce style que maintenant (que l'on a this.m_nDimensionPxZoneHeures)
		this.m_oStyle.CreationAjout();
		if (bChangementParametres)
		{
			this.__InitCSS_MAJ_AJAX(oParametres)
		}
		this.__StyleComplete(this.__sGetSelecteur(undefined, "", this.ms_sNomCorpsDimensionTotale), [this.ms_sStyleDimension + ":" + this.m_nDimensionPxZoneHeures + "px"]);
		this.__InitCSS_Heures(oParametres);
		// GP 05/09/2012 : QW221896 : Si le nombre de ressources change, il faut faire une MAJ des largeurs
		this.__InitCSS_Conteneurs(oParametres);
		this._vInitCSS_TitresConteneurs(oParametres);
		// GP 14/10/2013 : QW237036
		this._vInitCSS_TitresHeures(oParametres);
		this.m_oStyle.CreationFin();

		// Construit la zone de bouton de changement de periode
		this.__HTMLAfficheBoutonsPeriode(oParametres);
		// Construit les zones des titres
		this.__HTMLAfficheTitresHorizontal(oParametres);
		this.__HTMLAfficheTitresVertical(oParametres);
		// Construit la zone des rendez vous
		this.__HTMLAfficheCorps(oParametres);
	}

	// Construit les rendez-vous
	this.__HTMLAfficheRendezVous(oParametreFusion, oParametres, tabRendezVous);

	// Et affiche le rendez-vous selectionne (n'entre pas en saisie immediatement car on est non affiche)
	this.__HTMLAfficheRendezVousSelection(null, oParametres, false);

	if (!bFusion)
	{
		clWDUtil.SetDisplay(this.m_oHoteCorps, true);
	}

	// Fait defiler apres l'affichage
	this.__HTMLAfficheCorpsDefilement(bFusion, oParametres, nDimensionPxGraduationSiResize, oHote);

	this.__HTMLAfficheRendezVousSelectionApresAffichage(null, oParametres);

	// Declenche la synchronisation des scrolling (et des largeurs)
	this.m_oChampAP.nSetTimeoutUnique("__OnDefilementCorps", clWDUtil.ms_oTimeoutImmediat);
};

// Indique que le champ est redimensionne : supprime le contenu
WDVueAPBase.prototype.HTMLVideContenuSurOnResize = function HTMLVideContenuSurOnResize(oParametres, oOldDonnees)
{
	this.__HTMLVideContenu(oParametres, oOldDonnees, true);
	// Modifie temporairement la taille du corps
	this.m_oStyle.CreationAjout();
	this.__StyleComplete(this.__sGetSelecteur(undefined, "", this.ms_sNomGeneral), ["width:1px", "height:1px"]);
	this.__StyleComplete(this.__sGetSelecteur(undefined, "", this.ms_sNomCorps), ["width:1px", "height:1px"]);
	this.m_oStyle.CreationFin();
	// GP 20/11/2012 : QW224138 : Ce code pose probl�me dans certains cas (fait que la table � une petite taille)
	// Mais d'un autre cot�, sans ce code impossible de r�duire la vue
	(this.m_oHoteTitresHorizontal.style.width = "1px");
	if (this.m_oHoteTitresVertical)
	{
		(this.m_oHoteTitresVertical.style.height = "1px");
	}
};

// GP 24/07/2017 : C'est inutile, en cas de changement de tranche on re�oit un "resize" et donc le champ est redessin�
//// Changement de tranche
//WDVueAPBase.prototype.OnChangementTranche = function OnChangementTranche(oEvent, nTrancheDepuisDefautBase1)
//{
//	@@@;
//};

// Precalculs
WDVueAPBase.prototype.__CorrigeParametres = function __CorrigeParametres(oParametres)
{
	if (undefined === oParametres.m_nHeureAfficheMinOriginal)
	{
		// Precalculs
		if (oParametres.m_nResolutionGrille >= 86400000)
		{
			// Si on est en affichage par jour (ou plus)
			// => this.vnGetDimensionPxGraduation() contient en fait la hauteur d'un jour
			// 86400000 = 24 * 3600 * 1000 = 1 jour en ms
			this.m_nGraduationDureeMs = 86400000;
			// Jamais de ruptures ou de rendez-vous � la journ�e dans ce mode
			oParametres.m_nHauteurLibJour = 0;
			oParametres.m_bZoneJourneeComplete = false;
			oParametres.m_nHauteurZoneJourneeComplete = 0;
		}
		else if (oParametres.m_nResolutionGrille == 43200000)
		{
			// Si on est en affichage par demi-journee (exactement)
			// => this.vnGetDimensionPxGraduation() contient en fait la hauteur d'un jour
			// On affiche une seule zone pour la journee
			// 86400000 = 24 * 3600 * 1000 = 1 jour en ms
			this.m_nGraduationDureeMs = 86400000;
		}
		else
		{
			// Si on est en affichage par heure
			// 3600000 = 3600 * 1000 = 1 heure en ms
			this.m_nGraduationDureeMs = 3600000;
		}

		// Calcule les heures ouvrables (arrondi a l'heure pres)
		// => On corrige la valeur des parametres pour ne pas refaire le calcul partout
		// Ces 4 valeurs sont en heures (et pas en ms commes les valeurs de oParametres)
		var nHeureOuvrableMin, nHeureOuvrableMax, nHeureAfficheMin, nHeureAfficheMax;

		// Si on est en affichage par heure prend les valeurs transmisses
		if (this.m_nGraduationDureeMs == 3600000)
		{
			nHeureOuvrableMin = this.__nGetHeureArrondiDefaut(oParametres.m_nHeureOuvrableMin);
			nHeureOuvrableMax = this.__nGetHeureArrondiExces(oParametres.m_nHeureOuvrableMax);
			nHeureAfficheMin = this.__nGetHeureArrondiDefaut(oParametres.m_nHeureAfficheMin);
			nHeureAfficheMax = this.__nGetHeureArrondiExces(oParametres.m_nHeureAfficheMax);
		}
		else
		{
			// En affichage par demi-journee ou par journee
			nHeureOuvrableMin = 0;
			nHeureOuvrableMax = 24;
			nHeureAfficheMin = 0;
			nHeureAfficheMax = 24;
		}
		oParametres.m_nHeureAfficheMinOriginal = nHeureAfficheMin * 3600000;
		oParametres.m_nHeureAfficheMaxOriginal = nHeureAfficheMax * 3600000;
		if (this._vbAfficheTouteslesHeures(oParametres))
		{
			nHeureAfficheMin = 0;
			nHeureAfficheMax = 24;
			oParametres.m_oDateDebut.setUTCHours(0, 0, 0, 0);
			oParametres.m_oDateFin.setUTCHours(0, 0, 0, 0);
			oParametres.m_oDateFin.setTime(oParametres.m_oDateFin.getTime() + 86400000);
		}

		// Reforce les valeurs corrigees
		oParametres.m_nHeureOuvrableMin = nHeureOuvrableMin * 3600000;
		oParametres.m_nHeureOuvrableMax = nHeureOuvrableMax * 3600000;
		oParametres.m_nHeureAfficheMin = nHeureAfficheMin * 3600000;
		oParametres.m_nHeureAfficheMax = nHeureAfficheMax * 3600000;
	}
};

// Uniquement si pas fusion
WDVueAPBase.prototype.__InitPositionsHeures = function __InitPositionsHeures(oParametres)
{
	var nHeureOuvrableMin = oParametres.m_nHeureOuvrableMin / 3600000;
	var nHeureOuvrableMax = oParametres.m_nHeureOuvrableMax / 3600000;
	var nHeureAfficheMin = oParametres.m_nHeureAfficheMin / 3600000;
	var nHeureAfficheMax = oParametres.m_nHeureAfficheMax / 3600000;

	// Si on trouve une heure dans aujourd'hui on l'affichera
	(this.m_nPositionAujourdhui = -1);

	var oHeure = new Date(oParametres.m_oDateDebut);
	oHeure.setUTCMinutes(0, 0, 0);

	// Commence a -1 car des le debut on va passer au jour suivant
	var nJour = -1;
	var oJour;
	var nPosition = 0;
	var bRupture = false;
	var nDimensionPxGraduation = this.vnGetDimensionPxGraduation(oParametres);
	var oDateFin = this.voGetDateFinAffichage(oParametres);
	var nHeureStyle, nHeureStyleAvecAujourdhui;
	var bAujourdhui;
	var nNbGraduationsParalleles = this._vnGetNbGraduationsParalleles(oParametres);
	var bLignePaire = false;
	// Pour facilite la conversion position => Date, on stocke l'heure de debut chaque graduation (bloc html) dans un tableau
	// Si on n'est pas en mode par heure : contient le debut par
	var tabGraduations = [];

	// - Boucle de calcul
	for (; oHeure < oDateFin; oHeure.setTime(oHeure.getTime() + this.m_nGraduationDureeMs))
	{
		var nHeure = oHeure.getUTCHours();

		// Teste si on change de jour et que l'on doit alors affiche une rupture de jour
		// Ou si on est sur la premiere ligne
		if ((0 == nHeure) || (nJour == -1))
		{
			nJour++;
			// Trouve la description du jour
			oJour = oParametres.m_tabJours[nJour];

			if (oJour.m_bAujourdhui)
			{
				this.m_nPositionAujourdhui = nPosition;
				bAujourdhui = true;
			}
			else
			{
				bAujourdhui = false;
			}

			// Affiche les ruptures de jour (si besoin)
			nPosition += this._vnGetHauteurRuptureJour(oParametres);
			// Dans le cas d'un affichage � la semaine dans l'agenda, on passe � la colonne suivante
			if (this.ms_bReordonneGraduationAffichage)
			{
				nPosition = 0;
			}
			else
			{
				// Si on n'a pas de ruptures, oParametres.m_nHauteurLibJour n'est pas defini ou est a 0
				bRupture = true;
			}
		}

		// Si l'heure n'est pas affichee
		if ((nHeure < nHeureAfficheMin) || (nHeure >= nHeureAfficheMax))
		{
			// N'ecrase pas bRupture car on veux la premiere heure du jour courant)
			continue;
		}
		// GP 23/03/2015 : TB91666 : oHeure doit �tre interpr�t� en UTC (voir l'appel ci dessus de getUTCHours)
		nHeureStyle = this._nGetHeureStyle(oHeure.getUTCDay(), oJour, nHeure, nHeureOuvrableMin, nHeureOuvrableMax);

		// Objet resultat
		var oGraduation = {
			m_oDateDebut: new Date(oHeure),
			m_nPosition: nPosition,
			m_sClasses: this.__sGetGraduationClasses(nHeureStyle, bAujourdhui, bLignePaire && this.ms_bLibelleParGraduation)
		};

		if (bRupture)
		{
			oGraduation.m_bRupture = true;
			oGraduation.m_sRuptureLibelle = oJour.m_sLibelle;
			bRupture = false;
		}
		// Vraiment utile ? On place d�j� correctement le style
		// Dans quel cas on a besoin de reforcer la couleur de fond ?
		nHeureStyleAvecAujourdhui = bAujourdhui ? 2 : nHeureStyle;
		var oStyleHeureStyleAvecAujourdhui = oParametres["m_oStyle" + this._sGetHeureSuffixe(nHeureStyleAvecAujourdhui, bLignePaire && this.ms_bLibelleParGraduation)];
		oGraduation.m_sClassesHeure = oStyleHeureStyleAvecAujourdhui.m_sClasses;
		if (0 < nHeureStyleAvecAujourdhui)
		{
			// Si on a un style d'heure non standard on reforce la couleur de fond
			oGraduation.m_sCouleurFond = oStyleHeureStyleAvecAujourdhui.m_cFond;
		}
		// Affiche le libelle des heures/jours selon le mode
		if ((oParametres.m_nResolutionGrille >= 86400000) || ((oParametres.m_nResolutionGrille == 43200000) && !oParametres.m_nHauteurLibJour))
		{
			// Libelle du jour avec le style de la rupture :
			// - Si on est en affichage par jour (ou plus)
			// - Si on est en affichage par demi-journee (exactement) + sans ruptures
			oGraduation.m_sLibelle = oJour.m_sLibelle;
			// GP 11/02/2013 : QW229681 : Calcul avec le bon style
			if (this.ms_bLibelleParGraduation)
			{
				oGraduation.m_sLibelleClasse = oStyleHeureStyleAvecAujourdhui.m_sClasses;
			}
			else
			{
				oGraduation.m_sLibelleClasse = oParametres.m_oStyleLibJourSemaine.m_sClasses;
			}
			oGraduation.m_sLibelleCouleurFond = oParametres.m_oStyleLibJourSemaine.m_cFond;
		}
		else
		{
			// Si on est en affichage par demi-journee (exactement) + avec ruptures
			// Si on est en affichage par heure : libelle des heures avec la classe par defaut, sinon rien
			oGraduation.m_sLibelle = (oParametres.m_nResolution != 43200000) ? this.__sHTMLAfficheFormateHeure(oParametres, nHeure) : "";
			oGraduation.m_sLibelleClasse = oParametres.m_oStyleLibHeure.m_sClasses;
			// Pas de couleur de fond
		}

		tabGraduations.push(oGraduation);

		if ((0 == (tabGraduations.length % nNbGraduationsParalleles)) || this.ms_bReordonneGraduationAffichage)
		{
			nPosition += nDimensionPxGraduation;
			bLignePaire = !bLignePaire;
		}
	}

	// Dimension totale de la zone des heures
	(this.m_nDimensionPxZoneHeures = nPosition);
	// Pour facilite la conversion position => Date, on stocke l'heure de debut chaque graduation (bloc html) dans un tableau
	// Si on n'est pas en mode par heure : contient le debut par
	(this.m_tabGraduations = tabGraduations);
};

// Retourne le suffixe d'une graduation
WDVueAPBase.prototype._sGetHeureSuffixe = function _sGetHeureSuffixe(nHeureStyle, bLignePaireEtLibelleParGraduation)
{
	// GP 29/11/2012 : QW226840 : On a des lignes pair/impair, uniquement sur les vue au mois ou a l'ann�e
	return this.ms_tabHeureSuffixe[nHeureStyle] + (bLignePaireEtLibelleParGraduation ? this.ms_sSuffixePair : "");
};

// Calcule la/les classe(s) a utiliser pour une heure
WDVueAPBase.prototype.__sGetGraduationClasses = function __sGetGraduationClasses(nHeureStyle, bAujourdhui, bLignePaireEtLibelleParGraduation)
{
	var tabClasseTypeHeure = [this.ms_sNomHeure];
	tabClasseTypeHeure.push("WDPLN-" + this._sGetHeureSuffixe(nHeureStyle, bLignePaireEtLibelleParGraduation));

	// Si on est dans aujourdhui
	if (bAujourdhui)
	{
		tabClasseTypeHeure.push("WDPLN-" + this._sGetHeureSuffixe(2, bLignePaireEtLibelleParGraduation));
	}

	return tabClasseTypeHeure.join(" ");
};

// Calcule le style d'une heure
WDVueAPBase.prototype._nGetHeureStyle = function _nGetHeureStyle(nJourSemaine, oJour, nHeure, nHeureOuvrableMin, nHeureOuvrableMax)
{
	// Par ordre de priorite :

	if (oJour.m_bHorsPeriode)
	{
		// - Si c'est un jour hors p�riode
		return 6;
	}
	else if (oJour.m_bFerie)
	{
		// - Si c'est un jour ferie
		return 5;
	}
	else if ((undefined !== nHeure) && ((nHeure < nHeureOuvrableMin) || (nHeure >= nHeureOuvrableMax)))
	{
		// - Si l'heure est non ouvrable
		return 1;
	}
	else
	{
		// - L'heure est ouvrable : prend le style du jour
		switch (nJourSemaine)
		{
		case 6:
			// Samedi
			return 3;
		case 0:
			// Dimanche
			return 4;
		default:
			// Par defaut le style est celui d'une heure ouvrable
			return 0;
		}
	}
};

// Formatage d'une heure pour affichage
WDVueAPBase.prototype.__sHTMLAfficheFormateHeure = function __sHTMLAfficheFormateHeure(oParametres, nHeure)
{
	// Trouve l'heure qui correspond
	return oParametres.m_tabFormatHeure[nHeure];
};

// Construit la zone de bouton de changement de periode
WDVueAPBase.prototype.__HTMLAfficheBoutonsPeriode = function __HTMLAfficheBoutonsPeriode(oParametres)
{
	if (this.m_oHoteBoutonsPeriode)
	{
		var nNbBoutons = (oParametres.m_oDateDebutPrecedente ? 1 : 0) + (oParametres.m_oDateDebutSuivante ? 1 : 0);

		// Ajoute un div vide ou une table si on a les bouton de changement de periode
		if (0 < nNbBoutons)
		{
			var tabHTML = [];
			var nDimension = Math.min(oParametres.m_nHauteurTitresHorizontal, parseInt(oParametres.m_nLargeurTitresVertical / nNbBoutons, 10));
			// Si on a une bordure : il faut en tenir compte
			if (0 < oParametres.m_oStyleNormal.m_nBordureV)
			{
				nDimension -= oParametres.m_oStyleNormal.m_nBordureV;
			}

			// Si on a au moins un des boutons : ajoute une table (on a deja le DIV avec la taille)
			tabHTML.push("<table width=\"100%\" height=\"100%\"><tr>");
			// Premier bouton
			if (oParametres.m_oDateDebutPrecedente)
			{
				this.__HTMLAfficheUnBoutonPeriode(tabHTML, "__OnAffichePeriodePrecedente", oParametres, nDimension, oParametres.m_sImageBtnPeriodePrecedente, this.ms_sImagePeriodePrecedente);
			}
			// Second bouton
			if (oParametres.m_oDateDebutPrecedente)
			{
				this.__HTMLAfficheUnBoutonPeriode(tabHTML, "__OnAffichePeriodeSuivante", oParametres, nDimension, oParametres.m_sImageBtnPeriodeSuivante, this.ms_sImagePeriodeSuivante);
			}
			// TD intermediaire
			if (nDimension == oParametres.m_nHauteurTitresHorizontal)
			{
				tabHTML.push("<td width=\"100%\"/>");
			}
			tabHTML.push("</tr></table>");
			this.m_oHoteBoutonsPeriode.innerHTML = tabHTML.join("");
		}
	}
};

// Construit le HTML d'un des boutons de changement de periode
WDVueAPBase.prototype.__HTMLAfficheUnBoutonPeriode = function __HTMLAfficheUnBoutonPeriode(tabHTML, sCallback, oParametres, nDimension, sImage, sImageDefaut)
{
	tabHTML.push("<td vAlign=\"center\" align=\"center\" style=\"background-repeat: no-repeat; background-position: center center; background-image:");
	// Si on n'a pas d'image, prend l'image par defaut
	// GP 11/02/2014 : QW242506 : _WD_ est probablement faux en PHP/statique (par rapport � AWP)
	// Pour corriger simplement on d�tecte la p�sence de _WDR_
	tabHTML.push(clWDUtil.sGetURICSS(clWDUtil.sGetCheminImage(sImage, sImageDefaut)));
	tabHTML.push("\"");
	// Inutile de tester .length : "" s'�value a faux et "<Contenu>" s'�value � vrai.
	if (oParametres.m_oStyleBtnSuivPrec && oParametres.m_oStyleBtnSuivPrec.m_sClasses)
	{
		tabHTML.push(" class=\"");
		tabHTML.push(oParametres.m_oStyleBtnSuivPrec.m_sClasses);
		tabHTML.push("\"");
	}
	tabHTML.push("><a href=\"javascript:{oGetObjetChamp(\'");
	tabHTML.push(this.m_oChampAP.m_sAliasChamp);
	tabHTML.push("\').");
	tabHTML.push(sCallback);
	tabHTML.push("();}\"><img border=\"0\" src=\"");
	tabHTML.push(this.ms_sImageVide);
	tabHTML.push("\" width=\"");
	tabHTML.push(nDimension);
	tabHTML.push("\" height=\"");
	tabHTML.push(nDimension);
	tabHTML.push("\"></a></td>");
};

// Construit la zone des rendez vous
WDVueAPBase.prototype.__HTMLAfficheCorps = function __HTMLAfficheCorps(oParametres)
{
	var tabHTML = this._vtabHTMLAfficheCorps(oParametres, []);
	(this.m_oHoteCorps.innerHTML = tabHTML.join(""));

	// Gestion du clic sur les ressources
	var i;
	var nLimiteI = this.m_oChampAP._nGetNbConteneurs(false);
	for (i = 0; i < nLimiteI; i++)
	{
		var oConteneur = this.m_oChampAP._oGetConteneur(false, i);
		oConteneur.m_oDiv = this.oGetConteneurDiv(oParametres, i, false);
		var oDivTitreSeul = this.oGetConteneurDiv(oParametres, i, true);
		if (oDivTitreSeul)
		{
			oConteneur.m_oDivTitreSeul = oDivTitreSeul;
		}
		this.m_oChampAP.m_oDragPeriodeSelect.vInitElement(oConteneur, i, oConteneur.m_oDiv, oDivTitreSeul);
	}
};
WDVueAPBase.prototype._vtabHTMLAfficheCorps = function _vtabHTMLAfficheCorps(oParametres, tabHTML)
{
	var tabJours = oParametres.m_tabJours;
	var nHauteurZoneJourneeComplete = oParametres.m_nHauteurZoneJourneeComplete;

	// Selon la position des heures initialise
	var tabGraduations = this.m_tabGraduations;
	var nGraduation;
	var oGraduation;
	var nNbGraduations = tabGraduations.length;
	var nNbLignes = 1;
	var nNbColonnes = 1;
	if (this.ms_bReordonneGraduationAffichage)
	{
		nNbColonnes = this._vnGetNbGraduationsParalleles(oParametres);
		nNbLignes = nNbGraduations / nNbColonnes;
	}

	tabHTML.push("<table>");

	var nConteneur;
	var nNbConteneurs = this.m_oChampAP._nGetNbConteneurs(false);
	var tabHTMLFondCouleur;
	var tabHTMLFondBordure;
	for (nConteneur = 0; nConteneur < nNbConteneurs; nConteneur++)
	{
		// Sauf si c'est la premiere (ouverte au dessus)
		if (this.ms_bTableTrParRessource)
		{
			tabHTML.push("<tr class=\"");
			tabHTML.push(this.ms_sNomCorpsDimensionTotale);
			tabHTML.push("\">");
		}
		else if (0 == nConteneur)
		{
			tabHTML.push("<tr>");
		}

		// Le fond :
		// En ligne : sur toutes les lignes
		// En colonne : sur une ligne ind�pendante au d�but
		if (this.ms_bTableTrParRessource || (0 == nConteneur))
		{
			tabHTML.push("<td ");
			if (!this.ms_bTableTrParRessource)
			{
				tabHTML.push("colspan=\"");
				tabHTML.push(this.m_oChampAP._nGetNbConteneurs(false));
				tabHTML.push("\" ");
			}
			tabHTML.push("class=\"");
			tabHTML.push(this.ms_sNomCorpsQuadrillage);
			tabHTML.push("\">");

			if (nHauteurZoneJourneeComplete && this.ms_bZoneTitreSeulIndependanteParLigne)
			{
				tabHTMLFondCouleur = this.__tabHTMLAfficheCorpsHeureDebut(this.ms_sNomFondCouleur);
				tabHTMLFondBordure = this.__tabHTMLAfficheCorpsHeureDebut(this.ms_sNomFondBordure);

				for (nGraduation = 0; nGraduation < nNbGraduations; nGraduation++)
				{
					oGraduation = tabGraduations[nGraduation];
					if (oGraduation.m_bRupture)
					{
						// La partie avec la couleur : dessous : div vide
						this.__HTMLAfficheDiv(tabHTMLFondCouleur, this.ms_sNomJourneeComplete);
						// La partie avec les bordures : dessous : div vide
						this.__HTMLAfficheDiv(tabHTMLFondBordure, this.ms_sNomJourneeComplete);
					}
				}

				// Ferme les tableaux et les fusionne avec le tableau global
				tabHTML.push("<div>");
				tabHTMLFondCouleur.push("</div>");
				tabHTML = tabHTML.concat(tabHTMLFondCouleur);
				tabHTMLFondBordure.push("</div>");
				tabHTML = tabHTML.concat(tabHTMLFondBordure);
				tabHTML.push("</div>");
				tabHTML.push("<div class=\"");
				tabHTML.push(this.ms_sNomJourneeNonComplete);
				tabHTML.push("\">");
			}
			else
			{
				tabHTML.push("<div>");
			}

			// On construit en parallele les DIVs pour la couleur de fond et pour la couleur
			tabHTMLFondCouleur = this.__tabHTMLAfficheCorpsHeureDebut(this.ms_sNomFondCouleur);
			tabHTMLFondBordure = this.__tabHTMLAfficheCorpsHeureDebut(this.ms_sNomFondBordure);

			for (nGraduation = 0; nGraduation < nNbGraduations; nGraduation++)
			{
				oGraduation = tabGraduations[(nGraduation % nNbColonnes) * nNbLignes + parseInt(nGraduation / nNbColonnes, 10)];

				// Si on a une rupture : ajoute l'espace
				if (oGraduation.m_bRupture)
				{
					if (oParametres.m_nHauteurLibJour)
					{
						// La partie avec la couleur : dessous : div vide
						this.__HTMLAfficheDiv(tabHTMLFondCouleur, this.ms_sNomJour);
						// La partie avec les bordures : dessous : div vide
						this.__HTMLAfficheDiv(tabHTMLFondBordure, this.ms_sNomJour);
					}
					if (nHauteurZoneJourneeComplete && !this.ms_bZoneTitreSeulIndependanteExterne && !this.ms_bZoneTitreSeulIndependanteParLigne)
					{
						// La partie avec la couleur : dessous : div vide
						this.__HTMLAfficheDiv(tabHTMLFondCouleur, this.ms_sNomJourneeComplete);
						// La partie avec les bordures : dessous : div vide
						this.__HTMLAfficheDiv(tabHTMLFondBordure, this.ms_sNomJourneeComplete);
					}
				}

				// La partie avec la couleur : dessous
				var sClassesFond = oGraduation.m_sClasses;
				// Inutile de tester .length : "" s'�value a faux et "<Contenu>" s'�value � vrai.
				sClassesFond = sClassesFond + (sClassesFond ? " " : "") + oGraduation.m_sClassesHeure;
				this.__HTMLAfficheDiv(tabHTMLFondCouleur, sClassesFond, undefined, undefined, oGraduation.m_sCouleurFond);

				// La partie avec la bordure : dessus
				tabHTMLFondBordure.push("<div class=\"");
				if (this.ms_bLibelleParGraduation)
				{
					// GP 11/02/2013 : QW229681 : Il faut mettre le style (dans le bon ordre)
					tabHTMLFondBordure.push(clWDUtil.sOptimiseClasses(oGraduation.m_sClasses + " " + oGraduation.m_sLibelleClasse));
					// Il fut forcer la couleur de fond (qui est peut-�tre �cras� par un des styles)
					tabHTMLFondBordure.push("\" style=\"background-color:transparent");
				}
				else
				{
					tabHTMLFondBordure.push(oGraduation.m_sClasses);
					// GP 20/11/2013 : QW237310 : Ajoute la marque sur la derni�re graduation
					if (nGraduation == (nNbGraduations - 1))
					{
						tabHTMLFondBordure.push(" " + this.ms_sNomPremier);
					}
				}
				tabHTMLFondBordure.push("\">");
				// Si on n'est pas en affichage a la journee (mais la demi-journee est acceptee)
				if (this.__bAfficheDemiHeures(oParametres))
				{
					this.__HTMLAfficheDiv(tabHTMLFondBordure, this.ms_sNomHeureDemi);
				}
				else if (this.ms_bLibelleParGraduation)
				{
					// GP 13/03/2013 : QW230834 : Damande de SYC : force un blanc tournant (normalement moins prioritaire que si c'est d�fini en �dition (qui viens surcharger)
					// dans un SPAN pour ne pas casser la taille de l'�lement au dessus
					tabHTMLFondBordure.push("<span>");
					tabHTMLFondBordure.push(tabJours[nGraduation].m_sLibelle);
					tabHTMLFondBordure.push("</span>");
				}
				else if (bIEQuirks9Max)
				{
					tabHTMLFondBordure.push("<!-- -->");
				}
				tabHTMLFondBordure.push("</div>");
			}

			// Ferme les tableaux et les fusionne avec le tableau global
			tabHTMLFondCouleur.push("</div>");
			tabHTML = tabHTML.concat(tabHTMLFondCouleur);
			tabHTMLFondBordure.push("</div>");
			tabHTML = tabHTML.concat(tabHTMLFondBordure);

			tabHTML.push("</div></td>");

			if (!this.ms_bTableTrParRessource)
			{
				tabHTML.push("</tr><tr class=\"");
				tabHTML.push(this.ms_sNomCorpsDimensionTotale);
				tabHTML.push("\">");
			}
		}

		tabHTML.push("<td class=\"");
		tabHTML.push(this.ms_sNomConteneur);
		// GP 18/11/2013 : QW237309 : Reset de la hauteur des fils en HTML5
		tabHTML.push(" lh0");
		if (0 == nConteneur)
		{
			tabHTML.push(" " + this.ms_sNomPremier);
		}
		tabHTML.push("\">");
		this.__HTMLAfficheDiv(tabHTML, this.ms_sNomConteneur + " " + this.ms_sNomCorpsDimensionTotale);
		if (nHauteurZoneJourneeComplete && this.ms_bZoneTitreSeulIndependanteParLigne)
		{
			this.__HTMLAfficheDiv(tabHTML, this.ms_sNomConteneurTitreSeul, this.__sGetNomElement(this._sGetIDConteneur(oParametres, nConteneur, true)));
		}
		var sClasseConteneurRendezVous = this.ms_sNomConteneurRendezVous + " " + this.ms_sNomCorpsDimensionTotale;
		if (oParametres.m_bMargeFixes)
		{
			sClasseConteneurRendezVous += " " + this.ms_sPaddingCompatible;
		}
		this.__HTMLAfficheDiv(tabHTML, sClasseConteneurRendezVous, this.__sGetNomElement(this._sGetIDConteneur(oParametres, nConteneur, false)));
		tabHTML.push("</td>");

		if (this.ms_bTableTrParRessource)
		{
			tabHTML.push("</tr>");
		}
	}

	// Si on n'a pas une ligne par ressource, il faut au minimum un td pour avoir la taille
	if (0 == nNbConteneurs)
	{
		if (!this.ms_bTableTrParRessource)
		{
			tabHTML.push("<td/>");
		}
		else
		{
			tabHTML.push("<td>");
			this.__HTMLAfficheDiv(tabHTML, this.ms_sNomCorpsDimensionTotale);
			tabHTML.push("</td>");
		}
	}

	// Si on a ouvert un tr specifiquement, ou si on n'a jamais fermer le premier (cas this.ms_bTableTrParRessource + 0 == nNbConteneurs)
	if (!this.ms_bTableTrParRessource || (0 == nNbConteneurs))
	{
		tabHTML.push("</tr>");
	}
	tabHTML.push("</table>");
	return tabHTML;
};

WDVueAPBase.prototype.__bAfficheDemiHeures = function __bAfficheDemiHeures(oParametres)
{
	return (oParametres.m_nResolutionGrille < 86400000);
};

// Defilement du corps
WDVueAPBase.prototype.__HTMLAfficheCorpsDefilement = function __HTMLAfficheCorpsDefilement(bFusion, oParametres, nDimensionPxGraduationSiResize, oHote)
{
	var nPositionDefilement;

	// GP 11/02/2013 : QW228694 : Il faut faire le second test (this.m_oDefilementPrincipalDate.getTime() == oParametres.m_oDateDebut.getTime())
	// avec la date r�ellement utilis�e
	var oDateDebutCorrigee;
	if (this._vbAfficheTouteslesHeures(oParametres))
	{
		var oDateDebut0 = new Date(oParametres.m_oDateDebut);
		oDateDebut0.setUTCHours(0, 0, 0, 0);
		oDateDebutCorrigee = new Date(oDateDebut0.getTime() + oParametres.m_nHeureAfficheMinOriginal);
	}
	else
	{
		oDateDebutCorrigee = oParametres.m_oDateDebut;
	}

	// GP 25/02/2016 : TB92261 : Modifie m_nDefilementPrincipal selon la variation de pas des graduations
	if ((undefined !== nDimensionPxGraduationSiResize) && (undefined !== this.m_nDefilementPrincipal))
	{
		var nDimensionPxGraduation = this.vnGetDimensionPxGraduation(oParametres);
		if (nDimensionPxGraduationSiResize != nDimensionPxGraduation)
		{
			this.m_nDefilementPrincipal *= nDimensionPxGraduation / nDimensionPxGraduationSiResize;
		}
	}

	// Si on recoit une position du serveur
	if (oParametres.m_oDateDateHeure1erLigneVisible)
	{
		// GP 30/05/2014 : QW245414 : Il faut �tre plus pr�cis en fait bDebutDebut est plustot sur l'inclus de l'offset du jour courant
		var oDateDateHeure1erLigneVisible = oParametres.m_oDateDateHeure1erLigneVisible;
		var bDebutDebut = true;
		if ((oDateDateHeure1erLigneVisible.getUTCHours() <= oParametres.m_oDateDebut.getUTCHours())
			&& (oDateDateHeure1erLigneVisible.getUTCMinutes() <= oParametres.m_oDateDebut.getUTCMinutes())
			&& (oDateDateHeure1erLigneVisible.getUTCSeconds() <= oParametres.m_oDateDebut.getUTCSeconds())
			&& (oDateDateHeure1erLigneVisible.getUTCMilliseconds() <= oParametres.m_oDateDebut.getUTCMilliseconds()))
		{
			bDebutDebut = false;
		}

		// On filtre les dates avant le debut (debut inclus) pour que si on est au debut, on n'ignore pas la rupture de date
		if (oDateDateHeure1erLigneVisible.getTime() > oParametres.m_oDateDebut.getTime())
		{
			// GP 23/05/2014 : QW245414 : On compare � la date du d�but. Donc il faut l'indiquer. Pr�sence de la zone � la journ�e enti�re exacerbe le probl�me
			nPositionDefilement = this.__nGetDimensionPxDepuisDifferenceDate(oParametres, oDateDateHeure1erLigneVisible.getTime(), oParametres.m_oDateDebut.getTime(), bDebutDebut);
		}
		else
		{
			nPositionDefilement = 0
		}
		this.m_oDefilementPrincipalDate = oParametres.m_oDateDebut;
	}
	// Si on a une position existante pour la meme zone
	else if ((undefined !== this.m_nDefilementPrincipal) && (this.m_oDefilementPrincipalDate.getTime() == oDateDebutCorrigee.getTime()))
	{
		// Si on a une position existante pour la meme zone
		nPositionDefilement = this.m_nDefilementPrincipal;
	}
	else if (this._vbAfficheTouteslesHeures(oParametres))
	{
		nPositionDefilement = this.__nGetDimensionPxDepuisDifferenceDate(oParametres, oParametres.m_nHeureAfficheMinOriginal, oParametres.m_nHeureAfficheMin, false);
		// GP 25/02/2016 : TB92261 : Ne fait rien sur le premier affichage avec IE si le champ est ancr� en hauteur : le code des ancrages va faire ce qu'il faut et on recevra un onresize
		if (bIEAvec11 && (nPositionDefilement < 0) && clWDUtil.bAvecClasse(oHote, "h100"))
		{
			return;
		}
		this.m_oDefilementPrincipalDate = oDateDebutCorrigee;
	}
	else
	{
		// Si possible se place sur aujourdhui
		nPositionDefilement = (-1 != this.m_nPositionAujourdhui) ? this.m_nPositionAujourdhui : 0;
		this.m_oDefilementPrincipalDate = oDateDebutCorrigee;
	}
	if (!bFusion || (nPositionDefilement != this.m_nDefilementPrincipal))
	{
		this._vSetDefilementPrincipal(nPositionDefilement);
	}
	// Reforce la position (si on va trop loin)
	(this.m_nDefilementPrincipal = this._vnGetDefilementPrincipal());

	// Si on a une indication de defilement et que la ressource n'est pas encore visible
	if (oParametres.m_n1erRessourceVisible && !this.__bConteneurVisible(oParametres))
	{
		this._vSetDefilementLateral(oParametres.m_n1erRessourceVisible * this._nGetDimensionLateralePxConteneur(oParametres));
	}
	// Si on a une position existante pour la meme zone
	else if ((this.m_nDefilementLateral !== undefined) && (this.m_nDefilementLateralNbConteneurs == this.m_oChampAP._nGetNbConteneurs(false)))
	{
		if (!bFusion)
		{
			this._vSetDefilementLateral(this.m_nDefilementLateral);
		}
	}
	else
	{
		// Si possible se place en haut
		this._vSetDefilementLateral(0);
		this.m_nDefilementLateralNbConteneurs = this.m_oChampAP._nGetNbConteneurs(false);
	}
	// Reforce la position (si on va trop loin)
	(this.m_nDefilementLateral = this._vnGetDefilementLateral());
};
WDVueAPBase.prototype.__bConteneurVisible = function __bConteneurVisible(oParametres)
{
	var nDimensionLateralePxConteneur = this._nGetDimensionLateralePxConteneur(oParametres);
	var nDebutConteneur = oParametres.m_n1erRessourceVisible * nDimensionLateralePxConteneur;
	var nDefilementLateral = this.m_nDefilementLateral ? this.m_nDefilementLateral : 0;
	return ((nDefilementLateral <= nDebutConteneur) && ((nDefilementLateral + this._vnGetDimensionClienteLaterale()) >= (nDebutConteneur + nDimensionLateralePxConteneur)));
};

// Construit le debut du HTML des zone de couleur
WDVueAPBase.prototype.__tabHTMLAfficheCorpsHeureDebut = function __tabHTMLAfficheCorpsHeureDebut(sClasse)
{
	// On construit en parallele les DIVs pour la couleur de fond et pour la couleur
	var tabHTML = [];

	tabHTML.push("<div class=\"");
	tabHTML.push(sClasse);
	tabHTML.push("\">");

	return tabHTML;
};

// Construit la zone de titres horizontal
WDVueAPBase.prototype.__HTMLAfficheTitresHorizontal = function __HTMLAfficheTitresHorizontal(oParametres)
{
	// Genere la table
	var tabHTML = [];
	tabHTML.push("<table class=\"");
	tabHTML.push(this.ms_sNomTitresHorizontal);
	tabHTML.push("\">");
	this._vHTMLAfficheTitresHorizontal(tabHTML, oParametres);
	tabHTML.push("</table>");
	(this.m_oHoteTitresHorizontal.innerHTML = tabHTML.join(""));
};

// Construit la zone de titres vertical
WDVueAPBase.prototype.__HTMLAfficheTitresVertical = function __HTMLAfficheTitresVertical(oParametres)
{
	if (this.m_oHoteTitresVertical)
	{
		// Genere la table
		var tabHTML = [];
		tabHTML.push("<table class=\"");
		tabHTML.push(this.ms_sNomTitresVertical);
		tabHTML.push("\">");
		this._vHTMLAfficheTitresVertical(tabHTML, oParametres);
		tabHTML.push("</table>");
		this.m_oHoteTitresVertical.innerHTML = tabHTML.join("");
	}
};


// Construit les rendez-vous
WDVueAPBase.prototype.__HTMLAfficheRendezVous = function __HTMLAfficheRendezVous(oParametreFusion, oParametres, tabRendezVous)
{
	// Le tableau des rendez-vous est trie (calcul sur le serveur)
	// On precalcule la superposition des rendez-vous
	// On recoit un tableau des rendez-vous par conteneur
	var tabConteneurRendezVous = this.__tabGetConteneurRendezVous(tabRendezVous);

	// Affiche les rendez vous par ressources
	var i;
	var nLimiteI = this.m_oChampAP._nGetNbConteneurs(false);
	for (i = 0; i < nLimiteI; i++)
	{
		// Affiche si on est en affichage ou si la ressource contient des rendezvous modifie en Fusion
		if (!oParametreFusion || oParametreFusion[i])
		{
			this.__HTMLAfficheRendezVousConteneur(oParametres, tabConteneurRendezVous, i, !!oParametreFusion);
		}
	}
};

// Le tableau des rendez-vous est trie (calcul sur le serveur)
// On precalcule la superposition des rendez-vous
// On recoit un tableau des rendez-vous par conteneur
WDVueAPBase.prototype.__tabGetConteneurRendezVous = function __tabGetConteneurRendezVous(tabRendezVous)
{
	var tabConteneurRendezVous = [];

	// Creation des tableaux internes
	var i;
	var nLimiteI = this.m_oChampAP._nGetNbConteneurs(false);
	for (i = 0; i < nLimiteI; i++)
	{
		tabConteneurRendezVous.push([]);
	}

	// Et remplissage avec les rendez-vous
	// Normalement tous les indices sont valides (le serveur ne retourne que les rendezvous associees a une ressource)
	// Et comme les rendez-vous sont deja trie, ils seront aussi tri une fois dans les ressources
	nLimiteI = tabRendezVous.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oRendezVous = tabRendezVous[i];
		tabConteneurRendezVous[this.m_oChampAP.nGetRendezVousConteneur(oRendezVous)].push(oRendezVous);
	}

	return tabConteneurRendezVous;
};

// Affiche les rendez vous d'une ressource
WDVueAPBase.prototype.__HTMLAfficheRendezVousConteneur = function __HTMLAfficheRendezVousConteneur(oParametres, tabConteneurRendezVous, nConteneur, bFusion)
{
	// Trouve le conteneur de la ressource
	var oConteneurDiv = this.oGetConteneurDiv(oParametres, nConteneur, false);
	var oConteneurDivTitreSeul = this.oGetConteneurDiv(oParametres, nConteneur, true);
	// Recupere le tableau des rendez-vous pour la ressource
	var tabRendezVous = tabConteneurRendezVous[nConteneur];
	// OPTIM : Ne fait aucune calcul si on n'a pas de rendez-vous dans le conteneur
	if (tabRendezVous.length)
	{
		var bPremierConteneur = (0 == nConteneur);

		// Alloue a chaque rendez-vous une position (avec eventuellement sa superposition)
		// Chaque element du tableau est un objet avec "m_nSuperposition" et "m_nNbSuperpositions"
		var tabRendezVousSuperpositionInfo = this.__tabGetRendezVousSuperpositionInfo(oParametres, tabRendezVous);

		var i;
		var nLimiteI = tabRendezVous.length;
		for (i = 0; i < nLimiteI; i++)
		{
			// Affiche le rendez-vous
			this.__HTMLAfficheUnRendezVous(oParametres, tabRendezVous[i], tabRendezVousSuperpositionInfo[i], oConteneurDiv, oConteneurDivTitreSeul, bPremierConteneur, bFusion);
		}
	}
};

// Alloue a chaque rendez-vous une position (avec eventuellement sa superposition)
WDVueAPBase.prototype.__tabGetRendezVousSuperpositionInfo = function __tabGetRendezVousSuperpositionInfo(oParametres, tabRendezVous)
{
	// On s�pare le traitement des rendezvous TitreSeul (rendez-vous � la journ�e ou rendez-vous dans l'agenda au mois) des autres rendez-vous.

	// Pr�calculs
	// - Globaux : le tableau avec le resultat
	var nNbRendezVous = tabRendezVous.length;
	var tabRendezVousSuperpositionInfo = new Array(nNbRendezVous);
	// - tabSuperpositions : Le tableaux de l'etat des superpositions
	// - nDebutZone : Pour la detection du nombre de superpositions : le nombre de superpositions ne change pas tant qu'il y a un rendez-vous d'affiche pour une meme heure.
	// Donc on detecte le debut d'une zone ou tous est vide.
	var oSuperpositionsNormal = { m_tabSuperpositions: [], m_nDebutZone: 0 };
	var oSuperpositionsTitreSeul = { m_tabSuperpositions: [], m_nDebutZone: 0 };

	// Alloue a chaque rendez-vous une position
	var nRendezVous;
	var oSuperpositionInfo;
	var nDebutZone;
	for (nRendezVous = 0; nRendezVous < nNbRendezVous; nRendezVous++)
	{
		var oRendezVous = tabRendezVous[nRendezVous];

		oSuperpositionInfo = { m_bTitreSeul: this._bRendezVousTitreSeul(oParametres, oRendezVous), m_nSuperposition: 0, m_nNbSuperpositions: 1 };
		tabRendezVousSuperpositionInfo[nRendezVous] = oSuperpositionInfo;

		var oSuperpositions = oSuperpositionInfo.m_bTitreSeul ? oSuperpositionsTitreSeul : oSuperpositionsNormal;
		var tabSuperpositions = oSuperpositions.m_tabSuperpositions;

		// Si on n'a aucun aucun rendez-vous (cas apres l'init, on ne passe pas dans la boucle mais la valeur est deja bonne)
		var nPremiereSuperpositionLibre = tabSuperpositions.length;
		var nNbSuperpositionsLibres = 0;

		// Met a jour le contenu des superpositions (et supprime les superpositions inutiles)
		var nSuperpositionDepuisFin;
		for (nSuperpositionDepuisFin = tabSuperpositions.length - 1; nSuperpositionDepuisFin >= 0; nSuperpositionDepuisFin--)
		{
			// Si le rendez-vous existe et est fini
			if (tabSuperpositions[nSuperpositionDepuisFin] && (tabSuperpositions[nSuperpositionDepuisFin].m_oDateFin <= oRendezVous.m_oDateDebut))
			{
				// La superposition n'est plus utilise
				tabSuperpositions[nSuperpositionDepuisFin] = null;
			}
			// Si la superposition est vide
			if (!tabSuperpositions[nSuperpositionDepuisFin])
			{
				// => MAJ de nPremiereSuperpositionLibre (comme on fait un parcours a l'envers la valeur sera bonne a la fin de la boucle)
				nPremiereSuperpositionLibre = nSuperpositionDepuisFin;
				nNbSuperpositionsLibres++;
			}
		}

		// Note la superposition
		oSuperpositionInfo.m_nSuperposition = nPremiereSuperpositionLibre;

		// Si toutes les positions sont vides
		if (tabSuperpositions.length == nNbSuperpositionsLibres)
		{
			// Note le nombre de superpositions dans tous les rendez-vous depuis le dernier RAZ
			// (incremente nDebutZone au passage)
			nDebutZone = oSuperpositions.m_nDebutZone;
			for (; nDebutZone < nRendezVous; nDebutZone++)
			{
				if (tabRendezVousSuperpositionInfo[nDebutZone].m_bTitreSeul == oSuperpositionInfo.m_bTitreSeul)
				{
					tabRendezVousSuperpositionInfo[nDebutZone].m_nNbSuperpositions = tabSuperpositions.length;
				}
			}
			oSuperpositions.m_nDebutZone = nDebutZone;
			// Puis repart a zero
			tabSuperpositions.length = 0;
		}

		// Place le rendez-vous dans la premiere position de libre
		if (nPremiereSuperpositionLibre == tabSuperpositions.length)
		{
			tabSuperpositions.push(oRendezVous);
		}
		else
		{
			tabSuperpositions[nPremiereSuperpositionLibre] = oRendezVous;
		}
	}

	// Note le nombre de superpositions dans tous les rendez-vous depuis le dernier RAZ
	nDebutZone = oSuperpositionsTitreSeul.m_nDebutZone;
	var nNbSuperpositions = oSuperpositionsTitreSeul.m_tabSuperpositions.length;
	for (; nDebutZone < nRendezVous; nDebutZone++)
	{
		oSuperpositionInfo = tabRendezVousSuperpositionInfo[nDebutZone];
		if (oSuperpositionInfo.m_bTitreSeul)
		{
			oSuperpositionInfo.m_nNbSuperpositions = nNbSuperpositions;
		}
	}
	// GP 31/05/2013 : QW232471 : Ici il faut bien manipuler oSuperpositionsNormal et pas oSuperpositions
	// Car oSuperpositions pointe sur le dernier (entre oSuperpositionsTitreSeul et oSuperpositionsNormal) de manipuler
	// donc le calcul fonctionne si le dernier rendez est un normal et ne fonctionne pas si le dernier est un titreseul
	nDebutZone = oSuperpositionsNormal.m_nDebutZone;
	nNbSuperpositions = oSuperpositionsNormal.m_tabSuperpositions.length;
	for (; nDebutZone < nRendezVous; nDebutZone++)
	{
		oSuperpositionInfo = tabRendezVousSuperpositionInfo[nDebutZone];
		if (!oSuperpositionInfo.m_bTitreSeul)
		{
			oSuperpositionInfo.m_nNbSuperpositions = nNbSuperpositions;
		}
	}

	return tabRendezVousSuperpositionInfo;
};

// Affiche un rendez-vous
WDVueAPBase.prototype.__HTMLAfficheUnRendezVous = function __HTMLAfficheUnRendezVous(oParametres, oRendezVous, oSuperpositionInfo, oConteneurDiv, oConteneurDivTitreSeul, bPremierConteneur, bFusion)
{
	// Si on est en fusion : supprime le precedente rendezvous
	if (bFusion)
	{
		if (oRendezVous.m_oRendezVousPrecedent)
		{
			this.__HTMLVideUnRendezVous(oRendezVous.m_oRendezVousPrecedent);
			oRendezVous.m_oRendezVousPrecedent = null;
			delete oRendezVous.m_oRendezVousPrecedent;
		}
		else
		{
			this.__HTMLVideUnRendezVous(oRendezVous);
		}
	}

	var nDateDebutAff = oParametres.m_oDateDebut.getTime();
	var nDateFinAff = oParametres.m_oDateFin.getTime();

	// Duree en ms depuis le debut de l'affichage et le debut du rendez-vous
	// => gere le cas du rendez-vous qui commence avant le debut de l'affichage
	var nDateDebut = Math.max(oRendezVous.m_oDateDebut.getTime(), nDateDebutAff);
	// => gere le cas d'un rendez-vous qui commence dans la zone non affichee
	nDateDebut = this.__nCorrigeDateHeure(oParametres, nDateDebut, true);

	// Duree en ms entre le debut et la fin du rendez-vous
	// => gere le cas du rendez-vous qui fini apres la fin de l'affichage
	var nDateFin = Math.min(oRendezVous.m_oDateFin.getTime(), nDateFinAff);
	// => gere le cas d'un rendez-vous qui fini dans la zone non affichee
	nDateFin = this.__nCorrigeDateHeure(oParametres, nDateFin, false);

	// Si le rendez-vous n'est pas visible on ne l'affiche pas
	// WinDev ne fait pas forcement pareil
	if (nDateFin <= nDateDebut)
	{
		// GP 21/11/2012 : QW223412 : Si le rendez-vous n'est pas visible il n'a pas de div
		return;
	}

	// Creation du div
	var oDiv = document.createElement("div");
	oDiv.style.position = "absolute";
	oDiv.style.zIndex = this.ms_nZIndexRendezVous;
	oDiv.id = this.__sGetNomElement(this.__sGetSuffixeIDElement(this.ms_sNomRendezVous, oRendezVous.m_sID));
	oDiv.className = this.__sGetClassesDivExterneRendezVous(oParametres, oRendezVous, false);
	// Ajoute dans la ressource
	oDiv = (oSuperpositionInfo.m_bTitreSeul ? oConteneurDivTitreSeul : oConteneurDiv).appendChild(oDiv);


	// Selon le mode d'affichage du rendez-vous
	// Avec le mode "TitreSeul" en cache
	var nDimensionLateralePx;
	var sHTMLRendezVous;
	if (oSuperpositionInfo.m_bTitreSeul)
	{
		nDimensionLateralePx = this.__nHTMLAfficheUnRendezVousTitreSeulSuperposition(oParametres, oDiv, nDateDebut, nDateFin, nDateDebutAff);
		// La hauteur est fixe (hauteur du titre)
		var nHauteur = this._nGetHauteurRendezVousTitreSeul(oParametres);

		oDiv.style.top = this._vnGetDebutRendezVousTitreSeul(oParametres, oSuperpositionInfo, nDateDebut, nDateDebutAff) + "px";
		oDiv.style.height = this._nGetHauteurRendezVousTitreSeul(oParametres) + "px";

		// Appel direct de _sGetHTMLRendezVous car on a la largeur et la hauteur
		sHTMLRendezVous = this._sGetHTMLRendezVous(oParametres, oRendezVous, nDimensionLateralePx, nHauteur);
	}
	else
	{
		// Position laterale selon la superposition
		nDimensionLateralePx = this.nHTMLAfficheUnRendezVousSuperposition(oParametres, oDiv, oSuperpositionInfo, bPremierConteneur);
		var nLongueur = this.__nGetDimensionPxDepuisDifferenceDate(oParametres, nDateFin, nDateDebut, false);

		// GP 02/12/2014 : QW252748 : Si on est avec IE en HTML5, les tables du rendez-vous sont mal dessin� si le positionnement n'est pas sur un pixel entier
		var nDebut = this._vnGetDebutRendezVous(oParametres, oRendezVous, nDateDebut, nDateDebutAff);
		if (bIE11Plus)
		{
			nDebut = Math.round(nDebut);
		}

		this.vSetDebut(oDiv, nDebut);
		this.vSetLongueur(oDiv, nLongueur);

		sHTMLRendezVous = this._vsGetHTMLRendezVous(oParametres, oRendezVous, nLongueur, nDimensionLateralePx);
	}
	// + son contenu
	oDiv.innerHTML = sHTMLRendezVous;
	// + les evenements sur le contenu
	this.__SetRendezVousEvenements(oRendezVous, oDiv);

	// Memorise le DIV dans le rendez-vous
	oRendezVous.m_oDiv = oDiv;
};

// Calcule les classes du div externe du rendez-vous
WDVueAPBase.prototype.__sGetClassesDivExterneRendezVous = function __sGetClassesDivExterneRendezVous(oParametres, oRendezVous, bSelectionne)
{
	var tabClasses = [this.ms_sNomRendezVousExterne, bSelectionne ? this.ms_sNomRendezVousSelect : this.ms_sNomRendezVous];
	if (this.bUnRendezVousRedimensionnable(oParametres, oRendezVous))
	{
		if (!oRendezVous.m_bSansRedimDebut)
		{
			tabClasses.push(this.ms_sNomRendezVousRedimDebut);
		}
		if (!oRendezVous.m_bSansRedimFin)
		{
			tabClasses.push(this.ms_sNomRendezVousRedimFin);
		}
	}
	this.__bPushStyleClasses(bSelectionne ? oParametres.m_oStyleRendezVousSelect : oParametres.m_oStyleRendezVous, tabClasses);

	return tabClasses.join(" ");
};

// Positionne un rendez-vous en hauteur (ressources en ligne) ou en largeur (ressources en colonne)
// Retourne la dimension laterale (= perpendiculaire ayu passage du temps) du rendez-vous
WDVueAPBase.prototype.nHTMLAfficheUnRendezVousSuperposition = function nHTMLAfficheUnRendezVousSuperposition(oParametres, oDiv, oSuperpositionInfo, bPremierConteneur)
{
	var oDimensionLaterale =
	{
		m_oDebut: "",
		m_oLongueur: ""
	};
	var nReductionLateraleZoneTitreSeulIndependante = this._vnGetReductionLateraleRendezVousPourZoneTitreSeulIndependante(oParametres);
	var nDimensionLaterale = this.__nDimensionLateralRendezVous(oParametres, oDimensionLaterale, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur);

	// Fixe les dimension
	this.vSetDebutLateral(oDiv, oDimensionLaterale.m_oDebut);
	this.vSetLongueurLateral(oDiv, oDimensionLaterale.m_oLongueur);

	return nDimensionLaterale
};
WDVueAPBase.prototype.__nHTMLAfficheUnRendezVousTitreSeulSuperposition = function __nHTMLAfficheUnRendezVousTitreSeulSuperposition(oParametres, oDiv, nDateDebut, nDateFin, nDateReference)
{
	var oDimensionLaterale =
	{
		m_oDebut: "",
		m_oLongueur: ""
	};
	var nLargeur = this._vnDimensionHorizontalRendezVousTitreSeul(oParametres, oDimensionLaterale, nDateDebut, nDateFin, nDateReference);

	// Fixe les dimension
	WDChamp.prototype.s_SetStyleLeft(oDiv, oDimensionLaterale.m_oDebut);
	WDChamp.prototype.s_SetStyleWidth(oDiv, oDimensionLaterale.m_oLongueur);

	return nLargeur
};

WDVueAPBase.prototype.__nDimensionLateralRendezVous = function __nDimensionLateralRendezVous(oParametres, oDimensionLaterale, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur)
{
	// Selon le mode de superposition
	switch (oParametres.m_eModeSuperposition)
	{
	case this.ms_eSuperpositionDecalage:
		return this.__nDimensionLateralRendezVousSuperpositionDecalage(oParametres, oDimensionLaterale, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur);
		break;
	case this.ms_eSuperpositionCoteACote:
	default:
		return this.__nDimensionLateralRendezVousSuperpositionCoteACote(oParametres, oDimensionLaterale, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur);
		break;
	}
};

// Calcule la position lat�rale d'un rendez-vous avec un affichage "cote a cote"
// Retourne la dimension laterale (= perpendiculaire ayu passage du temps) du rendez-vous
WDVueAPBase.prototype.__nDimensionLateralRendezVousSuperpositionCoteACote = function __nDimensionLateralRendezVousSuperpositionCoteACote(oParametres, oDimensionLaterale, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur)
{
	var nNbSuperpositions = oSuperpositionInfo.m_nNbSuperpositions;
	var nSuperposition = oSuperpositionInfo.m_nSuperposition;

	// Il faut prendre la dimension totale car le conteneur des ressources n'a pas de bordure
	var nDimensionConteneur = this.__nGetDimensionPxSansBordureConteneurAvecSuperposition(oParametres, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur);

	// La colonne ne gere pas l'espace a gauche/haut et a droite/bas
	var nDimensionLaterale = nDimensionConteneur / nNbSuperpositions;

	// Position en colonne
	if (bIEQuirks9Max)
	{
		// La colonne gere deja l'espace a gauche/haut et a droite/bas via un padding
		var nDimensionLateralePourcentage = 100 / nNbSuperpositions;
		oDimensionLaterale.m_oDebut = (nSuperposition * nDimensionLateralePourcentage) + "%";
		oDimensionLaterale.m_oLongueur = nDimensionLateralePourcentage + "%";
	}
	else
	{
		// + this.ms_nPaddingLateralDebut : Padding haut/gauche
		oDimensionLaterale.m_oDebut = (this.ms_nPaddingLateralDebut + nSuperposition * nDimensionLaterale);
		// + this.ms_nPaddingLateralFin : Padding bas/droit
		oDimensionLaterale.m_oLongueur = (this.ms_nPaddingLateralFin + (nNbSuperpositions - nSuperposition - 1) * nDimensionLaterale);
	}
	return nDimensionLaterale;
};

// Calcule la position lat�rale d'un rendez-vous avec un affichage "decalage"
// Retourne la dimension laterale (= perpendiculaire ayu passage du temps) du rendez-vous
WDVueAPBase.prototype.__nDimensionLateralRendezVousSuperpositionDecalage = function __nDimensionLateralRendezVousSuperpositionDecalage(oParametres, oDimensionLaterale, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur)
{
	// Si il n'y a qu'un rendez-vous (pas de superposition) : retrouve le calcul "cote a cote"
	var nNbSuperpositions = oSuperpositionInfo.m_nNbSuperpositions;
	if (1 == nNbSuperpositions)
	{
		return this.__nDimensionLateralRendezVousSuperpositionCoteACote(oParametres, oDimensionLaterale, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur);
	}

	var nSuperposition = oSuperpositionInfo.m_nSuperposition;

	var nDimensionConteneur = this.__nGetDimensionPxSansBordureConteneurAvecSuperposition(oParametres, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur);
	// On reserve 30% pour les decalages
	var nPourcentageDecalage = 30;
	var nDimensionZoneVide = Math.floor(nDimensionConteneur * nPourcentageDecalage / 100);
	var nDimensionZoneVideColonne = nDimensionZoneVide / (nNbSuperpositions - 1);

	// Position en colonne
	if (bIEQuirks9Max)
	{
		oDimensionLaterale.m_oDebut = (nSuperposition * nDimensionZoneVideColonne);
		oDimensionLaterale.m_oLongueur = (nDimensionConteneur - nDimensionZoneVide + this.ms_nPaddingLateralDebut + this.ms_nPaddingLateralFin);
	}
	else
	{
		// + this.ms_nPaddingLateralDebut : Padding haut/gauche
		oDimensionLaterale.m_oDebut = (this.ms_nPaddingLateralDebut + nSuperposition * nDimensionZoneVideColonne);
		// + this.ms_nPaddingLateralFin : Padding bas/droit
		oDimensionLaterale.m_oLongueur = (this.ms_nPaddingLateralFin + (nNbSuperpositions - nSuperposition - 1) * nDimensionZoneVideColonne);
	}
	return Math.floor(nDimensionConteneur - nDimensionZoneVide);
};

// Dimension d'un conteneur en tenant compte du conteneur des TitreSeul independant
WDVueAPBase.prototype.__nGetDimensionPxSansBordureConteneurAvecSuperposition = function __nGetDimensionPxSansBordureConteneurAvecSuperposition(oParametres, oSuperpositionInfo, nReductionLateraleZoneTitreSeulIndependante, bPremierConteneur)
{
	// Il faut prendre la dimension totale car le conteneur des ressources n'a pas de bordure
	var nDimensionConteneur = this.__nGetDimensionPxSansBordureConteneur(oParametres, bPremierConteneur) - nReductionLateraleZoneTitreSeulIndependante;
	// GP 13/03/2013 : QW230845 : Un '-' en trop ici
	nDimensionConteneur -= this.ms_nPaddingLateralDebut + this.ms_nPaddingLateralFin;
	return Math.max(0, nDimensionConteneur);
};

// Recupere le contenu HTML d'un rendez-vous
// Cette fonction concerne le HTML interne du rendez-vous et est donc independant du sens d'affichage
WDVueAPBase.prototype._sGetHTMLRendezVous = function _sGetHTMLRendezVous(oParametres, oRendezVous, nLargeur, nHauteur)
{
	var oStyleRendezVous = oParametres.m_oStyleRendezVous;
	var oStyleTitre = oParametres.m_oStyleLibTitre;
	var oStyleContenu = oParametres.m_oStyleLibContenu;
	var bTitreSeul = this._bRendezVousTitreSeulSaufSiSansTitre(oParametres, oRendezVous);

	// GP 08/11/2017 : Semble faux en 23
//	var nEpaisseur = this.__nGetRendezVousEpaisseurBordure(oStyleRendezVous);
	var nEpaisseur = oStyleRendezVous.m_nBordureV || 0;
	// Dessin compatible WX22-
	var bEpaisseurSiMargesFixe = (0 < nEpaisseur) && oParametres.m_bMargeFixes;
	// GP 11/07/2017 : Ne force plus des valeurs enti�res puisque l'on n'utilise plus des tables
//	// GP 20/02/2013 : Force des largeur enti�res pour ne pas avoir de probl�mes avec Chrome qui ne g�re pas les tables avec des valeurs non enti�res
//	nLargeur = Math.floor(nLargeur);
//	nHauteur = Math.floor(nHauteur);
	// GP 20/02/2013 : TB81102 : Force une dimension minimale de 0 (IE ignore les valeurs n�gatives)
	var nLargeurSansPaddingRendezVousPx = Math.max(0, nLargeur - this.ms_nPaddingRendezVous * 2);

	var tabHTML = [];
	// Creation de la table exterieure
	tabHTML.push("<ul style=\"width:");
	// Tient compte de l'�paisseur : la bordure est sur le parent du ul
	tabHTML.push(nLargeur - nEpaisseur * 2);
	tabHTML.push("px;height:");
	tabHTML.push(nHauteur - nEpaisseur * 2);
	tabHTML.push("px");
	if (oRendezVous.m_cBord)
	{
		tabHTML.push(";border-color:");
		tabHTML.push(oRendezVous.m_cBord);
	}
	if (oRendezVous.m_sBulle)
	{
		tabHTML.push("\" title=\"");
		tabHTML.push(oRendezVous.m_sBulle);
	}
	tabHTML.push("\">");
	// GP 10/11/2014 : QW251411 : Pour le cas PHP traite m_bAfficherTitreRendezVous absent comme un true
	if (false !== oParametres.m_bAfficherTitreRendezVous)
	{
		tabHTML.push("<li");
		// Trouve la couleur de fond du titre
		var tabFondTitre = this.__tabGetFondTitre(oRendezVous, oStyleTitre, false);
		if (tabFondTitre || bEpaisseurSiMargesFixe)
		{
			tabHTML.push(" style=\"");
			// Dessin compatible WX22-
			if (bEpaisseurSiMargesFixe)
			{
				tabHTML.push("padding-top:");
				tabHTML.push(nEpaisseur);
				tabHTML.push("px");
				if (bTitreSeul)
				{
					tabHTML.push(";padding-bottom:");
					tabHTML.push(nEpaisseur);
					tabHTML.push("px");
				}
			}
			if (tabFondTitre)
			{
				// box-shadow fonctionne sans pr�fixe depuis 2012
				// box-shadow ne fonctionne pas que dans IE8-
				if (!bIE || (8 < nIE))
				{
					tabHTML.push(";box-shadow:0px 20px 10px -10px ");
					tabHTML.push(tabFondTitre[1]);
					tabHTML.push(" inset");
				}
				tabHTML.push(";background-color:");
				tabHTML.push(tabFondTitre[0]);
			}
			// GP 08/11/2017 : QW289690 : Pour avoir le m�me r�sultat que en 22
			if (bTitreSeul)
			{
				tabHTML.push(";height:100%");
			}
			tabHTML.push("\"");
		}
		tabHTML.push(" class=\"");
		tabHTML.push(this.ms_sNomRendezVousTitre);
		if (bTitreSeul)
		{
			tabHTML.push(" ");
			// Si on affiche des rendez-vous "TitreSeul", on doit placer le raduis en bas du haut aussi
			tabHTML.push(this.ms_sNomRendezVousTitreSeul);
		}
		// GP 27/10/2014 : QW250583 On ne peux pas : On perd alors l'alignement sur les �l�ments
//		// GP 17/10/2014 : Pour APL et les images de fond etc : le style g�n�ral est plac sur le table
		if (oStyleTitre.m_sClasses)
		{
			// GP 09/11/2017 : QW292788 : Mettre la classe "padding" (Pour avoir la version avec padding de la classe HTML d�finie en �dition).
			tabHTML.push(" padding ");
			tabHTML.push(oStyleTitre.m_sClasses);
		}
		tabHTML.push("\"><div style=\"width:");
		tabHTML.push(nLargeurSansPaddingRendezVousPx);
		tabHTML.push("px\">");
		if (oRendezVous.m_sTitre)
		{
			tabHTML.push(clWDUtil.sEncodeInnerHTML(oRendezVous.m_sTitre, true, false));
		}
		else
		{
			tabHTML.push("&nbsp;");
		}
		tabHTML.push("</div>");
		tabHTML.push("</li>");
	}
	// On n'affiche le corps uniquement si on en demande l'affichage
	if (!bTitreSeul)
	{
		var tabClasses = [];
		tabHTML.push("<li style=\"height:100%;");

		var cFondContenu = this.__cGetFond(oRendezVous, null, oStyleContenu, false);
		// Comme on ne transmet plus la couleur de fond si c'est la meme que le style, il faut le forcer ici sinon le style par defaut est prioritaire
		// GP 25/11/2014 : QW252308 : Ajout le padding que l'on aurait mis en haut sur le titre
		if (oRendezVous.m_sImage || cFondContenu || ((false === oParametres.m_bAfficherTitreRendezVous) && bEpaisseurSiMargesFixe))
		{
			if (oRendezVous.m_sImage)
			{
				tabHTML.push("background-image:");
				tabHTML.push(clWDUtil.sGetURICSS(clWDUtil.sGetCheminImage(oRendezVous.m_sImage, "")));
				tabHTML.push(";");
			}
			if (cFondContenu)
			{
				tabHTML.push("background-color:");
				tabHTML.push(cFondContenu);
				tabHTML.push(";");
			}
			if ((false === oParametres.m_bAfficherTitreRendezVous) && bEpaisseurSiMargesFixe)
			{
				tabHTML.push("padding-top:");
				tabHTML.push(nEpaisseur);
				tabHTML.push("px");
			}
			if (oRendezVous.m_sImage || cFondContenu)
			{
				tabClasses.push(this.ms_sNomRendezVousImage);
			}
		}
		tabHTML.push("\"");
		// GP 27/10/2014 : QW250583 On ne peux pas : On perd alors l'alignement sur les �l�ments
		// GP 06/11/2017 : QW290440 : En 23, les styles sont s�par�s
		(oRendezVous.m_sContenu && this.__bPushStyleClasses(oStyleContenu, tabClasses));
		if (0 < tabClasses.length)
		{
			tabHTML.push(" class=\"");
			tabHTML.push(tabClasses.join(" "));
			tabHTML.push("\"");
		}
		tabHTML.push(">");
		if (oRendezVous.m_sContenu)
		{
			tabHTML.push("<div style=\"width:");
			tabHTML.push(nLargeurSansPaddingRendezVousPx);
			tabHTML.push("px\">");
			tabHTML.push(clWDUtil.sEncodeInnerHTML(oRendezVous.m_sContenu, true, false));
			tabHTML.push("</div>");
		}
		if (oRendezVous.m_bRepetee)
		{
			tabHTML.push("<img class=\"");
			tabHTML.push(this.ms_sNomRendezVousRepetition);
			tabHTML.push("\" src=\"");
			tabHTML.push(this.ms_sImageRepetition);
			tabHTML.push("\" />");
		}
		tabHTML.push("</li>");
	}
	tabHTML.push("</ul>");
	// GP 14/05/2018 : Vu avec TB97976 : D�place l'image car si le texte est trop grand le ul est trop long et l'image n'est plus visible.
	if (0 < oRendezVous.m_nImportance)
	{
		tabHTML.push("<img class=\"");
		tabHTML.push(this.ms_sNomRendezVousImportance);
		tabHTML.push("\" src=\"");
		tabHTML.push(this.ms_sImageImportance);
		tabHTML.push("\" />");
	}
	return tabHTML.join("");
};

// Trouve la couleur de fond du titre
WDVueAPBase.prototype.__tabGetFondTitre = function __tabGetFondTitre(oRendezVous, oStyle, bSelection)
{
	// Si on a une couleur de fond force
	if (oRendezVous.m_cFondTitre && (!bSelection || !oStyle.m_cFondDegrade))
	{
		// Si on a m_cFondTitre, on a m_cFondContenu
		return [ oRendezVous.m_cFondTitre, oRendezVous.m_cFondContenu ];
	}
	// Prend la couleur de fond du style si elle existe
	if (oStyle.m_cFondDegrade)
	{
		return [oStyle.m_cFondDegrade, oStyle.m_cFond];
	}

	return undefined;
};

// Trouve la couleur de fond du contenu
WDVueAPBase.prototype.__cGetFond = function __cGetFond(oRendezVous, oStyle, oStyleContenu, bSelection)
{
	if (!oRendezVous.m_sContenu)
	{
		// Si le rendez-vous n'a pas de contenu
		if (bSelection && oStyle && oStyle.m_cFond)
		{
			// En selection le style de la selection est prioritaire
			return oStyle.m_cFond;
		}
		else if (oRendezVous.m_cFondContenu)
		{
			// Sinon on prend le style de fond du rendez-vous (mal nomm� en "FondContenu") si disponible
			return oRendezVous.m_cFondContenu;
		}
		else
		{
			// Sinon on ne prend aucun style particulier
			return undefined;
		}
	}
	else
	{
		// Le rendezvous a un contenu
		if (oStyleContenu && oStyleContenu.m_cFond)
		{
			// En le style du contenu est prioritaire (en s�lection ou pas en selection)
			return oStyleContenu.m_cFond;
		}
		else if (bSelection && oStyle && oStyle.m_cFond)
		{
			// En selection le style de la selection est prioritaire
			return oStyle.m_cFond;
		}
		else if (oRendezVous.m_cFondContenu)
		{
			// Sinon on prend le style de fond du rendez-vous (mal nomm� en "FondContenu") si disponible
			return oRendezVous.m_cFondContenu;
		}
		else if (oStyle && oStyle.m_cFond)
		{
			// Le style normal n'est pas prioritaire (en non s�lection donc)
			return oStyle.m_cFond;
		}
		else
		{
			// Sinon on ne prend aucun style particulier
			return undefined;
		}
	}
};

// Fixe les evenements sur un rendez-vous
WDVueAPBase.prototype.__SetRendezVousEvenements = function __SetRendezVousEvenements(oRendezVous, oDiv)
{
	// Intercepte le :
	//						Rendez-vous		Page
	// Debut du drag-drop	mousedown
	// En drag-drop							mousemove
	// Fin du drag-drop						mouseup
	// Selection/Autres		onclick
	// Entree en saisie		ondblclick
	this.m_oChampAP.m_oDragRendezVous.vInitElement(oRendezVous, 0, oDiv);

	var oThis = this;
	var oThisRendezVous = oRendezVous;
	(oRendezVous.m_fOnClick = function(oEvent) { return oThis.m_oChampAP.bOnRendezVousSelection(oEvent || event, oThisRendezVous); });
	(oRendezVous.m_fOnDblClick = function(oEvent) { return oThis.m_oChampAP.bOnRendezVousDoubleClic(oEvent || event, oThisRendezVous); });
	clWDUtil.AttacheDetacheEvent(true, oDiv, "click", oRendezVous.m_fOnClick);
	clWDUtil.AttacheDetacheEvent(true, oDiv, "dblclick", oRendezVous.m_fOnDblClick);
};

// Affiche les elements specifiques au rendez-vous selectionne
WDVueAPBase.prototype.__HTMLAfficheRendezVousSelection = function __HTMLAfficheRendezVousSelection(oEvent, oParametres, bAvecPlacement)
{
	// Si un element est selectionne
	var oRendezVousSelection = this.m_oChampAP.oGetRendezVousSelection();
	if (oRendezVousSelection)
	{
		// Debut de l'affichage du bouton de suppression
		this.__HTMLAfficheRendezVousSuppression(oParametres, bAvecPlacement);

		var oDiv = oRendezVousSelection.m_oDiv;
		// GP 21/11/2012 : QW223412 : Si le rendez-vous n'est pas visible il n'a pas de div
		if (oDiv)
		{
			// Style du rendez-vous
			oDiv.style.zIndex = this.ms_nZIndexRendezVousSelection;
			// Epaisseur des bordures : elle change avec le style : il faut changer les tailles des cellules
			this.__HTMLAfficheRendezVousCellulesBordures(oParametres, oRendezVousSelection, oDiv, true, oParametres.m_oStyleRendezVousSelect, oParametres.m_oStyleLibTitreSelect, oParametres.m_oStyleLibContenuSelect);
		}
	}
};

// Modifie l'epaisseur des cellules bordures d'un rendez-vous
WDVueAPBase.prototype.__HTMLAfficheRendezVousCellulesBordures = function __HTMLAfficheRendezVousCellulesBordures(oParametres, oRendezVous, oDiv, bSelection, oStyleRendezVous, oStyleTitre, oStyleContenu)
{
	var oUL = oDiv.firstChild;

	var nIndiceTitre = 0;
	var nIndiceContenu = 1;
	// GP 10/11/2014 : QW251411 : Pour le cas PHP traite m_bAfficherTitreRendezVous absent comme un true
	if (false === oParametres.m_bAfficherTitreRendezVous)
	{
		nIndiceTitre = undefined;
		nIndiceContenu--;
	}
	if (this._bRendezVousTitreSeulSaufSiSansTitre(oParametres, oRendezVous))
	{
		nIndiceContenu = undefined;
	}

	var tabCellules = oUL.getElementsByTagName("li");
	if (oParametres.m_bMargeFixes)
	{
		// Epaisseur des bordures : elle change avec le style : il faut changer les tailles des cellules
		if (oParametres.m_oStyleRendezVous.m_nBordureV != oParametres.m_oStyleRendezVousSelect.m_nBordureV)
		{
			// Epaisseur des elements sur le bord de la table
			var nEpaisseur = this.__nGetRendezVousEpaisseurBordure(oStyleRendezVous);

			if (undefined !== nIndiceTitre)
			{
				tabCellules[nIndiceTitre].style.paddingTop = nEpaisseur + "px";
			}
		}
	}

	var tabFondTitre = this.__tabGetFondTitre(oRendezVous, oStyleTitre, bSelection);
	//	var cFondContenu = this.__cGetFond(oRendezVous, oStyleRendezVous, oStyleContenu, bSelection);
	var cFondContenu = this.__cGetFond(oRendezVous, null, oStyleContenu, bSelection);
	// Si on est en s�lection et qu'il n'y a aucun style dans le style de s�lection, on prend le style par d�faut
	if (bSelection && (undefined === cFondContenu))
	{
		//		cFondContenu = this.__cGetFond(oRendezVous, oParametres.m_oStyleRendezVous, oParametres.m_oStyleLibContenu, bSelection);
		cFondContenu = this.__cGetFond(oRendezVous, null, oParametres.m_oStyleLibContenu, bSelection);
	}

	// GP : Vu avec QW292511 : Change le style externe
	oDiv.className = this.__sGetClassesDivExterneRendezVous(oParametres, oRendezVous, bSelection);

	var tabClasses = [];

	// Change la classe du texte
	if (undefined !== nIndiceTitre)
	{
		tabClasses.length = 0;
		tabClasses.push(this.ms_sNomRendezVousTitre);
		if (undefined === nIndiceContenu)
		{
			tabClasses.push(this.ms_sNomRendezVousTitreSeul);
		}
		if (oStyleTitre.m_sClasses)
		{
			// GP 09/11/2017 : QW292788 : Mettre la classe "padding" (Pour avoir la version avec padding de la classe HTML d�finie en �dition).
			tabClasses.push(" padding ");
			tabClasses.push(oStyleTitre.m_sClasses);
		}
		tabCellules[nIndiceTitre].className = tabClasses.join(" ");
		if (tabFondTitre)
		{
			// GP 26/07/2017 : Plus besoin de pr�fixe
			if (!bIE || (8 < nIE))
			{
				// Tout navigateurs sauf IE8-
				tabCellules[nIndiceTitre].style.boxShadow = "0px 20px 10px -10px " + tabFondTitre[1] + " inset";
			}
			tabCellules[nIndiceTitre].style.backgroundColor = tabFondTitre[0];
		}
	}
	if (undefined !== nIndiceContenu)
	{
		// Si on a un contenu
		tabClasses.length = 0;
		if (oRendezVous.m_sImage)
		{
			tabClasses.push(this.ms_sNomRendezVousImage);
		}
		// GP 06/11/2017 : QW290440 : En 23, les styles sont s�par�s
		//		((oRendezVous.m_sContenu && this.__bPushStyleClasses(oStyleContenu, tabClasses)) || this.__bPushStyleClasses(oStyleRendezVous, tabClasses));
		(oRendezVous.m_sContenu && this.__bPushStyleClasses(oStyleContenu, tabClasses));
		tabCellules[nIndiceContenu].className = tabClasses.join(" ");

		// Et le bas aussi
		tabClasses.push(this.ms_sNomRendezVousBas);
		tabCellules[nIndiceContenu].className = tabClasses.join(" ");
		// Et la couleur de fond de la cellule
		if (!cFondContenu)
		{
			cFondContenu = "";
		}
		// Cette cellule n'existe que si on affiche le corps
		tabCellules[nIndiceContenu].style.backgroundColor = cFondContenu;
	}
};

// Affiche le rendez vous de selection (apres l'affichage)
WDVueAPBase.prototype.__HTMLAfficheRendezVousSelectionApresAffichage = function __HTMLAfficheRendezVousSelectionApresAffichage(oEvent, oParametres)
{
	// Si un element est selectionne
	var oRendezVousSelection = this.m_oChampAP.oGetRendezVousSelection();
	if (oRendezVousSelection)
	{
		// Entre en saisie
		if (oParametres.m_bEditTitreRDVSelection)
		{
			oParametres.m_bEditTitreRDVSelection = false;
			this.m_oChampAP.__bEditionRendezVous(oEvent, oRendezVousSelection);
		}
	}
};

// Affiche le bouton de suppression
WDVueAPBase.prototype.__HTMLAfficheRendezVousSuppression = function __HTMLAfficheRendezVousSuppression(oParametres, bAvecPlacement)
{
	// Si le bouton existe : le supprime
	this.__HTMLVideRendezVousSuppression();

	// On n'affiche pas le bouton si l'utilisateur n'a pas le droit de supprimer
	// GP 21/11/2016 : QW278487 : S�pare le flag bActif des autres options
	if (oParametres.m_bSupprimeParUtilisateur && oParametres.m_bActif)
	{
		// Et le (re)cree
		var oRendezVousSuppression;
		var oBtnSuppression = oParametres.m_oBtnSuppression;
		var sClasses = this.ms_sNomRendezVousSupprime;

		if (oBtnSuppression)
		{
			// Dessin avec positionnement et style : dessin dans un div
			oRendezVousSuppression = document.createElement("div");
			var sStyleClasses = oBtnSuppression.m_oStyle.m_sClasses;
			// Inutile de tester .length : "" s'�value a faux et "<Contenu>" s'�value � vrai.
			if (sStyleClasses)
			{
				sClasses += " " + sStyleClasses;
			}
			// Pour que la taille fix�e soit la taille effective AVEC bordure.
			oRendezVousSuppression.style.boxSizing = "border-box";
		}
		else
		{
			// Dessin dessin compatible WX22- : dessin d'une balise img
			oRendezVousSuppression = document.createElement("img");
			oRendezVousSuppression.src = this.ms_sImageSupprime;
		}

		oRendezVousSuppression.className = sClasses;

		// Trouve le parent d'ajout : parent du corps pour ne pas etre coupe par l'overflow
		this.m_oRendezVousSuppression = this.m_oHote.appendChild(oRendezVousSuppression);
		// Fait ensuite dans __HTMLPlaceRendezVousSuppressionAutonome
		if (bAvecPlacement)
		{
			this.__HTMLPlaceRendezVousSuppressionAutonome(oParametres);
		}

		// Ajoute l'evenement
		clWDUtil.AttacheDetacheEvent(true, this.m_oRendezVousSuppression, "click", this.m_fOnRendezVousSupprime);
	}
};

// Place le bouton de suppression
WDVueAPBase.prototype.__HTMLPlaceRendezVousSuppressionAutonome = function __HTMLPlaceRendezVousSuppressionAutonome(oParametres)
{
	var oRendezVousSelection = this.m_oChampAP.oGetRendezVousSelection();
	var oRendezVousSuppression = this.m_oRendezVousSuppression;
	// GP 21/11/2012 : QW223412 : Si le rendez-vous n'est pas visible il n'a pas de div
	// => Pas besoin de tester oRendezVousSelection.m_oDiv car c'est test� dans __HTMLPlaceRendezVousSuppression
	if (oRendezVousSelection && oRendezVousSuppression)
	{
		this.__HTMLPlaceRendezVousSuppression(oParametres, oRendezVousSelection, oRendezVousSuppression);
	}
};
WDVueAPBase.prototype.__HTMLPlaceRendezVousSuppression = function __HTMLPlaceRendezVousSuppression(oParametres, oRendezVousSelection, oRendezVousSuppression)
{
	// GP 21/11/2012 : QW223412 : Si le rendez-vous n'est pas visible il n'a pas de div
	var oDiv = oRendezVousSelection.m_oDiv;
	if (!oDiv)
	{
		return;
	}

	// GP 13/12/2012 : QW227770 : Calcul diff�rent
	var oRectHote = this.m_oHote.getBoundingClientRect();
	var oRectDiv = oDiv.getBoundingClientRect();

	// Les valeurs qui d�pendent de la position
	var eAncrage;
	var nLargeurPx, nHauteurPx;
	var nDecalageXPx, nDecalageYPx;

	var oBtnSuppression = oParametres.m_oBtnSuppression;
	if (oBtnSuppression)
	{
		// Dessin avec positionnement et style : dessin dans un div
		// Trouve la description selon la tranche courante
		var tabPosition = oBtnSuppression.m_tabPosition;
		var nTrancheIndiceWL = clWDUtil.bRWD ? $.wb.nGetTrancheActiveIndiceWL(true) : 1;
		var nTrancheIndiceC = Math.min(nTrancheIndiceWL, tabPosition.length) - 1;
		var oPosition = tabPosition[nTrancheIndiceC];
		eAncrage = oPosition.m_eAncrage;
		nLargeurPx = oPosition.m_nLargeurPx;
		nHauteurPx = oPosition.m_nHauteurPx;
		nDecalageXPx = oPosition.m_nDecalageXPx;
		nDecalageYPx = oPosition.m_nDecalageYPx;

		// Force la taille du DIV (qui sinon n'a pas de taille)
		oRendezVousSuppression.style.width = clWDUtil.GetDimensionPxPourStyle(oPosition.m_nLargeurPx);
		oRendezVousSuppression.style.height = clWDUtil.GetDimensionPxPourStyle(oPosition.m_nHauteurPx);
	}
	else
	{
		// Dessin dessin compatible WX22- : positionnement dans le coin en haut a droite
		eAncrage = 2; // ANCRAGE_HAUT_DROITE
		// L'image fait 14x13
		nLargeurPx = 14;
		nHauteurPx = 13;
		// Avant : le coin haut gauche �tait positionn� 8 pixel � gauche et 6 pixel au dessus du coin du rendez-vous
		// => positionnement "arbitraire" de l'image de suppression pour etre sur le coin mais rentrant de un pixel.
		// Avec ANCRAGE_HAUT_DROITE on doit donner la position du coin haut droite
		nDecalageXPx = -6;	// 6 - 14
		nDecalageYPx = -6;
	}

	var nPointAncrageX, nPointAncrageY;
	var nLeft, nTop;
	switch (eAncrage)
	{
	case 0:
		// ANCRAGE_HAUT_GAUCHE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
	case 3:
		// ANCRAGE_CENTRE_GAUCHE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
	case 6:
		// ANCRAGE_BAS_GAUCHE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de bas (valeur n�gatives) en haut (valeur positives)
		nPointAncrageX = oRectDiv.left;
		nLeft = nPointAncrageX + nDecalageXPx;
		break;
	case 1:
		// ANCRAGE_HAUT_CENTRE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
	case 4:
		// ANCRAGE_CENTRE_CENTRE_IGNORE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
		// GP 19/07/2017 : Sans int�ret (masque le contenu du rendez-vous) mais on le garde pour le cas ou l'on doit l'utilis� un jour
	case 7:
		// ANCRAGE_BAS_CENTRE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de bas (valeur n�gatives) en haut (valeur positives)
		nPointAncrageX = (oRectDiv.left + oRectDiv.right) / 2;
		nLeft = nPointAncrageX + nDecalageXPx;
		break;
	default:
	case 2:
		// ANCRAGE_HAUT_DROITE
		// D�calage X : axe de droite (valeur n�gatives) � gauche (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
	case 5:
		// ANCRAGE_CENTRE_DROITE
		// D�calage X : axe de droite (valeur n�gatives) � gauche (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
	case 8:
		// ANCRAGE_BAS_DROITE
		// D�calage X : axe de droite (valeur n�gatives) � gauche (valeur positives). D�calage Y : axe de bas (valeur n�gatives) en haut (valeur positives)
		nPointAncrageX = oRectDiv.right;
		nLeft = nPointAncrageX - nDecalageXPx - nLargeurPx;
		break;
	}
	switch (eAncrage)
	{
	case 0:
		// ANCRAGE_HAUT_GAUCHE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
	case 1:
		// ANCRAGE_HAUT_CENTRE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
	default:
	case 2:
		// ANCRAGE_HAUT_DROITE
		// D�calage X : axe de droite (valeur n�gatives) � gauche (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
		nPointAncrageY = oRectDiv.top;
		nTop = nPointAncrageY + nDecalageYPx;
		break;
	case 3:
		// ANCRAGE_CENTRE_GAUCHE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
	case 4:
		// ANCRAGE_CENTRE_CENTRE_IGNORE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
		// GP 19/07/2017 : Sans int�ret (masque le contenu du rendez-vous) mais on le garde pour le cas ou l'on doit l'utilis� un jour
	case 5:
		// ANCRAGE_CENTRE_DROITE
		// D�calage X : axe de droite (valeur n�gatives) � gauche (valeur positives). D�calage Y : axe de haut (valeur n�gatives) en bas (valeur positives)
		nPointAncrageY = (oRectDiv.top + oRectDiv.bottom) / 2;
		nTop = nPointAncrageY + nDecalageYPx;
		break;
	case 6:
		// ANCRAGE_BAS_GAUCHE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de bas (valeur n�gatives) en haut (valeur positives)
	case 7:
		// ANCRAGE_BAS_CENTRE
		// D�calage X : axe de gauche (valeur n�gatives) � droite (valeur positives). D�calage Y : axe de bas (valeur n�gatives) en haut (valeur positives)
	case 8:
		// ANCRAGE_BAS_DROITE
		// D�calage X : axe de droite (valeur n�gatives) � gauche (valeur positives). D�calage Y : axe de bas (valeur n�gatives) en haut (valeur positives)
		nPointAncrageY = oRectDiv.bottom;
		nTop = nPointAncrageY - nDecalageYPx - nHauteurPx;
		break;
	}

	// En mode quirks, il y a le padding en plus
	// - En mode ressources en ligne, c'est le padding "avant" => this.ms_nPaddingLateralDebut
	// - En mode ressources en colonne, c'est le padding "apres" => this.ms_nPaddingLateralFin
	var nPaddingTop = this._vnGetPaddingTopPourRendezVous();
	var nPaddingRight = this._vnGetPaddingRightPourRendezVous();

	nLeft = nLeft - oRectHote.left - nPaddingRight;
	nTop = nTop - oRectHote.top + nPaddingTop;

	var bVisible = ((0 <= nLeft) && (0 <= nTop));
	if (bVisible)
	{
		oRendezVousSuppression.style.left = nLeft + "px";
		oRendezVousSuppression.style.top = nTop + "px";

		// GP 13/12/2012 : QW227770 : Calcul diff�rent
		// Pour avoir une dimension mesurable
		clWDUtil.SetDisplay(oRendezVousSuppression, true);
		var oRectHoteCorps = this.m_oHoteCorps.getBoundingClientRect();
		// GP 25/03/2013 : QW231375
		// Et avec Chrome on recoit un ClientRect qui est en lecture seule (=> le -= ne modifie pas la valeur interne)
		var nRectHoteCorpsTop = oRectHoteCorps.top;
		// GP 26/03/2013 : QW231462 : Ajout d'un test sur oRendezVousSelection.m_bJourneeEntiere pour avoir la croix qui ne s'affiche pas pour les rendez-vous normaux
		if (this.ms_bZoneTitreSeulIndependanteExterne && oRendezVousSelection.m_bJourneeEntiere)
		{
			nRectHoteCorpsTop -= this._vnGetHauteurZoneTitreSeulIndependante(this.m_oChampAP.m_oParametres);
		}
		// GP 
		bVisible = ((oRectHoteCorps.left <= nPointAncrageX) && (nRectHoteCorpsTop <= nPointAncrageY) && (nPointAncrageX <= oRectHoteCorps.right) && (nPointAncrageY <= oRectHoteCorps.bottom));
	}
	clWDUtil.SetDisplay(oRendezVousSuppression, bVisible);
};

// Supprime le contenu
WDVueAPBase.prototype.__HTMLVideContenu = function __HTMLVideContenu(oParametres, oOldDonnees, bPourRedimensionnement)
{
	// GP 25/03/2015 : Vu avec QW256413 : Ajout de __HTMLVideSaisie pour annuler la saisie
	this.__HTMLVideSaisie(oParametres, bPourRedimensionnement);
	this.__HTMLVideRendezVousSelection(oParametres);
	this.__HTMLVideRendezVous(oOldDonnees);
	this.__HTMLVideCorps();
	this.__HTMLVideTitresVertical();
	this.__HTMLVideTitresHorizontal();
	this.__HTMLVideBoutonsPeriode();
};

// GP 25/03/2015 : Vu avec QW256413 : Ajout de __HTMLVideSaisie pour annuler la saisie
WDVueAPBase.prototype.__HTMLVideSaisie = function __HTMLVideSaisie(oParametres, bPourRedimensionnement)
{
	var oPopupSaisie = this.m_oChampAP.m_oPopupSaisie;
	if (bPourRedimensionnement && oPopupSaisie.bSaisieEnCours())
	{
		// Se replacera en saisie au prochain affichage
		oParametres.m_bEditTitreRDVSelection = true;
	}
	oPopupSaisie.Annule();
};

// Supprime les elements specifiques au rendez-vous selectionne
WDVueAPBase.prototype.__HTMLVideRendezVousSelection = function __HTMLVideRendezVousSelection(oParametres)
{
	// Il faut valider le div aussi car si on est en reception traitement AJAX, m_oRendezVousSelection
	// contient deja le nouveau rendez-vous qui n'est pas encore liee a son DIV
	var oRendezVousSelection = this.m_oChampAP.oGetRendezVousSelection();
	if (oRendezVousSelection && oRendezVousSelection.m_oDiv)
	{
		var oDiv = oRendezVousSelection.m_oDiv;
		// Epaisseur des bordures : elle change avec le style : il faut changer les tailles des cellules
		this.__HTMLAfficheRendezVousCellulesBordures(oParametres, oRendezVousSelection, oDiv, false, oParametres.m_oStyleRendezVous, oParametres.m_oStyleLibTitre, oParametres.m_oStyleLibContenu);
		// Style du rendez-vous
		oDiv.style.zIndex = this.ms_nZIndexRendezVous;
	}

	// Masque le bouton de suppression
	this.__HTMLVideRendezVousSuppression();
};

// Masque le bouton de suppression
WDVueAPBase.prototype.__HTMLVideRendezVousSuppression = function __HTMLVideRendezVousSuppression()
{
	// Supprime l'evenement sur le bouton s'il existe
	if (this.m_oRendezVousSuppression)
	{
		clWDUtil.AttacheDetacheEvent(false, this.m_oRendezVousSuppression, "click", this.m_fOnRendezVousSupprime);
	}
	// Si le bouton existe : le supprime
	clWDUtil.bHTMLVideDepuisVariable(this, "m_oRendezVousSuppression");
};

// Supprime le HTML des rendez-vous
WDVueAPBase.prototype.__HTMLVideRendezVous = function __HTMLVideRendezVous(oOldDonnees)
{
	// Utilise le tableau des rendez-vous precedents
	var tabRendezVous = oOldDonnees.m_tabRendezVous;
	var i;
	var nLimiteI = tabRendezVous.length;
	for (i = 0; i < nLimiteI; i++)
	{
		// Supprime le rendez-vous
		this.__HTMLVideUnRendezVous(tabRendezVous[i]);
	}
};

// Supprime le HTML d'un rendez-vous
WDVueAPBase.prototype.__HTMLVideUnRendezVous = function __HTMLVideUnRendezVous(oRendezVous)
{
	// Supprime les evenements
	var oDiv = oRendezVous.m_oDiv;
	if (oDiv)
	{
		// Supprime les evenements
		clWDUtil.AttacheDetacheEvent(false, oDiv, "dblclick", oRendezVous.m_fOnDblClick);
		oRendezVous.m_fOnDblClick = null;
		delete oRendezVous.m_fOnDblClick;
		clWDUtil.AttacheDetacheEvent(true, oDiv, "click", oRendezVous.m_fOnClick);
		oRendezVous.m_fOnClick = null;
		delete oRendezVous.m_fOnClick;
		this.m_oChampAP.m_oDragRendezVous.vLibereElement(oRendezVous, oDiv);

		// Puis supprime le div du HTML
		clWDUtil.oSupprimeElement(oDiv);
		// Puis supprime la reference
		oDiv = null;
		oRendezVous.m_oDiv = null;
		delete oRendezVous.m_oDiv;
	}
};

// Supprime le HTML du conteneur
WDVueAPBase.prototype.__HTMLVideCorps = function __HTMLVideCorps()
{
	// Libere le hook sur les ressources
	var i;
	var nLimiteI = this.m_oChampAP._nGetNbConteneurs(true);
	for (i = 0; i < nLimiteI; i++)
	{
		var oConteneur = this.m_oChampAP._oGetConteneur(true, i);
		this.m_oChampAP.m_oDragPeriodeSelect.vLibereElement(oConteneur, oConteneur.m_oDiv, oConteneur.m_oDivTitreSeul);
		if (oConteneur.m_oDivTitreSeul)
		{
			oConteneur.m_oDivTitreSeul = null;
			delete oConteneur.m_oDivTitreSeul;
		}
		oConteneur.m_oDiv = null;
		delete oConteneur.m_oDiv;
	}

	clWDUtil.SupprimeFils(this.m_oHoteCorps);
};

// Supprime le HTML de la zone de titres vertical
WDVueAPBase.prototype.__HTMLVideTitresVertical = function __HTMLVideTitresVertical()
{
	if (this.m_oHoteTitresVertical)
	{
		clWDUtil.SupprimeFils(this.m_oHoteTitresVertical);
	}
};

// Supprime le HTML de la zone de titres horizontal
WDVueAPBase.prototype.__HTMLVideTitresHorizontal = function __HTMLVideTitresHorizontal()
{
	clWDUtil.SupprimeFils(this.m_oHoteTitresHorizontal);
};

// Vide la zone des boutons de changement de periode
WDVueAPBase.prototype.__HTMLVideBoutonsPeriode = function __HTMLVideBoutonsPeriode()
{
	if (this.m_oHoteBoutonsPeriode)
	{
		clWDUtil.SupprimeFils(this.m_oHoteBoutonsPeriode);
	}
};

//////////////////////////////////////////////////////////////////////////
// Positionnement dans l'affichage

// Retourne la coordonnee importante pour la position : X (ressources en ligne) ou Y (ressources en colonne) selon le conteneur hote
WDVueAPBase.prototype._nGetPositionHote = function _nGetPositionHote(oElement, nPosition, bX, bVersEcran)
{
	var nVersEcran = bVersEcran ? 1 : -1;
	var nOffset;
	if (bX)
	{
		nOffset = oElement.getBoundingClientRect().left;
	}
	else
	{
		nOffset = oElement.getBoundingClientRect().top;
	}
	return nPosition + nVersEcran * nOffset;
};

// Recupere la partie heure dans une journee une heure arrondie par defaut
// DD/MM/AAAA HH:MM:SS:MMM => HH:00:00:000
WDVueAPBase.prototype.__nGetHeureArrondiDefaut = function __nGetHeureArrondiDefaut(nHeure)
{
	// 3600000 = 3600 * 1000 = 1 heure en ms
	return Math.floor(nHeure / 3600000);
};

// Recupere la partie heure dans une journee une heure arrondie par defaut
// DD/MM/AAAA HH:MM:SS:MMM => HH:00:00:000 (si MM = SS = MMM = 0) ou HH+1:00:00:000
WDVueAPBase.prototype.__nGetHeureArrondiExces = function __nGetHeureArrondiExces(nHeure)
{
	// 3600000 = 3600 * 1000 = 1 heure en ms
	return Math.ceil(nHeure / 3600000);
};

// Recupere la description de l'heure dans lequel le point se trouve
// bFavoriseJourSuivant : si on est a une limite de jour : favorise le debut du jour suivant
// nConteneur : Si on a plusieurs graduation par conteneur : utiliser pour ce placer dans la bon pas
// bPourPosition : Indique si on est pour un affichage graphique ou pour retrouver l'heure du rendez-vous
// => Pour l'agenda � la semain ou les graduation sont permut�e en affichage, il faut permuter aussi selon le cas.
WDVueAPBase.prototype.__oGetGraduation = function __oGetGraduation(oParametres, nPosition, bFavoriseJourSuivant, nConteneur)
{
	var nDimensionPxGraduation = this.vnGetDimensionPxGraduation(oParametres);
	var nNbGraduationsParalleles = this._vnGetNbGraduationsParalleles(oParametres);
	var tabGraduations = this.m_tabGraduations;

	// Calcule la position en nombre d'heures depuis le debut de l'affichage => on obtient donc l'heure de debut de la zone
	// Normalement cette heure est aligne sur la resolution
	var nGraduationNumero = Math.floor(nPosition / nDimensionPxGraduation);
	var nGraduationMin = 0;
	var nGraduationPas = nNbGraduationsParalleles;
	if (1 < nNbGraduationsParalleles)
	{
		if (this.ms_bReordonneGraduationAffichage)
		{
			var nGraduationParJour = tabGraduations.length / nNbGraduationsParalleles;
			// Si on est sur le jour suivant : se place � la fin du jour
			nGraduationNumero = Math.min(nGraduationNumero, nGraduationParJour - 1);
			// Il faut faire la conversion selon le nombre de graduation par conteneur (et pas par le nombre de conteneur)
			nGraduationMin = nConteneur * nGraduationParJour;
			// Si on est sur le jour suivant : se place � la fin du jour
			nGraduationNumero = nGraduationNumero + nGraduationMin;
			nGraduationPas = 1;
		}
		else
		{
			nGraduationNumero = nGraduationNumero * nNbGraduationsParalleles + nConteneur;
		}
	}

	var nGraduationOriginale = nGraduationNumero;
	nGraduationNumero = Math.max(Math.min(nGraduationNumero, tabGraduations.length - 1), 0);
	// A cause des ruptures de jours, trouve l'heure exacte qui est forcement apres car les ruptures decalent vers le bas
	// Le calcul est fait pour avoir une valeur valide en cas de clic sur une rupture
	var oGraduation;
	do
	{
		oGraduation = tabGraduations[nGraduationNumero];
		nGraduationNumero -= nGraduationPas;
	} while ((nGraduationNumero >= nGraduationMin) && (oGraduation.m_nPosition > nPosition));

	// Donc si on est sur une rupture on en tient compte
	if (bFavoriseJourSuivant)
	{
		var bGraduationSuivante = false;
		// Si on est en fait sur la rupture du jour suivant
		// Les ruptures n'existent que pour le mode avec les ressources en colonne.
		// Donc dans le cas avec les ressources en ligne nHauteurRuptureJour contient 0 et on n'entre pas dans le test : ce qui est correct
		var nHauteurRuptureJour = this._vnGetHauteurRuptureJour(oParametres);
		if (nHauteurRuptureJour)
		{
			// Ici this.vnGetDimensionPxGraduation() fonctionne que l'on soit en affichage par heure ou en affichage par jour (le calcul est dans __oGetGraduation)
			var nFinGraduation = oGraduation.m_nPosition + nDimensionPxGraduation;
			var nDebutJourSuivant = nFinGraduation + nHauteurRuptureJour;
			if ((nPosition >= nFinGraduation) && (nPosition < nDebutJourSuivant))
			{
				bGraduationSuivante = true;
			}
		}
		// +/-2 car nGraduationNumero a ete decremente dans la boucle
		if (bGraduationSuivante && (nGraduationNumero < (tabGraduations.length - 2)) && tabGraduations[nGraduationNumero + 2].m_bRupture)
		{
			oGraduation = tabGraduations[nGraduationNumero + 2];
		}
	}
	else if (oGraduation.m_bRupture && (oGraduation.m_nPosition == nPosition) && (0 <= nGraduationNumero))
	{
		// il y deja eu "nGraduationNumero -= nGraduationPas"
		oGraduation = tabGraduations[nGraduationNumero];
	}
	// GP 29/04/2014 : TB87231 : le Math.min fait que l'on tombe sur la derni�re graduation affich�e en mode agenda en mode mois.
	// => Au lieu d'�tre sur une graduation qui n'existe pas, de passer dans nGraduationNumero -= nGraduationPas (7 ici)
	// et dans le else if (oGraduation.m_bRupture && (oGraduation.m_nPosition == nPosition) && (0 <= nGraduationNumero))
	// Il faut donc traiter le cas
	else if (oGraduation.m_bRupture && (oGraduation.m_nPosition < nPosition) && (tabGraduations.length <= nGraduationOriginale) && ((nGraduationNumero + nGraduationPas) == (tabGraduations.length - 1)))
	{
		var oGraduationPossible = tabGraduations[nGraduationOriginale - nGraduationPas];
		if (oGraduationPossible && oGraduation.m_bRupture)
		{
			oGraduation = oGraduationPossible;
		}
	}

	return oGraduation;
};

// Arrondi la variation en fonction de la granularite autorisee
WDVueAPBase.prototype.nAppliqueResolution = function nAppliqueResolution(oParametres, nPosition, dResolutionPx, nConteneur)
{
	// A cause des ruptures de jours, trouve l'heure exacte qui est forcement apres car les ruptures decalent vers le bas
	var oGraduation = this.__oGetGraduation(oParametres, nPosition, false, nConteneur);

	// Trouve la position (corrigee) en point par rapport au debut de l'heure
	var nPositionDansGraduation = this.__nGetPositionDansGraduation(oParametres, nPosition, oGraduation);

	// Arrondi la position en fonction de la granularite autorisee
	var nOffetNbResolution = Math.round(nPositionDansGraduation / dResolutionPx);
	return oGraduation.m_nPosition + Math.round(nOffetNbResolution * dResolutionPx);
};

// Indique si on est dans la zone de rendez-vous � la journ�e quand cette zone n'est pas s�par�e
WDVueAPBase.prototype.bDansRendezVousALaJournee = function bDansRendezVousALaJournee(oParametres, nPosition, nConteneur)
{
	// L'id�e est de d�tect� si on est entre deux jours en variant bFavoriseJourSuivant.
	// Si on obtient la m�me graduation, c'est que l'on est dans le corps d'un jour
	// Si on obtient deux graduations diff�rentes, c'est que l'on est dans la rupture.
	// Comme le texte de jours de la rupture n'est pas clicable, il ne reste que la zone des rendez-vous � la journ�e

	// Ou si on est avant la premi�re graduation (le calcul ne fonctionne pas avec la premi�re graduation
	if (nPosition < this.m_tabGraduations[0].m_nPosition)
	{
		return true;
	}

	// A cause des ruptures de jours, trouve l'heure exacte qui est forcement apres car les ruptures decalent vers le bas
	var oGraduation = this.__oGetGraduation(oParametres, nPosition, false, nConteneur);
	// A cause des ruptures de jours, trouve l'heure exacte qui est forcement apres car les ruptures decalent vers le bas
	var oGraduationFavoriseApres = this.__oGetGraduation(oParametres, nPosition, true, nConteneur);

	return (oGraduationFavoriseApres !== oGraduation);
};

// Trouve la position en point par rapport au debut de l'heure
WDVueAPBase.prototype.__nGetPositionDansGraduation = function __nGetPositionDansGraduation(oParametres, nPosition, oGraduation)
{
	return this.__nGetPositionDansGraduationInterne(nPosition, oGraduation, this.vnGetDimensionPxGraduation(oParametres));
};
// Trouve la position en point par rapport au debut de l'heure
// => Version interne qui prend nDimensionPxGraduation en param�tres
WDVueAPBase.prototype.__nGetPositionDansGraduationInterne = function __nGetPositionDansGraduationInterne(nPosition, oGraduation, nDimensionPxGraduation)
{
	// Calcule la difference de position
	var nPositionDansGraduation = nPosition - oGraduation.m_nPosition;
	// Si on est sur la premiere rupture : nPositionDansGraduation < 0
	nPositionDansGraduation = Math.max(nPositionDansGraduation, 0);
	// Si on est sur une autre rupture : nPositionDansGraduation > this.vnGetDimensionPxGraduation()
	nPositionDansGraduation = Math.min(nPositionDansGraduation, nDimensionPxGraduation);

	return nPositionDansGraduation;
};


// Convertie une nouvelle position (deja aligne sur la resolution) en date
// nHeureJour : heure a placer selon le mode
// - Planning/Agenda a la semaine/Agenda au jour : Les heures sont en fonction de la position
// - Agenda au mois/Agenda a l'ann�e : Les heures sont copi�s de la pr�c�dente heure si elle existe
WDVueAPBase.prototype.oGetDateFromPosAlignResolution = function oGetDateFromPosAlignResolution(oParametres, nPosition, bFavoriseJourSuivant, nConteneur, nHeureJourMs, bAvecAlignementSurLaGrille)
{
	// Trouve la date (verifiant la resolution) la plus proche de la position donnee

	// A cause des ruptures de jours, trouve l'heure exacte qui est forcement apres car les ruptures decalent vers le bas
	var oGraduation = this.__oGetGraduation(oParametres, nPosition, bFavoriseJourSuivant, nConteneur);

	// Calcule la date
	var nDatePosition = oGraduation.m_oDateDebut.getTime() + this._vnGetDureeMsFromPosAlignResolution(oParametres, nPosition, oGraduation, nHeureJourMs, bAvecAlignementSurLaGrille);
	// Et construit l'objet date
	// GP 29/06/2012 : Pourquoi parseInt ?
//	return new Date(parseInt(nDatePosition, 10));
	return new Date(nDatePosition);
};
WDVueAPBase.prototype._vnGetDureeMsFromPosAlignResolution = function _vnGetDureeMsFromPosAlignResolution(oParametres, nPosition, oGraduation, nHeureJourMs, bAvecAlignementSurLaGrille)
{
	// GP 30/01/2015 : OPTIM : __nGetPositionDansGraduationInterne et le calcul final ont besoin de vnGetDimensionPxGraduation
	// => Fait une seule fois le calcul
	var nDimensionPxGraduation = this.vnGetDimensionPxGraduation(oParametres);

	// Trouve la position en point par rapport au debut de l'heure
	var nPositionDansGraduation = this.__nGetPositionDansGraduationInterne(nPosition, oGraduation, nDimensionPxGraduation);
	// En deduit la date
	// GP 13/02/2015 : Sauf que si on est pour le d�filement, on peut avoir un d�filement qui n'est pas sur les graduation
	// GP 30/01/2015 : QW253446 : Il ne faut pas oublier d'appliquer la r�solution.
	// Sinon si on a 63 ligne par heure, la demi heure est a 32, ce qui est mal arrondi
	var nDureeMs = nPositionDansGraduation * this.m_nGraduationDureeMs / nDimensionPxGraduation;
	if (bAvecAlignementSurLaGrille)
	{
		nDureeMs = Math.round(nDureeMs / oParametres.m_nResolutionGrille) * oParametres.m_nResolutionGrille;
	}
	return nDureeMs;
};

// Applique la resolution du debut (resolution de la precision de placement
WDVueAPBase.prototype.nAppliqueResolutionDeplacement = function nAppliqueResolutionDeplacement(oParametres, nPosition, nConteneur)
{
	var dResolutionDeplacementPx = this.__nGetDimensionPxDepuisDureeMs(oParametres, oParametres.m_nResolutionDeplacement);
	var nDebut = this.nAppliqueResolution(oParametres, nPosition, dResolutionDeplacementPx, nConteneur);
	if (nDebut > nPosition)
	{
		nDebut -= Math.round(dResolutionDeplacementPx);
	}
	return nDebut;
};


// Applique la resolution de taille
// nDebutPositionCorrection : Debut - debut corrige
WDVueAPBase.prototype.nAppliqueResolutionTaille = function nAppliqueResolutionTaille(oParametres, nOffsetPosition, nDebutPositionCorrection, nConteneur, bTitreSeul)
{
	// Et la longueur : arrondi la position en fonction de la granularite autorisee
	var dResolutionLongueurPx = this.__nGetDimensionPxDepuisDureeMs(oParametres, oParametres.m_nResolutionTaille);
	var nLongueur = Math.round(Math.round(nOffsetPosition / dResolutionLongueurPx) * dResolutionLongueurPx);
	// GP 25/03/2013 : Sauf que ici si on a une zone pour les rendez-vous � la journ�e, elle entre dans le calcul de la premi�re it�ration
	var nHauteurZoneJourneeCompleteEffective = 0;
	if (!this.ms_bZoneTitreSeulIndependanteParLigne && !this.ms_bZoneTitreSeulIndependanteExterne && !!oParametres.m_nHauteurZoneJourneeComplete && !bTitreSeul)
	{
		nHauteurZoneJourneeCompleteEffective = oParametres.m_nHauteurZoneJourneeComplete;
	}
	nLongueur += nHauteurZoneJourneeCompleteEffective;

	// GP 02/05/2018 : TB100782 : Il semble que cet appel ne sert plus a rien. En tout cas dans la cas de la fiche c'est juste sans l'appel.
//	// On applique quand meme une resolution de 1 pour avoir les calculs pour la position des ruptures
//	nLongueur = this.nAppliqueResolution(oParametres, nLongueur, 1.0, nConteneur);
	if ((nLongueur < nOffsetPosition + nDebutPositionCorrection) || (0 == nLongueur))
	{
		nLongueur += Math.round(dResolutionLongueurPx); ;
	}

	return nLongueur - nHauteurZoneJourneeCompleteEffective;
};

// Corrige une heure pour etre dans la plage des heures affichables
// bSensFuture : Si vrai on arrondi en priorite la date vers le futur
WDVueAPBase.prototype.__nCorrigeDateHeure = function __nCorrigeDateHeure(oParametres, nDate, bSensFutur)
{
	// Si on est en affichage par journee ou demi-journee :
	// oParametres.m_nHeureAfficheMin contient deja 0
	// oParametres.m_nHeureAfficheMax contient deja 86400000
	// => ce qui revient a ne rien faire
	var nHeureJour = clWDUtil.nGetHeureJour(nDate);
	if (nHeureJour < oParametres.m_nHeureAfficheMin)
	{
		// Si on est le matin : avant l'heure min
		if (bSensFutur)
		{
			// Avance la date
			return nDate - nHeureJour + oParametres.m_nHeureAfficheMin;
		}
		else
		{
			// Recule la date au jour precedent
			// 86400000 = 24 * 3600 * 1000 = 1 jour en ms
			return nDate - nHeureJour - 86400000 + oParametres.m_nHeureAfficheMax;
		}
	}
	else if (nHeureJour >= oParametres.m_nHeureAfficheMax)
	{
		// Si on est le soir : apres l'heure max
		if (bSensFutur)
		{
			// Avance la date au jour suivant
			// 86400000 = 24 * 3600 * 1000 = 1 jour en ms
			return nDate - nHeureJour + 86400000 + oParametres.m_nHeureAfficheMin;
		}
		else
		{
			// Recule la date
			return nDate - nHeureJour + oParametres.m_nHeureAfficheMax;
		}
	}
	return nDate;
};

//////////////////////////////////////////////////////////////////////////
// Styles

// Initialisation du style des heures
WDVueAPBase.prototype.__InitCSS_Heures = function __InitCSS_Heures(oParametres)
{
	// Style (largeur) des zones
	// Le positionnement est dans des styles generaux
	var nDimensionLaterale;
	if (this.ms_bZoneTitreSeulIndependanteParLigne)
	{
		nDimensionLaterale = this._vnGetDimensionLateralePxGraduation(oParametres);
	}
	else
	{
		nDimensionLaterale = this.__nGetDimensionLateralePxToutesGraduations(oParametres);
	}
	var tabStyleLateralTotal = this._vtabInitCSS_DimensionPxLaterale([], nDimensionLaterale, 0, 0, false);

	// GP 27/11/2013 : QW239791 : D�plac� ici pour �tre plus pr�cis
	// GP 20/11/2013 : QW237310 : @@@ Hack pour test : Il faudrait tenir compte du style de la derni�re graduation pour trouver sa bordure et l'ajout�e
	// Mais uniquement si on n'est pas en quirks
	var nDimensionPxZoneHeures = this.m_nDimensionPxZoneHeures;
	if ((!bIEQuirks9Max) && (this instanceof WDVueAPHorizontale))
	{
		nDimensionPxZoneHeures++;
	}

	var tabStyleLateralFond = tabStyleLateralTotal.concat(this.ms_sStyleDimension + ":" + nDimensionPxZoneHeures + "px");
	var sClassSupplementaire = "";
	if (this.ms_bZoneTitreSeulIndependanteParLigne)
	{
		var nHauteurZoneTitreSeulIndependante = this._vnGetHauteurZoneTitreSeulIndependante(oParametres);
		if (0 < nHauteurZoneTitreSeulIndependante)
		{
			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomCorps, "", this.ms_sNomJourneeNonComplete), ["margin-top:" + nHauteurZoneTitreSeulIndependante + "px"]);
			sClassSupplementaire = "." + this.ms_sNomJourneeNonComplete + " ";
			var tabStyleZoneTitreSeulIndependante = this._vtabInitCSS_DimensionPxLaterale([], nHauteurZoneTitreSeulIndependante, 0, 0, false).concat(this.ms_sStyleDimension + ":" + this.m_nDimensionPxZoneHeures + "px");
			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomCorps, "", this.ms_sNomFondCouleur), tabStyleZoneTitreSeulIndependante);
			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomCorps, "", this.ms_sNomFondBordure), tabStyleZoneTitreSeulIndependante);
		}
	}
	this.__StyleCree(this.__sGetSelecteur(this.ms_sNomCorps, sClassSupplementaire, this.ms_sNomFondCouleur), tabStyleLateralFond);
	this.__StyleCree(this.__sGetSelecteur(this.ms_sNomCorps, sClassSupplementaire, this.ms_sNomFondBordure), tabStyleLateralFond);

	// Style general : hauteur d'une heure
	var tabStylePrincipal = this._vtabInitCSS_DimensionPxPrincipale([], this.vnGetDimensionPxGraduation(oParametres), 0, 0, false);
	var tabStyleLateralHeure = this._vtabInitCSS_DimensionPxLaterale([], this._vnGetDimensionLateralePxGraduation(oParametres), 0, 0, false);
	this.__StyleCree(this.__sGetSelecteur(undefined, "", this.ms_sNomHeure), tabStylePrincipal.concat(tabStyleLateralHeure));
	this.__StyleCree(this.__sGetSelecteur(undefined, "", this.ms_sNomHeureLibelle), tabStylePrincipal.concat(tabStyleLateralTotal));

	// Couleur des heures
	var i;
	var nLimiteI = this.ms_tabHeureSuffixe.length;
	for (i = 0; i < nLimiteI; i++)
	{
		this.__InitCSS_UneHeure(oParametres, i, tabStyleLateralHeure);
	}
};

// Initialisation du style des heures (on est forcement en affichage par heure)
WDVueAPBase.prototype.__InitCSS_UneHeure = function __InitCSS_UneHeure(oParametres, nStyle, tabStyleLateralHeure)
{
	var sSuffixe = this.ms_tabHeureSuffixe[nStyle];

	var sClasse = "WDPLN-" + sSuffixe;
	// Recupere le style demande
	var oStyle = oParametres["m_oStyle" + sSuffixe];

	// Traite le style impair
	this.__InitCSS_UneHeureInterne(oParametres, oStyle, nStyle, sClasse, tabStyleLateralHeure, oParametres.m_oStyleHorsBornes);

	// GP 29/11/2012 : QW226840 : Si le style pair existe
	oStyle = oParametres["m_oStyle" + sSuffixe + this.ms_sSuffixePair];
	if (oStyle)
	{
		this.__InitCSS_UneHeureInterne(oParametres, oStyle, nStyle, sClasse + this.ms_sSuffixePair, tabStyleLateralHeure, oParametres.m_oStyleHorsBornesPair);
	}
};
WDVueAPBase.prototype.__InitCSS_UneHeureInterne = function __InitCSS_UneHeureInterne(oParametres, oStyle, nStyle, sClasse, tabStyleLateralHeure, oStyleHorsBornes)
{
	// Si on a une couleur de fond
	if (oStyle.m_cFond)
	{
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomFondCouleur, "", sClasse), ["background-color:" + oStyle.m_cFond]);
	}

	// Style des bordures (demi-heures)
	var tabStyle = [];
	var nBordure = oStyle.m_nBordureV;
	var sClasseHorsBornes = "";
	if (0 < nBordure)
	{
		tabStyle = this._vtabInitCSS_BorduresPerpendiculaires(tabStyle, oStyle, oStyle, true);
		// Normalement la couleur de fond dans la premiere colonne est dessous donc cela ne pose pas de probleme
		var tabStyleLibelle = this._vtabInitCSS_BorduresPerpendiculaires(["background-color:transparent"], oStyle, undefined);
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomFondBordure + " ." + sClasse, "", this.ms_sNomHeureLibelle), tabStyleLibelle);

		var sSelecteurHeure = this.__sGetSelecteur(this.ms_sNomFondBordure + " ." + sClasse + "." + this.ms_sNomHeure, "", undefined);
		var sSelecteurHeurePremier = this.__sGetSelecteur(this.ms_sNomFondBordure + " ." + sClasse + "." + this.ms_sNomHeure + "." + this.ms_sNomPremier, "", undefined);
		// Si on est en affichage a la journee, affiche le separateur
		if (oParametres.m_nResolutionGrille >= 86400000)
		{
			var tabStyleHeure = this._vtabInitCSS_BorduresPerpendiculaires([], oStyle, null, false);
			// Il faut tenir compte du separateur
			if (!bIEQuirks9Max && (0 < nBordure))
			{
				tabStyleHeure = this._vtabInitCSS_DimensionPxPrincipale(tabStyleHeure, (this.vnGetDimensionPxGraduation(oParametres) - nBordure), 0, 0, false);
			}
			this.__StyleCree(sSelecteurHeure, tabStyleHeure);

			// GP 20/11/2013 : QW237310
			tabStyleHeure = this._vtabInitCSS_BorduresPerpendiculaires([], oStyle, oStyle, false);
			// Il faut tenir compte du separateur
			if (!bIEQuirks9Max && (0 < nBordure))
			{
				tabStyleHeure = this._vtabInitCSS_DimensionPxPrincipale(tabStyleHeure, (this.vnGetDimensionPxGraduation(oParametres) - nBordure), 0, 0, false);
			}
			this.__StyleCree(sSelecteurHeurePremier, tabStyleHeure);
		}
		else
		{
			// GP 28/07/2017 : TB104545 : En cas de changement de pr�sentation, il ne faut pas laisser des styles parasites.
			// En effet avec un affichage � la demi heure, les heures n'ont pas de bordure. Si on viens d'un affichage � la journ�e (qui utilise l'affichage des heures pour les journ�es)
			// on a des bordures parasites suppl�mentaires
			this.__StyleSupprime(sSelecteurHeure);
			this.__StyleSupprime(sSelecteurHeurePremier);
		}
	}
	else if ((2 <= nStyle) && (nStyle <= 5) && oStyleHorsBornes && (0 <= oStyleHorsBornes.m_nBordureV))
	{
		// GP 12/02/2013 : QW228390 : Si 2 <= nStyle <= 5(donc les styles de type de jours) : il faut g�rer la combinaison avec hors bornes
		sClasseHorsBornes = "WDPLN-HorsBornes.";
		nBordure = oStyleHorsBornes.m_nBordureV;
	}

	if (this.__bAfficheDemiHeures(oParametres))
	{
		var nDimensionPxDemiHeure = Math.floor(this.vnGetDimensionPxGraduation(oParametres) / 2);
		// On veux que le trait soit au debut de la demi heure donc il faut l'epaisseur en pixel supplementaire
		// Donc au lieu de faire :
		//	- compat : + 0 * bordure
		//	- strict : - 2 * bordure
		// On fait decale de 1 :
		//	- compat : + 1 * bordure
		//	- strict : - 1 * bordure
		if (bIEQuirks9Max)
		{
			nDimensionPxDemiHeure += nBordure; // - * 1 et pas - * 2
		}
		else
		{
			nDimensionPxDemiHeure -= nBordure; // - * 1 et pas - * 2
		}

		// Fixe la taille
		tabStyle = this._vtabInitCSS_DimensionPxPrincipale(tabStyle, nDimensionPxDemiHeure, 0, 0, false);
		tabStyle = tabStyle.concat(tabStyleLateralHeure);
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomFondBordure + " ." + sClasse, "", this.ms_sNomHeureDemi), tabStyle);

		// GP 12/02/2013 : QW228390 : Si 2 <= nStyle <= 5(donc les styles de type de jours) : il faut g�rer la combinaison avec hors bornes
		if ((2 <= nStyle) && (nStyle <= 5) && oStyleHorsBornes && (0 <= oStyleHorsBornes.m_nBordureV) && (oStyle.m_nBordureV != oStyleHorsBornes.m_nBordureV))
		{
			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomFondBordure + " ." + sClasseHorsBornes + sClasse, "", this.ms_sNomHeureDemi), tabStyle);
		}
	}
};

// Construit le style pour les bordures dans le sens haut/bas ou droite/gauche
WDVueAPBase.prototype.__tabInitCSS_BorduresMoitie = function __tabInitCSS_BorduresMoitie(tabStyle, oStyleDebut, sDebut, oStyleFin, sFin, bFinPointille)
{
	// Bordure du debut (ici haut)
	if (oStyleDebut && (0 < oStyleDebut.m_nBordureV))
	{
		tabStyle.push("border-" + sDebut + ":solid " + oStyleDebut.m_nBordureV + "px " + oStyleDebut.m_cBordureV);
	}
	// Bordure de la fin (ici bas)
	if (oStyleFin && (0 < oStyleFin.m_nBordureV))
	{
		tabStyle.push("border-" + sFin + ":" + (bFinPointille ? "dotted" : "solid") + " " + oStyleFin.m_nBordureV + "px " + oStyleFin.m_cBordureV);
	}
	return tabStyle;
};
WDVueAPBase.prototype._tabInitCSS_BorduresHautBas = function _tabInitCSS_BorduresHautBas(tabStyle, oStyleDebut, oStyleFin, bFinPointille)
{
	return this.__tabInitCSS_BorduresMoitie(tabStyle, oStyleDebut, "top", oStyleFin, "bottom", bFinPointille);
};
WDVueAPBase.prototype._tabInitCSS_BorduresGaucheDroite = function _tabInitCSS_BorduresGaucheDroite(tabStyle, oStyleDebut, oStyleFin, bFinPointille)
{
	return this.__tabInitCSS_BorduresMoitie(tabStyle, oStyleDebut, "left", oStyleFin, "right", bFinPointille);
};

// Construit le style pour une dimension (stricte si demande) dans le sens largueur/hauteur
WDVueAPBase.prototype.__tabInitCSS_Dimension = function __tabInitCSS_Dimension(tabStyle, nDimensionPx, sDimension, bStrict)
{
	// Vu en �valuant les probl�mes de JVS : on re�oit des NaN ici dans certains cas (c'est probablement des calculs inutiles mais difficule de corriger).
	// => Blinde le cas + assert
	if (!isNaN(nDimensionPx))
	{
		// Utilisation de clWDUtil.GetDimensionPxPourStyle pour avoir "0" et pas "0px"
		var sTemp = sDimension + ":" + clWDUtil.GetDimensionPxPourStyle(nDimensionPx);
		tabStyle.push(sTemp);
		if (bStrict)
		{
			tabStyle.push("min-" + sTemp);
			tabStyle.push("max-" + sTemp);
		}
	}
	else
	{
		clWDUtil.WDDebug.assert(false, "__tabInitCSS_Dimension : Dimensions non valides (NaN).");
	}
	return tabStyle;
};
WDVueAPBase.prototype._tabInitCSS_DimensionLargeur = function _tabInitCSS_DimensionLargeur(tabStyle, nDimensionPx, nPaddingLargeur, nPaddingHauteur, bStrict)
{
	return this.__tabInitCSS_Dimension(tabStyle, nDimensionPx - nPaddingLargeur, "width", bStrict);
};
WDVueAPBase.prototype._tabInitCSS_DimensionHauteur = function _tabInitCSS_DimensionHauteur(tabStyle, nDimensionPx, nPaddingLargeur, nPaddingHauteur, bStrict)
{
	if (bStrict)
	{
		// Vu en �valuant les probl�mes de JVS : on re�oit des NaN ici dans certains cas (c'est probablement des calculs inutiles mais difficule de corriger).
		// => Blinde le cas + assert
		if (!isNaN(nDimensionPx - nPaddingHauteur))
		{
			// Si on a un titre avec double ligne ici on supprime trop de hauteur (la seconde ligne perd une bordure quelle n'a pas
			tabStyle.push("line-height:" + (nDimensionPx - nPaddingHauteur) + "px");
		}
		else
		{
			clWDUtil.WDDebug.assert(false, "_tabInitCSS_DimensionHauteur : Dimensions non valides (NaN).");
		}
	}
	return this.__tabInitCSS_Dimension(tabStyle, nDimensionPx - nPaddingHauteur, "height", bStrict);
};


// Initialisation du style de titre
// Param					Ressources											Heures
// sClasseTitre			=>	this.ms_sNomTitresConteneurs				this.ms_sNomTitresSecondaires
// sClasseZoneTitre		=>	selon le sens
// tabBordure			=>	Bordures laterales							Bordure principales
// tabBordurePremier	=>	Bordures laterales							Bordure principales
// tabBordureCote		=>	Bordure principales							Bordures laterales
// oStyleTitre			=>	oParametres.m_oStyleNormal					oParametres.m_oStyleLibHeure
// oStyleLibelle		=>	Parametres.m_oStyleLibRessource				oParametres.m_oStyleLibHeure
WDVueAPBase.prototype.__InitCSS_UnTitre = function __InitCSS_UnTitre(sClasseTitre
	, sClasseZoneTitre
	, sClassePlus
	, tabBordure
	, tabBordurePremier
	, tabBordureCote
	, oStyleTitre
	, oStyleLibelle
	, nLargeurPx
	, nHauteurPx
	, bLargeurStricte
	, bHauteurStricte
	, nPaddingTitreHorizontal
	, nPaddingTitreVertical)
{
	// Fixe la bordure des div (div de fond des ressources et div de titre des ressources)
	// GP 14/10/2013 : Inutile : fait en dessous
	//	this.__StyleCree(this.__sGetSelecteur(sClasseTitre, "div", sClassePlus), tabBordure);
	this.__StyleCree(this.__sGetSelecteur(sClasseTitre + " ." + this.ms_sNomPremier, "div", sClassePlus), tabBordurePremier);

	// Bordure du haut de la colonne de ressources
	this.__StyleCree(this.__sGetSelecteur(sClasseTitre, "td", sClassePlus), tabBordureCote);

	// Autres style pour les titres
	// - Dimension (dans les deux sens)
	// - Couleur de fond
	if (oStyleLibelle.m_cFond)
	{
		tabBordure.push("background-color:" + oStyleLibelle.m_cFond);
	}
	// Le reste (les dimensions) est specifique en particulier, il faut supprimer (ou pas) le padding selon le sens
	tabBordure = this._tabInitCSS_DimensionLargeur(tabBordure, nLargeurPx, nPaddingTitreHorizontal, nPaddingTitreVertical, bLargeurStricte);
	tabBordure = this._tabInitCSS_DimensionHauteur(tabBordure, nHauteurPx, nPaddingTitreHorizontal, nPaddingTitreVertical, bHauteurStricte);

	// GP 22/05/2014 : TB87164 : Le style CSS contient une bordure. La bordure viens par cascading completer la notre.
	// => On force � z�ro les bordures interdites
	clWDUtil.bForEach(["left", "top", "right", "bottom"], function(sCote)
	{
		// Pas de + ":" : permet de voir les "border-xxx-yyy"
		var sBordureStyle = "border-" + sCote;
		// Si ne trouve pas, c'est que l'on a fini l'it�ration donc que l'on retourne true
		if (clWDUtil.bForEach(tabBordure, function(sStyle)
		{
			// Si on trouve : retourne false ce qui bloque l'it�ration
			return (sStyle.substring(0, sBordureStyle.length) != sBordureStyle);
		}))
		{
			tabBordure.push("border-" + sCote + "-style:none");
		}
		return true;
	});

	// La hauteur est fixe dans le style des titres horizontal/vertical
	this.__StyleComplete(this.__sGetSelecteur(sClasseTitre, "div", sClassePlus), tabBordure);

	// Couleur de fond generale (sur toute la zone de titre)
	if (oStyleTitre && oStyleTitre.m_cFond)
	{
		this.__StyleCree(this.__sGetSelecteur(undefined, "", sClasseZoneTitre), ["background-color:" + oStyleTitre.m_cFond]);
	}
};

// Style des titres horizontaux :
// - Ressources (conteneurs) dans le cas du planning vertical
// - Mois, semaines, jours et heures dans le cas du planning horizontal
// - Semaine et jours (conteneurs) dans le cas de l'agenda
WDVueAPBase.prototype.__InitCSS_TitresHorizontaux = function __InitCSS_TitresHorizontaux(oParametres, bTitreConteneur)
{
	// Recup�re le tableau des styles horizontaux
	var tabStylesHorizontaux = this.__tabGetStylesHorizontaux(oParametres);
	// GP 20/11/2017 : Plus r�f�renc� dans la m�thode.
//	var oStyleNormal = oParametres.m_oStyleNormal;

	// Invariants
	var sNomTitreBase = (bTitreConteneur ? this.ms_sNomTitresConteneurs : this.ms_sNomTitresSecondaires);
	var nHauteurTitresHorizontauxUneLigne = this._vnGetHauteurTitresHorizontaux(oParametres, 1);
	var nLargeurPxBase;
	if (bTitreConteneur)
	{
		nLargeurPxBase = this._nGetDimensionLateralePxConteneur(oParametres);
	}
	else
	{
		nLargeurPxBase = this.vnGetDimensionPxGraduation(oParametres);
	}

	// Pour chaque ligne de style
	var nStyle;
	var nNbStyles = tabStylesHorizontaux.length;
	for (nStyle = 0; nStyle < nNbStyles; nStyle++)
	{
		var oStyle = tabStylesHorizontaux[nStyle];
		// Si on est pour un titre de conteneur : commence par le style de la bordure (ou le style des la derni�re bordure des titres secondaires si le style n'a pas de bordure)
		var oStyleBordurePremierGauche = bTitreConteneur ? this._oGetStyleOuStyleTitreSecondaireDernier(oParametres, oStyle) : oStyle;
		// GP 17/11/2017 : QW292862 : Pourquoi ? Si on est sur un titre il faut aussi continuer avec le style de ce titre...
//		// Si on est pour un titre de conteneur : on enchaine avec la brodure g�n�rale et pas la bordure du style
//		var oStyleBordureSuivant = bTitreConteneur ? oStyleNormal : oStyle;
		var oStyleBordureSuivant = oStyle;
		// Puis calcule la bordure vertical : double sur le premier puis a droite sur la suite
		var tabBordurePremier = this._tabInitCSS_BorduresGaucheDroite([], oStyleBordurePremierGauche, oStyleBordureSuivant);
		// GP 13/02/2013 : QW228691 : Inversion : c'est faux si les bordure ne sont pas de la m�me couleur mais sinon cela fonctionne
		// GP 14/02/2013 : QW229840 : Sauf si on est dans le titre des conteneurs
		var tabBordure = this._tabInitCSS_BorduresGaucheDroite([], bTitreConteneur ? null : oStyleBordureSuivant, bTitreConteneur ? oStyleBordureSuivant : null);
		// Puis calcule la bordure haut et bas : on ne place le style que sur la bordure haute.Il n'y a pas de brodure sur la derni�re ligne
		// (cette bordure est dessine par la bordure du contenu)
		var tabBordureHautBas = this._tabInitCSS_BorduresHautBas([], oStyle, null);
		// Dimensions
		var nLargeurPx = this.__nGetDimensionPxSansBordure(nLargeurPxBase, oStyle);
		var nHauteurPx;
		if (bTitreConteneur)
		{
			nHauteurPx = nHauteurTitresHorizontauxUneLigne;
		}
		else
		{
			nHauteurPx = this.__nGetDimensionPxSansBordure(nHauteurTitresHorizontauxUneLigne, oStyle);
		}
		// Nom des styles
		var sNomTitres = sNomTitreBase + nStyle;

		// D�clare le style
		this.__InitCSS_UnTitre(sNomTitres
			, this.ms_sNomTitresHorizontal
			, undefined
			, tabBordure
			, tabBordurePremier
			, tabBordureHautBas
			, oStyleBordureSuivant
			, oStyle
			, nLargeurPx
			, nHauteurPx
			, true
			, true
			, this.ms_nPaddingTitreCalcul
			, 0);
	}
};

// Style des titres horizontaux :
// - Heures dans le cas du planning vertical
// - Ressources (conteneurs) dans le cas du planning horizontal
// - Heures dans le cas de l'agenda
WDVueAPBase.prototype.__InitCSS_TitresVerticaux = function __InitCSS_TitresVerticaux(oParametres, bTitreConteneur)
{
	var oStyle = this._voGetStyleVertical(oParametres);
//	var oStyleNormal = oParametres.m_oStyleNormal;

	// Si on est pour un titre de conteneur : commence par le style de la bordure (ou le style des la derni�re bordure des titres secondaires si le style n'a pas de bordure)
	var oStyleBordurePremierHaut = bTitreConteneur ? this._oGetStyleOuStyleTitreSecondaireDernier(oParametres, oStyle) : oStyle;
	// GP 28/03/2014 : TB77716 : Ce n'est pas ce qui est dessin� en �dition
//	// Si on est pour un titre de conteneur : on enchaine avec la brodure g�n�rale et pas la bordure du style
//	var oStyleBordureSuivant = bTitreConteneur ? oStyleNormal : oStyle;
	var oStyleBordureSuivant = oStyle;
	// Puis calcule la bordure vertical : double sur le premier puis a droite sur la suite
	var tabBordurePremier = this._tabInitCSS_BorduresHautBas([], oStyleBordurePremierHaut, oStyleBordureSuivant);
	// GP 13/02/2013 : QW228691 : Inversion : c'est faux si les bordure ne sont pas de la m�me couleur mais sinon cela fonctionne
	// GP 14/02/2013 : QW229840 : Sauf si on est dans le titre des conteneurs
	var tabBordure = this._tabInitCSS_BorduresHautBas([], bTitreConteneur ? null : oStyleBordureSuivant, bTitreConteneur ? oStyleBordureSuivant : null);
	// Puis calcule la bordure haut et bas : on ne place le style que sur la bordure haute.Il n'y a pas de brodure sur la derni�re ligne
	// (cette bordure est dessine par la bordure du contenu)
	var tabBordureGaucheDroite = this._tabInitCSS_BorduresGaucheDroite([], oStyle, null);
	// Dimensions
	var nLargeurPx;
	var nHauteurPx;
	if (bTitreConteneur)
	{
		nLargeurPx = oParametres.m_nLargeurTitresVertical;
		nHauteurPx = this.__nGetDimensionPxSansBordureTitresVerticaux(this._nGetDimensionLateralePxConteneur(oParametres), oStyle);
	}
	else
	{
		nLargeurPx = this.__nGetDimensionPxSansBordureTitresVerticaux(oParametres.m_nLargeurTitresVertical, oStyle);
		nHauteurPx = this.__nGetDimensionPxSansBordureTitresVerticaux(this.vnGetDimensionPxGraduation(oParametres), oStyle);
	}
	// Nom des styles
	var sNomTitres = bTitreConteneur ? this.ms_sNomTitresConteneurs : this.ms_sNomTitresSecondaires;

	var nPaddingTitresHorizontaux;
	var nPaddingTitresVerticaux;
	// GP 08/04/2019 : TB111341 : Suite de QW304791 : Passage en "box-sizing: border-box" pour les titres verticaux sur les navigateurs modernes, il faut tenir compte de bodure sur le line-height.
	if (clWDUtil.bHTML5 && !bIEAvec11)
	{
		nPaddingTitresHorizontaux = 0;
		nPaddingTitresVerticaux = this.ms_nPaddingTitresVerticaux;
		// GP 12/04/2019 : QW311607 : Manifestement cela ne semble fonctionner que avec les plannings horizontaux (tr�s bizarre).
		if (this instanceof WDVueAPHorizontale)
		{
			nPaddingTitresVerticaux += oStyle.m_nBordureV;
		}
	}
	else
	// GP 28/05/2019 : QW312428 : R�tablit le comportement pour IE (ce qui �tait intention initiale).
	// C'est assez illogique mais c'est ce qui fonctionne (il y a peut-�tre une inversion de valeur a un autre endroit ?).
	// GP 12/03/2020 : QW323936 : Et aussi pour le HTML4.
	{
		nPaddingTitresHorizontaux = this.ms_nPaddingTitresVerticaux;
		nPaddingTitresVerticaux = 0;
	}

	// D�clare le style
	this.__InitCSS_UnTitre(sNomTitres
		, this.ms_sNomTitresVertical
		, undefined
		, tabBordure
		, tabBordurePremier
		, tabBordureGaucheDroite
		, oStyleBordureSuivant
		, oStyle
		, nLargeurPx
		, nHauteurPx
		, false
		, bTitreConteneur
		, nPaddingTitresHorizontaux
		, nPaddingTitresVerticaux);
};

// Initialisation du style des conteneurs
WDVueAPBase.prototype.__InitCSS_Conteneurs = function __InitCSS_Conteneurs(oParametres)
{
	// Style du div (tient compte de la bordure)
	var nLargeurDivPremier = this.__nGetDimensionPxSansBordureConteneur(oParametres, true);
	var nLargeurDiv = this.__nGetDimensionPxSansBordureConteneur(oParametres, false);
	var nOffsetPremier = Math.max(0, nLargeurDiv - nLargeurDivPremier);

	if (isNaN(nLargeurDiv))
	{
		return;
	}

	var oStyleNormal = oParametres.m_oStyleNormal;

	var tabStyle;
	// Style general
	var nDimensionLateralePxConteneur = this._nGetDimensionLateralePxConteneur(oParametres);
	tabStyle = this._vtabInitCSS_DimensionPxLaterale([], nDimensionLateralePxConteneur, 0, 0, true);
	tabStyle = this._vtabInitCSS_BorduresLaterales(tabStyle, null, oStyleNormal);
	this.__StyleCree(this.__sGetSelecteur(undefined, "div", this.ms_sNomConteneur), tabStyle);
	// Style du premier
	// Le Style du libelle avant varie
	// Pour faire comme en edition : on privilige le style de la premiere ligne
	var oStyleBordureHaut = this._oGetStyleOuStyleTitreSecondaireDernier(oParametres, oStyleNormal);
	tabStyle = this._vtabInitCSS_DimensionPxLaterale([], nDimensionLateralePxConteneur - nOffsetPremier, 0, 0, true);
	tabStyle = this._vtabInitCSS_BorduresLaterales(tabStyle, oStyleBordureHaut, oStyleNormal);
	this.__StyleCree(this.__sGetSelecteur(this.ms_sNomPremier, "div", this.ms_sNomConteneur), tabStyle);

	var nHauteurZoneTitreSeulIndependante = this._vnGetHauteurZoneTitreSeulIndependante(oParametres);
	if (0 < nHauteurZoneTitreSeulIndependante)
	{
		tabStyle = ["height:" + nHauteurZoneTitreSeulIndependante + "px"];
		if (this.ms_bZoneTitreSeulIndependanteExterne)
		{
			tabStyle.push("width:" + this._nGetDimensionLateralePxConteneur(oParametres) + "px");
			tabStyle.push("float:left");
		}
		this.__StyleCree(this.__sGetSelecteur(undefined, "", this.ms_sNomConteneurTitreSeul), tabStyle);
	}
	// On soustrait ce style uniquement si les conteneurs sont horizontaux
	if (WDVueAPHorizontale.prototype.ms_sStyleDimensionLaterale != this.ms_sStyleDimensionLaterale)
	{
		nHauteurZoneTitreSeulIndependante = 0;
	}
	this.__StyleCree(this.__sGetSelecteur(undefined, "", this.ms_sNomConteneurRendezVous), [this.ms_sStyleDimensionLaterale + ":" + (nLargeurDiv - nHauteurZoneTitreSeulIndependante) + "px"]);

	// Si il y a une bordure sur le premier, il faut decaler le premier conteneur pour ne pas avoir le contenu coller a la bordure supplementaire
	// Sauf que sous IE en mode compat les bordures ne sont pas dans le calcul donc nOffsetPremier est toujours a 0
	if (bIEQuirks9Max && oStyleBordureHaut.m_nBordureV)
	{
		nOffsetPremier = oStyleBordureHaut.m_nBordureV;
		nLargeurDivPremier = nLargeurDiv - nOffsetPremier;
	}
	if (nOffsetPremier)
	{
		tabStyle.length = 0;
		tabStyle.push(this.ms_sStyleDebutLateral + ":" + nOffsetPremier + "px");
		tabStyle.push(this.ms_sStyleDimensionLaterale + ":" + (nLargeurDivPremier - nHauteurZoneTitreSeulIndependante) + "px");
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomPremier, "", this.ms_sNomConteneurRendezVous), tabStyle);
	}

	// Style general sur la largeur sur le td
	this.__StyleCree(this.__sGetSelecteur(undefined, "td", this.ms_sNomConteneur), this._vtabInitCSS_DimensionPxLaterale([], nDimensionLateralePxConteneur, 0, 0, true));
};

// Styles des rendez-vous
WDVueAPBase.prototype.__InitCSS_RendezVous = function __InitCSS_RendezVous(oParametres)
{
	// Le style des rendez-vous
	this.__InitCSS_RendezVous_UnStyle(oParametres, oParametres.m_oStyleRendezVous, this.ms_sNomRendezVous);
	// Le style du rendez-vous selectionne
	this.__InitCSS_RendezVous_UnStyle(oParametres, oParametres.m_oStyleRendezVousSelect, this.ms_sNomRendezVousSelect);
};

// Un des tyles des rendez-vous
WDVueAPBase.prototype.__InitCSS_RendezVous_UnStyle = function __InitCSS_RendezVous_UnStyle(oParametres, oStyle, sClass)
{
	// Style des bordures (demi-heures)
	var tabStyle;
	// Dessin compatible WX22-
	if (oParametres.m_bMargeFixes && (0 < oStyle.m_nBordureV))
	{
		tabStyle = ["border:solid " + oStyle.m_nBordureV + "px " + oStyle.m_cBordureV];

		// En mode quirks, IE9 n'affiche pas les bord arrondi
		if (!bIE || ((8 < nIE) && !bIEQuirks9Max))
		{
			tabStyle.push("border-collapse:separate");
			this.__BorderRadius(tabStyle, 5);

			var nRadiusInterne = Math.max(0, 5 - oStyle.m_nBordureV);
			if (0 < nRadiusInterne)
			{
				var tabStyleRadiusHaut = [];
				this.__BorderRadius(tabStyleRadiusHaut, nRadiusInterne, true);
				this.__StyleCree(this.__sGetSelecteur(this.ms_sNomRendezVousExterne, "li", ":first-child"), tabStyleRadiusHaut);
				var tabStyleRadius = [];
				this.__BorderRadius(tabStyleRadius, 5);
				this.__StyleCree(this.__sGetSelecteur(sClass, "", this.ms_sNomRendezVousTitreSeul), tabStyleRadius);
				var tabStyleRadiusBas = [];
				this.__BorderRadius(tabStyleRadiusHaut, nRadiusInterne, false);
				this.__StyleCree(this.__sGetSelecteur(this.ms_sNomRendezVousExterne, "li", ":last-child"), tabStyleRadiusHaut);

			}
		}
		this.__StyleCree(this.__sGetSelecteur(sClass, ""), tabStyle);
	}
	if (bEdge)
	{
		// Avec Edge : cela ne fonctionne pas. Il faut mettre le curseur sur tout le conteneur et supprimer le curseur du fils
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomRendezVousExterne, "", undefined), ["cursor:" + this.ms_sCurseurRedim]);
	}
	else
	{
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomRendezVousRedimDebutBefore, "", undefined), ["cursor:" + this.ms_sCurseurRedim]);
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomRendezVousRedimFinAfter, "", undefined), ["cursor:" + this.ms_sCurseurRedim]);
	}
	// Fait de mani�re globale dans WDVueAPBase.prototype._vInitInitiale
//	this.__StyleCree(this.__sGetSelecteur(this.ms_sNomRendezVous, "", undefined), ["cursor:default"]);
//	this.__StyleCree(this.__sGetSelecteur(this.ms_sNomRendezVousSelect, "", undefined), ["cursor:default"]);

	// Dessin compatible WX22-
	if (oParametres.m_bMargeFixes)
	{
		var nPadding = this.__nGetRendezVousEpaisseurBordure(oStyle);
		if (nPadding)
		{
			tabStyle = ["padding-left:" + nPadding + "px", "padding-right:" + nPadding + "px"];
			// Si besoin ajoute un deplacement de l'image
			if (bIEQuirks9Max && (nIE < 8))
			{
				tabStyle.push("-ms-background-position-x:" + nPadding + "px");
			}
			else
			{
				tabStyle.push("background-position-x:" + nPadding + "px");
			}
			this.__StyleCree(this.__sGetSelecteur(undefined, "", sClass + " li"), tabStyle);
		}
	}
};

// R�cup�re les styles

// Fonctions virtuelles
// _vtabGetStylesHorizontaux
//	=> Titre horizontaux
// _voGetStyleVertical
//	=> Titre verticaus
// _voGetStyleTitreSecondaireDernier
//	=> Style de la derni�re ligne des titres secondaires (= des titres qui ne sont pas les conteneurs)

// R�cup�re les styles horizontaux (sans cache)
// _vtabGetStylesHorizontaux

// R�cup�re les styles horizontaux (utilise un cache autour de _vtabGetStylesHorizontaux)
WDVueAPBase.prototype.__tabGetStylesHorizontaux = function __tabGetStylesHorizontaux(oParametres)
{
	if (undefined === oParametres.m_tabStylesHorizontaux)
	{
		oParametres.m_tabStylesHorizontaux = this._vtabGetStylesHorizontaux(oParametres);
	}
	return oParametres.m_tabStylesHorizontaux;
};

// Recup�re un style horizontal
WDVueAPBase.prototype._oGetStyleHorizontal = function _oGetStyleHorizontal(oParametres, nStyle)
{
	return this.__tabGetStylesHorizontaux(oParametres)[nStyle];
};

// R�cup�re le dernier style horizontal
WDVueAPBase.prototype._oGetStyleHorizontalDernier = function _oGetStyleHorizontalDernier(oParametres)
{
	var tabStylesHorizontaux = this.__tabGetStylesHorizontaux(oParametres);
	return tabStylesHorizontaux[tabStylesHorizontaux.length - 1];
};

// Pour faire comme en edition : si le style ne contient pas de brodure, on prend le style de la derni�re ligne de titre
WDVueAPBase.prototype._oGetStyleOuStyleTitreSecondaireDernier = function _oGetStyleOuStyleTitreSecondaireDernier(oParametres, oStyle)
{
	return ((oStyle && (0 < oStyle.m_nBordureV)) ? oStyle : this._voGetStyleTitreSecondaireDernier(oParametres));
};

// Modification de la largeur/hauteur du libelle des jours de la semaine pour tenir compte de la bordure et du mode quirks
// Attention : on retourne la valeur en negatif, faire un +=
WDVueAPBase.prototype._nGetOffsetBordure = function _nGetOffsetBordure(oStyle, nNbBordures)
{
	if ((0 < oStyle.m_nBordureV) && !bIEQuirks9Max)
	{
		return -(nNbBordures * oStyle.m_nBordureV);
	}
	return 0;
};

WDVueAPBase.prototype.__BorderRadius = function __BorderRadius(tabStyle, nRadius, bTop)
{
	var nRadiusTop = ((bTop === undefined) || bTop) ? nRadius : 0;
	var nRadiusBottom = ((bTop === undefined) || !bTop) ? nRadius : 0;
	// GP 11/07/2017 : Plus besoin de pr�fixer les divers styles CSS utilis�s (disponible sans pr�fixe depuis 2011/2012)
//	tabStyle.push(clWDUtil.m_sPrefixeCSS + "border-radius:" + nRadiusTop + "px " + nRadiusTop + "px " + nRadiusBottom + "px " + nRadiusBottom + "px");
	tabStyle.push("border-radius:" + nRadiusTop + "px " + nRadiusTop + "px " + nRadiusBottom + "px " + nRadiusBottom + "px");
};

// Trouve l'epaisseur des cellules bordures d'un rendez-vous en fonction de l'epaisseur des bordures du style
WDVueAPBase.prototype.__nGetRendezVousEpaisseurBordure = function __nGetRendezVousEpaisseurBordure(oStyle)
{
	// Epaisseur des elements sur le bord de la table
	var nEpaisseur = this.ms_nPaddingRendezVous;
	if (0 < oStyle.m_nBordureV)
	{
		return Math.max(0, nEpaisseur - oStyle.m_nBordureV);
	}
	else
	{
		return nEpaisseur;
	}
};

// Ajoute la classe d'un style dans un tableau si valide
WDVueAPBase.prototype.__bPushStyleClasses = function __bPushStyleClasses(oStyle, tabClasses)
{
	var sClasses = oStyle.m_sClasses;
	// Inutile de tester .length : "" s'�value a faux et "<Contenu>" s'�value � vrai.
	if (sClasses)
	{
		// GP 09/11/2017 : QW292788 : Mettre la classe "padding" (Pour avoir la version avec padding de la classe HTML d�finie en �dition).
		tabClasses.push("padding");
		tabClasses.push(sClasses);
		return true;
	}
	else
	{
		return false;
	}
};

//////////////////////////////////////////////////////////////////////////
// Manipulation du HTML

// Gestion des �v�nements qui doivent bloquer le d�filement
WDVueAPBase.prototype.__DansDefilement = function __DansDefilement(oObjet, pfMethode, tabArguments)
{
	try
	{
		var bDansGetDefilement = this.m_bDansGetDefilement;
		this.m_bDansGetDefilement = true;
		return pfMethode.apply(oObjet, tabArguments);
	}
	finally
	{
		this.m_bDansGetDefilement = bDansGetDefilement;
	}

};

WDVueAPBase.prototype.__nGetClientOuScroll = function __nGetClientOuScroll(oElement, sValeur)
{
	// La consultation des clientXxx/scrollXxx declenche un appel de onscroll
	return this.__DansDefilement(this, this.__nGetClientOuScrollInterne, [oElement, sValeur]);
};
WDVueAPBase.prototype.__nGetClientOuScrollInterne = function __nGetClientOuScrollInterne(oElement, sValeur)
{
	return oElement[sValeur];
};

WDVueAPBase.prototype.__nGetClientWidth = function __nGetClientWidth(oElement)
{
	return this.__nGetClientOuScroll(oElement, "clientWidth");
};
WDVueAPBase.prototype.__nGetClientHeight = function __nGetClientHeight(oElement)
{
	return this.__nGetClientOuScroll(oElement, "clientHeight");
};

// Recupere la largeur totale de la zone cible
WDVueAPBase.prototype.__nGetLargeur = function __nGetLargeur()
{
	return this.__nGetClientWidth(this.m_oHote);
};

// Recupere la hauteur totale de la zone cible
WDVueAPBase.prototype.__nGetHauteur = function __nGetHauteur()
{
	// La consultation des clientXxx/scrollXxx declenche un appel de onscroll
	return this.__DansDefilement(this.m_oChampAP, this.m_oChampAP._nGetOffsetHeight, [this.m_oHote]);
};

// Retourne la largeur d'un conteneur
WDVueAPBase.prototype._nGetDimensionLateralePxConteneur = function _nGetDimensionLateralePxConteneur(oParametres)
{
	// C'est la place totale divis�e par le nombre de conteneur
	var nNbConteneurs = this.m_oChampAP._nGetNbConteneurs(false);
	if (nNbConteneurs <= 0)
	{
		return oParametres.m_nDimensionLateralePxConteneurMin;
	}
	else if (undefined !== oParametres.m_nDimensionLateralePxRessource)
	{
		// ..LargeurRessrouce/..HauteurRessource : si on force la dimension des conteneurs par programmation.
		return oParametres.m_nDimensionLateralePxRessource;
	}
	else
	{
		// GP 10/11/2012 : Chrome (vu par le TDF) a partir de la version 23 affiche un ascenseur abusif
		// En fait ici la valeur n'est pas enti�re. Sauf que pour les table chrome arrondi la valeur � la valeur sup�rieure
		// mais il ne le fait pas pour les div. Donc le tendez-vous qui a un div puis une table avec des largeurs/hauteurs cor�ll�es
		// ne s'affiche plus bien (ascenseur) si la valeur n'est pas enti�re car la table est affich�e avec un pixel de plus.
		// GP 24/10/2014 : TB88960 + Remarque de APL : ici en fait, si le calcul tombe juste, on a un ascenseur en HTML5 (!!!)
		// Tous est a la bonne largeur sauf le scrollWidth qui prend 1 pixels mais je ne sais pas d'ou
		// Donc ajout d'un -1 pour �tre sur de n'est
		return Math.max(Math.floor((this._vnDimensionLateralePxCorps() - 1) / nNbConteneurs), oParametres.m_nDimensionLateralePxConteneurMin);
	}
};


// Defilement de la zone cliente
WDVueAPBase.prototype._nGetDefilementVertical = function _nGetDefilementVertical()
{
	return this.__nGetClientOuScroll(this.m_oHoteCorps, "scrollTop");
};
WDVueAPBase.prototype._nGetDefilementHorizontal = function _nGetDefilementHorizontal()
{
	return this.__nGetClientOuScroll(this.m_oHoteCorps, "scrollLeft");
};
WDVueAPBase.prototype._SetDefilementVertical = function _SetDefilementVertical(nDefilement)
{
	(this.m_oHoteCorps.scrollTop = nDefilement);
};
WDVueAPBase.prototype._SetDefilementHorizontal = function _SetDefilementHorizontal(nDefilement)
{
	(this.m_oHoteCorps.scrollLeft = nDefilement);
};

//////////////////////////////////////////////////////////////////////////
// Styles

// Cree le selecteur pour une classe
WDVueAPBase.prototype.__sGetSelecteurClass = function __sGetSelecteurClass(sClasse)
{
	return ((":" == sClasse.charAt(0)) ? "" : ".") + sClasse;
};
WDVueAPBase.prototype.__sGetSelecteur = function __sGetSelecteur(sClasse1, sTag, sClasse2)
{
	var tabSelecteur = [];
	tabSelecteur.push("#" + this.__sGetNomElement(this.m_oChampAP.ms_sSuffixeHote));
	if (sClasse1 !== undefined)
	{
		tabSelecteur.push(this.__sGetSelecteurClass(sClasse1));
	}
	if (sClasse2 !== undefined)
	{
		tabSelecteur.push(sTag + this.__sGetSelecteurClass(sClasse2));
	}
	// Inutile de tester .length : "" s'�value a faux et "<Contenu>" s'�value � vrai.
	else if (sTag)
	{
		tabSelecteur.push(sTag);
	}
	return tabSelecteur.join(' ');
};

// Creation d'un style pour tout les champs planning
WDVueAPBase.prototype.__StyleCreeGlobal = function __StyleCreeGlobal(sNomStyle, tabStyle)
{
	clWDUtil.CreeStyle(this.ms_oFeuilleStyleGlobale, sNomStyle, tabStyle.join(';'));
};

// Creation ou modification d'un style pour le champ courant
WDVueAPBase.prototype.__StyleCree = function __StyleCree(sNomStyle, tabStyle)
{
	this.m_oStyle.Ajoute(sNomStyle, tabStyle);
};

// Complete un style
WDVueAPBase.prototype.__StyleComplete = function __StyleComplete(sNomStyle, tabStyle)
{
	this.m_oStyle.Complete(sNomStyle, tabStyle);
};

// Supprime un style
WDVueAPBase.prototype.__StyleSupprime = function __StyleSupprime(sNomStyle)
{
	this.m_oStyle.Supprime(sNomStyle);
};

//////////////////////////////////////////////////////////////////////////
// Dimensions

// Conversion d'une duree (ms) en dimension (px)
WDVueAPBase.prototype.__nGetDimensionPxDepuisDureeMs = function __nGetDimensionPxDepuisDureeMs(oParametres, nDureeMs)
{
	return nDureeMs * this.vnGetDimensionPxGraduation(oParametres) / this.m_nGraduationDureeMs;
};

// Calcule la position en pixel du debut d'un rendez-vous
WDVueAPBase.prototype._vnGetDebutRendezVous = function _vnGetDebutRendezVous(oParametres, oRendezVous, nDate, nDateReference)
{
	return this.__nGetDimensionPxDepuisDifferenceDate(oParametres, nDate, nDateReference, true);
};
// Calcule la position en pixel du debut d'un rendez-vous en mode "TitreSeul" (tous les rendez-vous de l'agenda)
WDVueAPBase.prototype._vnGetDebutRendezVousTitreSeul = function _vnGetDebutRendezVousTitreSeul(oParametres, oSuperpositionInfo/*, nDate*//*, nDateReference*/)
{
	// Si on est ici c'est que l'on est pour le mode rendez-vous � la journ�e
	var nDimensionPxVerticale = oParametres.m_nHauteurZoneJourneeComplete;

	return this._nGetHautRendezVousTitreSeul(oParametres, oSuperpositionInfo, 0, 0, nDimensionPxVerticale);
};

// Calcule la position en pixel du debut d'un rendez-vous en mode "TitreSeul"
// Calcule la position en pixel du debut d'un rendez-vous dont on affiche que le titre (il est alors forc�ment positionn� verticalement
WDVueAPBase.prototype._nGetHautRendezVousTitreSeul = function _nGetHautRendezVousTitreSeul(oParametres, oSuperpositionInfo, nDebutDansConteneur, nEspaceReserve, nDimensionPxVerticale)
{
	// - La zone disponible dans le jour pour les rendez-vous
	var nDimensionPxVerticaleDisponible = Math.max(nDimensionPxVerticale - nEspaceReserve, 0);
	// - Calcule le pas des rendez-vous
	var nDimensionPxVerticaleRendezVous = this._nGetHauteurRendezVousTitreSeul(oParametres);
	// Par d�faut c'est la longueur des rendez-vous sauf si on n'a pas la place
	var nPasRendezVous = 0;
	if (1 < oSuperpositionInfo.m_nNbSuperpositions)
	{
		nPasRendezVous = Math.min(nDimensionPxVerticaleRendezVous, Math.floor((nDimensionPxVerticaleDisponible - nDimensionPxVerticaleRendezVous) / (oSuperpositionInfo.m_nNbSuperpositions - 1)));
	}
	return nDebutDansConteneur + nEspaceReserve + oSuperpositionInfo.m_nSuperposition * nPasRendezVous;
};

// La hauteur d'un rendez-vous dont on affiche uniquement le titre
WDVueAPBase.prototype._nGetHauteurRendezVousTitreSeul = function _nGetHauteurRendezVousTitreSeul(/*oParametres*/)
{
	// => @@@ On n'a aucun moyen de la calculer
	// GP 14/02/2013 : QW229682 : Avec le style par d�faut 25 n'est pas assez (il faut 26)
	return 26;
};

// Calcule la position en pixel d'une date donnee par rapport a une autre
// nDate doit etre une date dans la plage valide
// bDepuisDebut : indique que l'on compare a la date de debut. il faut le savoir car on a alors une rupture de plus (la premiere)
// mais elle n'apparait pas dans le calcul de nOffsetJour
WDVueAPBase.prototype.__nGetDimensionPxDepuisDifferenceDate = function __nGetDimensionPxDepuisDifferenceDate(oParametres, nDate, nDateReference, bDepuisDebut)
{
	// Calcule la duree depuis le debut de l'affichage
	var nOffsetMs = nDate - nDateReference;

	// Corrige pour les zones non affichees
	// => Commence par corriger en nombres de jours
	var nOffsetJour = Math.floor((nDate - nDateReference) / 86400000);
	// Si est sur deux jour
	var nHeureJourReference = clWDUtil.nGetHeureJour(nDateReference);
	var nHeureJour = clWDUtil.nGetHeureJour(nDate);
	if (nHeureJour < nHeureJourReference)
	{
		nOffsetJour++;
	}
	// Si on est en affichage par journee ou demi-journee :
	// oParametres.m_nHeureAfficheMin contient deja 0
	// oParametres.m_nHeureAfficheMax contient deja 86400000
	// => ce qui revient a ne rien faire
	nOffsetMs -= nOffsetJour * (oParametres.m_nHeureAfficheMin + 86400000 - oParametres.m_nHeureAfficheMax);
	nDateReference += nOffsetJour * 86400000;
	// => Puis corrige pour le dernier jour
	if (nHeureJourReference < oParametres.m_nHeureAfficheMin)
	{
		nOffsetMs -= oParametres.m_nHeureAfficheMin - nHeureJourReference;
		nOffsetJour--;
	}
	else if (nHeureJourReference >= oParametres.m_nHeureAfficheMax)
	{
		nOffsetMs -= oParametres.m_nHeureAfficheMin + nHeureJourReference - oParametres.m_nHeureAfficheMax;
		nOffsetJour--;
	}

	// Et retourne la valeur selon la dimension d'une heure
	var nDimensionPx = this.__nGetDimensionPxDepuisDureeMs(oParametres, nOffsetMs);
	// Compense pour les ruptures
	// Les ruptures n'existent que pour le mode avec les ressources en colonne.
	// Donc dans le cas avec les ressources en ligne nHauteurRuptureJour contient 0 et on n'entre pas dans le test : ce qui est correct
	var nHauteurRuptureJour = this._vnGetHauteurRuptureJour(oParametres);
	if (nHauteurRuptureJour)
	{
		nDimensionPx += (nOffsetJour + (bDepuisDebut ? 1 : 0)) * nHauteurRuptureJour;
	}
	return nDimensionPx;
};

WDVueAPBase.prototype.vnGetDimensionPxGraduation = function vnGetDimensionPxGraduation(oParametres)
{
	return oParametres.m_nDimensionPxGraduation;
};

WDVueAPBase.prototype.voGetDateFinAffichage = function voGetDateFinAffichage(oParametres)
{
	return oParametres.m_oDateFin;
};

// Recupere la dimension laterale d'un element (hauteur de ligne dans le cas en ligne et largeur de colonne dans le cas en colonne)
WDVueAPBase.prototype.__nGetDimensionPxSansBordure = function __nGetDimensionPxSansBordure(nDimensionPx, oStyle)
{
	if (0 < oStyle.m_nBordureV)
	{
		// - * 1 et pas - * 2 pour firefox et ie
		return nDimensionPx - (bIEQuirks9Max ? 0 : oStyle.m_nBordureV);
	}
	return nDimensionPx;
};

// GP 06/11/2018 : QW304791 : Passage en "box-sizing: border-box" pour les titres verticaux sur les navigateurs modernes.
if (clWDUtil.bHTML5 && !bIEAvec11)
{
	// Recupere la dimension laterale d'un element (hauteur de ligne dans le cas en ligne et largeur de colonne dans le cas en colonne) pour un titre.
	// Maintenant, pour les navigateurs modernes, on g�n�re les titres en box-sizing: border-box, pour ne pas avoir de probl�mes avec l'�paisseur des traits en mode zoom.
	// Note : il faudrait faire plus de box-sizing: border-box mais chaque chose en son temps.
	WDVueAPBase.prototype.__nGetDimensionPxSansBordureTitresVerticaux = function (nDimensionPx) { return nDimensionPx; };
	WDVueAPBase.prototype.ms_tabStyleBoxSizingTitresVerticaux = ["box-sizing:border-box"];
	WDVueAPBase.prototype.ms_nPaddingTitresVerticaux = 0;
}
else
{
	WDVueAPBase.prototype.__nGetDimensionPxSansBordureTitresVerticaux = WDVueAPBase.prototype.__nGetDimensionPxSansBordure;
	WDVueAPBase.prototype.ms_tabStyleBoxSizingTitresVerticaux = [];
	WDVueAPBase.prototype.ms_nPaddingTitresVerticaux = WDVueAPBase.prototype.ms_nPaddingTitreCalcul;
}

// Recupere la dimension laterale des ressources (hauteur de ligne dans le cas en ligne et largeur de colonne dans le cas en colonne)
WDVueAPBase.prototype.__nGetDimensionPxSansBordureConteneur = function __nGetDimensionPxSansBordureConteneur(oParametres, bPremierConteneur)
{
	var nDimensionPx = this.__nGetDimensionPxSansBordure(this._nGetDimensionLateralePxConteneur(oParametres), oParametres.m_oStyleNormal);
	if (bPremierConteneur)
	{
		return this.__nGetDimensionPxSansBordure(nDimensionPx, this._voGetStyleTitreSecondaireDernier(oParametres));
	}
	else
	{
		return nDimensionPx;
	}
};

// Nombre de graduations en parallele (= sur la m�me ligne/colonne)
WDVueAPBase.prototype._vnGetNbGraduationsParalleles = function _vnGetNbGraduationsParalleles(/*oParametres*/)
{
	// Une seule par d�faut (prend la largeur totale)
	return 1;
};

// Dimension (lat�rale) totale des graduations
WDVueAPBase.prototype.__nGetDimensionLateralePxToutesGraduations = function __nGetDimensionLateralePxToutesGraduations(oParametres)
{
	// Comme on a une seule gradution : prend la largeur totale
	return this.m_oChampAP._nGetNbConteneurs(false) * this._nGetDimensionLateralePxConteneur(oParametres);
};
// Dimension (lat�rale) d'une graduation
WDVueAPBase.prototype._vnGetDimensionLateralePxGraduation = WDVueAPBase.prototype.__nGetDimensionLateralePxToutesGraduations;

// Hauteur de la ligne des titres horizontaux
WDVueAPBase.prototype._vnGetHauteurTitresHorizontaux = function _vnGetHauteurTitresHorizontaux(oParametres, nNbLignes)
{
	return Math.floor(oParametres.m_nHauteurTitresHorizontal / nNbLignes);
};

// Si on affiche seulement le titre du rendez-vous
WDVueAPBase.prototype._vbJourneeEntiere = function _vbJourneeEntiere(oParametres, bJourneeEntiere)
{
	// G�n�ralement : seul les rendez-vous � la journ�e enti�re sont affich�s sous la forme d'un titre seul (si l'affichage � la journ�e enti�re est activ�)
	return bJourneeEntiere && !!oParametres.m_nHauteurZoneJourneeComplete;
};
WDVueAPBase.prototype._bRendezVousTitreSeul = function _bRendezVousTitreSeul(oParametres, oRendezVous)
{
	// G�n�ralement : seul les rendez-vous � la journ�e enti�re sont affich�s sous la forme d'un titre seul (si l'affichage � la journ�e enti�re est activ�)
	return this._vbJourneeEntiere(oParametres, oRendezVous.m_bJourneeEntiere);
};
WDVueAPBase.prototype._bRendezVousTitreSeulSaufSiSansTitre = function _bRendezVousTitreSeulSaufSiSansTitre(oParametres, oRendezVous)
{
	// GP 28/10/2014 : QW250694 : Si on est en mode sans titre et que l'on ne doit afficher que le titre, on n'affiche pas que le titre sinon on n'affiche rien.
	// GP 10/11/2014 : QW251411 : Pour le cas PHP traite m_bAfficherTitreRendezVous absent comme un true
	return this._bRendezVousTitreSeul(oParametres, oRendezVous) && (false !== oParametres.m_bAfficherTitreRendezVous);
};
// Si un rendez-vous est redimensionnable
WDVueAPBase.prototype.bUnRendezVousRedimensionnable = function bUnRendezVousRedimensionnable(oParametres, oRendezVous)
{
	// Redimensionnable si :
	// - On autorise le redimensionnement
	// - Le rendezvous n'est pas affich�e sous la forme d'un titre seul (rendez-vous � la journ�e ou agenda au mois)
	// GP 21/11/2016 : QW278487 : S�pare le flag bActif des autres options
	return oParametres.m_bRedimensionnementRendezVous && oParametres.m_bActif && (!this._bRendezVousTitreSeul(oParametres, oRendezVous));
};

// Hauteur de la rupture des jours
WDVueAPBase.prototype._vnGetHauteurRuptureJour = function _vnGetHauteurRuptureJour(/*oParametres*/)
{
	// Par d�faut aucune
	return 0;
};

// Si on affiche toutes les heures : non par d�faut
WDVueAPBase.prototype._vbAfficheTouteslesHeures = function _vbAfficheTouteslesHeures(/*oParametres*/)
{
	return false;
};

//////////////////////////////////////////////////////////////////////////
// Evenements

// Demande de d�filement � la molette dans la zone de titre vertical (et dans les ruptures de jours qui d�bordent dans les planning verticaux)
// GP 12/12/2012 : Le code de d�claration est a factoriser avec WDTable.prototype.InitForceDefilement et WDTable.prototype.__bForceDefilement
WDVueAPBase.prototype.__OnDefilementCorpsMolette = function __OnDefilementCorpsMolette(oEvent)
{
	var nDeplacement;
	if (oEvent.wheelDelta)
	{
		// IE
		nDeplacement = -oEvent.wheelDelta * 2 / 3;
	}
	else
	{
		// Firefox
		nDeplacement = (oEvent.detail ? oEvent.detail : 0) * 20;
	}

	this.m_oHoteCorps.scrollTop += nDeplacement;
};

WDVueAPBase.prototype.__OnDefilementTouchTitre = function __OnDefilementTouchTitre(nOffsetX, nOffsetY/*, oEvent*/)
{
	this.m_oHoteCorps.scrollLeft += nOffsetX;
	this.m_oHoteCorps.scrollTop += nOffsetY;
};

// Defilement de la zone d'affichage
WDVueAPBase.prototype.__OnDefilementCorps = function __OnDefilementCorps(/*oEvent*/)
{
	// La consultation des scrollXxx declenche un appel de onscroll
	if (this.m_bDansGetDefilement)
	{
		return;
	}

	return this.__DansDefilement(this, this.__OnDefilementCorpsInterne, arguments);
};
WDVueAPBase.prototype.__OnDefilementCorpsInterne = function __OnDefilementCorpsInterne(/*oEvent*/)
{
	var oParametres = this.m_oChampAP.m_oParametres;

	//	var nLargeurCorps = this.__nGetClientWidth(this.m_oHoteCorps);
	//	var nHauteurCorps = this.__nGetClientHeight(this.m_oHoteCorps);
	//	var nLargeurCorps = this.m_nLargeurCorps;
	//	var nHauteurCorps = this.m_nHauteurCorps;
	var nDefilementHorizontal = this._nGetDefilementHorizontal();
	var nDefilementVertical = this._nGetDefilementVertical();

	// Inutile : on change le style sur le resize
	// Ajoute la largeur de la zone des titres
	if (this.m_nLargeurClientCorps != this.__nGetClientWidth(this.m_oHoteTitresHorizontal))
	{
		this.m_oHoteTitresHorizontal.style.width = this.m_nLargeurClientCorps + "px";
	}

	// Synchronise les scrolls
	if (nDefilementHorizontal != this.m_oHoteTitresHorizontal.scrollLeft)
	{
		this.m_oHoteTitresHorizontal.scrollLeft = nDefilementHorizontal;
	}

	if (this.m_oHoteTitresVertical)
	{
		// Inutile : on change le style sur le resize
		// Ajoute la largeur de la zone des titres
		var nClientHeightTitresVertical = this.__nGetClientHeight(this.m_oHoteTitresVertical);
		if (this.m_nHauteurClientCorps != nClientHeightTitresVertical)
		{
			this.m_oHoteTitresVertical.style.height = this.m_nHauteurClientCorps + "px";
		}

		// Synchronise les scrolls
		// Le dessin avec clipping ne marche pas dans IE en mode quirks, on fait l'ancien mode avec overflow-x/overflow-y
		if (bIEQuirks9Max)
		{
			if (nDefilementVertical != this.m_oHoteTitresVertical.scrollTop)
			{
				this.m_oHoteTitresVertical.scrollTop = nDefilementVertical;
			}
		}
		// GP 27/05/2013 : TB78526 : Uniquement si le champ est dessin� (si on est en recr�ation ici le fils n'existe pas)
		else if (this.m_oHoteTitresVertical.firstChild)
		{
			if (nDefilementVertical != -parseInt(clWDUtil.oGetCurrentStyle(this.m_oHoteTitresVertical.firstChild).top, 10))
			{
				var nPositionVerticale = -nDefilementVertical;
				nPositionVerticale += oParametres.m_nHauteurTitresHorizontal;
				// GP 25/03/2013 : QW231379
				if (this.ms_bZoneTitreSeulIndependanteExterne)
				{
					nPositionVerticale += this._vnGetHauteurZoneTitreSeulIndependante(oParametres);
				}
				this.m_oHoteTitresVertical.firstChild.style.top = nPositionVerticale + "px";
				this.m_oHoteTitresVertical.firstChild.style.clip = "rect(" + nDefilementVertical + "px, auto, " + (nDefilementVertical + this.m_nHauteurClientCorps) + "px, auto)";
			}
		}
	}

	// GP 18/11/2013 : Mauvaise correction de QW237036 a tester et r�activer un jour (case le redimensionnement)
	// GP 14/10/2013 : QW237036 : Si on est en redimensionnement, il ne fait pas faire le calcul sinon on �crase this.m_nDefilementPrincipal
	if (1 < this.m_oHoteCorps.offsetHeight)
	{
		var nDefilementPrincipalOld = this.m_nDefilementPrincipal;
		var nDefilementPrincipalNew = this._vnGetDefilementPrincipal();
		var nDefilementLateralNew = this._vnGetDefilementLateral();

		// Memorise la position pour le serveur dans le champ formulaire la selection
		if (nDefilementPrincipalOld != nDefilementPrincipalNew)
		{
			this.m_nDefilementPrincipal = nDefilementPrincipalNew;
			this.m_oChampAP.ConstruitParam();
		}
		// Memorise la position pour le cas d'un reaffichage (mais on ne l'envoi pas au serveur)
		(this.m_nDefilementLateral = nDefilementLateralNew);
	}
	else if (this.m_nQW237036Max <= this.m_nQW237036++)
	{
		(this.m_oHoteTitresHorizontal.style.width = "1px");
		if (this.m_oHoteTitresVertical)
		{
			(this.m_oHoteTitresVertical.style.height = "1px");
		}
	}

	// Deplace le bouton de suppression (parente au parent du corps pour ne pas etre coupe par l'overflow
	this.__HTMLPlaceRendezVousSuppressionAutonome(oParametres);

	// Sur le defilement du corps
	this._vOnDefilementCorps(oParametres, nDefilementHorizontal, nDefilementVertical);
};

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// Vue verticale
function WDVueAPVerticale (/*oChampAP*//*, oVuePrecedente*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDVueAPBase.prototype.constructor.apply(this, arguments);
	}
}

// Declare l'heritage
WDVueAPVerticale.prototype = new WDVueAPBase();
// Surcharge le constructeur qui a ete efface
WDVueAPVerticale.prototype.constructor = WDVueAPVerticale;

//////////////////////////////////////////////////////////////////////////
// Constantes specifiques

// Classes
WDVueAPVerticale.prototype.ms_sNomFondRupture = "WDPLN-FondRupture";
// Paddings
WDVueAPVerticale.prototype.ms_nPaddingLibJour = 3;
// Indique la position des titres de ressources et d'heures
WDVueAPVerticale.prototype.ms_sNomGeneralSpecifique = "WDPLN-ZoneGeneralVertical";
//WDVueAPVerticale.prototype.ms_sTitresHeuresPosition = WDVueAPBase.prototype.ms_sNomTitresVertical;
// Indique le sens de la fusion des colonnes
WDVueAPVerticale.prototype.ms_bTableTrParRessource = false;
// Et les dimension
//WDVueAPVerticale.prototype.ms_sStyleDebut = "top";
WDVueAPVerticale.prototype.ms_sStyleDimension = "height";
WDVueAPVerticale.prototype.ms_sStyleDebutLateral = "left";
WDVueAPVerticale.prototype.ms_sStyleDimensionLaterale = "width";
WDVueAPVerticale.prototype.ms_sCurseurRedim = "N-resize";


//////////////////////////////////////////////////////////////////////////
// Methodes virtuelles

// Methode d'initialisation generale de la classe (ne s'execute que lors de l'init de la premi�re instance de ce type)
WDVueAPVerticale.prototype._vInitInitiale = function _vInitInitiale()
{
	// Appel de la methode de la classe de base
	WDVueAPBase.prototype._vInitInitiale.apply(this, arguments);

	var sPrefixeSpecifique = "." + this.ms_sNomGeneralSpecifique + " ";

	// Regles specifiques (la table des regles a ete cree par WDVueAPBase::_vInitInitiale)
	// - Corps
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomCorps, ["overflow-x:auto", "overflow-y:scroll", "position:relative"]);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "td." + this.ms_sNomCorpsQuadrillage, ["height:0px"]);
	// - Rendez-vous
	var nPaddingRight = this._vnGetPaddingRightPourRendezVous() + this.ms_nPaddingRendezVous;
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousRepetition, ["position:absolute", "top:" + this.ms_nPaddingRendezVous + "px", "right:" + nPaddingRight + "px"]);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousImportance, ["position:absolute", "bottom:" + this.ms_nPaddingRendezVous + "px", "right:" + nPaddingRight + "px"]);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousRedimDebutBefore, ["top:0", "left:0", "height:5px", "width:100%"]);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousRedimFinAfter, ["bottom:0", "left:0", "height:5px", "width:100%"]);
	if (bIEQuirks9Max)
	{
		this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousExterne, ["padding-left:" + this.ms_nPaddingLateralDebut + "px", "padding-right:" + this.ms_nPaddingLateralFin + "px"]);
	}
	// - Rupture des jours
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomFondRupture, ["z-index:" + this.ms_nZIndexFondRupture, "position:relative"]);
	// - Libelle des heures : aligne a droite par defaut
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomTitresSecondaires, ["text-align:right"]);
	// Le dessin avec clipping ne marche pas dans IE en mode quirks, on fait l'ancien mode avec overflow-x/overflow-y
	var tabStyle = ["z-index:" + this.ms_nZIndexFondRupture, "overflow:hidden", "padding-left:" + this.ms_nPaddingLibJour + "px", "padding-right:" + this.ms_nPaddingLibJour + "px"];
	if (bIEQuirks9Max)
	{
		tabStyle.push("position:absolute");
		tabStyle.push("left:0px");
		tabStyle.push("top:0px");
	}
	else
	{
		tabStyle.push("position:relative");
	}
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomFondRupture + " ." + this.ms_sNomJour, tabStyle);
	// Le left:0px ne sert a rien :
	// - C'est la position normale des elements
	// - Cela gene le float des elements
	// Le position:relative : ne sert que si on a des demi heures
	// En revanche on ajoute le float:left pour le cas de la vue au mois des agendas
//	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomHeure, ["position:relative", "left:0px"]);
	tabStyle = ["position:relative", "float:left"];
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomHeure, tabStyle);
	// GP 12/12/2012 : QW227768 : Il faut correctement positionner l'espacement des jours
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomCorpsQuadrillage + " ." + this.ms_sNomJour, tabStyle);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomCorpsQuadrillage + " ." + this.ms_sNomJourneeComplete, tabStyle);

	// S'auto efface pour ne plus etre appele
	WDVueAPVerticale.prototype._vInitInitiale = clWDUtil.m_pfVide;
};

// Touve le conteneur des rendez-vous d'une ressource
WDVueAPVerticale.prototype._vnGetHauteurZoneTitreSeulIndependante = function _vnGetHauteurZoneTitreSeulIndependante(/*oParametres*/)
{
	return 0;
};

// Fixe le debut dans le sens principal : left (ressources en ligne) ou top (ressources en colonne)
WDVueAPVerticale.prototype.vSetDebut = WDChamp.prototype.s_SetStyleTop;
// Fixe la longueur dans le sens principal : width (ressources en ligne) ou height (ressources en colonne)
WDVueAPVerticale.prototype.vSetLongueur = WDChamp.prototype.s_SetStyleHeight;
// Fixe le debut lateral : top (ressources en ligne) ou left (ressources en colonne)
WDVueAPVerticale.prototype.vSetDebutLateral = WDChamp.prototype.s_SetStyleLeft;
// Fixe la dimension laterale :
// - Quirk : Longueur : height (ressources en ligne) ou width (ressources en colonne)
// - Autres : Fin : bottom (ressources en ligne) ou right (ressources en colonne)
WDVueAPVerticale.prototype.vSetLongueurLateral = (bIEQuirks9Max ? WDChamp.prototype.s_SetStyleWidth : WDChamp.prototype.s_SetStyleRight);

// Initialisation des titres
WDVueAPVerticale.prototype._vInitCSS_TitresConteneurs = function _vInitCSS_TitresConteneurs(oParametres)
{
	return this.__InitCSS_TitresHorizontaux(oParametres, true);
};
WDVueAPVerticale.prototype._vInitCSS_TitresHeures = function _vInitCSS_TitresHeures(oParametres)
{
	return this.__InitCSS_TitresVerticaux(oParametres, false);
};
WDVueAPVerticale.prototype._vInitCSS_TitresHeuresAgenda = clWDUtil.m_pfVide;

// Initialisation du style des libelle des jours
WDVueAPVerticale.prototype._vInitCSS_LibJour = function _vInitCSS_LibJour(oParametres)
{
	var oStyle;
	var nOffsetBordure;
	// Style general : hauteur d'une rupture de jour
	if (oParametres.m_nHauteurLibJour)
	{
		// GP 17/01/2013 : Ici on est bien dans l'affichage de la ligne des jours donc on conserve oParametres.m_oStyleLibJourSemaine
		oStyle = oParametres.m_oStyleLibJourSemaine;

		// Le dessin avec clipping ne marche pas dans IE en mode quirks, on fait l'ancien mode avec overflow-x/overflow-y
		if (bIEQuirks9Max)
		{
			this.__StyleCree(this.__sGetSelecteur(undefined, "", this.ms_sNomTitresVertical), ["overflow-x:visible"]);
		}
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomTitresVertical, "div", this.ms_sNomFondRupture), ["overflow:visible", "padding:0px"]);

		var tabStyle = [];
		// Si on a une couleur de fond : normalement oui
		if (oStyle.m_cFond)
		{
			tabStyle.push("background-color:" + oStyle.m_cFond);
		}
		// Il faudrait prendre la largeur effective (this.__nGetLargeur()) du champ et pas la largeur des ressource
		nOffsetBordure = this._nGetOffsetBordure(oStyle, 2);
		this.m_nLargeurLibJour = this.__nGetLargeurLibJour(oParametres, nOffsetBordure);
		var nHauteur = oParametres.m_nHauteurLibJour + nOffsetBordure;
		if (0 < oStyle.m_nBordureV)
		{
			var nBordure = oStyle.m_nBordureV;
			var oBordureCouleur = oStyle.m_cBordureV;
			tabStyle.push("border:solid " + nBordure + "px " + oBordureCouleur);
		}
		tabStyle.push("height:" + nHauteur + "px");
		tabStyle.push("width:" + this.m_nLargeurLibJour + "px");
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomTitresVertical, "", this.ms_sNomJour), tabStyle);

		// - Espace pour la rupture des jours dans le corps (ils n'ont pas de bordures)
		// GP 12/12/2012 : QW227768 : Il faut le positionnement, le float et une largeur
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomCorps, "", this.ms_sNomJour), ["height:" + oParametres.m_nHauteurLibJour + "px", "width:" + this.__nGetLargeurLibJour(oParametres, nOffsetBordure, true) + "px"]);
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomTitresVertical, "td", this.ms_sNomFondRupture), ["height:" + oParametres.m_nHauteurLibJour + "px"]);
	}
	// Style g�n�ral : fond de la zone des rendez-vous � la journ�e compl�te
	if (oParametres.m_nHauteurZoneJourneeComplete)
	{
		oStyle = oParametres.m_oStyleJourneeComplete;

		var nLargeur = this.ms_bZoneTitreSeulIndependanteExterne ? this._vnGetDimensionLateralePxGraduation(oParametres) : this.m_nLargeurClientCorps;
		// Si on a une couleur de fond
		if (oStyle.m_cFond)
		{
			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomFondCouleur, " ", this.ms_sNomJourneeComplete), ["background-color:" + oStyle.m_cFond, "width:" + nLargeur + "px", "height:" + oParametres.m_nHauteurZoneJourneeComplete + "px", "float:left"]);
		}
		if (0 < oStyle.m_nBordureV)
		{
			nOffsetBordure = this._nGetOffsetBordure(oStyle, 2);
			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomFondBordure, " ", this.ms_sNomJourneeComplete), ["border:solid " + oStyle.m_nBordureV + "px " + oStyle.m_cBordureV, "width:" + (nLargeur + nOffsetBordure) + "px", "height:" + (oParametres.m_nHauteurZoneJourneeComplete + nOffsetBordure) + "px", "float:left"]);
		}
		// GP 27/03/2013 : QW231482 : Il fau tenir compte de la bordure du haut.
		this.__StyleCree(this.__sGetSelecteur(this.ms_sNomTitresVertical, " ", this.ms_sNomJourneeComplete), ["height:" + (oParametres.m_nHauteurZoneJourneeComplete + this._nGetOffsetBordure(oStyle, 1)) + "px"]);
	}
};

// Sur le defilement du corps
WDVueAPVerticale.prototype._vOnDefilementCorps = function _vOnDefilementCorps(oParametres/*, nDefilementHorizontal*//*, nDefilementVertical*/)
{
	if (oParametres.m_nHauteurLibJour || oParametres.m_nHauteurZoneJourneeComplete)
	{
		// Change la largeur si besoin
		var nLargeurLibJour = this.__nGetLargeurLibJour(oParametres, this._nGetOffsetBordure(oParametres.m_oStyleLibJourSemaine, 2));
		if (nLargeurLibJour != this.m_nLargeurLibJour)
		{
			this.m_nLargeurLibJour = nLargeurLibJour;
			this.m_oStyle.CreationAjout();
			// Si on doit afficher les ruptures de jour
			if (oParametres.m_nHauteurLibJour)
			{
				this.__StyleComplete(this.__sGetSelecteur(this.ms_sNomTitresVertical, "", this.ms_sNomJour), ["width:" + nLargeurLibJour + "px"]);
			}
			if (oParametres.m_nHauteurZoneJourneeComplete)
			{
				var nLargeur = this.ms_bZoneTitreSeulIndependanteExterne ? this._vnGetDimensionLateralePxGraduation(oParametres) : this.m_nLargeurClientCorps;
				var oStyle = oParametres.m_oStyleJourneeComplete;
				if (oStyle.m_cFond)
				{
					this.__StyleComplete(this.__sGetSelecteur(this.ms_sNomFondCouleur, " ", this.ms_sNomJourneeComplete), ["width:" + nLargeur + "px", "height:" + oParametres.m_nHauteurZoneJourneeComplete + "px"]);
				}
				if (0 < oStyle.m_nBordureV)
				{
					var nOffsetBordure = this._nGetOffsetBordure(oStyle, 2);
					// GP 25/03/2013 : QW231389 : utilisation de __StyleComplete au lieu de __StyleCree
					this.__StyleComplete(this.__sGetSelecteur(this.ms_sNomFondBordure, " ", this.ms_sNomJourneeComplete), ["width:" + (nLargeur + nOffsetBordure) + "px", "height:" + (oParametres.m_nHauteurZoneJourneeComplete + nOffsetBordure) + "px", "float:left"]);
				}
			}
			this.m_oStyle.CreationFin();
		}
	}
};

// Construit le stype pour une dimension sans le sens principale (largeur (ressources en lignes), hauteur (ressources en colonnes))
WDVueAPVerticale.prototype._vtabInitCSS_DimensionPxPrincipale = WDVueAPBase.prototype._tabInitCSS_DimensionHauteur;
// Construit le stype pour une dimension laterale (hauteur (ressources en lignes), largeur (ressources en colonnes))
WDVueAPVerticale.prototype._vtabInitCSS_DimensionPxLaterale = WDVueAPBase.prototype._tabInitCSS_DimensionLargeur;

// Construit le style pour les bordures dans le sens perpendiculaire au defilement principal (gauche/droite (ressources en lignes), haut/bas (ressources en colonnes))
WDVueAPVerticale.prototype._vtabInitCSS_BorduresPerpendiculaires = WDVueAPBase.prototype._tabInitCSS_BorduresHautBas;
// Construit le style pour les bordures dans le sens du defilement principal (haut/bas (ressources en lignes), droite/gauche (ressources en colonnes))
WDVueAPVerticale.prototype._vtabInitCSS_BorduresLaterales = WDVueAPBase.prototype._tabInitCSS_BorduresGaucheDroite;

WDVueAPVerticale.prototype._vnGetDimensionClienteLaterale = WDVueAPBase.prototype.__nGetLargeur;

WDVueAPVerticale.prototype._vnDimensionLateralePxCorps = function _vnDimensionLateralePxCorps(/*oParametres*/)
{
//	return this.m_nLargeurCorps;
	return this.m_nLargeurClientCorps;
};

// Hauteur de la rupture des jours
WDVueAPVerticale.prototype._vnGetHauteurRuptureJour = function _vnGetHauteurRuptureJour(oParametres)
{
	var nHauteur = 0;
	if (oParametres.m_nHauteurLibJour)
	{
		nHauteur += oParametres.m_nHauteurLibJour;
	}
	if (oParametres.m_nHauteurZoneJourneeComplete)
	{
		nHauteur += oParametres.m_nHauteurZoneJourneeComplete;
	}
	return nHauteur;
};

// R�cup�re les styles horizontaux (sans cache)
WDVueAPVerticale.prototype._vtabGetStylesHorizontaux = function _vtabGetStylesHorizontaux(oParametres)
{
	// Dans le cas du planning vertical :
	// - (Toujours) La ligne des ressources
	// La m�thode est red�finie dans les classes d�riv�es (agendas) car ils ont plusieurs lignes
	return [oParametres.m_oStyleLibRessource];
};

// R�cup�re le style vertical (sans cache)
WDVueAPVerticale.prototype._voGetStyleVertical = function _voGetStyleVertical(oParametres)
{
	return oParametres.m_oStyleLibHeure;
};

// Style de la derni�re ligne des titres secondaires (= des titres qui ne sont pas les conteneurs)
WDVueAPVerticale.prototype._voGetStyleTitreSecondaireDernier = function _voGetStyleTitreSecondaireDernier(oParametres)
{
	return this._voGetStyleVertical(oParametres);
};

// Construit le HTML des titres horizontaux
// tabHTML inclus deja un <table> ouvrant => il faut commencer a tr
WDVueAPVerticale.prototype._vHTMLAfficheTitresHorizontal = function _vHTMLAfficheTitresHorizontal(tabHTML, oParametres)
{
	var sLibelle;
	var nIndiceJour = 0;
	if (oParametres.m_bLigneTitreSemaine)
	{
		var nNbConteneurs = this.m_oChampAP._nGetNbConteneurs(false);
		var nDimensionPxGraduation = this._vnGetDimensionLateralePxGraduation(oParametres);
		var nLargeur = nDimensionPxGraduation * nNbConteneurs;
		// GP 17/01/2013 : On utilise maintenant le style sp�cifique au lieu de oParametres.m_oStyleLibJourSemaine
		nLargeur = this.__nGetDimensionPxSansBordure(nLargeur, oParametres.m_oStyleLibNumeroSemaine);

		// Genere la ligne pour la semaine
		tabHTML.push("<tr class=\"");
		tabHTML.push(this.ms_sNomTitresConteneurs);
		// GP 24/01/2013 : Les styles sont maintenant indic�es sur les titres horizontaux
		tabHTML.push(nIndiceJour);
		// On a une seule colonne...
		tabHTML.push("\"><td class=\"");
		tabHTML.push(this.ms_sNomPremier);
		// ...sur toute la largeur
		tabHTML.push("\" colspan=\"");
		tabHTML.push(nNbConteneurs);
		tabHTML.push("\">");
		sLibelle = this.m_oChampAP._sGetNomConteneur(0).split(this.ms_sSeparateurFormatLigne)[0];
		// GP 17/01/2013 : On utilise maintenant le style sp�cifique au lieu de oParametres.m_oStyleLibJourSemaine
		this.__HTMLAfficheDiv(tabHTML, oParametres.m_oStyleLibNumeroSemaine.m_sClasses, undefined, clWDUtil.sEncodeInnerHTML(sLibelle, true, false), undefined, this._tabInitCSS_DimensionLargeur([], nLargeur, this.ms_nPaddingTitreCalcul, 0, true).join(";"));
		tabHTML.push("</td></tr>");

		// Decale l'indice du nom du jour
		nIndiceJour++;
	}

	// Genere la table
	tabHTML.push("<tr class=\"");
	tabHTML.push(this.ms_sNomTitresConteneurs);
	// GP 24/01/2013 : Les styles sont maintenant indic�es sur les titres horizontaux
	tabHTML.push(nIndiceJour);
	tabHTML.push("\">");

	var i;
	var nLimiteI = this.m_oChampAP._nGetNbConteneurs(false);
	for (i = 0; i < nLimiteI; i++)
	{
		tabHTML.push("<td");
		if (i == 0)
		{
			tabHTML.push(" class=\"");
			tabHTML.push(this.ms_sNomPremier);
			tabHTML.push("\"");
		}
		tabHTML.push(">");
		// GP 27/05/2016 : Gestion des libell�s multilignes en ligne
		var oStyle = this._oGetStyleHorizontalDernier(oParametres);
		this.__HTMLAfficheDivLibelle(tabHTML
			, oStyle.m_sClasses
			, this.m_oChampAP._sGetNomConteneur(i).split(this.ms_sSeparateurFormatLigne)[nIndiceJour]
			, this.__nGetDimensionPxSansBordure(this._vnGetHauteurTitresHorizontaux(oParametres, 1), oStyle) - this.ms_nPaddingTitreCalcul);
		tabHTML.push("</td>");
	}
	tabHTML.push("</tr>");
};

// Construit le HTML des titres verticaux
// tabHTML inclus deja un <table> ouvrant => il faut commencer a tr
WDVueAPVerticale.prototype._vHTMLAfficheTitresVertical = function _vHTMLAfficheTitresVertical(tabHTML, oParametres)
{
	// Le dessin avec clipping ne marche pas dans IE en mode quirks, on fait l'ancien mode avec overflow-x/overflow-y
	if (bIEQuirks9Max)
	{
		// Pour avoir une debordement des ruptures (sans mettre une classe)
		this.m_oHoteTitresVertical.style.position = "relative";
		this.m_oHoteTitresVertical.style.zIndex = this.ms_nZIndexFondRupture;
		this.m_oHoteTitresVertical.parentNode.style.position = "relative";
		this.m_oHoteTitresVertical.parentNode.style.zIndex = this.ms_nZIndexFondRupture;
	}

	// Selon la position des heures initialise
	var tabGraduations = this.m_tabGraduations;
	var i;
	var nLimiteI = tabGraduations.length;
	if (this.ms_bReordonneGraduationAffichage)
	{
		nLimiteI = nLimiteI / this._vnGetNbGraduationsParalleles(oParametres);
	}
	for (i = 0; i < nLimiteI; i++)
	{
		var oGraduation = tabGraduations[i];

		// Si on a une rupture
		if (oGraduation.m_bRupture && oParametres.m_nHauteurLibJour)
		{
			// Genere la table
			tabHTML.push("<tr><td class=\"");
			tabHTML.push(this.ms_sNomFondRupture);
			tabHTML.push("\"><div class=\"");
			tabHTML.push(this.ms_sNomFondRupture);
			tabHTML.push("\">");
			// La partie avec les rupture : dessus
			tabHTML.push("<div class=\"");
			tabHTML.push(this.ms_sNomJour);
			tabHTML.push(" ");
			// GP 17/01/2013 : Ici on est bien dans l'affichage de la ligne des jours donc on conserve oParametres.m_oStyleLibJourSemaine
			tabHTML.push(oParametres.m_oStyleLibJourSemaine.m_sClasses);
			tabHTML.push("\">");
			tabHTML.push(clWDUtil.sEncodeInnerHTML(oGraduation.m_sRuptureLibelle, true, false));
			tabHTML.push("</div></div></td></tr>");

			// GP 22/05/2014 : QW245376 : Cette zone est en fait utile si on a le s�parateur de jour par ligne : d�calage dans le cas oParametres.m_nHauteurLibJour
			// GP 29/04/2014 : TB82277 : Cette zone d�cale les titres vers le bas de mani�re erron�.
			if (oParametres.m_nHauteurZoneJourneeComplete)
			{
				// Genere la table
				// GP 26/03/2013 : Ajout de this.ms_sNomTitresSecondaires pour avoir la bordure
				tabHTML.push("<tr class=\"");
				tabHTML.push(this.ms_sNomTitresSecondaires);
				tabHTML.push("\"><td>");
				this.__HTMLAfficheDiv(tabHTML, this.ms_sNomJourneeComplete);
				tabHTML.push("</td></tr>");
			}
		}

		// Genere la table
		tabHTML.push("<tr class=\"");
		tabHTML.push(this.ms_sNomTitresSecondaires);
		tabHTML.push("\"><td");
		// Si on est sur une graduation, affiche une graduation
		// On utilise le style premier sur le dernier
		if ((i + 1) >= nLimiteI)
		{
			tabHTML.push(" class=\"");
			tabHTML.push(this.ms_sNomPremier);
			tabHTML.push("\"");
		}
		tabHTML.push(">");
		tabHTML.push("<div class=\"");
		tabHTML.push(this.ms_sNomHeureLibelle);
		tabHTML.push(" ");
		tabHTML.push(oGraduation.m_sLibelleClasse);
		if (oGraduation.m_sLibelleCouleurFond)
		{
			tabHTML.push("\" style=\"background-color:");
			tabHTML.push(oGraduation.m_sLibelleCouleurFond);
		}
		tabHTML.push("\"><span class=\"");
		tabHTML.push(oGraduation.m_sLibelleClasse);
		tabHTML.push("\">");
		tabHTML.push(clWDUtil.sEncodeInnerHTML(oGraduation.m_sLibelle, true, false));
		tabHTML.push("</span></div></td></tr>");
	}
};

// Recupere le defilement du corps : scrollLeft (ressources en ligne) ou scrollTop (ressources en colonne)
WDVueAPVerticale.prototype._vnGetDefilementPrincipal = WDVueAPBase.prototype._nGetDefilementVertical;
WDVueAPVerticale.prototype._vnGetDefilementLateral = WDVueAPBase.prototype._nGetDefilementHorizontal;
// Fixe le defilement du corps : scrollLeft (ressources en ligne) ou scrollTop (ressources en colonne)
WDVueAPVerticale.prototype._vSetDefilementPrincipal = WDVueAPBase.prototype._SetDefilementVertical;
WDVueAPVerticale.prototype._vSetDefilementLateral = WDVueAPBase.prototype._SetDefilementHorizontal;

// Calcule la largeur du libelle du jour
WDVueAPVerticale.prototype.__nGetLargeurLibJour = function __nGetLargeurLibJour(oParametres, nOffsetBordure, bSansTitresVertical)
{
	// GP 02/05/2018 : Vu avec TB100782 : Il semble que en pr�sence d'ancrage, la taille du champ soit fausse : this.m_nLargeurClientCorps contient 0.
	// Ce qui donne une valeur n�gative en valeur de retour de cette fonction.
	// Le seul bug constant� est que cela r�duit la largeur du div qui r�serve l'espace pour le libell� du jour � une valeur n�gative, ce qui le masque.
	// On fait donc en sorte de retourner toujours une valeur au mieux valide.
	var nLargeurClientCorps = this.m_nLargeurClientCorps;
	var nLargeurClientCorpsMoinsLePadding;
	if (0 != nLargeurClientCorps)
	{
		nLargeurClientCorpsMoinsLePadding = nLargeurClientCorps + nOffsetBordure - 2 * (bIEQuirks9Max ? 0 : this.ms_nPaddingLibJour);
	}
	else
	{
		// Ne tient pas compte de nOffsetBordure qui peut aussi �tre n�gatif.
		nLargeurClientCorpsMoinsLePadding = 1;
	}

	// Il faudrait prendre la largeur effective (this.__nGetLargeur()) du champ et pas la largeur des ressource
	// sauf que avec ce code on ne detecte pas bien le defilement puisque les ruptures sont dans la zone basse donc si la zone se reduit cela ne fonctionne pas
	// Il faut tenir compte du padding pour les navigateurs respectant la norme.
	return ((!bSansTitresVertical) ? oParametres.m_nLargeurTitresVertical : 0) + nLargeurClientCorpsMoinsLePadding;
};

// En mode quirks, il y a le padding en plus
// - En mode ressources en ligne, c'est le padding "avant" => this.ms_nPaddingLateralDebut
// - En mode ressources en colonne, c'est le padding "apres" => this.ms_nPaddingLateralFin
WDVueAPVerticale.prototype._vnGetPaddingTopPourRendezVous = function _vnGetPaddingTopPourRendezVous()
{
	return 0;
//	return bIEQuirks9Max ? 0 : 0;
};
WDVueAPVerticale.prototype._vnGetPaddingRightPourRendezVous = function _vnGetPaddingRightPourRendezVous()
{
	return (bIEQuirks9Max ? this.ms_nPaddingLateralFin : 0);
};

// Retourne offsetLeft (ressources en ligne) ou offsetTop (ressources en colonne)
WDVueAPVerticale.prototype.voGetOffsetDebut = function voGetOffsetDebut(oElement)
{
	return oElement.offsetTop;
};
// Retourne offsetWidth (ressources en ligne) ou offsetHeight (ressources en colonne)
WDVueAPVerticale.prototype.voGetOffsetLongueur = function voGetOffsetLongueur(oElement)
{
	return oElement.offsetHeight;
};
WDVueAPVerticale.prototype.vbGetVertical = function vbGetVertical()
{
	return true;
};

// Retourne le deplacement important pour la position : X (ressources en ligne) ou Y (ressources en colonne)
WDVueAPVerticale.prototype.vnGetOffsetPosition = function vnGetOffsetPosition(nOffsetPositionX, nOffsetPositionY)
{
	return nOffsetPositionY;
};
// Retourne la coordonnee importante pour la position : X (ressources en ligne) ou Y (ressources en colonne) selon le conteneur hote
WDVueAPVerticale.prototype.vnGetPositionHote = function vnGetPositionHote(oElement, nPositionX, nPositionY, bVersEcran)
{
	return this._nGetPositionHote(oElement, nPositionY, false, bVersEcran);
};

// Appel de _sGetHTMLRendezVous avec les bonnes dimensions
WDVueAPVerticale.prototype._vsGetHTMLRendezVous = function _vsGetHTMLRendezVous(oParametres, oRendezVous, nLongueur, nDimensionLateralePx)
{
	return this._sGetHTMLRendezVous(oParametres, oRendezVous, nDimensionLateralePx, nLongueur);
};

// Calcule la position en pixel du debut d'un rendez-vous en mode "TitreSeul" (tous les rendez-vous de l'agenda)
WDVueAPVerticale.prototype._vnGetDebutRendezVousTitreSeul = function _vnGetDebutRendezVousTitreSeul(oParametres, oSuperpositionInfo, nDate, nDateReference)
{
	// Espace r�serv� : hauteur du libell� des jours
	var nEspaceReserve = 0;
	if (oParametres.m_nHauteurLibJour)
	{
		nEspaceReserve = oParametres.m_nHauteurLibJour;
	}
	// D�but dans le conteneur : d�calage des jours pr�c�dent
	var nDebutDansConteneur = this.__nGetDimensionPxDepuisDifferenceDate(oParametres, nDate, nDateReference, false);

	// Si on est ici c'est que l'on est pour le mode rendez-vous � la journ�e
	var nDimensionPxVerticale = oParametres.m_nHauteurZoneJourneeComplete;

	return this._nGetHautRendezVousTitreSeul(oParametres, oSuperpositionInfo, nDebutDansConteneur, nEspaceReserve, nDimensionPxVerticale);
};

WDVueAPVerticale.prototype._vnDimensionHorizontalRendezVousTitreSeul = function _vnDimensionHorizontalRendezVousTitreSeul(oParametres, oDimensionLaterale/*, nDateDebut*//*, nDateFin*//*, nDateReference*/)
{
	var nDimensionLateralRendezVous = this._nGetDimensionLateralePxConteneur(oParametres);

	// Position en colonne
	if (bIEQuirks9Max)
	{
		// La colonne gere deja l'espace a gauche/haut et a droite/bas via un padding
		oDimensionLaterale.m_oDebut = "0%";
		oDimensionLaterale.m_oLongueur = "100%";
	}
	else
	{
		oDimensionLaterale.m_oDebut = "0";
		oDimensionLaterale.m_oLongueur = (nDimensionLateralRendezVous - this.ms_nPaddingLateralDebut - this.ms_nPaddingLateralFin);
	}

	// GP 13/03/2013 : QW230834 : Ajout de "- this.ms_nPaddingLateralDebut - this.ms_nPaddingLateralFin"
	return nDimensionLateralRendezVous - this.ms_nPaddingLateralDebut - this.ms_nPaddingLateralFin;
};

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// Vue horizontale
function WDVueAPHorizontale(/*oChampAP*//*, oVuePrecedente*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDVueAPBase.prototype.constructor.apply(this, arguments);
	}
}

// Declare l'heritage
WDVueAPHorizontale.prototype = new WDVueAPBase();
// Surcharge le constructeur qui a ete efface
WDVueAPHorizontale.prototype.constructor = WDVueAPHorizontale;

//////////////////////////////////////////////////////////////////////////
// Constantes specifiques

// Indique la position des titres de ressources et d'heures
WDVueAPHorizontale.prototype.ms_sNomGeneralSpecifique = "WDPLN-ZoneGeneralHorizontal";
//WDVueAPHorizontale.prototype.ms_sTitresHeuresPosition = WDVueAPBase.prototype.ms_sNomTitresHorizontal;
// Indique le sens de la fusion des colonnes
WDVueAPHorizontale.prototype.ms_bTableTrParRessource = true;
// Et les dimension
//WDVueAPHorizontale.prototype.ms_sStyleDebut = "left";
WDVueAPHorizontale.prototype.ms_sStyleDimension = "width";
WDVueAPHorizontale.prototype.ms_sStyleDebutLateral = "top";
WDVueAPHorizontale.prototype.ms_sStyleDimensionLaterale = "height";
WDVueAPHorizontale.prototype.ms_sCurseurRedim = "E-resize";

WDVueAPHorizontale.prototype.ms_bZoneTitreSeulIndependanteParLigne = true;

//////////////////////////////////////////////////////////////////////////
// Methodes virtuelles

// Methode d'initialisation generale de la classe (ne s'execute que lors de l'init de la premi�re instance de ce type)
WDVueAPHorizontale.prototype._vInitInitiale = function _vInitInitiale()
{
	// Appel de la methode de la classe de base
	WDVueAPBase.prototype._vInitInitiale.apply(this, arguments);

	var sPrefixeSpecifique = "." + this.ms_sNomGeneralSpecifique + " ";

	// Regles specifiques (la table des regles a ete cree par WDVueAPBase::_vInitInitiale)
	// - Corps
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomCorps, ["overflow-x:scroll", "overflow-y:auto", "position:relative"]);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomTitresHorizontal + " td", ["overflow:hidden"]);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "td." + this.ms_sNomCorpsQuadrillage, ["width:0px"]);
	// - Rendez-vous
	var nPaddingTop = this._vnGetPaddingTopPourRendezVous() + this.ms_nPaddingRendezVous;
	var nPaddingBottom = (bIEQuirks9Max ? this.ms_nPaddingLateralFin : 0) + this.ms_nPaddingRendezVous;
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousRepetition, ["position:absolute", "top:" + nPaddingTop + "px", "right:" + this.ms_nPaddingRendezVous + "px"]);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousImportance, ["position:absolute", "bottom:" + nPaddingBottom + "px", "right:" + this.ms_nPaddingRendezVous + "px"]);
	// Pas sur que le top ici soit le plus correct (a quoi fait-il referencereference ? mais cela fonctionne)
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousRedimDebutBefore, ["left:0", "top:0", "height:100%", "width:5px"]);
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousRedimFinAfter, ["right:0", "top:0", "height:100%", "width:5px"]);
	if (bIEQuirks9Max)
	{
		this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomRendezVousExterne, ["padding-top:" + this.ms_nPaddingLateralDebut + "px", "padding-bottom:" + this.ms_nPaddingLateralFin + "px"]);
	}
	var tabStyle = ["position:relative", "float:left"];
	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomHeure, tabStyle);
//	this.__StyleCreeGlobal(sPrefixeSpecifique + "." + this.ms_sNomCorpsQuadrillage + " ." + this.ms_sNomJourneeComplete, tabStyle);

	// S'auto efface pour ne plus etre appele
	WDVueAPHorizontale.prototype._vInitInitiale = clWDUtil.m_pfVide;
};


// Fixe le debut dans le sens principal : left (ressources en ligne) ou top (ressources en colonne)
WDVueAPHorizontale.prototype.vSetDebut = WDChamp.prototype.s_SetStyleLeft;
// Fixe la longueur dans le sens principal : width (ressources en ligne) ou height (ressources en colonne)
WDVueAPHorizontale.prototype.vSetLongueur = WDChamp.prototype.s_SetStyleWidth;
// Fixe le debut lateral : top (ressources en ligne) ou left (ressources en colonne)
WDVueAPHorizontale.prototype.vSetDebutLateral = WDChamp.prototype.s_SetStyleTop;
// Fixe la dimension laterale :
// - Quirk : Longueur : height (ressources en ligne) ou width (ressources en colonne)
// - Autres : Fin : bottom (ressources en ligne) ou right (ressources en colonne)
WDVueAPHorizontale.prototype.vSetLongueurLateral = (bIEQuirks9Max ? WDChamp.prototype.s_SetStyleHeight : WDChamp.prototype.s_SetStyleBottom);

// Initialisation des titres
WDVueAPHorizontale.prototype._vInitCSS_TitresConteneurs = function _vInitCSS_TitresConteneurs(oParametres)
{
	return this.__InitCSS_TitresVerticaux(oParametres, true);
};
WDVueAPHorizontale.prototype._vInitCSS_TitresHeures = function _vInitCSS_TitresHeures(oParametres)
{
	return this.__InitCSS_TitresHorizontaux(oParametres, false);
};

// Initialisation du style des libelle des jours : pas de rupture dans ce mode
WDVueAPHorizontale.prototype._vInitCSS_LibJour = function _vInitCSS_LibJour(oParametres)
{
	// Supprimer tous les this.ms_sNomJour dans WDVueAPHorizontale ?
//	var oStyle = this._voGetStyleTitreSecondaireDernier(oParametres);
//
//	var tabBordure = this._vtabInitCSS_BorduresPerpendiculaires([], oStyle, null);
//	// Note : pour les heures ont a un bordure sur le dernier (meme si on garde le meme style)
//	var tabBordurePremier = this._vtabInitCSS_BorduresPerpendiculaires([], oStyle, oStyle);
//	var tabBordureCote = this._vtabInitCSS_BorduresLaterales([], oStyle, null);
//	var nDimensionPxPrincipale = this.__nGetDimensionPxSansBordure(this.vnGetDimensionPxGraduation(oParametres), oStyle);
//	var nDimensionPxLaterale = this.__nGetDimensionPxSansBordure(this._vnGetHauteurTitresHorizontaux(oParametres, 1), oStyle);
//	this.__InitCSS_UnTitre(this.ms_sNomTitresSecondaires + "." + this.ms_sNomJour, this.ms_sTitresHeuresPosition, undefined, tabBordure, tabBordurePremier, tabBordureCote, oStyle, oStyle, nDimensionPxPrincipale, nDimensionPxLaterale);
//	this.__InitCSS_UnTitre(this.ms_sNomTitresSecondaires + "." + this.ms_sNomJour, this.ms_sTitresHeuresPosition, this.ms_sNomJourLigneSupplementaire, tabBordure, tabBordurePremier, tabBordureCote, oStyle, oStyle, nDimensionPxPrincipale, this._vnGetHauteurTitresHorizontaux(oParametres, 1));

	// Style g�n�ral : fond de la zone des rendez-vous � la journ�e compl�te
	if (oParametres.m_nHauteurZoneJourneeComplete)
	{
		var oStyle = oParametres.m_oStyleJourneeComplete;

		var nNbGraduationsParJour = (oParametres.m_nHeureAfficheMax - oParametres.m_nHeureAfficheMin) / 3600000; ;
		var nDimensionLateral = this.vnGetDimensionPxGraduation(oParametres) * nNbGraduationsParJour;

		// Si on a une couleur de fond
		if (oStyle.m_cFond)
		{
			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomFondCouleur, " ", this.ms_sNomJourneeComplete), ["background-color:" + oStyle.m_cFond, "width:" + nDimensionLateral + "px", "height:" + oParametres.m_nHauteurZoneJourneeComplete + "px", "float:left"]);
		}
		if (0 < oStyle.m_nBordureV)
		{
			var nOffsetBordure = this._nGetOffsetBordure(oStyle, 2);
			this.__StyleCree(this.__sGetSelecteur(this.ms_sNomFondBordure, " ", this.ms_sNomJourneeComplete), ["border:solid " + oStyle.m_nBordureV + "px " + oStyle.m_cBordureV, "width:" + (nDimensionLateral + nOffsetBordure) + "px", "height:" + (oParametres.m_nHauteurZoneJourneeComplete + nOffsetBordure) + "px", "float:left"]);
		}
	}
};

// Sur le defilement du corps : pas de rupture dans ce mode
WDVueAPHorizontale.prototype._vOnDefilementCorps = function _vOnDefilementCorps(oParametres, nDefilementHorizontal/*, nDefilementVertical*/)
{
	var nLigne = 0;
	// Affiche correctement les ruptures de mois
	if (oParametres.m_bLigneTitreMois)
	{
		// GP 17/01/2013 : On utilise maintenant le style sp�cifique au lieu de oParametres.m_oStyleLibJourSemaine
		this.__DecaleRuptureMoisSemaine(oParametres.m_oStyleLibNomMois, nLigne, this.m_tabLargeurMois, nDefilementHorizontal);
		nLigne++;
	}
	// Et des semaine
	if (oParametres.m_bLigneTitreSemaine)
	{
		// GP 17/01/2013 : On utilise maintenant le style sp�cifique au lieu de oParametres.m_oStyleLibJourSemaine
		this.__DecaleRuptureMoisSemaine(oParametres.m_oStyleLibNumeroSemaine, nLigne, this.m_tabLargeurSemaine, nDefilementHorizontal);
	}

	// GP 27/03/2013 : QW231 500 : D�cale les libell�es des rendez-vous pour qu'ils soient toujours visibles
	var tabRendezVous = this.m_oChampAP.m_oDonnees.m_tabRendezVous;
	var nNbRendezVous = tabRendezVous.length;
	var nRendezVous;
	for (nRendezVous = 0; nRendezVous < nNbRendezVous; nRendezVous++)
	{
		var oRendezVous = tabRendezVous[nRendezVous];
		if (oRendezVous.m_oDiv)
		{
			var sTextIndent = undefined;
			var nOffsetLeft = oRendezVous.m_oDiv.offsetLeft;
			// Si on doit d�caler le titre du champ
			if ((nOffsetLeft < nDefilementHorizontal) && (nDefilementHorizontal < (nOffsetLeft + oRendezVous.m_oDiv.offsetWidth)))
			{
				sTextIndent = (nDefilementHorizontal - nOffsetLeft) + "px";
				oRendezVous.m_bTitreDecale = true;
			}
			else if (oRendezVous.m_bTitreDecale)
			{
				// Si le rendez-vous �tait d�cal� (mais ne l'est plus : enti�rement visible ou enti�rement masqu�)
				// => Ne d�cale plus son titre
				sTextIndent = "";
				delete oRendezVous.m_bTitreDecale;
			}

			if (undefined !== sTextIndent)
			{
				oRendezVous.m_oDiv.getElementsByTagName("div")[0].style.textIndent = sTextIndent;
			}
		}
	}
};

// Construit le stype pour une dimension sans le sens principale (largeur (ressources en lignes), hauteur (ressources en colonnes))
WDVueAPHorizontale.prototype._vtabInitCSS_DimensionPxPrincipale = WDVueAPBase.prototype._tabInitCSS_DimensionLargeur;
// Construit le stype pour une dimension laterale (hauteur (ressources en lignes), largeur (ressources en colonnes))
WDVueAPHorizontale.prototype._vtabInitCSS_DimensionPxLaterale = WDVueAPBase.prototype._tabInitCSS_DimensionHauteur;

// Construit le style pour les bordures dans le sens perpendiculaire au defilement principal (gauche/droite (ressources en lignes), haut/bas (ressources en colonnes))
WDVueAPHorizontale.prototype._vtabInitCSS_BorduresPerpendiculaires = WDVueAPBase.prototype._tabInitCSS_BorduresGaucheDroite;
// Construit le style pour les bordures dans le sens du defilement principal (haut/bas (ressources en lignes), droite/gauche (ressources en colonnes))
WDVueAPHorizontale.prototype._vtabInitCSS_BorduresLaterales = WDVueAPBase.prototype._tabInitCSS_BorduresHautBas;

WDVueAPHorizontale.prototype._vnGetDimensionClienteLaterale = WDVueAPBase.prototype.__nGetHauteur;
WDVueAPHorizontale.prototype._vnGetHauteurTitresHorizontaux = function _vnGetHauteurTitresHorizontaux(oParametres, nNbLignes)
{
	if (oParametres.m_bLigneTitreMois)
	{
		nNbLignes++;
	}
	if (oParametres.m_bLigneTitreSemaine)
	{
		nNbLignes++;
	}
	if (oParametres.m_bLigneTitreJourDouble)
	{
		nNbLignes++;
	}
	if (oParametres.m_bLigneTitreHeure)
	{
		nNbLignes++;
	}

	return WDVueAPBase.prototype._vnGetHauteurTitresHorizontaux.apply(this, [oParametres, nNbLignes]);
};

WDVueAPHorizontale.prototype._vnDimensionLateralePxCorps = function _vnDimensionLateralePxCorps(/*oParametres*/)
{
//	return this.m_nHauteurCorps;
	// GP 24/01/2013 : Si on est dans chrome ou FF, ils affichent un ascenseur abusif (li� a l'�paisseur de la premi�re ligne de la table qui contient le fond
	// Ajoute un -1 pour ne pas l'avoir
	return this.m_nHauteurClientCorps - (bIEQuirks ? 0 : 1);
};
// Dimension (lat�rale) d'une graduation
WDVueAPHorizontale.prototype._vnGetDimensionLateralePxGraduation = function _vnGetDimensionLateralePxGraduation(oParametres)
{
	var nDimension = this._nGetDimensionLateralePxConteneur(oParametres);
	if (oParametres.m_nHauteurZoneJourneeComplete)
	{
		nDimension -= oParametres.m_nHauteurZoneJourneeComplete;
	}
	return nDimension;
};

// R�cup�re les styles horizontaux (sans cache)
WDVueAPHorizontale.prototype._vtabGetStylesHorizontaux = function _vtabGetStylesHorizontaux(oParametres)
{
	// Dans le cas du planning horizontal :
	// - (Optionnel) La ligne du nom des mois
	// - (Optionnel) La ligne des num�ro de semaine
	// - (Toujours) La ligne du nom des jours
	// - (Optionnel) La ligne des heures
	var tabStylesHorizontaux = [];
	if (oParametres.m_bLigneTitreMois)
	{
		tabStylesHorizontaux.push(oParametres.m_oStyleLibNomMois);
	}
	if (oParametres.m_bLigneTitreSemaine)
	{
		tabStylesHorizontaux.push(oParametres.m_oStyleLibNumeroSemaine);
	}
	tabStylesHorizontaux.push(oParametres.m_oStyleLibJourSemaine);
	if (oParametres.m_bLigneTitreHeure)
	{
		tabStylesHorizontaux.push(oParametres.m_oStyleLibHeure);
	}

	return tabStylesHorizontaux;
};

WDVueAPHorizontale.prototype._voGetStyleVertical = function _voGetStyleVertical(oParametres)
{
	return oParametres.m_oStyleLibRessource;
};

// Style de la derni�re ligne des titres secondaires (= des titres qui ne sont pas les conteneurs)
WDVueAPHorizontale.prototype._voGetStyleTitreSecondaireDernier = function _voGetStyleTitreSecondaireDernier(oParametres)
{
	// Derni�re ligne des styles des titres horizontaux
	return this._oGetStyleHorizontalDernier(oParametres);
};

// Construit le HTML des titres horizontaux
// tabHTML inclus deja un <table> ouvrant => il faut commencer a tr
WDVueAPHorizontale.prototype._vHTMLAfficheTitresHorizontal = function _vHTMLAfficheTitresHorizontal(tabHTML, oParametres)
{
	// Genere la table

	// Si on dessine les heures, decide du nombre de colonnes par jour
	var nNbGraduationsParJour = 1;
	if (oParametres.m_bLigneTitreHeure)
	{
		// Normalement le calcul tomber juste
		nNbGraduationsParJour = (oParametres.m_nHeureAfficheMax - oParametres.m_nHeureAfficheMin) / 3600000;
	}

	// Premiere ligne : les titres des mois
	var nLigne = 0;
	if (oParametres.m_bLigneTitreMois)
	{
		this.m_tabLargeurMois = [];
		// GP 17/01/2013 : On utilise maintenant le style sp�cifique au lieu de oParametres.m_oStyleLibJourSemaine
		this.__HTMLAfficheTitresMoisSemaine(tabHTML, oParametres, oParametres.m_oStyleLibNomMois, nNbGraduationsParJour, this.m_tabLargeurMois, nLigne, this.__nGetNbJoursAfficheMois);
		nLigne++;
	}
	// Seconde ligne : les titres des semaines
	if (oParametres.m_bLigneTitreSemaine)
	{
		this.m_tabLargeurSemaine = [];
		// GP 17/01/2013 : On utilise maintenant le style sp�cifique au lieu de oParametres.m_oStyleLibJourSemaine
		this.__HTMLAfficheTitresMoisSemaine(tabHTML, oParametres, oParametres.m_oStyleLibNumeroSemaine, nNbGraduationsParJour, this.m_tabLargeurSemaine, nLigne, this.__nGetNbJoursAfficheSemaine);
		nLigne++;
	}

	// Seconde ligne : les titres des jours (eventuellement double)
	// GP 17/01/2013 : Ici on est bien dans l'affichage de la ligne des jours donc on conserve oParametres.m_oStyleLibJourSemaine
	this.__HTMLAfficheTitresJours(tabHTML, oParametres, oParametres.m_oStyleLibJourSemaine, nNbGraduationsParJour, nLigne);
	nLigne++;

	// Troisieme ligne : les titres des heures
	if (oParametres.m_bLigneTitreHeure)
	{
		this.__HTMLAfficheTitresHeures(tabHTML, oParametres, nNbGraduationsParJour, nLigne);
	}
};

// Premiere ligne : les titres des mois
WDVueAPHorizontale.prototype.__HTMLAfficheTitresMoisSemaine = function __HTMLAfficheTitresMoisSemaine(tabHTML, oParametres, oStyle, nNbGraduationsParJour, tabLargeur, nLigne, fnGetNbJoursAffiche)
{
	tabHTML.push("<tr class=\"");
	tabHTML.push(this.ms_sNomTitresSecondaires);
	// GP 24/01/2013 : Les styles sont maintenant indic�es sur les titres horizontaux
	tabHTML.push(nLigne);
	tabHTML.push(" ");
	tabHTML.push(this.ms_sNomJour);
	tabHTML.push("\">");

	// GP 15/03/2018 : QW297161 : Cette instruction ne fonctionnait pas jusqu'au 09/03/2018 (il manquait le ; : ce qui cassait cette instruction et la suivante).
	// Il semble que le comportement ant�rieur (ne force pas l'alignement) soit meilleur.
//	var sStyle = "text-align:left;";

	// Selon la position des heures initialise
	var tabGraduations = this.m_tabGraduations;
	var i;
	var nLimiteI = tabGraduations.length;
	// Pas de ++, l'avancement est en interne sur
	var nNbJoursAffiche = 0;
	var nDimensionPxGraduation = this.vnGetDimensionPxGraduation(oParametres);

	for (i = 0; i < nLimiteI; i += nNbJoursAffiche * nNbGraduationsParJour)
	{
		var oGraduation = tabGraduations[i];

		// Trouve le nombre de jours affiche dans le mois
		nNbJoursAffiche = fnGetNbJoursAffiche.apply(this, [oParametres, nNbGraduationsParJour, i]);
		var nNbGraduations = nNbGraduationsParJour * nNbJoursAffiche;

		// Genere la table
		tabHTML.push("<td colspan=\"");
		tabHTML.push(nNbGraduations);
		// Si on est sur une graduation, affiche une graduation
		// On utilise le style premier sur le dernier
		if ((i + nNbGraduations) >= nLimiteI)
		{
			tabHTML.push("\" class=\"");
			tabHTML.push(this.ms_sNomPremier);
		}
		tabHTML.push("\">");

		// Traite le contenu de la rupture
		var tabRuptureLibelle = oGraduation.m_sRuptureLibelle.split(this.ms_sSeparateurFormatLigne);
		var nLargeur = nDimensionPxGraduation * nNbGraduations;
		tabLargeur.push(nLargeur);
		nLargeur = this.__nGetDimensionPxSansBordure(nLargeur, oStyle);

//		this.__HTMLAfficheDiv(tabHTML, this.ms_sNomJour + " " + oStyle.m_sClasses, undefined, clWDUtil.sEncodeInnerHTML(tabRuptureLibelle[nLigne], true, false), undefined, sStyle + this._tabInitCSS_DimensionLargeur([], nLargeur, this.ms_nPaddingTitreCalcul, 0, true).join(";"));
		this.__HTMLAfficheDiv(tabHTML, this.ms_sNomJour + " " + oStyle.m_sClasses, undefined, clWDUtil.sEncodeInnerHTML(tabRuptureLibelle[nLigne], true, false), undefined, this._tabInitCSS_DimensionLargeur([], nLargeur, this.ms_nPaddingTitreCalcul, 0, true).join(";"));
		tabHTML.push("</td>");
	}
	tabHTML.push("</tr>");
};

// nombre de jour dans le mois
WDVueAPHorizontale.prototype.__nGetNbJoursAfficheMois = function __nGetNbJoursAfficheMois(oParametres, nNbGraduationsParJour, nGraduation)
{
	// Selon la position des heures initialise
	var tabGraduations = this.m_tabGraduations;
	var i;
	var nLimiteI = tabGraduations.length;
	var nNbJoursAfficheMois = 1;
	var nMois = tabGraduations[nGraduation].m_oDateDebut.getMonth();
	for (i = nGraduation + nNbGraduationsParJour; i < nLimiteI; i += nNbGraduationsParJour, nNbJoursAfficheMois++)
	{
		if (tabGraduations[i].m_oDateDebut.getMonth() != nMois)
		{
			break;
		}
	}
	return nNbJoursAfficheMois;
};

WDVueAPHorizontale.prototype.__nGetNbJoursAfficheSemaine = function __nGetNbJoursAfficheSemaine(oParametres, nNbGraduationsParJour, nGraduation)
{
	// Selon la position des heures initialise
	var tabGraduations = this.m_tabGraduations;
	var i;
	var nLimiteI = tabGraduations.length;
	var nNbJoursAfficheSemaine = 1;
	for (i = nGraduation + nNbGraduationsParJour; i < nLimiteI; i += nNbGraduationsParJour, nNbJoursAfficheSemaine++)
	{
		// Ne fonctionne pas si on saute des jours dans l'affichage
		if (tabGraduations[i].m_oDateDebut.getDay() == oParametres.m_nPremierJourSemaine)
		{
			break;
		}
	}
	return nNbJoursAfficheSemaine;
};

// Seconde ligne : les titres des jours (eventuellement double)
WDVueAPHorizontale.prototype.__HTMLAfficheTitresJours = function __HTMLAfficheTitresJours(tabHTML, oParametres, oStyle, nNbGraduationsParJour, nLigne)
{
	tabHTML.push("<tr class=\"");
	tabHTML.push(this.ms_sNomTitresSecondaires);
	// GP 24/01/2013 : Les styles sont maintenant indic�es sur les titres horizontaux
	tabHTML.push(nLigne);
	tabHTML.push(" ");
	tabHTML.push(this.ms_sNomJour);
	tabHTML.push("\">");

	var nLargeur = this.__nGetDimensionPxSansBordure(this.vnGetDimensionPxGraduation(oParametres) * nNbGraduationsParJour, oStyle);
	var sStyle = this._tabInitCSS_DimensionLargeur([], nLargeur, this.ms_nPaddingTitreCalcul, 0, true).join(";");
	if (oParametres.m_bLigneTitreMois || oParametres.m_bLigneTitreSemaine)
	{
		sStyle += ";text-align:center";
	}

	// Selon la position des heures initialise
	var tabGraduations = this.m_tabGraduations;
	var i;
	var nLimiteI = tabGraduations.length;
	for (i = 0; i < nLimiteI; i += nNbGraduationsParJour)
	{
		var oGraduation = tabGraduations[i];

		// Normalement on est sur une rupture (= changement de jour)
		// Genere la table
		tabHTML.push("<td colspan=\"");
		tabHTML.push(nNbGraduationsParJour);
		// Si on est sur une graduation, affiche une graduation
		// On utilise le style premier sur le dernier
		if ((i + nNbGraduationsParJour) >= nLimiteI)
		{
			tabHTML.push("\" class=\"");
			tabHTML.push(this.ms_sNomPremier);
		}
		tabHTML.push("\">");

		// Traite le contenu de la rupture
		var tabRuptureLibelle = oGraduation.m_sRuptureLibelle.split(this.ms_sSeparateurFormatLigne);

		// La partie avec les rupture : dessus
		var j;
		var nLimiteJ = tabRuptureLibelle.length;
		for (j = nLigne; j < nLimiteJ; j++)
		{
			tabHTML.push("<div class=\"");
			tabHTML.push((j == nLigne) ? this.ms_sNomJour : this.ms_sNomJourLigneSupplementaire);
			tabHTML.push(" ");
			tabHTML.push(oStyle.m_sClasses);
			tabHTML.push("\" style=\"");
			tabHTML.push(sStyle);
			tabHTML.push("\">");
			tabHTML.push(clWDUtil.sEncodeInnerHTML(tabRuptureLibelle[j], true, false));
			tabHTML.push("</div>");
		}
		tabHTML.push("</td>");
	}
	tabHTML.push("</tr>");
};

// Troisieme ligne : les titres des heures
WDVueAPHorizontale.prototype.__HTMLAfficheTitresHeures = function __HTMLAfficheTitresHeures(tabHTML, oParametres, nNbGraduationsParJour, nLigne)
{
	tabHTML.push("<tr class=\"");
	tabHTML.push(this.ms_sNomTitresSecondaires);
	// GP 24/01/2013 : Les styles sont maintenant indic�es sur les titres horizontaux
	tabHTML.push(nLigne);
	tabHTML.push("\">");

	// Selon la position des heures initialise
	var tabGraduations = this.m_tabGraduations;
	var i;
	var nLimiteI = tabGraduations.length;
	var nNbGraduationsAvantFinJour;
	var nNbColonnesPourHeure;
	var nDimensionPxGraduation = this.vnGetDimensionPxGraduation(oParametres);
	for (i = 0; i < nLimiteI; i += nNbColonnesPourHeure, nNbGraduationsAvantFinJour -= nNbColonnesPourHeure)
	{
		var oGraduation = tabGraduations[i];

		// Si on commence un nouveau jour
		if (oGraduation.m_bRupture)
		{
			nNbGraduationsAvantFinJour = nNbGraduationsParJour;
		}

		// Calcule le nombre de colonne a utiliser
		nNbColonnesPourHeure = Math.min(nNbGraduationsAvantFinJour, oParametres.m_nNbGraduationParHeureAffichee);

		// Genere la table
		tabHTML.push("<td");
		if (1 < nNbColonnesPourHeure)
		{
			tabHTML.push(" colspan=\"");
			tabHTML.push(nNbColonnesPourHeure);
			tabHTML.push("\"");
		}
		// Si on est sur une graduation, affiche une graduation
		// On utilise le style premier sur le dernier
		if ((i + nNbColonnesPourHeure) >= nLimiteI)
		{
			tabHTML.push(" class=\"");
			tabHTML.push(this.ms_sNomPremier);
			tabHTML.push("\"");
		}
		tabHTML.push(">");

		tabHTML.push("<div class=\"");
		tabHTML.push(this.ms_sNomHeureLibelle);
		tabHTML.push(" ");
		tabHTML.push(oGraduation.m_sLibelleClasse);
		tabHTML.push("\" style=\"");
		var nLargeur = this.__nGetDimensionPxSansBordure(nDimensionPxGraduation * nNbColonnesPourHeure, oParametres.m_oStyleLibHeure);
		tabHTML.push(this._tabInitCSS_DimensionLargeur([], nLargeur, this.ms_nPaddingTitreCalcul, 0, true).join(";"));
		if (oGraduation.m_sLibelleCouleurFond)
		{
			tabHTML.push(";background-color:");
			tabHTML.push(oGraduation.m_sLibelleCouleurFond);
		}
		tabHTML.push("\">");
		tabHTML.push(clWDUtil.sEncodeInnerHTML(oGraduation.m_sLibelle, true, false));
		tabHTML.push("</div></td>");
	}
	tabHTML.push("</tr>");

	// Ajoute une serie de colonnes vides pour IE
	if (bIEQuirks9Max)
	{
		tabHTML.push("<tr style=\"height:0px\">");
		var sCellule = "<td style=\"width:" + nDimensionPxGraduation + "px\" />";
		for (i = 0; i < nLimiteI; i++)
		{
			tabHTML.push(sCellule);
		}
		tabHTML.push("</tr>");
	}
};

// Construit le HTML des titres verticaux
// tabHTML inclus deja un <table> ouvrant => il faut commencer a tr
WDVueAPHorizontale.prototype._vHTMLAfficheTitresVertical = function _vHTMLAfficheTitresVertical(tabHTML, oParametres)
{
	// Genere la table
	var i;
	var nLimiteI = this.m_oChampAP._nGetNbConteneurs(false);
	for (i = 0; i < nLimiteI; i++)
	{
		tabHTML.push("<tr class=\"");
		tabHTML.push(this.ms_sNomTitresConteneurs);
		tabHTML.push("\"><td");
		if (i == 0)
		{
			tabHTML.push(" class=\"");
			tabHTML.push(this.ms_sNomPremier);
			tabHTML.push("\"");
		}
		tabHTML.push(">");
		// GP 04/11/2013 : QW80812 : si le libell� est multilignes
		var sLibelle = this.m_oChampAP._sGetNomConteneur(i);
		// GP 05/06/2018 : TB109022 : Sauf que si on a plusieurs lignes, on doit corriger le line-height
//		// GP 13/11/2017 : QW292861 : Plus de line-height, le centrage vertical est par un table-cell
		// GP 19/07/2019 : TB114073 : Il semble que le this.ms_nPaddingTitreCalcul est de trop ? Que dans le cas non IE ?
		var nLineHeightBase = (-1 != sLibelle.indexOf("\n")) ? (this.__nGetDimensionPxSansBordure(this._nGetDimensionLateralePxConteneur(oParametres), this._voGetStyleVertical(oParametres)) - ((clWDUtil.bHTML5 && !bIEAvec11 && (this instanceof WDVueAPHorizontale)) ? 0 : this.ms_nPaddingTitreCalcul)) : undefined;
		this.__HTMLAfficheDivLibelle(tabHTML
			, oParametres.m_oStyleLibRessource.m_sClasses
			, sLibelle
			, nLineHeightBase);
		tabHTML.push("</td>");
	}
	tabHTML.push("</tr>");
};

// Recupere le defilement du corps : scrollLeft (ressources en ligne) ou scrollTop (ressources en colonne)
WDVueAPHorizontale.prototype._vnGetDefilementPrincipal = WDVueAPBase.prototype._nGetDefilementHorizontal;
WDVueAPHorizontale.prototype._vnGetDefilementLateral = WDVueAPBase.prototype._nGetDefilementVertical;
// Fixe le defilement du corps : scrollLeft (ressources en ligne) ou scrollTop (ressources en colonne)
WDVueAPHorizontale.prototype._vSetDefilementPrincipal = WDVueAPBase.prototype._SetDefilementHorizontal;
WDVueAPHorizontale.prototype._vSetDefilementLateral = WDVueAPBase.prototype._SetDefilementVertical;

// Decale les libelles de ruptures
WDVueAPHorizontale.prototype.__DecaleRuptureMoisSemaine = function __DecaleRuptureMoisSemaine(oStyle, nLigne, tabLargeur, nDefilementHorizontal)
{
	// Trouve le TR
	var tabTR = this.m_oHoteTitresHorizontal.getElementsByTagName("tr");
	if (tabTR && tabTR.length && tabTR[nLigne])
	{
		var oTR = tabTR[nLigne];

		// Parcours les td
		var tabTD = oTR.getElementsByTagName("td");
		// Si on a bien les elements (et que l'on en a le bon nombre
		if (tabTD && tabTD.length && tabTD.length == tabLargeur.length)
		{
			var nLargeurTotale = 0;
			var i;
			var nLimiteI = tabTD.length;
			for (i = 0; i < nLimiteI; i++)
			{
				// On stocke la dimension avec bordure (pour le decalage)
				var nLargeur = tabLargeur[i];
				// Et on utilise la dimension avec bordure en interne
				var nLargeurSansBordure = this.__nGetDimensionPxSansBordure(nLargeur, oStyle);
				var oTD = tabTD[i];
				// Si le mois est le premier visible
				if ((nDefilementHorizontal >= nLargeurTotale) && (nDefilementHorizontal <= (nLargeurSansBordure + nLargeurTotale)))
				{
					// Force le defilement de l'element
					this.__DecaleUneRuptureMoisSemaine(oTD, nDefilementHorizontal - nLargeurTotale, nLargeurSansBordure);
				}
				else
				{
					// Stope le defilement de l'element
					this.__DecaleUneRuptureMoisSemaine(oTD, 0, nLargeurSansBordure);
				}
				nLargeurTotale += nLargeur;
			}
		}
	}
};

// Decale un libelle de mois
WDVueAPHorizontale.prototype.__DecaleUneRuptureMoisSemaine = function __DecaleUneRuptureMoisSemaine(oTD, nDecalage, nLargeur)
{
	(oTD.style.paddingLeft = (0 != nDecalage) ? (nDecalage + "px") : "");
	oTD.style.width = Math.max((bIEQuirks9Max ? 1 : 0), (nLargeur - nDecalage)) + "px";

	// 218977 : Il faut tenir compte du padding pour les appels de _vOnDefilementCorps
	var sLargeur = Math.max((bIEQuirks9Max ? 1 : 0), (nLargeur - nDecalage - this.ms_nPaddingTitreCalcul)) + "px";
	oTD.firstChild.style.width = sLargeur;
	oTD.firstChild.style.minWidth = sLargeur;
	oTD.firstChild.style.maxWidth = sLargeur;
	if (!bIEQuirks9Max)
	{
		var sPaddingLeft = "";
		var sPaddingRight = "";
		if (nLargeur - nDecalage < this.ms_nPaddingTitre)
		{
			sPaddingLeft = "0xp";
			sPaddingRight = Math.max(0, nLargeur - nDecalage) + "px";
		}
		else if (nLargeur - nDecalage < this.ms_nPaddingTitreCalcul)
		{
			sPaddingLeft = Math.max(0, nLargeur - nDecalage - this.ms_nPaddingTitre) + "px";
		}
		oTD.firstChild.style.paddingLeft = sPaddingLeft;
		oTD.firstChild.style.paddingRight = sPaddingRight;
	}
};

// En mode quirks, il y a le padding en plus
// - En mode ressources en ligne, c'est le padding "avant" => this.ms_nPaddingLateralDebut
// - En mode ressources en colonne, c'est le padding "apres" => this.ms_nPaddingLateralFin
WDVueAPHorizontale.prototype._vnGetPaddingTopPourRendezVous = function _vnGetPaddingTopPourRendezVous()
{
	return (bIEQuirks9Max ? this.ms_nPaddingLateralDebut : 0);
};
WDVueAPHorizontale.prototype._vnGetPaddingRightPourRendezVous = function _vnGetPaddingRightPourRendezVous()
{
	return 0;
//	return bIEQuirks9Max ? 0 : 0;
};

// Retourne offsetLeft (ressources en ligne) ou offsetTop (ressources en colonne)
WDVueAPHorizontale.prototype.voGetOffsetDebut = function voGetOffsetDebut(oElement)
{
	return oElement.offsetLeft;
};
// Retourne offsetWidth (ressources en ligne) ou offsetHeight (ressources en colonne)
WDVueAPHorizontale.prototype.voGetOffsetLongueur = function voGetOffsetLongueur(oElement)
{
	return oElement.offsetWidth;
};
WDVueAPHorizontale.prototype.vbGetVertical = function vbGetVertical()
{
	return false;
};


// Retourne le deplacement important pour la position : X (ressources en ligne) ou Y (ressources en colonne)
WDVueAPHorizontale.prototype.vnGetOffsetPosition = function vnGetOffsetPosition(nOffsetPositionX/*, nOffsetPositionY*/)
{
	return nOffsetPositionX;
};
// Retourne la coordonnee importante pour la position : X (ressources en ligne) ou Y (ressources en colonne) selon le conteneur hote
WDVueAPHorizontale.prototype.vnGetPositionHote = function vnGetPositionHote(oElement, nPositionX, nPositionY, bVersEcran)
{
	return this._nGetPositionHote(oElement, nPositionX, true, bVersEcran);
};

// Appel de _sGetHTMLRendezVous avec les bonnes dimensions
WDVueAPHorizontale.prototype._vsGetHTMLRendezVous = WDVueAPBase.prototype._sGetHTMLRendezVous;

WDVueAPHorizontale.prototype._vnDimensionHorizontalRendezVousTitreSeul = function _vnDimensionHorizontalRendezVousTitreSeul(oParametres, oDimensionLaterale, nDateDebut, nDateFin, nDateReference)
{
	var nNbGraduationsParJour = (oParametres.m_nHeureAfficheMax - oParametres.m_nHeureAfficheMin) / 3600000;
	var nDimensionLateralUnJour = this.vnGetDimensionPxGraduation(oParametres) * nNbGraduationsParJour;
	// GP 26/03/2013 : QW231469 : Et on tient compte du nombre de jours du rendez-vous
	var nJourDebut = Math.floor(nDateDebut / 86400000);
	var nJourFin = Math.floor(nDateFin / 86400000);
	var nNbJoursRendezVous = nJourFin - nJourDebut + 1;

	var nDimensionLateralRendezVous = nDimensionLateralUnJour * nNbJoursRendezVous;
	var nDebut = nDimensionLateralUnJour * Math.floor((nDateDebut - nDateReference) / 86400000);

	oDimensionLaterale.m_oDebut = nDebut;
	oDimensionLaterale.m_oLongueur = nDimensionLateralRendezVous;

	return nDimensionLateralRendezVous
};

//////////////////////////////////////////////////////////////////////////
// Manipulation d'un champ planning
function WDPlanning(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDAPBase.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
	}
}

// Declare l'heritage
WDPlanning.prototype = new WDAPBase();
// Surcharge le constructeur qui a ete efface
WDPlanning.prototype.constructor = WDPlanning;
var WDPlanningVertical = WDPlanning;
var WDPlanningHorizontal = WDPlanning;

//////////////////////////////////////////////////////////////////////////
// Membres statiques
WDPlanning.prototype.ms_eModeRessourcesEnLignes = 0;
WDPlanning.prototype.ms_eModeRessourcesEnColonnes = 1;

//////////////////////////////////////////////////////////////////////////
// Methodes virtuelles generales

//////////////////////////////////////////////////////////////////////////
// Methodes virtuelles

// Retourne la classe de la vue
WDPlanning.prototype._voGetClasseVue = function _voGetClasseVue()
{
	return (this.ms_eModeRessourcesEnLignes === this.m_oParametres.m_eModeAffichage) ? WDVueAPHorizontale : WDVueAPVerticale;
};

// Recupere le tableau des conteneurs (pour l'initialisation)
WDPlanning.prototype._vtabCreeConteneurs = function _vtabCreeConteneurs()
{
	if (this.m_oDonnees.m_tabRessources)
	{
		// Si on a un tableau des ressources, c'est que l'on n'est pas en fusion
		var tabConteneurs = this.m_oDonnees.m_tabRessources;
		(this.m_oDonnees.m_tabRessources = null);
		delete this.m_oDonnees.m_tabRessources;

		return tabConteneurs;
	}
	else
	{
		// Sans tableau des ressources (on doit �tre en fusion) : utilise le pr�c�dent tableau
		return this._tabGetConteneurs(false);
	}
};

// Trouve le conteneur d'un rendez-vous
WDPlanning.prototype._vnGetRendezVousConteneur = function _vnGetRendezVousConteneur(oRendezVous)
{
	return oRendezVous.m_nRessource;
};

// Notifie du changement de conteneur d'un rendez-vous
WDPlanning.prototype._vChangeRendezVousConteneur = function _vChangeRendezVousConteneur(oRendezVous, nConteneur/*, nOldConteneur*/)
{
	// Appel de la methode de la classe de base
	WDAPBase.prototype._vChangeRendezVousConteneur.apply(this, arguments);

	// Maj du membre sp�cifique des plannings
	oRendezVous.m_nRessource = nConteneur;
};

//////////////////////////////////////////////////////////////////////////
// Manipulation d'un champ agenda
var WDAgenda = (function ()
{
	//////////////////////////////////////////////////////////////////////////
	// Vue des agendas
	var WDVueAgendaBase = (function ()
	{
		function __WDVueAgendaBase(/*oChampAP*//*, oVuePrecedente*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDVueAPVerticale.prototype.constructor.apply(this, arguments);
			}
		}

		// Declare l'heritage
		__WDVueAgendaBase.prototype = new WDVueAPVerticale();
		// Surcharge le constructeur qui a ete efface
		__WDVueAgendaBase.prototype.constructor = __WDVueAgendaBase;

		//////////////////////////////////////////////////////////////////////////
		// Dimensions
		__WDVueAgendaBase.prototype._nGetDimensionPxGraduationSelonNbLignes = function _nGetDimensionPxGraduationSelonNbLignes(oParametres, nNbLignes)
		{
			// GP 27/10/2014 : QW250667 : La hauteur disponible n'est pas la hauteur totale du corps mais la hauteur totale MOINS la zone de rendez-vous � la journ�e.
			var nHauteurTotaleDisponible = this.m_nHauteurCorps;
			if (oParametres.m_nHauteurZoneJourneeComplete)
			{
				nHauteurTotaleDisponible -= oParametres.m_nHauteurZoneJourneeComplete;
			}
			// Calcule le nombre d'heures affich�es et divise par la hauteur disponible
			var nGetDimensionPxGraduation = Math.floor(nHauteurTotaleDisponible / nNbLignes);

			// QW223559 : En IEQuirks, si le calcul tombe exact, les graduations prennent exactement la place
			// Sauf que le premier TD en haut (celui qui contient les fonds en superpos�) prend un de haut
			if (bIEQuirks9Max && 0 === this.m_nHauteurCorps % nNbLignes)
			{
				nGetDimensionPxGraduation--;
			}
			return nGetDimensionPxGraduation;
		};

		__WDVueAgendaBase.prototype.vnGetDimensionPxGraduation = function vnGetDimensionPxGraduation(oParametres)
		{
			// Precalculs si besoin
			this.__CorrigeParametres(oParametres);

			// Calcule le nombre d'heures affich�es et divise par la hauteur disponible
			var nNbHeures = (oParametres.m_nHeureAfficheMaxOriginal - oParametres.m_nHeureAfficheMinOriginal) / 3600000;
			// GP 21/11/2012 : QW223559 : factorisation partielle avec WDVueAgendaMois.prototype.vnGetDimensionPxGraduation
			return this._nGetDimensionPxGraduationSelonNbLignes(oParametres, nNbHeures);
		};

		__WDVueAgendaBase.prototype.voGetDateFinAffichage = function voGetDateFinAffichage(oParametres)
		{
			// On n'affiche que un jour
			return clWDUtil.oDecaleDateJour(new Date(oParametres.m_oDateDebut), 1, true);
		};

		// Calcule la position en pixel du debut d'un rendez-vous
		__WDVueAgendaBase.prototype._vnGetDebutRendezVous = function _vnGetDebutRendezVous(oParametres, oRendezVous, nDate, nDateReference)
		{
			// Il faut d�caler la date pour tenir compte que les conteneurs divisent le temps
			return WDVueAPVerticale.prototype._vnGetDebutRendezVous.apply(this, [oParametres, oRendezVous, nDate - this.m_oChampAP.nGetRendezVousConteneur(oRendezVous) * 86400000, nDateReference]);
		};

		// R�cup�re les styles horizontaux (sans cache)
		__WDVueAgendaBase.prototype._vtabGetStylesHorizontaux = function _vtabGetStylesHorizontaux(oParametres)
		{
			// Dans le cas d'un agenda � la journ�e :
			// - (Toujours) La ligne du nom des jours
			return [oParametres.m_oStyleLibJourSemaine];
		};

		// Hauteur de la ligne des titres horizontaux
		__WDVueAgendaBase.prototype._vnGetHauteurTitresHorizontaux = function _vnGetHauteurTitresHorizontaux(oParametres, nNbLignes)
		{
			if (oParametres.m_bLigneTitreSemaine)
			{
				nNbLignes++;
			}

			return WDVueAPVerticale.prototype._vnGetHauteurTitresHorizontaux.apply(this, [oParametres, nNbLignes]);
		};

		// Hauteur de la rupture des jours
		// => Ignore le comportement surcharg� de WDVueAPVerticale
		__WDVueAgendaBase.prototype._vnGetHauteurRuptureJour = WDVueAPBase.prototype._vnGetHauteurRuptureJour;

		// Calcule la position en pixel du debut d'un rendez-vous en mode "TitreSeul" (tous les rendez-vous de l'agenda)
		__WDVueAgendaBase.prototype._vnGetDebutRendezVousTitreSeul = WDVueAPBase.prototype._vnGetDebutRendezVousTitreSeul;

		// Si on affiche toutes les heures : oui sauf si demande
		__WDVueAgendaBase.prototype._vbAfficheTouteslesHeures = function _vbAfficheTouteslesHeures(oParametres)
		{
			// GP 24/10/2014 : QW250584 : Pour le cas PHP qui ne retourne pas la valeur (car undefined !== false)
			return false !== oParametres.m_bAccesAuxHeuresNonAffichees;
		};

		// Initialise les styles
		__WDVueAgendaBase.prototype._vInitCSS = function _vInitCSS(oParametres)
		{
			// GP 24/10/2014 : QW250461
			// GP 24/10/2014 : QW250584 : Pour le cas PHP qui ne retourne pas la valeur (car undefined !== false)
			if (false === oParametres.m_bAccesAuxHeuresNonAffichees)
			{
				this.__StyleCree(this.__sGetSelecteur(this.ms_sNomGeneralSpecifique, "", this.ms_sNomCorps), ["overflow-y:auto"]);
			}

			return WDVueAPVerticale.prototype._vInitCSS.apply(this, arguments);
		};

		__WDVueAgendaBase.prototype._vInitCSS_TitresHeuresAgenda = __WDVueAgendaBase.prototype._vInitCSS_TitresHeures;

		return __WDVueAgendaBase;
	})();


	//////////////////////////////////////////////////////////////////////////
	// Vue � la journ�e de l'agenda
	var WDVueAgendaJournee = (function ()
	{
		function __WDVueAgendaJournee(/*oChampAP*//*, oVuePrecedente*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDVueAgendaBase.prototype.constructor.apply(this, arguments);
			}
		}

		// Declare l'heritage
		__WDVueAgendaJournee.prototype = new WDVueAgendaBase();
		// Surcharge le constructeur qui a ete efface
		__WDVueAgendaJournee.prototype.constructor = __WDVueAgendaJournee;

		// Si on a une zone de "TitreSeul" ind�pedante, est-elle externe
		__WDVueAgendaJournee.prototype.ms_bZoneTitreSeulIndependanteExterne = true;

		// Construit la zone des rendez vous
		__WDVueAgendaJournee.prototype._vtabHTMLAfficheCorps = function _vtabHTMLAfficheCorps(oParametres/*, tabHTML*/)
		{
			var i;
			var nLimiteI;

			// Si on a une zone � la journ�e enti�re : l'affiche
			if (oParametres.m_nHauteurZoneJourneeComplete)
			{
				var tabHTML2 = [];

				// On construit en parallele les DIVs pour la couleur de fond et pour la couleur
				var tabHTMLFondCouleur = this.__tabHTMLAfficheCorpsHeureDebut(this.ms_sNomFondCouleur);
				var tabHTMLFondBordure = this.__tabHTMLAfficheCorpsHeureDebut(this.ms_sNomFondBordure);

				// Selon la position des heures initialise
				// On prend le premier �l�ments de chaque jour pour avoir le style de fond
				var tabGraduations = this.m_tabGraduations;
				var nColonne;
				var nNbColonnes = this._vnGetNbGraduationsParalleles(oParametres);
				var nNbLignes = tabGraduations.length / nNbColonnes;
				for (nColonne = 0; nColonne < nNbColonnes; nColonne++)
				{
					var nGraduation = nColonne * nNbLignes;
					var oGraduation = tabGraduations[nGraduation];
					var oJour = oParametres.m_tabJours[nColonne];

					var nJourStyleAvecAujourdhui = oJour.m_bAujourdhui ? 2 : this._nGetHeureStyle(oGraduation.m_oDateDebut.getDay(), oJour);
					var oStyleJourStyleAvecAujourdhui = oParametres["m_oStyle" + this._sGetHeureSuffixe(nJourStyleAvecAujourdhui, false)];
					var sClassesJour = oStyleJourStyleAvecAujourdhui.m_sClasses;
					var sCouleurFond;
					if (0 < nJourStyleAvecAujourdhui)
					{
						// Si on a un style d'heure non standard on reforce la couleur de fond
						sCouleurFond = oStyleJourStyleAvecAujourdhui.m_cFond;
					}
					else
					{
						sCouleurFond = undefined;
					}

					// La partie avec la couleur : dessous : div vide
					this.__HTMLAfficheDiv(tabHTMLFondCouleur, this.ms_sNomJourneeComplete + (sClassesJour ? " " + sClassesJour : ""), undefined, undefined, sCouleurFond);
					// La partie avec les bordures : dessous : div vide
					this.__HTMLAfficheDiv(tabHTMLFondBordure, this.ms_sNomJourneeComplete + " " + oGraduation.m_sClasses);
				}

				// Ferme les tableaux et les fusionne avec le tableau global
				tabHTMLFondCouleur.push("</div>");
				tabHTML2 = tabHTML2.concat(tabHTMLFondCouleur);
				tabHTMLFondBordure.push("</div>");
				tabHTML2 = tabHTML2.concat(tabHTMLFondBordure);

				tabHTML2.push("<div>");

				// Affiche les DIV pour la zone � la journ�e complete
				nLimiteI = this.m_oChampAP._nGetNbConteneurs(false);
				for (i = 0; i < nLimiteI; i++)
				{
					this.__HTMLAfficheDiv(tabHTML2, this.ms_sNomConteneurTitreSeul, this.__sGetNomElement(this._sGetIDConteneur(oParametres, i, true)));
				}
				tabHTML2.push("</div>");

				this.m_oHoteCorpsTitreSeulIndependant.innerHTML = tabHTML2.join("");
			}
			// Ce qui en fait est fait automatiquement par la classe de base de WDVueAgendaBase (WDVueAPVerticale
			return WDVueAgendaBase.prototype._vtabHTMLAfficheCorps.apply(this, arguments);
		};

		//////////////////////////////////////////////////////////////////////////
		// Dimensions

		// Touve le conteneur des rendez-vous d'une ressource
		// Ignore le comportement de l'affichage vertical (qui fusionne les conteneurs)
		__WDVueAgendaJournee.prototype._vnGetHauteurZoneTitreSeulIndependante = WDVueAPBase.prototype._vnGetHauteurZoneTitreSeulIndependante;
		__WDVueAgendaJournee.prototype._vnGetReductionLateraleRendezVousPourZoneTitreSeulIndependante = function _vnGetReductionLateraleRendezVousPourZoneTitreSeulIndependante(/*oParametres*/)
		{
			return 0;
		};

		return __WDVueAgendaJournee;
	})();

	//////////////////////////////////////////////////////////////////////////
	// Vue � la semaine de l'agenda
	var WDVueAgendaSemaine = (function ()
	{
		function __WDVueAgendaSemaine(/*oChampAP*//*, oVuePrecedente*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDVueAgendaJournee.prototype.constructor.apply(this, arguments);
			}
		}

		// Declare l'heritage
		__WDVueAgendaSemaine.prototype = new WDVueAgendaJournee();
		// Surcharge le constructeur qui a ete efface
		__WDVueAgendaSemaine.prototype.constructor = __WDVueAgendaSemaine;

		// Si on r�ordonne les graduations en affichage
		__WDVueAgendaSemaine.prototype.ms_bReordonneGraduationAffichage = true;

		// Nombre de graduations en parallele (= sur la m�me ligne/colonne)
		__WDVueAgendaSemaine.prototype._vnGetNbGraduationsParalleles = function _vnGetNbGraduationsParalleles(oParametres)
		{
			// Nombre de jours de la semaine
			return oParametres.m_nNbJoursSemaine;
		};

		// Dimension (lat�rale) d'une graduation
		// Prend la largeur d'un conteneur car on a normalement n conteneur (un par jour de la semaine)
		__WDVueAgendaSemaine.prototype._vnGetDimensionLateralePxGraduation = WDVueAPBase.prototype._nGetDimensionLateralePxConteneur;

		// R�cup�re les styles horizontaux (sans cache)
		__WDVueAgendaSemaine.prototype._vtabGetStylesHorizontaux = function _vtabGetStylesHorizontaux(oParametres)
		{
			// Dans le cas d'un agenda � la semaine :
			// - (Optionnel) La ligne des num�ro de semaine
			// - (Toujours) La ligne du nom des jours
			var tabStylesHorizontaux = [];
			if (oParametres.m_bLigneTitreSemaine)
			{
				tabStylesHorizontaux.push(oParametres.m_oStyleLibNumeroSemaine);
			}
			tabStylesHorizontaux.push(oParametres.m_oStyleLibJourSemaine);

			return tabStylesHorizontaux;
		};

		__WDVueAgendaSemaine.prototype.voGetDateFinAffichage = function voGetDateFinAffichage(oParametres)
		{
			// Nombre de jours de la semaine
			return clWDUtil.oDecaleDateJour(new Date(oParametres.m_oDateDebut), oParametres.m_nNbJoursSemaine, true);
		};

		return __WDVueAgendaSemaine;
	})();

	//////////////////////////////////////////////////////////////////////////
	// Vue mois
	var WDVueAgendaMois = (function ()
	{
		function __WDVueAgendaMois(/*oChampAP*//*, oVuePrecedente*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDVueAgendaBase.prototype.constructor.apply(this, arguments);
			}
		}

		// Declare l'heritage
		__WDVueAgendaMois.prototype = new WDVueAgendaBase();
		// Surcharge le constructeur qui a ete efface
		__WDVueAgendaMois.prototype.constructor = __WDVueAgendaMois;

		// Si on affiche un libell� dans chaque graduation
		__WDVueAgendaMois.prototype.ms_bLibelleParGraduation = true;

		// Methode d'initialisation generale de la classe (ne s'execute que lors de l'init de la premi�re instance de ce type)
		__WDVueAgendaMois.prototype._vInitInitiale = function _vInitInitiale()
		{
			// Appel de la methode de la classe de base
			WDVueAgendaBase.prototype._vInitInitiale.apply(this, arguments);

			// GP 13/03/2013 : QW230834 : Damande de SYC : force un blanc tournant (normalement moins prioritaire que si c'est d�fini en �dition (qui viens surcharger)
			// dans un SPAN pour ne pas casser la taille de l'�lement au dessus
			// Le padding ne marche pas (selon le style et l'alignement, le navigateur peut faire afficher l'�lement en -padding (pour le top) ce qui reviens a ne pas avoir de padding)
//			this.__StyleCreeGlobal("." + this.ms_sNomFondBordure + " div", ["padding: 2px 2px 2px 2px", "margin: 0px -4px -4px 0px"]);
//			this.__StyleCreeGlobal("." + this.ms_sNomFondBordure + " div span", ["padding: 2px 2px 2px 2px", "float:left"]);
			this.__StyleCreeGlobal("." + this.ms_sNomFondBordure + " div span", ["margin: 2px 2px 2px 2px", "float:left"]);
		};

		//////////////////////////////////////////////////////////////////////////
		// Styles

		// R�cup�re les styles horizontaux (sans cache)
		// => Comme � la journ�e : une seule ligne avec le nom des jours (seulement le nom ici et pas nom + num�ro)
//		__WDVueAgendaMois.prototype._vtabGetStylesHorizontaux = function _vtabGetStylesHorizontaux(oParametres)

		//////////////////////////////////////////////////////////////////////////
		// Dimensions

		__WDVueAgendaMois.prototype._vnGetDureeMsFromPosAlignResolution = function _vnGetDureeMsFromPosAlignResolution(oParametres, nPosition, oGraduation, nHeureJourMs/*, bAvecAlignementSurLaGrille*/)
		{
			return nHeureJourMs;
		};

		__WDVueAgendaMois.prototype.vnGetDimensionPxGraduation = function vnGetDimensionPxGraduation(oParametres)
		{
			// GP 21/11/2012 : QW223559 : factorisation partielle avec WDVueAgendaJournee.prototype.vnGetDimensionPxGraduation
			// Toujours 6 lignes pour les jours
			return this._nGetDimensionPxGraduationSelonNbLignes(oParametres, 6);
		};

		__WDVueAgendaMois.prototype.voGetDateFinAffichage = function voGetDateFinAffichage(oParametres)
		{
			// Toujours 6 lignes de 7 jours
			return clWDUtil.oDecaleDateJour(new Date(oParametres.m_oDateDebut), 42, true);
		};

		// Calcule la position en pixel du debut d'un rendez-vous en mode "TitreSeul" (tous les rendez-vous de l'agenda)
		__WDVueAgendaMois.prototype._vnGetDebutRendezVousTitreSeul = function _vnGetDebutRendezVousTitreSeul(oParametres, oSuperpositionInfo, nDate, nDateReference)
		{
			// Si on a le libell� en haut : lui conserve de la place
			var nEspaceReserve = 25;
			var nDimensionPxVerticale = this.vnGetDimensionPxGraduation(oParametres);
			// Calcule le d�but du jour dans le conteneur
			var nDebutDansConteneur = nDimensionPxVerticale * Math.floor(Math.floor((nDate - nDateReference) / 86400000) / 7);

			return this._nGetHautRendezVousTitreSeul(oParametres, oSuperpositionInfo, nDebutDansConteneur, nEspaceReserve, nDimensionPxVerticale);
		};

		// Nombre de graduations en parallele (= sur la m�me ligne/colonne)
		__WDVueAgendaMois.prototype._vnGetNbGraduationsParalleles = function _vnGetNbGraduationsParalleles(/*oParametres*/)
		{
			// 7 jours dans la semaine
			return 7;
		};

		// Dimension (lat�rale) d'une graduation
		// Prend la largeur d'un conteneur car on a normalement 7 conteneur (un par jour de la semaine)
		__WDVueAgendaMois.prototype._vnGetDimensionLateralePxGraduation = WDVueAPBase.prototype._nGetDimensionLateralePxConteneur;

		// Si on affiche seulement le titre du rendez-vous
		__WDVueAgendaMois.prototype._vbJourneeEntiere = function _vbJourneeEntiere(/*oParametres*//*, bJourneeEntiere*/)
		{
			// Toujours dans la cas de la vue au mois
			return true;
		};

		//////////////////////////////////////////////////////////////////////////
		// Methodes virtuelles

//		_vInitInitiale
//		vSetDebut
//		vSetLongueur
//		vSetDebutLateral
//		vSetLongueurLateral
//		_vInitCSS_LibJour
//		_vOnDefilementCorps
//		_vtabInitCSS_DimensionPxPrincipale
//		_vtabInitCSS_DimensionPxLaterale
//		_vtabInitCSS_BorduresPerpendiculaires
//		_vtabInitCSS_BorduresLaterales
//		_vnGetDimensionClienteLaterale
//		_vnDimensionLateralePxCorps
//		_vHTMLAfficheTitresVertical
//		_vnGetDefilementPrincipal
//		_vnGetDefilementLateral
//		_vSetDefilementPrincipal
//		_vSetDefilementLateral
//		_vnGetPaddingTopPourRendezVous
//		_vnGetPaddingRightPourRendezVous
//		voGetOffsetDebut
//		voGetOffsetLongueur
//		vbGetVertical
//		vnGetOffsetPosition
//		vnGetPositionHote
//		_vsGetHTMLRendezVous

		return __WDVueAgendaMois;
	})();

	function __WDAgenda(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDAPBase.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
		}
	}

	// Declare l'heritage
	__WDAgenda.prototype = new WDAPBase();
	// Surcharge le constructeur qui a ete efface
	__WDAgenda.prototype.constructor = WDAgenda;

	//////////////////////////////////////////////////////////////////////////
	// Membres statiques
	var ms_eModeZoomJournee = 0;
	var ms_eModeZoomSemaine = 1;
	var ms_eModeZoomMois = 2;
//	var ms_eModeZoomAnnee = 3;

	//////////////////////////////////////////////////////////////////////////
	// Methodes virtuelles

	// Retourne la classe de la vue
	__WDAgenda.prototype._voGetClasseVue = function _voGetClasseVue()
	{
		switch (this.m_oParametres.m_eModeZoom)
		{
		default:
		case ms_eModeZoomJournee:
			return WDVueAgendaJournee;
		case ms_eModeZoomSemaine:
			return WDVueAgendaSemaine;
		case ms_eModeZoomMois:
			return WDVueAgendaMois;
		}
	};

	// Recupere le tableau des conteneurs (pour l'initialisation)
	__WDAgenda.prototype._vtabCreeConteneurs = function _vtabCreeConteneurs()
	{
		// Ici on ne peut pas utiliser la vue car elle n'est pas encore initialisee
		switch (this.m_oParametres.m_eModeZoom)
		{
		default:
		case ms_eModeZoomJournee:
		case ms_eModeZoomSemaine:
			return this.__tabCreeConteneursJour();
		case ms_eModeZoomMois:
			return this.__tabCreeConteneursMois();
		}
	};

	// Recupere le tableau des conteneurs (pour l'initialisation) dans le cas d'un affichage au jour ou a la semaine
	__WDAgenda.prototype.__tabCreeConteneursJour = function __tabCreeConteneursJour()
	{
		// Construit le tableau avec les jours affich�s
		var tabConteneurs = [];

		var tabJours = this.m_oParametres.m_tabJours;
		var i;
		var nLimiteI = tabJours.length;
		for (i = 0; i < nLimiteI; i++)
		{
			tabConteneurs.push({ m_sNomAffiche : tabJours[i].m_sLibelle });
		}

		return tabConteneurs;
	};
	// Recupere le tableau des conteneurs (pour l'initialisation) dans le cas d'un affichage au mois
	__WDAgenda.prototype.__tabCreeConteneursMois = function __tabCreeConteneursMois()
	{
		// Construit le tableau avec les jours affich�s
		var tabConteneurs = [];

		var tabNomJoursSemaine = this.m_oParametres.m_tabNomJoursSemaine;
		var i;
		var nLimiteI = tabNomJoursSemaine.length;
		for (i = 0; i < nLimiteI; i++)
		{
			tabConteneurs.push({ m_sNomAffiche : tabNomJoursSemaine[i] });
		}

		return tabConteneurs;
	};

	// Trouve le conteneur d'un rendez-vous
	__WDAgenda.prototype._vnGetRendezVousConteneur = function _vnGetRendezVousConteneur(oRendezVous)
	{
		// Calcule le conteneur en fonction du de la position du rendez-vous et de la disposition
		var nDateDebutAffichage = new Date(this.m_oParametres.m_oDateDebut).setUTCHours(0, 0, 0, 0);
		var nDateFinAffichage = this.m_oParametres.m_oDateFin.getTime();
		var nDateDebutRendezVous = oRendezVous.m_oDateDebut.getTime();

		var nJour;
		var nConteneur = 0;
		// 86400000 = 24 * 3600 * 1000 = 1 jour en ms
		for (nJour = nDateDebutAffichage, nConteneur = 0; nJour < nDateFinAffichage; nJour += 86400000, nConteneur++)
		{
			if (nDateDebutRendezVous < nJour + 86400000)
			{
				switch (this.m_oParametres.m_eModeZoom)
				{
				default:
				case ms_eModeZoomJournee:
				case ms_eModeZoomSemaine:
					return nConteneur;
				case ms_eModeZoomMois:
					return nConteneur % 7;
				}
			}
		}

		// Non trouve
		return 0;
	};

	// GP 13/02/2013 : QW229802 : R�activer pour ne pas faire des rendez-vous vide dans le conteneur
	// GP 31/10/2012 : QW223401 : On fait des graduation par conteneur, il n'y a plus besoin de ce code le jour est correct maintenant
//	// Notifie du changement de conteneur d'un rendez-vous
	__WDAgenda.prototype._vChangeRendezVousConteneur = function _vChangeRendezVousConteneur(oRendezVous/*, nConteneur*//*, nOldConteneur*/)
	{
		// Appel de la methode de la classe de base
		WDAPBase.prototype._vChangeRendezVousConteneur.apply(this, arguments);

		if (this.m_oParametres.m_eModeZoom === ms_eModeZoomMois && oRendezVous.m_oDateDebut.getTime() === oRendezVous.m_oDateFin.getTime())
		{
			oRendezVous.m_oDateFin.setUTCHours(23, 59, 59, 999);
		}

//		// GP 31/10/2012 : QW223401 : On fait des graduation par conteneur, il n'y a plus besoin de ce code le jour est correct maintenant
//		// Decale la date du rendez-vous si on est a la semaine
//		// A la journ�e : pas besoin
//		// Au mois : c'est plus compliqu� et "d�j�" fait
//		if ((this.m_oParametres.m_eModeZoom == ms_eModeZoomSemaine) && (nOldConteneur != nConteneur))
//		{
//			clWDUtil.oDecaleDateJour(oRendezVous.m_oDateDebut, nConteneur - nOldConteneur);
//			clWDUtil.oDecaleDateJour(oRendezVous.m_oDateFin, nConteneur - nOldConteneur);
//		}
	};

	return __WDAgenda;
})();

//////////////////////////////////////////////////////////////////////////
// Le gestionnaire de dragdrop pour les champs agenda et planning : gestion des ressources et d'un fantome

// Constructeur
function WDDragAP (nDelaiAvantDeplacement, nDelaiEntreDeplacement, oChamp)
{
	// Si on est pas dans l'init d'un protoype
	if (nDelaiAvantDeplacement !== undefined)
	{
		// Appel le constructeur de la classe de base
		WDDrag.prototype.constructor.apply(this, [nDelaiAvantDeplacement, nDelaiEntreDeplacement]);

		// Sauve l'objet attache
		this.m_oChamp = oChamp;
	}
}

// Declare l'heritage
WDDragAP.prototype = new WDDrag();
// Surcharge le constructeur qui a ete efface
WDDragAP.prototype.constructor = WDDragAP;

// Gestion pour un element
WDDragAP.prototype.vInitElement = function vInitElement(oElement, nElement, oDiv, oDivTitreSeul)
{
	// Intercepte le mousedown sur le rendez-vous ou sur le conteneur
	var oThis = this;
	oElement.m_fMouseDown = function(oEvent) { return oThis.bOnMouseDown(oEvent || event, oElement, nElement, false) ? oThis._bStopPropagation(oEvent) : true; };
	this._AttacheDetacheMouseDown(true, oDiv, oElement.m_fMouseDown);
	if (oDivTitreSeul && oDivTitreSeul !== oDiv)
	{
		oElement.m_fMouseDownTitreSeul = function(oEvent) { return oThis.bOnMouseDown(oEvent || event, oElement, nElement, true) ? oThis._bStopPropagation(oEvent) : true; };
		this._AttacheDetacheMouseDown(true, oDivTitreSeul, oElement.m_fMouseDownTitreSeul);
	}
};
WDDragAP.prototype.vLibereElement = function vLibereElement(oElement, oDiv, oDivTitreSeul)
{
	// Supprime l'evenement mousedown sur le rendez-vous ou sur le conteneur
	if (oDivTitreSeul && oDivTitreSeul !== oDiv)
	{
		this._AttacheDetacheMouseDown(false, oDivTitreSeul, oElement.m_fMouseDownTitreSeul);
		oElement.m_fMouseDownTitreSeul = null;
	}
	this._AttacheDetacheMouseDown(false, oDiv, oElement.m_fMouseDown);
	oElement.m_fMouseDown = null;
};

// Appel lors du debut d'un clic pour le deplacement
// Pose les hooks
WDDragAP.prototype._vbOnMouseDown = function _vbOnMouseDown(/*oEvent*/)
{
	// Pas de drag-drop si on est en saisie
	if (this.m_oChamp.m_oPopupSaisie.m_oRendezVous)
	{
		return false;
	}

	// Appel de la classe de base : sauve la position de la souris et place les hooks
	if (!WDDrag.prototype._vbOnMouseDown.apply(this, arguments))
	{
		return false;
	}

	// Suppression du fantome : on est sur de ne plus avoir un ancien fantome
	this.__FantomeSupprime();

	return true;
};

// Appel lors du deplacement de la souris
WDDragAP.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
{
	// Appel de la classe de base
	WDDrag.prototype._vOnMouseMove.apply(this, arguments);

	// Cr�ation ou d�placement du fantome.
	// _vFantomeCreeDeplace est redefinie dans les classes derivees et transmet les parametres a _FantomeCree et _FantomeDeplace.
	this._vFantomeCreeDeplace(oEvent);
};

// Appel lors du relachement de la souris
WDDragAP.prototype._vOnMouseUp = function _vOnMouseUp(/*oEvent*/)
{
	// Si besoin il faut que la fonction dans la classe derivee fasse une derniere MAJ du Fantome
//	this._vFantomeCreeDeplace(oEvent);

	// Suppression du fantome
	this.__FantomeSupprime();

	// Appel de la classe de base
	WDDrag.prototype._vOnMouseUp.apply(this, arguments);
};

// Cr�ation ou d�placement du fantome (a redefinir).
// _vFantomeCreeDeplace est redefinie dans les classes derivees et transmet les parametres a _FantomeCree et _FantomeDeplace.
WDDragAP.prototype._vFantomeCreeDeplace = clWDUtil.m_pfVide;

// Creation du fantome
WDDragAP.prototype._FantomeCree = function _FantomeCree(nDebut, nLongueur, nConteneur, bTitreSeul, sCouleur, bPlaceDebut)
{
	// On a d�j� v�rifi� que le fantome n'existait pas.
	clWDUtil.WDDebug.assert(!this.m_oDivFantome);

	// Creation du fantome
	var oDivFantome = document.createElement("div");
	oDivFantome.style.position = "absolute";

	// Positionne le fantome pour prendre toute la place et le dimensionne au meme endroit que le rendez-vous
	this.m_oChamp.m_oVue.nHTMLAfficheUnRendezVousSuperposition(this.m_oChamp.m_oParametres, oDivFantome, { m_bTitreSeul : bTitreSeul, m_nSuperposition: 0, m_nNbSuperpositions: 1 }, 0 === nConteneur);
	this.m_oChamp.m_oVue.vSetDebut(oDivFantome, nDebut);
	this.m_oChamp.m_oVue.vSetLongueur(oDivFantome, nLongueur);

	this.m_nDivFantomeDebut = nDebut;
	this.m_nDivFantomeLongueur = nLongueur;

	oDivFantome.style.backgroundColor = sCouleur ? sCouleur : "#cccccc";
	// GP 12/11/2012 : En fait il n'y a pas besoin d'affecter la valeur dans le style.opacity c'est fait par la fonction en interne
	clWDUtil.nSetOpacite(60, oDivFantome);
	// Colle le fantome au premier plan
	oDivFantome.style.zIndex = this.m_oChamp.m_oVue.ms_nZIndexFantome;
	// Et masque le bouton de suppression pour qu'il ne passe pas dessus
	if (this.m_oChamp.m_oRendezVousSuppression)
	{
		this.m_oChamp.m_oRendezVousSuppression.style.visibility = "hidden";
	}

	var oConteneurDiv = this.m_oChamp.m_oVue.oGetConteneurDiv(this.m_oChamp.m_oParametres, nConteneur, bTitreSeul);
	this.m_oDivFantome = oConteneurDiv.appendChild(oDivFantome);
	this.m_nDivFantomeConteneur = nConteneur;
	this.m_bDivFantomeTitreSeul = bTitreSeul;

	if (bPlaceDebut)
	{
		// Ecrase la coordonnee pour avoir le deplacement par rapport au debut (permet d'avoir le fantome toujours sous le curseur)
		// On utilise vnGetOffsetPosition comme "filtre" (= le fait que vnGetOffsetPosition retourne la coordonne principale)
		var nDivFantomeDebutAbsolu = this.m_oChamp.m_oVue.vnGetPositionHote(oConteneurDiv, this.m_nDivFantomeDebut, this.m_nDivFantomeDebut, true);
		this.m_nPosX = this.m_oChamp.m_oVue.vnGetOffsetPosition(nDivFantomeDebutAbsolu, this.m_nPosX);
		this.m_nPosY = this.m_oChamp.m_oVue.vnGetOffsetPosition(this.m_nPosY, nDivFantomeDebutAbsolu);
	}
};

// Deplacement du fantome
WDDragAP.prototype._FantomeDeplace = function _FantomeDeplace(nDebut, nLongueur, nConteneur)
{
	// On a d�j� v�rifi� que le fantome existe pas.
	clWDUtil.WDDebug.assert(this.m_oDivFantome);

	this.m_oChamp.m_oVue.vSetDebut(this.m_oDivFantome, nDebut);
	this.m_oChamp.m_oVue.vSetLongueur(this.m_oDivFantome, nLongueur);

	// Changement de conteneur si besoin
	if (this.m_nDivFantomeConteneur !== nConteneur)
	{
		this.m_oDivFantome = clWDUtil.oSupprimeElement(this.m_oDivFantome);
		this.m_oDivFantome = this.m_oChamp.m_oVue.oGetConteneurDiv(this.m_oChamp.m_oParametres, nConteneur, this.m_bDivFantomeTitreSeul).appendChild(this.m_oDivFantome);
		this.m_nDivFantomeConteneur = nConteneur;
	}
};

// Suppression du fantome
WDDragAP.prototype.__FantomeSupprime = function __FantomeSupprime()
{
	if (clWDUtil.bHTMLVideDepuisVariable(this, "m_oDivFantome"))
	{
		delete this.m_nOffsetXYPourDebutFantome;
		// Reaffiche le bouton de suppression
		if (this.m_oChamp.m_oRendezVousSuppression)
		{
			this.m_oChamp.m_oRendezVousSuppression.style.visibility = "visible";
		}
		delete this.m_bDivFantomeTitreSeul;
		delete this.m_nDivFantomeConteneur;
		delete this.m_nDivFantomeLongueur;
		delete this.m_nDivFantomeDebut;
	}
};

// Le gestionnaire de dragdrop des rendez-vous
function WDDragRendezVous(oChamp)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDDragAP.prototype.constructor.apply(this, [250, 50, oChamp]);
	}
}

// Declare l'heritage
WDDragRendezVous.prototype = new WDDragAP();
// Surcharge le constructeur qui a ete efface
WDDragRendezVous.prototype.constructor = WDDragRendezVous;

// Appel lors du debut d'un clic pour le deplacement
// Pose les hooks
WDDragRendezVous.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent, oRendezVous)
{
	// Appel de la classe de base : sauve la position de la souris et place les hooks
	if (!WDDragAP.prototype._vbOnMouseDown.apply(this, [oEvent]))
	{
		return false;
	}

	// Selectionne le rendez-vous
	var bRes = this.m_oChamp.bOnRendezVousSelection(oEvent, oRendezVous);
	if (bRes)
	{
		// Determine si on est en deplacement ou en redimensionnement
		this.m_eDragMode = this.__eGetDragMode(oEvent, oRendezVous);
		var oParametres = this.m_oChamp.m_oParametres;
		// Verifie si l'action est autorise
		switch (this.m_eDragMode)
		{
		case this.ms_eDragRedimDebut:
		case this.ms_eDragRedimFin:
			bRes = this.m_oChamp.m_oVue.bUnRendezVousRedimensionnable(oParametres, oRendezVous);
			break;
		case this.ms_eDragDrop:
		default:
			// GP 21/11/2016 : QW278487 : S�pare le flag bActif des autres options
			// GP 27/03/2014 : Sauf que ce n'est pas juste on a le droit de changer le rendez-vous de conteneur (= d�placer le tout)
			// => Garde le code pr�c�dent (qui est parfois faux) en attente d'une meilleure correction.
//			// GP 27/03/2014 : TB81820 : On n'a le droit de d�placer un rendez-vous que si son d�but est d�placable
//			// Sinon c'est que le rendez-vous est une instance d'un rendez-vous plus large
//			bRes = oParametres.m_bDeplacementRendezVous && oParametres.m_bActif && !oRendezVous.m_bSansRedimDebut;
			bRes = oParametres.m_bDeplacementRendezVous && oParametres.m_bActif;
			break;
		}
	}

	// Si on doit annuler
	if (!bRes)
	{
		delete this.m_eDragMode;
		// Annule la selection
		this.bOnMouseUp(oEvent);

		return false;
	}

	return true;
};

// Determine si on est en deplacement ou en redimensionnement
WDDragRendezVous.prototype.__eGetDragMode = function __eGetDragMode(oEvent, oRendezVous)
{
	// Il ne faut pas d�tecter la classe : on utilise maintenant un pseudo �l�ment.
	// GP 17/11/2017 : QW292926 : Il faut prendre le div du conteneur comme r�f�rence. Sinon on prend l'�l�ment sur lequel on a cliqu� comme r�f�rence (dans le cas du titre).
	var oCible = oRendezVous.m_oDiv || this._oGetOriginalTarget(oEvent);
	var oVue = this.m_oChamp.m_oVue;
	var nOffset = this.oGetOffsetElementAutre(oEvent, oCible, oVue.vbGetVertical());
	if (nOffset < 5)
	{
		// Le filtre sur le fait que le rendez-vous est redimensionnable est fait dans WDDragRendezVous.prototype._vbOnMouseDown
		return this.ms_eDragRedimDebut;
	}
	else if (oVue.voGetOffsetLongueur(oCible) - 5 <= nOffset)
	{
		return this.ms_eDragRedimFin;

	}
	return this.ms_eDragDrop;
};

//// Appel lors du deplacement de la souris
//WDDragRendezVous.prototype._vOnMouseMove = function _vOnMouseMove(/*oEvent*/)
//{
//	// Appel de la classe de base
//	WDDragAP.prototype._vOnMouseMove.apply(this, arguments);
//};

// Appel lors du relachement de la souris
WDDragRendezVous.prototype._vOnMouseUp = function _vOnMouseUp(oEvent)
{
	// Uniquement les clics "lents"
	if (this.m_nDateMouseDown === undefined)
	{
		// Dernier deplacement du fantome (si il y a eu cr�ation du fantome, donc si il y a eu d�placement).
		if (this.m_oDivFantome)
		{
			this._vFantomeCreeDeplace(oEvent);

			// C'est un clic "lent" : drag-drop : effectue le deplacement
			this.__Deplacement(oEvent);

			// GP 08/04/2019 : TB112976 : Avec Firefox (depuis la version 66), on re�oit aussi un clic (bien que le d�but soit un clic sur le rendez-vous).
			// Bloque donc prochain onclick (on va recevoir un onclick).
			if (bFF)
			{
				this.m_oChamp.BloqueClicSuivant();
			}
		}
	}

	delete this.m_eDragMode;

	// Appel de la classe de base
	WDDragAP.prototype._vOnMouseUp.apply(this, arguments);
};

// Effectue le deplacement
WDDragRendezVous.prototype.__Deplacement = function __Deplacement(oEvent)
{
	var nDebut = this.m_oChamp.m_oVue.voGetOffsetDebut(this.m_oDivFantome);
	var nLongueur = this.m_oChamp.m_oVue.voGetOffsetLongueur(this.m_oDivFantome);
	var nConteneur = this.m_nDivFantomeConteneur;

	switch (this.m_eDragMode)
	{
	case this.ms_eDragRedimDebut:
	case this.ms_eDragRedimFin:
		// Notifie du redimensionnement de la selection
		this.m_oChamp.OnRendezVousRedimensionne(oEvent, nDebut, nLongueur);
		break;
	case this.ms_eDragDrop:
	default:
		// Notifie du deplacement (et/ou du changement de conteneurs)
		this.m_oChamp.OnRendezVousDeplacement(oEvent, nDebut, nLongueur, nConteneur);
		break;
	}
};

// Cr�ation ou d�placement du fantome (a redefinir).
WDDragRendezVous.prototype._vFantomeCreeDeplace = function _vFantomeCreeDeplace(oEvent)
{
	var oChamp = this.m_oChamp;
	var oParametres = oChamp.m_oParametres;

	if (!this.m_oDivFantome)
	{
		// Appel _FantomeCree avec les bons parametres
		var oRendezVous = oChamp.oGetRendezVousSelection();
		var oRendezVousDiv = oRendezVous.m_oDiv;
		var cCouleurFond = oChamp.m_oVue.__cGetFond(oRendezVous, oParametres.m_oStyleRendezVousSelect, oParametres.m_oStyleLibContenuSelect, true);
		this._FantomeCree(oChamp.m_oVue.voGetOffsetDebut(oRendezVousDiv), oChamp.m_oVue.voGetOffsetLongueur(oRendezVousDiv), oChamp.nGetRendezVousConteneur(oRendezVous), oChamp.m_oVue._bRendezVousTitreSeul(oParametres, oRendezVous), cCouleurFond, this.ms_eDragDrop === this.m_eDragMode);
	}
	else
	{
		var oVue = oChamp.m_oVue;

		var nDebut = this.m_nDivFantomeDebut;
		var nLongueur = this.m_nDivFantomeLongueur;
		var bTitreSeul = this.m_bDivFantomeTitreSeul;
		var nConteneur = this.m_nDivFantomeConteneur;

		// Arrondi la variation en fonction de la granularite autorisee
		var nOffsetPosition = oVue.vnGetOffsetPosition(this.nGetOffsetPosX(oEvent), this.nGetOffsetPosY(oEvent));

		// Selon le mode de redimensionnement
		switch (this.m_eDragMode)
		{
		case this.ms_eDragRedimDebut:
			nDebut = oVue.nAppliqueResolutionDeplacement(oParametres, nDebut + nOffsetPosition, nConteneur);
			nLongueur = oVue.nAppliqueResolutionTaille(oParametres, nLongueur - nOffsetPosition, 0, nConteneur, bTitreSeul);
			// Si la variation de hauteur (arrondie) est negative
			if (nLongueur <= 0)
			{
				nLongueur = oVue.nAppliqueResolutionTaille(oParametres, 0, 0, nConteneur);
			}
			break;

		case this.ms_eDragRedimFin:
			nLongueur = oVue.nAppliqueResolutionTaille(oParametres, nLongueur + nOffsetPosition, 0, nConteneur, bTitreSeul);
			// Si la variation de hauteur (arrondie) est negative
			if (nLongueur <= 0)
			{
				nLongueur = oVue.nAppliqueResolutionTaille(oParametres, 0, 0, nConteneur);
			}
			break;
		case this.ms_eDragDrop:
		default:
			nDebut = oVue.nAppliqueResolutionDeplacement(oParametres, nDebut + nOffsetPosition, nConteneur);
			nLongueur = oVue.nAppliqueResolutionTaille(oParametres, nLongueur, 0, nConteneur, bTitreSeul);
			// GP 12/11/2014 : QW250679 : Si on n'affiche que une partie des heures dans un agenda : on limite le rendez-vous en bas
			if (false === oParametres.m_bAccesAuxHeuresNonAffichees)
			{
				var nMargeBas = oVue.m_nDimensionPxZoneHeures - (nDebut + nLongueur);
				if (nMargeBas < 0)
				{
					nDebut += nMargeBas;
				}
			}
			// Changement de conteneur ?
			nConteneur = oChamp.nGetConteneurDepuisPosition(this._oGetOriginalTarget(oEvent), nConteneur, bTitreSeul);
			break;
		}

		// Appel de _FantomeDeplace pour effectue l'affichage
		this._FantomeDeplace(nDebut, nLongueur, nConteneur);
	}
};

// Le gestionnaire de selection d'une periode pour la creation d'un rendez-vous
function WDDragPeriodeSelect(oChamp)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		// 250 : Pour permettre d'avoir le clic sans les petites s�lection
		// Non car sinon le fantome n'est pas sous la souris et on a le onclick qui interf�re
//		// 200 : Pour ne pas appeler le PCode en boucle
		WDDragAP.prototype.constructor.apply(this, [250, 0, oChamp]);
	}
}

// Declare l'heritage
WDDragPeriodeSelect.prototype = new WDDragAP();
// Surcharge le constructeur qui a ete efface
WDDragPeriodeSelect.prototype.constructor = WDDragRendezVous;

// Gestion pour un element
WDDragPeriodeSelect.prototype.vInitElement = function vInitElement(oElement, nElement, oDiv, oDivTitreSeul)
{
	WDDragAP.prototype.vInitElement.apply(this, arguments);

	// Se branche sur clic
	var oThis = this;
	oElement.m_fClic = function(oEvent) { return oThis.bOnClick(oEvent || event, oElement, nElement, false) ? oThis._bStopPropagation(oEvent) : true; };
	clWDUtil.AttacheDetacheEvent(true, oDiv, "click", oElement.m_fClic, bTouch);
	if (oDivTitreSeul && oDivTitreSeul !== oDiv)
	{
		oElement.m_fClicTitreSeul = function(oEvent) { return oThis.bOnClick(oEvent || event, oElement, nElement, true) ? oThis._bStopPropagation(oEvent) : true; };
		clWDUtil.AttacheDetacheEvent(true, oDivTitreSeul, "click", oElement.m_fClicTitreSeul, bTouch);
	}

};
WDDragPeriodeSelect.prototype.vLibereElement = function vLibereElement(oElement, oDiv, oDivTitreSeul)
{
	// Se debranche du clic
	if (oDivTitreSeul && oDivTitreSeul !== oDiv)
	{
		clWDUtil.AttacheDetacheEvent(false, oDivTitreSeul, "click", oElement.m_fClicTitreSeul, bTouch);
		oElement.m_fClicTitreSeul = null;
	}

	clWDUtil.AttacheDetacheEvent(false, oDiv, "click", oElement.m_fClic, bTouch);
	oElement.m_fClic = null;

	WDDragAP.prototype.vLibereElement.apply(this, arguments);
};

// Stoppe la propagation sauf si on est en edition de champ
WDDragPeriodeSelect.prototype._vbStopPropagation = function _vbStopPropagation()
{
	var oParametres = this.m_oChamp.m_oParametres;
	// GP 21/11/2016 : QW278487 : S�pare le flag bActif des autres options
	return !(oParametres.m_bSelectionPeriode && oParametres.m_bActif) || bTouch;
};

// Appel lors du debut d'un clic pour le deplacement
// Pose les hooks
WDDragPeriodeSelect.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent, oConteneur, nConteneur, bTitreSeul)
{
	// Si on clic sur un rendez-vous ne fait rien
	var oSource = this._oGetOriginalTarget(oEvent);
	var oDiv = bTitreSeul && oConteneur.m_oDivTitreSeul ? oConteneur.m_oDivTitreSeul : oConteneur.m_oDiv;
	if (oSource !== oDiv)
	{
		return false;
	}

	// Valide que l'on a le droit de selectionner une periode
	// On interdit la s�lection de p�riode en mobile si on a un ascenseur (on a maintenant le clic)
	var oChamp = this.m_oChamp;
	var oParametres = oChamp.m_oParametres;
	// GP 21/11/2016 : QW278487 : S�pare le flag bActif des autres options
	if (!(oParametres.m_bSelectionPeriode && oParametres.m_bActif))
	{
		return false;
	}

	var oVue = oChamp.m_oVue;
	var oHoteCorps = oVue.m_oHoteCorps;
	if (bTouch)
	{
		if (oVue.__nGetClientOuScroll(oHoteCorps, "scrollWidth") > oHoteCorps.offsetWidth || oVue.__nGetClientOuScroll(oHoteCorps, "scrollHeight") > oHoteCorps.offsetHeight)
		{
			return false;
		}
	}

	// Appel de la classe de base : sauve la position de la souris et place les hooks
	if (!WDDragAP.prototype._vbOnMouseDown.apply(this, [oEvent]))
	{
		return false;
	}

	// GP 25/03/2013 : QW231387 : Si on a un seul conteneur pour les titre seul et les titres, il faut s�parer les deux cas
	// Comme on ne hook le div commun que une fois, on recoit !bTitreSeul
	bTitreSeul = this.__bCorrigeTitreSeul(oDiv, oConteneur, nConteneur, bTitreSeul, this.nGetPosX(), this.nGetPosY());

	// Calcule la position initiale du fantome
	var oPosition = this.__oGetPositionFantome(oEvent, oConteneur, nConteneur, bTitreSeul);
	// Lancement de la selection
	if (!oChamp.bOnPeriodeSelect(oEvent, oPosition.m_nDebut, oPosition.m_nLongueur, oConteneur))
	{
		// Annule la selection
		this.bOnMouseUp(oEvent);
		return false;
	}

	this.m_oConteneur = oConteneur;
	this.m_nConteneur = nConteneur;
	this.m_bTitreSeul = bTitreSeul;
	return true;
};

//// Appel lors du deplacement de la souris
//WDDragPeriodeSelect.prototype._vOnMouseMove = function _vOnMouseMove(/*oEvent*/)
//{
//	// Appel de la classe de base
//	WDDragAP.prototype._vOnMouseMove.apply(this, arguments);
//};

// Appel lors du relachement de la souris
WDDragPeriodeSelect.prototype._vOnMouseUp = function _vOnMouseUp(oEvent)
{
	// Dernier deplacement du fantome
	if (this.m_oDivFantome)
	{
		this._vFantomeCreeDeplace(oEvent);

		// C'est un clic "lent" : drag-drop : effectue le deplacement
		this.__Creation(oEvent);

		// Bloque le prochain onclick (on va recevoir un onclick)
		this.m_oChamp.BloqueClicSuivant();
	}

	delete this.m_bTitreSeul;
	delete this.m_nConteneur;
	delete this.m_oConteneur;

	// Appel de la classe de base
	WDDragAP.prototype._vOnMouseUp.apply(this, arguments);
};

// Clic dans le cas ou l'on demande la cr�ation par clic
WDDragPeriodeSelect.prototype.bOnClick = function bOnClick(oEvent, oConteneur, nConteneur, bTitreSeul)
{
	// GP 02/05/2018 : TB100768 : Une seule cr�ation sur un double-clic.
	if (1 < oEvent.detail)
	{
		return false;
	}

	var oChamp = this.m_oChamp;
	var oParametres = oChamp.m_oParametres;
	// Valide que l'on a le droit de selectionner une periode
	// GP 21/11/2016 : QW278487 : S�pare le flag bActif des autres options
	if (!(oParametres.m_bSelectionPeriode && oParametres.m_bActif))
	{
		return false;
	}

	// On recoit le clic si la cr�ation par s�lection de p�riode se termine dans le conteneur
	// => Il faut filtrer le cas
	if (oChamp.bGetBloqueClicSuivant())
	{
		return false;
	}

	var oDiv = bTitreSeul && oConteneur.m_oDivTitreSeul ? oConteneur.m_oDivTitreSeul : oConteneur.m_oDiv;

	// Regarde si le clic n'est pas sur un rendez-vous
	var oTarget = clWDUtil.oGetTarget(oEvent);
	var oBody = oTarget.ownerDocument.body;
	var oVue = oChamp.m_oVue;
	var oHoteCorps = oVue.m_oHoteCorps;

	while (oTarget && oTarget !== oBody && oTarget !== oDiv && oTarget !== oHoteCorps)
	{
		if (clWDUtil.bAvecClasse(oTarget, oChamp.m_oVue.ms_sNomRendezVousExterne))
		{
			return false;
		}
		oTarget = oTarget.parentNode;
	}

	// GP 25/03/2013 : QW231387 : Si on a un seul conteneur pour les titre seul et les titres, il faut s�parer les deux cas
	// Comme on ne hook le div commun que une fois, on recoit !bTitreSeul
	var bPosX = this._nGetPosXEvent(oEvent);
	var bPosY = this._nGetPosYEvent(oEvent);
	bTitreSeul = this.__bCorrigeTitreSeul(oDiv, oConteneur, nConteneur, bTitreSeul, bPosX, bPosY);

	// Gestion du clic : cr�ation du rendez-vous
	oChamp.OnRendezVousAjouteSur1Heure(oEvent, oVue.vnGetPositionHote(oDiv, bPosX, bPosY, false), nConteneur, bTitreSeul);

	return true;
};

// GP 25/03/2013 : QW231387 : Si on a un seul conteneur pour les titre seul et les titres, il faut s�parer les deux cas
// Comme on ne hook le div commun que une fois, on recoit !bTitreSeul
WDDragPeriodeSelect.prototype.__bCorrigeTitreSeul = function __bCorrigeTitreSeul(oDiv, oConteneur, nConteneur, bTitreSeul, nPosX, nPosY)
{
	if (!bTitreSeul && oConteneur.m_oDivTitreSeul && oConteneur.m_oDivTitreSeul === oConteneur.m_oDiv)
	{
		var nPosition = this.m_oChamp.m_oVue.vnGetPositionHote(oDiv, nPosX, nPosY, false);
		return this.m_oChamp.m_oVue.bDansRendezVousALaJournee(this.m_oChamp.m_oParametres, nPosition, nConteneur);
	}
	else
	{
		return bTitreSeul;
	}
};

// Effectue la creation
WDDragPeriodeSelect.prototype.__Creation = function __Creation(oEvent)
{
	// Calcule la position du fantome (en double entre l'appel de _vFantomeCreeDeplace de _vOnMouseUp)
	var oPosition = this.__oGetPositionFantome(oEvent, this.m_oConteneur, this.m_nConteneur, this.m_bTitreSeul);
	// Lancement de la creation
	this.m_oChamp.OnRendezVousAjoute(oEvent, oPosition.m_nDebut, oPosition.m_nLongueur, this.m_nConteneur, this.m_bTitreSeul);
};

// Cr�ation ou d�placement du fantome (a redefinir).
WDDragPeriodeSelect.prototype._vFantomeCreeDeplace = function _vFantomeCreeDeplace(oEvent)
{
	// Calcule la position du fantome
	var oPosition = this.__oGetPositionFantome(oEvent, this.m_oConteneur, this.m_nConteneur, this.m_bTitreSeul);
	// Lancement de la selection
	if (!this.m_oChamp.bOnPeriodeSelect(oEvent, oPosition.m_nDebut, oPosition.m_nLongueur, this.m_oConteneur))
	{
		// Annule la selection
		this.bOnMouseUp(oEvent);
		return;
	}

	// Appel _FantomeCree/_FantomeDeplace avec les bons parametres
	if (!this.m_oDivFantome)
	{
		return this._FantomeCree(oPosition.m_nDebut, oPosition.m_nLongueur, this.m_nConteneur, this.m_bTitreSeul, this.m_oChamp.m_oParametres.m_oStyleSelection.m_cFond, false);
	}
	else
	{
		return this._FantomeDeplace(oPosition.m_nDebut, oPosition.m_nLongueur, this.m_nConteneur);
	}
};

// Calcule la position du fantome
// retourne un objet avec m_nDebut et m_nLongueur
WDDragPeriodeSelect.prototype.__oGetPositionFantome = function __oGetPositionFantome(oEvent, oConteneur, nConteneur, bTitreSeul)
{
	var oChamp = this.m_oChamp;
	var oDiv = bTitreSeul && oConteneur.m_oDivTitreSeul ? oConteneur.m_oDivTitreSeul : oConteneur.m_oDiv;
	// Recupere le dragdrop actuel
	var nPosition = oChamp.m_oVue.vnGetPositionHote(oDiv, this.nGetPosX(), this.nGetPosY(), false);
	var nOffsetPosition = oChamp.m_oVue.vnGetOffsetPosition(this.nGetOffsetPosX(oEvent), this.nGetOffsetPosY(oEvent));

	// Inverse la position si besoin pour avoir des coordonnees positives
	if (nOffsetPosition < 0)
	{
		nPosition = nPosition + nOffsetPosition;
		nOffsetPosition = -nOffsetPosition;
	}

	// Calcule la position du haut
	var nDebut = oChamp.m_oVue.nAppliqueResolutionDeplacement(oChamp.m_oParametres, nPosition, nConteneur);
	// Et la longueur : arrondi la position en fonction de la granularite autorisee
	var nLongueur = oChamp.m_oVue.nAppliqueResolutionTaille(oChamp.m_oParametres, nOffsetPosition, nPosition - nDebut, nConteneur, bTitreSeul);

	return {
		m_nDebut: nDebut,
		m_nLongueur: nLongueur
	};
};

// Objet pour la recherche dans une colonne
function WDPopupSaisiePlanning(oChampParent)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDPopupSaisie.prototype.constructor.apply(this, [oChampParent, true]);
	}
}

// Declare l'heritage
WDPopupSaisiePlanning.prototype = new WDPopupSaisie();
// Surcharge le constructeur qui a ete efface
WDPopupSaisiePlanning.prototype.constructor = WDPopupSaisiePlanning;

// Debut de la saisie
// nReductionLargeur : pour la saisie dans le champ table : on ne prend pas toute la largeur
WDPopupSaisiePlanning.prototype._vDebut = function _vDebut(oConteneurParent, oOffsetParent, nReductionLargeur, sValeurInitiale, oChampModeleMasque, sTaillePolice, tabParametresSpecifiques)
{
	// Appel de la classe de base
	WDPopupSaisie.prototype._vDebut.apply(this, arguments);

	// D�code le(s) parametre(s)
	var oRendezVous = tabParametresSpecifiques[0];

	// Memorise le rendez-vous
	this.m_oRendezVous = oRendezVous;

	// GP 25/03/2015 : QW256413 : Bloque les messages de redimensionnement pendant quelques instant (pour l'ouverture du clavier)
	// GP 26/03/2015 : QW256568 : Toujours : on ne d�tecte pas IE en mode modernUI comme �tant en touch
	if (bTouch)
	{
		this.m_oChampParent.m_nBloqueOnResize = (new Date()).getTime();
	}
};

// Valide la saisie
WDPopupSaisiePlanning.prototype._vValide = function _vValide(oEvent, sValeur)
{
	// Appel de la classe de base
	WDPopupSaisie.prototype._vValide.apply(this, arguments);

	// Appel du champ
	this.m_oChampParent.OnRendezVousValideSaisie(oEvent, this.m_oRendezVous, sValeur);
};

// Annule la saisie
WDPopupSaisiePlanning.prototype._vAnnule = function _vAnnule()
{
	// Libere nos valeurs
	this.m_oRendezVous = null;

	// GP 20/03/2015 : QW255998 : Bloque la cr�ation de rendez-vous par simple clic. Car en effet si on perd le focus par clic externe, on veux probablement ne pas cr�er de rendez-vous
	// GP 23/03/2015 : Si on valide on va avoir un acc�s r�seau : bloque le prochain avec un d�lai suppl�mentaire de 200ms
	// GP 26/03/2015 : QW256544 : Utilise une autre m�thode
	this.m_oChampParent.BloqueClicSuivant();

	// Appel de la classe de base
	WDPopupSaisie.prototype._vAnnule.apply(this, arguments);
};

// Manipulation d'un rendez-vous du champ planning
// oRendezVous : structure du champ planning contenant les donnees du rendez-vous (cette classe n'est qu'un wrapper)
function WDRendezVous(oChamp, oRendezVous)
{
	// Appel le constructeur de la classe de base
	// Si un jour on derive de la classe, mettre un parametre pour proteger l'appel
	WDTypeAvance.prototype.constructor.apply(this, [true]);

	if (oChamp && oRendezVous)
	{
		this.m_oChamp = oChamp;
		this.m_oRendezVous = oRendezVous;
	}
}

// Declare l'heritage
WDRendezVous.prototype = new WDTypeAvance();
// Surcharge le constructeur qui a ete efface
WDRendezVous.prototype.constructor = WDRendezVous;

// Lire une propriete
WDRendezVous.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
	case 0:		// Titre
		return this.m_oRendezVous.m_sTitre;
	case 1:		// CouleurFond
		return this.m_oRendezVous.m_cFondContenu;
	case 2:		// DateDebut
		// GP 24/02/2015 : TB91127 : Il faut bien passer par __DateHeure2WL pour avoir une date en UTC
		// On fait alors une conversion Date => Chaine => Date mais on amoins c'est juste (et comme avant on ne prenait pas la date en r�f�rence, cela n'a pas d'mportance)
		// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides : c'est une date JS donc forc�ment valide
//		return this.__DateHeure2WL(this.m_oRendezVous.m_oDateDebut);
//		return new clWLangage.WDDateHeure(true, true, this.m_oRendezVous.m_oDateDebut);
		return new clWLangage.WDDateHeure(true, true, this.__DateHeure2WL(this.m_oRendezVous.m_oDateDebut), undefined, false);
	case 3:		// DateFin
		// GP 24/02/2015 : TB91127 : Il faut bien passer par __DateHeure2WL pour avoir une date en UTC
		// On fait alors une conversion Date => Chaine => Date mais on amoins c'est juste (et comme avant on ne prenait pas la date en r�f�rence, cela n'a pas d'mportance)
		// GP 16/03/2015 : TB91216/TB91683 : N'accepte pas les date/heure/dateheure invalides : c'est une date JS donc forc�ment valide
//		return this.__DateHeure2WL(this.m_oRendezVous.m_oDateFin);
//		return new clWLangage.WDDateHeure(true, true, this.m_oRendezVous.m_oDateFin);
		return new clWLangage.WDDateHeure(true, true, this.__DateHeure2WL(this.m_oRendezVous.m_oDateFin), undefined, false);
	case 4:		// Contenu
		return this.m_oRendezVous.m_sContenu;
	case 8:		// Categorie
		return this.m_oRendezVous.m_sCategorie;
	case 14:	// ID (attention c'est l'ID utilisateur par l'ID unique du rendez-vous)
		return this.m_oRendezVous.m_sIDUtilisateur;
	case 15:	// Bulle
		return this.m_oRendezVous.m_sBulle;
	case 16:	// Ressource
		return this.m_oChamp._sGetNomConteneur(this.m_oChamp.nGetRendezVousConteneur(this.m_oRendezVous));
	case 17:	// Journ�eEnti�re
		return this.m_oRendezVous.m_bJourneeEntiere;
	default:
		return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};

WDRendezVous.prototype.__DateHeure2WL = function __DateHeure2WL(oDate)
{
	// Demande la date en UTC (pour avoir la meme reponse quelque soit l'endroit de consultation)
	return clWDUtil.sGetDateHeureWL(oDate, true, true, true);
};

// Manipulation d'une repetition de rendez-vous
function WDRepetition()
{
	// Appel le constructeur de la classe de base
	// Si un jour on derive de la classe, mettre un parametre pour proteger l'appel
	WDTypeAvance.prototype.constructor.apply(this, [true]);
}

// Declare l'heritage
WDRepetition.prototype = new WDTypeAvance();
// Surcharge le constructeur qui a ete efface
WDRepetition.prototype.constructor = WDRepetition;

// Lire une propriete
WDRepetition.prototype.GetProp = function GetProp(nPropriete)
{
	switch (nPropriete)
	{
	default:
		return WDTypeAvance.prototype.GetProp.apply(this, arguments);
	}
};
