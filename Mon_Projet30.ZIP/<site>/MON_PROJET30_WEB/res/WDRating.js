// WDRating.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - StdAction.js
///#GLOBALS
// _JGE
// - WDUtil.js
///#GLOBALS bIE nIE bIEQuirks bIEQuirks9Max WDErreur
// - WDChamp.js
///#GLOBALS WDChampParametresHote
// - WDDrag.js
///#GLOBALS WDDrag

//////////////////////////////////////////////////////////////////////////
// Le gestionnaire de clic sous forme de dragdrop pour les champs rating/potentiometre/range slider : permet la gestion de la surbrillance
var WDDragPotentiometreBase = (function ()
{
	"use strict";

	function __WDDragPotentiometreBase(oChamp)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDDrag.prototype.constructor.apply(this, [0, 50]);

			// Sauve l'objet attache
			this.m_oChamp = oChamp;
		}
	};

	// Declare l'heritage
	__WDDragPotentiometreBase.prototype = new WDDrag();
	// Surcharge le constructeur qui a ete efface
	__WDDragPotentiometreBase.prototype.constructor = __WDDragPotentiometreBase;

	// Gestion pour un element
	__WDDragPotentiometreBase.prototype.InitElement = function InitElement(oObjetSurDiv, oDiv, nIndiceZR)
	{
		// Intercepte le debut de clic
		var oThis = this;
		oObjetSurDiv.m_fMouseDown = function(oEvent) { return oThis.bOnMouseDown(oEvent || event, nIndiceZR) ? oThis._bStopPropagation(oEvent) : true; };
		this._AttacheDetacheMouseDown(true, oDiv, oObjetSurDiv.m_fMouseDown);
	};
	__WDDragPotentiometreBase.prototype.LibereElement = function LibereElement(oObjetSurDiv, oDiv)
	{
		// Supprime l'evenement clic
		this._AttacheDetacheMouseDown(false, oDiv, oObjetSurDiv.m_fMouseDown);
		oObjetSurDiv.m_fMouseDown = null;
		delete oObjetSurDiv.m_fMouseDown;
	};

	// Appel lors du debut d'un clic pour le deplacement
	// Pose les hooks
	__WDDragPotentiometreBase.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent, nIndiceZR)
	{
		// Appel de la classe de base : sauve la position de la souris et place les hooks
		if (!WDDrag.prototype._vbOnMouseDown.apply(this, arguments))
		{
			return false;
		}

		// Interdit si le champ est en lecture seule
		if (this.m_oChamp.bLectureSeuleOuGriseExterne(nIndiceZR))
		{
			return false;
		}

		// Premier dessin avec la valeur de selection
		this.m_nIndiceZR = nIndiceZR;
		this.__MAJAfficheComplet(oEvent);

		return true;
	};

	// Appel lors du deplacement de la souris
	__WDDragPotentiometreBase.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
	{
		// Appel de la classe de base
		WDDrag.prototype._vOnMouseMove.apply(this, arguments);

		// Interdit si le champ est en lecture seule
		if (this.m_oChamp.bLectureSeuleOuGriseExterne(this.m_nIndiceZR))
		{
			return;
		}

		// Dessin avec la valeur de selection
		this.__MAJAfficheComplet(oEvent);
	};

	// Appel lors du relachement de la souris
	__WDDragPotentiometreBase.prototype._vOnMouseUp = function _vOnMouseUp(oEvent)
	{
		try
		{
			// Interdit si le champ est en lecture seule
			if (!this.m_oChamp.bLectureSeuleOuGriseExterne(this.m_nIndiceZR))
			{
				// Sauve la valeur
				this.m_oChamp.OnChange(oEvent, this._vtabGetValeursSelection(oEvent), this.m_nIndiceZR);
			}
		}
		finally
		{
			// Pour avoir une liberation complete
			// Appel de la classe de base
			WDDrag.prototype._vOnMouseUp.apply(this, arguments);

			// Pas de dessin final (fait par OnChange)
			if (this.m_nIndiceZR !== undefined)
			{
				delete this.m_nIndiceZR;
			}
		}
	};

	// MAJ de l'affichage
	__WDDragPotentiometreBase.prototype.__MAJAfficheComplet = function __MAJAfficheComplet(oEvent)
	{
		// Dessin avec la valeur de selection
		var tabGetValeursSelection = this._vtabGetValeursSelection(oEvent);
		this.m_oChamp.MAJAfficheComplet(this.m_nIndiceZR, tabGetValeursSelection);
		this.m_oChamp._OnPCodeChangementSimple(oEvent, this.m_nIndiceZR, tabGetValeursSelection)
	};

	return __WDDragPotentiometreBase;
})();

//////////////////////////////////////////////////////////////////////////
// Classe de base pour les champs rating/potentiometre/range slider
var WDPotentiometreBase = (function ()
{
	"use strict";

	function __WDPotentiometreBase(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChampParametresHote.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
		}
	};

	// Declare l'heritage
	__WDPotentiometreBase.prototype = new WDChampParametresHote();
	// Surcharge le constructeur qui a ete efface
	__WDPotentiometreBase.prototype.constructor = __WDPotentiometreBase;

	// Initialisation :
	__WDPotentiometreBase.prototype.Init = function ()
	{
		// Appel de la methode de la classe de base
		WDChampParametresHote.prototype.Init.apply(this, arguments);

		this.m_oDrag = new this.vDrag(this);

		this.__tabInitTousElements();
	};

	// Applique les parametres
	__WDPotentiometreBase.prototype._vAppliqueParametres = function _vAppliqueParametres(/*oParametreFusion*/)
	{
		WDChampParametresHote.prototype._vAppliqueParametres.apply(this, arguments);

		// GP 15/05/2013 : TB82095 : MAJ du champ cach� sinon au prochain submit on retournera la pr�c�dement valeur au serveur
		this._vSetValeur(this.vtabGetValeurs(), undefined, true);

		// GP 15/05/2013 : Inutile : d�j� fait par this._vSetValeur
	//	// Affiche le champ
	//	this.MAJAfficheComplet();
	};

	// Initialise un champ rating. Retourne le tableau de gestion
	__WDPotentiometreBase.prototype.__tabInitTousElements = function __tabInitTousElements()
	{
		// Si on est dans une ZR AJAX : ne fait rien sur les champs
		if (!this.bGestionTableZR())
		{
			this.m_tabDescriptions = this.__tabInitElements(this.m_oHote);

			// Affiche le champ (non fait par le serveur)
			this.MAJAfficheComplet();
		}
		else if (!this.oGetTableZRParent())
		{
			// Recupere la collection des champs dans la ZR
			this.m_tabDescriptions = [];
			this.PourToutesLignesTableZR(this.__InitElementsZR);
		}
		else
		{
			this.m_tabDescriptions = [];
		}
	};

	__WDPotentiometreBase.prototype.__InitElementsZR = function __InitElementsZR(nLigneAbsolueBase1)
	{
		this.m_tabDescriptions[nLigneAbsolueBase1 - 1] = this.__tabInitElements(this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, this.ms_sSuffixeHote), nLigneAbsolueBase1);
		// Affiche le champ (non fait par le serveur)
		this.MAJAfficheComplet(nLigneAbsolueBase1);
	};

	// Initialise un champ rating. Retourne le tableau de gestion
	__WDPotentiometreBase.prototype.__tabInitElements = function __tabInitElements(oConteneur, nIndiceZR)
	{
		// Pas de conteneur possible pour les lignes invisibles
		var tabDescriptions;
		if (oConteneur)
		{
			tabDescriptions = [];

			// Liaison avec les div d'affichage (nombre de div)
			// Normalement tabElements.length == this.m_oParametres.m_nNbEtoileMax * 2;
			var tabElements = this._vtabGetElements(oConteneur);
			var nLimiteI = tabElements.length;
			for (var i = 0; i < nLimiteI; i++)
			{
				var oDiv = { m_oDiv: tabElements[i] };
				tabDescriptions.push(oDiv);

				// Liaison sur le clic
				this.m_oDrag.InitElement(oDiv, oDiv.m_oDiv, nIndiceZR);
			}
		}

		return tabDescriptions;
	};

	// Libere un champ rating
	__WDPotentiometreBase.prototype.__LibereTousElements = function __LibereTousElements()
	{
		var nLimiteI = this.m_tabDescriptions.length;
		for (var i = 0; i < nLimiteI; i++)
		{
			this.__LibereElements(this.m_tabDescriptions[i]);
		}
		this.m_tabDescriptions = [];
	};

	__WDPotentiometreBase.prototype.__LibereElementsZR = function __LibereElementsZR(nLigneAbsolueBase1, bDelete)
	{
		var nLigne = nLigneAbsolueBase1 - 1;
		if (this.m_tabDescriptions[nLigne])
		{
			this.__LibereElements(this.m_tabDescriptions[nLigne]);
			if (bDelete)
			{
				delete this.m_tabDescriptions[nLigne];
			}
		}
	};

	// Libere un champ rating
	__WDPotentiometreBase.prototype.__LibereElements = function __LibereElements (tabDescriptions)
	{
		var nLimiteI = tabDescriptions.length;
		for (var i = 0; i < nLimiteI; i++)
		{
			var oDiv = tabDescriptions[i];
			this.m_oDrag.LibereElement(oDiv, oDiv.m_oDiv);
			oDiv.m_oDiv = null;
			delete oDiv.m_oDiv;
			tabDescriptions[i] = null;
		}
	};

	// Recupere la valeur
	__WDPotentiometreBase.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp)
	{
		// HORS ZR : sValeur et this.m_oDonnees.m_dValeur sont identique (sauf sur le type)
		// ZR : sValeur est la vraie valeur
		if (this.bGestionTableZR())
		{
			sValeur = this._vParseValeur(sValeur);
		}
		else
		{
			sValeur = this.m_oDonnees.m_dValeur;
		}
		// Prend la valeur dans les donn�es sauf si on est dans une ZR (car

		// Appel de la methode de la classe de base et retour de son resultat
		return WDChampParametresHote.prototype.GetValeur.apply(this, [oEvent, sValeur, oChamp]);
	};

	// Ecriture de la valeur du champ en programmation
	__WDPotentiometreBase.prototype.SetValeur = function SetValeur(oEvent, sValeur/*, oChamp*/)
	{
		// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
		WDChampParametresHote.prototype.SetValeur.apply(this, arguments);

		this.__SetValeur(this._vParseValeur(sValeur), undefined, true);

		// Dans tous les cas : retourne la vraie valeur (celle dans le champ)
		// GP 10/10/2012 : Fonctionne dans les ZRs ?
		return this.m_oDonnees.m_dValeur;
	};

	// Lit les proprietes dont l'indication
	__WDPotentiometreBase.prototype.GetProp = function GetProp(eProp/*, oEvent, oValeur, oChamp*/)
	{
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_BORNEMIN:
			// Appel depuis le framework V2 (qui s'occupe de la partie "propri�t� s�curis�e")
			return this.vdGetBorneInferieure();
		case this.XML_CHAMP_PROP_NUM_BORNEMAX:
			// Appel depuis le framework V2 (qui s'occupe de la partie "propri�t� s�curis�e")
			return this.vdGetBorneSuperieure();
		default:
			// Retourne a l'impl�mentation de la classe de base avec la valeur �ventuellement modifi�e
			return WDChampParametresHote.prototype.GetProp.apply(this, arguments);
		}
	};
	__WDPotentiometreBase.prototype.SetProp = function SetProp(eProp, oEvent, oValeur/*, oChamp, oXMLAction*/)
	{
		// Implementation de la classe de base
		oValeur = WDChampParametresHote.prototype.SetProp.apply(this, arguments);

		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_BORNEMIN:
			// Appel depuis le framework V2 (qui s'occupe de la partie "propri�t� s�curis�e")
			return this.__xoSetBorneMinMax(oValeur, false);
		case this.XML_CHAMP_PROP_NUM_BORNEMAX:
			// Appel depuis le framework V2 (qui s'occupe de la partie "propri�t� s�curis�e")
			return this.__xoSetBorneMinMax(oValeur, true);
		default:
			// Retourne inchang�e la valeur de la propri�t�
			return oValeur;
		}
	};
	__WDPotentiometreBase.prototype.__xoSetBorneMinMax = function __xoSetBorneMinMax(oValeur, bBorneMax)
	{
		// Validation du param�tre : c'est toujours conversion en entier
		oValeur = parseInt(oValeur, 10);

		// A cause des valeurs s�curis�es, ont ne peut pas changer l'autre borne dans le cas d'une inversion Max < Min.
		// => On interdit le cas
		var nBorneInferieure = this.vdGetBorneInferieure();
		var nBorneSuperieure = this.vdGetBorneSuperieure();
		if (bBorneMax)
		{
			nBorneSuperieure = oValeur;
		}
		else
		{
			nBorneInferieure = oValeur;
		}
		if (nBorneSuperieure < nBorneInferieure)
		{
			throw new WDErreur(700, nBorneInferieure, nBorneSuperieure);
		}

		// Execution des validations sp�cifiques au champ et affectation dans le bon membre
		oValeur = this.__xvoSetBorneMinMax(oValeur, bBorneMax);

		// Et il faut reforcer le dessin : fait en reforcant la valeur
		this._vAppliqueParametres();

		return oValeur;
	};

	// Fixe la valeur
	__WDPotentiometreBase.prototype._vSetValeur = function _vSetValeur(tabValeursSelection, nIndiceZR, bMAJAfficheComplet)
	{
		this.__SetValeur(tabValeursSelection[0], nIndiceZR, bMAJAfficheComplet);
	};
	__WDPotentiometreBase.prototype.__SetValeur = function __SetValeur(dValeur, nIndiceZR, bMAJAfficheComplet)
	{
		// Valide la valeur
		if (isNaN(dValeur))
		{
			return;
		}
		dValeur = this._dGetValeurDansBornes(dValeur);

		// Modifie la valeur dans les parametres
		this.m_oDonnees.m_dValeur = dValeur;

		// Gere le cas de la ZR
		// => Deja gere au niveau parent si besoin (OnChange)
		// (pas dans le cas de SetValeur car on n'est alors pas en ZR)
		// On utilise donc directement __MAJAfficheCompletInterne

		// Ecrit la valeur dans le champ formulaire
		// Meme dans le cas du parcours navigateur car il tient compte des bornes
		this._vSetValeurChampFormulaire(dValeur);

		// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
		if (bMAJAfficheComplet)
		{
			this.__MAJAfficheCompletZR(nIndiceZR);
		}
	};

	// Force une valeur dans les bornes
	__WDPotentiometreBase.prototype._dGetValeurDansBornes = function _dGetValeurDansBornes(dValeur)
	{
		return Math.min(Math.max(dValeur, this.vdGetBorneInferieure()), this.vdGetBorneSuperieure());
	};

	// Recupere la valeur en tenant compte de la ligne de ZR
	__WDPotentiometreBase.prototype.tabGetValeurs = function tabGetValeurs(nIndiceZR)
	{
		return this.oAppelSurLigneTableZR(nIndiceZR, this.vtabGetValeurs, []);
	};

	// Indique que la valeur a changer par une action de l'utilisateur (provoque un redessin)
	__WDPotentiometreBase.prototype.OnChange = function OnChange(oEvent, tabValeursSelection, nIndiceZR)
	{
		// Gere le cas de la ZR
		var tabValeursPrecedente = this.tabGetValeurs(nIndiceZR);
		this.__ArrondiSelection(tabValeursSelection, tabValeursPrecedente);

		// On force reelement la ligne de la ZR
		if (this.bGestionTableZR() && (nIndiceZR !== undefined))
		{
			this.SetTableZRValeur(oEvent, nIndiceZR);
		}

		// Rien si la valeur ne change pas
		if ((tabValeursSelection[0] == tabValeursPrecedente[0]) && (tabValeursSelection[1] == tabValeursPrecedente[1]))
		{
			return;
		}

		// Fixe la valeur (provoque un redessin)
		this._vSetValeur(tabValeursSelection, nIndiceZR, true);

		// Appel du PCode (qui appel le code serveur)
		this.RecuperePCode(this.ms_nEventNavChange)(oEvent);

		// Notifie la ZR
		this._OnChampModifie(oEvent, tabValeursSelection[0]);
	};

	// Indique que la valeur a changer pendant une modification de l'utilisateur
	__WDPotentiometreBase.prototype._OnPCodeChangementSimple = function _OnPCodeChangementSimple(oEvent, nIndiceZR, tabValeursSelection)
	{
		// On force reellement la ligne de la ZR
		if (this.bGestionTableZR() && (nIndiceZR !== undefined))
		{
			this.SetTableZRValeur(oEvent, nIndiceZR);
		}

		// Sauve la valeur
		var tabValeurs = this.vtabGetValeurs();

		// Fixe la valeur (SANS redessin)
		this._vSetValeur(tabValeursSelection, nIndiceZR, false);

		// Appel du PCode 'A chaque modification'
		this.RecuperePCode(this.ms_nEventNavModifSimple)(oEvent);

		// Replace la valeur
		this._vSetValeur(tabValeurs, nIndiceZR, false);

		// On ne notifie pas la ZR
	//	// Notifie la ZR
	//	this._OnChampModifie(oEvent, tabValeursSelection[0]);
	};

	__WDPotentiometreBase.prototype.__ArrondiSelection = function __ArrondiSelection(tabValeursSelection, tabValeursPrecedente)
	{
		var nLimiteI = tabValeursSelection.length;
		for (var i = 0; i < nLimiteI; i++)
		{
			if (undefined != tabValeursSelection[i])
			{
				tabValeursSelection[i] = this._vdArrondiSelection(tabValeursSelection[i], tabValeursPrecedente[i]);
			}
		}
	};

	// Trouve la valeur du champ selon l'indice de la ZR
	// Modifie tabIndiceZRSav si besoin pour stocker nIndiceZRSav
	__WDPotentiometreBase.prototype.vtabGetValeurs = function vtabGetValeurs()
	{
		var dValeur;
		if (this.bGestionTableZR())
		{
			this._vLiaisonHTML();
			if (this.m_oChampFormulaire)
			{
				dValeur = this._vParseValeur(this.m_oChampFormulaire.value);
			}
		}
		else
		{
			dValeur = this.m_oDonnees.m_dValeur;
		}
		return [ dValeur, undefined ];
	};

	// - Tous les champs : notifie que une table ou ZRs a �t� MAJ en AJAX (= table/ZR non AJAX mais avec les ZR horizontales)
	__WDPotentiometreBase.prototype._vOnTableZRAfficheAJAXInterne = function _vOnTableZRAfficheAJAXInterne()
	{
		// Appel de la methode de la classe de base (qui normalement ne fait rien)
		WDChampParametresHote.prototype._vOnTableZRAfficheAJAXInterne.apply(this, arguments);

		this.__tabInitTousElements();
	};

	// Methode appele directement
	// - Champ dans une table/ZR : notifie le champ de l'affichage/suppression de la ligne
	__WDPotentiometreBase.prototype._vOnLigneTableZRAffiche = function _vOnLigneTableZRAffiche(nLigneAbsolueBase1/*, bSelectionne*/)
	{
		// Appel de la methode de la classe de base
		WDChampParametresHote.prototype._vOnLigneTableZRAffiche.apply(this, arguments);

		this.__LibereElementsZR(nLigneAbsolueBase1, false);
		this.__InitElementsZR(nLigneAbsolueBase1);
	};
	__WDPotentiometreBase.prototype._vOnLigneTableZRMasque = function _vOnLigneTableZRMasque(nLigneAbsolueBase1/*, bSelectionne*//*, oEvent*/)
	{
		this.__LibereElementsZR(nLigneAbsolueBase1, true);

		// Appel de la methode de la classe de base
		WDChampParametresHote.prototype._vOnLigneTableZRMasque.apply(this, arguments);
	};

	// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
	__WDPotentiometreBase.prototype.MAJAfficheComplet = function MAJAfficheComplet(nIndiceZR/*, tabValeursSelection*/)
	{
		this.oAppelSurLigneTableZR(nIndiceZR, this.__MAJAfficheCompletZR, arguments);
	};

	// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
	__WDPotentiometreBase.prototype.__MAJAfficheCompletZR = function __MAJAfficheCompletZR(nIndiceZR, tabValeursSelection)
	{
		this._vMAJAfficheCompletInterne(this.vtabGetValeurs(), nIndiceZR, tabValeursSelection);
	};

	// Trouve la description de l'element
	__WDPotentiometreBase.prototype.tabGetDescriptions = function tabGetDescriptions(nIndiceZR)
	{
		if (this.bGestionTableZR())
		{
			if (nIndiceZR === undefined)
			{
				nIndiceZR = this.nGetTableZRValeur();
			}
			return this.m_tabDescriptions[nIndiceZR - 1];
		}
		else
		{
			return this.m_tabDescriptions;
		}
	};

	return __WDPotentiometreBase;
})();

//////////////////////////////////////////////////////////////////////////
// Manipulation d'un champ rating
var WDRating = (function ()
{
	"use strict";

	function __WDRating(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDPotentiometreBase.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
		}
	};

	// Declare l'heritage
	__WDRating.prototype = new WDPotentiometreBase();
	// Surcharge le constructeur qui a ete efface
	__WDRating.prototype.constructor = __WDRating;

	var ms_eRateEntier = 0;
	var ms_eRateDemi = 1;
	var ms_eRateReel = 2;
	var ms_eEtoileSans = -1;
	var ms_eEtoilePleine = 0;
	var ms_eEtoileVide = 1;
	var ms_eEtoileSelection = 2;
	var ms_eEtoileGrise = 3;

	// Classe de DnD : le gestionnaire de clic sous forme de dragdrop pour le champ rating
	__WDRating.prototype.vDrag = (function ()
	{
		// Constructeur
		function __WDDragRating(/*oChampRating*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDDragPotentiometreBase.prototype.constructor.apply(this, arguments);
			}
		};

		// Declare l'heritage
		__WDDragRating.prototype = new WDDragPotentiometreBase();
		// Surcharge le constructeur qui a ete efface
		__WDDragRating.prototype.constructor = __WDDragRating;

		// Indique la valeur courante (uniquement si on est en selection)
		// La valeur retournee est toujours brute, il faut la retraiter par l'appelant selon l'ancienne valeur
		__WDDragRating.prototype._vtabGetValeursSelection = function _vtabGetValeursSelection(oEvent)
		{
			return [this.__dGetValeursSelection(oEvent), undefined];
		};
		__WDDragRating.prototype.__dGetValeursSelection = function __dGetValeursSelection(oEvent)
		{
			// Pour le mode touch on n'a pas la position dans le touchend
			var nPositionX = this._nGetPosXEvent(oEvent);

			var tabDescriptions = this.m_oChamp.tabGetDescriptions(this.m_nIndiceZR);

			var nLargeurDiv = this.m_oChamp.m_oParametres.m_oTailleUneEtoile.m_nX;
			// GP 26/10/2015 : QW263909 : Si la taille se r�duit (responsive web design) this.m_oChamp.m_oParametres.m_oTailleUneEtoile.m_nX n'est plus forc�ment la largeur r�elle.
			if (tabDescriptions[0] && tabDescriptions[0].m_oDiv)
			{
				var oLargeurDivReel = tabDescriptions[0].m_oDiv.offsetWidth;
				if (0 < oLargeurDivReel)
				{
					nLargeurDiv = Math.min(nLargeurDiv, tabDescriptions[0].m_oDiv.offsetWidth)
				}
			}

			// Compare la valeur par rapport au div principaux
			var nLimiteI = tabDescriptions.length / 2;
			for (var i = 0; i < nLimiteI; i++)
			{
				var nEtoile = clWDUtil.bRTL ? nLimiteI - i - 1 : i;
				var oDiv = tabDescriptions[nEtoile * 2].m_oDiv;
				// Si on est en right-to-left il faut prendre le debut du div de fin s'il est visible
				if (clWDUtil.bRTL && clWDUtil.bEstDisplay(tabDescriptions[nEtoile * 2 + 1].m_oDiv, document))
				{
					oDiv = tabDescriptions[nEtoile * 2 + 1].m_oDiv
				}
				// GP 16/07/2012 : Utilisation de getBoundingClientRect()
				// On n'a pas besoin de window.pageXOffset car les coordonn�es de la souris sont aussi relative au viewport (comme la coordonn�e de getBoundingClientRect())
				var nDifference = nPositionX - oDiv.getBoundingClientRect().left;
				// Si on est en dessous c'est que l'on est :
				// - Entre deux div (on a deja teste la presence dans les div precedents)
				// - Avant le premier div (si on teste le premier div
				if (nDifference < 0)
				{
					// Donc on prend l'indice du div qui correspond a la valeur du div precedent
					return clWDUtil.bRTL ? (nEtoile + 1) : nEtoile;
				}
				else if (nDifference < nLargeurDiv)
				{
					// Si on est avant la fin du div : prend la position dans le div
					var dOffsetEtoile = nDifference / nLargeurDiv;
					if (clWDUtil.bRTL)
					{
						dOffsetEtoile = 1.0 - dOffsetEtoile;
					}
					return nEtoile + dOffsetEtoile;
				}
				// Sinon teste le div suivant
			}

			// Non trouve : on prend la valeur maximale
			return clWDUtil.bRTL ? 0 : this.m_oChamp.m_oParametres.m_nNbEtoileMax;
		};
		return __WDDragRating;
	})();
	// Fonction de conversion de chaine en valeur
	__WDRating.prototype._vParseValeur = parseFloat;

	// Declare les fonction une par une

	// Recupere les �l�ments pour la gestion du clic
	__WDRating.prototype._vtabGetElements = function _vtabGetElements(oConteneur)
	{
		// GP 16/11/2016 : QW280146 : On m�morise pour chaque li son "style" initial par l'ajout d'une classe
		var tabElements = oConteneur.getElementsByTagName("li");
		clWDUtil.bForEach(tabElements, function(oElement)
		{
			if ("none" === oElement.style.display)
			{
				clWDUtil.ActiveDesactiveClassName(oElement, "wbRatingDisplay", true);
			}
			if ("none" === oElement.style.backgroundImage)
			{
				clWDUtil.ActiveDesactiveClassName(oElement, "wbRatingBackgroundImage", true);
			}
			return true;
		});
		return tabElements;
	};

	// Borne sup�rireure et inf�rieure
	__WDRating.prototype.vdGetBorneInferieure = function vdGetBorneInferieure()
	{
		return this.m_oParametres.m_nNbEtoileMin;
	};
	__WDRating.prototype.vdGetBorneSuperieure = function vdGetBorneSuperieure()
	{
		return this.m_oParametres.m_nNbEtoileMax;
	};

	// Recupere la valeur arrondie correctement
	__WDRating.prototype._vdArrondiSelection = function _vdArrondiSelection(dValeurSelection, dValeurPrecedente)
	{
		// Calcule la valeur reelle selon la position de la valeur actuelle et les options
		// Si on demande une valeur entiere, il faut arrondir
		switch (this.m_oParametres.m_eGranulariteValeur)
		{
		case ms_eRateEntier:
			// Si on demande une valeur entiere
			return Math.ceil(dValeurSelection);

		case ms_eRateDemi:
			// Si on demande une valeur a la moitie, il faut arrondir dans le bon sens
			if (dValeurSelection < dValeurPrecedente)
			{
				return Math.ceil(dValeurSelection * 2) / 2;
			}
			else if (dValeurSelection > dValeurPrecedente)
			{
				return Math.ceil(dValeurSelection * 2) / 2;
			}
			break;

		case ms_eRateReel:
			// Si on demande une valeur flotante, on ne change pas la valeur
			return dValeurSelection;
		}
	};

	__WDRating.prototype._vMAJAfficheCompletInterne = function _vMAJAfficheCompletInterne(tabValeurs, nIndiceZR, tabValeursSelection)
	{
		var dValeur = tabValeurs[0];
		var dValeurSelection;
		if (tabValeursSelection)
		{
			dValeurSelection = tabValeursSelection[0];
		}

		var tabDescriptions = this.tabGetDescriptions(nIndiceZR);
		// Dans une ligne de ZR invisible ou repliee, le champ n'est pas present
		if (tabDescriptions && (dValeur !== undefined))
		{
			// Supprime le div tertiaire s'il existe
			clWDUtil.bHTMLVideDepuisVariable(this, "m_oDivTertiaire");

			// GP 16/11/2016 : QW280146 : On a m�morise pour chaque li son "style" initial par l'ajout d'une classe
			// On replace le style initial selon cette classe.
			// Ainsi, si on n'a moins d'�toile maintenant (manipulation de ..BorneMax) on masque les �toiles en trop
			clWDUtil.bForEach(tabDescriptions, function(oDescription)
			{
				var oElement = oDescription.m_oDiv;
				if (clWDUtil.bAvecClasse(oElement, "wbRatingDisplay"))
				{
					oElement.style.display = "none";
				}
				if (clWDUtil.bAvecClasse(oElement, "wbRatingBackgroundImage"))
				{
					oElement.style.backgroundImage = "none";
				}
				return true;
			});

			var bGrise = this.oAppelSurLigneTableZR(nIndiceZR, this._bGrise, [], true);

			var nEtoile;
			var nLimiteEtoile = this.m_oParametres.m_nNbEtoileMax;
			for (nEtoile = 0; nEtoile < nLimiteEtoile; nEtoile++)
			{
				// Si la valeur de selection correspond a l'etoile courante
				var bSelection;
				var bDivTertiaire = false;
				if (dValeurSelection !== undefined)
				{
					dValeurSelection = this._vdArrondiSelection(dValeurSelection, dValeur);
					if (dValeurSelection < dValeur)
					{
						bSelection = (Math.floor(dValeurSelection) <= nEtoile) && (nEtoile < dValeur);
					}
					else if (dValeurSelection > dValeur)
					{
						bSelection = (Math.floor(dValeurSelection) > nEtoile) && (nEtoile >= Math.floor(dValeur));
					}
					else
					{
						bSelection = false;
					}
					if ((dValeur > nEtoile) && (dValeur < (nEtoile + 1)) && (dValeurSelection > nEtoile) && (dValeurSelection < (nEtoile + 1)))
					{
						bDivTertiaire = true;
					}
				}

				// Dessine chaque etoile
				this.__AfficheUnDivPrincipal(tabDescriptions, nEtoile, dValeur, bSelection, dValeurSelection, bGrise);
				this.__AfficheUnDivSecondaire(tabDescriptions, nEtoile, dValeur, bSelection, dValeurSelection, bGrise);

				// Si besoin, ajoute le troisieme div
				if (bDivTertiaire)
				{
					this.__AfficheUnDivTertiaire(tabDescriptions, nEtoile, dValeur, bSelection, dValeurSelection, bGrise);
				}
			}

			// 
		}
	};

	// Dessine un div principal (= celui affiche en cas de valeur entiere)
	__WDRating.prototype.__AfficheUnDivPrincipal = function __AfficheUnDivPrincipal(tabDescriptions, nEtoile, dValeur, bSelection, dValeurSelection, bGrise)
	{
		var dLargeur;
		var eEtatEtoile;
		if ((dValeurSelection !== undefined) && (ms_eRateEntier !== this.m_oParametres.m_eGranulariteValeur) && (dValeurSelection > nEtoile) && (dValeurSelection < (nEtoile + 1)))
		{
			if ((dValeur > nEtoile) && (dValeur < (nEtoile + 1)))
			{
				eEtatEtoile = ms_eEtoilePleine;
				dLargeur = Math.min(dValeur, dValeurSelection) - nEtoile;
			}
			else
			{
				dLargeur = dValeurSelection - nEtoile;
				eEtatEtoile = (dValeurSelection > dValeur) ? ms_eEtoileSelection : ms_eEtoilePleine;
			}
		}
		else if ((ms_eRateEntier !== this.m_oParametres.m_eGranulariteValeur) && (dValeur > nEtoile) && (dValeur < (nEtoile + 1)))
		{
			dLargeur = dValeur - nEtoile;
			eEtatEtoile = (bSelection && (dValeurSelection < dValeur)) ? ms_eEtoileSelection : ms_eEtoilePleine;
		}
		else
		{
			dLargeur = 1.0;
			if (bSelection)
			{
				eEtatEtoile = ms_eEtoileSelection;
			}
			else if (dValeur > (nEtoile + 1))
			{
				eEtatEtoile = this.m_oParametres.m_bDessinValeurPrevAvec0 ? ms_eEtoileVide : ms_eEtoilePleine;
			}
			else if (dValeur == (nEtoile + 1))
			{
				eEtatEtoile = ms_eEtoilePleine;
			}
			else
			{
				eEtatEtoile = ms_eEtoileVide;
			}
		}
		this.__AfficheUnDiv(tabDescriptions, nEtoile, false, dLargeur, eEtatEtoile, dValeur, bGrise);
	};

	// Dessine un div secondaire (= celui affiche en cas de valeur non entiere sur l'etoile donnee)
	__WDRating.prototype.__AfficheUnDivSecondaire = function __AfficheUnDivSecondaire(tabDescriptions, nEtoile, dValeur, bSelection, dValeurSelection, bGrise)
	{
		if (ms_eRateEntier !== this.m_oParametres.m_eGranulariteValeur)
		{
			var bVisible;
			var eEtatEtoile;

			if ((dValeurSelection !== undefined) && (dValeurSelection > nEtoile) && (dValeurSelection < (nEtoile + 1)))
			{
				bVisible = true;
				if ((dValeur > nEtoile) && (dValeur < (nEtoile + 1)))
				{
					eEtatEtoile = ms_eEtoileVide;
					dValeur = Math.max(dValeur, dValeurSelection);
				}
				else
				{
					eEtatEtoile = (dValeurSelection > dValeur) ? ms_eEtoileVide : ms_eEtoileSelection;
					dValeur = dValeurSelection;
				}
			}
			else if ((dValeur > nEtoile) && (dValeur < (nEtoile + 1)))
			{
				// Affichee uniquement si on a une valeur non entiere sur la plage de l'etoile courante
				bVisible = true;
				eEtatEtoile = (bSelection && (dValeurSelection > dValeur)) ? ms_eEtoileSelection : ms_eEtoileVide;
			}
			else
			{
				// Masque l'etoile
				bVisible = false;
			}

			if (bVisible)
			{
				var dLargeur = 1.0 - (dValeur - nEtoile);
				this.__AfficheUnDiv(tabDescriptions, nEtoile, true, dLargeur, eEtatEtoile, dValeur, bGrise);
			}
			clWDUtil.SetDisplay(tabDescriptions[nEtoile * 2 + 1].m_oDiv, bVisible);
		}
	};

	// Dessine le div tertiaire (= celui affiche en cas de valeur non entiere sur l'etoile donnee et que l'on est en selection depuis la valeur courante !!)
	__WDRating.prototype.__AfficheUnDivTertiaire = function __AfficheUnDivTertiaire(tabDescriptions, nEtoile, dValeur, bSelection, dValeurSelection, bGrise)
	{
		// Creation du div avant le div secondaire
		var oDivSecondaire = tabDescriptions[nEtoile * 2 + 1].m_oDiv;
		this.m_oDivTertiaire = oDivSecondaire.parentNode.insertBefore(oDivSecondaire.cloneNode(), oDivSecondaire);

		// Et l'affiche
		var dLargeur = Math.abs(dValeur - dValeurSelection);
		var dDebut = Math.min(dValeur, dValeurSelection) - nEtoile;
		if (clWDUtil.bRTL)
		{
			dDebut = 1.0 - (Math.max(dValeur, dValeurSelection) - nEtoile);
		}
		this.__AfficheUnDivInterne(this.m_oDivTertiaire, nEtoile, dLargeur, dDebut, ms_eEtoileSelection, dValeurSelection, bGrise, false);
	};

	// Place les caracteristiques d'un div
	// dLargeur : ]0, 1] : largeur totale de l'etoile utilise
	// nEtat : { 0, 1, 2 } : { Vide, plein, selection }
	__WDRating.prototype.__AfficheUnDiv = function __AfficheUnDiv(tabDescriptions, nEtoile, bDivSecondaire, dLargeur, eEtatEtoile, dValeur, bGrise)
	{
		// dDebut : [0, 1[ : debut de l'affichage du div dans l'etoile (> 0 uniquement avec les etoiles secondaires)
		var dDebut = 0.0;
		if ((dLargeur !== 1.0) && (clWDUtil.bRTL !== bDivSecondaire))
		{
			dDebut = 1.0 - dLargeur;
		}

		this.__AfficheUnDivInterne(tabDescriptions[nEtoile * 2 + (bDivSecondaire ? 1 : 0)].m_oDiv, nEtoile, dLargeur, dDebut, eEtatEtoile, dValeur, bGrise, bDivSecondaire);
	};

	// Place les caracteristiques d'un div
	// dLargeur : ]0, 1] : largeur totale de l'etoile utilise
	// dDebut : [0, 1[ : debut de l'affichage du div dans l'etoile
	// nEtat : { 0, 1, 2 } : { Vide, plein, selection }
	__WDRating.prototype.__AfficheUnDivInterne = function __AfficheUnDivInterne(oDiv, nEtoile, dLargeur, dDebut, eEtatEtoile, dValeur, bGrise, bDivSecondaire)
	{
		// Corrige l'etat en fonction de la disponibilite et de l'etat grise
		eEtatEtoile = this.__eCorrigeEtat(eEtatEtoile, bGrise);

		// Si on est sous IE en mode quirks et que la largeur totale n'est pas un multiple de 2, la largueur va etre mal arrondie
		// Et un element passera a la ligne et ne sera donc pas affiche
		// Le calcul est complique : on test d'abord le cas simple de 50%
		if (bIEQuirks && bDivSecondaire && (dLargeur === 0.5) && (1 === (this.m_oParametres.m_oTailleUneEtoile.m_nX % 2)))
		{
			dLargeur = 0.499;
		}	

		// Calcule la position reelle dans la planche
		// Si on a un offset de debut en tient compte
		var dPosition = eEtatEtoile + dDebut;

		//cas du rating avec les smileys
		if (this.m_oParametres.m_bUnePlancheParValeur)
		{
			dPosition += nEtoile * this.m_oParametres.m_nNbEtatsImageEtoile;
		}

		//backgroundsize support� ?
		if (!bIEQuirks && (!bIE || nIE>8))
		{
			var nBgSize;
			var nLargeurPlanche;
			// Cas du rating avec les smileys
			if (this.m_oParametres.m_bUnePlancheParValeur)
			{
				nBgSize = this.m_oParametres.m_nNbEtatsImageEtoile * this.m_oParametres.m_nNbEtoileMax;
				nLargeurPlanche = this.m_oParametres.m_oTailleUneEtoile.m_nX * this.m_oParametres.m_nNbEtatsImageEtoile * this.m_oParametres.m_nNbEtoileMax;

				var nLargeurDecalage = nLargeurPlanche - this.m_oParametres.m_oTailleUneEtoile.m_nX;

				var nBackgroundPositionPixels = dPosition * this.m_oParametres.m_oTailleUneEtoile.m_nX;

				dPosition = 100 * nBackgroundPositionPixels / nLargeurDecalage;
			}
			//cas du rating avec les �toiles
			else
			{
				// Puis convertit en coordonnees % dans l'image de fond
				dPosition *= this.m_oParametres.m_oTailleUneEtoile.m_nX;	
				dPosition /= (this.m_oParametres.m_oTailleUneEtoile.m_nX * Math.max(1,this.m_oParametres.m_nNbEtatsImageEtoile-1));	
				dPosition *= 100;

				// Calcul le rapport pour positionner la planche dans un plus petit conteneur
				nBgSize = this.m_oParametres.m_nNbEtatsImageEtoile;
				nLargeurPlanche = this.m_oParametres.m_oTailleUneEtoile.m_nX * this.m_oParametres.m_nNbEtatsImageEtoile;

			}

			//cas des valeurs r�elles
			if (dLargeur<1)
			{
				nBgSize /= dLargeur;		
			
				var nPositionBordGaucheEn100p100 = nLargeurPlanche - this.m_oParametres.m_oTailleUneEtoile.m_nX;
				var nPositionBordGaucheEn100p100SelonLargeur = nLargeurPlanche - this.m_oParametres.m_oTailleUneEtoile.m_nX * dLargeur;
				dPosition = dPosition * nPositionBordGaucheEn100p100 / nPositionBordGaucheEn100p100SelonLargeur;
			}
		
			// Fixe les proprietes
			oDiv.style.backgroundSize = (100 * nBgSize)  +"% auto";
			//css
			dPosition = dPosition + "%"; 
		}
		else
		{
			//cas en px
			// Puis convertit en coordonnees dans l'image de fond
			dPosition *= this.m_oParametres.m_oTailleUneEtoile.m_nX;
			//css
			dPosition = "-" + dPosition.toFixed(0) + "px";
		}

		oDiv.style.width = parseInt(dLargeur * 100, 10) + "%";
		if (eEtatEtoile != ms_eEtoileSans)
		{
			oDiv.style.backgroundPosition = dPosition + " center";
			oDiv.style.backgroundImage = "";
		}
		else
		{
			oDiv.style.backgroundImage = "none";
		}

		// Affiche la bulle
		var sBulle;
		if (this.m_oDonnees.m_tabBulles && (nEtoile < this.m_oDonnees.m_tabBulles.length))
		{
			sBulle = this.m_oDonnees.m_tabBulles[nEtoile].m_sBulle;
		}
		if (!sBulle || (sBulle.length == 0))
		{
			var dValeurArrondie;
			switch (this.m_oParametres.m_eGranulariteValeur)
			{
			case ms_eRateEntier:
				dValeurArrondie = dValeur.toFixed(0);
				break;

			case ms_eRateDemi:
				dValeurArrondie = dValeur.toFixed(1);
				break;

			case ms_eRateReel:
				dValeurArrondie = dValeur.toFixed(2);
				break;
			}
			if (!bGrise)
			{
				// Si on est sur une valeur non entiere et que l'on est sur la bulle en cours de modification, on prend la valeur affichee avec deux decimales
				sBulle = ((dLargeur != 1.0) ? dValeurArrondie : (nEtoile + 1)) + "/" + this.m_oParametres.m_nNbEtoileMax;
			}
			else
			{
				// On affiche toujours la note
				sBulle = dValeurArrondie + "/" + this.m_oParametres.m_nNbEtoileMax;
			}
		}
		oDiv.title = sBulle;
	};

	// Corrige l'etat en fonction de la disponibilite et de l'etat grise
	__WDRating.prototype.__eCorrigeEtat = function __eCorrigeEtat(eEtatEtoile, bGrise)
	{
		var eEtatSiNonDisponible;
		switch (eEtatEtoile)
		{
		default:
		case ms_eEtoilePleine:
			// Si besoin applique l'etat grise
			if (bGrise)
			{
				eEtatEtoile = ms_eEtoileGrise;
			}
			// Si non disponible : dessine une etoile pleine (aussi pour le cas grise)
			eEtatSiNonDisponible = ms_eEtoilePleine;
			break;

		case ms_eEtoileVide:
			// Si non disponible : ne dessine rien
			eEtatSiNonDisponible = ms_eEtoileSans;
			break;

		case ms_eEtoileSelection:
			// Si non disponible : dessine une etoile pleine
			eEtatSiNonDisponible = ms_eEtoilePleine;
			break;
		}
		return (eEtatEtoile < this.m_oParametres.m_nNbEtatsImageEtoile) ? eEtatEtoile : eEtatSiNonDisponible;
	};

	// Execution des validations sp�cifiques au champ et affectation dans le bon membre
	__WDRating.prototype.__xvoSetBorneMinMax = function __xvoSetBorneMinMax(oValeur, bBorneMax)
	{
		var nPlageMin;
		var nPlageMax;
		if (bBorneMax)
		{
			// Validation du param�tre : la plage admissible est [2, 100]
			nPlageMin = 2;
			nPlageMax = 100;
		}
		else
		{
			// Validation du param�tre : la plage admissible est [0, 1]
			nPlageMin = 0;
			nPlageMax = 1;
		}

		if ((oValeur < nPlageMin) || (nPlageMax < oValeur))
		{
			throw new WDErreur(301, oValeur, nPlageMin, nPlageMax);
		}

		// Affectation dans le bon membre
		if (bBorneMax)
		{
			this.m_oParametres.m_nNbEtoileMax = oValeur;
		}
		else
		{
			this.m_oParametres.m_nNbEtoileMin = oValeur;
		}

		// Ne reforce pas la valeur. La valeur sera utilis�e par _dGetValeurDansBornes.
		// Dans le cas de la borne min ce n'est pas le cas du code serveur : que faire ?

		return oValeur;
	};

	return __WDRating;
})();

//////////////////////////////////////////////////////////////////////////
// Manipulation d'un champ potentiometre
var WDPotentiometre = (function ()
{
	"use strict";

	function __WDPotentiometre(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDPotentiometreBase.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
		}
	};

	// Declare l'heritage
	__WDPotentiometre.prototype = new WDPotentiometreBase();
	// Surcharge le constructeur qui a ete efface
	__WDPotentiometre.prototype.constructor = __WDPotentiometre;

	var ms_eSelectionRien = 0;
	var ms_eSelectionDebut = 1;
	var ms_eSelectionFin = 2;
	var ms_eSelectionEntreCurseur = 3;

	// Classe de DnD : le gestionnaire de clic sous forme de dragdrop pour le champ potentiometre
	__WDPotentiometre.prototype.vDrag = (function ()
	{
		// Constructeur
		function __WDDragPotentiometre(/*oChampPotentiometre*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDDragPotentiometreBase.prototype.constructor.apply(this, arguments);
			}
		};

		// Declare l'heritage
		__WDDragPotentiometre.prototype = new WDDragPotentiometreBase();
		// Surcharge le constructeur qui a ete efface
		__WDDragPotentiometre.prototype.constructor = __WDDragPotentiometre;

		// Appel lors du debut d'un clic pour le deplacement
		// Pose les hooks
		__WDDragPotentiometre.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent/*, nIndiceZR*/)
		{
			// Memorise l'�l�ment sur lequel on a cliqu� si c'est un des curseurs
			var oSource = this._oGetOriginalTarget(oEvent);
			if (oSource && clWDUtil.bBaliseEstTag(oSource, "a"))
			{
				this.m_oCurseur = oSource;
				this.m_nCurseurOffsetM = -this.m_oChamp.nGetDimensionPrincipale(this.m_oCurseur) / 2 + this.oGetOffsetElement(oEvent, this.m_oChamp.m_oParametres.m_bVertical);
			}

			// Appel de la classe de base : sauve la position de la souris et place les hooks
			if (!WDDragPotentiometreBase.prototype._vbOnMouseDown.apply(this, arguments))
			{
				// Supprime l'�lement sur lequel on a clique
				delete this.m_nCurseur;
				delete this.m_nCurseurOffsetM;
				delete this.m_oCurseur;
				return false;
			}

			return true;
		};

		// Appel lors du relachement de la souris
		__WDDragPotentiometre.prototype._vOnMouseUp = function _vOnMouseUp(/*oEvent*/)
		{
			// Pour avoir une liberation complete
			// Appel de la classe de base
			WDDragPotentiometreBase.prototype._vOnMouseUp.apply(this, arguments);

			// Supprime l'�lement sur lequel on a clique
			delete this.m_nCurseur;
			delete this.m_nCurseurOffsetM;
			delete this.m_oCurseur;
		};

		// Indique la valeur courante (uniquement si on est en selection)
		// La valeur retournee est toujours brute, il faut la retraiter par l'appelant selon l'ancienne valeur
		__WDDragPotentiometre.prototype._dGetValeursSelection = function _dGetValeursSelection(oEvent)
		{

			// Trouve le conteneur et ses dimensions
			var nDimensionPrincipaleExtensionFond = this.m_oChamp.nGetDimensionPrincipaleExtensionFond();
			var nDimension = this.m_oChamp.nGetDimensionPrincipale(this.m_oChamp.m_oHote) - nDimensionPrincipaleExtensionFond;
			// Maintenant que l'on n'a un curseur : utilise la position avec l'offset
			var nPosition = this.oGetOffsetElementAutre(oEvent, this.m_oChamp.m_oHote, this.m_oChamp.m_oParametres.m_bVertical) - this.m_nCurseurOffsetM;
			var dValeur = Math.min(Math.max(0, nPosition - nDimensionPrincipaleExtensionFond / 2), nDimension) / nDimension;
			if (this.m_oChamp.m_oParametres.m_bVertical)
			{
				dValeur = 1 - dValeur;
			}
			// Maintenant tranforme dans la plage
			return this.m_oChamp.vdGetBorneInferieure() + (this.m_oChamp.vdGetBorneSuperieure() - this.m_oChamp.vdGetBorneInferieure()) * dValeur;
		};

		// Indique la valeur courante (uniquement si on est en selection)
		// La valeur retournee est toujours brute, il faut la retraiter par l'appelant selon l'ancienne valeur
		__WDDragPotentiometre.prototype._vtabGetValeursSelection = function _vtabGetValeursSelection(oEvent)
		{
			// Si on n'a pas encore de curseur
			if (!this.m_oCurseur)
			{
				// D�place le bon curseur en �tant centr� dessus
				this.m_nCurseurOffsetM = 0;
				this.m_oCurseur = this.m_oChamp.oGetCurseur(0);
			}

			return [this._dGetValeursSelection(oEvent), undefined];
		};

		return __WDDragPotentiometre;
	})();
	// Fonction de conversion de chaine en valeur
	__WDPotentiometre.prototype._vParseValeur = parseInt;

	// Initialisation :
	__WDPotentiometre.prototype.Init = function Init()
	{
		// Modifie les calculs selon orientation (avant l'appel de la classe de base qui fait le dessin)
		this.__SetOrientation();

		// Appel de la methode de la classe de base
		WDPotentiometreBase.prototype.Init.apply(this, arguments);
	};

	// Applique les parametres
	__WDPotentiometre.prototype._vAppliqueParametres = function _vAppliqueParametres(/*oParametreFusion*/)
	{
		WDPotentiometreBase.prototype._vAppliqueParametres.apply(this, arguments);

		// Modifie les calculs selon orientation
		this.__SetOrientation();
	};

	// Modifie les calculs selon orientation
	__WDPotentiometre.prototype.__SetOrientation = function __SetOrientation()
	{
		// Modifie les fonctions de calcul
		if (this.m_oParametres.m_bVertical)
		{
			// Retourne la largeur/hauteur (selon le sens) d'un �l�ment
			this.nGetDimensionPrincipale = this._nGetOffsetHeight;
			this.sGetDimensionPrincipaleStyle = function(oElement) { return oElement.style.height; };
			this.SetDimensionPrincipaleStyle = this.s_SetStyleHeight;
			// GP 19/10/2012 : Attention : bottom pas top !!!!
			this.SetPositionPrincipaleStyle = this.s_SetStyleBottom;
		}
		else
		{
			// Retourne la largeur/hauteur (selon le sens) d'un �l�ment
			this.nGetDimensionPrincipale = this._nGetOffsetWidth;
			this.sGetDimensionPrincipaleStyle = function(oElement) { return oElement.style.width; };
			this.SetDimensionPrincipaleStyle = this.s_SetStyleWidth;
			this.SetPositionPrincipaleStyle = this.s_SetStyleLeft;
		}
	};

	// Recupere les �l�ments pour la gestion du clic
	__WDPotentiometre.prototype._vtabGetElements = function _vtabGetElements(oConteneur)
	{
		return [ oConteneur ];
	};

	// Borne sup�rireure et inf�rieure
	__WDPotentiometre.prototype.vdGetBorneInferieure = function vdGetBorneInferieure()
	{
		return this.m_oDonnees.m_nBorneInferieure;
	};
	__WDPotentiometre.prototype.vdGetBorneSuperieure = function vdGetBorneSuperieure()
	{
		return this.m_oDonnees.m_nBorneSuperieure;
	};

	// Recupere la valeur arrondie correctement
	__WDPotentiometre.prototype._vdArrondiSelection = function _vdArrondiSelection(dValeurSelection/*, dValeurPrecedente*/)
	{
		// Si on demande une valeur entiere
		return Math.ceil(dValeurSelection);
	};

	// MAJ de l'affichage (prend en compte le changement possible de taille du champ externe)
	__WDPotentiometre.prototype._vMAJAfficheCompletInterne = function _vMAJAfficheCompletInterne(tabValeurs, nIndiceZR, tabValeursSelection)
	{
		// Si dans une Table/ZR.
		var oHote = this.bGestionTableZR() ? this.oGetElementByIdZRIndice(document, nIndiceZR, this.ms_sSuffixeHote) : this.m_oHote;

		if (tabValeursSelection !== undefined)
		{
			// Le champ n'est normalement pas en lecture seule (d�j� test� par les appelant)
			//		this.m_oChamp.bLectureSeuleOuGriseExterne(this.m_nIndiceZR)
			// On force la valeur pour avoir un affichage correct

			// Et on arrondi correctement
			// Ce n'est pas fait dans le champ rating car le dessin tient compte de la valeur et de la valeur s�lectionn�e
			// Ici la valeur s�lectionn� devient imm�diatement la valeur donc il faut avoir un arrondi correct sinon moment du larcher le curseur risque de bouger
			// car la valeur finale est correctement arrondie
			this.__ArrondiSelection(tabValeursSelection, tabValeurs);
			tabValeurs = tabValeursSelection;
		}
		// GP 03/10/2012 : Si on est dans une ZR, la valeur n'a pas �t� "valid�e" par le code serveur (et n'est donc pas dans les bornes
		var dValeurInferieure = this._dGetValeurDansBornes(tabValeurs[0]);
		var dValeurSuperieure = this._dGetValeurDansBornes(tabValeurs[1]);

		var dPosition;
		var dLongueur;
		var dValeurPourcent = (dValeurInferieure - this.vdGetBorneInferieure()) / (this.vdGetBorneSuperieure() - this.vdGetBorneInferieure());
		switch (this.m_oParametres.m_eSelection)
		{
			case ms_eSelectionRien:
				dPosition = dValeurPourcent;
				// GP 30/11/2012 : QW227089 : Possible pour les champs potentiom�tre d'intervalle
				if (!isNaN(dValeurSuperieure))
				{
					dLongueur = (dValeurSuperieure - dValeurInferieure) / (this.vdGetBorneSuperieure() - this.vdGetBorneInferieure());
				}
				break;
			case ms_eSelectionDebut:
				dLongueur = dValeurPourcent;
				break;
			case ms_eSelectionFin:
				dPosition = dValeurPourcent;
				dLongueur = 1 - dValeurPourcent;
				break;
			case ms_eSelectionEntreCurseur:
				dPosition = dValeurPourcent;
				dLongueur = (dValeurSuperieure - dValeurInferieure) / (this.vdGetBorneSuperieure() - this.vdGetBorneInferieure());
				break;
		}

		var oDivValeur = clWDUtil.oGetElementByTagAndClass(oHote, "div", "wbSliderValeur");
		if (undefined !== dPosition)
		{
			this.SetPositionPrincipaleStyle(oDivValeur, (100 * dPosition) + "%");
		}
		if (undefined !== dLongueur)
		{
			this.SetDimensionPrincipaleStyle(oDivValeur, (100 * dLongueur) + "%");

			// GP 19/05/2015 : QW257543/QW257570 : Si le potentiometre est avec le fond �tendu, le "padding-left" inject� pour faire le d�calage fausse tous les calculs :
			// Compense pas un right/bottom dans les cas simple.
			if (undefined === dPosition)
			{
				// On fait un calcul simple (ne sera pas exactement correct en cas de redimensionnement)
				var nPaddingLeftDivValeur = parseInt(clWDUtil.oGetCurrentStyle(oDivValeur).paddingLeft, 10);
				if (0 < nPaddingLeftDivValeur)
				{
					// En fait on prend la plus petite valeur entre :
					// - dLongueur * Largeur totale <= compense le non d�calage au d�but
					// - (1 - dLongueur) * paddingLeft <=  compense le padding-left surle reste du parcours.
					clWDUtil.oGetElementByTagAndClass(oDivValeur, "a", "wbSliderCurseurPrincipal").style.right = (-Math.min(oHote.offsetWidth * dLongueur, (1 - dLongueur) * nPaddingLeftDivValeur)) + "px";
				}
			}

			// GP 19/10/2012 : QW224166 : On a changer la largeur de la selection.
			// Si la s�lection est trop �troite, il faut masque une partie des bordures en mode 3 �tats
			this.__MasqueDiv3ImagesSiBesoin(oDivValeur, dLongueur);
		}
	};
	// GP 19/10/2012 : QW224166 : On a changer la largeur de la selection.
	// Si la s�lection est trop �troite, il faut masque une partie des bordures en mode 3 �tats
	__WDPotentiometre.prototype.__MasqueDiv3ImagesSiBesoin = function __MasqueDiv3ImagesSiBesoin(oDivValeur, dLongueur)
	{
		// GP 12/12/2012 : QW227788 : En vertical on manipule des tr
		var sTag = "div";
		var nLimite = 0;
		if (this.m_oParametres.m_bVertical)
		{
			// GP 12/12/2012 : QW227788 : En vertical les tr on une hauteur minimum de 1
			// On donc une possible erreur de 1 mais c'est moins pire que le d�calage de l'affichage
			sTag = "tr";
			nLimite = 1;
			// En plus avec IE si la hauteur totale est de z�ro : il y a un effet d'affichage l'overflow ne fonctionne pas)
			// On masque donc si besoin le curseur
			if (bIEQuirks9Max)
			{
				clWDUtil.SetDisplay(oDivValeur.firstElementChild, dLongueur > 0.0);
			}
		}
		// Trouve les 3 divs
		var oDivGauche = clWDUtil.oGetElementByTagAndClass(oDivValeur, sTag, "wbSliderGauche");
		var oDivDroite = clWDUtil.oGetElementByTagAndClass(oDivValeur, sTag, "wbSliderDroite");
		var oDivRepeat = clWDUtil.oGetElementByTagAndClass(oDivValeur, sTag, "wbSliderRepeat");

		// Si on est bien en mode 3 images
		if (oDivGauche && oDivDroite && oDivRepeat)
		{
			// Redonne leurs dimensions aux divs
			this.__SupprimeDimensionPrincipaleStyle(oDivGauche);
			this.__SupprimeDimensionPrincipaleStyle(oDivDroite);

			// Regarde la dimension du div r�p�t�
			// GP 25/01/2016 : QW267770 : Il y a un truc bizarre avec les ZRs (probablement li� au ancrage ou autre).
			// Filtre le cas des �l�ments non affich�es pour ne pas mettre 0 quand on lit 0 car l'�l�ment n'est pas affich�.
			if ((this.nGetDimensionPrincipale(oDivRepeat) <= nLimite) && clWDUtil.bEstDisplay(oDivRepeat, document))
			{
				// Il faut r�duire un des divs
				// => Prend la taille disponible
				var nTailleTotale = this.nGetDimensionPrincipale(oDivValeur);
				// Selon le mode
				switch (this.m_oParametres.m_eSelection)
				{
				// On ne doit pas passer par ici (filtr� dans _vMAJAfficheCompletInterne)
	//			case ms_eSelectionRien:
	//				break;
				case ms_eSelectionDebut:
					this.SetDimensionPrincipaleStyle(oDivDroite, Math.max(0, nTailleTotale - this.nGetDimensionPrincipale(oDivGauche)));
					break;
				case ms_eSelectionFin:
					this.SetDimensionPrincipaleStyle(oDivGauche, Math.max(0, nTailleTotale - this.nGetDimensionPrincipale(oDivDroite)));
					break;
				case ms_eSelectionEntreCurseur:
					var nTailleGauche = Math.floor(nTailleTotale / 2);
					this.SetDimensionPrincipaleStyle(oDivGauche, nTailleGauche);
					this.SetDimensionPrincipaleStyle(oDivDroite, (nTailleTotale - nTailleGauche));
					break;
				}
			}
		}
	};
	// Supprime le style de la dimension principale si surcharge
	__WDPotentiometre.prototype.__SupprimeDimensionPrincipaleStyle = function __SupprimeDimensionPrincipaleStyle(oElement)
	{
		if ("" != this.sGetDimensionPrincipaleStyle(oElement))
		{
			this.SetDimensionPrincipaleStyle(oElement, "");
		}
	};

	// Execution des validations sp�cifiques au champ et affectation dans le bon membre
	__WDPotentiometre.prototype.__xvoSetBorneMinMax = function __xvoSetBorneMinMax(oValeur, bBorneMax)
	{
		// Affectation dans le bon membre
		if (bBorneMax)
		{
			return this.m_oDonnees.m_nBorneSuperieure = oValeur;
		}
		else
		{
			return this.m_oDonnees.m_nBorneInferieure = oValeur;
		}
	};

	// Dimension totale des extensions
	__WDPotentiometre.prototype.nGetDimensionPrincipaleExtensionFond = function nGetDimensionPrincipaleExtensionFond()
	{
		return this.m_oParametres.m_bExtensionFond ? this._nGetDimensionPrincipaleCurseurMax() : 0;
	};

	// Largeur/hauteur (selon le sens) du plus grand curseur du champ
	__WDPotentiometre.prototype._nGetDimensionPrincipaleCurseurMax = function _nGetDimensionPrincipaleCurseurMax()
	{
		var tabCurseurs = this.m_oHote.getElementsByTagName("a");
		var nLimiteI = tabCurseurs.length;
		var nDimension = 0;
		for (var i = 0; i < nLimiteI; i++)
		{
			nDimension = Math.max(this.nGetDimensionPrincipale(tabCurseurs[i]), nDimension);
		}

		return nDimension;
	};

	// Retourne un des curseur
	__WDPotentiometre.prototype.oGetCurseur = function oGetCurseur(nCurseur)
	{
		return this.m_oHote.getElementsByTagName("a")[nCurseur];
	};

	return __WDPotentiometre;
})();

//////////////////////////////////////////////////////////////////////////
// Manipulation d'un champ potentiometre d'intervalle
var WDRangeSlider = (function ()
{
	"use strict";

	function __WDRangeSlider(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDPotentiometre.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees ]
		}
	};

	// Declare l'heritage
	__WDRangeSlider.prototype = new WDPotentiometre();
	// Surcharge le constructeur qui a ete efface
	__WDRangeSlider.prototype.constructor = __WDRangeSlider;

	// Recupere la valeur
	__WDRangeSlider.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp)
	{
		// GP 26/10/2012 : QW224942 : Rebond sur ..ValeurInf�rieure
		return this.GetProp(this.XML_CHAMP_PROP_NUM_VALEURINFERIEURE, oEvent, sValeur, oChamp);
	};

	// Ecriture de la valeur du champ en programmation
	__WDRangeSlider.prototype.SetValeur = function SetValeur(oEvent, sValeur, oChamp)
	{
		// GP 26/10/2012 : QW224942 : Rebond sur ..ValeurInf�rieure
		return this.SetProp(this.XML_CHAMP_PROP_NUM_VALEURINFERIEURE, oEvent, sValeur, oChamp);
	};

	// Lit les proprietes dont l'indication
	__WDRangeSlider.prototype.GetProp = function GetProp(eProp, oEvent, oValeur/*, oChamp*/)
	{
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_VALEURINFERIEURE:
			// GP 26/10/2012 : QW224942 : ..Valeur fait un rebond sur ..ValeurInf�rieure
			return this.__GetValeurChampFormulaireUneValeur(oValeur, false);
		case this.XML_CHAMP_PROP_NUM_VALEURSUPERIEURE:
			// GP 10/10/2012 : On ne recoit pas oChamp (car la Js recherche "ALIAS" et pas "ALIAS_DATA"
			// Pour ne pas changer pour la JS (donc pour les autres champs)
			// Ici oValeur recoit la valeur de ALIAS_DATA (ou l'attribut en cas d'attribut)
			return this.__GetValeurChampFormulaireUneValeur(oValeur, true);
		default:
			// Retourne a l'impl�mentation de la classe de base avec la valeur �ventuellement modifi�e
			return WDPotentiometre.prototype.GetProp.apply(this, arguments);
		}
	};

	__WDRangeSlider.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp/*, oXMLAction*/)
	{
		// Implementation de la classe de base
		oValeur = WDPotentiometre.prototype.SetProp.apply(this, arguments);

		// Force le champ
		var oChampFormulaireSav;
		try
		{
			if (oChamp)
			{
				oChampFormulaireSav = this.m_oChampFormulaire;
				this.m_oChampFormulaire = oChamp;
			}

			var tabValeurs;
			switch (eProp)
			{
			case this.XML_CHAMP_PROP_NUM_VALEURINFERIEURE:
				// GP 26/10/2012 : QW224942 : ..Valeur fait un rebond sur ..ValeurInf�rieure
				tabValeurs = [this._vParseValeur(oValeur), this.__GetValeurChampFormulaireUneValeur(oChamp.value, true)];
				// Teste la validit� de la valeur
				if (tabValeurs[1] < tabValeurs[0])
				{
					// Si invalide on d�place l'autre borne
					tabValeurs[1] = tabValeurs[0];
				}
				// GP 29/11/2012 : QW227018 : Il faut bien �videment demander la MAJ graphique
				this._vSetValeur(tabValeurs, undefined, true);
				return oChamp.value;
			case this.XML_CHAMP_PROP_NUM_VALEURSUPERIEURE:
				// GP 25/10/2012 : QW224731 : Passe par _vSetValeur pour avoir un redessin
				tabValeurs = [this.__GetValeurChampFormulaireUneValeur(oChamp.value, false), this._vParseValeur(oValeur)];
				// Teste la validit� de la valeur
				if (tabValeurs[1] < tabValeurs[0])
				{
					// Si invalide on d�place l'autre borne
					tabValeurs[0] = tabValeurs[1];
				}
				this._vSetValeur(tabValeurs, undefined, true);
				return oChamp.value;
			default:
				// Retourne inchangee la valeur de la propriete
				return oValeur;
			}
		}
		finally
		{
			if (undefined !== oChampFormulaireSav)
			{
				this.m_oChampFormulaire = oChampFormulaireSav;
			}
		}
	};

	// Classe de DnD : le gestionnaire de clic sous forme de dragdrop pour le champ range slider
	__WDRangeSlider.prototype.vDrag = (function ()
	{
		var __WDDragPotentiometre = WDPotentiometre.prototype.vDrag;

		// Constructeur
		function __WDDragRangeSlider(/*oChampRangeSlider*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				__WDDragPotentiometre.prototype.constructor.apply(this, arguments);
			}
		};

		// Declare l'heritage
		__WDDragRangeSlider.prototype = new __WDDragPotentiometre();
		// Surcharge le constructeur qui a ete efface
		__WDDragRangeSlider.prototype.constructor = __WDDragRangeSlider;

		// Trouve le curseur le plus proche selon la valeur
		__WDDragRangeSlider.prototype.__nGetCurseur = function __nGetCurseur(dValeurSelection, tabValeurs)
		{
			if (dValeurSelection <= tabValeurs[0])
			{
				// Le clic est avant la borne inf�rieure de la s�lection
				return 0;
			}
			else if (dValeurSelection >= tabValeurs[1])
			{
				// Le clic est apr�s la borne inf�rieure de la s�lection
				return 1;
			}
			else if ((dValeurSelection - tabValeurs[0]) <= (tabValeurs[1] - dValeurSelection))
			{
				// Le clic est plus proche du curseur de la borne inf�rieure de la s�lection
				return 0;
			}
			else
			{
				// Le clic est plus proche du curseur de la borne sup�rieure de la s�lection
				return 1;
			}
		};

		// Indique la valeur courante (uniquement si on est en selection)
		// La valeur retournee est toujours brute, il faut la retraiter par l'appelant selon l'ancienne valeur
		__WDDragRangeSlider.prototype._vtabGetValeursSelection = function _vtabGetValeursSelection(oEvent)
		{
			if (!this.m_oCurseur)
			{
				// On n'a pas encore de curseur : il faut decider si on bouge le curseur de la borne inf�rieure ou sup�rieure de la s�lection
				// _dGetValeursSelection a besoin de this.m_nCurseurOffsetM. Comme on sait que l'on n'est pas sur un curseur il n'y a pas de probl�mes
				this.m_nCurseurOffsetM = 0;
			}

			// Trouve la valeur.
			var dValeurSelection = this._dGetValeursSelection(oEvent);
			// Et les valeurs actuelles
			var tabValeurs = this.m_oChamp.tabGetValeurs(this.m_nIndiceZR);

			if (!this.m_oCurseur)
			{
				// On n'a pas encore de curseur : il faut decider si on bouge le curseur de la borne inf�rieure ou sup�rieure de la s�lection
				this.m_nCurseur = this.__nGetCurseur(dValeurSelection, tabValeurs);
				this.m_oCurseur = this.m_oChamp.oGetCurseur(this.m_nCurseur);
			}
			else if (undefined === this.m_nCurseur)
			{
				// Si on a d�j� un curseur mais pas m_nCurseur : c'est le premier appel apr�s un clic sur le curseur
				// => Calcule si besoin si c'est le curseur superieur ou inferieur
				this.m_nCurseur = (this.m_oCurseur != this.m_oChamp.oGetCurseur(0)) ? 1 : 0;

				if (tabValeurs[0] == tabValeurs[1])
				{
					// Normalement m_nCurseurOffsetM ne change pas car les deux curseurs sont superpos�s
					switch (tabValeurs[0])
					{
					case this.m_oChamp.vdGetBorneInferieure():
						// Au d�but : prend le s�lecteur de la borne sup�rieure de l'intervalle
						this.m_nCurseur = 1;
						break;
					case this.m_oChamp.vdGetBorneSuperieure():
						// Au d�but : prend le s�lecteur de la borne inferieure de l'intervalle
						this.m_nCurseur = 0;
						break;
					default:
						// N'importe ou au milieu : normalement on prend le curseur au dessus
						// sauf que si les curseurs n'ont pas la m�me taille : cela ne fonctionne pas (car on peut cliquer sur le curseur du dessous)
						this.m_nCurseur = (dValeurSelection < tabValeurs[0]) ? 0 : 1;
						break;
					}
					this.m_oCurseur = this.m_oChamp.oGetCurseur(this.m_nCurseur);
				}
			}
			else
			{
				// Il faut �tre sur que le curseur reste dans sa plage
				switch (this.m_nCurseur)
				{
				case 0:
					dValeurSelection = Math.min(dValeurSelection, tabValeurs[1]);
					break;
				case 1:
					dValeurSelection = Math.max(tabValeurs[0], dValeurSelection);
					break;
				}
			}

			tabValeurs[this.m_nCurseur] = dValeurSelection;
			return tabValeurs;
		};

		return __WDDragRangeSlider;
	})();

	// Ecrit une des valeurs dans le champ formulaire
	__WDRangeSlider.prototype.__SetValeurChampFormulaireUneValeur = function __SetValeurChampFormulaireUneValeur(oChamp, sValeur, bValeurSuperieure)
	{
		if (oChamp)
		{
			var tabValeurs = oChamp.value.split(",");
			tabValeurs[bValeurSuperieure ? 1 : 0] = sValeur;
			oChamp.value = tabValeurs.join(",");
		}
	};
	__WDRangeSlider.prototype.__GetValeurChampFormulaireUneValeur = function __GetValeurChampFormulaireUneValeur(oValeur, bValeurSuperieure)
	{
		return this._vParseValeur(oValeur.split(",")[bValeurSuperieure ? 1 : 0]);
	};

	// Ecrit la valeur du champ formulaire si il existe
	__WDRangeSlider.prototype._vSetValeurChampFormulaire = function _vSetValeurChampFormulaire(sValeur)
	{
		this.__SetValeurChampFormulaireUneValeur(this.m_oChampFormulaire, sValeur, false);
	};

	// Fixe la valeur
	__WDRangeSlider.prototype._vSetValeur = function _vSetValeur(tabValeursSelection/*, nIndiceZR*//*, bMAJAfficheComplet*/)
	{
		// Valide la valeur
		var dValeurSuperieure = tabValeursSelection[1];
		if (!isNaN(dValeurSuperieure))
		{
			dValeurSuperieure = this._dGetValeurDansBornes(dValeurSuperieure);

			// Modifie la valeur dans les parametres
			this.m_oDonnees.m_dValeurSuperieure = dValeurSuperieure;

			// Gere le cas de la ZR
			// => Deja gere au niveau parent si besoin (OnChange)
			// (pas dans le cas de SetValeur car on n'est alors pas en ZR)
			// On utilise donc directement __MAJAfficheCompletInterne

			// WDPotentiometre.prototype._vSetValeur fait _vSetValeurChampFormulaire et __MAJAfficheCompletZR
			this.__SetValeurChampFormulaireUneValeur(this.m_oChampFormulaire, dValeurSuperieure, true);
		}

		// Appel de la classe de base pour la valeur inf�rieure (d�clenche le redessin)
		WDPotentiometre.prototype._vSetValeur.apply(this, arguments);
	};

	// Trouve la valeur du champ selon l'indice de la ZR
	// Modifie tabIndiceZRSav si besoin pour stocker nIndiceZRSav
	__WDRangeSlider.prototype.vtabGetValeurs = function vtabGetValeurs()
	{
		// Appel de la classe de base pour la valeur minimum
		var tabValeurs = WDPotentiometre.prototype.vtabGetValeurs.apply(this, arguments);

		if (this.bGestionTableZR())
		{
			if (this.m_oChampFormulaire)
			{
				tabValeurs[1] = this.__GetValeurChampFormulaireUneValeur(this.m_oChampFormulaire.value, true);
			}
		}
		else
		{
			tabValeurs[1] = this.m_oDonnees.m_dValeurSuperieure;
		}

		return tabValeurs;
	};

	return __WDRangeSlider;
})();