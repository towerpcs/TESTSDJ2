// WDSaisie.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS bIE nIE bIEQuirks
// - WDAJAX.js
///#GLOBALS clWDAJAXMain
// - WDChamp.js
///#GLOBALS WDChamp

var WDSaisie = (function()
{
	"use strict";

	// GP 10/12/2012 : Si le navigateur g�re le HTML5, on utilise l'attribut placeholder du HTML5
	var bPlaceHolder = (!bIE) || ((10 <= nIE) && ((!bIEQuirks) || (6 <= document.documentMode)));

	// Affiche le style de l'indication
	function __SetStyle (oChamp)
	{
		// Sauve la couleur et le style de la police
		var oStyle = clWDUtil.oGetCurrentStyle(oChamp);
		oChamp.sIndicationColor = oStyle.color;
		oChamp.sIndicationFontStyle = oStyle.fontStyle;

		// Et met les styles demande
		oChamp.style.color = sIndicationCouleur;
		oChamp.style.fontStyle = sIndicationStyleF;

		oChamp.bIndication = true;
	}
	// Supprime le style de l'indication
	function __ClearStyle (oChamp)
	{
		// Restaure la couleur et le style de la police
		var oStyle = clWDUtil.oGetCurrentStyle(oChamp);
		// Sauf si la couleur a ete entre temps par programmation
		if ((oStyle.color === sIndicationCouleur) && (oChamp.sIndicationColor !== undefined))
		{
			oChamp.style.color = oChamp.sIndicationColor;
			oChamp.sIndicationColor = undefined;
		}
		// Pareil pour le style de la police
		if ((oStyle.fontStyle === sIndicationStyleF) && (oChamp.sIndicationFontStyle !== undefined))
		{
			oChamp.style.fontStyle = oChamp.sIndicationFontStyle;
			oChamp.sIndicationFontStyle = undefined;
		}

		if (oChamp.bIndication !== undefined)
		{
			oChamp.bIndication = false;
		}
	}

	// Manipulation d'un champ de saisie
	function __WDSaisie(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChamp.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ sIndication, sAliasChampCalendrier (undefined possible), sFormatAffichage (undefined possible : uniquement avec un champ calendrier) ]
			var sIndication = tabParametresSupplementaires[0];
			var sAliasChampCalendrier = tabParametresSupplementaires[1];
			var sFormatAffichage = tabParametresSupplementaires[2];

			this.m_sIndication = String(sIndication);
			this.m_sAliasChampCalendrier = sAliasChampCalendrier;
			this.m_sFormatAffichage = sFormatAffichage;

			this.m_oObjetChampCalendrier = null;
			this.m_bDepuisOnChange = false;
			this.m_bChangeDepuisCalendrier = false;
		}
	}

	// Declare l'heritage
	__WDSaisie.prototype = new WDChamp();
	// Surcharge le constructeur qui a ete efface
	__WDSaisie.prototype.constructor = __WDSaisie;

	// Initialisation :
	__WDSaisie.prototype.Init = function Init()
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype.Init.apply(this, arguments);

		// Place l'indication si besoin
		this.RAZIndication();
	};

	// Trouve les divers elements : liaison avec le HTML
	__WDSaisie.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire, sSuffixeHote*/)
	{
		// Appel de la methode de la classe de base avec les bon param�tres
		WDChamp.prototype._vLiaisonHTML.apply(this, arguments);

		// Sauve le champ calendrier associe
		if (this.m_sAliasChampCalendrier)
		{
			this.m_oObjetChampCalendrier = clWDUtil.m_oChamps.oGetChampDirect(this.m_sAliasChampCalendrier);
		}
	};

	// Recupere la collection des champs
	__WDSaisie.prototype.__tabGetChamps = function __tabGetChamps()
	{
		// Si la valeur du champ n'est pas lie a un attribut de zone repetee
		if (!this.bGestionTableZR())
		{
			// On force la recuperation : si le champ est dans une ZR sans �tre lie a un attribut pour sa valeur : la liste peut changer
			return document.getElementsByName(this.m_sAliasChamp);
		}
		else
		{
			// Recupere la collection des champs dans la ZR
			var tabChamps = [];
			// PourToutesLignesTableZR conserve le this lors de l'appel
			this.PourToutesLignesTableZR(function(nLigneAbsolueBase1, nDebutBase1)
			{
				// Par compat, on a l'alias de l'attribut dans le nom du champ
//				tabChamps[nLigneAbsolueBase1 - nDebutBase1] = this.oGetElementByNameZRIndice(document, nLigneAbsolueBase1, "");
				tabChamps[nLigneAbsolueBase1 - nDebutBase1] = document.getElementsByName("zrl_" + nLigneAbsolueBase1 + "_" + this.m_sAliasChamp)[0];
			}, this.nGetTableZRDebut());
			return tabChamps;
		}
	};

	// Place l'indication si besoin (Init ou apres un submit AJAX)
	__WDSaisie.prototype.RAZIndication = function RAZIndication()
	{
		// Place l'indication si besoin
		if ("" !== this.m_sIndication)
		{
			// Parcours de la collection des champs
			clWDUtil.bForEachThis(this.__tabGetChamps(), this, function(oChamp)
			{
				// Si par erreur, il y a un id en double (possible en 16-), IE retourne aussi les autres elements, on filtre ce qui n'est pas le champ de saisie
				if (oChamp && (oChamp.value !== undefined))
				{
					this.__PlaceIndication(oChamp, true);
				}
				return true;
			});
		}
	};

	// Lit les proprietes dont l'indication
	__WDSaisie.prototype.GetProp = function GetProp(eProp, oEvent, oValeur, oChamp)
	{
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_INDICATION:
			// Traite le cas de ..Indication : modifie la valeur
			return this.m_sIndication;
		case this.XML_CHAMP_PROP_NUM_TEXTESANSFORMAT:
			// On retourne la valeur (le champ est sans formatage)
			return this.GetProp(this, oEvent, oValeur, oChamp);
		default:
			// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
			return WDChamp.prototype.GetProp.apply(this, arguments);
		}
	};

	// Ecrit les proprietes dont l'indication
	__WDSaisie.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp, oXMLAction)
	{
		// Implementation de la classe de base
		oValeur = WDChamp.prototype.SetProp.apply(this, arguments);

		var oBouton;
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_INDICATION:
			// Traite le cas de ..Indication
			// MAJ de la collection des champs
			var tabChamps = this.__tabGetChamps();

			// Pour bien faire le style : simule une prise de focus et une perte de focus
			// Comme ca on gere bien le cas de l'indication vide avant et vide apres

			if (!bPlaceHolder)
			{
				// Parcours de la collection
				clWDUtil.bForEachThis(tabChamps, this, function(oChamp)
				{
					if (oChamp)
					{
						// Supprime le focus
						oChamp.blur();
						// Simule une prise de focus
						this.OnFocus(null, oChamp);
					}

					return true;
				});
			}

			// Supprime l'indication
			this.m_sIndication = String(oValeur);

			// Simule une perte de focus
			clWDUtil.bForEachThis(tabChamps, this, function(oChamp)
			{
				if (oChamp)
				{
					this.__PlaceIndication(oChamp, false);
				}

				return true;
			});
			return oValeur;
		case this.XML_CHAMP_PROP_NUM_BOUTONCALENDRIER:
			oBouton = oChamp.nextElementSibling;
			if (clWDUtil.bBaliseEstTag(oBouton, "div"))
			{
				clWDUtil.SetDisplay(oBouton, oValeur);
			}
			return oValeur;
		case this.XML_CHAMP_PROP_NUM_ETAT:
			// Modifie sur le champ calendrier si besoin
			oBouton = oChamp.nextElementSibling;
			if (clWDUtil.bBaliseEstTag(oBouton, "div"))
			{
				clWDAJAXMain._AppliqueAttributEtat(oXMLAction, oBouton.firstElementChild, oValeur, true);
			}
			return oValeur;
		default:
			return oValeur;
		}
	};

	// Notifie le champ calendrier de sa MAJ
	__WDSaisie.prototype.MAJContenuCalendrier = function MAJContenuCalendrier(oEvent, oChamp)
	{
		var sValeurChamp = this.GetValeur(oEvent, oChamp.value, oChamp);

		// Calcul de la valeur avec une conversion en valeur WL si besoin
		var sValeur;
		// GP 13/11/2018 : TB110491 : Si la valeur est le format d'affichage, on consid�re que le champ est vide.
		// Arrive si on donne le focus au champ quand le calendrier popup est ouvert.
		if ((sValeurChamp === this.m_sFormatAffichage) || ("" === sValeurChamp))
		{
			sValeur = "";
		}
		else
		{
			sValeur = clWDUtil.sChaineVersDate(oChamp.value, this.m_sFormatAffichage);
		}

		// Notifie le champ calendrier du changement de valeur
		this.m_oObjetChampCalendrier.OnChangeSaisie(oEvent, sValeur, oChamp);
	};

	// Fonction appelle quand le champ perd le focus et que la valeur a ete modifie
	// bDepuisOnChange : indique que l'on est appel� depuis le onchange du champ
	__WDSaisie.prototype.OnChange = function OnChange(oEvent, oChamp, bDepuisOnChange)
	{
		// Uniquement si on n'est pas en cours de modification par le champ calendrier
		if (!this.m_bChangeDepuisCalendrier)
		{
			if (!oChamp && oEvent)
			{
				oChamp = clWDUtil.oGetTarget(oEvent);
			}

			// GP 01/02/2013 : TB80494
			try
			{
				var bDepuisOnChangeOld = this.m_bDepuisOnChange;
				this.m_bDepuisOnChange = bDepuisOnChange;
				this.MAJContenuCalendrier(oEvent, oChamp);
			}
			finally
			{
				this.m_bDepuisOnChange = bDepuisOnChangeOld;
			}
		}
	};

	// Notification du champ que sa valeur a changer a cause du champ calendrier
	// oChampSaisie : champ de saisie precis concerne (cas des ZR)
	__WDSaisie.prototype.OnChangeCalendrier = function OnChangeCalendrier(oEvent, sValeur, oChampSaisie)
	{
		// Entre l'ouverture de la popup calendrier et la selection, si le champ de saisie a ete MAJ (dans une ZR), l'objet DOM a peut etee changer
		if (this.bGestionTableZR())
		{
			var tabElements = document.getElementsByName(oChampSaisie.name);
			if (1 === tabElements.length)
			{
				oChampSaisie = tabElements[0];
				// GP 14/04/2015 : QW257095 : Si on est dans un champ de saisie dans une table/zr navigateur => simule un evenement avec la bonne cible
				// GP 20/04/2015 : QW257410 : Sauf dans une table/ZR classique
//				// Si on a un champ table/zone r�p�t�e AJAX/navigateur on inclus forc�ment WDTableZRCommun.js qui d�clare WDTableZRNavigateur, donc WDTableZRNavigateur existe toujours si on arrive ici.
//				if (this.oGetTableZRParent() instanceof WDTableZRNavigateur)
				if (window["WDTableZRNavigateur"] && ((this.oGetTableZRParent()) instanceof WDTableZRNavigateur))
				{
					oEvent = oEvent ? clWDUtil.oCloneObjet(oEvent) : {};
					oEvent.target = oChampSaisie;
				}
			}
		}

		// Convertion de la valeur en valeur affichee
		sValeur = clWDUtil.sDateVersChaine(sValeur, this.m_sFormatAffichage);

		// Simule une affectation de la valeur par programmation
		sValeur = this.SetValeur(oEvent, sValeur, oChampSaisie);

		// Puis ecrit reellement la valeur
		oChampSaisie.value = sValeur;

		// GP 01/02/2013 : TB80494 (Le seul cas erron� est si le calendrier donne un nouvelle date diff�rentes)
		if (!this.m_bDepuisOnChange)
		{
			// Execute le PCode de changement
			// Le probleme est que ce code va rappeler le code de l'utilisateur qui se fini par un appel a this.OnChange()
			// Sauf que dans ce cas, il n'y a pas d'evenement et pas de champ courant et que l'on ne doit pas se notifier dans l'autre sens
			try
			{
				var bChangeDepuisCalendrier = this.m_bChangeDepuisCalendrier;
				this.m_bChangeDepuisCalendrier = true;
				oChampSaisie.onchange(oEvent);
			}
			finally
			{
				this.m_bChangeDepuisCalendrier = bChangeDepuisCalendrier;
			}
		}
	};


	if (bPlaceHolder)
	{
		// GP 10/12/2012 : Si le navigateur g�re le HTML5, on utilise l'attribut placeholder du HTML5

		// Lecture de la valeur du champ en programmation : supprime l'indication si elle est affichee
		__WDSaisie.prototype.GetValeur = function GetValeur(oEvent, sValeur/*, oChamp*/)
		{
			return sValeur;
		};

		// Ecriture de la valeur du champ en programmation : ajoute l'indication si besoin ou supprime le style de l'indication
		__WDSaisie.prototype.SetValeur = function SetValeur(oEvent, sValeur, oChamp)
		{
			// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
			WDChamp.prototype.SetValeur.apply(this, arguments);

			// GP 19/01/2018 : TB106916 : Si on est avec libelle en texte d'indication, il faut notifier que le champ se comporte de cette mani�re.
			if (window.$)
			{
				$(oChamp).trigger("trigger.wb.saisie.rwd.postaffectation")
			}

			// Dans tous les cas : retourne la vraie valeur
			return sValeur;
		};

		// Fonction appelle quand le champ recoit le focus : supprime l'indication si besoin
		__WDSaisie.prototype.OnFocus = clWDUtil.m_pfVide;
		// Fonction appelle quand le champ perd le focus : remet l'indication si besoin
		__WDSaisie.prototype.OnBlur = clWDUtil.m_pfVide;
		// Il y a maintenant une m�thode dans la classe de base, inutile de red�finir la m�thode
//		// Fonction appelle en submit de la page : supprime l'indication pour ne pas l'envoyer au serveur
//		__WDSaisie.prototype.OnSubmit = clWDUtil.m_pfVide;

		// Place r�ellement l'indication
		__WDSaisie.prototype.__PlaceIndication = function __PlaceIndication(oChamp/*, bAvecOnBlur*/)
		{
			oChamp.placeholder = this.m_sIndication;
		};
	}
	else
	{
		var sIndicationCouleur = "#808080";
		var sIndicationStyleF = "italic";

		// Lecture de la valeur du champ en programmation : supprime l'indication si elle est affichee
		__WDSaisie.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp)
		{
			return (("" !== this.m_sIndication) && oChamp.bIndication) ? "" : sValeur;
		};

		// Ecriture de la valeur du champ en programmation : ajoute l'indication si besoin ou supprime le style de l'indication
		__WDSaisie.prototype.SetValeur = function SetValeur(oEvent, sValeur, oChamp)
		{
			// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
			WDChamp.prototype.SetValeur.apply(this, arguments);

			if ("" !== this.m_sIndication)
			{
				// Si la valeur est vide => Affiche l'indication
				if (0 === sValeur.length)
				{
					// Si la valeur affichee n'est pas deja l'indication
					if (!oChamp.bIndication)
					{
						// Affiche l'indication : pas besoin de l'afficher : le code autour le fera pour nous => on met juste le style
						__SetStyle(oChamp);
					}
					// Dans tout les cas retourne l'indication car c'est la valeur finalement dans le champ
					return this.m_sIndication;
				}

				// La valeur est non vide : il faut supprimer l'indication si besoin
				if (oChamp.bIndication)
				{
					__ClearStyle(oChamp);
				}
			}

			// Non : cette fonctionnalit� n'est pas disponible en HTML4.
//			// GP 19/01/2018 : TB106916 : Si on est avec libelle en texte d'indication, il faut notifier que le champ se comporte de cette mani�re.
//			if (window.$)
//			{
//				$(oChamp).trigger("trigger.wb.saisie.rwd.postaffectation")
//			}

			// Dans tous les cas : retourne la vraie valeur
			return sValeur;
		};

		// Fonction appelle quand le champ recoit le focus : supprime l'indication si besoin
		__WDSaisie.prototype.OnFocus = function OnFocus(oEvent, oChamp)
		{
			if ("" !== this.m_sIndication)
			{
				if (oEvent && !oChamp)
				{
					oChamp = clWDUtil.oGetTarget(oEvent);
				}
				// Il faut supprimer l'indication si besoin
				if (oChamp.bIndication)
				{
					__ClearStyle(oChamp);
					oChamp.value = "";
					// GP 05/09/2012 : TB69411 : Je ne comprend pas pourquoi mais si le champ a un masque on a parfois un comportement bizarre
					// dans IE en arrivant dans le champ par TAB. Je force dans ce cas le focus.
					// Le focus est imm�diat : un DonneFocus sera dans un timeout donc il sera �x�cut� en apr�s et sera donc prioritaire.
					if (bIE && oChamp.createTextRange)
					{
						var oRange = oChamp.createTextRange();
						oRange.collapse(true);
						oRange.moveStart('character', 0);
						oRange.moveEnd('character', 0);
						oRange.select();
						oChamp.focus();
					}
				}
			}
		};
		// Fonction appelle quand le champ perd le focus : remet l'indication si besoin
		__WDSaisie.prototype.OnBlur = function OnBlur(oEvent, oChamp)
		{
			if ("" !== this.m_sIndication)
			{
				if (oEvent && !oChamp)
				{
					oChamp = clWDUtil.oGetTarget(oEvent);
				}
				this.__PlaceIndication(oChamp, false);
			}
		};
		// Fonction appelle en submit de la page : supprime l'indication pour ne pas l'envoyer au serveur
		__WDSaisie.prototype.OnSubmit = function OnSubmit(/*oEvent*/)
		{
			// Appel de la methode de la classe de base
			WDChamp.prototype.OnSubmit.apply(this, arguments);

			if ("" !== this.m_sIndication)
			{
				// Parcours de la collection
				clWDUtil.bForEachThis(this.__tabGetChamps(), this, function(oChamp)
				{
					// Il faut supprimer l'indication si besoin
					if (oChamp && oChamp.bIndication)
					{
						__ClearStyle(oChamp);
						oChamp.value = "";
					}

					return true;
				});
			}
		};

		// Place r�ellement l'indication
		__WDSaisie.prototype.__PlaceIndication = function __PlaceIndication(oChamp, bAvecOnBlur)
		{
			if (0 === oChamp.value.length)
			{
				// Supprime le focus
				if (bAvecOnBlur)
				{
					oChamp.blur();
				}

				// Dans firefox, l'appel de blur appel le code JS alors que ce n'est pas le cas dans IE
				if (0 === oChamp.value.length)
				{
					// Modifie le style
					__SetStyle(oChamp);
					// Place l'indication
					oChamp.value = this.m_sIndication;
				}
			}
		};
	}

	return __WDSaisie;
})();
