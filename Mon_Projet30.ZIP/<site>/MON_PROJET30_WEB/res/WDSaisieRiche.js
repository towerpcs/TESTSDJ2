// WDSaisieRiche.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// Définition des globales définies dans :
// - La page
///#GLOBALS _WD_
// - WDUtil.js
///#GLOBALS bIE bIEQuirks bIEAvec11 bIE11Plus bEdge bFF bCrm AppelMethode
// - WDChamp.js
///#GLOBALS WDChamp
// - WDBarreOutils.js
///#GLOBALS WDBarreBouton WDBarreBoutonOnOff WDBarreBoutonPopup WDBarre
// - WWConstanteX.js
///#GLOBALS HTML_TOOLBAR
// - Autres
///#GLOBALS Option $ WDSaisieAPI

// Le champ contient plusieurs elements :
// Role									ID			Membre
// - Un INPUT type="hidden"				ALIAS		m_oValeur
// - Un DIV/TD/Autres hote racine		ALIAS_HTE	m_oHote
//	- (IE)Un DIV editable				ALIAS_EDT	m_oData		Construit dynamiquement
//	- (FF/Autres)IFrame					ALIAS_EDT				Construit dynamiquement
//		- BODY editable								m_oData		Construit dynamiquement

// Manipulation d'un champ de saisie HTML
var WDSaisieRiche = (function ()
{
	"use strict";

	// Compare deux ranges
	var __bCompareRange = bIE ? function (oRange1, oRange2)
		{
			return oRange1.isEqual(oRange2);
		} : function (oRange1, oRange2)
		{
			return (oRange1.compareBoundaryPoints(0, oRange2) == 0) && (oRange1.compareBoundaryPoints(2, oRange2) == 0);
		};


	function __SelectionneCouleurDansNuancierDepuisCouleurHTML(sCouleurHTML,oObjet)
	{
		var tabRVB = clWDUtil.tabHTML2RVBA(sCouleurHTML);
		var sCouleurRvbHTML = clWDUtil.sRVB2HTML(tabRVB).substr(1).toLowerCase();//minuscule sans # en préfixe
		var domCouleursPickers = oObjet.querySelector(".wbColorPickerChoice" + sCouleurRvbHTML);
		if (!domCouleursPickers)
		{
			domCouleursPickers = oObjet.querySelector(".wbColorPickerChoice" + sCouleurRvbHTML.toUpperCase());
		}
		if (domCouleursPickers)
		{
			__SelectionneCouleurDansNuancierDepuisDom(domCouleursPickers,oObjet);
		}
	}
	function __SelectionneCouleurDansNuancierDepuisDom(domCouleurNuancier,oObjet)
	{
		var domSel = oObjet.querySelector(".wbColorPickerChoiceChecked");
		if (domSel)
		{
			domSel.classList.remove("wbColorPickerChoiceChecked");
		}
		//flag comem étant la couleur active
		domCouleurNuancier.classList.add("wbColorPickerChoiceChecked");
	}

	var WDBarreBoutonRiche = (function ()
	{
		//Bouton lien et image
		function __WDBarreBoutonRiche(oObjetParent, oBouton, sCommande, oParamCommande)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDBarreBouton.prototype.constructor.apply(this, [oObjetParent, oBouton, sCommande, oParamCommande]);
			}
		}

		// Declare l'heritage
		__WDBarreBoutonRiche.prototype = new WDBarreBouton();
		// Surcharge le constructeur qui a ete efface
		__WDBarreBoutonRiche.prototype.constructor = __WDBarreBoutonRiche;

		return __WDBarreBoutonRiche;
	})();

	var WDBarreBoutonOnOffRiche = (function ()
	{
		// Manipulation d'un bouton On/Off du champ de saisie
		function __WDBarreBoutonOnOffRiche(oObjetParent, oBouton, sCommande, sStyle, tabStyleValeur)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDBarreBoutonOnOff.prototype.constructor.apply(this, [oObjetParent, oBouton, "ExecuteCommande", [sCommande, false, null]]);

				// Sauve les parametres specifiques
				this.m_sStyle = sStyle;
				// Valeurs que l'on recherche ou que l'on evite dans le style
				// Chaque valeur est un couple : valeur (sVal, bTst)
				// Si le booleen est a vrai on recherche style == this.m_sStyleValeur, a faux on recherche !=
				this.m_tabStyleValeur = tabStyleValeur;
			}
		}

		// Declare l'heritage
		__WDBarreBoutonOnOffRiche.prototype = new WDBarreBoutonOnOff();
		// Surcharge le constructeur qui a ete efface
		__WDBarreBoutonOnOffRiche.prototype.constructor = __WDBarreBoutonOnOffRiche;

		// Dessine un etat
		__WDBarreBoutonOnOffRiche.prototype.__DessineEtat = function __DessineEtat(eEtat, oObjetEtat, oObjetStyle/*, oDataEtat*/)
		{
			WDBarreBouton.prototype.__DessineEtat.apply(this,arguments);
			//et applique létat sur la planche
			if (this.m_oObjetParent.bRelookUL())
			{
				if (eEtat == this.ms_eEtatActif)
				{
					oObjetStyle.classList.add("wbActif");//li
					oObjetStyle.firstElementChild.classList.add("wbActif");//i
					oObjetStyle.firstElementChild.firstElementChild.classList.add("wbActif");//img
				}
				else
				{
					oObjetStyle.classList.remove("wbActif");//li
					oObjetStyle.firstElementChild.classList.remove("wbActif");//i
					oObjetStyle.firstElementChild.firstElementChild.classList.remove("wbActif");//img
				}
			}
		};

		// Execute la commande : methode definie dans les classes derivees
		__WDBarreBoutonOnOffRiche.prototype.ExecuteCommande = function (oEvent)
		{
			// Sauve le range courant
			var oDataEtat = this.m_oObjetParent.oGetParamEtat(oEvent, false);
			// Il ne faut pas forcer sur les commandes a effet immediat
			if (oDataEtat[0] && (this.m_sStyle != "textAlign"))
			{

				// Efface un ancien etat
				if (this.m_oRange)
				{
					delete this.m_oRange;
					delete this.m_bForceActif;
				}

				// Inverse l'etat
				if (this.m_sStyle)
				{
					switch (this._veGetEtatSpecifique(oEvent, this.ms_eEtatNormal, oDataEtat))
					{
					case this.ms_eEtatNormal:
						this.m_bForceActif = true;
						break;
					case this.ms_eEtatActif:
						this.m_bForceActif = false;
						break;
					}
				}

				this.m_oRange = oDataEtat[0];
			}

			// Execute la commande
			WDBarreBoutonOnOff.prototype.ExecuteCommande.apply(this, arguments);
		};

		// Si on doit manipuler l'etat surcharge

		// Applique ensuite l'etat d'activation
		__WDBarreBoutonOnOffRiche.prototype.bActif = function (oEvent, oDataEtat)
		{
			// Si on a un range memorise et que la selection est identique : retourne la valeur
			if (this.m_oRange)
			{
				try
				{
					if (__bCompareRange(this.m_oRange, oDataEtat[0]))
					{
						return this.m_bForceActif;
					}
				}
				catch (e)
				{
				}
				// La selection a change
				delete this.m_oRange;
				delete this.m_bForceActif;
			}

			if (this.m_sStyle && oDataEtat[2] && this.m_sStyle.length)
			{
				switch (this.m_oParamCommande[0])
				{
				case "italic":
					// Le style italique utilise la balise EM qui ne change pas le style
					// => Cas particulier
					if (this.__bStyleMatchRecursif(oDataEtat[1], "em"))
					{
						return true;
					}
					break;
				case "underline":
					// Le souligne et le barre se partage le meme style et cascadent mais sans que cela se voit dans le style
					// Teste le style local et le style des parents
					if (this.__bStyleMatchRecursif(oDataEtat[1], "u"))
					{
						return true;
					}
					break;
				case "strikeThrough":
					if (this.__bStyleMatchRecursif(oDataEtat[1], "strike"))
					{
						return true;
					}
					break;
				case "bold":
					// Pour chrome qui retourne "normal" au lieu de "400" : cas particulier
					if (oDataEtat[2][this.m_sStyle] == "normal")
					{
						return false;
					}
				// Pas de break
				default:
					if (this.__bStyleMatch(oDataEtat[2][this.m_sStyle]))
					{
						return true;
					}
					break;
				}
			}
			// L'etat n'est pas actif
			return false;
		};

		// Verifie si l'element matche le style en pronfondeur
		__WDBarreBoutonOnOffRiche.prototype.__bStyleMatchRecursif = function (oElement, sBalise)
		{
			// Teste le style local et le style des parents
			while (oElement && (oElement != this.m_oObjetParent.m_oData))
			{
				// Si le style match ou que l'on a une balise specifique
				if ((this.__bStyleMatch(clWDUtil.oGetCurrentStyle(oElement)[this.m_sStyle])) || (oElement.tagName && clWDUtil.bBaliseEstTag(oElement, sBalise)))
				{
					return true;
				}
				oElement = oElement.parentNode;
			}
			return false;
		};

		// Verifie si l'element matche le style
		__WDBarreBoutonOnOffRiche.prototype.__bStyleMatch = function (sValeur)
		{
			var i;
			var nLimiteI = this.m_tabStyleValeur.length;
			for (i = 0; i < nLimiteI; i++)
			{
				var oTest = this.m_tabStyleValeur[i];
				// Comme this.m_tabStyleValeur est une reference sur un tableau inline, on semble lister aussi la propriete .length que l'on ne veux pas
				if (oTest)
				{
					if (oTest.bTst)
					{
						if (sValeur.indexOf(oTest.sVal)!=-1)//cas de line-through alors qu'on lit "underline line-through solid rgb(95, 100, 105)"
						{
							return true;
						}
					}
					else
					{
						if (sValeur != oTest.sVal)
						{
							return true;
						}
					}
				}
			}
			return false;
		};

		return __WDBarreBoutonOnOffRiche;
	})();

	// Manipulation d'un bouton dropdown du champ de saisie
	var WDBarreBoutonPopupRiche = (function ()
	{
		function __WDBarreBoutonPopupRiche(oObjetParent, oBouton, sCommande, oPopup, sSuffixe, sStyle)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				WDBarreBoutonPopup.prototype.constructor.apply(this, [oObjetParent, oBouton, "ExecuteCommande", [sCommande, false, null], oPopup]);

				this.m_sStyle = sStyle;

				//clic dans le document ou ESC ferme
				var oThis = this;
				document.body.addEventListener("click",this.m_oBouton.onmouseout);
				document.body.addEventListener("keydown",function(oEvent){ if (oEvent.keyCode == 27) { oThis.m_oBouton.onmouseout.apply(this,arguments); oThis.m_oObjetParent.SetFocus(); } });
				//masque au focus dans l'iframe
				window.addEventListener("blur",this.m_oBouton.onmouseout);

				// Traduit les textes dans la popup
				var tabLibelle = HTML_TOOLBAR[sSuffixe];
				if (tabLibelle)
				{
					var tabSpan = oPopup.getElementsByTagName("span");
					if (this.m_oObjetParent.bRelookUL())
					{
						//reset en 1er
						tabLibelle = [HTML_TOOLBAR.COSP[0]].concat(Object.keys(tabLibelle).map(function(key) {
							return tabLibelle[key];
						}));
					}
					var i = 0;
					var nLimiteI = tabSpan.length;
					for (i = 0; i < nLimiteI; i++)
					{
						var oSpan = tabSpan[i];
						clWDUtil.SupprimeFils(tabSpan[i]);
						if (tabLibelle[i] !== undefined)
						{
							tabSpan[i].appendChild(document.createTextNode(tabLibelle[i]));
						}
					}
				}
			}
		}

		// Declare l'heritage
		__WDBarreBoutonPopupRiche.prototype = new WDBarreBoutonPopup();
		// Surcharge le constructeur qui a ete efface
		__WDBarreBoutonPopupRiche.prototype.constructor = __WDBarreBoutonPopupRiche;


		// Declare les fonction une par une

		// Clic sur une couleur : "vraie" commande
		__WDBarreBoutonPopupRiche.prototype.OnClickP = function (oEvent)
		{
			var oSource = clWDUtil.oGetTarget(oEvent);
			// Filtre les clics autour des couleurs
			if (clWDUtil.bBaliseEstTag(oSource, "div"))
			{
				// Trouve la couleur
				this.m_oParamCommande[2] =
					(this.m_oObjetParent.bRelookUL() && this.m_sStyle=="backgroundColor")//accepte l'alpha
					? clWDUtil.sRVBA2HTML(clWDUtil.tabHTML2RVBA(clWDUtil.oGetCurrentStyle(oSource).backgroundColor))
					: __sConversionCouleur(clWDUtil.oGetCurrentStyle(oSource).backgroundColor)
				;

				//notifie du choix
				//NON car le clic sur l'option fait un blur du body de la saisie riche et donc désélectionne l'image et ses trackers
				//if (this.m_oObjetParent.bRelookUL() && this.m_oObjetParent.m_oData.wbSaisieRicheSetStyle)this.m_oObjetParent.m_oData.wbSaisieRicheSetStyle(this);

				// Execute la commande de la classe de base deux niveau au dessus
				WDBarreBouton.prototype.ExecuteCommande.apply(this, [oEvent]);

				//flag comme étant la couleur active
				__SelectionneCouleurDansNuancierDepuisDom(oSource,this.m_oBouton);
			}

			// Ferme la popup
			WDBarreBoutonPopup.prototype.OnClickP.apply(this, arguments);
		};

		__WDBarreBoutonPopupRiche.prototype.OnMouseOut = function(oEvent)
		{
			// Detecte si la souris quitte vraiment l'objet
			var oDestination = (oEvent.type != "mouseout") ? clWDUtil.oGetTarget(oEvent) : (bIE ? oEvent.toElement : oEvent.relatedTarget);
			if (oDestination!=window && clWDUtil.bEstFils(oDestination, this.m_oBouton))
			{
				// L'element qui recoit la souris est encore dans le bouton : ne masque pas la popup
				return;
			}

			// Masque la popup au clic en dehors
			if (oEvent.type != "mouseout")
			{
				this.__SetDisplayPopup(false);
			}

			// Rappel de la methode de la classe de base
			WDBarreBouton.prototype.OnMouseOut.apply(this, arguments);
		};

		function __sConversionCouleur(sCouleur)
		{
			// GP 17/09/2012 : TB79056 : Sur la couleur du texte, Firefox génère un <font color="">.
			// Or cette syntaxe ne semble pas accepter les couleurs "rgb(xxx, xxx, xxx)"
			// GP 04/03/2016 : TB96928 : Appel de sRVB2HTML à la place de sRVBA2HTML pour rétablir la correction de TB79056
			return clWDUtil.sRVB2HTML(clWDUtil.tabHTML2RVBA(sCouleur));
		}

		// Calcule l'etat specifique du bouton : inchange
		__WDBarreBoutonPopupRiche.prototype._veGetEtatSpecifique = function _veGetEtatSpecifique(oEvent, eEtat, oDataEtat)
		{
			if (this.m_sStyle && oDataEtat[2] && oDataEtat[2][this.m_sStyle])
			{
				__SelectionneCouleurDansNuancierDepuisCouleurHTML(oDataEtat[2][this.m_sStyle],this.m_oBouton);
			}

			return eEtat;
		};

		// Dessine un etat
		__WDBarreBoutonPopupRiche.prototype.__DessineEtat = function __DessineEtat(eEtat, oObjetEtat, oObjetStyle, oDataEtat)
		{
			// Puis dessine l'etat
			if (eEtat != oObjetEtat.m_eEtat)
			{
				if (eEtat != this.ms_eEtatNormal)
				{
					oObjetEtat.m_eEtat = eEtat;
				}
				else
				{
					delete oObjetEtat.m_eEtat;
				}
				oObjetStyle.style.backgroundColor = this.m_oObjetParent.sGetCouleurFond(eEtat);
				//permet d'avoir la couleur active visible sous le picto
				if (oDataEtat[2] && this.m_oObjetParent.bRelookUL())
				{
					oObjetStyle.style.color = oDataEtat[2][this.m_sStyle];
				}
			}
		};

		return __WDBarreBoutonPopupRiche;
	})();

	// Manipulation d'une combo du champ de saisie
	var WDSaisieRicheCbm = (function ()
	{
		function __WDSaisieRicheCbm(oObjetParent, oCombo, sCommande, sStyle, tabValeurs, sSuffixe)
		{
			if (!arguments.length)
			{
				return;
			}

			this.m_oObjetParent = oObjetParent;
			this.m_oCombo = oCombo;
			this.m_sCommande = sCommande;
			this.m_sStyle = sStyle;

			// Pour la validation W3C, il faut au moins une option dans les combos :
			// La generation ajoute une option dans la combo, et je la supprime ici
			if (this.m_oCombo.options && this.m_oCombo.options.length)
			{
				this.m_oCombo.options.length = 0;
			}

			// Recherche le tableau des traductions
			var tabLibelle = HTML_TOOLBAR[sSuffixe];

			// Remplit la combo
			var i;
			var nLimiteI = tabValeurs.length;
			for (i = 0; i < nLimiteI; i++)
			{
				var clValeur = tabValeurs[i];
				// Comme tabValeurs est une reference sur un tableau inline, on semble lister aussi la propriete .length que l'on ne veux pas
				if (clWDUtil.isArray(clValeur))
				{
					var sLibelle = i;
					if (tabLibelle && tabLibelle[i])
					{
						sLibelle = tabLibelle[i];
					}
					this.ajouteOption(sLibelle, clValeur);
				}
				else if (clValeur)
				{
					//filtre certaines valeurs pour le relook
					if (this.m_oObjetParent.bRelookUL() && clValeur.bMasquerEnRelookUL)
					{
						continue;
					}

					// Construit le libelle
					var sLibelle = clValeur.sN;
					if (tabLibelle && tabLibelle[i])
					{
						if (this.m_oObjetParent.bRelookUL())
						{
							sLibelle = tabLibelle[i];
						}
						else
						{
							var sTraduction = tabLibelle[i];
							var sSuffixeTrad = " (" + sLibelle + ")";

							//hack de compat
							if (sSuffixe == "FHE")
							{
								if (i==0)
								{
									//historique corps de texte s'appelait normal
									sTraduction = HTML_TOOLBAR["FSI"][1];
								}
							}
							else if (sSuffixe == "FSI")
							{
								//historiquement on n'affichait que les valeurs et pas les libellés des tailles
								sTraduction = "";
								sSuffixeTrad = parseInt(sLibelle);
							}

							sLibelle = sTraduction + sSuffixeTrad;
						}
					}
					this.ajouteOption(sLibelle, clValeur.sV);
				}
			}

			// Hook les methodes des boutons
			// Uniquement si le parent n'est pas dans une ZR
			// Si le parent est dans une ZR, le hook est fait au deplacement de la barre
			if (oObjetParent.bRelookUL() || !oObjetParent.bGestionTableZR())
			{
				this.vPostPlaceBarre();
			}
		}

		// Hook les boutons
		// Le fait de deplacer la barre fait perdre le hook sur onchange des combos
		__WDSaisieRicheCbm.prototype.vPrePlaceBarre = function vPrePlaceBarre()
		{
			this.m_oCombo.onchange = null;
		};

		// Le fait de deplacer la barre fait perdre le hook sur onchange des combos
		__WDSaisieRicheCbm.prototype.vPostPlaceBarre = function vPostPlaceBarre()
		{
			var oThis = this;
			this.m_oCombo.onchange = function (oEvent) { oThis.OnChange(oEvent || event); }
		};

		__WDSaisieRicheCbm.prototype.OnChange = function OnChange(oEvent)
		{
			// Memorise le range courant
			var oRange = this.m_oObjetParent.oGetRange();
			if (oRange)
			{
				this.m_oRange = oRange;
			}

			// Execute la commande (rafraichit le bouton en interne)
			this.m_oObjetParent.ExecuteCommande(oEvent, [this.m_sCommande, false, this.m_oCombo.options[this.m_oCombo.selectedIndex].value]);
		};

		// Rafraichit le bouton
		__WDSaisieRicheCbm.prototype.RafEtatSimple = function RafEtatSimple(oEvent)
		{
			this.RafEtat(oEvent, this.m_oObjetParent.oGetParamEtat(oEvent, false));
		};

		__WDSaisieRicheCbm.prototype.RafEtat = function RafEtat(oEvent, oDataEtat)
		{
			// Si on a un range memorise et que la selection est identique : retourne la valeur
			if (this.m_oRange)
			{
				try
				{
					if (__bCompareRange(this.m_oRange, oDataEtat[0]))
					{
						// Ne fait rien (ne change pas l'etat)
						return;
					}
				}
				catch (e)
				{
				}
				// La selection a change
				delete this.m_oRange;
			}

			// Si on n'a pas de style
			if (!oDataEtat[2])
			{
				return;
			}

			// On pretraite la valeur du style pour eviter les valeurs transforme de firefox
			var sValeurStyleCal = oDataEtat[2][this.m_sStyle];



			// Cas de la taille de la police
			switch (this.m_sCommande)
			{
			case "FontSize":
				this.__RafEtat_Taille(oEvent, sValeurStyleCal);
				break;
			case "FontName":

				//sans les doubles quotes
				if (sValeurStyleCal && sValeurStyleCal[0]=='"' && sValeurStyleCal[sValeurStyleCal.length-1]=='"')
				{
					sValeurStyleCal = sValeurStyleCal.substr(1,sValeurStyleCal.length-2);
				}
				//et plutôt des simples quotes
				sValeurStyleCal = sValeurStyleCal.replace(/"/g,"'");
				this.__RafEtat_Police(oEvent, sValeurStyleCal);
				break;
			case "FormatBlock":
				this.__RafEtat_Format(oEvent, oDataEtat[1]);
				break;
			default:
				break;
			}
		};

		// Traite la selection de la taille de la police
		__WDSaisieRicheCbm.prototype.__RafEtat_Taille = function __RafEtat_Taille(oEvent, sValeurStyleCal)
		{
			// Supprime les '
			sValeurStyleCal = sValeurStyleCal.replace(/'/g, "");
//			var sValeurStyleCalOri = sValeurStyleCal;

			// toutes les tailles ne sont pas proposées en relook
			var fTailleDispo = !this.m_oObjetParent.bRelookUL() ? function() { return true;} : function(nTaille)
			{
				return !this.m_oObjetParent.m_tabDescBarre.filter( function(e) {return e.sSuf == "FSI";} )[0].tabP.filter( function(e) { return e.sN == nTaille;} )[0].bMasquerEnRelookUL;
			}.bind(this);

			var fTaillePlusProcheDispo = function(nTailleSimple,dTailleReelle,nTaillePixel,nTaillePixelSuivante)
			{
				if (!fTailleDispo(nTailleSimple))
				{
					return false;
				}

				if (dTailleReelle < nTaillePixel)
				{
					return true;
				}
				if (dTailleReelle < nTaillePixelSuivante)
				{
					if (!fTailleDispo(nTailleSimple+1))
					{
						return true;
					}

					if (nTaillePixelSuivante-dTailleReelle > dTailleReelle-nTaillePixel)
					{
						return true;
					}
				}
				return false;
			};

			// Cas de la taille transformee en px
			if (sValeurStyleCal.charAt(sValeurStyleCal.length - 2) == "p")
			{
				var dTaille = parseFloat(sValeurStyleCal);
				if (sValeurStyleCal.charAt(sValeurStyleCal.length - 1) == "t")
				{
					dTaille *= 96.0 / 72.0;
				}
				if (fTaillePlusProcheDispo(1,dTaille, 11.5,	14.5))
				{
					sValeurStyleCal = "1";
				}
				else if (fTaillePlusProcheDispo(2,dTaille, 14.5,17))
				{
					sValeurStyleCal = "2";
				}
				else if (fTaillePlusProcheDispo(3,dTaille, 17,21))
				{
					sValeurStyleCal = "3";
				}
				else if (fTaillePlusProcheDispo(4,dTaille, 21,28))
				{
					sValeurStyleCal = "4";
				}
				else if (fTaillePlusProcheDispo(5,dTaille, 28,40))
				{
					sValeurStyleCal = "5";
				}
				else if (fTaillePlusProcheDispo(6,dTaille, 40,48))
				{
					sValeurStyleCal = "6";
				}
				else if (fTailleDispo(7))						// 48 => 7
				{
					sValeurStyleCal = "7";
				}
			}

			// Selectionne l'element dans la combo
			var nOption;
			var tabOptions = this.__tabRechercheValeurCombo(sValeurStyleCal, function (sValeur, sOptionValue) { return (sValeur.toUpperCase() == sOptionValue.toUpperCase()); });
			if (tabOptions.length > 0)
			{
				nOption = tabOptions[0];
			}
			// Ajouter l'option est perturbant à l'usage et la commande ne fonctionne pas avec des taille en "Valeur<Unité px>"
			// else
			// {
			// 	tabOptions = this.__tabRechercheValeurCombo(sValeurStyleCalOri, function (sValeur, sOptionValue) { return (sValeur.toUpperCase() == sOptionValue.toUpperCase()); });
			// 	if (tabOptions.length > 0)
			// 	{
			// 		nOption = tabOptions[0];
			// 	}
			// 	// Element non trouve dans la combo : l'ajoute a la combo
			// 	else 
			// 	{
			// 		nOption = this.ajouteOption(sValeurStyleCalOri, sValeurStyleCalOri);
			// 	}
			// }
			this.__Selection(nOption);
		};

		// Transforme une liste de police en tableau
		function __tabSplitPolices(sValeur)
		{
			// Commence par separer les differentes valeurs
			var tabPolices = sValeur.split(",");
			// Puis supprime les apostrophes et espaces au debut
			var i;
			var nLimiteI = tabPolices.length;
			for (i = 0; i < nLimiteI; i++)
			{
				var nTaille = tabPolices[i].length;
				while ((nTaille > 0) && ((tabPolices[i].charAt(0) == "'") || (tabPolices[i].charAt(0) == " ")))
				{
					tabPolices[i] = tabPolices[i].substring(1);
					nTaille--;
				}
				while ((nTaille > 0) && ((tabPolices[i].charAt(nTaille - 1) == "'") || (tabPolices[i].charAt(nTaille - 1) == " ")))
				{
					tabPolices[i] = tabPolices[i].substring(0, nTaille - 1);
					nTaille--;
				}
			}
			return tabPolices;
		}
		// Traite la selection du style de la police
		__WDSaisieRicheCbm.prototype.__RafEtat_Police = function __RafEtat_Police(oEvent, sValeurStyleCal)
		{
			// Commence par separer les differentes valeurs
			var tabPolices = __tabSplitPolices(sValeurStyleCal);
			var sSubStitutionReconstruite = tabPolices.join(",");

			// Recherche la police dans la combo avec le texte
			var fTest = function (sValeur, sOptionValue)
			{
				// Transforme la valeur en tableau
				return (sValeur.toUpperCase() == __tabSplitPolices(sOptionValue)[0].toUpperCase());
			};

			var nOption;
			var tabOptions = this.__tabRechercheValeurCombo(tabPolices[0], fTest);
			if (tabOptions.length > 0)
			{
				// Test si on a une valeur identique
				var i;
				var nLimiteI = tabOptions.length;
				for (i = 0; i < nLimiteI; i++)
				{
					if (sSubStitutionReconstruite.toUpperCase().indexOf(__tabSplitPolices(this.getOptionValue(tabOptions[i])).join(",").toUpperCase()) == 0)
					{
						// Trouvee
						nOption = tabOptions[i];
						break;
					}
				}
				if (nOption === undefined)
				{
					// On n'a pas d'option complete : ajoute un doublon
					nOption = this.ajouteOption(tabPolices[0] + "(" + sSubStitutionReconstruite + ")", sSubStitutionReconstruite);
				}
			}
			else
			{
				// On n'a pas l'option et pas de doublon : ajoute simplement
				nOption = this.ajouteOption(tabPolices[0], sSubStitutionReconstruite);
			}
			this.__Selection(nOption);
		};
		// Traite la selection formatage logique
		__WDSaisieRicheCbm.prototype.__RafEtat_Format = function __RafEtat_Format(oEvent, oElement)
		{
			// Si on est dans le click sur la combo : ne fait pas MAJ (IE)
			if (bIE && oEvent && clWDUtil.bBaliseEstTag(oEvent.srcElement, "select"))
			{
				return;
			}

			// Selectionne le premier element par defaut (format par defaut)
			var nOption = 0;

			// Remonte les parents pour rechercher un conteneur correct
			var oBody = this.m_oObjetParent.m_oData;
			while (oElement && (oElement != oBody))
			{
				var sTag = "&lt;" + clWDUtil.sGetTagName(oElement) + "&gt;";
				var tabOptions = this.__tabRechercheValeurCombo(sTag, function (sValeur, sOptionValue) { return (sValeur == sOptionValue); });
				if (0 < tabOptions.length)
				{
					nOption = tabOptions[0];
					break;
				}

				oElement = oElement.parentNode;
			}

			this.__Selection(nOption);
		};

		__WDSaisieRicheCbm.prototype.__tabRechercheValeurCombo = function __tabRechercheValeurCombo(sValeur, fbFonction)
		{
			var tabOptions = [];
			var i;
			var nLimiteI = this.m_oCombo.childElementCount;
			for (i = 0; i < nLimiteI; i++)
			{
				if (fbFonction(sValeur, this.getOptionValue(i)))
				{
					// Trouve
					tabOptions.push(i);
				}
			}
			return tabOptions;
		};

		// Selectionne un element dans la combo
		__WDSaisieRicheCbm.prototype.__Selection = function __Selection(nOption)
		{
			if (this.m_oCombo.selectedIndex != nOption)
			{
				this.m_oCombo.selectedIndex = nOption;
			}
		};

		__WDSaisieRicheCbm.prototype.getOptionValue = function getOptionValue(nOption)
		{
			return this.m_oCombo.options[nOption].value;
		};
		__WDSaisieRicheCbm.prototype.ajouteOption = function ajouteOption(sLibelle, sValeur)
		{
			this.m_oCombo.options[this.m_oCombo.childElementCount] = new Option(sLibelle, sValeur);
			return this.m_oCombo.childElementCount-1;
		};

		return __WDSaisieRicheCbm;
	})();

	// Manipulation d'une combo du champ de saisie
	var WDSaisieRicheCbmUL = (function ()
	{
		function WDSaisieRicheCbmUL(oObjetParent, oCombo, sCommande, sStyle, tabValeurs, sSuffixe)
		{
			this.m_domInputCombo = oCombo.previousElementSibling.previousElementSibling;
			this.m_domLabelReplie = oCombo.previousElementSibling;
			this.m_sSuffixe = sSuffixe;

			WDSaisieRicheCbm.prototype.constructor.apply(this,arguments);

			//recherche l'indice par défaut à sélectionner
			var nIndiceSelectionDefaut = 0;
			var i;
			var nLimiteI = oObjetParent.m_tabDescBarre.length;
			for (i = 0; i < nLimiteI; i++)
			{
				var oDesc = oObjetParent.m_tabDescBarre[i];
				// Comme this.m_tabDescBouton est un tableau inline, on semble lister aussi la propriete .length que l'on ne veux pas
				if (oDesc)
				{
					if (oDesc.sCom == sCommande)
					{
						nIndiceSelectionDefaut = oDesc.nIndiceSelectionDefaut || 0;
						break;
					}
				}
			}

			this.__Selection(nIndiceSelectionDefaut);
		}

		// Declare l'heritage
		WDSaisieRicheCbmUL.prototype = new WDSaisieRicheCbm();
		// Surcharge le constructeur qui a ete efface
		WDSaisieRicheCbmUL.prototype.constructor = WDSaisieRicheCbmUL;

		//convertion de la valeur <fotn size> vers css font-size:px
		WDSaisieRicheCbmUL.prototype.nGetFontSizeCssPxFromFontSizeHtml = function nGetFontSizeCssPxFromFontSizeHtml(nSizeHTML)
		{
			switch(+nSizeHTML)
			{
				case 1: return 10 ;
				case 2: return 13;
				case 3: return 16 ;
				case 4: return 18 ;
				case 5: return 24;
				case 6: return 32;
				case 7: return 48;
				default:
					return +nSizeHTML;
			}
		};

		//font size en REM pour les pages RWD
		WDSaisieRicheCbmUL.prototype.ajouteOption = function ajouteOption(sLibelle, sValeur)
		{			
			if (this.m_sCommande == "wbEmoji" && clWDUtil.isArray(sValeur))
			{
				//optim pas de remplissage si invisible 
				if (this.m_oObjetParent.m_tabBoutonsInfo[this.m_sSuffixe] && !this.m_oObjetParent.m_tabBoutonsInfo[this.m_sSuffixe].bVisible)
				{
					return;
				}
				var oThis = this;
				this.m_oCombo.classList.add("wbBarreOutilsComboListeDroite");
				this.m_oCombo.innerHTML += sValeur.map(function(tabSousVal)
				{
					//0 code html de l'émoji
					//1 : nom us
					//2 à N : mots clés
					return '<li class="wbBarreOutilsComboListeOption">'
					+ '<label for="'+ oThis.m_domInputCombo.id/*id de l'input*/ +'" class="wbBarreOutilComboLabel">'
					+ '<span class="wbSaisirRicheOptionValueInnerHTML"'
					+ " title=\""+clWDUtil.sEncodeInnerHTML(tabSousVal[1],true)+"\">" + tabSousVal[0] + '</span></label></li>'
					;
				}).join("");
			}
			else
			{
				//this.m_oCombo.options[nOption] = new Option(sLibelle, sValeur);
				var sBalise = this.m_sCommande=="FormatBlock" ? sValeur.substr("&lt;".length,sValeur.length-("&lt;".length+"&gt;".length)) : "span";

				var sOptionHTML = '<li class="wbBarreOutilsComboListeOption">'
				+ '<label for="'+ this.m_domInputCombo.id/*id de l'input*/ +'" class="wbBarreOutilComboLabel">'
				+ '<' + sBalise;

				switch (this.m_sCommande)
				{
				case "FontSize":
					var sTailleCSS;
					if (typeof sValeur === "string" )
					{
						var nTaillePX;
						//cas unité font size "2"
						if (!isNaN(+sValeur))
						{
							nTaillePX = this.nGetFontSizeCssPxFromFontSizeHtml(+sValeur);
						}
						//cas "12px"
						else if (sValeur.indexOf("px")>-1)
						{
							nTaillePX = parseFloat(sValeur);
						}
						//"15vw"
						else
						{
							sTailleCSS=sValeur;
						}
						//proportionnelau zoom des polices RWD
						if (nTaillePX)
						{
							sTailleCSS = clWDUtil.bRWD ? ((nTaillePX/16)+"rem") : (nTaillePX+"px");
						}
					}
					sOptionHTML += " style=\"font-family:Helvetica,Arial,sans-serif;font-size:" + sTailleCSS + ";\"";
					break;
				case "FontName":
					sOptionHTML += " style=\"font-family:'" + sValeur.split(',').join("','") + "';\"";
					break;
				case "FormatBlock":
					//balise <h1> déjà placée, laisse le font size hérité
					sOptionHTML += " style=\"font-family:Helvetica,Arial,sans-serif;\"";
					break;
				default:
					break;
				}

				this.m_oCombo.innerHTML += sOptionHTML + " title=\""+clWDUtil.sEncodeInnerHTML(sValeur,true)+"\">" + sLibelle + '</'+sBalise+'></label></li>';
			}
			return this.m_oCombo.childElementCount-1;
		};

		WDSaisieRicheCbmUL.prototype.getOptionValue = function getOptionValue(nOption)
		{
			var domLi = clWDUtil.isObject(nOption) ? nOption : this.m_oCombo.children[nOption];
			//li > label > span title
			return domLi.firstElementChild.firstElementChild.classList.contains("wbSaisirRicheOptionValueInnerHTML")
				? domLi.firstElementChild.firstElementChild.innerHTML
				: (domLi.firstElementChild.firstElementChild.title||document.getElementById( domLi.firstElementChild.firstElementChild.getAttribute("aria-describedby") ).innerText)//cas de jqueryui tooltip
			;
		};
		// Hook les boutons
		// Le fait de deplacer la barre fait perdre le hook sur onchange des combos
		WDSaisieRicheCbmUL.prototype.vPrePlaceBarre = function vPrePlaceBarre()
		{
			this.m_oCombo.onmousedown = null;
		};

		// Le fait de deplacer la barre fait perdre le hook sur onchange des combos
		WDSaisieRicheCbmUL.prototype.vPostPlaceBarre = function vPostPlaceBarre()
		{
			var oThis = this;
			this.m_oCombo.onmousedown = function(oEvent)
			{
				//clic sur un label de combo ul
				oThis.OnChange(oEvent || event);
			};
		};

		WDSaisieRicheCbmUL.prototype.OnChange = function OnChange(oEvent)
		{
			// QW316893 : oGetOriginalTarget retourne un élément différent dans Firefox (c'est fait exprès dans le code). Cela ne semble pas être ce que l'on demande maintenant.
			// (ou alors le comportement de Firefox a changé et on n'a plus besoin du contournement de oGetOriginalTarget).
//			var domTargetLi = clWDUtil.oGetOriginalTarget(oEvent);
			var domTargetLi = clWDUtil.oGetTarget(oEvent);
			if (domTargetLi.parentNode && clWDUtil.bBaliseEstTag(domTargetLi.parentNode, "label"))
			{
				domTargetLi = domTargetLi.parentNode;//clic sur span
			}
			if (clWDUtil.bBaliseEstTag(domTargetLi, "label"))
			{
				domTargetLi = domTargetLi.parentNode;//clic sur label
			}
			if (!clWDUtil.bBaliseEstTag(domTargetLi, "li"))
			{
				return;//clic doit être sur le li
			}

			//clic sur un label de combo ul

			// Memorise le range courant
			var oRange = this.m_oObjetParent.oGetRange();
			if (oRange)
			{
				this.m_oRange = oRange;
			}

			//sélectionne
			this.__Selection(domTargetLi);

			// Execute la commande (rafraichit le bouton en interne)
			this.m_oObjetParent.ExecuteCommande(oEvent, [this.m_sCommande, false, this.getOptionValue(domTargetLi)]);

			//applique aussi le style de l'élément sélectionné
			if ("FormatBlock" == this.m_sCommande)
			{
				var oStyleBlock = clWDUtil.oGetCurrentStyle(domTargetLi.firstElementChild.firstElementChild);
				var oStyleEnCours = this.m_oObjetParent.oGetParamEtat(oEvent, false)[2];
				if (oStyleBlock.fontWeight != oStyleEnCours.fontWeight)
				{
					this.m_oObjetParent.ExecuteCommande(oEvent, ["bold", false, (oStyleBlock.fontWeight!="normal" && oStyleBlock.fontWeight!="400")]);
				}
				if (oStyleBlock.fontStyle != oStyleEnCours.fontStyle)
				{
					this.m_oObjetParent.ExecuteCommande(oEvent, ["italic", false, oStyleBlock.fontStyle.indexOf("normal")==-1]);
				}
				if (oStyleBlock.textDecoration != oStyleEnCours.textDecoration)
				{
					this.m_oObjetParent.ExecuteCommande(oEvent, [oStyleBlock.textDecoration.indexOf("none")==-1, false, null]);
				}
			}

		};
		// Selectionne un element dans la combo
		WDSaisieRicheCbmUL.prototype.__Selection = function __Selection(nOptionOuLi)
		{
			var domLiOption = nOptionOuLi;
			if (!clWDUtil.isObject(nOptionOuLi))
			{
				domLiOption = this.m_oCombo.children[nOptionOuLi];
			}
			if (!domLiOption)
			{
				return;
			}

			var domLabelOption = domLiOption.firstElementChild;

			//sugg ? if (this.m_sCommande=="FontName")//seule la combo de famille de font prend la valeur courante dans le libellé replié
			this.m_domLabelReplie.innerHTML = domLabelOption.innerHTML;

			var domDejaFlag = this.m_oCombo.querySelector(".wbBarreOutilComboLabelActif");
			if (domDejaFlag)
			{
				domDejaFlag.classList.remove("wbBarreOutilComboLabelActif");
			}
			domLabelOption.classList.add("wbBarreOutilComboLabelActif");

			if (!bEdge && domLiOption.scrollIntoView) //edge clignotte trop pendant le scrollIntoView //SUGG : modifier le scrolltop plutôt
			{
				//rend la sélection visible sans toucher au scroll de la page
				var jqParentPrefere = $(this.m_oObjetParent.m_oHote).closest(".dzSpanRiche,.dzSpan");
				if (!jqParentPrefere.length)
				{
					jqParentPrefere = $(window);
				}
				var nScrollAvant = jqParentPrefere.scrollTop();
				domLiOption.scrollIntoView();
				jqParentPrefere.get(0).scrollTo(jqParentPrefere.scrollLeft(),nScrollAvant);
			}
		};

		return WDSaisieRicheCbmUL;
	})();

	function __WDSaisieRiche(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDBarre.prototype.constructor.apply(this, arguments);

			// Le redo se masque comme le undo, pas de masquage spécifique 
			if (this.m_tabBoutonsInfo && this.m_tabBoutonsInfo.UND !== undefined)
			{
				this.m_tabBoutonsInfo.RED = this.m_tabBoutonsInfo.UND;
			}

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees, eModeBarre, sCouleurFondSurvol, sCouleurFondActif, tabBoutonsInfo, bBaliseP ]
			var bBaliseP = tabParametresSupplementaires[6];

			this.m_bBaliseP = bBaliseP;

			var oThis = this;
			this.m_fKeyDown = function (event) { return oThis.bOnKeyDown(event); };
			this.m_fRafBarreTrueMasqueAutre = function (oEvent) { return oThis.__RafBarreMasqueAutre(oEvent || event); };
//			this.m_fRafBarreTrue = function(oEvent) { return oThis.RafBarre(oEvent || event, true); }
			this.m_fRafBarreSans = function (oEvent) { return oThis.RafBarre(oEvent || event); }
		}
	}

	// Declare l'heritage
	__WDSaisieRiche.prototype = new WDBarre();
	// Surcharge le constructeur qui a ete efface
	__WDSaisieRiche.prototype.constructor = __WDSaisieRiche;

	// Membres statiques
	var ms_sSuffixeEditeur = "_EDT";
	var ms_tabPropBordureSav = ["borderTopWidth", "borderTopStyle", "borderTopColor",
		"borderLeftWidth", "borderLeftStyle", "borderLeftColor",
		"borderRightWidth", "borderRightStyle", "borderRightColor",
		"borderBottomWidth", "borderBottomStyle", "borderBottomColor"];
	var ms_tabPropPaddingSav = ["paddingLeft", "paddingTop", "paddingRight", "paddingBottom"];

	//source https://codepen.io/DCzajkowski/pen/JLypqP mixé avec les libellés de https://emojipedia.org/emoji/
	var ms_tabEmojis =
	[
		//Fréquents
		[
			["&#x1f44d;", "thumbs_up", "Thumbs Up"],
			["&#x1f44e;", "-1", "Thumbs Down"],
			["&#x1f62d;", "sob", "Loudly Crying Face"],
			["&#x1f615;", "confused", "Confused Face"],
			["&#x1f610;", "neutral_face", "Neutral Face"],
			["&#x1f60a;", "blush", "Smiling Face With Smiling Eyes"],
			["&#x1f60d;", "heart_eyes", "Smiling Face With Heart-Eyes"]
		],
		//Personnes
		[
			["&#x1f604;", "smile", "Grinning Face With Smiling Eyes"],
			["&#x1f603;", "smiley", "Grinning Face With Big Eyes"],
			["&#x1f600;", "grinning", "Grinning Face"],
			["&#x1f60a;", "blush", "Smiling Face With Smiling Eyes"],
			["&#x1f609;", "wink", "Winking Face"],
			["&#x1f60d;", "heart_eyes", "Smiling Face With Heart-Eyes"],
			["&#x1f618;", "kissing_heart", "Face Blowing a Kiss"],
			["&#x1f61a;", "kissing_closed_eyes", "Kissing Face With Closed Eyes"],
			["&#x1f617;", "kissing", "Kissing Face"],
			["&#x1f619;", "kissing_smiling_eyes", "Kissing Face With Smiling Eyes"],
			["&#x1f61c;", "stuck_out_tongue_winking_eye", "Winking Face With Tongue"],
			["&#x1f61d;", "stuck_out_tongue_closed_eyes", "Squinting Face With Tongue"],
			["&#x1f61b;", "stuck_out_tongue", "Face With Tongue"],
			["&#x1f633;", "flushed", "Flushed Face"],
			["&#x1f601;", "grin", "Beaming Face With Smiling Eyes"],
			["&#x1f614;", "pensive", "Pensive Face"],
			["&#x1f60c;", "relieved", "Relieved Face"],
			["&#x1f612;", "unamused", "Unamused Face"],
			["&#x1f61e;", "disappointed", "Disappointed Face"],
			["&#x1f623;", "persevere", "Persevering Face"],
			["&#x1f622;", "cry", "Crying Face"],
			["&#x1f602;", "joy", "Face With Tears of Joy"],
			["&#x1f62d;", "sob", "Loudly Crying Face"],
			["&#x1f62a;", "sleepy", "Sleepy Face"],
			["&#x1f625;", "disappointed_relieved", "Sad but Relieved Face"],
			["&#x1f630;", "cold_sweat", "Anxious Face With Sweat"],
			["&#x1f605;", "sweat_smile", "Grinning Face With Sweat"],
			["&#x1f613;", "sweat", "Downcast Face With Sweat"],
			["&#x1f629;", "weary", "Weary Face"],
			["&#x1f62b;", "tired_face", "Tired Face"],
			["&#x1f628;", "fearful", "Fearful Face"],
			["&#x1f631;", "scream", "Face Screaming in Fear"],
			["&#x1f620;", "angry", "Angry Face"],
			["&#x1f621;", "rage", "Pouting Face"],
			["&#x1f624;", "triumph", "Face With Steam From Nose"],
			["&#x1f616;", "confounded", "Confounded Face"],
			["&#x1f606;", "laughing", "Grinning Squinting Face"],
			["&#x1f60b;", "yum", "Face Savoring Food"],
			["&#x1f637;", "mask", "Face With Medical Mask"],
			["&#x1f60e;", "sunglasses", "Smiling Face With Sunglasses"],
			["&#x1f634;", "sleeping", "Sleeping Face"],
			["&#x1f635;", "dizzy_face", "Dizzy Face"],
			["&#x1f632;", "astonished", "Astonished Face"],
			["&#x1f61f;", "worried", "Worried Face"],
			["&#x1f626;", "frowning", "Frowning Face With Open Mouth"],
			["&#x1f627;", "anguished", "Anguished Face"],
			["&#x1f47f;", "imp", "Angry Face With Horns"],
			["&#x1f62e;", "open_mouth", "Face With Open Mouth"],
			["&#x1f62c;", "grimacing", "Grimacing Face"],
			["&#x1f610;", "neutral_face", "Neutral Face"],
			["&#x1f615;", "confused", "Confused Face"],
			["&#x1f62f;", "hushed", "Hushed Face"],
			["&#x1f60f;", "smirk", "Smirking Face"],
			["&#x1f611;", "expressionless", "Expressionless Face"],
			["&#x1f472;", "man_with_gua_pi_mao", "Man With Chinese Cap"],
			["&#x1f473;", "man_with_turban", "Person Wearing Turban"],
			["&#x1f46e;", "cop", "Police Officer"],
			["&#x1f477;", "construction_worker", "Construction Worker"],
			["&#x1f482;", "guardsman", "Guard"],
			["&#x1f476;", "baby", "Baby"],
			["&#x1f466;", "boy", "Boy"],
			["&#x1f467;", "girl", "Girl"],
			["&#x1f468;", "man", "Man"],
			["&#x1f469;", "woman", "Woman"],
			["&#x1f474;", "older_man", "Old Man"],
			["&#x1f475;", "older_woman", "Old Woman"],
			["&#x1f471;", "person_with_blond_hair", "Person: Blond Hair"],
			["&#x1f47c;", "angel", "Baby Angel"],
			["&#x1f478;", "princess", "Princess"],
			["&#x1f63a;", "smiley_cat", "Grinning Cat Face"],
			["&#x1f638;", "smile_cat", "Grinning Cat Face With Smiling Eyes"],
			["&#x1f63b;", "heart_eyes_cat", "Smiling Cat Face With Heart-Eyes"],
			["&#x1f63d;", "kissing_cat", "Kissing Cat Face"],
			["&#x1f63c;", "smirk_cat", "Cat Face With Wry Smile"],
			["&#x1f640;", "scream_cat", "Weary Cat Face"],
			["&#x1f63f;", "crying_cat_face", "Crying Cat Face"],
			["&#x1f639;", "joy_cat", "Cat Face With Tears of Joy"],
			["&#x1f63e;", "pouting_cat", "Pouting Cat Face"],
			["&#x1f479;", "japanese_ogre", "Ogre"],
			["&#x1f47a;", "japanese_goblin", "Goblin"],
			["&#x1f648;", "see_no_evil", "See-No-Evil Monkey"],
			["&#x1f649;", "hear_no_evil", "Hear-No-Evil Monkey"],
			["&#x1f64a;", "speak_no_evil", "Speak-No-Evil Monkey"],
			["&#x1f480;", "skull", "Skull"],
			["&#x1f47d;", "alien", "Alien"],
			["&#x1f4a9;", "hankey", "Pile of Poo"],
			["&#x1f525;", "fire", "Fire"],
			["&#x2728;", "sparkles", "parkles"],
			["&#x1f31f;", "star2", "Glowing Star"],
			["&#x1f4ab;", "dizzy", "Dizzy"],
			["&#x1f4a5;", "boom", "Collision"],
			["&#x1f4a2;", "anger", "Anger Symbol"],
			["&#x1f4a6;", "sweat_drops", "Sweat Droplets"],
			["&#x1f4a7;", "droplet", "Droplet"],
			["&#x1f4a4;", "zzz", "Zzz"],
			["&#x1f4a8;", "dash", "Dashing Away"],
			["&#x1f442;", "ear", "Ear"],
			["&#x1f440;", "eyes", "Eyes"],
			["&#x1f443;", "nose", "Nose"],
			["&#x1f445;", "tongue", "Tongue"],
			["&#x1f444;", "lips", "Mouth"],
			["&#x1f44d;", "thumbs_up", "Thumbs Up"],
			["&#x1f44e;", "-1", "Thumbs Down"],
			["&#x1f44c;", "ok_hand", "OK Hand"],
			["&#x1f44a;", "facepunch", "Oncoming Fist"],
			["&#x270a;", "fist", "aised Fist"],
			["&#x1f44b;", "wave", "Waving Hand"],
			["&#x270b;", "hand", "aised Hand"],
			["&#x1f450;", "open_hands", "Open Hands"],
			["&#x1f446;", "point_up_2", "Backhand Index Pointing Up"],
			["&#x1f447;", "point_down", "Backhand Index Pointing Down"],
			["&#x1f449;", "point_right", "Backhand Index Pointing Right"],
			["&#x1f448;", "point_left", "Backhand Index Pointing Left"],
			["&#x1f64c;", "raised_hands", "Raising Hands"],
			["&#x1f64f;", "pray", "Folded Hands"],
			["&#x1f44f;", "clap", "Clapping Hands"],
			["&#x1f4aa;", "muscle", "Flexed Biceps"],
			["&#x1f6b6;", "walking", "Person Walking"],
			["&#x1f3c3;", "runner", "Person Running"],
			["&#x1f483;", "dancer", "Woman Dancing"],
			["&#x1f46b;", "couple", "Woman and Man Holding Hands"],
			["&#x1f46a;", "family", "Family"],
			["&#x1f48f;", "couplekiss", "Kiss"],
			["&#x1f491;", "couple_with_heart", "Couple With Heart"],
			["&#x1f46f;", "dancers", "People With Bunny Ears"],
			["&#x1f646;", "ok_woman", "Person Gesturing OK"],
			["&#x1f645;", "no_good", "Person Gesturing No"],
			["&#x1f481;", "information_desk_person", "Person Tipping Hand"],
			["&#x1f64b;", "raising_hand", "Person Raising Hand"],
			["&#x1f486;", "massage", "Person Getting Massage"],
			["&#x1f487;", "haircut", "Person Getting Haircut"],
			["&#x1f485;", "nail_care", "Nail Polish"],
			["&#x1f470;", "bride_with_veil", "Bride With Veil"],
			["&#x1f64e;", "person_with_pouting_face", "Person Pouting"],
			["&#x1f64d;", "person_frowning", "Person Frowning"],
			["&#x1f647;", "bow", "Person Bowing"],
			["&#x1f3a9;", "tophat", "Top Hat"],
			["&#x1f451;", "crown", "Crown"],
			["&#x1f452;", "womans_hat", "Woman’s Hat"],
			["&#x1f45f;", "athletic_shoe", "Running Shoe"],
			["&#x1f45e;", "mans_shoe", "Man’s Shoe"],
			["&#x1f461;", "sandal", "Woman’s Sandal"],
			["&#x1f460;", "high_heel", "High-Heeled Shoe"],
			["&#x1f462;", "boot", "Woman’s Boot"],
			["&#x1f455;", "shirt", "T-Shirt"],
			["&#x1f454;", "necktie", "Necktie"],
			["&#x1f45a;", "womans_clothes", "Woman’s Clothes"],
			["&#x1f457;", "dress", "Dress"],
			["&#x1f3bd;", "running_shirt_with_sash", "Running Shirt"],
			["&#x1f456;", "jeans", "Jeans"],
			["&#x1f458;", "kimono", "Kimono"],
			["&#x1f459;", "bikini", "Bikini"],
			["&#x1f4bc;", "briefcase", "Briefcase"],
			["&#x1f45c;", "handbag", "Handbag"],
			["&#x1f45d;", "pouch", "Clutch Bag"],
			["&#x1f45b;", "purse", "Purse"],
			["&#x1f453;", "eyeglasses", "Glasses"],
			["&#x1f380;", "ribbon", "Ribbon"],
			["&#x1f302;", "closed_umbrella", "Closed Umbrella"],
			["&#x1f484;", "lipstick", "Lipstick"],
			["&#x1f49b;", "yellow_heart", "Yellow Heart"],
			["&#x1f499;", "blue_heart", "Blue Heart"],
			["&#x1f49c;", "purple_heart", "Purple Heart"],
			["&#x1f49a;", "green_heart", "Green Heart"],
			["&#x1f494;", "broken_heart", "Broken Heart"],
			["&#x1f497;", "heartpulse", "Growing Heart"],
			["&#x1f493;", "heartbeat", "Beating Heart"],
			["&#x1f495;", "two_hearts", "Two Hearts"],
			["&#x1f496;", "sparkling_heart", "Sparkling Heart"],
			["&#x1f49e;", "revolving_hearts", "Revolving Hearts"],
			["&#x1f498;", "cupid", "Heart With Arrow"],
			["&#x1f48c;", "love_letter", "Love Letter"],
			["&#x1f48b;", "kiss", "Kiss Mark"],
			["&#x1f48d;", "ring", "Ring"],
			["&#x1f48e;", "gem", "Gem Stone"],
			["&#x1f464;", "bust_in_silhouette", "Bust in Silhouette"],
			["&#x1f4ac;", "speech_balloon", "Speech Balloon"],
			["&#x1f463;", "footprints", "Footprints"]
		],
		//Nature
		[
			["&#x1f436;", "dog", "Dog Face"],
			["&#x1f43a;", "wolf", "Wolf Face"],
			["&#x1f431;", "cat", "Cat Face"],
			["&#x1f42d;", "mouse", "Mouse Face"],
			["&#x1f439;", "hamster", "Hamster Face"],
			["&#x1f430;", "rabbit", "Rabbit Face"],
			["&#x1f438;", "frog", "Frog Face"],
			["&#x1f42f;", "tiger", "Tiger Face"],
			["&#x1f428;", "koala", "Koala"],
			["&#x1f43b;", "bear", "Bear Face"],
			["&#x1f437;", "pig", "Pig Face"],
			["&#x1f43d;", "pig_nose", "Pig Nose"],
			["&#x1f42e;", "cow", "Cow Face"],
			["&#x1f417;", "boar", "Boar"],
			["&#x1f435;", "monkey_face", "Monkey Face"],
			["&#x1f412;", "monkey", "Monkey"],
			["&#x1f434;", "horse", "Horse Face"],
			["&#x1f411;", "sheep", "Ewe"],
			["&#x1f418;", "elephant", "Elephant"],
			["&#x1f43c;", "panda_face", "Panda Face"],
			["&#x1f427;", "penguin", "Penguin"],
			["&#x1f426;", "bird", "Bird"],
			["&#x1f424;", "baby_chick", "Baby Chick"],
			["&#x1f425;", "hatched_chick", "Front-Facing Baby Chick"],
			["&#x1f423;", "hatching_chick", "Hatching Chick"],
			["&#x1f414;", "chicken", "Chicken"],
			["&#x1f40d;", "snake", "Snake"],
			["&#x1f422;", "turtle", "Turtle"],
			["&#x1f41b;", "bug", "Bug"],
			["&#x1f41d;", "bee", "Honeybee"],
			["&#x1f41c;", "ant", "Ant"],
			["&#x1f41e;", "beetle", "Lady Beetle"],
			["&#x1f40c;", "snail", "Snail"],
			["&#x1f419;", "octopus", "Octopus"],
			["&#x1f41a;", "shell", "Spiral Shell"],
			["&#x1f420;", "tropical_fish", "Tropical Fish"],
			["&#x1f41f;", "fish", "Fish"],
			["&#x1f42c;", "dolphin", "Dolphin"],
			["&#x1f433;", "whale", "Spouting Whale"],
			["&#x1f40e;", "racehorse", "Horse"],
			["&#x1f432;", "dragon_face", "Dragon Face"],
			["&#x1f421;", "blowfish", "Blowfish"],
			["&#x1f42b;", "camel", "Two-Hump Camel"],
			["&#x1f429;", "poodle", "Poodle"],
			["&#x1f43e;", "feet", "Paw Prints"],
			["&#x1f490;", "bouquet", "Bouquet"],
			["&#x1f338;", "cherry_blossom", "Cherry Blossom"],
			["&#x1f337;", "tulip", "Tulip"],
			["&#x1f340;", "four_leaf_clover", "Four Leaf Clover"],
			["&#x1f339;", "rose", "Rose"],
			["&#x1f33b;", "sunflower", "Sunflower"],
			["&#x1f33a;", "hibiscus", "Hibiscus"],
			["&#x1f341;", "maple_leaf", "Maple Leaf"],
			["&#x1f343;", "leaves", "Leaf Fluttering in Wind"],
			["&#x1f342;", "fallen_leaf", "Fallen Leaf"],
			["&#x1f33f;", "herb", "Herb"],
			["&#x1f33e;", "ear_of_rice", "Sheaf of Rice"],
			["&#x1f344;", "mushroom", "Mushroom"],
			["&#x1f335;", "cactus", "Cactus"],
			["&#x1f334;", "palm_tree", "Palm Tree"],
			["&#x1f330;", "chestnut", "Chestnut"],
			["&#x1f331;", "seedling", "Seedling"],
			["&#x1f33c;", "blossom", "Blossom"],
			["&#x1f311;", "new_moon", "New Moon"],
			["&#x1f313;", "first_quarter_moon", "First Quarter Moon"],
			["&#x1f314;", "moon", "Waxing Gibbous Moon"],
			["&#x1f315;", "full_moon", "Full Moon"],
			["&#x1f31b;", "first_quarter_moon_with_face", "First Quarter Moon Face"],
			["&#x1f319;", "crescent_moon", "Crescent Moon"],
			["&#x1f30f;", "earth_asia", "Globe Showing Asia-Australia"],
			["&#x1f30b;", "volcano", "Volcano"],
			["&#x1f30c;", "milky_way", "Milky Way"],
			["&#x1f320;", "stars", "Shooting Star"],
			["&#x26c5;", "partly_sunny", "un Behind Cloud"],
			["&#x26c4;", "snowman", "nowman Without Snow"],
			["&#x1f300;", "cyclone", "Cyclone"],
			["&#x1f301;", "foggy", "Foggy"],
			["&#x1f308;", "rainbow", "Rainbow"],
			["&#x1f30a;", "ocean", "Water Wave"]
		],
		//Objets
		[
			["&#x1f38d;", "bamboo", "Pine Decoration"],
			["&#x1f49d;", "gift_heart", "Heart With Ribbon"],
			["&#x1f38e;", "dolls", "Japanese Dolls"],
			["&#x1f392;", "school_satchel", "Backpack"],
			["&#x1f393;", "mortar_board", "Graduation Cap"],
			["&#x1f38f;", "flags", "Carp Streamer"],
			["&#x1f386;", "fireworks", "Fireworks"],
			["&#x1f387;", "sparkler", "Sparkler"],
			["&#x1f390;", "wind_chime", "Wind Chime"],
			["&#x1f391;", "rice_scene", "Moon Viewing Ceremony"],
			["&#x1f383;", "jack_o_lantern", "Jack-O-Lantern"],
			["&#x1f47b;", "ghost", "Ghost"],
			["&#x1f385;", "santa", "Santa Claus"],
			["&#x1f384;", "christmas_tree", "Christmas Tree"],
			["&#x1f381;", "gift", "Wrapped Gift"],
			["&#x1f38b;", "tanabata_tree", "Tanabata Tree"],
			["&#x1f389;", "tada", "Party Popper"],
			["&#x1f38a;", "confetti_ball", "Confetti Ball"],
			["&#x1f388;", "balloon", "Balloon"],
			["&#x1f38c;", "crossed_flags", "Crossed Flags"],
			["&#x1f52e;", "crystal_ball", "Crystal Ball"],
			["&#x1f3a5;", "movie_camera", "Movie Camera"],
			["&#x1f4f7;", "camera", "Camera"],
			["&#x1f4f9;", "video_camera", "Video Camera"],
			["&#x1f4fc;", "vhs", "Videocassette"],
			["&#x1f4bf;", "cd", "Optical Disk"],
			["&#x1f4c0;", "dvd", "DVD"],
			["&#x1f4bd;", "minidisc", "Computer Disk"],
			["&#x1f4be;", "floppy_disk", "Floppy Disk"],
			["&#x1f4bb;", "computer", "Laptop Computer"],
			["&#x1f4f1;", "iphone", "Mobile Phone"],
			["&#x1f4de;", "telephone_receiver", "Telephone Receiver"],
			["&#x1f4df;", "pager", "Pager"],
			["&#x1f4e0;", "fax", "Fax Machine"],
			["&#x1f4e1;", "satellite", "Satellite Antenna"],
			["&#x1f4fa;", "tv", "Television"],
			["&#x1f4fb;", "radio", "Radio"],
			["&#x1f50a;", "loud_sound", "Speaker High Volume"],
			["&#x1f514;", "bell", "Bell"],
			["&#x1f4e2;", "loudspeaker", "Loudspeaker"],
			["&#x1f4e3;", "mega", "Megaphone"],
			["&#x23f3;", "hourglass_flowing_sand", "ourglass Not Done"],
			["&#x231b;", "hourglass", "ourglass Done"],
			["&#x23f0;", "alarm_clock", "larm Clock"],
			["&#x231a;", "watch", "atch"],
			["&#x1f513;", "unlock", "Unlocked"],
			["&#x1f512;", "lock", "Locked"],
			["&#x1f50f;", "lock_with_ink_pen", "Locked With Pen"],
			["&#x1f510;", "closed_lock_with_key", "Locked With Key"],
			["&#x1f511;", "key", "Key"],
			["&#x1f50e;", "mag_right", "Magnifying Glass Tilted Right"],
			["&#x1f4a1;", "bulb", "Light Bulb"],
			["&#x1f526;", "flashlight", "Flashlight"],
			["&#x1f50c;", "electric_plug", "Electric Plug"],
			["&#x1f50b;", "battery", "Battery"],
			["&#x1f50d;", "mag", "Magnifying Glass Tilted Left"],
			["&#x1f6c0;", "bath", "Person Taking Bath"],
			["&#x1f6bd;", "toilet", "Toilet"],
			["&#x1f527;", "wrench", "Wrench"],
			["&#x1f529;", "nut_and_bolt", "Nut and Bolt"],
			["&#x1f528;", "hammer", "Hammer"],
			["&#x1f6aa;", "door", "Door"],
			["&#x1f6ac;", "smoking", "Cigarette"],
			["&#x1f4a3;", "bomb", "Bomb"],
			["&#x1f52b;", "gun", "Pistol"],
			["&#x1f52a;", "hocho", "Kitchen Knife"],
			["&#x1f48a;", "pill", "Pill"],
			["&#x1f489;", "syringe", "Syringe"],
			["&#x1f4b0;", "moneybag", "Money Bag"],
			["&#x1f4b4;", "yen", "Yen Banknote"],
			["&#x1f4b5;", "dollar", "Dollar Banknote"],
			["&#x1f4b3;", "credit_card", "Credit Card"],
			["&#x1f4b8;", "money_with_wings", "Money With Wings"],
			["&#x1f4f2;", "calling", "Mobile Phone With Arrow"],
			["&#x1f4e5;", "inbox_tray", "Inbox Tray"],
			["&#x1f4e4;", "outbox_tray", "Outbox Tray"],
			["&#x1f4e9;", "envelope_with_arrow", "Envelope With Arrow"],
			["&#x1f4e8;", "incoming_envelope", "Incoming Envelope"],
			["&#x1f4eb;", "mailbox", "Closed Mailbox With Raised Flag"],
			["&#x1f4ea;", "mailbox_closed", "Closed Mailbox With Lowered Flag"],
			["&#x1f4ee;", "postbox", "Postbox"],
			["&#x1f4e6;", "package", "Package"],
			["&#x1f4dd;", "memo", "Memo"],
			["&#x1f4c4;", "page_facing_up", "Page Facing Up"],
			["&#x1f4c3;", "page_with_curl", "Page With Curl"],
			["&#x1f4d1;", "bookmark_tabs", "Bookmark Tabs"],
			["&#x1f4ca;", "bar_chart", "Bar Chart"],
			["&#x1f4c8;", "chart_with_upwards_trend", "Chart Increasing"],
			["&#x1f4c9;", "chart_with_downwards_trend", "Chart Decreasing"],
			["&#x1f4dc;", "scroll", "Scroll"],
			["&#x1f4cb;", "clipboard", "Clipboard"],
			["&#x1f4c5;", "date", "Calendar"],
			["&#x1f4c6;", "calendar", "Tear-Off Calendar"],
			["&#x1f4c7;", "card_index", "Card Index"],
			["&#x1f4c1;", "file_folder", "File Folder"],
			["&#x1f4c2;", "open_file_folder", "Open File Folder"],
			["&#x1f4cc;", "pushpin", "Pushpin"],
			["&#x1f4ce;", "paperclip", "Paperclip"],
			["&#x1f4cf;", "straight_ruler", "Straight Ruler"],
			["&#x1f4d0;", "triangular_ruler", "Triangular Ruler"],
			["&#x1f4d5;", "closed_book", "Closed Book"],
			["&#x1f4d7;", "green_book", "Green Book"],
			["&#x1f4d8;", "blue_book", "Blue Book"],
			["&#x1f4d9;", "orange_book", "Orange Book"],
			["&#x1f4d3;", "notebook", "Notebook"],
			["&#x1f4d4;", "notebook_with_decorative_cover", "Notebook With Decorative Cover"],
			["&#x1f4d2;", "ledger", "Ledger"],
			["&#x1f4da;", "books", "Books"],
			["&#x1f4d6;", "book", "Open Book"],
			["&#x1f516;", "bookmark", "Bookmark"],
			["&#x1f4db;", "name_badge", "Name Badge"],
			["&#x1f4f0;", "newspaper", "Newspaper"],
			["&#x1f3a8;", "art", "Artist Palette"],
			["&#x1f3ac;", "clapper", "Clapper Board"],
			["&#x1f3a4;", "microphone", "Microphone"],
			["&#x1f3a7;", "headphones", "Headphone"],
			["&#x1f3bc;", "musical_score", "Musical Score"],
			["&#x1f3b5;", "musical_note", "Musical Note"],
			["&#x1f3b6;", "notes", "Musical Notes"],
			["&#x1f3b9;", "musical_keyboard", "Musical Keyboard"],
			["&#x1f3bb;", "violin", "Violin"],
			["&#x1f3ba;", "trumpet", "Trumpet"],
			["&#x1f3b7;", "saxophone", "Saxophone"],
			["&#x1f3b8;", "guitar", "Guitar"],
			["&#x1f47e;", "space_invader", "Alien Monster"],
			["&#x1f3ae;", "video_game", "Video Game"],
			["&#x1f0cf;", "black_joker", "Joker"],
			["&#x1f3b4;", "flower_playing_cards", "Flower Playing Cards"],
			["&#x1f004;", "mahjong", "Mahjong Red Dragon"],
			["&#x1f3b2;", "game_die", "Game Die"],
			["&#x1f3af;", "dart", "Direct Hit"],
			["&#x1f3c8;", "football", "American Football"],
			["&#x1f3c0;", "basketball", "Basketball"],
			["&#x26bd;", "soccer", "occer Ball"],
			["&#x26be;", "baseball", "aseball"],
			["&#x1f3be;", "tennis", "Tennis"],
			["&#x1f3b1;", "8ball", "Pool 8 Ball"],
			["&#x1f3b3;", "bowling", "Bowling"],
			["&#x26f3;", "golf", "lag in Hole"],
			["&#x1f3c1;", "checkered_flag", "Chequered Flag"],
			["&#x1f3c6;", "trophy", "Trophy"],
			["&#x1f3bf;", "ski", "Skis"],
			["&#x1f3c2;", "snowboarder", "Snowboarder"],
			["&#x1f3ca;", "swimmer", "Person Swimming"],
			["&#x1f3c4;", "surfer", "Person Surfing"],
			["&#x1f3a3;", "fishing_pole_and_fish", "Fishing Pole"],
			["&#x1f375;", "tea", "Teacup Without Handle"],
			["&#x1f376;", "sake", "Sake"],
			["&#x1f37a;", "beer", "Beer Mug"],
			["&#x1f37b;", "beers", "Clinking Beer Mugs"],
			["&#x1f378;", "cocktail", "Cocktail Glass"],
			["&#x1f379;", "tropical_drink", "Tropical Drink"],
			["&#x1f377;", "wine_glass", "Wine Glass"],
			["&#x1f374;", "fork_and_knife", "Fork and Knife"],
			["&#x1f355;", "pizza", "Pizza"],
			["&#x1f37e;", "bottle", "Champagne"],
			["&#x1f354;", "hamburger", "Hamburger"],
			["&#x1f35f;", "fries", "French Fries"],
			["&#x1f357;", "poultry_leg", "Poultry Leg"],
			["&#x1f356;", "meat_on_bone", "Meat on Bone"],
			["&#x1f35d;", "spaghetti", "Spaghetti"],
			["&#x1f35b;", "curry", "Curry Rice"],
			["&#x1f364;", "fried_shrimp", "Fried Shrimp"],
			["&#x1f371;", "bento", "Bento Box"],
			["&#x1f363;", "sushi", "Sushi"],
			["&#x1f365;", "fish_cake", "Fish Cake With Swirl"],
			["&#x1f359;", "rice_ball", "Rice Ball"],
			["&#x1f358;", "rice_cracker", "Rice Cracker"],
			["&#x1f35a;", "rice", "Cooked Rice"],
			["&#x1f35c;", "ramen", "Steaming Bowl"],
			["&#x1f372;", "stew", "Pot of Food"],
			["&#x1f362;", "oden", "Oden"],
			["&#x1f361;", "dango", "Dango"],
			["&#x1f373;", "egg", "Cooking"],
			["&#x1f35e;", "bread", "Bread"],
			["&#x1f369;", "doughnut", "Doughnut"],
			["&#x1f36e;", "custard", "Custard"],
			["&#x1f366;", "icecream", "Soft Ice Cream"],
			["&#x1f368;", "ice_cream", "Ice Cream"],
			["&#x1f367;", "shaved_ice", "Shaved Ice"],
			["&#x1f382;", "birthday", "Birthday Cake"],
			["&#x1f370;", "cake", "Shortcake"],
			["&#x1f36a;", "cookie", "Cookie"],
			["&#x1f36b;", "chocolate_bar", "Chocolate Bar"],
			["&#x1f36c;", "candy", "Candy"],
			["&#x1f36d;", "lollipop", "Lollipop"],
			["&#x1f36f;", "honey_pot", "Honey Pot"],
			["&#x1f34e;", "apple", "Red Apple"],
			["&#x1f34f;", "green_apple", "Green Apple"],
			["&#x1f34a;", "tangerine", "Tangerine"],
			["&#x1f352;", "cherries", "Cherries"],
			["&#x1f347;", "grapes", "Grapes"],
			["&#x1f349;", "watermelon", "Watermelon"],
			["&#x1f353;", "strawberry", "Strawberry"],
			["&#x1f351;", "peach", "Peach"],
			["&#x1f348;", "melon", "Melon"],
			["&#x1f34c;", "banana", "Banana"],
			["&#x1f34d;", "pineapple", "Pineapple"],
			["&#x1f360;", "sweet_potato", "Roasted Sweet Potato"],
			["&#x1f346;", "eggplant", "Eggplant"],
			["&#x1f345;", "tomato", "Tomato"],
			["&#x1f33d;", "corn", "Ear of Corn"]
		],
		//Lieux
		[
			["&#x1f3e0;", "house", "House"],
			["&#x1f3e1;", "house_with_garden", "House With Garden"],
			["&#x1f3eb;", "school", "School"],
			["&#x1f3e2;", "office", "Office Building"],
			["&#x1f3e3;", "post_office", "Japanese Post Office"],
			["&#x1f3e5;", "hospital", "Hospital"],
			["&#x1f3e6;", "bank", "Bank"],
			["&#x1f3ea;", "convenience_store", "Convenience Store"],
			["&#x1f3e9;", "love_hotel", "Love Hotel"],
			["&#x1f3e8;", "hotel", "Hotel"],
			["&#x1f492;", "wedding", "Wedding"],
			["&#x26ea;", "church", "hurch"],
			["&#x1f3ec;", "department_store", "Department Store"],
			["&#x1f307;", "city_sunrise", "Sunset"],
			["&#x1f306;", "city_sunset", "Cityscape at Dusk"],
			["&#x1f3ef;", "japanese_castle", "Japanese Castle"],
			["&#x1f3f0;", "european_castle", "Castle"],
			["&#x26fa;", "tent", "ent"],
			["&#x1f3ed;", "factory", "Factory"],
			["&#x1f5fc;", "tokyo_tower", "Tokyo Tower"],
			["&#x1f5fe;", "japan", "Map of Japan"],
			["&#x1f5fb;", "mount_fuji", "Mount Fuji"],
			["&#x1f304;", "sunrise_over_mountains", "Sunrise Over Mountains"],
			["&#x1f305;", "sunrise", "Sunrise"],
			["&#x1f303;", "night_with_stars", "Night With Stars"],
			["&#x1f5fd;", "statue_of_liberty", "Statue of Liberty"],
			["&#x1f309;", "bridge_at_night", "Bridge at Night"],
			["&#x1f3a0;", "carousel_horse", "Carousel Horse"],
			["&#x1f3a1;", "ferris_wheel", "Ferris Wheel"],
			["&#x26f2;", "fountain", "ountain"],
			["&#x1f3a2;", "roller_coaster", "Roller Coaster"],
			["&#x1f6a2;", "ship", "Ship"],
			["&#x26f5;", "boat", "ailboat"],
			["&#x1f6a4;", "speedboat", "Speedboat"],
			["&#x1f680;", "rocket", "Rocket"],
			["&#x1f4ba;", "seat", "Seat"],
			["&#x1f689;", "station", "Station"],
			["&#x1f684;", "bullettrain_side", "High-Speed Train"],
			["&#x1f685;", "bullettrain_front", "Bullet Train"],
			["&#x1f687;", "metro", "Metro"],
			["&#x1f683;", "railway_car", "Railway Car"],
			["&#x1f68c;", "bus", "Bus"],
			["&#x1f699;", "blue_car", "Sport Utility Vehicle"],
			["&#x1f697;", "car", "Automobile"],
			["&#x1f695;", "taxi", "Taxi"],
			["&#x1f69a;", "truck", "Delivery Truck"],
			["&#x1f6a8;", "rotating_light", "Police Car Light"],
			["&#x1f693;", "police_car", "Police Car"],
			["&#x1f692;", "fire_engine", "Fire Engine"],
			["&#x1f691;", "ambulance", "Ambulance"],
			["&#x1f6b2;", "bike", "Bicycle"],
			["&#x1f488;", "barber", "Barber Pole"],
			["&#x1f68f;", "busstop", "Bus Stop"],
			["&#x1f3ab;", "ticket", "Ticket"],
			["&#x1f6a5;", "traffic_light", "Horizontal Traffic Light"],
			["&#x1f6a7;", "construction", "Construction"],
			["&#x1f530;", "beginner", "Japanese Symbol for Beginner"],
			["&#x26fd;", "fuelpump", "uel Pump"],
			["&#x1f3ee;", "izakaya_lantern", "Red Paper Lantern"],
			["&#x1f3b0;", "slot_machine", "Slot Machine"],
			["&#x1f5ff;", "moyai", "Moai"],
			["&#x1f3aa;", "circus_tent", "Circus Tent"],
			["&#x1f3ad;", "performing_arts", "Performing Arts"],
			["&#x1f4cd;", "round_pushpin", "Round Pushpin"],
			["&#x1f6a9;", "triangular_flag_on_post", "Triangular Flag"]
		],
		//Symboles
		[
			["&#x1f4af;", "100", "Hundred Points"],
			["&#x1f522;", "1234", "Input Numbers"],
			["&#x1f51f;", "keycap_ten", "Keycap: 10"],
			["&#x1f523;", "symbols", "Input Symbols"],
			["&#x1f520;", "capital_abcd", "Input Latin Uppercase"],
			["&#x1f521;", "abcd", "Input Latin Lowercase"],
			["&#x1f524;", "abc", "Input Latin Letters"],
			["&#x1f53c;", "arrow_up_small", "Upwards Button"],
			["&#x1f53d;", "arrow_down_small", "Downwards Button"],
			["&#x23ea;", "rewind", "ast Reverse Button"],
			["&#x23e9;", "fast_forward", "ast-Forward Button"],
			["&#x23eb;", "arrow_double_up", "ast Up Button"],
			["&#x23ec;", "arrow_double_down", "ast Down Button"],
			["&#x1f197;", "ok", "OK Button"],
			["&#x1f195;", "new", "New Button"],
			["&#x1f199;", "up", "Up! Button"],
			["&#x1f192;", "cool", "Cool Button"],
			["&#x1f193;", "free", "Free Button"],
			["&#x1f196;", "ng", "NG Button"],
			["&#x1f4f6;", "signal_strength", "Antenna Bars"],
			["&#x1f3a6;", "cinema", "Cinema"],
			["&#x1f201;", "koko", "Japanese “Here” Button"],
			["&#x1f22f;", "u6307", "Japanese “Reserved” Button"],
			["&#x1f233;", "u7a7a", "Japanese “Vacancy” Button"],
			["&#x1f235;", "u6e80", "Japanese “No Vacancy” Button"],
			["&#x1f234;", "u5408", "Japanese “Passing Grade” Button"],
			["&#x1f232;", "u7981", "Japanese “Prohibited” Button"],
			["&#x1f250;", "ideograph_advantage", "Japanese “Bargain” Button"],
			["&#x1f239;", "u5272", "Japanese “Discount” Button"],
			["&#x1f23a;", "u55b6", "Japanese “Open for Business” Button"],
			["&#x1f236;", "u6709", "Japanese “Not Free of Charge” Button"],
			["&#x1f21a;", "u7121", "Japanese “Free of Charge” Button"],
			["&#x1f6bb;", "restroom", "Restroom"],
			["&#x1f6b9;", "mens", "Men’s Room"],
			["&#x1f6ba;", "womens", "Women’s Room"],
			["&#x1f6bc;", "baby_symbol", "Baby Symbol"],
			["&#x1f6be;", "wc", "Water Closet"],
			["&#x1f6ad;", "no_smoking", "No Smoking"],
			["&#x1f238;", "u7533", "Japanese “Application” Button"],
			["&#x1f251;", "accept", "Japanese “Acceptable” Button"],
			["&#x1f191;", "cl", "CL Button"],
			["&#x1f198;", "sos", "SOS Button"],
			["&#x1f194;", "id", "ID Button"],
			["&#x1f6ab;", "no_entry_sign", "Prohibited"],
			["&#x1f51e;", "underage", "No One Under Eighteen"],
			["&#x26d4;", "no_entry", "o Entry"],
			["&#x274e;", "negative_squared_cross_mark", "ross Mark Button"],
			["&#x2705;", "white_check_mark", "hite Heavy Check Mark"],
			["&#x1f49f;", "heart_decoration", "Heart Decoration"],
			["&#x1f19a;", "vs", "Vs Button"],
			["&#x1f4f3;", "vibration_mode", "Vibration Mode"],
			["&#x1f4f4;", "mobile_phone_off", "Mobile Phone Off"],
			["&#x1f18e;", "ab", "AB Button (Blood Type)"],
			["&#x1f4a0;", "diamond_shape_with_a_dot_inside", "Diamond With a Dot"],
			["&#x26ce;", "ophiuchus", "phiuchus"],
			["&#x1f52f;", "six_pointed_star", "Dotted Six-Pointed Star"],
			["&#x1f3e7;", "atm", "ATM Sign"],
			["&#x1f4b9;", "chart", "Chart Increasing With Yen"],
			["&#x1f4b2;", "heavy_dollar_sign", "Heavy Dollar Sign"],
			["&#x1f4b1;", "currency_exchange", "Currency Exchange"],
			["&#x274c;", "x", "ross Mark"],
			["&#x2757;", "exclamation", "xclamation Mark"],
			["&#x2753;", "question", "uestion Mark"],
			["&#x2755;", "grey_exclamation", "hite Exclamation Mark"],
			["&#x2754;", "grey_question", "hite Question Mark"],
			["&#x2b55;", "o", "eavy Large Circle"],
			["&#x1f51d;", "top", "Top Arrow"],
			["&#x1f51a;", "end", "End Arrow"],
			["&#x1f519;", "back", "Back Arrow"],
			["&#x1f51b;", "on", "On! Arrow"],
			["&#x1f51c;", "soon", "Soon Arrow"],
			["&#x1f503;", "arrows_clockwise", "Clockwise Vertical Arrows"],
			["&#x1f55b;", "clock12", "Twelve O’Clock"],
			["&#x1f550;", "clock1", "One O’Clock"],
			["&#x1f551;", "clock2", "Two O’Clock"],
			["&#x1f552;", "clock3", "Three O’Clock"],
			["&#x1f553;", "clock4", "Four O’Clock"],
			["&#x1f554;", "clock5", "Five O’Clock"],
			["&#x1f555;", "clock6", "Six O’Clock"],
			["&#x1f556;", "clock7", "Seven O’Clock"],
			["&#x1f557;", "clock8", "Eight O’Clock"],
			["&#x1f558;", "clock9", "Nine O’Clock"],
			["&#x1f559;", "clock10", "Ten O’Clock"],
			["&#x1f55a;", "clock11", "Eleven O’Clock"],
			["&#x2795;", "heavy_plus_sign", "eavy Plus Sign"],
			["&#x2796;", "heavy_minus_sign", "eavy Minus Sign"],
			["&#x2797;", "heavy_division_sign", "eavy Division Sign"],
			["&#x1f4ae;", "white_flower", "White Flower"],
			["&#x1f518;", "radio_button", "Radio Button"],
			["&#x1f517;", "link", "Link"],
			["&#x27b0;", "curly_loop", "urly Loop"],
			["&#x1f531;", "trident", "Trident Emblem"],
			["&#x1f53a;", "small_red_triangle", "Red Triangle Pointed Up"],
			["&#x1f532;", "black_square_button", "Black Square Button"],
			["&#x1f533;", "white_square_button", "White Square Button"],
			["&#x1f534;", "red_circle", "Red Circle"],
			["&#x1f535;", "large_blue_circle", "Blue Circle"],
			["&#x1f53b;", "small_red_triangle_down", "Red Triangle Pointed Down"],
			["&#x2b1c;", "white_large_square", "hite Large Square"],
			["&#x2b1b;", "black_large_square", "lack Large Square"],
			["&#x1f536;", "large_orange_diamond", "Large Orange Diamond"],
			["&#x1f537;", "large_blue_diamond", "Large Blue Diamond"],
			["&#x1f538;", "small_orange_diamond", "Small Orange Diamond"],
			["&#x1f539;", "small_blue_diamond", "Small Blue Diamond"]
		]
	];

	// Description de la barre
	// - Le type (m_nBoutonXXX ou ms_nCombo)
	// - Le suffixe du nom
	// - La commande/la fonction (pour les boutons commandes)
	// - Le style
	// - Les parametres
	__WDSaisieRiche.prototype.m_tabDescBarre = [
		// Boutons OnOff
		{ nType: 0, sSuf: "GRA", sCom: "bold", sSty: "fontWeight", tabP: [{ sVal: "400", bTst: false }] },
		{ nType: 0, sSuf: "ITA", sCom: "italic", sSty: "fontStyle", tabP: [{ sVal: "italic", bTst: true }, { sVal: "oblique", bTst: true }] },
		{ nType: 0, sSuf: "SOU", sCom: "underline", sSty: "textDecoration", tabP: [{ sVal: "underline", bTst: true }] },
		{ nType: 0, sSuf: "BAR", sCom: "strikeThrough", sSty: "textDecoration", tabP: [{ sVal: "line-through", bTst: true }] },
		{ nType: 0, sSuf: "AGA", sCom: "JustifyLeft", sSty: "textAlign", tabP: [{ sVal: "left", bTst: true }] },
		{ nType: 0, sSuf: "ACE", sCom: "JustifyCenter", sSty: "textAlign", tabP: [{ sVal: "center", bTst: true }] },
		{ nType: 0, sSuf: "ADR", sCom: "JustifyRight", sSty: "textAlign", tabP: [{ sVal: "right", bTst: true }] },
		{ nType: 0, sSuf: "AJU", sCom: "JustifyFull", sSty: "textAlign", tabP: [{ sVal: "justify", bTst: true }] },
		{ nType: 0, sSuf: "LNU", sCom: "InsertOrderedList", sSty: "", tabP: [] },
		{ nType: 0, sSuf: "LPU", sCom: "InsertUnorderedList", sSty: "", tabP: [] },
		{ nType: 0, sSuf: "RMO", sCom: "Outdent", sSty: "", tabP: [] },
		{ nType: 0, sSuf: "RPL", sCom: "Indent", sSty: "", tabP: [] },
		{ nType: 0, sSuf: "EXP", sCom: "superscript", sSty: "", tabP: [] },
		{ nType: 0, sSuf: "IND", sCom: "subscript", sSty: "", tabP: [] },
		{ nType: 0, sSuf: "UND", sCom: "undo" },
		{ nType: 0, sSuf: "RED", sCom: "redo" },
		// Boutons popup
		{ nType: 1, sSuf: "COF", sCom: "BackColor", sSty: "backgroundColor" },
		{ nType: 1, sSuf: "COL", sCom: "ForeColor", sSty: "color" },
		// Boutons action
		{ nType: 2, sSuf: "LNK", sCom: "OnLink" },
		{ nType: 2, sSuf: "IMG", sCom: "OnImage" },
		// Combo
		{
			nType: 3, sSuf: "FNA", sCom: "FontName", sSty: "fontFamily", tabP: [
				{ sN: "Arial", sV: "Arial,Helvetica,sans-serif" },
				{ sN: "Courier", sV: "Courier New,Courier,mono" },
				{ sN: "Geneva", sV: "Geneva,Verdana,Arial,Helvetica" },
				{ sN: "Georgia", sV: "Georgia,Times New Roman,Times" },
				{ sN: "Helvetica", sV: "Helvetica" },
				{ sN: "Tahoma", sV: "Tahoma,Geneva,sans-serif" },//comme GreyVolution
				{ sN: "Times New Roman", sV: "Times New Roman,Times,serif" },
				//retire Geneva pour correspondre à la famille par défaut sous Chrome
				{ sN: "Verdana", sV: "Verdana,Arial,Helvetica" }
			]
		},
		{
			//comme gmail, on propose 4 tailles en relook
			nType: 3, sSuf: "FSI", sCom: "FontSize", sSty: "fontSize", tabP:
			[
				{ sN: "1", sV: "1"},
				{ sN: "2", sV: "2" },
				{ sN: "3", sV: "3", bMasquerEnRelookUL : true },
				{ sN: "4", sV: "4" },
				{ sN: "5", sV: "5", bMasquerEnRelookUL : true },
				{ sN: "6", sV: "6" },
				{ sN: "7", sV: "7", bMasquerEnRelookUL : true }
			]
		},
		{
			nType: 3, sSuf: "FHE", sCom: "FormatBlock", sSty: "", tabP: [
				{ sN: "div", sV: "&lt;div&gt;" },
				{ sN: "h1", sV: "&lt;h1&gt;" },
				{ sN: "h2", sV: "&lt;h2&gt;" },
				{ sN: "h3", sV: "&lt;h3&gt;" },
				{ sN: "h4", sV: "&lt;h4&gt;" },
				{ sN: "h5", sV: "&lt;h5&gt;" },
				{ sN: "h6", sV: "&lt;h6&gt;" },
				{ sN: "pre", sV: "&lt;pre&gt;" }
//				{ sN: "mark", sV: "&lt;mark&gt;" }
			]
		}
	];

	// Declare les fonction une par une


	// Recupere l'image de fond des bouton
	// 0 : Normal
	// 1 : Survol
	// 2 : Actif
	__WDSaisieRiche.prototype.sGetCouleurFond = function sGetCouleurFond(/*eEtat*/)
	{
		if (!this.bRelookUL())
		{
			return WDBarre.prototype.sGetCouleurFond.apply(this, arguments);
		}
		//la couleur de fond vient uniquement par la planche SVG
		return "";
	};

	// Initialisation
	__WDSaisieRiche.prototype.Init = function Init()
	{
		// Lance l'init interne qui gere le cas du 'reinit'
		// Rappele le Init de la classe de base
		this.__InitInterne(arguments);
	};

	// Trouve les divers elements : liaison avec le HTML
	__WDSaisieRiche.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
	{
		// nettoyage pour IE : on reste tel quel mais pour les autres on préfère la barre UL
		if (window.$)
		{
			var oBarreBarreUl = this.oGetElementById(document, this.ms_sSuffixeCommande + '_BARREUL');
			var oBarreBarreTable = this.oGetElementById(document, this.ms_sSuffixeCommande);
			if (oBarreBarreUl && oBarreBarreTable)
			{
				if (bIEAvec11)
				{
					$(oBarreBarreUl).remove();
				}
				else
				{
					$(oBarreBarreUl).attr("id",oBarreBarreTable.id);
					$(oBarreBarreTable).remove();
				}
			}
		}

		// Appel de la methode de la classe de base
		WDBarre.prototype._vLiaisonHTML.apply(this, arguments);
		this.ms_tagBoutonClic = this.bRelookUL() ? "i" : "img";
	};

	__WDSaisieRiche.prototype.bRelookUL = function bRelookUL()
	{
		// Lance l'init interne qui gere le cas du 'reinit'
		// Rappele le Init de la classe de base
		return window.$ && this.m_oBarre && this.m_oBarre.tagName.toLowerCase() == "ul";
	};

	// Initialisation
	__WDSaisieRiche.prototype.__InitInterne = function __InitInterne(tabArgumentsSiInitInitiale)
	{
		var bInitInitiale = !!tabArgumentsSiInitInitiale;

		// GP 04/09/2015 : QW260809 : Suite au "Refactoring des constructeurs et de .Init", le test a été inversé. Ici on veux bien tester !bInitInitiale (comme l'indique le commentaire)
		// Si on est pas dans l'init initiale : supprime tout les elements initialises
		if (!bInitInitiale)
		{
			this.__Uninit();
		}

		// Initialise les membres et le contenu
		this.__Init1(bInitInitiale);

		if (bInitInitiale)
		{
			// Appel de la methode de la classe de base
			// Fait ici car on a besoin d'une partie de l'initalisation de __InitCommun
			WDBarre.prototype.Init.apply(this, tabArgumentsSiInitInitiale);
		}

		// Fini l'initalisation
		// true : initialisation initiale
		this.__Init2(bInitInitiale);
	};

	// Initialise ou reinitialise les membres qui font reference au HTML
	// Cree aussi l'iframe
	__WDSaisieRiche.prototype.__Init1 = function __Init1(bInitInitiale)
	{
		// Si on est dans une ZR AJAX : ne fait rien sur les champs
		if (this.oGetTableZRParent())
		{
			return;
		}

		// Initialise les membres
		this.m_oValeur = this.oGetElementByIdZR(document, "");
		this._vLiaisonHTML();

		// Si c'est l'init initiale recupere le tabindex d'une des valeurs
		// Si on est dans une ZR tout les champs ont le meme tabindex donc cela ne pose pas de problemes
		// On peut ne pas avoir this.m_oHote si la ligne selectionne n'est pas sur la page courante
		if (bInitInitiale && this.m_oHote)
		{
			// Reporte si besoin l'attribut TABINDEX
			var oTabIndex = this.m_oHote.attributes.getNamedItem("TABINDEX");
			if (oTabIndex)
			{
				this.m_sTabIndex = oTabIndex.nodeValue;
				// Supprime l'attribut du parent
				this.m_oHote.removeAttribute("TABINDEX", 0);
			}
		}

		// Construit le contenu
		this.__InitCommun();
	};

	// Inverse les elements important de __Init1 (pour ne pas garder des references croisees perdu dans IE)
	__WDSaisieRiche.prototype.__Uninit1 = function ()
	{
		// Si on est dans une ZR AJAX : ne fait rien sur les champs
		if (this.oGetTableZRParent())
		{
			return;
		}

		// Supprime le contenu
		// En particulier suppression de tous les hooks des lignes hors de la ligne selectionnee de la ZR
		this.__UninitCommun();

		if (this.m_oHote)
		{
			// Restaure le style de la bordure de l'hote (et plus que pour IE)
			this.__AppliqueHoteStyleBordure(this.m_oHote);
			delete this.m_oHoteStyleBordure;
			clWDUtil.SupprimeFils(this.m_oHote);
		}
		this.m_oHote = null; delete this.m_oHote;
		this.m_oValeur = null; delete this.m_oValeur;
	};

	// Fini l'initalisation
	__WDSaisieRiche.prototype.__Init2 = function (bInitInitiale)
	{
		// Si on est dans une ZR : place la barre d'outils
		// On peut ne pas avoir oHoteBarre si la ligne selectionne n'est pas sur la page courante
		if (this.bGestionTableZR())
		{
			this.DeplaceBarre(this.oGetElementByIdZRIndice(document, this.nGetTableZRValeur(), this.ms_sSuffixeCommande));
		}

		// Cree/Recree le lien avec la barre d'outils si besoin
		this.__InitHookDocumentBarre();

		// Fixe la valeur
		// On peut ne pas avoir m_oData/m_oValeur si la ligne selectionne n'est pas sur la page courante
		if (this.m_oData && this.m_oValeur)
		{
			this.__EcraseContenu(this.m_oValeur.value);
		}

		// Met a jour la barre d'outils
		this.RafBarre(null);

		// Initialisation specifique
		this.__InitSpecifique(bInitInitiale);
	};

	// Inverse les elements important de __Init2 (pour ne pas garder des references croisees perdu dans IE)
	__WDSaisieRiche.prototype.__Uninit2 = function ()
	{
		// Pour ie : unhook de keydown
		this.__UninitSpecifique();

		// Unhook le document
		this.__UnhookDocumentBarre();
	};

	// Supprime tout les hooks en cas de reinitialisation du champ
	__WDSaisieRiche.prototype.__Uninit = function ()
	{
		// Si on est dans une ZR AJAX : ne fait rien sur les champs
		if (this.oGetTableZRParent())
		{
			return;
		}

		// Appel les initialisation dans l'ordre inverse de l'initialisation
		this.__Uninit2();
		this.__Uninit1();
	};

	// Change l'etat du champ
	__WDSaisieRiche.prototype.SetEtat = function (/*eEtat*/)
	{
		// Appel de la methode de la classe de base
		WDBarre.prototype.SetEtat.apply(this, arguments);

		// Traite les modifications
		this.__ActiveModeEditable();
	};

	// Active le mode editable
	__WDSaisieRiche.prototype.__ActiveModeEditable = function ()
	{
		var bContentEditable;
		var sDesignMode;
		var sCouleurFond;

		// Selon l'etat
		switch (this.eGetEtat())
		{
		default:
		case WDChamp.prototype.ms_eEtatActif:
			bContentEditable = true;
			sDesignMode = "on";
			sCouleurFond = "";
			break;

		case WDChamp.prototype.ms_eEtatLectureSeule:
			bContentEditable = false;
			sDesignMode = "off";
			sCouleurFond = "";
			break;

		case WDChamp.prototype.ms_eEtatGrise:
			bContentEditable = false;
			sDesignMode = "off";
			sCouleurFond = "InactiveBorder";
			break;
		}

		// On peut ne pas avoir m_oData/m_oDocument si la ligne selectionne n'est pas sur la page courante
		if (this.m_oData && this.m_oDocument)
		{
			if (bIEAvec11)
			{
				// Passe en mode editable
				this.m_oDocument.contentEditable = bContentEditable;
				this.m_oData.contentEditable = bContentEditable;
			}
			else
			{
				// Passe en mode editable uniquement si l'element est visible
				if (clWDUtil.oGetCurrentStyle(this.m_oHote).display != "none")
				{
					this.m_oDocument.designMode = sDesignMode;
				}
			}
			this.__SetRegles();
			this.m_oData.style.backgroundColor = sCouleurFond;
		}
	};

	// Fixe les règles de saisie
	__WDSaisieRiche.prototype.__SetRegles = function __SetRegles()
	{
		// GP 26/01/2015 : TB87999/QW251174 : On autorise le choix de paragraphes ou de sauts de lignes sur la touche entrée :
		if (this.m_bBaliseP)
		{
			if (bFF)
			{
				// Ne fonctionne pas
//				// FF : insertBrOnReturn
//				this.m_oDocument.execCommand("insertBrOnReturn", false, "false");
			}
			else
			{
				// Autres (IE11/Chrome) : paragraphes
				// GP 29/01/2015 : Il semble que la valeur soit "globale" pour IE (= si on a deux zone de texte riche dans la même page, avec les options différentes)
				this.m_oDocument.execCommand("defaultParagraphSeparator", false, "p");
			}
		}
		else
		{
			if (bFF)
			{
				// Ne fonctionne pas
//				// FF : Ne commande rien c'est le mode par défaut
			}
			else if (bCrm)
			{
				// Ne commande rien c'est le mode par défaut
			}
			else if (bIE11Plus)
			{
				// Pase en mode "div"
				this.m_oDocument.execCommand("defaultParagraphSeparator", false, "div");
			}
			else if (bIE)
			{
				// Pose le hook sur onkeypress
			}
		}

		// GP 19/07/2018 : TB109644 : Demande au navigateur de faire du CSS (Fonctionne avec Chrome, fonctionne partiellement avec FF. Ne fonctionne pas avec Edge ni IE. Pas testé sous Opéra).
		this.m_oDocument.execCommand("styleWithCSS", false, true);
	};

	// Reactive le mode d'edition (pour firefox uniquement)
	__WDSaisieRiche.prototype.__ReactiveModeEditable = function ()
	{
		if (this.m_oHote && !bIEAvec11)
		{
			// Uniquement si l'element est visible
			// Si l'element est invisible, la modification sera faite quand l'element est rendu visible
			if (clWDUtil.oGetCurrentStyle(this.m_oHote).display != "none")
			{
				this.m_oDocument.designMode = "off";

				// Selon l'etat
				switch (this.eGetEtat())
				{
				default:
				case WDChamp.prototype.ms_eEtatActif:
					this.m_oDocument.designMode = "on";
					this.__SetRegles();
					break;

				case WDChamp.prototype.ms_eEtatLectureSeule:
				case WDChamp.prototype.ms_eEtatGrise:
					// Laisse desactive
					break;
				}
			}
		}
	};

	// Initialisation commune des contenus : IFrame ou HTML direct dans les ZR
	__WDSaisieRiche.prototype.__InitCommun = function ()
	{
		// Si on est pas dans une ZR
		if (!this.bGestionTableZR())
		{
			// Initialise directement l'IFrame
			this.__InitCommunIFrame();
		}
		else
		{
			this.__InitCommunZR();
		}
	};

	// Initialisation commune de l'IFrame
	__WDSaisieRiche.prototype.__InitCommunIFrame = function ()
	{
		// Construit l'IFRAME interne
		var oIFrame = document.createElement("iframe");
		oIFrame.id = this.sGetNomElement(ms_sSuffixeEditeur);
		oIFrame.src = "javascript:\"\"";

		this.__OnResize(null, oIFrame, oIFrame.style);
		oIFrame.frameBorder = "0";
		oIFrame.border = "0";

		// Reporte si besoin l'attribut TABINDEX
		if (this.m_sTabIndex)
		{
			oIFrame.tabIndex = this.m_sTabIndex;
		}

		// L'ajoute au document
		clWDUtil.SupprimeFils(this.m_oHote);
		this.m_oIFrame = this.m_oHote.appendChild(oIFrame);

		// Document a manipuler
		this.m_oDocument = this.m_oIFrame.contentWindow.document;

		//et grip ?
		if (this.bRelookUL())
		{
			//grip pour redimensionner la saisie via JS
			oIFrame.style.resize = "none";
			//évite le blanc sous l'iframe
			oIFrame.style.verticalAlign="top";

			//récupère la taille du parent si en px uniquement			
			//afin d'en faire la taille min du champ même en cas de redimensionnement par le grip
			if (this.m_oHote.style.height.indexOf("%") == -1)
			{
				oIFrame.style.minHeight=this.m_oHote.style.height;
				this.m_oHote.style.minHeight=this.m_oHote.style.height;
				//note : pas de height 100% sur le div car le parent peut ne pas avoir de taille et alors la hauteur prise sera celle par défaut de l'iframe, sous Chrome = 150px
			}

			this.m_jqGrip = $('<div class="wbSaisieRicheGrip"></div>');
			$(this.m_oHote).append(this.m_jqGrip);
			var oThis = this;
			var fOnDebutGrip = function (jqEventDown)
			{
				var nHauteurInit = $(oThis.m_oIFrame).height();
				var nDebutY = jqEventDown.screenY;
				var jqBodys = $(document.body).add(oThis.m_oDocument.body).add(window)
				.on("mousemove.wb.saisieriche.grip.pendant",function(jqEventMove)
				{
					$(oThis.m_oIFrame).add(oThis.m_oIFrame.parentElement).css("height", nHauteurInit+jqEventMove.screenY-nDebutY );
					jqEventMove.stopPropagation();
					jqEventMove.preventDefault();
					//re place la barre car un ascenseur sur la page a peut être été créée à cause de ce redimensionnement
					oThis._DeplaceBarre();
				})
				.on("mouseup.wb.saisieriche.grip.fin",function(/*jqEventMove*/)
				{
					jqBodys.off("mousemove.wb.saisieriche.grip.pendant");
					jqBodys.off("mouseup.wb.saisieriche.grip.fin");

					oThis.m_jqGrip.one("mousedown.wb.saisieriche.grip.debut",fOnDebutGrip);
				})
				;
			};
			this.m_jqGrip.one("mousedown.wb.saisieriche.grip.debut",fOnDebutGrip);

			//_vOnResize
			var oThis = this;
			$(window)
			.on("trigger.wb.postUpdateLayoutSuperposableEpingle",function(jqEvent){
				//redimensionne la saisie 
				oThis._vOnResize(jqEvent);
			})
			;
		}


		// Construit le contenu de l'IFRAME
		var tabIFrameHTML = [];
		var tabDependancesJS = [];
		var tabDependancesCSS = [];
		var sBaseHref = _WD_;//attention que _WD_ contient ..: pour une page PHP dans FR, donc les ressources iraient vers _WEB au lieu de _WEB/FR/
		if (clWDUtil.bHTML5)
		{
			tabIFrameHTML.push("<!DOCTYPE html>");
			if (this.bRelookUL())
			{
				//prend toutes les dépendances CSS car on a besoin de static et de l'ambiance pour les planches
				$("link").filter(function(){ return this.href && this.href.indexOf(".css")>-1; }).each(function(){
					tabDependancesCSS.push(this.cloneNode(true));
				});
				$("script").filter(function()
				{
					return this.src && (
					   (this.src.indexOf("WDUtil.js")!=-1)
					|| (this.src.indexOf("WDEditeurImage")!=-1)
					|| (this.src.indexOf("WWConstante")!=-1)
					|| (this.src.indexOf("jquery.js")!=-1)
					|| (this.src.indexOf("jquery-3.js")!=-1)
					|| (this.src.indexOf("jquery-ui.js")!=-1)
					// || (this.src.indexOf("jquery-effet.js")!=-1)
					);
				}).each(function()
				{
					var nPosRes;
					if ((nPosRes=this.src.indexOf("res/WDUtil.js"))!=-1)
					{
						//attention que _WD_ contient ..: pour une page PHP dans FR, donc les ressources iraient vers _WEB au lieu de _WEB/FR/
						//cette astuce permet de fonctionner autant sur une page PHP que Session que AWP avec URL rewriting
						sBaseHref = this.src.substr(0,nPosRes);
					}
					tabDependancesJS.push(this);
				});

				var oStylePalette = getComputedStyle( this.m_oBarre );
				var tabRgbTexte = clWDUtil.tabHTML2RVBA(oStylePalette.color);
				var sCouleurSurvol = "rgba("+tabRgbTexte[0]+", "+tabRgbTexte[1]+", "+tabRgbTexte[2]+", 0.15)";
				var sCouleurActif = "rgba("+tabRgbTexte[0]+", "+tabRgbTexte[1]+", "+tabRgbTexte[2]+", 0.25)";

				//indique la couleur de fond pour les barres
				document.head.appendChild( $("<style id='wbSaisieRicheStyle-" + this.m_oBarre.id + "'>"
				+"#"+this.m_oBarre.id+" .wbBarreOutilsLi:hover, .wbBarreOutilsComboListeOption:hover{background-color:" + sCouleurSurvol +";}"
				+"#"+this.m_oBarre.id+" .wbBarreOutilsLi.wbActif, #"+this.m_oBarre.id+" .wbBarreOutilComboCheckbox:checked+.wbBarreOutilComboLabelReplie>* {background-color:" + sCouleurActif +";}"
				/*séparateur entre 2 combos*/
				+"#"+this.m_oBarre.id+" .wbBarreOutilsLi:not([id])+.wbBarreOutilsLi:not([id])>label>* { border-left: 1px solid " + oStylePalette.borderColor +"; }"
				+ "}</style>").get(0) );

				//indique la couleur de fond pour les mini barres
				tabDependancesCSS.push($("<style>.wbSaisieRicheBarre{ "
				+ "background-color:" + oStylePalette.backgroundColor +";"
				+ "border-color:" + oStylePalette.borderColor +";"
				+"}"
				+".wbBarreOutilsMiniBarreLi:hover{background-color:" + sCouleurSurvol +";}"
				+ "</style>").get(0));
			}
		}
		else
		{
			tabIFrameHTML.push("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		}
		// Cela ne semble pas fonctionner dans certaines version de FireFox sans le xmlns
		tabIFrameHTML.push(clWDUtil.bRTL ? "<html dir=\"rtl\">" : "<html>");
		tabIFrameHTML.push("<head xmlns=\"http://www.w3.org/1999/xhtml\">");
		// Recupere le style du texte
		// GP 19/12/2012 : Modifié de 1px a 2px sur demande de SYC (pour faire comme la valeur par défaut d'un input text normal)
//		tabIFrameHTML.push("<style type=\"text/css\">body{margin:0px;padding:2px;overflow:auto;}p{margin:0px;}</style>");
		// GP 17/11/2014 : TB87999/QW251174 : Nouvelle correction différente : on fait pour avoir des <p> sur entrée et des <br> sur shift+entrée
		// GP 22/07/2015 : QW258944 : Ajoute les style qui vons bien pour Chrome mais aussi les autres navigateurs
		tabIFrameHTML.push(
		"<style type=\"text/css\">body{margin:0;padding:2px;overflow:auto;}html{height: 100%;overflow:hidden;}body{height:100%;box-sizing:border-box !important;}");
		// Copie aussi le style des paragraphes
		var sStyleParagraphes = clWDUtil.sGetCSSTexte("#" + this.m_oHote.id + " p");
		if ("" != sStyleParagraphes)
		{
			tabIFrameHTML.push("p{");
			tabIFrameHTML.push(sStyleParagraphes);
			tabIFrameHTML.push("}");
		}
		tabIFrameHTML.push("</style>" );
		tabIFrameHTML.push("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><base target=\"_blank\" /><base href=\"");
		//tabIFrameHTML.push(window.location.pathname.substr(0,window.location.pathname.lastIndexOf("/")+1));
		tabIFrameHTML.push(sBaseHref);
		tabIFrameHTML.push("\" />");

		// L'ecrit
		var sContenuHTML = tabIFrameHTML.join("") ;

		sContenuHTML += "</head><body></body></html>";

		// Init du code commun gestion des images dans l'editeur html
		this.m_oSaisieAPI = new WDSaisieAPI(true,this.m_oIFrame,{
			domStyleCommun 	: tabDependancesCSS
		,	bGestionImages	: true
		});
		this.m_oSaisieAPI.SetProp_Valeur(sContenuHTML);

		//force l'ajout des dépendances JS => après le SetProp_Valeur afin que <body> soit présent pour que l'exécution fonctionne
		// mais qu'on puisse les rajouter dans <head>
		//this.m_oDocument.head.innerHTML += sDependancesJS;
		for(var iDep=0; iDep<tabDependancesJS.length; ++iDep)
		{
			var domCopie = document.createElement("script");
			//synchrone
			domCopie.async = false;
			domCopie.defer = false;
			domCopie.src = tabDependancesJS[iDep].src;
			//sContenuHTML += domCopie.outerHTML;
			this.m_oDocument.head.appendChild(domCopie);
		}

		// Memorise les donnees
		this.m_oData = this.m_oDocument.body;
		//lien pour jquery-effet, utile pour tester la visibilité des options de la barre de FAA (pour les appliquer sur les mini barres)
		this.m_oDocument.documentElement.wdSaisieRiche = this;

		// Copie la bordure de l'hote sur le body
		var oStyleHote = clWDUtil.oGetCurrentStyle(this.m_oHote);

		// Sauve le style de la bordure de l'hote (toujours et pas plus que pour IE)
		// Utilise un parcours par index car sinon var/in liste des propriétés indésirables (length entre autre)
		var oHoteStyleBordure = {};
		__SaveProprietes(oStyleHote, ms_tabPropBordureSav, oHoteStyleBordure, false);
		__SaveProprietes(oStyleHote, ms_tabPropPaddingSav, oHoteStyleBordure, true);
		this.m_oHoteStyleBordure = oHoteStyleBordure;

		this.__AppliqueHoteStyleBordure(this.m_oData);
		// Supprime la bordure et le padding de l'hote
		this.m_oHote.style.border = "0px solid transparent";
		this.m_oHote.style.padding = "0px 0px 0px 0px";

		// Copie les autres styles
		this.__CopieStyleBase();

		//post traitement

		if (window.$)
		{
			var jqChampSaisieMaterialDesign = $(this.m_oIFrame).closest(".wbLibChamp" + this.m_sAliasChamp);
			if (jqChampSaisieMaterialDesign.length)
			{
				jqChampSaisieMaterialDesign.trigger("trigger.wb.saisie.rwd.riche");
			}
		}
		// Branche le hook pour ..Modifié et l'evénement de modification "simple" de champ de saisie.
		if (window["NSPCS"])
		{
			var sAlias = this.m_sAliasChamp;
			this.m_oData.addEventListener("input", function ()
			{
				NSPCS.NSChamps.OnInputModification(sAlias);
			});
		}
	};

	// Sauve des propriétés depuis un tableau
	function __SaveProprietes(oStyleHote, tabPropSav, oHoteStyleProp, bFiltreSi0)
	{
		var i;
		var nLimiteI = tabPropSav.length;
		var sProprieteNom, sProprieteValeur;
		for (i = 0; i < nLimiteI; i++)
		{
			sProprieteNom = tabPropSav[i];
			sProprieteValeur = oStyleHote[sProprieteNom];
			if (bFiltreSi0 && ("0" == sProprieteValeur.charAt(0)))
			{
				continue;
			}
			oHoteStyleProp[sProprieteNom] = sProprieteValeur;
		}
	}

	// Applique m_oHoteStyleBordure sur un élément
	__WDSaisieRiche.prototype.__AppliqueHoteStyleBordure = function __AppliqueHoteStyleBordure(oElement)
	{
		// Applique le style de la bordure de l'hote
		var oHoteStyleBordure = this.m_oHoteStyleBordure;
		for (var sPropriete in oHoteStyleBordure)
		{
			if (oHoteStyleBordure.hasOwnProperty(sPropriete))
			{
				oElement.style[sPropriete] = oHoteStyleBordure[sPropriete];
			}
		}
	};

	// Initialisation commune des contenus dans une ZR : IFrame ou HTML direct dans les ZR
	__WDSaisieRiche.prototype.__InitCommunZR = function ()
	{
		this.PourToutesLignesTableZR(this.__InitCommunZR_CB, this.nGetTableZRValeur());
	};
	__WDSaisieRiche.prototype.__InitCommunZR_CB = function __InitCommunZR_CB(nLigneAbsolueBase1, nValeur)
	{
		if (nLigneAbsolueBase1 != nValeur)
		{
			// Initialise une valeur sans le HTML
			this.__InitCommunZR_HTML(nLigneAbsolueBase1);
		}
		else
		{
			// Initialise l'IFrame
			this.__InitCommunZR_IFrame(nLigneAbsolueBase1);
		}
	};

	// Initialisation commune des contenus dans une ZR : IFrame
	__WDSaisieRiche.prototype.__InitCommunZR_IFrame = function (/*nIndice*/)
	{
		// On ne peut pas le faire maintenant car this.m_oBarre n'est pas encore defini
//		// Place la barre d'outils
//		this.m_oBarre = this.oGetElementByIdZRIndice(document, nIndice, this.ms_sSuffixeCommande).insertBefore(this.m_oBarre, null);

		// Init l'IFrame
		if (this.m_oHote)
		{
			this.__InitCommunIFrame();
		}
	};

	// Initialisation commune des contenus dans une ZR : HTML
	__WDSaisieRiche.prototype.__InitCommunZR_HTML = function (nIndice)
	{
		// Place simplement la valeur HTML
		var oValeur = this.oGetElementByIdZRIndice(document, nIndice, "");
		var oHote = this.oGetElementByIdZRIndice(document, nIndice, this.ms_sSuffixeHote);

		if (!oValeur || !oHote)
		{
			return;
		}

		// Applique la couleur selon l'etat
		var oAttribut = oValeur.attributes.getNamedItem("DISABLED");
		oHote.style.backgroundColor = (oAttribut && oAttribut.specified) ? "InactiveBorder" : "";
		// Pour avoir un asenseur et ne pas deformer la page
		oHote.style.overflow = "auto";
		// Maintenant que l'hote est pret : ecrit la valeur
		oHote.innerHTML = oValeur.value;

		// Se branche sur le onclick de l'element pour pourvoir changer de ligne
		// normalement il n'y a pas de code de onclick sur l'hote donc on n'a pas besoin de gerer le cas
		var oThis = this;
		oHote.onclick = function (oEvent) { oThis.OnClickLigne(oEvent || event, nIndice); };
	};

	// Inverse les elements important de __InitCommun (pour ne pas garder des references croisees perdu dans IE)
	__WDSaisieRiche.prototype.__UninitCommun = function ()
	{
		// Si on est dans une ZR : suppression des onclick sur les elements
		if (this.bGestionTableZR())
		{
			this.__UninitCommunZR();
		}

		// Suppression de l'iframe et des membres
		this.m_oData = null; delete this.m_oData;
		this.m_oDocument = null; delete this.m_oDocument;
		this.m_oIFrame = null; delete this.m_oIFrame;
	};

	// Inverse les elements important de __InitCommunZR (pour ne pas garder des references croisees perdu dans IE)
	// (sauf la gestion de l'iframe qui est manipule globalement)
	__WDSaisieRiche.prototype.__UninitCommunZR = function ()
	{
		// Pour toutes les lignes de la ZR : Uninitialise une valeur dans le HTML
		this.PourToutesLignesTableZR(this.__UninitCommunZR_HTML);
	};
	__WDSaisieRiche.prototype.__UninitCommunZR_HTML = function (nLigneAbsolueBase1)
	{
		// Trouve simplement la valeur HTML
		var oHote = this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, this.ms_sSuffixeHote);
		if (oHote)
		{
			clWDUtil.SupprimeFils(oHote);
			oHote.onclick = null;
		}
	};

	// Initialisation specifique
	__WDSaisieRiche.prototype.__InitSpecifique = function __InitSpecifique(/*bInitInitiale*/)
	{
		// Met a jour le mode lecture seule/grise du champ
		if (this.m_oValeur)
		{
			var bLectureSeule = false;
			var oAttribut = this.m_oValeur.attributes.getNamedItem("READONLY");
			if (oAttribut && oAttribut.specified)
			{
				// Appele directement la methode de la classe de base car on ne veux pas modifier maintenant l'iframe
				// (fait par __ActiveModeEditable)
				WDBarre.prototype.SetEtat.apply(this, [this.ms_eEtatLectureSeule]);
				bLectureSeule = true;
			}
			// Grise est prioritaire sur lecture seule
			var bGrise = false;
			oAttribut = this.m_oValeur.attributes.getNamedItem("DISABLED");
			if (oAttribut && oAttribut.specified)
			{
				// Appele directement la methode de la classe de base car on ne veux pas modifier maintenant l'iframe
				// (fait par __ActiveModeEditable)
				WDBarre.prototype.SetEtat.apply(this, [this.ms_eEtatGrise]);
				bGrise = true;
			}

			// Si on n'est pas en lecture seule ou en grise, et que l'on n'etait pas actif, passe en actif
			if (!bLectureSeule && !bGrise && (this.ms_eEtatActif != this.eGetEtat()))
			{
				WDBarre.prototype.SetEtat.apply(this, [this.ms_eEtatActif]);
			}
		}

		// Passe en mode editable
		this.__ActiveModeEditable();

		// GP 10/12/2013 : QW240191 : On modifie la hauteur minimale du champ
		this.__SetMinHeight();

		// GP 06/03/2015 : Si on est dans une ZR, on n'a pas encore this.m_oDocument
		if (this.m_oDocument)
		{
			// Pour tous les navigateurs : hook de keydown pour gerer les divers cas de br/p/div
			// On peut ne pas avoir m_oData si la ligne selectionne n'est pas sur la page courante
			clWDUtil.AttacheDetacheEvent(true, this.m_oDocument, "keydown", this.m_fKeyDown);
		}
	};

	// Desinitialisation specifique
	__WDSaisieRiche.prototype.__UninitSpecifique = function ()
	{
		// GP 06/03/2015 : Si on est dans une ZR, on n'a pas encore this.m_oDocument
		if (this.m_oDocument)
		{
			// Pour tous les navigateurs : hook de keydown pour gerer les divers cas de br/p/div
			// On peut ne pas avoir m_oData si la ligne selectionne n'est pas sur la page courante
			clWDUtil.AttacheDetacheEvent(false, this.m_oDocument, "keydown", this.m_fKeyDown);
		}

		// pas besoin de supprimer le mode editable

		// Pas besoin de supprimer la fonction de redimensionnement : elle est globale
	};

	// Recupere le style par defaut du champ
	__WDSaisieRiche.prototype.__CopieStyleBase = function __CopieStyleBase()
	{
		var oCurrentStyleData = clWDUtil.oGetCurrentStyle(this.m_oData);
		// GP 11/06/2013 : TB82701 : Sous Firefox, si le champ est dans un conteneur display:none, getComputedStyle retourne null
		// Voir : https://bugzilla.mozilla.org/show_bug.cgi?id=548397
		// Donc ici oCurrentStyleData est null
		// => Si le champ est dans une celulle en display:none, alors oCurrentStyleData echoue
		if (bFF && (null === oCurrentStyleData))
		{
			return;
		}

		var oCurrentStyleHote = clWDUtil.oGetCurrentStyle(this.m_oHote);

		// GP 04/05/2016 : TB97762 : Place le style dans un style css (déjà créé) et pas directement dans le style du body.
		// En effet si on place le style directement dans la balise, que le style écrit n'est pas le style par défaut de Chrome et que l'utilisateur applique
		// un style qui se trouve être le style par défaut alors Chrome supprime le style de la balise body (et replace le style sur tout les éléments sauf la sélection)
//		var oStyleData = this.m_oData.style;
		// Attention : ne pas utiliser clWDUtil.oStyleTrouve car il manipule le document qui est la page courante et pas le document de l'IFRAME de saisie
		var oStyleData = (clWDUtil.oStyleTrouveDocument(this.m_oDocument, "body") || { style: {} }).style;

		// On copie TOUT les styles HTML du champ caché sauf :
		// - Les bordures (copié depuis l'hote)
		// - Le padding s'il est de 0px
		// - Overflow (forcé à auto)
		for (var sPropriete in oCurrentStyleHote)
		{
			// GP 12/12/2019 : QW321186 : Sous Firefox, cela liste des propriétés "numéro" qui ont comme valeur un nom de "vraie" propriété CSS.
			// En fait les propriétés "normales" sont héritées par le prototype.
			if (bFF && oCurrentStyleHote.hasOwnProperty(sPropriete))
			{
				continue;
			}

			// Si c'est une vraie propriété
			var sStyleValeurPropriete = oCurrentStyleHote[sPropriete];

			if ("string" === (typeof sStyleValeurPropriete))
			{
				// Filtre :
				// - "borderXxx" (copié depuis l'hote) (inclus "border")
				// - "paddingXxx (copié depuis l'hote) (inclus "padding")
				// - "outline" (alias de border)
				// - "margin" (non supprimé de l'hote)
				// - "overflow" (forcé en interne)
				// - "width" et "height" (forcé en interne)
				// - "cssText" (pseudo propriété dispo selon les navigateurs et le mode)
				// - "background" (composition des backgroundXxx)
				// - "font" (composition des fontXxx)
				// - "webkitBorderXxx" (modifie les bordures)
				// - "webkitPaddingXxx" (modifie le padding)
				// - "webkitLogicalXxx" (modifie les dimensions)
				// GP 10/11/2017 : QW288969 : Ignore aussi visibility : il semble que avec Chrome, on lise visibility : hidden sur le champ hote si on viens d'une popup déjà masquée.
				// Note : cela ne se produit pas avec un point d'arrêt donc cela semble vraiment un problème avec Chrome.
				// De toutes façons soit l'hote n'est pas visible et on n'est pas visible, soit il est visible et on veux être visible. Donc dans tous les cas cela n'a aucun intéret de copier ce style.
				// GP 23/11/2018 : QW306949 : Ignore aussi "-webkit-user-modify" exporté par EDGE et qui bloque la saisie.
				if (	"border" === sPropriete.substr(0, 6)
					||	"padding" === sPropriete.substr(0, 7)
					||	"outline" === sPropriete
					||	"margin" === sPropriete.substr(0, 6)
					||	"overflow" === sPropriete.substr(0, 8)
					||	"width" === sPropriete
					||	"height" === sPropriete
					||	"cssText" === sPropriete
					||	"background" === sPropriete
					||	"font" === sPropriete
					||	"webkitBorder" === sPropriete.substr(0, 12)
					||	"webkitPadding" === sPropriete.substr(0, 13)
					||	"webkitLogical" === sPropriete.substr(0, 13)
					||	"visibility" === sPropriete
					||	"webkitUserModify" === sPropriete)
				{
					continue;
				}
				else if ("lineHeight" === sPropriete)
				{
					//relativise la hauteur de ligne pour qu'en cas de modification de taille de font, la hauteur de ligne suive proportionnellement
					var nHauteurLigneDefaut = parseInt(oCurrentStyleHote.lineHeight);
					var nHauteurFontDefaut = parseInt(oCurrentStyleHote.fontSize);
					if (!isNaN(nHauteurLigneDefaut) && !isNaN(nHauteurFontDefaut))
					{
						sStyleValeurPropriete = nHauteurLigneDefaut / nHauteurFontDefaut;
					}
				}

				// On n'arrive a pas a ecrire certaines propriétés
				// Par exemple avec IE on a textKashidaSpace qui retourne "0pt" alors que la valeur attendue est "xx%" ou "auto"...
//				try
//				{
				if (oCurrentStyleData[sPropriete] !== sStyleValeurPropriete)
				{
					oStyleData[sPropriete] = sStyleValeurPropriete;
				}
//				}
//				catch (e)
//				{
//				}
			}
		}
	};

	// GP 03/09/2012 : QW78915 : Affiche la barre et masque celle des autres champsdes autres champs quand
	__WDSaisieRiche.prototype.__RafBarreMasqueAutre = function __RafBarreMasqueAutre(oEvent)
	{
		// Masque la barre des autres champs
		AppelMethode("RafBarre", [oEvent], this);

		return this.RafBarre(oEvent, true);
	};

	// Initialise la barre d'outils
	__WDSaisieRiche.prototype._InitBarreAutomatique = function _InitBarreAutomatique()
	{
		// Deplace en dehors de l'init de la barre pour ne pas avoir plein de cas : init initiale et init dans ZR
//		// Hook la gestion de la barre dans l'iframe
//		this.__InitHookDocumentBarre();

		// Ajoute le hook sur onkeyup et onclick
		// Cette init n'est faite que une fois donc pas besoin de fonction de unhook
		clWDUtil.AttacheDetacheEvent(true, document, "click", this.m_fRafBarreSans);
		clWDUtil.AttacheDetacheEvent(true, document, "keyup", this.m_fRafBarreSans);
	};

	// Hook la gestion de la barre dans l'iframe
	__WDSaisieRiche.prototype.__InitHookDocumentBarre = function ()
	{
		// Le cas FF semble fonctioner aussi dans IE mais dans le doute je garde les deux cas
		// On peut ne pas avoir this.m_oData/this.m_oDocument si la ligne selectionne n'est pas sur la page courante
		var oCible = bIEAvec11 ? this.m_oData : this.m_oDocument;
		if (oCible)
		{
			clWDUtil.AttacheDetacheEvent(true, oCible, "click", this.m_fRafBarreTrueMasqueAutre);
			clWDUtil.AttacheDetacheEvent(true, oCible, "keyup", this.m_fRafBarreTrueMasqueAutre);
		}
	};

	// Suppression de la gestion de la barre dans l'iframe
	__WDSaisieRiche.prototype.__UnhookDocumentBarre = function ()
	{
		var oCible = bIEAvec11 ? this.m_oData : this.m_oDocument;
		if (oCible)
		{
			clWDUtil.AttacheDetacheEvent(false, oCible, "click", this.m_fRafBarreTrueMasqueAutre);
			clWDUtil.AttacheDetacheEvent(false, oCible, "keyup", this.m_fRafBarreTrueMasqueAutre);
		}
	};

	// Creation des boutons de la barre d'outils

	// Boutons on/off
	__WDSaisieRiche.prototype._voNewBoutonOnOff = function _voNewBoutonOnOff(oElementBarre, oDesc)
	{
		return new WDBarreBoutonOnOffRiche(this, oElementBarre, oDesc.sCom, oDesc.sSty, oDesc.tabP);
	};
	// Boutons popup
	__WDSaisieRiche.prototype._voNewBoutonPopup = function _voNewBoutonPopup(oElementBarre, oDesc)
	{
		var sSuffixe = oDesc.sSuf + "P";
		return new WDBarreBoutonPopupRiche(this, oElementBarre, oDesc.sCom, this.oGetElementByIdBarre(document, sSuffixe), sSuffixe, oDesc.sSty);
	};
	// Boutons action
	__WDSaisieRiche.prototype._voNewBoutonAction = function _voNewBoutonAction(oElementBarre, oDesc)
	{
		return new WDBarreBoutonRiche(this, oElementBarre, oDesc.sCom);//pour lien et image
	};
	// Combos
	__WDSaisieRiche.prototype._voNewBoutonCombo = function _voNewBoutonCombo(oElementBarre, oDesc)
	{
		if (this.bRelookUL())
		{
			return new WDSaisieRicheCbmUL(this, oElementBarre, oDesc.sCom, oDesc.sSty, oDesc.tabP, oDesc.sSuf);
		}
		return new WDSaisieRicheCbm(this, oElementBarre, oDesc.sCom, oDesc.sSty, oDesc.tabP, oDesc.sSuf);
	};

	// Associe les boutons de la barre
	__WDSaisieRiche.prototype._AssocieBarreElements = function _AssocieBarreElements()
	{
		if (this.bRelookUL())
		{
			//option uniquement dispo pour la barre relookée en UL
			this.m_tabDescBarre.push({
				nType: 3, sSuf: "EMO", sCom: "wbEmoji", tabP : ms_tabEmojis, nIndiceSelectionDefaut : 9
			});
		}

		WDBarre.prototype._AssocieBarreElements.apply(this,arguments);

		if (this.bRelookUL())
		{
			//IE et Edge ne supporte pas la planche SVG
			if (! (bIEAvec11||bEdge))
			{
				$(".wbBarreOutilsImgPlanche").addClass("wbBarreOutilsImgPlancheSVG");
			}
		}
	};

//	// Menus
//	__WDSaisieRiche.prototype._voNewBoutonMenu = function _voNewBoutonMenu(oElementBarre, oDesc)
//	{
//		return null;
//	};
//	// Menus avec highlight du parent si un element est selectionne
//	__WDSaisieRiche.prototype._voNewBoutonMenuS = function _voNewBoutonMenuS(oElementBarre, oDesc)
//	{
//		return null;
//	};

	// Gestion du click dans une ligne autre de la ZR
	__WDSaisieRiche.prototype.OnClickLigne = function (oEvent, nLigneAbsolueBase1)
	{
		// Sauve le contenu de la ligne
		this.bSauveContenu(oEvent);

		// Dans le cas des ZR Ajax, il faut attendre la MAJ de la ZR par le serveur pour forcer la valeur sinon notre valeur est ecrasee
		// Appel de la methode automone qui supporte l'appel retarde
		this._OnClickLigneRetarde(oEvent, nLigneAbsolueBase1);
	};

	// Dans le cas des ZR Ajax, il faut attendre la MAJ de la ZR par le serveur pour forcer la valeur sinon notre valeur est ecrasee
	// Appel de la methode automone qui supporte l'appel retarde
	__WDSaisieRiche.prototype._OnClickLigneRetarde = function (oEvent, nLigneAbsolueBase1)
	{
		// Si on est dans une ZR Ajax, retarde l'appel tant que toutes les requetes ne sont pas traitees
		var oTableZRParent = this.oGetTableZRParent();
		if (oTableZRParent && oTableZRParent.m_oCache && (oTableZRParent.m_oCache.m_tabRequetes.length > 0))
		{
			this.nSetTimeout(this._OnClickLigneRetarde, clWDUtil.ms_oTimeoutImmediat, null, nLigneAbsolueBase1);
			return;
		}

		// Affecte la valeur de la ZR
		this.SetTableZRValeur(oEvent, nLigneAbsolueBase1);

		// Redessine tout
		this.__InitInterne();
	};

	// Evenement sur le rechargement du champ apres filtrage par la classe de base
	__WDSaisieRiche.prototype._vOnResize = function (oEvent)
	{
		// Appel de la classe de base
		WDBarre.prototype._vOnResize.apply(this, arguments);

		// GP 26/06/2020 : TB116116 : Ne réactive pas si le champ n'est pas vraiment disponible.
		// Probablement que le bug est à un autre endroit et que le champ doit être disponible, mais pas trouvé.
		// Et seulement si affiché (cas dans popup et le window prend un resize)
		if (!this.m_oDocument || !this.m_oHote || !clWDUtil.bEstDisplay(this.m_oHote,document,true))
		{
			return;
		}

		// Ne fait rien si on a un redimensionnement en attente (IE)
		// Car dans ce cas le computedStyle de this.m_oIFrame n'existe pas (element non visible)
		// GP 18/10/2017 : TB105681 : Ajout du test sur this.m_oIFrame
		if (this.m_oIFrame && !this.bGetTimeXXXExiste("__OnResizeInterneS1"))
		{
			this.__OnResize(oEvent, this.m_oIFrame, clWDUtil.oGetCurrentStyle(this.m_oIFrame));
		}

		// GP 12/11/2018 : QW305938 : Avec IE et Edge, la lecture du backgroundSize effectif du parent retourne une valeur effective : backgroundSize:x% y% est transformé en backgroundSize:XXXpx YYYpx.
		// Donc il faut faire la MAJ en continue de ces valeurs en fonction de l'évolution de la taille de l'élément.
		if (bIEAvec11 || bEdge)
		{
			this.__CopieStyleBase();
		}

		// GP 10/12/2013 : QW240191 : On modifie la hauteur minimale du champ
		this.__SetMinHeight();

		// Met à jour la position et taille de la barre
		this.__RafBarreMasqueAutre(oEvent);
	};

	// Dimensionne le body
	__WDSaisieRiche.prototype.__SetMinHeight = function __SetMinHeight()
	{
		// GP 10/12/2013 : QW240191 : On modifie la hauteur minimale du champ
		// GP 27/03/2014 : TB81141 : Toujours en HTML5 (inclus bIE11Plus qui n'est vrai que en HTML5)
		// GP 28/04/2014 : TB81798 : Toujours dans Firefox
		if ((clWDUtil.bHTML5 || bFF) && this.m_oData)
		{
			// GP 27/03/2014 : TB81141 : Place en absolute et 0 sur les bord pour avoir l'ancrage
			// Remonte div > td > tr > tbody > table
			// GP 24/06/2016 : QW274422 : Activation de ce code pour tous les navigateurs (sauf IE)
			if ((bFF || clWDUtil.bHTML5) && (!bIE) && ("100%" == this.m_oHote.parentNode.parentNode.parentNode.parentNode.style.height))
			{
				// 0 pour avoir un reflow et avoir la taille correcte du parent
				this.m_oIFrame.style.minHeight = "0";
				// -3 : C'est la valeur qui marche...
				// Aucune idée de la source de cette valeur
				this.m_oIFrame.style.minHeight = (this.m_oHote.parentNode.offsetHeight - 3) + "px";
			}

			// 0 pour avoir un reflow et avoir la taille correcte du parent
			this.m_oData.style.minHeight = "0";

			// 4 : Pour le padding.
			// GP 04/09/2014 : Dans Firefox, si le champ est invisible (par exemple dans une popup non affichée) : clWDUtil.oGetCurrentStyle(this.m_oData) retourne NULL
			var oCurrentStyleData = clWDUtil.oGetCurrentStyle(this.m_oData);
			var nOffsetBorderPourHeight = oCurrentStyleData ? this.s_nGetOffsetBorderPourHeight(oCurrentStyleData) : 0;
			this.m_oData.style.minHeight = this.m_oIFrame.offsetHeight - 4 - nOffsetBorderPourHeight + "px";
		}
	};

	// Evenement sur le rechargement du champ
	__WDSaisieRiche.prototype.__OnResize = function __OnResize(oEvent, oIFrame, oStyle)
	{
		// Il faut tenir compte des bordure du parent
		var nLargeurOffset = this.s_nGetOffsetBorderPourWidth(oStyle);
		var nHauteurOffset = this.s_nGetOffsetBorderPourHeight(oStyle);

		if (bIEQuirks)
		{
			// Sauf si on est dans l'init et que l'iframe n'est pas encore dans l'hote
			if (this.m_oIFrame == oIFrame)
			{
				clWDUtil.oSupprimeElement(oIFrame);
			}
			// Appel de la version interne par timeout si on est dans un vrai redimensionnement
			if (oEvent)
			{
				// Modifie temporairement la taille de l'hote pour etre sur de la reduction (se reduit en hauteur mais pas en largeur)
				// La sauvegarde de la valeur (pour le cas en %) ne fonctionne que parce que l'on est en quirks et que l'on lit la valeur en %
				// Avec les autres navigateurs on recoit la valeur finale en px
				var oStyleHote = clWDUtil.oGetCurrentStyle(this.m_oHote);
				var sWidth = oStyleHote.width;
				var sHeight = oStyleHote.height;
				this.m_oHote.style.width = "1px";
				this.m_oHote.style.height = "1px";
				this.nSetTimeoutUnique("__OnResizeInterneS1", clWDUtil.ms_oTimeoutNonImmediat200, nLargeurOffset, nHauteurOffset, sWidth, sHeight, oIFrame);
				return;
			}
		}
		else
		{
			// On remet une taille extensible que que le m_oHote recalcule sa taille (utile en reduction)
			oIFrame.style.width = "100%";
			oIFrame.style.height = "100%";
			// Tous le reste semble inutile dans les navigateurs moderne : sort direct
			return;
		}

		// Appel direct de la version interne
		this.__OnResizeInterne(oIFrame, nLargeurOffset, nHauteurOffset);
	};

	// Versions interne
	__WDSaisieRiche.prototype.__OnResizeInterneS1 = function __OnResizeInterneS1(nLargeurOffset, nHauteurOffset, sWidth, sHeight, oIFrame)
	{
		// Replace la taille du champ
		this.m_oHote.style.width = sWidth;
		this.m_oHote.style.height = sHeight;

		// Appel la version finale
		this.__OnResizeInterne(oIFrame, nLargeurOffset, nHauteurOffset);
	};
	__WDSaisieRiche.prototype.__OnResizeInterne = function __OnResizeInterne(oIFrame, nLargeurOffset, nHauteurOffset)
	{
		// Il faut tenir compte des bordure du parent
		var nLargeur = this.m_oHote.offsetWidth - nLargeurOffset;
		var nHauteur = this.m_oHote.offsetHeight - nHauteurOffset;

		if (bIEQuirks && (this.m_oIFrame == oIFrame))
		{
			this.m_oHote.appendChild(oIFrame);
		}
		// Filtre les valeurs negatives (possible si offsetXXX retourne 0 et que l'on supprime les bordures)
		oIFrame.style.width = ((nLargeur >= 0) ? nLargeur : 0) + "px";
		oIFrame.style.height = ((nHauteur >= 0) ? nHauteur : 0) + "px";

		// GP 08/09/2014 : QW247817 : Notifie la barre du redimensionnement
		this._DeplaceBarre();
	};

	// Passe en mode editable les barres affichees
	__WDSaisieRiche.prototype.OnDisplay = function (oElementRacine, bAffiche)
	{
		// GP 18/05/2020 : TB117197 : Si pas encore correctement initialisé (cas de l'affichage d'une popup depuis le code serveur).
		// En fait, l'ordre est faux :
		// - Code des popups affiche du serveur => déclenche un OnDisplay des fils.
		// - Init de la page dont init des champs.
		// On fait un init forcé ici. Il sera en double mais cela semble fonctionner.
		if (undefined === this.m_tabBarreElements)
		{
			this.Init();
		}

		// Appel de la methode de la classe de base
		WDBarre.prototype.OnDisplay.apply(this, arguments);

		//pas concerné
		if (false === (bAffiche && this.m_oHote && clWDUtil.bEstFils(this.m_oHote, oElementRacine)))
		{
			return;
		}

		//Cas de l'affichage

		var bResize = true;
		// Deplace si besoin l'iframe (FF)
		// Si on a plusieurs champs de saisie dans le contenu il faut faire un parcours
		var bTrouve = false;
		var tabIFrame = oElementRacine.getElementsByTagName("iframe");
		var i;
		var nLimiteI = tabIFrame.length;
		for (i = 0; i < nLimiteI; i++)
		{
			if (this.m_oDocument == tabIFrame[i].contentWindow.document)
			{
				bTrouve = true;
				break;
			}
		}
		if (!bTrouve)
		{
			// Reinitialise les membres et le contenu
			this.__InitInterne();

			// On ne redimensionnera pas
			bResize = false;
		}

		// GP 11/06/2013 : TB82701 : Sous Firefox, si le champ est dans un conteneur display:none, getComputedStyle retourne null
		// Voir : https://bugzilla.mozilla.org/show_bug.cgi?id=548397
		// Donc ici oCurrentStyleData est null
		// => Si le champ est dans une celulle en display:none, alors oCurrentStyleData echoue
		// Donc le __CopieStyleBase original n'a pas été fait
		if (bFF)
		{
			this.__CopieStyleBase();
		}

		// GP 02/11/2013 : TB84307 : On a aussi recu un visibilty:hidden sur le body
		if (this.m_oDocument)
		{
			if (this.m_oDocument.body)
			{
				this.m_oDocument.body.style.visibility = "";
			}

			// GP 26/06/2020 : TB116116 : Ne réactive pas si le champ n'est pas vraiment disponible.
			// Probablement que le bug est à un autre endroit et que le champ doit être disponible, mais pas trouvé.
			this.__ReactiveModeEditable();
		}

		// Et redimensionne la zone cliente si besoin
		if (bResize)
		{
			this._vOnResize(null);
		}
	};

	// - Tous les champs : notifie que une table ou ZRs a été MAJ en AJAX (= table/ZR non AJAX mais avec les ZR horizontales)
	__WDSaisieRiche.prototype._vOnTableZRAfficheAJAXInterne = function _vOnTableZRAfficheAJAXInterne()
	{
		// Appel de la methode de la classe de base (qui normalement ne fait rien)
		WDBarre.prototype._vOnTableZRAfficheAJAXInterne.apply(this, arguments);

		// MAJ du champ
		this.__InitInterne();
	};

	// Methode appele directement
	// - Champ dans une table/ZR : notifie le champ de l'affichage/suppression de la ligne
	__WDSaisieRiche.prototype._vOnLigneTableZRAffiche = function _vOnLigneTableZRAffiche(nLigneAbsolueBase1, bSelectionne)
	{
		// Appel de la methode de la classe de base
		WDBarre.prototype._vOnLigneTableZRAffiche.apply(this, arguments);

		// Si c'est la ligne selectionnee
		// bSelectionne n'est pas fiable, il peut pas exemple venir de WDTable.prototype.bMAJLignes qui le calcule par this.vbLigneEstSelectionneeSansZR.
		// Note : il faudrait faire une correction correcte en calculant les deux FLAGS bSelectionne et bSelectionneSansZR et en les transmettant correctement.
		var oTableZRParent = this.oGetTableZRParent();
		if (bSelectionne || (oTableZRParent && oTableZRParent.bLigneEstSelectionnee(nLigneAbsolueBase1 - 1, NaN)))
		{
			// Init 1

			// Initialise les membres
			this.m_oValeur = this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, "");
			this.m_oHote = this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, this.ms_sSuffixeHote);
			// Initialise l'IFrame
			this.__InitCommunZR_IFrame(nLigneAbsolueBase1 - 1);

			// Init 2
			this.DeplaceBarre(this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, this.ms_sSuffixeCommande));

			// Cree/Recree le lien avec la barre d'outils si besoin
			this.__InitHookDocumentBarre();

			// Fixe la valeur
			// On peut ne pas avoir m_oData/m_oValeur si la ligne selectionne n'est pas sur la page courante
			if (this.m_oData && this.m_oValeur)
			{
				this.__EcraseContenu(this.m_oValeur.value);
			}

			// Met a jour la barre d'outils
			this.RafBarre(null);

			// Initialisation specifique
			this.__InitSpecifique(false);
		}
		else
		{
			// Initialise une valeur dans le HTML
			this.__InitCommunZR_HTML(nLigneAbsolueBase1);
		}
	};
	__WDSaisieRiche.prototype._vOnLigneTableZRMasque = function _vOnLigneTableZRMasque(nLigneAbsolueBase1, bSelectionne, oEvent)
	{
		// Uninit 2

		// Si c'est la ligne selectionnee
		if (bSelectionne)
		{
			// Sauve la valeur
			this.bSauveContenu(oEvent);

			// Pour ie : unhook de keydown
			this.__UninitSpecifique();

			// Unhook le document
			this.__UnhookDocumentBarre();
		}

		// Trouve simplement la valeur HTML
		var oHote = this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, this.ms_sSuffixeHote);
		if (oHote)
		{
			// Restaure la bordure de l'hote
			if (bSelectionne)
			{
				// Restaure le style de la bordure de l'hote (et plus que pour IE)
				this.__AppliqueHoteStyleBordure(oHote);
				delete this.m_oHoteStyleBordure;
			}

			clWDUtil.SupprimeFils(oHote);
			oHote.onclick = null;
		}

		// Suppression de l'iframe et des membres
		if (bSelectionne)
		{
			this.m_oData = null; delete this.m_oData;
			this.m_oDocument = null; delete this.m_oDocument;
			this.m_oIFrame = null; delete this.m_oIFrame;

			// Uninit1

			// Restaure la bordure de l'hote : aucune importance on supprime la ligne

			this.m_oHote = null; delete this.m_oHote;
			this.m_oValeur = null; delete this.m_oValeur;
		}

		// Appel de la methode de la classe de base
		WDBarre.prototype._vOnLigneTableZRMasque.apply(this, arguments);
	};

	// Met a jour la barre d'outils
	__WDSaisieRiche.prototype.RafBarre = function (oEvent, bAfficheBarre)
	{
		// Calcule l'etat de la barre dans tous les cas
		// Calcule si besoin si on doit afficher la barre
		if (bAfficheBarre === undefined)
		{
			// Regarde l'element actif dans le document
			var oA = null;
			if (!bIE && oEvent)
			{
				oA = clWDUtil.oGetOriginalTarget(oEvent);
			}
			if (!oA)
			{
				oA = document.activeElement;
				// Avec Firefox la valeur recue n'est pas forcement dans le document (c'est un objet externe donc sans acces)
				try
				{
					oA.parentNode;
				}
				catch (e)
				{
					oA = null;
				}
			}
			if (oA === window || clWDUtil.bEstFils(oA, this.m_oBarre) || clWDUtil.bEstFils(oA, this.m_oHote))
			{
				bAfficheBarre = true;
			}
			// Si on est dans une ZR Ajax, on recoit parfois le fils racine de la cellule
			var oTableZRParent = this.oGetTableZRParent();
			if (oTableZRParent && oTableZRParent.m_tabSelection && oTableZRParent.m_oCache)
			{
				var oLigneCache = oTableZRParent.m_oCache.oGetLigne(oTableZRParent.m_tabSelection[0]);
				if (oLigneCache && (oA == oLigneCache.m_oLigneHTML.oGetLigneLogiqueHTML(oLigneCache.vnGetColonneHTML())))
				{
					bAfficheBarre = true;
				}
			}
		}

		// Si le champ n'avais pas le focus, le notifie qu'il le recoit
		if (bAfficheBarre)
		{
			this.OnFocus(oEvent);
		}
		else
		{
			// Supprime le focus si besoin
			this.OnBlur(oEvent);
		}

		// Masque les autres barres
		if (bAfficheBarre)
		{
			this.AppelMethodeAutresPtr(WDChamp.prototype.MasqueBarre, [oEvent]);
		}

		// Memorise la valeur uniquement en mode automatiqueoDataCommande
		var bAfficheBarreRecu = bAfficheBarre;
		if (this.m_eModeBarre != this.ms_eModeBarreAutomatique)
		{
			bAfficheBarre = undefined;
		}

		// Puis appele la methode de la classe de base
		//NON car au lieu de SetDisplay on joue sur l'opacité ici
		if (!this.bRelookUL())
		{
			return WDBarre.prototype.RafBarre.apply(this, [oEvent, bAfficheBarre]);
		}

		// Si le champ est desactive : masque la barre
		if (this.eGetEtat() != WDChamp.prototype.ms_eEtatActif)
		{
			bAfficheBarre = false;
		}

		// Selon le mode de la barre
		switch (this.m_eModeBarre)
		{
		// Jamais : rien a faire
		case this.ms_eModeBarreJamais:
			// Rien
			break;

		// Automatique : calcule l'etat de la barre
		case this.ms_eModeBarreAutomatique:
		default:
			// Affiche/masque la barre
			//clWDUtil.SetDisplay(this.m_oBarre, bAfficheBarre);
			this.m_oBarre.style.display = "block";
			this.m_oBarre.style.opacity = bAfficheBarre ? 1 : 0;
			this.m_oBarre.style.pointerEvents = bAfficheBarre ? "all" : "none";

			if (!bAfficheBarre)
			{
				// Pas besoin de la MAJ des boutons
				break;
			}
			// Pas de break;

		// Toujours + automatique : MAJ des boutons
		case this.ms_eModeBarreToujours:
			// Deplace la barre (au cas ou le champ se d�place)
			this._DeplaceBarre();

			// GP 06/10/2014 : QW249402 : Si la barre a �t� d�plac�e, la visibilit� n'est plus h�rit�e du parent.
			if (this.m_bBarreDeplacee)
			{
				//clWDUtil.SetDisplay(this.m_oBarre, clWDUtil.bEstDisplay(this.m_oHote, document, true));
				this.m_oBarre.style.display = "block";
				bAfficheBarre = !(!bAfficheBarreRecu && !clWDUtil.bEstDisplay(this.m_oHote, document, true));
				this.m_oBarre.style.opacity = bAfficheBarre ? 1 : 0;
				this.m_oBarre.style.pointerEvents = bAfficheBarre ? "all" : "none";
			}

			var oDataEtat = this.oGetParamEtat(oEvent, false);

			// Demande a chaque element de la barre
			var i;
			var nLimiteI = this.m_tabBarreElements.length;
			for (i = 0; i < nLimiteI; i++)
			{
				this.m_tabBarreElements[i].RafEtat(oEvent, oDataEtat);
			}
			break;
		}


	};

	__WDSaisieRiche.prototype._DeplaceBarreSiBesoinAvecTimeout = function()
	{
		//pas de timeout
		if (this.m_bBarreDeplacee && this.m_oBarre && this.m_oHote && clWDUtil.bEstDisplay(this.m_oHote, document, true))
		{
			this._DeplaceBarre();
		}
	};


	// Deplace la barre au bon endroit via une règle sur bottom plutôt que top et chevauchant la bordure haute de la saisie
	__WDSaisieRiche.prototype._DeplaceBarre = function _DeplaceBarre()
	{
		if (!this.bRelookUL())
		{
			//raz le bottom 0 venu du style .WDBarreOutils
			this.m_oBarre.style.bottom = "auto";
			//code historique
			WDBarre.prototype._DeplaceBarre.apply(this,arguments);
			return;
		}

		if (this.m_oHote && this.m_bBarreDeplacee)
		{
			var oStyle = {};
			oStyle.top = "auto";
			oStyle.left = "auto";
			//ajuste aussi la largeur au champ
			oStyle.marginTop = 0;
			//la barre doit être dans la partie scrollable de la saisie
			var jqParentPrefere = $(this.m_oHote).closest(".dzSpanRiche,.dzSpan,.dzSpanRiche>span,.dzSpan>span");
			//champ dans un conteneur à débordement
			if (jqParentPrefere.length)
			{
				//pas au bon endroit ?
				if (this.m_oBarre.parentElement != this.m_oHote.parentElement)
				{
					var jqBarre = $(this.m_oBarre).detach();
					$(this.m_oHote.parentElement).css("position","relative").prepend(jqBarre);
				}
				//et chevauche la bordure
				oStyle.marginTop = (parseInt(this.m_oData.style.borderTopWidth));
				if (oStyle.marginTop)
				{
					oStyle.marginTop += "px";
				}
				oStyle.transform = "translateY(-100%)";
				oStyle.width = "100%";
			}
			//champ dans la page qui scroll
			else if (this.m_oHote)
			{
				oStyle.left = (clWDUtil.nGetBoundingClientRectLeft(this.m_oHote, true, false)) + "px";
				oStyle.width = (this.m_oHote.getBoundingClientRect().width) + "px";

				var nHauteurPage = document.body.getBoundingClientRect().height;				

				var nBas = (nHauteurPage - clWDUtil.nGetBoundingClientRectTop(this.m_oHote, true, false) - parseInt(this.m_oData.style.borderTopWidth));

				//et chevauche la bordure
				oStyle.bottom = nBas+"px";

				//coulisse
				var nBasCoulisse = nBas;
				nBasCoulisse = Math.min(nBasCoulisse,nHauteurPage - ($(window).scrollTop()) - this.m_oBarre.clientHeight);
			nBasCoulisse = Math.max(nBasCoulisse,nHauteurPage - ($(this.m_oHote).offset().top + this.m_oHote.clientHeight));
				oStyle.transform = "translateY(" + (nBas-nBasCoulisse) + "px)";

				if (this.rafDeplaceBarre)
				{
					cancelAnimationFrame(this.rafDeplaceBarre);
				}
	//			var oThis = this;
	//			this.rafDeplaceBarre = requestAnimationFrame(function()
	//			{
	//				var sMembreStyle;
	//				for(sMembreStyle in oStyle)
	//				{
	//					if (!oThis.m_oDernierePositionBarre || oThis.m_oDernierePositionBarre[sMembreStyle]!=oStyle[sMembreStyle])
	//					{
	//						oThis.m_oBarre.style[sMembreStyle] = oStyle[sMembreStyle];
	//					}
	//				}
	//				oThis.m_oDernierePositionBarre = oStyle;
	//			});
			}

			var sMembreStyle;
			for (sMembreStyle in oStyle)
			{
				if (!this.m_oDernierePositionBarre || this.m_oDernierePositionBarre[sMembreStyle] != oStyle[sMembreStyle])
				{
					this.m_oBarre.style[sMembreStyle] = oStyle[sMembreStyle];
				}
			}
			this.m_oDernierePositionBarre = oStyle;
		}
	};

	// Si le champ n'avais pas le focus, le donne
	__WDSaisieRiche.prototype.OnFocus = function (oEvent)
	{
		// Si le champ n'a pas encore le focus
		if (!this.m_bFocus)
		{
			// Memorise que l'on a le focus
			this.m_bFocus = true;
			// Execute le PCode
			this.RecuperePCode(this.ms_nEventNavFocus)(oEvent);
		}
	};

	// Si le champ avais pas le focus, le supprime
	__WDSaisieRiche.prototype.OnBlur = function (oEvent)
	{
		// Si le champ a le focus
		if (this.m_bFocus)
		{
			// GP 24/02/2015 : TB91122 : Sauve le contenu en premier pour toujours le faire.
			this.__SauveContenuAvecOnChange(oEvent);

			// Execute le PCode
			this.RecuperePCode(this.ms_nEventNavBlur)(oEvent);
			// Memorise que l'on n'a plus le focus
			delete this.m_bFocus
		}
	};
	__WDSaisieRiche.prototype.__SauveContenuAvecOnChange = function __SauveContenuAvecOnChange(oEvent)
	{
		// GP 24/02/2015 : TB91122 : Sauve le contenu en premier pour toujours le faire.
		if (this.bSauveContenu(oEvent))
		{
			// Si la valeur du champ a ete modifie : appel de onchange
			// (Comme sur un champ de saisie normal, avant le onfocus)
			var fOnChange = this.RecuperePCode(this.ms_nEventNavChange);
			if (fOnChange != clWDUtil.m_pfVide)
			{
				fOnChange(oEvent);
			}
		}
	};

	// Evenement sur l'appuis d'une touche (remplace les <p> par des <BR /> en IE
	__WDSaisieRiche.prototype.bOnKeyDown = function (oEvent)
	{
		// Selon le code du caractere
		// On est dans IE donc pas besoin de lire le membre de FF
		// GP 30/01/2015 : QW254227 : Filtre le cas ou l'on demande les balises <P>
		if (oEvent.keyCode == 13)
		{
			if (bIE && !bIE11Plus && !this.m_bBaliseP)
			{
				// Recupere la selection
				var oRange = this.oGetRange();
				if (oRange)
				{
					// Si on a une selection texte
					if (oRange["duplicate"])
					{
						if (oRange["parentElement"])
						{
							// GP 30/01/2015 : QW254227 : Filtre aussi les parent puce ou nuémro
							var oParentElement = oRange.parentElement();
							if (oParentElement && (clWDUtil.bBaliseEstTag(oParentElement, "ul") || clWDUtil.bBaliseEstTag(oParentElement, "li")))
							{
								return true;
							}
						}
						oRange.pasteHTML("<br>");
						oRange.moveStart("character", 1);
						oRange.moveEnd("character", 2);
						oRange.select();
						oRange.collapse(false);
						oRange.scrollIntoView();

						// Bloque la propagation de l'evenement
						return clWDUtil.bStopPropagation(oEvent);
					}
					else
					{
						// La selection est un/des objets
						// Laisse IE faire seul car les objets controlRange ne permettent pas la manipulation simple
					}
				}
			}
			else if ((!bIE) && (bIE11Plus || bEdge) && this.m_bBaliseP)
			{
				// Recupere la selection
				var oRange = this.oGetRange();
				if (oRange)
				{
					// GP 20/11/2015 : QW265971 : Code pour IE11+/EDGE en HTML5
					// Le cas vu dans la fiche est un problème si on a <div><font xxx>Texte<br></br></font></div>
					// => Le <br></br> ne sert a rien
					// On détecte le cas d'une sélection "vide" et d'un br qui est seul ensuite
					var oStartContainer = oRange.startContainer;
					if (oStartContainer && (oStartContainer == oRange.endContainer))
					{
						var oNextSibling = oStartContainer.nextSibling;
						if (oNextSibling && clWDUtil.bBaliseEstTag(oNextSibling, "br") && (!oNextSibling.nextSibling))
						{
							oNextSibling.parentNode.removeChild(oNextSibling);
						}
					}
				}
			}
			else if (bFF && this.m_bBaliseP)
			{
				// GP 12/02/2015 : QW254368 : Cette correction semble fonctionner
				this.m_oDocument.execCommand("formatBlock", false, "p");
			}
			else if (bCrm && this.m_bBaliseP)
			{
				// Si on est au début du document, on force un p sur la première ligne
				var oChildNodes = this.m_oDocument.body.childNodes;
				if ((1 == oChildNodes.length) && (oChildNodes[0].nodeName == "#text"))
				{
					// GP 12/02/2015 : QW254440 : Cette correction semble fonctionner
					this.m_oDocument.execCommand("formatBlock", false, "p");
				}
			}
		}

		return true;
	};

	// Recupere les parametres pour RafEtat
	__WDSaisieRiche.prototype.oGetParamEtat = function (oEvent, bSimple)
	{
		// Si on est lie a un ZR vide, on n'a pas de selection
		if (this.bGestionTableZR() && !this.m_oDocument)
		{
			return [null, null, null];
		}
		var oDataEtat = [this.oGetRange(), null, null];
		// Sous IE on peut avoir un "controlRange"
		var oElement = null;
		if (bIE && !(oDataEtat[0]["duplicate"]))
		{
			oElement = oDataEtat[0].item(0);
			oDataEtat[0] = null;
		}

		if (bSimple == false)
		{
			oDataEtat[1] = oElement ? oElement : this.oGetSelection(oDataEtat[0]);
			oDataEtat[2] = oDataEtat[1] ? clWDUtil.oGetCurrentStyle(oDataEtat[1]) : null;
		}
		return oDataEtat;
	};

	// Récupère l'objet sélection
	__WDSaisieRiche.prototype.__oGetSelection = function __oGetSelection()
	{
		var oDocument = this.m_oDocument;
		// Si le champ n'est pas visible (cellule masque qui sera affiche par CelluleAfficheDialogue) : defaultView est null
		var oDefaultView = oDocument.defaultView;
		// GP 07/11/2015 : TB94777 : Bizarrement document.defaultView.getSelection n'existe pas dans EDGE mais document.getSelection qui normalement juste un alias existe :
		// - Garde le même ordre (document.defaultView.getSelection en premier)
		// - Ajout d'une utilisation de document.getSelection
		if (oDefaultView && oDefaultView.getSelection)
		{
			return oDefaultView.getSelection();
		}
		else if (oDocument.getSelection)
		{
			return oDocument.getSelection();
		}
		else
		{
			return undefined;
		}
	};

	// Recupere la selection
	__WDSaisieRiche.prototype.oGetRange = function ()
	{
		// Recupere la selection
		if (bIE)
		{
			// Recupere la selection
			return this.m_oDocument.selection.createRange();
		}
		else
		{
			// Si le champ n'est pas visible (cellule masque qui sera affiche par CelluleAfficheDialogue) : defaultView est null
			var oSelection = this.__oGetSelection();
			if (oSelection && oSelection.rangeCount)
			{
				return oSelection.getRangeAt(0);
			}
		}
		return null;
	};

	// Recupere une copie de la selection
	__WDSaisieRiche.prototype.oGetRangeCpy = function ()
	{
		var oRange = this.oGetRange();
		if (bIE)
		{
			return oRange.duplicate();
		}
		else
		{
			if (oRange)
			{
				oRange.cloneRange();
			}
		}
		return null;
	};

	// Recupere le noeud qui contient le debut de la selection
	__WDSaisieRiche.prototype.oGetSelection = function (oRange)
	{
		// Recupere la selection
		if (bIE)
		{
			// On veut l'element le plus bas qui contient le debut
			// Donc on va reduire la selection au debut et demander le parent contenant
			// Duplication pour ne pas la modifier
			oRange = oRange.duplicate();
			oRange.collapse(true);
			var oParent = oRange.parentElement();
			// Si le focus est vraiment sortit du champ de saisie, on peut avoir un element qui n'est pas dans l'IFrame mais le body de la frame hote
			return (oParent.document == this.m_oDocument) ? oParent : this.m_oData;
		}
		else
		{
			if (oRange)
			{
				return oRange.startContainer;
			}
		}

		return null;
	};

	// Optimise le contenu au niveau du DOM
	__WDSaisieRiche.prototype.OptimiseContenu = function ()
	{
		// Rien pour le moment
	};

	// Ecrase le contenu et marque les P originaux (IE)
	__WDSaisieRiche.prototype.__EcraseContenu = function __EcraseContenu(sValeur)
	{
		// Ecrase le contenu
		this.m_oData.innerHTML = sValeur;
//		// Marque les P originaux (IE)
//		if (bIE)
//		{
//			var tabP = this.m_oData.getElementsByTagName("p");
//			var i = 0;
//			var nLimiteI = tabP.length;
//			for (i = 0; i < nLimiteI; i++)
//			{
//				tabP[i].m_bOriginal = true;
//			}
//		}

		//post traitement

		if (window.$)
		{
			var jqChampSaisieMaterialDesign = $(this.m_oIFrame).closest(".wbLibChamp" + this.m_sAliasChamp);
			if (jqChampSaisieMaterialDesign.length)
			{
				jqChampSaisieMaterialDesign.trigger("trigger.wb.saisie.rwd.valeurinitDepuisConteneur");
			}
		}
	};

	// Sauvegarde du contenu. Indique si le contenu a changer
	__WDSaisieRiche.prototype.bSauveContenu = function bSauveContenu(oEvent)
	{
		var bChange = false;
		if (this.m_oValeur)
		{
			// Optimise le contenu du champ pour avoir un HTML compact
			this.OptimiseContenu();

			// Et recupere ce contenu HTML
			var sOldValue = this.m_oValeur.value;
			var sValue = this.m_oData.innerHTML;
			this.m_oValeur.value = sValue;
			bChange = (sOldValue != sValue);

			// Si on est dans une ZR AJAX, notifie la ZR de la modification de la valeur
			// Et si on ne change que la case du texte ?
			if (sOldValue.toUpperCase() != sValue.toUpperCase())
			{
				// Notifie la ZR
				this._OnChampModifie(oEvent, sValue);
			}
		}

		return bChange;
	};

	// Affectation externe du contenu du champ
	__WDSaisieRiche.prototype.SetValeur = function (oEvent, sValeur/*, oChamp*/)
	{
		// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
		WDBarre.prototype.SetValeur.apply(this, arguments);

		// Ecrase le contenu
		this.__EcraseContenu(sValeur);
		// Sauve ensuite le contenu
		this.bSauveContenu();

		// Bug de FF : il faut supprimer le mode d'edition et le remettre
		this.__ReactiveModeEditable();

		// Et le relit pour avoir la version reelle du navigateur
		return this.m_oValeur.value;
	};

	// Lecture externe du contenu du champ
	__WDSaisieRiche.prototype.GetValeur = function GetValeur(/*oEvent*//*, sValeur*//*, oChamp*/)
	{
		// sValeur est ignore car il contient une valeur obsolete
		// Sauve le contenu HTML dans le champ cache
		this.bSauveContenu();
		// Puis retourne cette valeur
		return this.m_oValeur.value;
	};

	// Lit les proprietes dont l'indication
	__WDSaisieRiche.prototype.GetProp = function GetProp(eProp/*, oEvent*//*, oValeur*//*, oChamp*/)
	{
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_TEXTESANSFORMAT:
			// On retourne la valeur interne sans formatage.
			return this.m_oData ? this.m_oData.innerText : "";
		default:
			// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
			return WDBarre.prototype.GetProp.apply(this, arguments);
		}
	};

	// Ecrit les proprietes dont la couleur et la couleur de fond
	__WDSaisieRiche.prototype.SetProp = function SetProp(eProp, oEvent, oValeur/*, oChamp*//*, oXMLAction*/)
	{
		// Implementation de la classe de base
		oValeur = WDBarre.prototype.SetProp.apply(this, arguments);

		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_COULEUR:
			// this.m_oDocument.body == this.m_oData non ?
			this.m_oDocument.body.style.color = oValeur;
			return oValeur;
		case this.XML_CHAMP_PROP_NUM_COULEURFOND:
			// this.m_oDocument.body == this.m_oData non ?
			this.m_oDocument.body.style.backgroundColor = oValeur;
			return oValeur;
		case this.XML_CHAMP_PROP_NUM_ETAT:
			// On a deja modifie la valeur par le champ cache
			// On force juste un reaffichage
			this.__InitSpecifique(false);
			return oValeur;
		default:
			return oValeur;
		}
	};


	// En cas de Submit : sauve le contenu
	__WDSaisieRiche.prototype.OnSubmit = function (oEvent)
	{
		// Appel de la methode de la classe de base
		WDBarre.prototype.OnSubmit.apply(this, arguments);

		// GP 24/02/2015 : TB91122 : la sauvegarde du contenu ici empeche l'exécution du code de onchange dans le raf
		this.__SauveContenuAvecOnChange(oEvent);
	};

	// Donne le focus au champ (pour reprisesaisie et la validation de champ obligatoire
	__WDSaisieRiche.prototype.SetFocus = function ()
	{
		// Pour les navigateur autre que IE il faut d'abord donner le focus a l'IFrame
		if (!bIEAvec11)
		{
			this.m_oIFrame.contentWindow.focus();
		}
		this.m_oData.focus();

		this.RafBarre(null);
	};

	// Gestion des commandes

	__WDSaisieRiche.prototype.AjouteEmoji = function (oDataCommande)
	{
		var sel = this.m_oIFrame.contentWindow.getSelection();
		var range = sel.getRangeAt(0);
		//pour ajouter après la sélection
		//range.setStartAfter( range.endContainer );?
		//pour remplacer la sélection
		range.deleteContents();
		range.insertNode( $("<span>" + oDataCommande[2] + "</span>")[0] );
		//avoir le focus (caret en saisie) après ajout d'emoji
		//Debug on dirait qu'on perd le focus car la sélection disparaît
		range.collapse();

//non car cela ne tient pas compte de la taille du texte où est inséré l'emoji
		//this.m_oDocument.execCommand("insertHTML", oDataCommande[1], oDataCommande[2]);
	};

	// Execute une commande
	__WDSaisieRiche.prototype.ExecuteCommande = function (oEvent, oDataCommande)
	{
		// Donne le focus au document
		this.SetFocus();


		if (oDataCommande[0] == "wbEmoji")
		{
			//commande webdev
			this.AjouteEmoji(oDataCommande);
		}
		// Execute la commande native
		else
		{
			if (oDataCommande[0] === 'FormatBlock' && typeof oDataCommande[2] === 'string')
			{
				oDataCommande[2] = oDataCommande[2].replace('&lt;','<').replace('&gt;','>');
			}
			this.m_oDocument.execCommand(oDataCommande[0], oDataCommande[1], oDataCommande[2]);
		}

//		// Remplace les font + size si besoin
//		var bAvecFontSize;
//		do
//		{
//			bAvecFontSize = false;
//			var tabBalisesFont = this.m_oDocument.getElementsByTagName("font");
//			bAvecFontSize = !clWDUtil.bForEachThis(this.m_oDocument.getElementsByTagName("font"), this, function(oBalise)
//			{
//				// Si la balise a l'attribut font
//				if (clWDUtil.bHasAttribute(oBalise, "size"))
//				{
//					var sTaille;
//					switch (oBalise.getAttribute("size"))
//					{
//					default:
//					case "1":
//						sTaille = "0.63em";
//						break;
//					case "2":
//						sTaille = "0.82em";
//						break;
//					case "3":
//						sTaille = "1.0em";
//						break;
//					case "4":
//						sTaille = "1.13em";
//						break;
//					case "5":
//						sTaille = "1.5em";
//						break;
//					case "6":
//						sTaille = "2em";
//						break;
//					case "7":
//						sTaille = "3em";
//						break;
//					}
//					var oSpan = this.m_oDocument.createElement("span");
//					oSpan.style.fontSize = sTaille;
//					while (oBalise.childNodes.length > 0)
//					{
//						oSpan.appendChild(oBalise.childNodes[0]);
//					}
//					oBalise.parentNode.replaceChild(oSpan, oBalise);
//
//					// Arret de la boucle (une des balises du tableau est peut-être un fils "déplacé" et la référence est peut-être devenue invalide)
//					// Le "bAvecFontSize = !" fait que l'on relance un calcul
//					return false;
//				}
//				return true;
//			});
//
//		}
//		while (bAvecFontSize);

		// Donne le focus au document
		this.SetFocus();

		// Rafrachit les boutons
		this.RafBarre(oEvent, true);

	};

	// Insere un lien
	__WDSaisieRiche.prototype.OnLink = function (oEvent)
	{
		// GP 20/02/2018 : TB100018 : La norme est très claire : Pour CreateLink il faut une sélection.
		// Chrome fait sans mais il faut le faire pour les autres navigateurs.
		// (Voir https://developer.mozilla.org/en-US/docs/Web/API/document/execCommand)
		this.__OnPrompt(oEvent, "CreateLink", HTML_TOOLBAR.DLG.LNK || "URL ?", "http://", false, true);
	};

	// Insere une image
	__WDSaisieRiche.prototype.OnImage = function (oEvent)
	{
		// Si une image est selectionnee : on prend son URL
		var oRange = this.oGetRange();
		var sDefaut = undefined;
		// Sous IE on peut avoir un "controlRange"
		if (bIE && !oRange["duplicate"] && oRange.item(0) && oRange.item(0).src)
		{
			sDefaut = oRange.item(0).src;
		}

		if (!this.bRelookUL())
		{
			this.__OnPrompt(oEvent, "InsertImage", HTML_TOOLBAR.DLG.IMG || "Image ?", sDefaut||"http://", true, false);
			return;
		}

		var changeImage = function(sNouvelleValeur)
		{
			if (!sNouvelleValeur || sNouvelleValeur === sDefaut)
			{
				return;
			}

			if (oRange && oRange.item && oRange.item(0).src)
			{
				// oRange.item(0).setAttribute('crossOrigin', 'anonymous');
				oRange.item(0).src = sNouvelleValeur;
			}
			else
			{
				var domImg = document.createElement("img");
				// domImg.setAttribute('crossOrigin', 'anonymous');
				domImg.src = sNouvelleValeur; 
				if (this.bRelookUL())
				{
					domImg.style.margin = "24px";
				}

				if (oRange)
				{
					//pour ajouter après la sélection
					//range.setStartAfter( range.endContainer );?
					//pour remplacer la sélection
					oRange.deleteContents();
					oRange.insertNode(domImg);
					//avoir le focus (caret en saisie) après ajout
					//Debug on dirait qu'on perd le focus car la sélection disparaît
					oRange.collapse();
				}
				else 
				{
					var sel = this.m_oIFrame.contentWindow.getSelection();
					if (!sel.anchorNode) 
					{
						this.m_oIFrame.contentWindow.document.body.appendChild(domImg);
					}
					else 
					{
						var range = sel.getRangeAt(0);
						range.deleteContents();
						range.insertNode(domImg);		

					}
				}
			}
		}.bind(this);		

		//stop la propagation de l'event pour que la barre ne se réaffiche pas suite au clic sur le boutojn img de la barre
		oEvent.stopPropagation();
		this.m_oSaisieAPI.ExecuteEditeurImage(function(){
		    var domRoot = window.wbEditeurImageSelectImage({
				onOK: function(dataURI)
				{
					// appelé en validation de l'éditeur d'image 
					// dataURI est undefined en cas d'annulation
					if (dataURI)
					{
					changeImage(dataURI);
					}
				}
			,	onComponentDidMount : function() {
					//donne le focus 
					$(domRoot).hide().fadeIn().focus();
				}
			});	
			//ferme la barre
			this.m_oDocument.documentElement.wdSaisieRiche.RafBarre(undefined,false);		
		}, function(){
			changeImage( prompt(HTML_TOOLBAR.DLG.IMG || "Image ?", sDefaut||"http://") );
		});
	};

	// Insertion generique
	__WDSaisieRiche.prototype.__OnPrompt = function (oEvent, sCommande, sTexte, sDefaut, bForcePrompt, bForceSelection)
	{
		// IE
		if (bIE && !bForcePrompt)
		{
			// Demande l'affichage de l'interface
			this.ExecuteCommande(oEvent, [sCommande, true, ""]);
		}
		else
		{
			var sVal = prompt(sTexte, sDefaut);
			if (sVal && (sVal != sDefaut))
			{
				// Désactivé avec IE (la manipulation des range et de la sélection ne fonctionne pas forcément)
				if (bForceSelection && !bIEAvec11)
				{
					var oRange = this.oGetRange();
					if (oRange.collapsed)
					{
						// Insère le texte
						var sel = this.m_oIFrame.contentWindow.getSelection();
						var range = sel.getRangeAt(0);
						//pour remplacer la sélection par le prochain ExecuteCommande
						range.deleteContents();
						var s = document.createElement("span");
						s.innerText = sVal;
						range.insertNode(s);
//QW#320090	Champ HTML : insérer un lien sans texte sélectionné au préalable insère l'URL saisie sans définir le lien	SDJ	Evolution test automatique	19/11/2019
//Uncaught DOMException: Failed to execute 'setEnd' on 'Range': There is no child at offset 14
						//this.ExecuteCommande(oEvent, ["insertText", false, sVal]);
						//var oNewRange = oRange.cloneRange();
						//oNewRange.setEnd(oRange.startContainer, oRange.startOffset + sVal.length);
						//var oSelection = this.__oGetSelection();
						//oSelection.removeAllRanges();
						//oSelection.addRange(oNewRange);
					}
				}

				this.ExecuteCommande(oEvent, [sCommande, false, sVal]);
			}
		}
	};


	// Recupere le texte alternatif d'un bouton
	__WDSaisieRiche.prototype.sGetAltText = function (sSuffixe)
	{
		return HTML_TOOLBAR.ALTTEXT[sSuffixe];
	};

	// Place l'indication si besoin (Init ou apres un submit AJAX)
	// Declare uniquement pour le cas ou le champ est en 'dynamique' auquel cas la generation HTML fait un appel
	__WDSaisieRiche.prototype.RAZIndication = clWDUtil.m_pfVide;

	return __WDSaisieRiche;
})();
