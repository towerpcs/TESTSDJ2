// WDStd.js
/*! 26.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */
// !!!! Ne pas mettre d'espace dans les intructions ci dessus. Tous les commentaires sans espaces au début du fichier sont conservées par Typescript !!!!
///#DEBUG=clWDUtil.WDDebug
///#GLOBALS clWDTableau WDSTD_CONST WDErreur NSPCS _NA_
// Attention a ne pas mettre d'accent dans le code, chaines incluses
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
;
var clWDStd = {
    CO_FIN: 1,
    CO_MOT: 2,
    CO_CAS: 4,
    RG_PRM: -0x80000000,
    RG_SUI: -0x7fffffff,
    RG_DER: -0x7ffffffd,
    RG_PRC: -0x7ffffffe,
    wifiErreur: -1,
    wifiActif: 1,
    wifiDesactive: 4,
    m_fWifiCallback: null,
    //Formats TailleVersChaine
    tailleO: 1,
    tailleKo: 2,
    tailleMo: 3,
    tailleGo: 4,
    tailleTo: 5,
    __nChaineCompare: function (sChaine1, sChaine2, nOption) {
        function __nCompare(oValeur1, oValeur2) {
            if (oValeur1 === oValeur2) {
                return 0;
            }
            else if (oValeur1 < oValeur2) {
                return -1;
            }
            else {
                return 1;
            }
        }
        function __sExtraitNombre(sChaine, nPositionDebut) {
            while ((nPositionDebut < sChaine.length) && (sChaine.charAt(nPositionDebut) == "0")) {
                nPositionDebut++;
            }
            var nPositionFin = nPositionDebut;
            while ((nPositionFin < sChaine.length) && EstChiffre(sChaine.charAt(nPositionFin))) {
                nPositionFin++;
            }
            return sChaine.substring(nPositionDebut, nPositionFin);
        }
        if (0 === (nOption & (8 /* OrdreLexicographique */ | 128 /* RespecteNumerique */))) {
            return __nCompare(sChaine1, sChaine2);
        }
        var nLongueur1 = sChaine1.length;
        var nLongueur2 = sChaine2.length;
        var nResultatCompare;
        for (var nPosition = 0; (nPosition < nLongueur1) && (nPosition < nLongueur2); nPosition++) {
            if (nOption & 128 /* RespecteNumerique */) {
                var sNombre1 = __sExtraitNombre(sChaine1, nPosition);
                var sNombre2 = __sExtraitNombre(sChaine2, nPosition);
                if ((sNombre1 != "") && (sNombre2 != "")) {
                    nResultatCompare = __nCompare(parseInt(sNombre1), parseInt(sNombre2));
                    if (0 != nResultatCompare) {
                        return nResultatCompare;
                    }
                }
            }
            var sCaractere1 = sChaine1.charAt(nPosition);
            var sCaractere2 = sChaine2.charAt(nPosition);
            if (nOption & 8 /* OrdreLexicographique */) {
                nResultatCompare = __nCompare(CarSansAccent(sCaractere1), CarSansAccent(sCaractere2));
                if (0 != nResultatCompare) {
                    return nResultatCompare;
                }
            }
            nResultatCompare = __nCompare(sCaractere1, sCaractere2);
            if (0 != nResultatCompare) {
                return nResultatCompare;
            }
        }
        return __nCompare(nLongueur1, nLongueur2);
    },
    __bEstEspace: function (c) {
        return null != c.match(/\s/);
    },
    __bEstPonctuationOuEspace: function (c) {
        return EstPonctuation(c) || this.__bEstEspace(c);
    }
};
clWDStd.m_nWifiEtat = clWDStd.wifiErreur;
function EstChiffre(c) {
    return (c >= "0") && (c <= "9");
}
function ChaineConstruit(f) {
    // GP 17/03/2017 : QW284870 : Force la conversion en chaine par sécurité (+ utile pour le framework V2)
    f = String(f);
    var p = 0;
    while ((p = f.indexOf("%", p)) >= 0) {
        var d = p + 1;
        var i = d;
        var b = (f.charAt(i) == "%");
        if (b) {
            i++;
        }
        else {
            while ((i < f.length) && EstChiffre(f.charAt(i))) {
                i++;
            }
            // Pour le cas de "[%v%]0", la compilation ajoute un caractère 8 => le supprime.
            if (f.charAt(i) == String.fromCharCode(8)) {
                i++;
            }
        }
        if (i > d) {
            var n = parseInt(f.substring(d, i));
            // GP 23/06/2017 : TB104007 : Force le paramètre en chaine (sinon r.length échoue)
            var r = ((n > 0) && (n < arguments.length)) ? String(arguments[n]) : (b ? "%" : "");
            f = f.substring(0, p) + r + f.substring(i, f.length);
            p += r.length;
        }
        else {
            p++;
        }
    }
    return f;
}
function CarSansAccent(c) {
    if ((c == "\x9f") || (c == "\xdd")) {
        return "Y";
    }
    if ((c > "\xbf") && (c < "\xc6")) {
        return "A";
    }
    if (c == "\xc7") {
        return "C";
    }
    if ((c > "\xc7") && (c < "\xcc")) {
        return "E";
    }
    if ((c > "\xcb") && (c < "\xd0")) {
        return "I";
    }
    if (c == "\xd0") {
        return "D";
    }
    if (c == "\xd1") {
        return "N";
    }
    if (((c > "\xd1") && (c < "\xd7")) || (c == "\xd8")) {
        return "O";
    }
    if ((c > "\xd8") && (c < "\xdd")) {
        return "U";
    }
    if ((c > "\xdf") && (c < "\xe6")) {
        return "a";
    }
    if (c == "\xe7") {
        return "c";
    }
    if ((c > "\xe7") && (c < "\xec")) {
        return "e";
    }
    if ((c > "\xeb") && (c < "\xf0")) {
        return "i";
    }
    if (c == "\xf1") {
        return "n";
    }
    if (((c > "\xf1") && (c < "\xf7")) || (c == "\xf8")) {
        return "o";
    }
    if ((c > "\xf8") && (c < "\xfd")) {
        return "u";
    }
    if ((c == "\xfd") || (c == "\xff")) {
        return "y";
    }
    return c;
}
function EstPonctuation(c) {
    return (c < "\t") || ((c > "\r") && (c < " ")) || ((c > " ") && (c < "0")) || ((c > "9") && (c < "A")) || ((c > "Z") && (c < "a")) || ((c > "z") && (c < "\x83")) || ((c > "\x83") && (c < "\x8c")) || (c == "\x8d") || ((c > "\x8e") && (c < "\x99")) || (c == "\x9b") || (c == "\x9d") || ((c > "\x9f") && (c < "\xaa")) || ((c > "\xaa") && (c < "\xb2")) || ((c > "\xb3") && (c < "\xb9")) || (c == "\xbb") || (c == "\xbf") || (c == "\xd7") || (c == "\xf7");
}
function ChaineFormate(oChaine, o) {
    var sChaine = String(oChaine);
    if (o & (1 /* SansEspace */ | 2 /* SansPonctuationNiEspace */)) {
        sChaine = clWDUtil.sSupprimeEspacesDebutFin(sChaine, false, false);
    }
    if (o & (256 /* SansEspaceInterieur */ | 2 /* SansPonctuationNiEspace */)) {
        sChaine = clWDUtil.sSupprimeEspacesInterieur(sChaine);
    }
    if (o & (16 /* SansCasse */ | 32 /* Majuscule */)) {
        sChaine = sChaine.toUpperCase();
    }
    if (o & 64 /* Minuscule */) {
        sChaine = sChaine.toLowerCase();
    }
    if (o & 2 /* SansPonctuationNiEspace */) {
        // On à déjà supprimer les espaces, reste à supprimer la ponctuation.
        sChaine = sChaine.replace(/./g, function (sCaractere) {
            return EstPonctuation(sCaractere) ? "" : sCaractere;
        });
    }
    if (o & 4 /* SansAccent */) {
        sChaine = sChaine.replace(/./g, CarSansAccent);
    }
    return sChaine;
}
function SansAccent(s) {
    return ChaineFormate(s, 4 /* SansAccent */);
}
function ChaineCompare(oChaine1, oChaine2, nOption) {
    var sChaine1 = ChaineFormate(oChaine1, nOption);
    var sChaine2 = ChaineFormate(oChaine2, nOption);
    return clWDStd.__nChaineCompare(sChaine1, sChaine2, nOption);
}
//Paramètre position
var CWDStdParamPosition = /** @class */ (function () {
    //Constructeur
    function CWDStdParamPosition(bStrict) {
        if (bStrict === void 0) { bStrict = false; }
        this.m_bStrict = bStrict;
        this.m_nTailleChaineTrouve = 0;
    }
    return CWDStdParamPosition;
}());
function Position(s, r, i, o, clParametre) {
    function __sMajusculeSansAccent(s) {
        return ChaineFormate(s, 4 /* SansAccent */ | 32 /* Majuscule */);
    }
    if ((i == null) || (i < 0)) {
        i = 1;
    }
    var f = o & clWDStd.CO_FIN;
    //Indique si la recherche depuis la fin est stricte (la chaîne trouvée ne doit pas finir après la position de départ de recherche depuis la fin)
    var bStrict = (f && clParametre) ? clParametre.m_bStrict : false;
    //Taille de la chaîne dans laquelle on recherche
    var nTailleChaine = s.length;
    if (i == 0) {
        //Recherche depuis la fin ? oui => on part de la fin de la chaîne; non => on part du début de la chaîne
        i = f ? nTailleChaine : 1;
    }
    if (i > s.length) {
        return 0;
    }
    var t = new Array();
    if (typeof (r) != typeof (t)) {
        t[0] = r;
    }
    else {
        t = r;
    }
    var x;
    if (o & clWDStd.CO_CAS) {
        s = __sMajusculeSansAccent(s);
        for (x = 0; x < t.length; x++) {
            t[x] = __sMajusculeSansAccent(t[x]);
        }
    }
    var b = -1;
    var c = false;
    //Taille de la chaîne trouvée
    var nTailleChaineTrouve = 0;
    //Position de début de la recherche
    var PositionDebutRecherche = i;
    for (x = 0; x < t.length; x++) {
        r = t[x];
        if (r != "") {
            //Taille de la chaîne recherchée
            var nTailleChaineRecherche = r.length;
            //La chaîne trouvée ne doit pas finir après la position de départ de recherche depuis la fin ?
            if (bStrict) {
                //Oui => on part de la position la plus grande où on peut trouver la chaîne depuis la fin sans qu'elle ne dépasse de la position de départ de recherche
                i = PositionDebutRecherche - (nTailleChaineRecherche - 1);
            }
            //Possible de trouver la chaîne recherchée
            if (i > 0) {
                //Oui => on fait la recherche
                var p = i - 1;
                var d = p;
                while ((d = f ? s.lastIndexOf(r, p) : s.indexOf(r, p)) > -1) {
                    //Position après chaîne trouvée
                    var e = d + nTailleChaineRecherche;
                    p = f ? (d - 1) : e;
                    if ((!(o & clWDStd.CO_MOT)) || (((d == 0) || clWDStd.__bEstPonctuationOuEspace(s.charAt(d - 1))) && ((e == s.length) || clWDStd.__bEstPonctuationOuEspace(s.charAt(e))))) {
                        c = true;
                        if (f ? (d > b) : ((d > -1) && ((b < 0) || (d < b)))) {
                            b = d;
                            //On mémorise la taille de la chaîne trouvée
                            nTailleChaineTrouve = nTailleChaineRecherche;
                        }
                        break;
                    }
                }
            }
        }
    }
    //Chaîne trouvée et paramètre position fourni ?
    if (c && clParametre) {
        //Oui => mémorisation taille chaîne trouvée dans paramètre position
        clParametre.m_nTailleChaineTrouve = nTailleChaineTrouve;
    }
    return c ? (b + 1) : 0;
}
//Indique si une chaîne en contient une autre
//Entrée :	sChaine		Chaîne analysée
//			sRecherche	Chaîne ou tableau de chaînes recherchée(s)
//			nOption		Options de recherche : combinaisons de flags : mot complet (CO_MOT), sans casse (CO_CAS)
//Sortie :	true si chaînes(s) trouvée(s) dans chaîne à analyser, false sinon
clWDStd.Contient = function Contient(sChaine, sRecherche, nOption) {
    //Chaîne(s) recherchée(s) trouvée(s) si position valide dans chaîne analysée
    return Position(sChaine, sRecherche, 0, nOption) > 0;
};
var gp;
function PositionOccurrence(s, r, i, o) {
    if (i == null) {
        i = 1;
    }
    if ((i < 1) && (i > clWDStd.RG_DER)) {
        return 0;
    }
    var f = o & clWDStd.CO_FIN;
    if ((i == clWDStd.RG_DER) || (i == clWDStd.RG_PRC)) {
        f = !f;
    }
    if (f) {
        o |= clWDStd.CO_FIN;
    }
    if ((i != clWDStd.RG_SUI) && (i != clWDStd.RG_PRC)) {
        gp = f ? (s.length) : 1;
    }
    if (f && (gp == 0)) {
        return 0;
    }
    if (i <= clWDStd.RG_DER) {
        i = 1;
    }
    var n = 0;
    var p = gp;
    while ((n < i) && ((p = Position(s, r, gp, o)) > 0)) {
        gp = p + (f ? -1 : ((typeof (r) == typeof ("")) ? r.length : 1));
        n++;
    }
    return (n < i) ? 0 : p;
}
function ChaineOccurrence(s, r, o) {
    var n = 0;
    var p = PositionOccurrence(s, r, clWDStd.RG_PRM, o);
    while (p > 0) {
        n++;
        p = PositionOccurrence(s, r, clWDStd.RG_SUI, o);
    }
    return n;
}
//Comparaison de chaines sans casse
//Entrée :	szChaine1	Première chaîne de comparaison
//			szChaine2	Deuxième chaîne de comparaison
//Sortie :	true si les chaînes sont égales à la casse près, false sinon
function bCompareChaineSansCasse(szChaine1, szChaine2) {
    //Comparaison sans casse
    return szChaine1.toLowerCase() == szChaine2.toLowerCase();
}
(function () {
    function __nChaineCommenceFinitPar(oChaine1, oChaine2, nOption, pfExtraction) {
        function __nCommenceFinitPar(oChaine2) {
            var nLongueurChaine2 = String(oChaine2).length;
            var sChaine1Brute = String(oChaine1);
            var sChaine2 = ChaineFormate(oChaine2, nOption);
            // GP 18/11/2019 : QW319636 : Algo de WDxxxVm : Travaille sur la longeur pour avoir la longueur exacte
            for (var nLongueurCompare = nLongueurChaine2, nLongueurChaine1 = sChaine1Brute.length; nLongueurCompare <= nLongueurChaine1; nLongueurCompare++) {
                var sChaine1BruteExtraction = pfExtraction(sChaine1Brute, nLongueurChaine1, nLongueurCompare);
                if (0 == clWDStd.__nChaineCompare(ChaineFormate(sChaine1BruteExtraction, nOption), sChaine2, nOption)) {
                    return nLongueurCompare;
                }
                if (0 === nOption) {
                    break;
                }
            }
            // La chaîne ne correspond pas.
            return 0;
        }
        // Syntaxe qui prend un tableau pour les chaines à tester
        if (clWDTableau.__bEstTableau(oChaine2)) {
            // GP 18/11/2019 : Vu avec QW319636 : L'implémentation dans WDxxxVM retourne le plus long match et pas uniquement un match
            var nTailleMatch_1 = 0;
            oChaine2.forEach(function (oChaineCourante) {
                var nCommencePar = __nCommenceFinitPar(oChaineCourante);
                if (nTailleMatch_1 < nCommencePar) {
                    nTailleMatch_1 = nCommencePar;
                }
            });
            return nTailleMatch_1;
        }
        else {
            return __nCommenceFinitPar(oChaine2);
        }
    }
    clWDStd.ChaineCommencePar = function ChaineCommencePar(oChaine1, oChaine2, nOption) {
        if (nOption === void 0) { nOption = 0; }
        return __nChaineCommenceFinitPar(oChaine1, oChaine2, nOption, function (sChaine, nLongueurChaine, nLongueurAttendue) { return sChaine.substr(0, nLongueurAttendue); });
    };
    clWDStd.ChaineFinitPar = function ChaineCommencePar(oChaine1, oChaine2, nOption) {
        if (nOption === void 0) { nOption = 0; }
        return __nChaineCommenceFinitPar(oChaine1, oChaine2, nOption, function (sChaine, nLongueurChaine, nLongueurAttendue) { return sChaine.substr(nLongueurChaine - nLongueurAttendue, nLongueurAttendue); });
    };
})();
clWDStd.ChaineDecoupe = function ChaineDecoupe(oChaineSrc) {
    var tabArguments = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        tabArguments[_i - 1] = arguments[_i];
    }
    var nOptions = 0;
    var tabSeparateurs = tabArguments;
    if (0 === tabSeparateurs.length) {
        // GP 15/11/2019 : QW319639 : Accepte l'appel sans paramètres.
        tabSeparateurs = ["\t"];
    }
    else {
        if (1 < tabArguments.length) {
            // Si au moins 3 arguments
            var oOptions = tabArguments[tabArguments.length - 1];
            if (typeof oOptions === "number") {
                nOptions = oOptions;
                // Supprime le dernier séparateur (qui correspond aux options)
                // Attention tabSeparateurs est un alias de tabArguments donc modifie aussi tabArguments.
                tabSeparateurs.length--;
            }
        }
        // Si le séparateur est un tableau de séparateur.
        // A faire après l'extraction des options, sinon on perd les options.
        if (clWDTableau.__bEstTableau(tabSeparateurs[0])) {
            tabSeparateurs = tabSeparateurs[0];
        }
    }
    var sChaineSrc = String(oChaineSrc);
    var tabResultat;
    if (1 === tabSeparateurs.length) {
        // Un seul séparateur : on découpe toute la chaine
        tabResultat = sChaineSrc.split(String(tabSeparateurs[0]));
    }
    else {
        // Plusieurs séparateurs : on découpe la chaine par bout pour chaque séparateur
        tabResultat = tabSeparateurs.map(function (oSeparateur) {
            var sSeparateur = String(oSeparateur);
            var tabSplit = sChaineSrc.split(sSeparateur);
            var sSousElement = tabSplit[0];
            sChaineSrc = sChaineSrc.substr(sSousElement.length + sSeparateur.length);
            return sSousElement;
        });
        if (sChaineSrc.length) {
            tabResultat.push(sChaineSrc);
        }
    }
    // GP 15/11/2019 : QW319640 : Le formatage de la chaîne est en sortie.
    return tabResultat.map(function (sResultat) {
        return ChaineFormate(sResultat, nOptions);
    });
};
clWDStd.ChaineInsere = function ChaineInsere(oChaineOrigine, oChaineAInserer, oPositionWL) {
    var sChaineOrigine = String(oChaineOrigine);
    var sChaineInsertion = String(oChaineAInserer);
    // -1 : WL -> 0 based index
    var nPositionC = parseInt(oPositionWL, 10) - 1;
    if (nPositionC < 0) {
        nPositionC = 0;
    }
    return sChaineOrigine.substr(0, nPositionC) + sChaineInsertion + sChaineOrigine.substr(nPositionC);
};
function VerifieExpressionReguliere(s, f) {
    var e = new RegExp(f);
    var r = e.exec(s);
    var t = new Array();
    if ((t[0] = (r != null) && (r.index == 0) && (r[0].length == s.length)) == true) {
        for (var i = 1; i < arguments.length - 1; i++) {
            t[i] = (i < r.length) ? r[i] : "";
        }
    }
    return t;
}
function EstNumerique(v) {
    return (!isNaN(v)) || (!isNaN(parseFloat(v)));
}
function NavigateurEstConnecte() {
    return navigator.onLine;
}
//Constructeur touche
//Entrée :	sToucheMinuscule			Touche sans majuscule enfoncée
//			sToucheMajuscule			Touche avec majuscule enfoncée
//			bIgnoreMajusculeEnfoncee	Indique si on peut ignorer que la touche majuscule soit enfoncée pour tenir compte de la touche quand on veut la touche sans majuscule enfoncée
//			bIgnoreMinuscule			Indique si on ignore la touche quand on veut la touche sans majuscule enfoncée
//			bIgnoreMajuscule			Indique si on ignore la touche quand on veut la touche avec majuscule enfoncée
clWDStd.CTouche = function CTouche(sToucheMinuscule, sToucheMajuscule, bIgnoreMajusculeEnfoncee, bIgnoreMinuscule, bIgnoreMajuscule) {
    this.m_sToucheMinuscule = sToucheMinuscule;
    this.m_sToucheMajuscule = sToucheMajuscule;
    this.m_bIgnoreMajusculeEnfoncee = bIgnoreMajusculeEnfoncee;
    this.m_bIgnoreMinuscule = bIgnoreMinuscule;
    this.m_bIgnoreMajuscule = bIgnoreMajuscule;
};
//Tableau des touches à traîtement spécifique
clWDStd.gclTabTouche =
    [
        new clWDStd.CTouche("&", "1"),
        //"é"
        new clWDStd.CTouche("\x82", "2"),
        new clWDStd.CTouche("\"", "3"),
        new clWDStd.CTouche("'", "4"),
        new clWDStd.CTouche("(", "5"),
        new clWDStd.CTouche("-", "6", false, false, true),
        //"è"
        new clWDStd.CTouche("\x8a", "7"),
        new clWDStd.CTouche("_", "8"),
        //"ç"
        new clWDStd.CTouche("\x87", "9"),
        //"à"
        new clWDStd.CTouche("\xe0", "0"),
        //"°"
        new clWDStd.CTouche(")", "\xb0", true),
        new clWDStd.CTouche("=", "+", true, true),
        //"¨"
        new clWDStd.CTouche("^", "\xa8", true),
        //"£"
        new clWDStd.CTouche("$", "\xa3", true),
        //"ù"
        new clWDStd.CTouche("\xf9", "%", true),
        //"µ"
        new clWDStd.CTouche("*", "\xb5", true, false, true),
        //Cas particulier pour le caractère "µ" obtenu par (maj + *) car FireFox donne "M" comme majuscule, ce qui fausse le résultat
        new clWDStd.CTouche("\xb5", "\xb5"),
        new clWDStd.CTouche(",", "?", true),
        new clWDStd.CTouche(";", "."),
        new clWDStd.CTouche(":", "/", true, true),
        //"§"
        new clWDStd.CTouche("!", "\xa7", true)
    ];
//Indique si une touche est la touche sans majuscule enfoncée recherchée
//Entrée :	clTouche	Touche dont on veut savoir si c'est la touche sans majuscule enfoncée recherchée
//			sTouche		Touche sans majuscule enfoncée recherchée
//Sortie :	true si la touche est celle sans majuscule enfoncée recherchée, false sinon
clWDStd.__bEstToucheMinuscule = function __bEstToucheMinuscule(clTouche, sTouche) {
    //On regarde si la touche est celle sans majuscule enfoncée recherchée
    return (sTouche == clTouche.m_sToucheMinuscule);
};
//Donne la touche avec majuscule enfoncée d'une touche
//Entrée :	sTouche		Touche dont on veut la touche avec majuscule enfoncée
//Sortie :	Touche avec majuscule enfoncée de la touche en entrée
clWDStd.__sToucheAvecMajuscule = function __sToucheAvecMajuscule(sTouche) {
    //Recherche de la touche
    var clTouche = clWDUtil.oDansTableauFct(this.gclTabTouche, this.__bEstToucheMinuscule, sTouche, { m_bIgnoreMajuscule: true });
    //Touche à traîter ?
    if (clTouche.m_bIgnoreMajuscule) {
        //Non => majuscule de la touche
        return sTouche.toUpperCase();
    }
    //Oui => Touche avec majuscule enfoncée
    return clTouche.m_sToucheMajuscule;
};
//Indique si une touche est la touche avec majuscule enfoncée recherchée
//Entrée :	clTouche	Touche dont on veut savoir si c'est la touche avec majuscule enfoncée recherchée
//			sTouche		Touche avec majuscule enfoncée recherchée
//Sortie :	true si la touche est celle avec majuscule enfoncée recherchée, false sinon
clWDStd.__bEstToucheMajuscule = function __bEstToucheMajuscule(clTouche, sTouche) {
    //On regarde si la touche est celle avec majuscule enfoncée recherchée
    return (sTouche == clTouche.m_sToucheMajuscule);
};
//Donne la touche sans majuscule enfoncée d'une touche
//Entrée :	sTouche		Touche dont on veut la touche sans majuscule enfoncée
//			bMajuscule	Indique si touche majuscule enfoncé
//Sortie :	Touche sans majuscule enfoncée de la touche en entrée
clWDStd.__sToucheSansMajuscule = function __sToucheSansMajuscule(sTouche, bMajuscule) {
    //Recherche de la touche
    var clTouche = clWDUtil.oDansTableauFct(this.gclTabTouche, this.__bEstToucheMajuscule, sTouche, { m_bIgnoreMinuscule: true });
    //Touche à traîter ?
    if ((!clTouche.m_bIgnoreMinuscule) && (bMajuscule || clTouche.m_bIgnoreMajusculeEnfoncee)) {
        //Oui => touche majuscule enfoncée ou touche ne tenant pas compte de l'état de la touche majuscule ? oui => touche minuscule
        return clTouche.m_sToucheMinuscule;
    }
    //Minuscule de la touche
    return sTouche.toLowerCase();
};
//Indique si touche CapsLock enfoncée
clWDStd.CapsLockVerifie = function CapsLockVerifie(stEvenement) {
    //Code touche tapée
    var nCodeTouche = stEvenement.which ? stEvenement.which : stEvenement.keyCode;
    //Touche tapée
    var sTouche = String.fromCharCode(nCodeTouche);
    //Touche avec majuscule enfoncée
    var sToucheMajuscule = this.__sToucheAvecMajuscule(sTouche);
    //Indique si touche majuscule enfoncée
    var bMajuscule = stEvenement.shiftKey ? stEvenement.shiftKey : (nCodeTouche == 16);
    //La touche CapsLock est enfoncée si lettre majuscule et touche majuscule non enfoncée ou si lettre minuscule et touche majuscule enfoncée (et si touche majuscule différente de touche minuscule)
    return ((sTouche == sToucheMajuscule) != bMajuscule) && (sToucheMajuscule != this.__sToucheSansMajuscule(sTouche, bMajuscule));
};
//Affiche une notification
clWDStd.NotificationAffiche = function NotificationAffiche(sTitre, sMessage, sImage) {
    //Gestionnaire de notifications
    var clNotification = window.Notification;
    //Notifications supportées ?
    if (clNotification == null) {
        //Non => on essaie les notifications WebKit
        clNotification = window.webkitNotifications;
    }
    //Notifications supportées ?
    if (clNotification == null) {
        //Non => échec
        return;
    }
    //Indique si notifications autorisées
    var bDroitNotif = false;
    //Indique si notifications interdites
    var bNotifInterdit = false;
    //Notifications supportées ?
    if (clNotification.permission != null) {
        //Oui => on regarde si notifications autorisées
        bDroitNotif = (clNotification.permission == "granted");
        //On regarde si notifications interdites
        bNotifInterdit = (clNotification.permission == "denied");
    }
    else {
        //Non => on regarde si notifications WebKit autorisées
        //On ne passe pas par l'objet clNotification car Chrome supporte Notification et webkitNotifications mais n'implémente pas le membre permission de Notification
        bDroitNotif = (window.webkitNotifications.checkPermission() == 0);
        //On regarde si notifications interdites
        bNotifInterdit = (window.webkitNotifications.checkPermission() == 2);
    }
    //Notifications autorisées ?
    if (bDroitNotif) {
        //Oui => on va afficher la notification
        var clMessage = null;
        //Notifications supportées ?
        if (window.Notification != null) {
            //Oui => création et affichage notification
            clMessage = new window.Notification(sTitre, { body: sMessage, icon: sImage });
            //Notification OK ?
            if (clMessage != null) {
                //OK
                return;
            }
        }
        //Non => création notification WebKit
        clMessage = clNotification.createNotification(sTitre, sImage, sMessage);
        //Notification créée ?
        if (clMessage == null) {
            //Non => échec
            return;
        }
        //Oui => affichage notification
        clMessage.show();
        //OK
        return;
    }
    if (!bNotifInterdit) {
        //Non => on demande l'autorisation
        clNotification.requestPermission(function () { clWDStd.NotificationAffiche(sMessage, sTitre, sImage); });
    }
};
//Indique si page visible
clWDStd.PageVisible = function PageVisible() {
    //Propriété standard dispo ?
    if (document.hidden != null) {
        //Oui => on consulte la propriété standard
        return !(document.hidden);
    }
    //Non => propriété Microsoft dispo ?
    if (document.msHidden != null) {
        //Oui => on consulte la propriété Microsoft
        return !(document.msHidden);
    }
    //Non => propriété Mozilla dispo ?
    if (document.mozHidden != null) {
        //Oui => on consulte la propriété Mozilla
        return !(document.mozHidden);
    }
    //Non => propriété Webkit dispo ?
    if (document.webkitHidden != null) {
        //Oui => on consulte la propriété Webkit
        return !(document.webkitHidden);
    }
    //Non => propriété Opéra dispo ?
    if (document.oHidden != null) {
        //Oui => on consulte la propriété Opéra
        return !(document.oHidden);
    }
    //Non => on considère que la page est visible
    return true;
};
clWDStd.oGetConnexion = function oGetConnexion() {
    var oConnexion = navigator.connection;
    if (oConnexion == null) {
        oConnexion = navigator.mozConnection;
    }
    if (oConnexion == null) {
        oConnexion = navigator.webkitConnection;
    }
    return oConnexion;
};
clWDStd.nEtatConnexion = function nEtatConnexion() {
    var oConnexion = this.oGetConnexion();
    if (oConnexion == null) {
        return this.wifiErreur;
    }
    var nType = oConnexion.type;
    if (nType === undefined) {
        return this.wifiErreur;
    }
    switch (nType) {
        case oConnexion.WIFI:
            return this.wifiActif;
        default:
            return this.wifiDesactive;
    }
};
clWDStd.s_WifiCallback = function s_WifiCallback(oEvenement) {
    clWDStd.WifiCallback(oEvenement);
};
clWDStd.WifiCallback = function WifiCallback( /*oEvenement*/) {
    if (this.m_fWifiCallback != null) {
        var nEtat = this.nEtatConnexion();
        this.m_fWifiCallback(this.m_nWifiEtat, nEtat);
        this.m_nWifiEtat = nEtat;
    }
};
//Paramètre callback
//Entrée :	fCallback	Paramètre callback
//Sortie :	null si paramètre callback chaîne vide, fonction callback sinon
clWDStd.fParamCallback = function fParamCallback(fCallback) {
    //Paramètre callback chaîne ?
    if ((typeof fCallback) == "string") {
        //Oui => chaîne vide ?
        if (fCallback == "") {
            //Oui => callback nulle
            return null;
        }
        //Non => récupération fonction par son nom
        return eval(fCallback);
    }
    //Non => paramètre callback tel quel
    return fCallback;
};
clWDStd.wifiEtat = function wifiEtat(fCallback) {
    if (fCallback == null) {
        this.m_nWifiEtat = this.nEtatConnexion();
        return this.m_nWifiEtat;
    }
    this.m_fWifiCallback = this.fParamCallback(fCallback);
    var oConnexion = this.oGetConnexion();
    if (oConnexion != null) {
        clWDUtil.AttacheDetacheEvent(fCallback != "", this.oGetConnexion(), "change", this.s_WifiCallback, true);
    }
};
clWDStd.PleinEcranActive = function PleinEcranActive() {
    var oDocument = document.documentElement;
    if (oDocument == null) {
        return;
    }
    if (oDocument.requestFullscreen != null) {
        oDocument.requestFullscreen();
    }
    else if (oDocument.mozRequestFullScreen != null) {
        oDocument.mozRequestFullScreen();
    }
    else if (oDocument.webkitRequestFullScreen != null) {
        oDocument.webkitRequestFullScreen();
    }
};
clWDStd.PleinEcranDesactive = function PleinEcranDesactive() {
    if (document.exitFullscreen != null) {
        document.exitFullscreen();
    }
    else if (document.mozCancelFullScreen != null) {
        document.mozCancelFullScreen();
    }
    else if (document.webkitCancelFullScreen != null) {
        document.webkitCancelFullScreen();
    }
};
// Fonction WLangage TailleVersChaine
// Entrée : nTaille	Taille en octets
//			nFormat	Format désirée (constante taille..., format le plus adapté à la taille si non précisé)
// Sortie : Taille formatée, chaîne vide en cas d'erreur
clWDStd.TailleVersChaine = function TailleVersChaine(nTaille, nFormat) {
    //Valeur absolue de la taille
    var nTailleSansSigne = Math.abs(nTaille);
    //Kilo-octet
    var nKilo = 1024;
    //Format précisé ?
    if (nFormat == null) {
        //Non => on part du format octet
        nFormat = this.tailleO;
        //La limite est le kilo-octet
        var nLimite = nKilo;
        //Recherche du format le plus adapté
        while ((nFormat < this.tailleTo) && (nTailleSansSigne >= nLimite)) {
            //Format suivant
            nFormat++;
            //On passe à l'unité suivante
            nLimite *= nKilo;
        }
    }
    //Indique si format octet
    var bFormatOctet = (nFormat == this.tailleO);
    //Taille adaptée au format
    var fTailleFormat = clWDUtil.oArrondi(nTaille / Math.pow(nKilo, nFormat - 1), bFormatOctet ? 0 : 2);
    //Unité
    var sUnite = "";
    //Détermination de l'unité en fonction du format
    switch (nFormat) {
        //Octet :  
        case this.tailleO:
            //Libellé unité octet
            sUnite = WDSTD_CONST.FORMAT_TAILLE_OCTET;
            //Plus d'un octet ?
            if (fTailleFormat > 1) {
                //Oui => on ajoute un "s"
                sUnite += "s";
            }
            break;
        //Kilo-octet :  
        case this.tailleKo:
            //Libellé unité kilo-octet
            sUnite = WDSTD_CONST.FORMAT_TAILLE_KO;
            break;
        //Mega-octet :  
        case this.tailleMo:
            //Libellé unité mega-octet
            sUnite = WDSTD_CONST.FORMAT_TAILLE_MO;
            break;
        //Giga-octet :  
        case this.tailleGo:
            //Libellé unité giga-octet
            sUnite = WDSTD_CONST.FORMAT_TAILLE_GO;
            break;
        //Tera-octet :  
        case this.tailleTo:
            //Libellé unité tera-octet
            sUnite = WDSTD_CONST.FORMAT_TAILLE_TO;
            break;
        //Autre format :  
        default:
            //Erreur
            return "";
            break;
    }
    //Formatage taille
    return "" + (bFormatOctet ? fTailleFormat : clWDUtil.sNumeriqueVersChaine(fTailleFormat, ".2f")) + " " + sUnite;
};
//Capteur
var clWDCapteur = {
    //Axe accélération
    cptVertical: 1,
    cptLongitudinal: 2,
    cptLateral: 4,
    //Axe orientation
    cptAzimut: 1,
    cptPitch: 2,
    cptRoll: 4,
    //Fréquence appel callback
    cptFrequenceNormal: 1,
    cptFrequenceRapide: 2,
    cptFrequenceJeu: 3,
    //Fréquence d'appel de callback par défaut
    nFrequenceDefaut: 200,
    //Durée minimale des secousses par défaut pour déclencher début secousses
    nDureeDebutSecousseDefaut: 100,
    //Durée minimale des secousses par défaut pour déclencher fin secousses
    nDureeFinSecousseDefaut: 200,
    //Sensibilité normale par défaut
    nSensibiliteDefaut: 500,
    //Callback WLangage accélération
    m_fCallbackAcceleration: null,
    //Callback WLangage orientation
    m_fCallbackOrientation: null,
    //Callback WLangage début secousses
    m_fCallbackDebutSecousse: null,
    //Callback WLangage fin secousses
    m_fCallbackFinSecousse: null,
    //Accélération axe vertical
    m_dAccelerationAxeVertical: 0,
    //Accélération axe longitudinal
    m_dAccelerationAxeLongitudinal: 0,
    //Accélération axe latéral
    m_dAccelerationAxeLateral: 0,
    //Heure de dernière détection accélération
    m_nHeureAcceleration: -1,
    //Orientation axe vertical
    m_nOrientationAxeVertical: 0,
    //Orientation axe horizontal
    m_nOrientationAxeHorizontal: 0,
    //Orientation axe longitudinal
    m_nOrientationAxeLongitudinal: 0,
    //Dernière orientation axe vertical transmise
    m_nOrientationAxeVerticalTransmise: 0,
    //Dernière orientation axe horizontal transmise
    m_nOrientationAxeHorizontalTransmise: 0,
    //Dernière orientation axe longitudinal transmise
    m_nOrientationAxeLongitudinalTransmise: 0,
    //Heure de dernier appel de callback WLangage accélération
    m_nHeureDernierEnvoiAcceleration: -1,
    //Heure de dernier appel de callback WLangage orientation
    m_nHeureDernierEnvoiOrientation: -1,
    //Heure de première secousse pour détection début secousses
    m_nHeureDebutSecousse: -1,
    //Identifiant timer pour détection début secousses
    m_nIdTimeoutDebutSecousse: -1,
    //Indique si callback WLangage appelée pour secousse en cours
    m_bDebutSecousse: false,
    //Heure de première secousse pour détection fin secousses
    m_nHeureFinSecousse: -1,
    //Identifiant timer pour détection fin secousses
    m_nIdTimeoutFinSecousse: -1,
    //Valeur minimale accélération détectable
    m_dSeuilAcceleration: 0,
    //Valeur minimale modification orientation détectable
    m_nSeuilOrientation: 0,
    //Indique si callback accélération branchée
    m_bCallbackAccelerationBranche: false
};
//Par défaut, on détecte l'accélération sur tous les axes
clWDCapteur.nAxeAccelerationDefaut = clWDCapteur.cptVertical + clWDCapteur.cptLongitudinal + clWDCapteur.cptLateral;
//Par défaut, on détecte l'orientation sur tous les axes
clWDCapteur.nAxeOrientationDefaut = clWDCapteur.cptAzimut + clWDCapteur.cptPitch + clWDCapteur.cptRoll;
//Axes sur lesquels on détecte l'accélération
clWDCapteur.m_nAxeAcceleration = clWDCapteur.nAxeAccelerationDefaut;
//Axes sur lesquels on détecte l'orientation
clWDCapteur.m_nAxeOrientation = clWDCapteur.nAxeOrientationDefaut;
//Fréquence maximale d'appel de callback WLangage accélération
clWDCapteur.m_nFrequenceAcceleration = clWDCapteur.nFrequenceDefaut;
//Fréquence maximale d'appel de callback WLangage orientation
clWDCapteur.m_nFrequenceOrientation = clWDCapteur.nFrequenceDefaut;
//Durée minimale des secousses pour détection début secousses
clWDCapteur.m_nDureeDebutSecousse = clWDCapteur.nDureeDebutSecousseDefaut;
//Temps maximal sans secousses pour considérer secousses terminées pour détection début secousses
clWDCapteur.m_nTimeoutDebutSecousse = clWDCapteur.nDureeDebutSecousseDefaut;
//Durée minimale des secousses pour détection fin secousses
clWDCapteur.m_nDureeFinSecousse = clWDCapteur.nDureeFinSecousseDefaut;
//Temps maximal sans secousses pour considérer secousses terminées pour détection fin secousses
clWDCapteur.m_nTimeoutFinSecousse = clWDCapteur.nDureeFinSecousseDefaut;
//Sensibilité secousses pour détection début secousses
clWDCapteur.m_nSensibiliteDebutSecousse = clWDCapteur.nSensibiliteDefaut;
//Sensibilité secousses pour détection fin secousses
clWDCapteur.m_nSensibiliteFinSecousse = clWDCapteur.nSensibiliteDefaut;
//Valeur selon axe
//Entrée :	nValeur		Valeur détectée sur l'axe
//			nAxe		Axe concerné
//			nMasqueAxe	Masque des axes à détecter
//Sortie :	Valeur détectée sur l'axe si l'axe fait partie des axes à détecter, 0 sinon
clWDCapteur.nValeurSelonAxe = function nValeurSelonAxe(nValeur, nAxe, nMasqueAxe) {
    //Axe de détection de la valeur à détecter ? oui => on renvoie la valeur; non => on renvoie 0
    return (nMasqueAxe & nAxe) ? nValeur : 0;
};
//Accélération selon axe
//Entrée :	dAccélération	Accélération détectée sur l'axe
//			nAxe			Axe concerné
//Sortie :	Accélération détectée sur l'axe si l'axe fait partie des axes à détecter et est supérieure au minimum détectable, 0 sinon
clWDCapteur.dAccelerationSelonAxe = function dAccelerationSelonAxe(dAcceleration, nAxe) {
    //Accélération selon axe
    var dValeur = this.nValeurSelonAxe(dAcceleration, nAxe, this.m_nAxeAcceleration);
    //Accélération supérieure au minimum détectable ? oui => on renvoie l'accélération détectée; non => on renvoie 0
    return (dValeur > this.m_dSeuilAcceleration) ? dValeur : 0;
};
//Orientation selon axe
//Entrée :	nOrientation	Orientation détectée sur l'axe
//			nAxe			Axe concerné
//Sortie :	Orientation détectée sur l'axe si l'axe fait partie des axes à détecter, 0 sinon
clWDCapteur.nOrientationSelonAxe = function nOrientationSelonAxe(nOrientation, nAxe) {
    //Orientation selon axe
    return this.nValeurSelonAxe(nOrientation, nAxe, this.m_nAxeOrientation);
};
//Indique si orientation détectée sur un axe à prendre en compte
//Entrée :	nOrientation		Orientation détectée sur l'axe
//			nOrientationAvant	Précédente orientation détectée sur l'axe
//			nAxe				Axe concerné
//Sortie :	true si écart entre orientation détectée et précédente suffisant et sur axe à détecter, false sinon
clWDCapteur.bOrientationSelonAxe = function bOrientationSelonAxe(nOrientation, nOrientationAvant, nAxe) {
    //Indique si écart entre orientation détectée et précédente suffisant et sur axe à détecter
    return ((Math.abs(nOrientation - nOrientationAvant) > this.m_nSeuilOrientation) && (this.m_nAxeOrientation & nAxe));
};
//Débranchement timer
//Entrée :	nIdTimeout	Identifiant timer
//Sortie :	-1 si timeout débranché, identifiant du timer en entrée sinon
clWDCapteur.nDebrancheTimeout = function nDebrancheTimeout(nIdTimeout) {
    //Timer déjà débranché ?
    if (nIdTimeout >= 0) {
        //Non => on le débranche
        clWDUtil.ClearTimeout(nIdTimeout);
        //Identifiant timer débranché
        nIdTimeout = -1;
    }
    //Identifiant timer
    return nIdTimeout;
};
//Initialisation détection début secousses
clWDCapteur.InitDebutSecousse = function InitDebutSecousse() {
    //Initialisation heure première secousses pour détection début secousses
    this.m_nHeureDebutSecousse = -1;
    //Callback WLangage non appelée pour secousses en cours
    this.m_bDebutSecousse = false;
};
//Débranchement timer pour détection début secousses
clWDCapteur.DebrancheTimeoutDebutSecousse = function DebrancheTimeoutDebutSecousse() {
    //Initialisation détection début secousses
    this.InitDebutSecousse();
    //Débranchement timer pour détection début secousses
    this.m_nIdTimeoutDebutSecousse = this.nDebrancheTimeout(this.m_nIdTimeoutDebutSecousse);
};
//Débranchement timer pour détection fin secousses
clWDCapteur.DebrancheTimeoutFinSecousse = function DebrancheTimeoutFinSecousse() {
    //Initialisation heure première secousses pour détection fin secousses
    this.m_nHeureFinSecousse = -1;
    //Débranchement timer pour détection fin secousses
    this.m_nIdTimeoutFinSecousse = this.nDebrancheTimeout(this.m_nIdTimeoutFinSecousse);
};
//Réinitialisation timer
//Entrée :	nIdTimeout	Identifiant timer à réinitialiser
//			nTimeout	Nouveau délai pour le timer
//			fCallback	Nouvelle callback pour le timer
//Sortie :	Nouvel identifiant du timer
clWDCapteur.nReinitTimeout = function nReinitTimeout(nIdTimeout, nTimeout, fCallback) {
    //Débranchement timer
    this.nDebrancheTimeout(nIdTimeout);
    //Branchement timer sur nouveaux délai et callback
    return clWDUtil.nSetTimeout(fCallback, nTimeout);
};
//Indique si heure OK pour appel callback
//Entrée :	nHeure				Heure courante
//			nHeureDernierEnvoi	Heure du dernier appel à la callback
//			nFréquence			Durée minimale entre deux appels à la callback
//Sortie :	true si heure OK pour appel callback, false sinon
clWDCapteur.bHeureEnvoiOK = function bHeureEnvoiOK(nHeure, nHeureDernierEnvoi, nFrequence) {
    //Heure OK si callback non encore appelée ou si écart avec dernier envoi suffisant
    return ((nHeureDernierEnvoi < 0) || ((nHeure - nHeureDernierEnvoi) > nFrequence));
};
//Callback timer pour détection début secousse
clWDCapteur.s_CallbackDebutSecousse = function s_CallbackDebutSecousse() {
    //Initialisation détection début secousses
    clWDCapteur.InitDebutSecousse();
};
//Callback timer pour détection fin secousse
clWDCapteur.s_CallbackFinSecousse = function s_CallbackFinSecousse() {
    //Initialisation heure première secousses pour détection fin secousses
    clWDCapteur.m_nHeureFinSecousse = -1;
};
//Heure courante
//Sortie :	Heure courante (en millisecondes)
clWDCapteur.nHeure = function nHeure() {
    //Heure courante
    return (new Date()).getTime();
};
//Callback détection orientation
//Entrée :	stEvenement	Evènement
clWDCapteur.s_CallbackCapteurOrientation = function s_CallbackCapteurOrientation(stEvenement) {
    //Appel callback détection orientation de l'objet capteur
    clWDCapteur.CallbackCapteurOrientation(stEvenement);
};
//Callback détection orientation
//Entrée :	stEvenement	Evènement
clWDCapteur.CallbackCapteurOrientation = function CallbackCapteurOrientation(stEvenement) {
    //Orientation axe vertical
    this.m_nOrientationAxeVertical = stEvenement.alpha;
    //Orientation axe horizontal
    this.m_nOrientationAxeHorizontal = stEvenement.beta;
    //Orientation axe longitudinal
    this.m_nOrientationAxeLongitudinal = stEvenement.gamma;
    //Callback WLangage orientation branchée ?
    if (this.m_fCallbackOrientation != null) {
        //Oui => on regarde s'il faut tenir compte de l'orientation selon axe vertical
        var bOrientationSelonAxeVertical = this.bOrientationSelonAxe(this.m_nOrientationAxeVertical, this.m_nOrientationAxeVerticalTransmise, this.cptAzimut);
        //On regarde s'il faut tenir compte de l'orientation selon axe horizontal
        var bOrientationSelonAxeHorizontal = this.bOrientationSelonAxe(this.m_nOrientationAxeHorizontal, this.m_nOrientationAxeHorizontalTransmise, this.cptPitch);
        //On regarde s'il faut tenir compte de l'orientation selon axe longitudinal
        var bOrientationSelonAxeLongitudinal = this.bOrientationSelonAxe(this.m_nOrientationAxeLongitudinal, this.m_nOrientationAxeLongitudinalTransmise, this.cptRoll);
        //Heure courante
        var nHeure = this.nHeure();
        //Il faut tenir compte de l'orientation selon au moins l'un des axes et heure OK pour appel callback WLangage ?
        if ((bOrientationSelonAxeVertical || bOrientationSelonAxeHorizontal || bOrientationSelonAxeLongitudinal) && this.bHeureEnvoiOK(nHeure, this.m_nHeureDernierEnvoiOrientation, this.m_nFrequenceOrientation)) {
            //Oui => il faut tenir compte de l'orientation selon l'axe vertical ?
            if (bOrientationSelonAxeVertical) {
                //Oui => on va transmettre l'orientation selon l'axe vertical
                this.m_nOrientationAxeVerticalTransmise = this.m_nOrientationAxeVertical;
            }
            //Oui => il faut tenir compte de l'orientation selon l'axe horizontal ?
            if (bOrientationSelonAxeHorizontal) {
                //Oui => on va transmettre l'orientation selon l'axe horizontal
                this.m_nOrientationAxeHorizontalTransmise = this.m_nOrientationAxeHorizontal;
            }
            //Oui => il faut tenir compte de l'orientation selon l'axe longitudinal ?
            if (bOrientationSelonAxeLongitudinal) {
                //Oui => on va transmettre l'orientation selon l'axe longitudinal
                this.m_nOrientationAxeLongitudinalTransmise = this.m_nOrientationAxeLongitudinal;
            }
            //Appel de la callback WLangage d'orientation
            this.m_fCallbackOrientation(this.nOrientationSelonAxe(this.m_nOrientationAxeVerticalTransmise, this.cptAzimut), this.nOrientationSelonAxe(this.m_nOrientationAxeHorizontalTransmise, this.cptPitch), this.nOrientationSelonAxe(this.m_nOrientationAxeLongitudinalTransmise, this.cptRoll));
            //Mémorisation heure appel callback WLangage d'orientation
            this.m_nHeureDernierEnvoiOrientation = nHeure;
        }
    }
};
//Branchement ou débranchement d'un évènement sur une callback
//Entrée :	sEvenement	Nom de l'évènement
//			fCallback	Callback à brancher sur l'évènement
//			bBranche	Indique si on branche l'évènement sur la callback
clWDCapteur.BrancheEvenement = function BrancheEvenement(sEvenement, fCallback, bBranche) {
    //Branchement ou débranchement de l'évènement sur la callback
    clWDUtil.AttacheDetacheEvent(bBranche, window, sEvenement, fCallback, true);
};
//On branche l'évènement d'orientation sur la callback d'orientation
clWDCapteur.BrancheEvenement("deviceorientation", clWDCapteur.s_CallbackCapteurOrientation, true);
//Callback détection accélération
//Entrée :	stEvenement	Evènement
clWDCapteur.s_CallbackCapteurAcceleration = function s_CallbackCapteurAcceleration(stEvenement) {
    //Appel callback détection accélération de l'objet capteur
    clWDCapteur.CallbackCapteurAcceleration(stEvenement);
};
//Conversion des degrés en radians
//Entrée : nDegre	Degrés à convertir en radians
//Sortie : Conversion des degrés en radians
function nDegreVersRadian(nDegre) {
    //Conversion des degrés en radians
    return nDegre * Math.PI / 360;
}
//Callback détection accélération
//Entrée :	stEvenement	Evènement
clWDCapteur.CallbackCapteurAcceleration = function CallbackCapteurAcceleration(stEvenement) {
    //Variation due à la gravité pour axe latéral
    var nDeltaXGravite = 0;
    //Variation due à la gravité pour axe longitudinal
    var nDeltaYGravite = 0;
    //Variation due à la gravité pour axe vertical
    var nDeltaZGravite = 0;
    //Récupération accélération
    var stAcceleration = stEvenement.acceleration;
    //Accélération disponible ?
    if (stAcceleration == null) {
        //Non => récupération accélération avec gravité
        stAcceleration = stEvenement.accelerationIncludingGravity;
        //Gravité
        var nGravite = 9.81;
        //Angle axe longitudinal
        var nAngleAxeLongitudinal = nDegreVersRadian(this.m_nOrientationAxeLongitudinal);
        //Angle axe horizontal
        var nAngleAxeHorizontal = nDegreVersRadian(this.m_nOrientationAxeHorizontal);
        //Calcul variation due à la gravité pour axe latéral
        nDeltaXGravite = (-nGravite) * Math.sin(nAngleAxeLongitudinal);
        //Calcul variation due à la gravité pour axe longitudinal
        nDeltaYGravite = nGravite * Math.sin(nAngleAxeHorizontal);
        //Calcul variation due à la gravité pour axe vertical
        nDeltaZGravite = nGravite * Math.cos(nAngleAxeLongitudinal) * Math.cos(nAngleAxeHorizontal);
    }
    //Accélération selon axe vertical
    var dAccelerationAxeVertical = stAcceleration.z - nDeltaZGravite;
    //Accélération selon axe longitudinal
    var dAccelerationAxeLongitudinal = stAcceleration.y - nDeltaYGravite;
    //Accélération selon axe latéral
    var dAccelerationAxeLateral = stAcceleration.x - nDeltaXGravite;
    //Heure courante
    var nHeure = this.nHeure();
    //Vélocité de l'accélération
    var nVelocite = (this.m_nHeureAcceleration < 0) ? 0 : (Math.abs(dAccelerationAxeVertical + dAccelerationAxeLongitudinal + dAccelerationAxeLateral - this.m_dAccelerationAxeVertical - this.m_dAccelerationAxeLongitudinal - this.m_dAccelerationAxeLateral) / (nHeure - this.m_nHeureAcceleration) * 10000);
    //Mémorisation de l'heure de l'accélération
    this.m_nHeureAcceleration = nHeure;
    //Mémorisation de l'accélération selon axe vertical
    this.m_dAccelerationAxeVertical = dAccelerationAxeVertical;
    //Mémorisation de l'accélération selon axe longitudinal
    this.m_dAccelerationAxeLongitudinal = dAccelerationAxeLongitudinal;
    //Mémorisation de l'accélération selon axe latéral
    this.m_dAccelerationAxeLateral = dAccelerationAxeLateral;
    //Callback WLangage accélération branchée ?
    if (this.m_fCallbackAcceleration != null) {
        //Accélération selon axe vertical à transmettre à la callback WLangage d'accélération
        dAccelerationAxeVertical = this.dAccelerationSelonAxe(dAccelerationAxeVertical, this.cptVertical);
        //Accélération selon axe longitudinal à transmettre à la callback WLangage d'accélération
        dAccelerationAxeLongitudinal = this.dAccelerationSelonAxe(dAccelerationAxeLongitudinal, this.cptLongitudinal);
        //Accélération selon axe latéral à transmettre à la callback WLangage d'accélération
        dAccelerationAxeLateral = this.dAccelerationSelonAxe(dAccelerationAxeLateral, this.cptLateral);
        //Il faut tenir compte de l'accélération selon au moins l'un des axes et heure OK pour appel callback WLangage ?
        if (((dAccelerationAxeVertical != 0) || (dAccelerationAxeLongitudinal != 0) || (dAccelerationAxeLateral != 0)) && this.bHeureEnvoiOK(nHeure, this.m_nHeureDernierEnvoiAcceleration, this.m_nFrequenceAcceleration)) {
            //Oui => appel de la callback WLangage d'accélération
            this.m_fCallbackAcceleration(dAccelerationAxeVertical, dAccelerationAxeLongitudinal, dAccelerationAxeLateral);
            //Mémorisation heure appel callback WLangage d'accélération
            this.m_nHeureDernierEnvoiAcceleration = nHeure;
        }
    }
    //Callback WLangage début secousses branchée ?
    if (this.m_fCallbackDebutSecousse != null) {
        //Oui => accélération détectable ?
        if (nVelocite > this.m_nSensibiliteDebutSecousse) {
            //Oui => première secousse ?
            if (this.m_nHeureDebutSecousse < 0) {
                //Oui => on mémorise l'heure la première secousse pour la détection de début des secousses
                this.m_nHeureDebutSecousse = nHeure;
            }
            //Callback WLangage début secousses non encore appelée pour les secousses en cours et durée des secousses suffisante ?
            if ((!this.m_bDebutSecousse) && ((nHeure - this.m_nHeureDebutSecousse) >= this.m_nDureeDebutSecousse)) {
                //On n'appellera plus la callback WLangage de début de secousses pour cette série de secousses
                this.m_bDebutSecousse = true;
                //Appel de la callback WLangage de début de secousses
                this.m_fCallbackDebutSecousse();
            }
            //Réinitialisation timer détection secousses terminées pour détection début secousses
            this.m_nIdTimeoutDebutSecousse = this.nReinitTimeout(this.m_nIdTimeoutDebutSecousse, this.m_nTimeoutDebutSecousse, this.s_CallbackDebutSecousse);
        }
    }
    //Callback WLangage fin secousses branchée ?
    if (this.m_fCallbackFinSecousse != null) {
        //Oui => accélération détectable ?
        if (nVelocite > this.m_nSensibiliteFinSecousse) {
            //Oui => première secousse ?
            if (this.m_nHeureFinSecousse < 0) {
                //Oui => on mémorise l'heure la première secousse pour la détection de fin des secousses
                this.m_nHeureFinSecousse = nHeure;
            }
            //Durée des secousses
            var nDureeSecousse = nHeure - this.m_nHeureFinSecousse;
            //Durée des secousses suffisante
            if (nDureeSecousse >= this.m_nDureeFinSecousse) {
                //Oui => si pas de secousses pendant l'intervalle de temps voulu pour considérer secousses terminées, on appellera la callback WLangage de fin de secousses
                this.m_nIdTimeoutFinSecousse = this.nReinitTimeout(this.m_nIdTimeoutFinSecousse, this.m_nTimeoutFinSecousse, function () { clWDCapteur.m_nHeureFinSecousse = -1; clWDCapteur.m_fCallbackFinSecousse(nDureeSecousse); });
            }
            else {
                //Non => réinitialisation timer détection secousses terminées pour détection fin secousses
                this.m_nIdTimeoutFinSecousse = this.nReinitTimeout(this.m_nIdTimeoutFinSecousse, this.m_nTimeoutFinSecousse, this.s_CallbackFinSecousse);
            }
        }
    }
};
//Fréquence selon mode
//Entrée :	nMode	Mode de fréquence
//Sortie :	Fréquence correspondant au mode
clWDCapteur.nFrequenceMode = function nFrequenceMode(nMode) {
    //Le mode est
    switch (nMode) {
        //Rapide :  
        case this.cptFrequenceRapide:
            //Fréquence mode rapide
            return 0;
        //Jeu :
        case this.cptFrequenceJeu:
            //Fréquence mode jeu
            return 20;
        //Autre :
        default:
            //Fréquence par défaut
            return this.nFrequenceDefaut;
    }
};
//Indique si capteur accélération disponible
clWDCapteur.bCapteurAccelerationDisponible = function bCapteurAccelerationDisponible() {
    //Capteur accélération disponible si évènement mouvement supporté
    return (window.DeviceMotionEvent != null);
};
//Branchement ou débranchement callback accélération
clWDCapteur.BrancheCallbackAcceleration = function BrancheCallbackAcceleration() {
    //Callback accélération à brancher ou débrancher ?
    if (this.m_bCallbackAccelerationBranche != ((this.m_fCallbackAcceleration != null) || (this.m_fCallbackDebutSecousse != null) || (this.m_fCallbackFinSecousse != null))) {
        //Oui => inversion du branchement de la callback d'accélération
        this.m_bCallbackAccelerationBranche = (!this.m_bCallbackAccelerationBranche);
        //Branchement ou débranchement de la callback d'accélération
        this.BrancheEvenement("devicemotion", this.s_CallbackCapteurAcceleration, this.m_bCallbackAccelerationBranche);
    }
};
//////////////////////////////////////////////////////////////////////////
// Interface WL fonctions capteur
//Détection changement accélération
//Entrée :	fCallback	Callback WLangage de détection de changement d'accélération
//			nAxe		Masque axes sur lesquels on détecte l'accélération
//			nFrequence	Fréquence maximale d'appel de la callback WLangage de détection de changement d'accélération
//			dSeuil		Seuil à partir duquel l'accélération est transmise à la callback WLangage de détection de changement d'accélération
//Sortie :	true si capteur accélération disponible, false sinon
clWDCapteur.CapteurDetecteChangementAcceleration = function CapteurDetecteChangementAcceleration(fCallback, nAxe, nFrequence, dSeuil) {
    //Callback WLangage de détection de changement d'accélération
    this.m_fCallbackAcceleration = clWDStd.fParamCallback(fCallback);
    //Masque axes sur lesquels on détecte l'accélération
    this.m_nAxeAcceleration = WDStd.vValeurOuParDefaut(nAxe, this.nAxeAccelerationDefaut);
    //Fréquence maximale d'appel de la callback WLangage de détection de changement d'accélération
    this.m_nFrequenceAcceleration = this.nFrequenceMode(nFrequence);
    //Seuil à partir duquel l'accélération est transmise à la callback WLangage de détection de changement d'accélération
    this.m_dSeuilAcceleration = WDStd.vValeurOuParDefaut(dSeuil, 0);
    //Initialisation heure dernier envoi accélération
    this.m_nHeureDernierEnvoiAcceleration = -1;
    //Branchement callback accélération
    this.BrancheCallbackAcceleration();
    //Indique si capteur accélération disponible
    return this.bCapteurAccelerationDisponible();
};
//Détection changement orientation
//Entrée :	fCallback		Callback WLangage de détection de changement d'orientation
//			nOrientation	Masque axes sur lesquels on détecte l'orientation
//			nFrequence		Fréquence maximale d'appel de la callback WLangage de détection de changement d'orientation
//			nSeuil			Modification d'orientation minimale pour être transmise à la callback WLangage de détection de changement d'orientation
//Sortie :	true si capteur orientation disponible, false sinon
clWDCapteur.CapteurDetecteChangementOrientation = function CapteurDetecteChangementOrientation(fCallback, nOrientation, nFrequence, nSeuil) {
    //Callback WLangage de détection de changement d'orientation
    this.m_fCallbackOrientation = clWDStd.fParamCallback(fCallback);
    //Masque axes sur lesquels on détecte l'orientation
    this.m_nAxeOrientation = WDStd.vValeurOuParDefaut(nOrientation, this.nAxeOrientationDefaut);
    //Fréquence maximale d'appel de la callback WLangage de détection de changement d'orientation
    this.m_nFrequenceOrientation = this.nFrequenceMode(nFrequence);
    //Modification d'orientation minimale pour être transmise à la callback WLangage de détection de changement d'orientation
    this.m_nSeuilOrientation = WDStd.vValeurOuParDefaut(nSeuil, 0);
    //Initialisation heure dernier envoi orientation
    this.m_nHeureDernierEnvoiOrientation = -1;
    //Capteur orientation disponible si évènement orientation supporté
    return (window.DeviceOrientationEvent != null);
};
//Détection début secousses
//Entrée :	fCallback		Callback WLangage de détection de début de secousses
//			nSensibilite	Sensibilité aux secousses
//			nDurée			Durée minimale des secousses pour détection début secousses
//			nIntervalle		Temps maximal sans secousses pour considérer secousses terminées pour détection début secousses
//Sortie :	true si capteur accélération disponible, false sinon
clWDCapteur.CapteurDetecteDebutSecousses = function CapteurDetecteDebutSecousses(fCallback, nSensibilite, nDuree, nIntervalle) {
    //Callback WLangage de détection de début de secousses
    this.m_fCallbackDebutSecousse = clWDStd.fParamCallback(fCallback);
    //Sensibilité aux secousses
    this.m_nSensibiliteDebutSecousse = WDStd.vValeurOuParDefaut(nSensibilite, this.nSensibiliteDefaut);
    //Durée minimale des secousses pour détection début secousses
    this.m_nDureeDebutSecousse = WDStd.vValeurOuParDefaut(nDuree, this.nDureeDebutSecousseDefaut);
    //Temps maximal sans secousses pour considérer secousses terminées pour détection début secousses
    this.m_nTimeoutDebutSecousse = WDStd.vValeurOuParDefaut(nIntervalle, this.nDureeDebutSecousseDefaut);
    //Débranchement timer fin secousses pour détection début secousses
    this.DebrancheTimeoutDebutSecousse();
    //Branchement callback accélération
    this.BrancheCallbackAcceleration();
    //Indique si capteur accélération disponible
    return this.bCapteurAccelerationDisponible();
};
//Détection fin secousses
//Entrée :	fCallback		Callback WLangage de détection de fin de secousses
//			nSensibilite	Sensibilité aux secousses
//			nDurée			Durée minimale des secousses pour détection fin secousses
//			nIntervalle		Temps maximal sans secousses pour considérer secousses terminées pour détection fin secousses
//Sortie :	true si capteur accélération disponible, false sinon
clWDCapteur.CapteurDetecteFinSecousses = function CapteurDetecteFinSecousses(fCallback, nSensibilite, nDuree, nIntervalle) {
    //Callback WLangage de détection de fin de secousses
    this.m_fCallbackFinSecousse = clWDStd.fParamCallback(fCallback);
    //Sensibilité aux secousses
    this.m_nSensibiliteFinSecousse = WDStd.vValeurOuParDefaut(nSensibilite, this.nSensibiliteDefaut);
    //Durée minimale des secousses pour détection fin secousses
    this.m_nDureeFinSecousse = WDStd.vValeurOuParDefaut(nDuree, this.nDureeFinSecousseDefaut);
    //Temps maximal sans secousses pour considérer secousses terminées pour détection fin secousses
    this.m_nTimeoutFinSecousse = WDStd.vValeurOuParDefaut(nIntervalle, this.nDureeFinSecousseDefaut);
    //Débranchement timer fin secousses pour détection fin secousses
    this.DebrancheTimeoutFinSecousse();
    //Branchement callback accélération
    this.BrancheCallbackAcceleration();
    //Indique si capteur accélération disponible
    return this.bCapteurAccelerationDisponible();
};
//Fin détection par capteur
clWDCapteur.CapteurTermine = function CapteurTermine() {
    //Initialisation des callbacks WLangage;
    this.m_fCallbackAcceleration = this.m_fCallbackOrientation = this.m_fCallbackDebutSecousse = this.m_fCallbackFinSecousse = null;
    //Débranchement timer fin secousses pour détection début secousses
    this.DebrancheTimeoutDebutSecousse();
    //Débranchement timer fin secousses pour détection fin secousses
    this.DebrancheTimeoutFinSecousse();
    //Débranchement callback accélération
    this.BrancheCallbackAcceleration();
};
//Récupération orientation selon un axe
//Entrée :	nAxe	Axe selon lequel on veut l'orientation
//Sortie : Orientation selon l'axe désiré
clWDCapteur.CapteurRecupereOrientation = function CapteurRecupereOrientation(nAxe) {
    //L'axe désiré est
    switch (nAxe) {
        //Vertical :  
        case this.cptAzimut:
            //Orientation selon axe vertical
            return this.m_nOrientationAxeVertical;
        //Horizontal :
        case this.cptPitch:
            //Orientation selon axe horizontal
            return this.m_nOrientationAxeHorizontal;
        //Longitudinal :
        case this.cptRoll:
            //Orientation selon axe longitudinal
            return this.m_nOrientationAxeLongitudinal;
        //Autre :
        default:
            //Pas d'orientation
            return 0;
    }
};
// retour à la ligne
var XRC = "\r\n";
var WDStd;
(function (WDStd) {
    //Position chaîne erreur en WLangage
    var nPOSITION_CHAINE_WL_ERREUR = 0;
    //Position chaîne début en WLangage
    var nPOSITION_CHAINE_WL_DEBUT = 1;
    //EOT
    var sEOT = "\b";
    //Code erreur si pas d'erreur
    WDStd.nERREUR_AUCUNE = 0;
    //Paramètre modifiable
    var CParam = /** @class */ (function () {
        //Constructeur
        function CParam(Valeur) {
            this.m_Valeur = Valeur;
        }
        return CParam;
    }());
    WDStd.CParam = CParam;
    //Paramètre numérique modifiable
    var CParamNum = /** @class */ (function (_super) {
        __extends(CParamNum, _super);
        function CParamNum() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return CParamNum;
    }(CParam));
    WDStd.CParamNum = CParamNum;
    ;
    //Paramètre chaîne modifiable
    var CParamChaine = /** @class */ (function (_super) {
        __extends(CParamChaine, _super);
        function CParamChaine() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return CParamChaine;
    }(CParam));
    WDStd.CParamChaine = CParamChaine;
    ;
    //Indique si un code d'erreur est une erreur
    //Entrée :	nErreur	Code d'erreur dont on vaut savoir s'il signale une erreur
    //Sortie :	true si le code d'erreur signale une erreur, false sinon
    function bErreur(nErreur) {
        //Indique si le code d'erreur signale une erreur
        return nErreur != WDStd.nERREUR_AUCUNE;
    }
    WDStd.bErreur = bErreur;
    //Lève une erreur
    //Entrée :	nErreur		Erreur à lever
    //			tabParam	Paramètres optionnels
    function LeveErreur(nErreur) {
        var tabParam = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            tabParam[_i - 1] = arguments[_i];
        }
        throw new WDErreur(nErreur, tabParam);
    }
    WDStd.LeveErreur = LeveErreur;
    //Tableau des parcours de chaîne par ExtraitChaîneEntre
    var gnTabParcoursExtraitChaineEntre;
    //Indique si option vraie dans une variable
    function OPTION_TRUE(nVariable, nOption) {
        return (nVariable & nOption) != 0;
    }
    WDStd.OPTION_TRUE = OPTION_TRUE;
    //Met une option à vrai dans une variable
    function SET_OPTION_TRUE(Variable, Option) {
        return Variable | Option;
    }
    WDStd.SET_OPTION_TRUE = SET_OPTION_TRUE;
    //Met une option à faux dans une variable
    function SET_OPTION_FALSE(Variable, Option) {
        return Variable & (~Option);
    }
    WDStd.SET_OPTION_FALSE = SET_OPTION_FALSE;
    //Change une option dans une variable
    function SET_OPTION(Variable, Option, Valeur) {
        return Valeur ? SET_OPTION_TRUE(Variable, Option) : SET_OPTION_FALSE(Variable, Option);
    }
    WDStd.SET_OPTION = SET_OPTION;
    //Indique si une variable est indéfinie
    function bNonDefini(vVariable) {
        return undefined === vVariable;
    }
    WDStd.bNonDefini = bNonDefini;
    //Valeur reçue ou par défaut si valeur non précisée
    //Entrée :	Valeur			Valeur
    //			ValeurParDefaut	Valeur par défaut
    function vValeurOuParDefaut(Valeur, ValeurParDefaut) {
        //Valeur précisée ? oui => on renvoie la valeur; non => on renvoie la valeur par défaut
        return bNonDefini(Valeur) ? ValeurParDefaut : Valeur;
    }
    WDStd.vValeurOuParDefaut = vValeurOuParDefaut;
    WDStd.nPREMIER_INDICE_WL = 1;
    //Conversion indice WLangage vers indice C++
    function nIndiceWLVersC(nIndice) {
        return ((nIndice) - WDStd.nPREMIER_INDICE_WL);
    }
    WDStd.nIndiceWLVersC = nIndiceWLVersC;
    //Indique si position chaîne OK en WLangage
    function bPOSITION_CHAINE_WL_OK(nPosition) {
        return ((nPosition) >= nPOSITION_CHAINE_WL_DEBUT);
    }
    //Conversion position chaîne WLangage vers position chaîne C++
    function nPOSITION_CHAINE_WL_VERS_C(nPosition) {
        return nIndiceWLVersC(nPosition);
    }
    //Extrait une sous-chaine incluse entre 2 séparateurs en partant du début
    //Entrée :	sOrigine			Chaîne dans laquelle on recherche
    //			sTabSeparateurDebut	Séparateurs de début
    //			sTabSeparateurFin	Séparateurs de fin
    //			nRang				Indice de la chaîne recherchée (ou constante rangPremier, rangDernier, rangPrécédent ou rangSuivant)
    //			nOption				Options (depuis fin, sans casse, mot complet)
    //Sortie :	Chaîne trouvée ou EOT en cas d'échec
    function __ExtraitChaineEntreNormal(sOrigine, sTabSeparateurDebut, sTabSeparateurFin, nRang, nOption) {
        if (nOption === void 0) { nOption = 0; }
        //Résultat
        var sResultat = "";
        // position de début de recherche
        var nDebut = nPOSITION_CHAINE_WL_DEBUT;
        // la fin de la sous-chaîne n'est pas définie
        var nFin = nPOSITION_CHAINE_WL_ERREUR;
        // indice de la sous-chaine en cours
        var nIndiceSousChaine = 0;
        // paramètre de recherche
        var clParamRecherche = new CWDStdParamPosition();
        // recherche sous-chaîne
        while ((nIndiceSousChaine < nRang) && bPOSITION_CHAINE_WL_OK(nDebut = Position(sOrigine, sTabSeparateurDebut, nDebut, nOption, clParamRecherche))) {
            // la sous-chaîne commence après le séparateur de début
            nDebut += clParamRecherche.m_nTailleChaineTrouve;
            // on cherche la position du séparateur de fin suivant
            nFin = Position(sOrigine, sTabSeparateurFin, nDebut, nOption, clParamRecherche);
            // séparateur de fin trouvé ?
            if (!bPOSITION_CHAINE_WL_OK(nFin)) {
                // non => on arrête la recheche
                break;
            }
            // oui => on incrémente l'indice de la sous-chaine en cours
            nIndiceSousChaine++;
            // on a trouvé la sous-chaîne recherchée
            if (nIndiceSousChaine == nRang) {
                // oui => on arrête le recherche
                break;
            }
            // non => on se positionne après le séparateur de fin
            nDebut = nFin + clParamRecherche.m_nTailleChaineTrouve;
        }
        // on a trouvé la bonne sous-chaine ?
        if (nIndiceSousChaine == nRang) {
            // oui => on la renvoie
            sResultat = sOrigine.substring(nPOSITION_CHAINE_WL_VERS_C(nDebut), nPOSITION_CHAINE_WL_VERS_C(nFin));
        }
        else {
            // non => on renvoie EOT
            sResultat = sEOT;
        }
        return sResultat;
    }
    //Extrait une sous-chaine incluse entre 2 séparateurs en partant de la fin
    //Entrée :	sOrigine			Chaîne dans laquelle on recherche
    //			sTabSeparateurDebut	Séparateurs de début
    //			sTabSeparateurFin	Séparateurs de fin
    //			nRang				Indice de la chaîne recherchée (ou constante rangPremier, rangDernier, rangPrécédent ou rangSuivant)
    //			nOption				Options (depuis fin, sans casse, mot complet)
    //Sortie :	Chaîne trouvée ou EOT en cas d'échec
    function __ExtraitChaineEntreInverse(sOrigine, sTabSeparateurDebut, sTabSeparateurFin, nRang, nOption) {
        if (nOption === void 0) { nOption = 0; }
        //Résultat
        var sResultat = "";
        // position de début de recherche : on met taille min séparateur fin car taille min séparateur fin enlévée à position début recherche pour chercher séparateur fin => recherche commence à la fin
        var nDebut = 1;
        // la fin de la sous-chaîne n'est pas définie
        var nFin = nPOSITION_CHAINE_WL_ERREUR;
        // indice de la sous-chaine en cours
        var nIndiceSousChaine = 0;
        // paramètre de recherche
        var clParamRecherche = new CWDStdParamPosition(true);
        // recherche sous-chaîne
        while ((nIndiceSousChaine < nRang) && bPOSITION_CHAINE_WL_OK(nFin = Position(sOrigine, sTabSeparateurFin, nDebut - 1, nOption, clParamRecherche))) {
            // on a une chance de trouver le séparateur de début ?
            if (nFin <= 1) {
                // non => on arrête la recherche
                break;
            }
            // on cherche la position du séparateur de début précédent
            nDebut = Position(sOrigine, sTabSeparateurDebut, nFin - 1, nOption, clParamRecherche);
            // séparateur de début trouvé ?
            if (!bPOSITION_CHAINE_WL_OK(nDebut)) {
                // non => on arrête la recheche
                break;
            }
            // oui => on incrémente l'indice de la sous-chaine en cours
            nIndiceSousChaine++;
            // on a trouvé la sous-chaîne recherchée
            if (nIndiceSousChaine == nRang) {
                // oui => la sous-chaîne commence après le séparateur de début
                nDebut += clParamRecherche.m_nTailleChaineTrouve;
                // on arrête le recherche
                break;
            }
            // non => on a une chance de trouver le séparateur de fin ?
            else if (nDebut <= 1) {
                // non => on arrête la recherche
                break;
            }
        }
        // on a trouvé la bonne sous-chaine ?
        if (nIndiceSousChaine == nRang) {
            // oui => on la renvoie
            sResultat = sOrigine.substring(nPOSITION_CHAINE_WL_VERS_C(nDebut), nPOSITION_CHAINE_WL_VERS_C(nFin));
        }
        else {
            // non => on renvoie EOT
            sResultat = sEOT;
        }
        return sResultat;
    }
    //Conversiion d'une variable en tableau de chaînes
    function sTabTableauChaine(vVariable) {
        //La variable est un tableau
        if (clWDUtil.isArray(vVariable)) {
            //Oui => on convertit le contenu du tableau en chaîne
            return vVariable.map(function (vValeur) { return String(vValeur); });
        }
        else {
            //Non => on met la variable convertie en chaîne dans un tableau
            return [String(vVariable)];
        }
    }
    //Extraction d'une chaîne entre deux séparateurs
    //Entrée :	sOrigine			Chaîne dans laquelle on recherche
    //			sTabSeparateurDebut	Séparateurs de début
    //			sTabSeparateurFin	Séparateurs de fin
    //			nRang				Indice de la chaîne recherchée (ou constante rangPremier, rangDernier, rangPrécédent ou rangSuivant)
    //			nOption				Options (depuis fin, sans casse, mot complet)
    //Sortie :	Chaîne trouvée ou EOT en cas d'échec
    function __ExtraitChaineEntre(sOrigine, sTabSeparateurDebut, sTabSeparateurFin, nRang, nOption) {
        if (nOption === void 0) { nOption = 0; }
        //Indique si on est dans un parcours (premier/suivant ou dernier/précédent)
        var bParcours = true;
        //Indique si parcours depuis fin de chaîne
        var bDepuisFin = false;
        //Clé chaine de recherche pour parcours
        var sCleParcours = sOrigine.substring(0, 50);
        // on commence par traiter les cas particulier des options de parcours
        switch (nRang) {
            // rangDernier :
            case clWDStd.RG_DER:
                // recherche depuis la fin
                bDepuisFin = true;
            // pas de break;
            // rangPremier :
            case clWDStd.RG_PRM:
                //Tableau des parcours par ExtraitChaîneEntre initialisé ?
                if (gnTabParcoursExtraitChaineEntre == null) {
                    //Non => on le crée
                    gnTabParcoursExtraitChaineEntre = new Array();
                }
                //On recherche la première occurrence
                nRang = 1;
                break;
            // rangPrécédent :
            case clWDStd.RG_PRC:
                // recherche depuis la fin
                bDepuisFin = true;
            // pas de break;
            // rangSuivant :
            case clWDStd.RG_SUI:
                //Recherche dans la chaîne initié par recherche premier ou dernier ?
                if ((gnTabParcoursExtraitChaineEntre == null) || (gnTabParcoursExtraitChaineEntre[sCleParcours] == null)) {
                    //Non => échec
                    return sEOT;
                }
                //Oui => on recherche du suivant
                nRang = gnTabParcoursExtraitChaineEntre[sCleParcours] + 1;
                break;
            // autres valeurs : c'est le rang
            default:
                // on n'est pas dans un parcours (premier/suivant ou dernier/précédent)
                bParcours = false;
                break;
        }
        // on est dans un parcours (premier/suivant ou dernier/précédent) ?
        if (bParcours) {
            //Oui => mémorisation nouveau rang parcours
            gnTabParcoursExtraitChaineEntre[sCleParcours] = nRang;
            //On fixe l'option de recherche depuis fin selon le parcours
            nOption = SET_OPTION(nOption, clWDStd.CO_FIN, bDepuisFin);
        }
        //Résultat
        var sResultat = sEOT;
        // est-ce qu'on est en sens normal ?
        if (OPTION_TRUE(nOption, clWDStd.CO_FIN)) {
            // non => on cherche à partir de la fin
            sResultat = __ExtraitChaineEntreInverse(sOrigine, sTabSeparateurDebut, sTabSeparateurFin, nRang, nOption);
        }
        else {
            // oui => on cherche la chaine dans le sens normal
            sResultat = __ExtraitChaineEntreNormal(sOrigine, sTabSeparateurDebut, sTabSeparateurFin, nRang, nOption);
        }
        //On est dans un parcours (premier/suivant ou dernier/précédent) qui est terminé ?
        if (bParcours && (sResultat == sEOT)) {
            //Oui => destruction parcours
            delete gnTabParcoursExtraitChaineEntre[sCleParcours];
        }
        return sResultat;
    }
    //Indique si une variable est un nombre
    function bNombre(vVariable) {
        return typeof vVariable == "number";
    }
    //Converison d'une variable en entier
    function nEntier(vVariable) {
        return parseInt(String(vVariable));
    }
    //Extraction d'une chaîne entre deux séparateurs
    //Entrée :	vChaineInitiale			Chaîne dans laquelle on recherche
    //			vRang					Indice de la chaîne recherchée (ou constante rangPremier, rangDernier, rangPrécédent ou rangSuivant)
    //			vSeparateurDebut		Séparateur(s) de début
    //			vSeparateurFinOuOptions	Séparateur(s) de fin ou options (depuis fin, sans casse, mot complet)
    //			vOption					Options (depuis fin, sans casse, mot complet)
    //Sortie :	Chaîne trouvée ou EOT en cas d'échec
    function ExtraitChaineEntre(vChaineInitiale, vRang, vSeparateurDebut, vSeparateurFinOuOptions, vOption) {
        if (vOption === void 0) { vOption = 0; }
        //Rang de recherche
        var nRang = nEntier(vRang);
        //Rang de recherche numérique ?
        if (isNaN(nRang)) {
            //Non => échec
            return sEOT;
        }
        //Options
        var nOption = 0;
        //Indique si le paramètre séparateur de fin ou option représente les options
        var bSeparateurFinOuOptionsEstOption = bNombre(vSeparateurFinOuOptions);
        //Le paramètre séparateur de fin ou option représente les options ?
        if (bSeparateurFinOuOptionsEstOption) {
            //Oui => on récupère donc les options de ce paramètre
            nOption = nEntier(vSeparateurFinOuOptions);
        }
        else {
            //Non => on récupère les options du paramètre otpions
            nOption = nEntier(vOption);
        }
        //Options numérique
        if (isNaN(nOption)) {
            //Non => échec
            return sEOT;
        }
        //Séparateur de début
        var sTabSeparateurDebut = sTabTableauChaine(vSeparateurDebut);
        //Séparateur de fin
        var sTabSeparateurFin;
        //Paramètre séparateur de fin ou options non fourni ou représentant les options ?
        if ((!vSeparateurFinOuOptions) || bSeparateurFinOuOptionsEstOption) {
            //Oui => les séparateurs de fin sont les même que ceux de début
            sTabSeparateurFin = sTabSeparateurDebut;
        }
        else {
            //Non => on récupère les séparateur de fin de ce paramètre
            sTabSeparateurFin = sTabTableauChaine(vSeparateurFinOuOptions);
        }
        //Extraction chaîne
        return __ExtraitChaineEntre(String(vChaineInitiale), sTabSeparateurDebut, sTabSeparateurFin, nRang, nOption);
    }
    WDStd.ExtraitChaineEntre = ExtraitChaineEntre;
    // Conversion date-heure UTC vers date-heure locale ou vice-versa
    // Entrée :	sDateHeure		Date-heure à convertir au format WLangage (AAAAMMJJHHSSLLL)
    //			bUTCVersLocale	Indique si conversion date-heure UTC vers date-heure locale
    // Sortie :	Date-heure convertie au format WLangage (AAAAMMJJHHSSLLL)
    function _DateHeureUTCLocale(sDateHeure, bUTCVersLocale) {
        if (bUTCVersLocale === void 0) { bUTCVersLocale = true; }
        //Date-heure système
        var oDate = new Date();
        //Conversion date-heure UTC au format WLangage en date-heure système OK ?
        var bDateOK = clWDUtil.bSetDateHeureFromWL(oDate, sDateHeure, bUTCVersLocale, true, true, 0);
        //Converion OK ?
        if (bDateOK) {
            //Oui => date-heure limite
            var oDateLimite = new Date(1980, 0, 1, 0, 0, 0, 0);
            //La date-heure doit être au moins égale à la date-heure limite
            bDateOK = (oDate >= oDateLimite);
        }
        //Date-heure OK ?
        if (!bDateOK) {
            //Non => erreur
            throw new WDErreur(204);
        }
        //Conversion date-heure système en date-heure locale au format WLangage
        return clWDUtil.sGetDateHeureWL(oDate, !bUTCVersLocale, true, true);
    }
    // Conversion date-heure UTC vers date-heure locale
    // Entrée :	sDateHeureUTC	Date-heure UTC au format WLangage (AAAAMMJJHHSSLLL)
    // Sortie :	Date-heure locale au format WLangage (AAAAMMJJHHSSLLL)
    function DateHeureUTCVersLocale(sDateHeureUTC) {
        //Conversion date-heure UTC en date-heure locale
        return _DateHeureUTCLocale(sDateHeureUTC);
    }
    WDStd.DateHeureUTCVersLocale = DateHeureUTCVersLocale;
    // Conversion date-heure locale vers date-heure UTC
    // Entrée :	sDateHeureLocal	Date-heure locale au format WLangage (AAAAMMJJHHSSLLL)
    // Sortie :	Date-heure UTC au format WLangage (AAAAMMJJHHSSLLL)
    function DateHeureLocaleVersUTC(sDateHeureLocal) {
        //Conversion date-heure locale en date-heure UTC
        return _DateHeureUTCLocale(sDateHeureLocal, false);
    }
    WDStd.DateHeureLocaleVersUTC = DateHeureLocaleVersUTC;
    // Fonction WL ExtraitLigne
    function sExtraitLigne(oChaine, oNumLigne) {
        // les paramètres
        var sChaine = String(oChaine);
        var nNumLigne = parseInt(String(oNumLigne)) - 1;
        // chaine vide
        if (sChaine.length === 0) {
            return sEOT;
        }
        var nOffset = 0;
        var nCompteur = 0;
        // parcours des lignes
        while (nCompteur <= nNumLigne) {
            // si on est sur la ligne recherchée
            if (nCompteur === nNumLigne) {
                // récupération du prochaine séparateur
                var nOffsetFin = sChaine.indexOf("\n", nOffset);
                // cas particulier de la dernière ligne
                if (nOffsetFin === -1) {
                    return sChaine.substring(nOffset);
                }
                // si on a un \r\n, on remonte d'un caractère
                // il faut prendre la fin de la chaine
                if (sChaine[nOffsetFin - 1] == "\r") {
                    nOffsetFin--;
                }
                // extraction de la ligne
                return sChaine.substring(nOffset, nOffsetFin);
            }
            // recherche de la prochaine fin de ligne
            nOffset = sChaine.indexOf("\n", nOffset);
            // pas assez de ligne
            if (nOffset === -1) {
                return sEOT;
            }
            // incrémente le compteur de ligne
            nCompteur++;
            // et on se place au début de la ligne suivante
            nOffset++;
        }
        // pas trouvé
        return sEOT;
    }
    WDStd.sExtraitLigne = sExtraitLigne;
})(WDStd || (WDStd = {}));
var StdEncode;
(function (StdEncode) {
    ///////////////////////////////////////////////////////////////////////////////////
    // Conversion chaine en BYTE
    // Entree :	sChaine	Chaine à convertir en BYTE
    // Sortie :	Code ASCII du premier caractere de la chaine
    function byBYTE(sChaine) {
        //Code ASCII du premier catractere de la chaine
        return sChaine.charCodeAt(0);
    }
    ///////////////////////////////////////////////////////////////////////////////////
    // Affectation d'un caractere donne d'une chaine
    // Entree :	sChaine		Chaine a modifier
    //			nPosition	Indice du caractere a modifier
    //			sCaractere	Caractere affecte a la chaine
    // Sortie :	Chaine modifiee
    function sChaineAffecteCaractere(sChaine, nPosition, sCaractere) {
        //Ajout des caracteres manquants
        while (sChaine.length < nPosition) {
            //On met un caractere nul
            sChaine += "\x00";
        }
        //Chaine avec caractere a la position desiree modifie
        return sChaine.substring(0, nPosition) + sCaractere + sChaine.substring(nPosition + 1, sChaine.length);
    }
    ///////////////////////////////////////////////////////////////////////////////////
    // Classe CEncodeBase
    // Classe de base dérive pour faire l'UUEncodage, l'encodage BASE64 et le "BASE 64 PC SOFT" (pour compat)
    var CEncodeBase = /** @class */ (function () {
        function CEncodeBase() {
        }
        ////////////////////////////////////////////////////////////////////////////////
        // UUEncoder un buffer
        // Entrée:
        //		pbySource		:	buffer binaire à encoder
        //		nLineLength		:	nombre de blocs de 4 caractères par ligne de texte
        // Retour:
        //		chaîne destination
        CEncodeBase.prototype.sEncode = function (pbySource, nLineLength) {
            var nIndiceSource = 0;
            var nRemaining = 0;
            var nBloc = 0;
            var byBuffer1 = 0;
            var byBuffer2 = 0;
            var byBuffer3 = 0;
            var nSize = pbySource.length;
            var pszDestination = "";
            // On parcourt le buffer source 3 octets par 3 octets et le texte destination 4 caractères par 4 caractères
            for (nIndiceSource = 0; nIndiceSource < nSize; nIndiceSource += 3) {
                nRemaining = nSize - nIndiceSource;
                // On stocke les 3 octets commençant à nIndiceSource. S'il n'en reste pas assez, on stocke 0
                byBuffer1 = pbySource.charCodeAt(nIndiceSource);
                byBuffer2 = (nRemaining > 1) ? pbySource.charCodeAt(nIndiceSource + 1) : 0;
                byBuffer3 = (nRemaining > 2) ? pbySource.charCodeAt(nIndiceSource + 2) : 0;
                // On les étend en 4 caractères. S'il n'y a plus rien à coder, on met des '\0' pour terminer le bloc. 
                pszDestination += this.__cEncodeByte(((byBuffer1 & 0xfc) >> 2));
                pszDestination += this.__cEncodeByte((((byBuffer1 & 0x03) << 4) | ((byBuffer2 & 0xf0) >> 4)));
                if (nRemaining > 1) {
                    pszDestination += this.__cEncodeByte((((byBuffer2 & 0x0f) << 2) | ((byBuffer3 & 0xc0) >> 6)));
                }
                else {
                    break;
                }
                if (nRemaining > 2) {
                    pszDestination += this.__cEncodeByte((byBuffer3 & 0x3f));
                }
                else {
                    break;
                }
                // Découpage du texte encodé en lignes de taille fixe et ligne remplie ?
                if (this.__bDecoupeTexteEncodeEnLignedeTailleFixe() && (((++nBloc) % nLineLength) == 0)) {
                    //Oui => on va à la ligne
                    pszDestination += XRC;
                }
            }
            // On renvoie la chaîne encodée
            return pszDestination;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // UUDécoder une chaîne
        // Entrée:
        //		pszSource		:	chaîne de caractères à décoder
        // Retour:
        //		buffer binaire destination
        //virtual 
        CEncodeBase.prototype.sDecode = function (pszSource) {
            var nIndiceSource = 0;
            var nRemaining = 0;
            var nSize = pszSource.length;
            var byBuffer1 = 0;
            var byBuffer2 = 0;
            var byBuffer3 = 0;
            var byBuffer4 = 0;
            var pbyDestination = "";
            // On parcourt le texte source 4 caractères par 4 caractères et le buffer destination 3 octets par 3 octets
            for (nIndiceSource = 0; nIndiceSource < nSize; nIndiceSource += 4) {
                nRemaining = nSize - nIndiceSource;
                // On détecte les retours à la ligne
                if (pszSource[nIndiceSource] == "\n" || pszSource[nIndiceSource] == "\r") {
                    // Dans ce cas, on revient en arrière pour se positionner au début du bloc suivant
                    nIndiceSource -= 3;
                    continue;
                }
                // On stocke les 4 caractères commençant à nIndiceSource. S'il n'y en a plus, on stocke 0.
                byBuffer1 = this.__byDecodeChar(pszSource[nIndiceSource]);
                byBuffer2 = (nRemaining > 1) ? this.__byDecodeChar(pszSource[nIndiceSource + 1]) : 0;
                byBuffer3 = (nRemaining > 2) ? this.__byDecodeChar(pszSource[nIndiceSource + 2]) : 0;
                byBuffer4 = (nRemaining > 3) ? this.__byDecodeChar(pszSource[nIndiceSource + 3]) : 0;
                // On les comprime en 3 octets 
                if (nRemaining > 1) {
                    pbyDestination += String.fromCharCode((byBuffer1 << 2) | ((byBuffer2 & 0x30) >> 4));
                }
                else {
                    break;
                }
                if (nRemaining > 2) {
                    pbyDestination += String.fromCharCode(((byBuffer2 & 0x0f) << 4) | ((byBuffer3 & 0x3c) >> 2));
                }
                else {
                    break;
                }
                if (nRemaining > 3) {
                    pbyDestination += String.fromCharCode(((byBuffer3 & 0x03) << 6) | (byBuffer4 & 0x3f));
                }
                else {
                    break;
                }
            }
            // On renvoie le buffer binaire
            return pbyDestination;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Encodage d'un octet d'une plage donnee
        // Entree :	sCaractMin	Caractère minimum de la plage d'encodage de l'octet
        //			nOctet		Octet à encoder
        //			nOctetMin	Valeur minimum de la plage d'encodage de l'octet
        // Sortie :	Encodage de l'octet
        CEncodeBase.prototype.__sEncodeOctetPlage = function (sCaractMin, nOctet, nOctetMin) {
            //Encodage de l'octet
            return String.fromCharCode(byBYTE(sCaractMin) + nOctet - nOctetMin);
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Indique si découpage du texte encodé en lignes de taille fixe
        // Retour:
        //		true si découpage du texte encodé en lignes de taille fixe, false sinon
        CEncodeBase.prototype.__bDecoupeTexteEncodeEnLignedeTailleFixe = function () {
            //Lignes de taille fixe
            return true;
        };
        return CEncodeBase;
    }());
    // Encodeur BASE 64 à la sauce PC SOFT
    var CEncodeBase64PCS = /** @class */ (function (_super) {
        __extends(CEncodeBase64PCS, _super);
        function CEncodeBase64PCS() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ////////////////////////////////////////////////////////////////////////////////
        // Encoder 6 bits binaires
        // Entrée:
        //		b	:	valeur binaire à encoder (entre 0 et 63 inclus)
        // Retour:
        //		le caractère correspondant
        CEncodeBase64PCS.prototype.__cEncodeByte = function (b) {
            if (b <= 25) {
                return this.__sEncodeOctetPlage("A", b, 0);
            }
            if ((b >= 26) && (b <= 51)) {
                return this.__sEncodeOctetPlage("a", b, 26);
            }
            if ((b >= 52) && (b <= 61)) {
                return this.__sEncodeOctetPlage("0", b, 52);
            }
            if (b == 62) {
                return "+";
            }
            return "/";
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Décoder un caractère
        // Entrée:
        //		c	:	le carctère à décoder
        // Retour:
        //		la valeur sur 6 bits correspondante
        CEncodeBase64PCS.prototype.__byDecodeChar = function (c) {
            var byCode = byBYTE(c);
            var byCodeMin = byBYTE("A");
            if ((byCode >= byCodeMin) && (byCode <= byBYTE("Z"))) {
                return (byCode - byCodeMin);
            }
            byCodeMin = byBYTE("a");
            if ((byCode >= byCodeMin) && (byCode <= byBYTE("z"))) {
                return (byCode - byCodeMin + 26);
            }
            byCodeMin = byBYTE("0");
            if ((byCode >= byCodeMin) && (byCode <= byBYTE("9"))) {
                return (byCode - byCodeMin + 52);
            }
            if (byCode == byBYTE("+")) {
                return 62;
            }
            return 63;
        };
        return CEncodeBase64PCS;
    }(CEncodeBase));
    // Encodeur BASE 64 à la norme RFC3548
    var CEncodeBase64 = /** @class */ (function (_super) {
        __extends(CEncodeBase64, _super);
        function CEncodeBase64() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ////////////////////////////////////////////////////////////////////////////////
        // UUEncoder un buffer
        // Entrée:
        //		pbySource		:	buffer binaire à encoder
        //		nLineLength		:	nombre de blocs de 4 caractères par ligne de texte
        // Retour:
        //		chaîne destination
        CEncodeBase64.prototype.sEncode = function (pbySource, nLineLength) {
            //Init avec resultat methode classe de base
            var pszDestination = _super.prototype.sEncode.call(this, pbySource, nLineLength);
            //Taille chaine source
            var nSize = pbySource.length;
            // On ajoute les valeurs de padding
            switch (nSize % 3) {
                case 1:
                    // Est-ce qu'une chaîne a été passée à la fonction
                    pszDestination += "==";
                    break;
                case 2:
                    pszDestination += "=";
                    break;
            }
            // On renvoie la chaîne encodée
            return pszDestination;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // UUDécoder une chaîne
        // Entrée:
        //		pszSource		:	chaîne de caractères à décoder
        // Retour:
        //		buffer binaire destination
        //virtual 
        CEncodeBase64.prototype.sDecode = function (pszSource) {
            var nIndiceSource = 0;
            var nRemaining = 0;
            var nSize = pszSource.length;
            var byBuffer1 = 0;
            var byBuffer2 = 0;
            var byBuffer3 = 0;
            var byBuffer4 = 0;
            var pbyDestination = "";
            // On parcourt le texte source 4 caractères par 4 caractères et le buffer destination 3 octets par 3 octets
            for (nIndiceSource = 0; nIndiceSource < nSize; nIndiceSource += 4) {
                nRemaining = nSize - nIndiceSource;
                // On détecte les retours à la ligne
                if (pszSource[nIndiceSource] == "\n" || pszSource[nIndiceSource] == "\r") {
                    // Dans ce cas, on revient en arrière pour se positionner au début du bloc suivant
                    nIndiceSource -= 3;
                    continue;
                }
                // On stocke les 4 caractères commençant à nIndiceSource. S'il n'y en a plus, on stocke 0.
                byBuffer1 = this.__byDecodeChar(pszSource[nIndiceSource]);
                byBuffer2 = (nRemaining > 1) ? this.__byDecodeChar(pszSource[nIndiceSource + 1]) : 0;
                byBuffer3 = (nRemaining > 2) ? this.__byDecodeChar(pszSource[nIndiceSource + 2]) : 0;
                byBuffer4 = (nRemaining > 3) ? this.__byDecodeChar(pszSource[nIndiceSource + 3]) : 0;
                // On les comprime en 3 octets 
                if ((nRemaining > 1) && (pszSource[nIndiceSource] != "=")) {
                    pbyDestination += String.fromCharCode((byBuffer1 << 2) | ((byBuffer2 & 0x30) >> 4));
                }
                else {
                    break;
                }
                if ((nRemaining > 2) && (pszSource[nIndiceSource] != "=")) {
                    // si on a que la moitié du buffer, c'est que c'est juste la terminaison du 1er char.
                    if (pszSource[nIndiceSource + 2] == "=" && ((byBuffer2 & 0x0f) == 0)) {
                        break;
                    }
                    pbyDestination += String.fromCharCode(((byBuffer2 & 0x0f) << 4) | ((byBuffer3 & 0x3c) >> 2));
                }
                else {
                    break;
                }
                if ((nRemaining > 3) && (pszSource[nIndiceSource] != "=")) {
                    // si on a que la moitié du buffer, c'est que c'est juste la terminaison du 1er char.
                    if (pszSource[nIndiceSource + 3] == "=" && ((byBuffer3 & 0x3f) == 0)) {
                        break;
                    }
                    pbyDestination += String.fromCharCode(((byBuffer3 & 0x03) << 6) | (byBuffer4 & 0x3f));
                }
                else {
                    break;
                }
            }
            // On renvoie le buffer binaire
            return pbyDestination;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Décoder un caractère
        // Entrée:
        //		c	:	le carctère à décoder
        // Retour:
        //		la valeur sur 6 bits correspondante
        CEncodeBase64.prototype.__byDecodeChar = function (c) {
            //Caractère de padding ?
            if (c == "=") {
                //Oui => 0
                return 0;
            }
            //Non => comme classe de base
            return _super.prototype.__byDecodeChar.call(this, c);
        };
        return CEncodeBase64;
    }(CEncodeBase64PCS));
    //Caractère pour encoder valeur binaire 62 en Base 64 URL
    var cCAR_ENCODE_BASE64URL_62 = "-";
    //Caractère pour encoder valeur binaire 63 en Base 64 URL
    var cCAR_ENCODE_BASE64URL_63 = "_";
    // Encodeur BASE 64 à la norme RFC3548 sans retour chariot
    var CEncodeBase64SansRC = /** @class */ (function (_super) {
        __extends(CEncodeBase64SansRC, _super);
        function CEncodeBase64SansRC() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ////////////////////////////////////////////////////////////////////////////////
        // Indique si découpage du texte encodé en lignes de taille fixe
        // Retour:
        //		true si découpage du texte encodé en lignes de taille fixe, false sinon
        CEncodeBase64SansRC.prototype.__bDecoupeTexteEncodeEnLignedeTailleFixe = function () {
            //Pas de retour chariot
            return false;
        };
        return CEncodeBase64SansRC;
    }(CEncodeBase64));
    // Encodeur BASE 64 URL à la norme RFC4648
    var CEncodeBase64URL = /** @class */ (function (_super) {
        __extends(CEncodeBase64URL, _super);
        function CEncodeBase64URL() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ////////////////////////////////////////////////////////////////////////////////
        // Encoder 6 bits binaires
        // Entrée:
        //		b	:	valeur binaire à encoder (entre 0 et 63 inclus)
        // Retour:
        //		le caractère correspondant
        CEncodeBase64URL.prototype.__cEncodeByte = function (b) {
            //Valeurs encodés de la même manière qu'en Base 64 (caractères non gênant dans une URL)
            if (b < 62) {
                return _super.prototype.__cEncodeByte.call(this, b);
            }
            //Valeurs encodées différemment en Base 64 URL
            if (b == 62) {
                return cCAR_ENCODE_BASE64URL_62;
            }
            return cCAR_ENCODE_BASE64URL_63;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Décoder un caractère
        // Entrée:
        //		c	:	le carctère à décoder
        // Retour:
        //		la valeur sur 6 bits correspondante
        CEncodeBase64URL.prototype.__byDecodeChar = function (c) {
            //Détermination de la valeur binaire encodée par le caractère
            switch (c) {
                //Caractères spécifiques à l'encodage Base 64 URL
                case cCAR_ENCODE_BASE64URL_62:
                    return 62;
                case cCAR_ENCODE_BASE64URL_63:
                    return 63;
                //Caractères communs avec l'encodage Base 64
                default:
                    return _super.prototype.__byDecodeChar.call(this, c);
            }
        };
        return CEncodeBase64URL;
    }(CEncodeBase64SansRC));
    //Nombre d'octets du bloc à encoder en base 85
    var nTAILLE_BLOC_ENTREE_BASE85 = 4;
    //Nombre d'octets du bloc encodé en base 85
    var nTAILLE_BLOC_SORTIE_BASE85 = 5;
    //Indice max octet de bloc encodé en base 85
    var nINDICE_MAX_BLOC_SORTIE_BASE85 = (nTAILLE_BLOC_SORTIE_BASE85 - 1);
    //Caractère début alphabet encodage Base 85
    var cCAR_DEBUT_ALPHABET_BASE85 = 33;
    //Nombre de caractère utilisés dans encodage Base 85
    var nNB_CAR_BASE85 = 85;
    //Valeur erreur
    var byVAL_ERREUR = 255;
    //Début chaîne encodée en Base 85
    var szDEBUT_ENCODAGE_BASE85 = "<~";
    //Fin chaîne encodée en Base 85
    var szFIN_ENCODAGE_BASE85 = "~>";
    // Encodeur BASE 85 à la norme RFC1924
    var CEncodeBase85 = /** @class */ (function (_super) {
        __extends(CEncodeBase85, _super);
        function CEncodeBase85() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ////////////////////////////////////////////////////////////////////////////////
        // UUEncoder un buffer
        // Entrée:
        //		pbySource		:	buffer binaire à encoder
        //		nLineLength		:	nombre de blocs de 4 caractères par ligne de texte
        // Retour:
        //		chaîne destination
        CEncodeBase85.prototype.sEncode = function (pbySource /*, nLineLength: number*/) {
            //Taille chaine source
            var nSize = pbySource.length;
            //Nombre d'octets du dernier bloc incomplet de sortie
            var nNbEnPus = (nSize % nTAILLE_BLOC_ENTREE_BASE85) + 1;
            //Indique si dernier bloc incomplet
            var bDernierBlocIncomplet = nNbEnPus > 1;
            //Indique si on est sur le dernier bloc
            var bDernierBloc = false;
            //Indice caractère dans source
            var nIndiceSource = 0;
            //Chaine resultat
            var pszDestination = "";
            //Position dans chaine resultat
            var nIndiceDestination = 0;
            //Encodage
            while (nSize > 0) {
                //Bloc à encoder
                var dwBloc = 0;
                //Récupération bloc à encoder
                for (var nNbBit = 24; nNbBit >= 0; nNbBit -= 8) {
                    //Récupération valeur octet
                    var byOctet = byBYTE(pbySource[nIndiceSource++]);
                    //Transfert octet dans bloc à encoder
                    dwBloc |= (byOctet << nNbBit);
                    //Dernier caractère (donc dernier bloc) ?
                    if ((bDernierBloc = (--nSize == 0)) == true) {
                        //Oui => fin de récupération de bloc à encoder
                        break;
                    }
                }
                //Indique si on est dans le dernier bloc et qu'il est incomplet
                var bDansDernierBlocIncomplet = bDernierBloc && bDernierBlocIncomplet;
                //Encodage du bloc
                for (var nOctet = nINDICE_MAX_BLOC_SORTIE_BASE85; nOctet >= 0; nOctet--) {
                    //Récupération valeur à encoder
                    var nVal = dwBloc % nNB_CAR_BASE85;
                    //Passage à la valeur à encoder suivante
                    dwBloc /= nNB_CAR_BASE85;
                    //On est pas dans le dernier bloc qui est incomplet, ou on est dans les limites du dernier bloc incomplet ?
                    if ((!bDansDernierBlocIncomplet) || (nOctet < nNbEnPus)) {
                        //Oui => ajout valeur encodée dans buffer destination
                        pszDestination = sChaineAffecteCaractere(pszDestination, nIndiceDestination + nOctet, this.__cEncodeByte(nVal));
                    }
                }
                //On se positionne sur le début du prochain bloc encodé
                nIndiceDestination += (bDansDernierBlocIncomplet ? nNbEnPus : nTAILLE_BLOC_SORTIE_BASE85);
            }
            //Chaine encodee
            return pszDestination;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // UUDécoder une chaîne
        // Entrée:
        //		pszSource		:	chaîne de caractères à décoder
        // Retour:
        //		buffer binaire destination
        //virtual 
        CEncodeBase85.prototype.sDecode = function (pszSource) {
            //Taille chaîne à décoder
            var nSize = pszSource.length;
            //Longueur en-tête
            var nLngEntete = szDEBUT_ENCODAGE_BASE85.length;
            //On saute éventuellement l'en-tête
            if ((nSize >= nLngEntete) && (pszSource.indexOf(szDEBUT_ENCODAGE_BASE85) == 0)) {
                pszSource = pszSource.substring(nLngEntete, nSize);
                nSize -= nLngEntete;
            }
            //Longeur terminaison
            var nLngTerminaison = szFIN_ENCODAGE_BASE85.length;
            //On coupe éventuellement la terminaison d'encodage Base 85
            if ((nSize >= nLngTerminaison) && (pszSource.substring(nSize - nLngTerminaison, nSize) == szFIN_ENCODAGE_BASE85)) {
                nSize -= nLngTerminaison;
            }
            //Taille données décodées
            var nLongueurDecode = 0;
            //Position dans chaine source
            var nIndiceSource = 0;
            //Donnees decodees
            var pbyDestination = "";
            //Décodage
            while (nSize > 0) {
                //Bloc décodé
                var dwBloc = 0;
                //Valeur corresondant au caractère lu
                var byVal = byVAL_ERREUR;
                //Position dans bloc à décoder
                var nPosition = nINDICE_MAX_BLOC_SORTIE_BASE85;
                //Caractère encodé lu
                var cEncode = "";
                //Nombre de caractères restant à traiter
                var nNbCarRestant = nSize;
                //Décodage bloc
                do {
                    //Indique s'il reste des caractère à traiter
                    var bPasFini = nNbCarRestant > 0;
                    //Récupération caractère encodé
                    cEncode = (bPasFini) ? pszSource[nIndiceSource++] : String.fromCharCode(cCAR_DEBUT_ALPHABET_BASE85 + nNB_CAR_BASE85 - 1);
                    //Il reste des caractères à traiter ?
                    if (bPasFini) {
                        //Oui => un caractère de moins à traîter
                        nNbCarRestant--;
                    }
                    //Récupération valeur correspondant au caractère encodé
                    byVal = this.__byDecodeChar(cEncode);
                    //Valeur incorrecte ?
                    if (byVal == byVAL_ERREUR) {
                        //Oui => on saute le caractère
                        nPosition++;
                    }
                    else {
                        //Non => mise à jour valeur
                        dwBloc = (dwBloc * nNB_CAR_BASE85) + byVal;
                    }
                } while (nPosition-- > 0);
                //Position dans bloc décodé
                nPosition = Math.min(nSize - 1, nTAILLE_BLOC_ENTREE_BASE85);
                //Mise à jour du nombre de caractères traités
                nSize = nNbCarRestant;
                //Inversion de l'ordre des octets (car en mémoire les octets d'un nombre sont inversés)
                while (nPosition-- > 0) {
                    //Rotation des octets vers la gauche
                    dwBloc = (dwBloc << 8) | (dwBloc >> 24);
                    //Ecriture du dernier octet
                    pbyDestination += String.fromCharCode(dwBloc & 0xff);
                    //Un octet de plus dans la chaîne décodée
                    nLongueurDecode++;
                }
            }
            //Données décodées
            return pbyDestination;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Encoder 6 bits binaires
        // Entrée:
        //		b	:	valeur binaire à encoder (entre 0 et 84 inclus)
        // Retour:
        //		le caractère correspondant
        CEncodeBase85.prototype.__cEncodeByte = function (b) {
            return String.fromCharCode(b + cCAR_DEBUT_ALPHABET_BASE85);
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Indique si un caractere appartient a une plage donnee
        // Entree :	sCaract		Caractere dont on veut savoir s'il est dans la plage
        //			sCaractMin	Caractère minimum de la plage de décodage de l'octet
        //			nOctetMin	Valeur minimum de la plage de décodage de l'octet
        //			nOctetMax	Valeur maximum de la plage de décodage de l'octet
        // Sortie :	true si le caractere appartient à la plage, false sinon
        CEncodeBase85.prototype.__bCaractDansPlage = function (sCaract, sCaractMin, nOctetMin, nOctetMax) {
            //Code ASCII caractere a tester
            var nCaract = byBYTE(sCaract);
            //Code ASCII caractere minimum de la plage
            var nCaractMin = byBYTE(sCaractMin);
            //On teste si l'octet appartient à la plage
            return ((nCaract >= nCaractMin) && (nCaract <= (nCaractMin + (nOctetMax - nOctetMin))));
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Decodage d'un caractere d'une plage donnee
        // Entree :	sCaract		Caractere dont on veut savoir s'il est dans la plage
        //			sCaractMin	Caractère minimum de la plage de décodage de l'octet
        //			nOctetMin	Valeur minimum de la plage de décodage de l'octet
        // Sortie :	Decodage du carcatere
        CEncodeBase85.prototype.__nDecodeCarPlage = function (sCaract, sCaractMin, nOctetMin) {
            //Decodage du caractere
            return byBYTE(sCaract) - byBYTE(sCaractMin) + nOctetMin;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Décoder un caractère
        // Entrée:
        //		c	:	le carctère à décoder
        // Retour:
        //		la valeur sur 6 bits correspondante
        CEncodeBase85.prototype.__byDecodeChar = function (c) {
            //Récupération code ascii caractère
            var byCode = byBYTE(c);
            //Décodage caractères corrects
            if ((byCode >= cCAR_DEBUT_ALPHABET_BASE85) && (byCode < (cCAR_DEBUT_ALPHABET_BASE85 + nNB_CAR_BASE85))) {
                return byCode - cCAR_DEBUT_ALPHABET_BASE85;
            }
            //Caractère invalide
            return byVAL_ERREUR;
        };
        return CEncodeBase85;
    }(CEncodeBase));
    var UU_SIGN = "begin 0666 uu" + XRC;
    var UU_SIGNOFF_STANDARD = XRC + "`" + XRC + "end" + XRC;
    // Encodeur UUEncode (historique, ne respecte pas le standard)
    var CEncodeUUEncodeStandard = /** @class */ (function (_super) {
        __extends(CEncodeUUEncodeStandard, _super);
        function CEncodeUUEncodeStandard() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ////////////////////////////////////////////////////////////////////////////////
        // UUEncoder un buffer
        // Entrée:
        //		pbySource		:	buffer binaire à encoder
        //		nLineLength		:	nombre de blocs de 4 caractères par ligne de texte
        // Retour:
        //		chaîne destination
        CEncodeUUEncodeStandard.prototype.sEncode = function (pbySource, nLineLength) {
            nLineLength = 45;
            var nIndiceSource = 0;
            var nIndiceDestination = 0;
            var nRemaining = 0;
            var nBloc = 0;
            var byBuffer1 = 0;
            var byBuffer2 = 0;
            var byBuffer3 = 0;
            var bDebutLigne = true;
            // on sort tout d'abord une entete
            var pszDestination = UU_SIGN;
            nIndiceDestination = pszDestination.length;
            // On parcourt le buffer source 3 octets par 3 octets et le texte destination 4 caractères par 4 caractères
            var nSize = pbySource.length;
            for (nIndiceSource = 0; nIndiceSource < nSize; nIndiceSource += 3) {
                nRemaining = nSize - nIndiceSource;
                // Caractère spécial de début de ligne : indique le nombre de caractères encodés sur la ligne 
                if (bDebutLigne) {
                    if (nRemaining > nLineLength - 1) {
                        pszDestination += String.fromCharCode(nLineLength + 32);
                    }
                    else {
                        pszDestination += String.fromCharCode(nRemaining + 32);
                    }
                    bDebutLigne = false;
                }
                // On stocke les 3 octets commençant à nIndiceSource. S'il n'en reste pas assez, on stocke 0
                byBuffer1 = pbySource.charCodeAt(nIndiceSource);
                byBuffer2 = (nRemaining > 1) ? pbySource.charCodeAt(nIndiceSource + 1) : 0;
                byBuffer3 = (nRemaining > 2) ? pbySource.charCodeAt(nIndiceSource + 2) : 0;
                // On les étend en 4 caractères. S'il n'y a plus rien à coder, on met des '\0' pour terminer le bloc. 
                pszDestination += String.fromCharCode(0x20 + ((byBuffer1 >> 2) & 0x3F));
                pszDestination += String.fromCharCode(0x20 + (((byBuffer1 << 4) | ((byBuffer2 >> 4) & 0xF)) & 0x3F));
                if (nRemaining > 1) {
                    pszDestination += String.fromCharCode(0x20 + (((byBuffer2 << 2) | ((byBuffer3 >> 6) & 0x3)) & 0x3F));
                }
                if (nRemaining > 2) {
                    pszDestination += String.fromCharCode(0x20 + ((byBuffer3) & 0x3F));
                }
                // Si la ligne est remplie, on va à la ligne
                if ((++nBloc) % nLineLength == 0) {
                    pszDestination += XRC;
                    // On change le flag pour inscrire l'entete
                    bDebutLigne = true;
                }
            }
            // on ajoute l'épilogue
            pszDestination += UU_SIGNOFF_STANDARD;
            // On renvoie la chaîne encodée
            return pszDestination;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // UUDécoder une chaîne
        // Entrée:
        //		pszSource		:	chaîne de caractères à décoder
        // Retour:
        //		buffer binaire destination
        //virtual 
        CEncodeUUEncodeStandard.prototype.sDecode = function (pszSource) {
            var nIndiceSource = 0;
            var nRemaining = 0;
            var nSize = pszSource.length;
            var byBuffer1 = 0;
            var byBuffer2 = 0;
            var byBuffer3 = 0;
            var byBuffer4 = 0;
            // On "saute" l'entete
            nIndiceSource = UU_SIGN.length - 2;
            //Buffer decode
            var pbyDestination = "";
            // On parcourt le texte source 4 caractères par 4 caractères et le buffer destination 3 octets par 3 octets
            var bLastLine = false;
            for (; nIndiceSource < nSize && !bLastLine; nIndiceSource += 4) {
                // On détecte les retours à la ligne
                if (pszSource[nIndiceSource] == '\n' || pszSource[nIndiceSource] == '\r') {
                    // Dans ce cas, on avance de deux pour se positionner au début du bloc suivant
                    nIndiceSource += 2;
                    // Et on lit le nombre de caractères de la ligne
                    nRemaining = byBYTE(pszSource[nIndiceSource++]) - 32;
                    // Cas de la ligne vide
                    if (nRemaining == 64) {
                        nRemaining = 0;
                        bLastLine = true;
                    }
                }
                // On stocke les 4 caractères commençant à nIndiceSource. S'il n'y en a plus, on stocke 0.
                byBuffer1 = this.__byDecodeChar(pszSource[nIndiceSource]);
                byBuffer2 = (nRemaining > 1) ? this.__byDecodeChar(pszSource[nIndiceSource + 1]) : 0;
                byBuffer3 = (nRemaining > 2) ? this.__byDecodeChar(pszSource[nIndiceSource + 2]) : 0;
                byBuffer4 = (nRemaining > 2) ? this.__byDecodeChar(pszSource[nIndiceSource + 3]) : 0;
                // On les comprime en 3 octets 
                if (nRemaining >= 1) {
                    pbyDestination += String.fromCharCode((byBuffer1 << 2) | ((byBuffer2 & 0x30) >> 4));
                    nRemaining--;
                    if (nRemaining >= 1) {
                        pbyDestination += String.fromCharCode(((byBuffer2 & 0x0f) << 4) | ((byBuffer3 & 0x3c) >> 2));
                        nRemaining--;
                        if (nRemaining >= 1) {
                            pbyDestination += String.fromCharCode(((byBuffer3 & 0x03) << 6) | (byBuffer4 & 0x3f));
                            nRemaining--;
                        }
                    }
                }
            }
            // On le buffer binaire
            return pbyDestination;
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Encoder 6 bits binaires
        // Entrée:
        //		b	:	valeur binaire à encoder (entre 0 et 63 inclus)
        // Retour:
        //		le caractère correspondant
        CEncodeUUEncodeStandard.prototype.__cEncodeByte = function (b) {
            return String.fromCharCode(b + 0x20);
        };
        ////////////////////////////////////////////////////////////////////////////////
        // Décoder un caractère
        // Entrée:
        //		c	:	le carctère à décoder
        // Retour:
        //		la valeur sur 6 bits correspondante
        CEncodeUUEncodeStandard.prototype.__byDecodeChar = function (c) {
            return byBYTE(c) - 0x20;
        };
        return CEncodeUUEncodeStandard;
    }(CEncodeBase));
    // Tableau accélérateur : permet d'éviter d'avoir recours à un sprintf ou autre
    // Indice dans le tableau = code ascii à transformer.
    // "" = pas de conversion à faire.
    // URLEncode converti une URL avec toute sorte de caractère en une URL avec tous les caractère bizarre encodé par %xx avec xx = code ascii du caratère
    // URLDecode fait l'inverse : tout les %xx sont remplcé par le caractère correspondant
    // En unicode les caractères sont remplcé par %xx%yy
    var Code = [
        [
            "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0A", "0B", "0C", "0D", "0E", "0F",
            "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1A", "1B", "1C", "1D", "1E", "1F",
            "20", "", "22", "", "", "25", "", "", "", "", "", "2B", "", "", "", "",
            "", "", "", "", "", "", "", "", "", "", "", "", "3C", "", "3E", "",
            "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            "", "", "", "", "", "", "", "", "", "", "", "5B", "5C", "5D", "5E", "",
            "60", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            "", "", "", "", "", "", "", "", "", "", "", "7B", "7C", "7D", "7E", "7F",
            "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8A", "8B", "8C", "8D", "8E", "8F",
            "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9A", "9B", "9C", "9D", "9E", "9F",
            "A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "AA", "AB", "AC", "AD", "AE", "AF",
            "B0", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "BA", "BB", "BC", "BD", "BE", "BF",
            "C0", "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "CA", "CB", "CC", "CD", "CE", "CF",
            "D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "DA", "DB", "DC", "DD", "DE", "DF",
            "E0", "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9", "EA", "EB", "EC", "ED", "EE", "EF",
            "F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "FA", "FB", "FC", "FD", "FE", "FF" // Fx
        ],
        [
            "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0A", "0B", "0C", "0D", "0E", "0F",
            "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1A", "1B", "1C", "1D", "1E", "1F",
            "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "2A", "2B", "2C", "2D", "2E", "2F",
            "", "", "", "", "", "", "", "", "", "", "3A", "3B", "3C", "3D", "3E", "3F",
            "40", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            "", "", "", "", "", "", "", "", "", "", "", "5B", "5C", "5D", "5E", "5F",
            "60", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            "", "", "", "", "", "", "", "", "", "", "", "7B", "7C", "7D", "7E", "7F",
            "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8A", "8B", "8C", "8D", "8E", "8F",
            "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9A", "9B", "9C", "9D", "9E", "9F",
            "A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "AA", "AB", "AC", "AD", "AE", "AF",
            "B0", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "BA", "BB", "BC", "BD", "BE", "BF",
            "C0", "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "CA", "CB", "CC", "CD", "CE", "CF",
            "D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "DA", "DB", "DC", "DD", "DE", "DF",
            "E0", "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9", "EA", "EB", "EC", "ED", "EE", "EF",
            "F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "FA", "FB", "FC", "FD", "FE", "FF" // Fx
        ]
    ];
    /////////////////////////////////////////////
    // Indique si un cararactère est délimiteur d'URL
    // cCaractere : Caractère à tester
    function bDelimiteurURL(cCaractere) {
        //Conversion caractère en entier
        var byCaractere = byBYTE(cCaractere);
        //Un caractère est ddélimiteur d'URL s'il n'est pas encodé en encodage sans encodage des délimiteurs d'URL alors qu'il est en encodage total
        return Code[0][byCaractere] != Code[1][byCaractere];
    }
    /////////////////////////////////////////////
    // Indique si un cararactère doit etre encodé
    // cCaractere : Caractère à tester
    function bCaractereEncode(cCaractere, bEncodageTotal, bEncodeDelimiteurURLSeulement) {
        //On encode que les délimiteurs d'URL ? oui => caractère encodé si délimiteur d'URL; non => on regarde si caractère encodé selon si encodage total ou pas
        return bEncodeDelimiteurURLSeulement ? bDelimiteurURL(cCaractere) : (Code[bEncodageTotal ? 1 : 0][byBYTE(cCaractere) & 0x0FF] != "");
    }
    /////////////////////////////////////////////
    // Encodage proprement dit de l'url
    // pszURL : URL à encoder
    // pszURLEncodee : buffer pour stocker l'URL encodée. Ce buffer doit DEJA être alloué. Comme ce buffer doit venir d'un CWLDSTR, on ne met pas de zero final
    // bEncodageTotal : Indique si on encode tous les caractères y compris les délimiteurs d'URL
    // bEncodeDelimiteurURLSeulement : Indique si on n'encode que les délimiteurs d'URL
    // valeur de retour : la taille effectivement utilisé dans le buffer
    function EncodeURL(pszURL, bEncodageTotal, bEncodeDelimiteurURLSeulement) {
        if (bEncodeDelimiteurURLSeulement === void 0) { bEncodeDelimiteurURLSeulement = false; }
        // URL encodee
        var pszURLEncodee = "";
        //Taille URL
        var nTailleURL = pszURL.length;
        // Parcours des caractères de l'url
        for (var nIndiceURL = 0; nIndiceURL < nTailleURL; nIndiceURL++) {
            if (bCaractereEncode(pszURL[nIndiceURL], bEncodageTotal, bEncodeDelimiteurURLSeulement)) // Test de l'encodage à applique
             {
                //On va chercher l'encodage dans le tableau d'encodage avec délimiteur URL si encodage total si on encode les délimiteurs d'URL seulement
                var nIndiceTbaleauEncodage = (bEncodageTotal || bEncodeDelimiteurURLSeulement) ? 1 : 0;
                // Ce caractère à un encodage en %xx
                pszURLEncodee += "%";
                pszURLEncodee += Code[nIndiceTbaleauEncodage][byBYTE(pszURL[nIndiceURL]) & 0x0FF];
            }
            //#endif				// *** #ifdef UNICODE ***
            else {
                // Sinon on le copie simplement
                pszURLEncodee += pszURL[nIndiceURL];
            }
        }
        // Et renvoi la chaine
        return pszURLEncodee;
    }
    var szMARQUEEURO95 = "%26%238364%3B";
    var cMARQUEEURO95 = "2";
    var XCHAR_EURO = "\u20AC";
    var NUMCARAC = 2;
    /////////////////////////////////////////////
    // Décodage proprement dit de l'url
    // pszURL : URL à décoder
    // pszURLDecodee : buffer pour stocker l'URL encodée. Ce buffer doit DEJA être alloué. Comme ce buffer doit venir d'un CWLDSTR, on ne met pas de zero final
    // valeur de retour : la taille effectivement utilisé dans le buffer
    function DecodeURL(pszURL) {
        // URL decodee
        var pszURLDecodee = "";
        //Taille URL
        var nTailleURL = pszURL.length;
        //Position dans URL
        var nIndiceURL = 0;
        // On parcours l'URL encodée
        while (nIndiceURL < nTailleURL) // tant qu'il y a des car
         {
            switch (pszURL[nIndiceURL]) {
                case "%":
                    // Gestion du cas particuler de win95 qui ne connais pas le symbole €
                    // => renvoie "%26%238364%3B" => "&#8364;"
                    if ((pszURL[nIndiceURL + 1] == cMARQUEEURO95) && (pszURL.substring(0, szMARQUEEURO95.length) == szMARQUEEURO95)) {
                        pszURLDecodee += XCHAR_EURO; // _X('€');
                        nIndiceURL += szMARQUEEURO95.length; // Ce cas particulier ne gène pas notre decodage
                        break; // Car il utilise moins de caractère que compté
                    }
                    // Normalement il y a %xx soit 2 caractères hexa
                    if ((nIndiceURL + 2) < nTailleURL) // Si ils y sont effectivement
                     {
                        // Parcours des 6 caractères pour reconstruire la caractère original
                        var nCaractDecode = 0;
                        //Indique si traitement termine
                        var bFin = false;
                        for (var i = 0; (!bFin) && (i < NUMCARAC); i++, nIndiceURL++) {
                            // NUMCARAC défini au début
                            while (pszURL[nIndiceURL] == "%") { // On ignore les caractère % du début et du milieu
                                nIndiceURL++;
                            }
                            nCaractDecode <<= 4; // On decale la valeur actuelle
                            if (byBYTE(pszURL[nIndiceURL]) >= byBYTE("0") && byBYTE(pszURL[nIndiceURL]) <= byBYTE("9")) // Et on met la valeur decodé
                             {
                                nCaractDecode = nCaractDecode + byBYTE(pszURL[nIndiceURL]) - byBYTE("0");
                            }
                            else if (byBYTE(pszURL[nIndiceURL]) >= byBYTE("A") && byBYTE(pszURL[nIndiceURL]) <= byBYTE("Z")) // Et on met la valeur decodé
                             {
                                nCaractDecode = nCaractDecode + 10 + byBYTE(pszURL[nIndiceURL]) - byBYTE("A");
                            } //PAD le 22/12/2011 pour TB~#72580 : 'z' comme borne au lieu de 'a'
                            else if (byBYTE(pszURL[nIndiceURL]) >= byBYTE("a") && byBYTE(pszURL[nIndiceURL]) <= byBYTE("z")) // Et on met la valeur decodé
                             {
                                nCaractDecode = nCaractDecode + 10 + byBYTE(pszURL[nIndiceURL]) - byBYTE("a");
                            }
                            // GP 31/08/2006 : Si la chaine contient des % suivi de zéro binaires la fonction de calcul de longueur stoppe dessus
                            // donc il faut s'arreter aussi
                            else if (nIndiceURL >= nTailleURL) {
                                // Normalement on ne passe jamais ici
                                bFin = true;
                            }
                            // SInon on ne fait rien
                        }
                        //Ajout caractere encode
                        pszURLDecodee += String.fromCharCode(nCaractDecode);
                        // Traitement termine ?
                        if (bFin) {
                            //Oui => on renvoie l'URL decodee
                            return pszURLDecodee;
                        }
                    }
                    else // Les caractères n'y sont pas... On évite les pb et on ignore le '%'
                     {
                        // GP 31/08/2006 : Si la chaine contient des % suivi de zéro binaires la fonction de calcul de longueur stoppe dessus
                        // donc il faut s'arreter aussi
                        return pszURLDecodee;
                    }
                    break;
                case "+": // Pour compatibilité : espace codé par '+'
                    pszURLDecodee += " ";
                    nIndiceURL++;
                    break;
                default: // caractères communs HTTP/ANSI
                    pszURLDecodee += pszURL[nIndiceURL++]; // copie du caractère et passage au suivant
                    break;
            }
        }
        // Et renvoi la chaine
        return pszURLDecodee;
    }
    ;
    // Allocation d'un encodeur
    // le libérer par un deleteRCV
    function pclGetEncodeur(nAlgoEncodage) {
        switch (nAlgoEncodage) {
            case 0 /* EEncodeAucun */:
                return null;
            case 1 /* EEncodePCS */:
                return new CEncodeBase64PCS();
            case 2 /* EEncodeBASE64 */:
                return new CEncodeBase64();
            //Base 64 sans retour chariot
            case 11 /* EEncodeBASE64SansRC */:
                return new CEncodeBase64SansRC();
            //Base 64 URL
            case 5 /* EEncodeBASE64URL */:
                return new CEncodeBase64URL();
            //Base 85
            case 6 /* EEncodeBASE85 */:
                return new CEncodeBase85();
            case 4 /* EEncodeUUEncodeStandard */: // UUEncode correct, on utilise une nouvelle valeur pour ne pas casser la fonction Crypte existante
                return new CEncodeUUEncodeStandard();
        }
        return null;
    }
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Indique si l'encodage necessite une conversion UTF-8
    // Entrée :	nEncodage	Encodage
    // Sortie :	TRUE si encodage nécessite conversion UTF-8, FALSE sinon
    function bEncodageUTF8(nEncodage) {
        //Si l'encodage est :
        switch (nEncodage) {
            //Un encodage avec conversion UTF-8 :
            case 8 /* EEncodeURLDepuisVersAnsi */:
            case 9 /* EEncodeURLDepuisVersUnicode */:
                //Conversion UTF-8
                return true;
            //Un autre encodage :
            default:
                //Pas de conversion UTF-8
                return false;
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Syntaxe : 
    //	0 > URLEncode(<URL>)
    //	1 > URLEncode(<URL>,<Format d'encodage>)
    function URLEncode(pszURL, nEncodage) {
        if (nEncodage === void 0) { nEncodage = 7 /* EEncodeURLDepuisVersUTF8 */; }
        // Chaîne vide : on s'évite du travail et des problèmes (SetUtilLength qui asserte avec une taille de 0 car on n'a pas alloué le buffer) en sortant de suite
        if (pszURL == "") {
            return "";
        }
        // Conversion UTF-8 nécessaire ?
        if (bEncodageUTF8(nEncodage)) {
            //Oui => conversion UTF-8
            pszURL = unescape(encodeURIComponent(pszURL));
        }
        // Encodage de l'URL
        // On n'oublie pas de définir la taille finale de URLEncodee au cas ou la taille calculée précedement serai fausse
        // Cela n'est théoriquement pas possible mais cela ne coute rien
        var URLEncodee = EncodeURL(pszURL, false, nEncodage == 10 /* EEncodeURLParametre */);
        // Et retour
        return URLEncodee;
    }
    StdEncode.URLEncode = URLEncode;
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Indique si encodage URL
    // Entrée :	eEncodage
    // Sortie : TRUE si encodage URL, FALSE sinon
    function bEncodageURL(nEncodage) {
        //Si l'encodage est :
        switch (nEncodage) {
            //Un encodage URL :
            case 7 /* EEncodeURLDepuisVersUTF8 */:
            case 8 /* EEncodeURLDepuisVersAnsi */:
            case 9 /* EEncodeURLDepuisVersUnicode */:
            case 10 /* EEncodeURLParametre */:
                //C'est un encodage URL
                return true;
            //Un autre encodage :
            default:
                //Ce n'est pas un encodage URL
                return false;
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Encodage corrige d'un encodage donne
    // Entree :	eEncodage
    // Sortie : Encodage corrige
    function eEncodageCorrige(eEncodage) {
        //Encodage corrige
        return ((eEncodage == 3 /* EEncodeUUEncode */) ? 4 /* EEncodeUUEncodeStandard */ : eEncodage);
    }
    var UU_LONGUEUR_LIGNE = 20; // Nombre de blocs de 4 caractères par ligne de texte encodé
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Encoder une chaîne
    function ChaineEncode(clSource, nAlgoEncodage) {
        // On encode le buffer source (sauf le 0 binaire) et on alloue la chaîne destination
        // Ce faisant, on récupère la longueur de la chaîne codée (sans compter le zéro binaire)
        var pclEncodeur = pclGetEncodeur(nAlgoEncodage);
        if (pclEncodeur != null) {
            // On renvoie la chaîne codée
            return pclEncodeur.sEncode(clSource, UU_LONGUEUR_LIGNE);
        }
        //pas d'encodage
        return "";
    }
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Syntaxe : 
    //	0 > Encode(<Chaîne ou buffer à encoder>)
    //	1 > Encode(<Chaîne ou buffer à encoder>,<Format d'encodage>)
    function Encode(pstChaineSrc, nAlgoEncodage) {
        if (nAlgoEncodage === void 0) { nAlgoEncodage = 2 /* EEncodeBASE64 */; }
        //Encodage URL ?
        if (bEncodageURL(nAlgoEncodage)) {
            //Oui => encodage URL
            return URLEncode(pstChaineSrc, nAlgoEncodage);
        }
        else {
            //Non => autre encodage
            return ChaineEncode(pstChaineSrc, eEncodageCorrige(nAlgoEncodage));
        }
    }
    StdEncode.Encode = Encode;
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Syntaxe :
    // 0 > URLDecode(<URL>)
    // 1 > URLDécode(<URL>,<Format de décodage>)
    function URLDecode(pszURL, nEncodage) {
        if (nEncodage === void 0) { nEncodage = 7 /* EEncodeURLDepuisVersUTF8 */; }
        // Chaîne vide : on s'évite du travail et des problèmes (SetUtilLength qui asserte avec une taille de 0 car on n'a pas alloué le buffer) en sortant de suite
        if (pszURL == "") {
            return "";
        }
        // Chaine qui recevra la chaîne décodée
        var czURLDecodee = DecodeURL(pszURL);
        // Conversion depuis UTF-8 nécessaire ?
        if (bEncodageUTF8(nEncodage)) {
            //Oui => depuis conversion UTF-8
            czURLDecodee = decodeURIComponent(escape(czURLDecodee));
        }
        return czURLDecodee;
    }
    StdEncode.URLDecode = URLDecode;
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Décoder une chaîne
    function ChaineDecode(pszSource, nAlgoEncodage) {
        var pclDecodeur = pclGetEncodeur(nAlgoEncodage);
        if (pclDecodeur == null) {
            return "";
        }
        // On décode la chaîne source et on alloue le buffer destination
        // Ce faisant, on récupère la taille en octets du buffer décodé
        return pclDecodeur.sDecode(pszSource);
    }
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Syntaxe : 
    //	0 > Décode(<Chaîne à décoder>)
    //	1 > Décode(<Chaîne à décoder>,<Format d'encodage>)
    function Decode(pstChaineSrc, nAlgoEncodage) {
        if (nAlgoEncodage === void 0) { nAlgoEncodage = 2 /* EEncodeBASE64 */; }
        //Décodage URL ?
        if (bEncodageURL(nAlgoEncodage)) {
            //Oui => décodage URL
            return URLDecode(pstChaineSrc, nAlgoEncodage);
        }
        else {
            //Non => autre décodage
            return ChaineDecode(pstChaineSrc, eEncodageCorrige(nAlgoEncodage));
        }
    }
    StdEncode.Decode = Decode;
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Syntaxe : 
    //	0 > UUEncode(<Chaine>)
    function UUEncode(pstChaineSrc) {
        return ChaineEncode(pstChaineSrc, 4 /* EEncodeUUEncodeStandard */);
    }
    StdEncode.UUEncode = UUEncode;
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Syntaxe : 
    //	0 > UUDécode(<Chaine>)
    function UUDecode(pstChaineSrc) {
        return ChaineDecode(pstChaineSrc, 4 /* EEncodeUUEncodeStandard */);
    }
    StdEncode.UUDecode = UUDecode;
})(StdEncode || (StdEncode = {}));
clWDStd.VersPressePapier = function VersPressePapier(oChaine) {
    var sChaine = String(oChaine);
    //On crée un textarea dans le document
    var textArea = document.createElement("textarea");
    // GP 24/06/2020 : QW326855 : Un appel de VersPressePapier déclenche le défilement de la page (car en fait la page grandit puis réduit).
    // L'idée est de placer l'élément en fixed + (0, 0) pour ne pas faire de défilement.
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.position = "fixed";
    textArea.value = sChaine;
    document.body.appendChild(textArea);
    //On lui donne le focus + sélection
    textArea.focus();
    textArea.select();
    //Appel de "copy"
    try {
        return document.execCommand('copy');
    }
    catch (err) {
        return false;
    }
    finally {
        // On supprime le textarea temporaire
        document.body.removeChild(textArea);
    }
};
var StdPaysContinent;
(function (StdPaysContinent) {
    //Infos continent
    var clINFO_CONTINENT = /** @class */ (function () {
        //Constructeur
        function clINFO_CONTINENT(m_eContinent, //Identifiant continent
        m_sRessourceLibelle //Ressource libellé
        ) {
            this.m_eContinent = m_eContinent;
            this.m_sRessourceLibelle = m_sRessourceLibelle;
        }
        return clINFO_CONTINENT;
    }());
    //Liste continents
    var gstTabListeContinent = [
        new clINFO_CONTINENT("AF" /* eAfrique */, WDSTD_CONST.CONTINENT.AFRIQUE),
        new clINFO_CONTINENT("NA" /* eAmeriqueNord */, WDSTD_CONST.CONTINENT.AMERIQUE_DU_NORD),
        new clINFO_CONTINENT("SA" /* eAmeriqueSud */, WDSTD_CONST.CONTINENT.AMERIQUE_DU_SUD),
        new clINFO_CONTINENT("AN" /* eAntarctique */, WDSTD_CONST.CONTINENT.ANTARCTIQUE),
        new clINFO_CONTINENT("AS" /* eAsie */, WDSTD_CONST.CONTINENT.ASIE),
        new clINFO_CONTINENT("EU" /* eEurope */, WDSTD_CONST.CONTINENT.EUROPE),
        new clINFO_CONTINENT("OC" /* eOceanie */, WDSTD_CONST.CONTINENT.OCEANIE)
    ];
    //Infos pays
    var clINFO_PAYS = /** @class */ (function () {
        //Constructeur
        function clINFO_PAYS(m_sRessourceLibelle, //Ressource libellé
        m_sCodeAlpha2, //Code alpha sur 2
        m_sCodeAlpha3, //Code alpha sur 3
        m_sCodeNum, //Code numérique
        m_nNation, //Constante nation correspondante
        eCodeContinent, m_sPrefixeNumTel //Préfixe numéro téléphone
        ) {
            this.m_sRessourceLibelle = m_sRessourceLibelle;
            this.m_sCodeAlpha2 = m_sCodeAlpha2;
            this.m_sCodeAlpha3 = m_sCodeAlpha3;
            this.m_sCodeNum = m_sCodeNum;
            this.m_nNation = m_nNation;
            this.m_sPrefixeNumTel = m_sPrefixeNumTel;
            this.m_oInfoContinent = gstTabListeContinent[eCodeContinent];
        }
        return clINFO_PAYS;
    }());
    ;
    //Infos pays
    var gstTabListePays = [
        new clINFO_PAYS(WDSTD_CONST.PAYS.AFGHANISTAN, "AF", "AFG", "004", 0, 4 /* eContinentAsie */, "93"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.AFRIQUE_DU_SUD, "ZA", "ZAF", "710", 42, 0 /* eContinentAfrique */, "27"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ALAND_ILES, "AX", "ALA", "248", 8, 5 /* eContinentEurope */, "358"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ALBANIE, "AL", "ALB", "008", 0, 5 /* eContinentEurope */, "355"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ALGERIE, "DZ", "DZA", "012", 19, 0 /* eContinentAfrique */, "213"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ALLEMAGNE, "DE", "DEU", "276", 1, 5 /* eContinentEurope */, "49"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ANDORRE, "AD", "AND", "020", 45, 5 /* eContinentEurope */, "376"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ANGOLA, "AO", "AGO", "024", 14, 0 /* eContinentAfrique */, "244"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ANGUILLA, "AI", "AIA", "660", 3, 1 /* eContinentAmeriqueNord */, "1264"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ANTARCTIQUE, "AQ", "ATA", "010", 5, 3 /* eContinentAntarctique */, "672"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ANTIGUA_ET_BARBUDA, "AG", "ATG", "028", 3, 1 /* eContinentAmeriqueNord */, "1268"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ARABIE_SAOUDITE, "SA", "SAU", "682", 19, 4 /* eContinentAsie */, "966"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ARGENTINE, "AR", "ARG", "032", 7, 2 /* eContinentAmeriqueSud */, "54"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ARMENIE, "AM", "ARM", "051", 0, 4 /* eContinentAsie */, "374"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ARUBA, "AW", "ABW", "533", 12, 1 /* eContinentAmeriqueNord */, "297"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.AUSTRALIE, "AU", "AUS", "036", 4, 6 /* eContinentOceanie */, "61"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.AUTRICHE, "AT", "AUT", "040", 1, 5 /* eContinentEurope */, "43"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.AZERBAIDJAN, "AZ", "AZE", "031", 0, 4 /* eContinentAsie */, "994"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BAHAMAS, "BS", "BHS", "044", 2, 1 /* eContinentAmeriqueNord */, "1242"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BAHREIN, "BH", "BHR", "048", 19, 4 /* eContinentAsie */, "973"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BANGLADESH, "BD", "BGD", "050", 43, 4 /* eContinentAsie */, "880"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BARBADE, "BB", "BRB", "052", 3, 1 /* eContinentAmeriqueNord */, "1246"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BELARUS, "BY", "BLR", "112", 44, 5 /* eContinentEurope */, "375"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BELGIQUE, "BE", "BEL", "056", 5, 5 /* eContinentEurope */, "32"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BELIZE, "BZ", "BLZ", "084", 3, 1 /* eContinentAmeriqueNord */, "501"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BENIN, "BJ", "BEN", "204", 5, 0 /* eContinentAfrique */, "229"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BERMUDES, "BM", "BMU", "060", 3, 1 /* eContinentAmeriqueNord */, "1441"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BHOUTAN, "BT", "BTN", "064", 0, 4 /* eContinentAsie */, "975"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BOLIVIE_L_ETAT_PLURINATIONAL_DE, "BO", "BOL", "068", 7, 2 /* eContinentAmeriqueSud */, "591"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BONAIRE_SAINT_EUSTACHE_ET_SABA, "BQ", "BES", "535", 12, 1 /* eContinentAmeriqueNord */, "599"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BOSNIE_HERZEGOVINE, "BA", "BIH", "070", 25, 5 /* eContinentEurope */, "387"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BOTSWANA, "BW", "BWA", "072", 3, 0 /* eContinentAfrique */, "267"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BOUVET_ILE, "BV", "BVT", "074", 13, 3 /* eContinentAntarctique */, "47"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BRESIL, "BR", "BRA", "076", 15, 2 /* eContinentAmeriqueSud */, "55"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BRUNEI_DARUSSALAM, "BN", "BRN", "096", 0, 4 /* eContinentAsie */, "673"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BULGARIE, "BG", "BGR", "100", 21, 5 /* eContinentEurope */, "359"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BURKINA_FASO, "BF", "BFA", "854", 5, 0 /* eContinentAfrique */, "226"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.BURUNDI, "BI", "BDI", "108", 5, 0 /* eContinentAfrique */, "257"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CAIMANES_ILES, "KY", "CYM", "136", 3, 1 /* eContinentAmeriqueNord */, "1345"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CAMBODGE, "KH", "KHM", "116", 0, 4 /* eContinentAsie */, "855"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CAMEROUN, "CM", "CMR", "120", 5, 0 /* eContinentAfrique */, "237"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CANADA, "CA", "CAN", "124", 9, 1 /* eContinentAmeriqueNord */, "1"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CAP_VERT, "CV", "CPV", "132", 14, 0 /* eContinentAfrique */, "238"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CENTRAFRICAINE_REPUBLIQUE, "CF", "CAF", "140", 5, 0 /* eContinentAfrique */, "236"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CHILI, "CL", "CHL", "152", 7, 2 /* eContinentAmeriqueSud */, "56"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CHINE, "CN", "CHN", "156", 23, 4 /* eContinentAsie */, "86"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CHYPRE, "CY", "CYP", "196", 27, 4 /* eContinentAsie */, "357"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.COCOS_KEELING_ILES, "CC", "CCK", "166", 4, 4 /* eContinentAsie */, "61"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.COLOMBIE, "CO", "COL", "170", 7, 2 /* eContinentAmeriqueSud */, "57"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.COMORES, "KM", "COM", "174", 5, 0 /* eContinentAfrique */, "269"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CONGO, "CG", "COG", "178", 5, 0 /* eContinentAfrique */, "242"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CONGO_RD, "CD", "COD", "180", 5, 0 /* eContinentAfrique */, "243"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.COREE_DU_NORD, "KP", "PRK", "408", 24, 4 /* eContinentAsie */, "850"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.COREE_REPUBLIQUE_DE, "KR", "KOR", "410", 24, 4 /* eContinentAsie */, "82"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.COSTA_RICA, "CR", "CRI", "188", 7, 1 /* eContinentAmeriqueNord */, "506"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.COTE_D_IVOIRE, "CI", "CIV", "384", 5, 0 /* eContinentAfrique */, "225"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CROATIE, "HR", "HRV", "191", 25, 5 /* eContinentEurope */, "385"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CUBA, "CU", "CUB", "192", 7, 1 /* eContinentAmeriqueNord */, "53"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.CURACAO, "CW", "CUW", "531", 12, 1 /* eContinentAmeriqueNord */, "599"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.DANEMARK, "DK", "DNK", "208", 6, 5 /* eContinentEurope */, "45"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.DJIBOUTI, "DJ", "DJI", "262", 5, 0 /* eContinentAfrique */, "253"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.DOMINICAINE_REPUBLIQUE, "DO", "DOM", "214", 7, 1 /* eContinentAmeriqueNord */, "1809"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.DOMINIQUE, "DM", "DMA", "212", 3, 1 /* eContinentAmeriqueNord */, "1767"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.EGYPTE, "EG", "EGY", "818", 19, 0 /* eContinentAfrique */, "20"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.EL_SALVADOR, "SV", "SLV", "222", 7, 1 /* eContinentAmeriqueNord */, "503"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.EMIRATS_ARABES_UNIS, "AE", "ARE", "784", 19, 4 /* eContinentAsie */, "971"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.EQUATEUR, "EC", "ECU", "218", 7, 2 /* eContinentAmeriqueSud */, "593"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ERYTHREE, "ER", "ERI", "232", 19, 0 /* eContinentAfrique */, "291"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ESPAGNE, "ES", "ESP", "724", 7, 5 /* eContinentEurope */, "34"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ESTONIE, "EE", "EST", "233", 26, 5 /* eContinentEurope */, "372"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ETATS_FEDERES_DE_MICRONESIE, "FM", "FSM", "583", 2, 6 /* eContinentOceanie */, "691"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ETATS_UNIS, "US", "USA", "840", 2, 1 /* eContinentAmeriqueNord */, "1"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ETHIOPIE, "ET", "ETH", "231", 0, 0 /* eContinentAfrique */, "251"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.FALKLAND_ILES_MALVINAS, "FK", "FLK", "238", 3, 2 /* eContinentAmeriqueSud */, "500"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.FEROE_ILES, "FO", "FRO", "234", 6, 5 /* eContinentEurope */, "298"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.FIDJI, "FJ", "FJI", "242", 3, 6 /* eContinentOceanie */, "679"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.FINLANDE, "FI", "FIN", "246", 8, 5 /* eContinentEurope */, "358"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.FRANCE, "FR", "FRA", "250", 5, 5 /* eContinentEurope */, "33"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GABON, "GA", "GAB", "266", 5, 0 /* eContinentAfrique */, "241"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GAMBIE, "GM", "GMB", "270", 3, 0 /* eContinentAfrique */, "220"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GEORGIE, "GE", "GEO", "268", 0, 4 /* eContinentAsie */, "995"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GEORGIE_DU_SUD_ET_LES_ILES_SANDWICH_DU_SU, "GS", "SGS", "239", 3, 4 /* eContinentAsie */, "500"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GHANA, "GH", "GHA", "288", 3, 0 /* eContinentAfrique */, "233"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GIBRALTAR, "GI", "GIB", "292", 3, 5 /* eContinentEurope */, "350"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GRECE, "GR", "GRC", "300", 27, 5 /* eContinentEurope */, "30"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GRENADE, "GD", "GRD", "308", 3, 1 /* eContinentAmeriqueNord */, "1473"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GROENLAND, "GL", "GRL", "304", 6, 1 /* eContinentAmeriqueNord */, "299"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUADELOUPE, "GP", "GLP", "312", 5, 1 /* eContinentAmeriqueNord */, "590"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUAM, "GU", "GUM", "316", 2, 4 /* eContinentAsie */, "1671"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUATEMALA, "GT", "GTM", "320", 7, 1 /* eContinentAmeriqueNord */, "502"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUERNESEY, "GG", "GGY", "831", 3, 5 /* eContinentEurope */, "44"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUINEE, "GN", "GIN", "324", 5, 0 /* eContinentAfrique */, "224"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUINEE_EQUATORIALE, "GQ", "GNQ", "226", 7, 0 /* eContinentAfrique */, "240"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUINEE_BISSAU, "GW", "GNB", "624", 5, 0 /* eContinentAfrique */, "245"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUYANA, "GY", "GUY", "328", 3, 2 /* eContinentAmeriqueSud */, "592"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.GUYANE_FRANCAISE, "GF", "GUF", "254", 5, 2 /* eContinentAmeriqueSud */, "594"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.HAITI, "HT", "HTI", "332", 5, 1 /* eContinentAmeriqueNord */, "509"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.HEARD_ILE_ET_MCDONALD_ILES, "HM", "HMD", "334", 4, 3 /* eContinentAntarctique */, "672"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.HONDURAS, "HN", "HND", "340", 7, 1 /* eContinentAmeriqueNord */, "504"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.HONG_KONG, "HK", "HKG", "344", 23, 4 /* eContinentAsie */, "852"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.HONGRIE, "HU", "HUN", "348", 29, 5 /* eContinentEurope */, "36"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILE_CHRISTMAS, "CX", "CXR", "162", 4, 4 /* eContinentAsie */, "61"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILE_DE_MAN, "IM", "IMN", "833", 3, 5 /* eContinentEurope */, "44"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILE_NORFOLK, "NF", "NFK", "574", 4, 6 /* eContinentOceanie */, "6723"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILES_COOK, "CK", "COK", "184", 3, 6 /* eContinentOceanie */, "682"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILES_MARIANNES_DU_NORD, "MP", "MNP", "580", 2, 6 /* eContinentOceanie */, "1670"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILES_MINEURES_ELOIGNEES_DES_ETATS_UNIS, "UM", "UMI", "581", 2, 1 /* eContinentAmeriqueNord */, "699"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILES_TURKS_ET_CAIQUES, "TC", "TCA", "796", 3, 1 /* eContinentAmeriqueNord */, "1649"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILES_VIERGES_BRITANNIQUES, "VG", "VGB", "092", 3, 1 /* eContinentAmeriqueNord */, "1284"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ILES_VIERGES_DES_ETATS_UNIS, "VI", "VIR", "850", 2, 1 /* eContinentAmeriqueNord */, "1340"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.INDE, "IN", "IND", "356", 50, 4 /* eContinentAsie */, "91"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.INDONESIE, "ID", "IDN", "360", 46, 4 /* eContinentAsie */, "62"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.IRAN_REPUBLIQUE_ISLAMIQUE_D_, "IR", "IRN", "364", 0, 4 /* eContinentAsie */, "98"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.IRAQ, "IQ", "IRQ", "368", 19, 4 /* eContinentAsie */, "964"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.IRLANDE, "IE", "IRL", "372", 30, 5 /* eContinentEurope */, "353"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ISLANDE, "IS", "ISL", "352", 10, 5 /* eContinentEurope */, "354"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ISRAEL, "IL", "ISR", "376", 28, 4 /* eContinentAsie */, "972"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ITALIE, "IT", "ITA", "380", 11, 5 /* eContinentEurope */, "39"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.JAMAIQUE, "JM", "JAM", "388", 3, 1 /* eContinentAmeriqueNord */, "1876"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.JAPON, "JP", "JPN", "392", 31, 4 /* eContinentAsie */, "81"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.JERSEY, "JE", "JEY", "832", 3, 5 /* eContinentEurope */, "44"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.JORDANIE, "JO", "JOR", "400", 19, 4 /* eContinentAsie */, "962"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.KAZAKHSTAN, "KZ", "KAZ", "398", 16, 4 /* eContinentAsie */, "7"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.KENYA, "KE", "KEN", "404", 3, 0 /* eContinentAfrique */, "254"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.KIRGHIZISTAN, "KG", "KGZ", "417", 16, 4 /* eContinentAsie */, "996"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.KIRIBATI, "KI", "KIR", "296", 3, 6 /* eContinentOceanie */, "686"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.KOWEIT, "KW", "KWT", "414", 19, 4 /* eContinentAsie */, "965"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LAO_REPUBLIQUE_DEMOCRATIQUE_POPULAIRE, "LA", "LAO", "418", 0, 4 /* eContinentAsie */, "856"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LESOTHO, "LS", "LSO", "426", 3, 0 /* eContinentAfrique */, "266"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LETTONIE, "LV", "LVA", "428", 32, 5 /* eContinentEurope */, "371"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LIBAN, "LB", "LBN", "422", 19, 4 /* eContinentAsie */, "961"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LIBERIA, "LR", "LBR", "430", 3, 0 /* eContinentAfrique */, "231"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LIBYENNE_JAMAHIRIYA_ARABE, "LY", "LBY", "434", 19, 0 /* eContinentAfrique */, "218"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LIECHTENSTEIN, "LI", "LIE", "438", 1, 5 /* eContinentEurope */, "423"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LITUANIE, "LT", "LTU", "440", 33, 5 /* eContinentEurope */, "370"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.LUXEMBOURG, "LU", "LUX", "442", 1, 5 /* eContinentEurope */, "352"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MACAO, "MO", "MAC", "446", 23, 4 /* eContinentAsie */, "853"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MACEDOINE, "MK", "MKD", "807", 47, 5 /* eContinentEurope */, "389"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MADAGASCAR, "MG", "MDG", "450", 3, 0 /* eContinentAfrique */, "261"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MALAISIE, "MY", "MYS", "458", 0, 4 /* eContinentAsie */, "60"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MALAWI, "MW", "MWI", "454", 3, 0 /* eContinentAfrique */, "265"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MALDIVES, "MV", "MDV", "462", 0, 4 /* eContinentAsie */, "960"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MALI, "ML", "MLI", "466", 5, 0 /* eContinentAfrique */, "223"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MALTE, "MT", "MLT", "470", 3, 5 /* eContinentEurope */, "356"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MAROC, "MA", "MAR", "504", 19, 0 /* eContinentAfrique */, "212"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MARSHALL_ILES, "MH", "MHL", "584", 3, 6 /* eContinentOceanie */, "692"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MARTINIQUE, "MQ", "MTQ", "474", 5, 1 /* eContinentAmeriqueNord */, "596"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MAURICE, "MU", "MUS", "480", 3, 0 /* eContinentAfrique */, "230"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MAURITANIE, "MR", "MRT", "478", 19, 0 /* eContinentAfrique */, "222"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MAYOTTE, "YT", "MYT", "175", 5, 0 /* eContinentAfrique */, "262"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MEXIQUE, "MX", "MEX", "484", 7, 1 /* eContinentAmeriqueNord */, "52"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MOLDOVA, "MD", "MDA", "498", 35, 5 /* eContinentEurope */, "373"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MONGOLIE, "MN", "MNG", "496", 0, 4 /* eContinentAsie */, "976"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MONTENEGRO, "ME", "MNE", "499", 36, 5 /* eContinentEurope */, "382"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MONTSERRAT, "MS", "MSR", "500", 3, 1 /* eContinentAmeriqueNord */, "1664"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MOZAMBIQUE, "MZ", "MOZ", "508", 14, 0 /* eContinentAfrique */, "258"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.MYANMAR, "MM", "MMR", "104", 0, 4 /* eContinentAsie */, "95"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NAMIBIE, "NA", "NAM", "516", 3, 0 /* eContinentAfrique */, "264"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NAURU, "NR", "NRU", "520", 3, 6 /* eContinentOceanie */, "674"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NEPAL, "NP", "NPL", "524", 0, 4 /* eContinentAsie */, "977"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NICARAGUA, "NI", "NIC", "558", 7, 1 /* eContinentAmeriqueNord */, "505"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NIGER, "NE", "NER", "562", 5, 0 /* eContinentAfrique */, "227"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NIGERIA, "NG", "NGA", "566", 3, 0 /* eContinentAfrique */, "234"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NIUE, "NU", "NIU", "570", 3, 6 /* eContinentOceanie */, "683"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NORVEGE, "NO", "NOR", "578", 13, 5 /* eContinentEurope */, "47"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NOUVELLE_CALEDONIE, "NC", "NCL", "540", 5, 6 /* eContinentOceanie */, "687"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.NOUVELLE_ZELANDE, "NZ", "NZL", "554", 3, 6 /* eContinentOceanie */, "64"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.OMAN, "OM", "OMN", "512", 19, 4 /* eContinentAsie */, "968"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.OUGANDA, "UG", "UGA", "800", 3, 0 /* eContinentAfrique */, "256"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.OUZBEKISTAN, "UZ", "UZB", "860", 0, 4 /* eContinentAsie */, "998"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PAKISTAN, "PK", "PAK", "586", 49, 4 /* eContinentAsie */, "92"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PALAOS, "PW", "PLW", "585", 3, 6 /* eContinentOceanie */, "680"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PALESTINE_GAZA, "PS", "PSE", "275", 19, 4 /* eContinentAsie */, "970"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PANAMA, "PA", "PAN", "591", 7, 1 /* eContinentAmeriqueNord */, "507"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PAPOUASIE_NOUVELLE_GUINEE, "PG", "PNG", "598", 3, 6 /* eContinentOceanie */, "675"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PARAGUAY, "PY", "PRY", "600", 7, 2 /* eContinentAmeriqueSud */, "595"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PAYS_BAS, "NL", "NLD", "528", 12, 5 /* eContinentEurope */, "31"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PEROU, "PE", "PER", "604", 7, 2 /* eContinentAmeriqueSud */, "51"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PHILIPPINES, "PH", "PHL", "608", 3, 4 /* eContinentAsie */, "63"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PITCAIRN, "PN", "PCN", "612", 3, 6 /* eContinentOceanie */, "64"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.POLOGNE, "PL", "POL", "616", 34, 5 /* eContinentEurope */, "48"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.POLYNESIE_FRANCAISE, "PF", "PYF", "258", 5, 6 /* eContinentOceanie */, "689"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PORTO_RICO, "PR", "PRI", "630", 7, 1 /* eContinentAmeriqueNord */, "1787"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PORTUGAL, "PT", "PRT", "620", 14, 5 /* eContinentEurope */, "351"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.PRINCIPAUTE_DE_MONACO, "MC", "MCO", "492", 5, 5 /* eContinentEurope */, "377"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.QATAR, "QA", "QAT", "634", 19, 4 /* eContinentAsie */, "974"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.REUNION, "RE", "REU", "638", 5, 0 /* eContinentAfrique */, "262"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ROUMANIE, "RO", "ROU", "642", 35, 5 /* eContinentEurope */, "40"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ROYAUME_UNI, "GB", "GBR", "826", 3, 5 /* eContinentEurope */, "44"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.RUSSIE_FEDERATION_DE, "RU", "RUS", "643", 16, 5 /* eContinentEurope */, "7"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.RWANDA, "RW", "RWA", "646", 3, 0 /* eContinentAfrique */, "250"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAHARA_OCCIDENTAL, "EH", "ESH", "732", 19, 0 /* eContinentAfrique */, "212"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINT_BARTHELEMY, "BL", "BLM", "652", 5, 1 /* eContinentAmeriqueNord */, "590"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINTE_HELENE_ASCENSION_ET_TRISTAN_DA_CUN, "SH", "SHN", "654", 3, 0 /* eContinentAfrique */, "290"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINTE_LUCIE, "LC", "LCA", "662", 3, 1 /* eContinentAmeriqueNord */, "1758"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINT_KITTS_ET_NEVIS, "KN", "KNA", "659", 3, 1 /* eContinentAmeriqueNord */, "1869"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINT_MAARTIN, "SX", "SXM", "534", 12, 1 /* eContinentAmeriqueNord */, "1721"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINT_MARIN, "SM", "SMR", "674", 11, 5 /* eContinentEurope */, "378"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINT_MARTIN, "MF", "MAF", "663", 5, 1 /* eContinentAmeriqueNord */, "590"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINT_PIERRE_ET_MIQUELON, "PM", "SPM", "666", 5, 1 /* eContinentAmeriqueNord */, "508"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINT_SIEGE_ETAT_DE_LA_CITE_DU_VATICAN, "VA", "VAT", "336", 11, 5 /* eContinentEurope */, "379"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAINT_VINCENT_ET_LES_GRENADINES, "VC", "VCT", "670", 3, 1 /* eContinentAmeriqueNord */, "1784"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SALOMON_ILES, "SB", "SLB", "090", 3, 6 /* eContinentOceanie */, "677"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAMOA, "WS", "WSM", "882", 3, 6 /* eContinentOceanie */, "685"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAMOA_AMERICAINES, "AS", "ASM", "016", 2, 6 /* eContinentOceanie */, "1684"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SAO_TOME_ET_PRINCIPE, "ST", "STP", "678", 14, 0 /* eContinentAfrique */, "239"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SENEGAL, "SN", "SEN", "686", 5, 0 /* eContinentAfrique */, "221"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SERBIE, "RS", "SRB", "688", 36, 5 /* eContinentEurope */, "381"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SEYCHELLES, "SC", "SYC", "690", 3, 0 /* eContinentAfrique */, "248"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SIERRA_LEONE, "SL", "SLE", "694", 3, 0 /* eContinentAfrique */, "232"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SINGAPOUR, "SG", "SGP", "702", 23, 4 /* eContinentAsie */, "65"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SLOVAQUIE, "SK", "SVK", "703", 37, 5 /* eContinentEurope */, "421"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SLOVENIE, "SI", "SVN", "705", 38, 5 /* eContinentEurope */, "386"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SOMALIE, "SO", "SOM", "706", 19, 0 /* eContinentAfrique */, "252"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SOUDAN, "SD", "SDN", "736", 19, 0 /* eContinentAfrique */, "249"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SOUDAN_SUD, "SS", "SSD", "728", 19, 0 /* eContinentAfrique */, "211"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SRI_LANKA, "LK", "LKA", "144", 0, 4 /* eContinentAsie */, "94"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SUEDE, "SE", "SWE", "752", 17, 5 /* eContinentEurope */, "46"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SUISSE, "CH", "CHE", "756", 1, 5 /* eContinentEurope */, "41"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SURINAME, "SR", "SUR", "740", 12, 2 /* eContinentAmeriqueSud */, "597"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SVALBARD_ET_ILE_JAN_MAYEN, "SJ", "SJM", "744", 13, 5 /* eContinentEurope */, "47"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SWAZILAND, "SZ", "SWZ", "748", 3, 0 /* eContinentAfrique */, "268"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.SYRIENNE_REPUBLIQUE_ARABE, "SY", "SYR", "760", 19, 4 /* eContinentAsie */, "963"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TADJIKISTAN, "TJ", "TJK", "762", 0, 4 /* eContinentAsie */, "992"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TAIWAN_PROVINCE_DE_CHINE, "TW", "TWN", "158", 22, 4 /* eContinentAsie */, "886"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TANZANIE_REPUBLIQUE_UNIE_DE, "TZ", "TZA", "834", 3, 0 /* eContinentAfrique */, "255"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TCHAD, "TD", "TCD", "148", 5, 0 /* eContinentAfrique */, "235"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TCHEQUE_REPUBLIQUE, "CZ", "CZE", "203", 18, 5 /* eContinentEurope */, "420"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TERRES_AUSTRALES_FRANCAISES, "TF", "ATF", "260", 5, 3 /* eContinentAntarctique */, "262"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TERRITOIRE_BRITANNIQUE_DE_L_OCEAN_INDIEN, "IO", "IOT", "086", 3, 4 /* eContinentAsie */, "246"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.THAILANDE, "TH", "THA", "764", 39, 4 /* eContinentAsie */, "66"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TIMOR_ORIENTAL, "TL", "TLS", "626", 14, 4 /* eContinentAsie */, "670"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TOGO, "TG", "TGO", "768", 5, 0 /* eContinentAfrique */, "228"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TOKELAU, "TK", "TKL", "772", 3, 6 /* eContinentOceanie */, "690"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TONGA, "TO", "TON", "776", 3, 6 /* eContinentOceanie */, "676"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TRINITE_ET_TOBAGO, "TT", "TTO", "780", 3, 1 /* eContinentAmeriqueNord */, "1868"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TUNISIE, "TN", "TUN", "788", 19, 0 /* eContinentAfrique */, "216"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TURKMENISTAN, "TM", "TKM", "795", 0, 4 /* eContinentAsie */, "993"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TURQUIE, "TR", "TUR", "792", 40, 4 /* eContinentAsie */, "90"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.TUVALU, "TV", "TUV", "798", 3, 6 /* eContinentOceanie */, "688"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.UKRAINE, "UA", "UKR", "804", 0, 5 /* eContinentEurope */, "380"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.URUGUAY, "UY", "URY", "858", 7, 2 /* eContinentAmeriqueSud */, "598"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.VANUATU, "VU", "VUT", "548", 3, 6 /* eContinentOceanie */, "678"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.VENEZUELA_REPUBLIQUE_BOLIVARIENNE_DU, "VE", "VEN", "862", 7, 2 /* eContinentAmeriqueSud */, "58"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.VIET_NAM, "VN", "VNM", "704", 41, 4 /* eContinentAsie */, "84"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.WALLIS_ET_FUTUNA, "WF", "WLF", "876", 5, 4 /* eContinentAsie */, "681"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.YEMEN, "YE", "YEM", "887", 19, 4 /* eContinentAsie */, "967"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ZAMBIE, "ZM", "ZMB", "894", 3, 0 /* eContinentAfrique */, "260"),
        new clINFO_PAYS(WDSTD_CONST.PAYS.ZIMBABWE, "ZW", "ZWE", "716", 3, 0 /* eContinentAfrique */, "263")
    ];
    //Indique si un code ISO est celui d'un pays donné
    //Entrée :	rstInfoPays	Pays dont on vérifie le code ISO
    //			pszCodeISO	Code ISO vérifié
    //Sortie :	TRUE si le code ISO est celui du payx, FALSE sinon
    function _bCodeISOPays(rstInfoPays, pszCodeISO) {
        //Vérification code ISO
        return (pszCodeISO == rstInfoPays.m_sCodeAlpha2) || (pszCodeISO == rstInfoPays.m_sCodeAlpha3) || (pszCodeISO == rstInfoPays.m_sCodeNum);
    }
    //Conversion numérique en code ISO numérique
    //Entrée :	nCodeISO	Code ISO numérique à convertir
    //Sortie :	rclCodeISO	Code ISO numérique
    //			Résultat	Code ISO numérique
    function _cszCodeIsoNumerique(nCodeISO) {
        //code numérique converti en chaîne sur 3 caractères complétée par des 0
        return clWDUtil.sCompleteEntier(nCodeISO, 3);
    }
    //Récupération pays par son nom ou code ISO
    //Entrée :	pszLibelleOuCodeISOPays	Nom ou code ISO du pays recherché
    //Sortie :	Infos pays si trouvé, NULL sinon
    function oGetPaysParNomOuCodeISO(sLibelleOuCodeISOPays) {
        //Recherche pays avec nom ou code ISO donné
        return clWDUtil.oDansTableauFct(gstTabListePays, function (pstInfoPays) {
            //Le code ISO ou le libellé correspond ?
            if (_bCodeISOPays(pstInfoPays, sLibelleOuCodeISOPays) || bCompareChaineSansCasse(pstInfoPays.m_sRessourceLibelle, sLibelleOuCodeISOPays)) {
                //Oui => on a trouvé le pays
                return true;
            }
            return false;
        }, undefined, undefined);
    }
    StdPaysContinent.oGetPaysParNomOuCodeISO = oGetPaysParNomOuCodeISO;
    //Récupération continent par son nom
    //Entrée :	pszContinent	Nom du continent recherché
    //Sortie :	Infos continent si trouvé, NULL sinon
    function oGetContinentParNomOuCode(sContinent) {
        //Recherche pays avec nom ou code ISO donné
        return clWDUtil.oDansTableauFct(gstTabListeContinent, function (pstInfoContinent) {
            if (bCompareChaineSansCasse(pstInfoContinent.m_eContinent, sContinent) || bCompareChaineSansCasse(pstInfoContinent.m_sRessourceLibelle, sContinent)) {
                //Oui => on a trouvé le pays
                return true;
            }
            return false;
        }, undefined, undefined);
    }
    StdPaysContinent.oGetContinentParNomOuCode = oGetContinentParNomOuCode;
    function PaysListe(oContinent) {
        // Création du tableau
        var cltabListePays = [];
        //Indique si on veut tous les pays
        var bTousPays = oContinent === undefined;
        //Libellé ou code continent
        var sLibelleOuCodeContinent;
        //On veut tous les pays ?
        if (!bTousPays) {
            //Non => code ou nom continent ?
            if (typeof oContinent == "string") {
                //Oui => récupération code ou nom continent
                sLibelleOuCodeContinent = oContinent;
            }
            else {
                //Non => récupération code dino continent
                sLibelleOuCodeContinent = oContinent.m_tValeur.m_eContinent;
            }
        }
        //Ajout dinos pays
        for (var _i = 0, gstTabListePays_1 = gstTabListePays; _i < gstTabListePays_1.length; _i++) {
            var pstInfoPays = gstTabListePays_1[_i];
            //On veut tous les pays ou le pays appartient au continent désiré ?
            if (bTousPays || (pstInfoPays.m_oInfoContinent == oGetContinentParNomOuCode(sLibelleOuCodeContinent))) {
                //Oui => on ajoute le pays à la liste
                cltabListePays.push(NSPCS.NSTypes.oCreeDinoPays(pstInfoPays));
            }
        }
        //Liste des pays
        return cltabListePays;
    }
    StdPaysContinent.PaysListe = PaysListe;
    function PaysRecupere(NomOuCodeISO) {
        //Dino pays correspondant au libellé ou code ISO
        return NSPCS.NSTypes.oCreeDinoPays(oGetPaysParNomOuCodeISO((typeof NomOuCodeISO === "string") ? NomOuCodeISO : _cszCodeIsoNumerique(NomOuCodeISO)));
    }
    StdPaysContinent.PaysRecupere = PaysRecupere;
    //Liste des continent
    function ContinentListe() {
        //Liste continents
        var clTabContinent = [];
        //Oui => construction liste continents
        for (var _i = 0, gstTabListeContinent_1 = gstTabListeContinent; _i < gstTabListeContinent_1.length; _i++) {
            var pstInfoContinent = gstTabListeContinent_1[_i];
            //Ajout continent à liste continents
            clTabContinent.push(NSPCS.NSTypes.oCreeDinoContinent(pstInfoContinent));
        }
        //Liste des continents
        return clTabContinent;
    }
    StdPaysContinent.ContinentListe = ContinentListe;
    //Récupération d'un continent
    function ContinentRecupere(sNomOuCodeContinent) {
        //Dino continent correspondant au nom ou code de continent
        return NSPCS.NSTypes.oCreeDinoContinent(oGetContinentParNomOuCode(sNomOuCodeContinent));
    }
    StdPaysContinent.ContinentRecupere = ContinentRecupere;
})(StdPaysContinent || (StdPaysContinent = {}));
// Fonction WL ChaineInverse
clWDStd.sChaineInverse = function sChaineInverse(oChaine) {
    var sRes = "";
    var sChaine = String(oChaine);
    for (var i = sChaine.length - 1; i >= 0; i--) {
        sRes += sChaine[i];
    }
    return sRes;
};
;
// Fonction WL ChaineSupprime
(function () {
    // Suppression des occurrences d'une sous-chaine à l'intérieur d'un chaine
    function __sChaineSupprimeSousChaine(sChaine, sSousChaine, nOption) {
        var sRes = "";
        var sChaineOrigine;
        var sChaineARechercher;
        // pour une recherche sans tenir compte de la casse et des accents
        if ((nOption & 4 /* SANS_CASSE */) != 0) {
            // formate les chaines pour la recherche
            var nOption_1 = 16 /* SansCasse */ | 32 /* Majuscule */ | 4 /* SansAccent */;
            sChaineOrigine = ChaineFormate(sChaine, nOption_1);
            sChaineARechercher = ChaineFormate(sSousChaine, nOption_1);
        }
        // pour une recherche avec casse et accent
        else {
            sChaineOrigine = sChaine;
            sChaineARechercher = sSousChaine;
        }
        var nOffset = 0;
        var nIndex = 0;
        // parcours des occurrences de la sous chaine
        while (nIndex !== -1 && nIndex < sChaineOrigine.length) {
            // recherche de la sous chaine
            nIndex = sChaineOrigine.indexOf(sChaineARechercher, nIndex);
            // trouvé
            if (nIndex !== -1) {
                // si on fait une recherche par mot complet, il faut vérifier si les caractères 
                // qui entourent la sous chaine sont des caractères de ponctuation
                if ((nOption & 2 /* MOT_COMPLET */) === 0 ||
                    (
                    // On est au début de la chaîne ou le caractère précédent est un caractère d'espacement ou ponctuation
                    (nIndex === 0 || clWDStd.__bEstPonctuationOuEspace(sChaineOrigine[nIndex - 1])) &&
                        // Et la sous-chaîne est à la fin ou le caractère suivant la sous-chaîne est un caractère d'espacement ou ponctuation
                        (((nIndex + sChaineARechercher.length) >= sChaineOrigine.length) || clWDStd.__bEstPonctuationOuEspace(sChaineOrigine[nIndex + sChaineARechercher.length])))) {
                    // remplit le résultat
                    sRes += sChaine.substring(nOffset, nIndex);
                    // on se positionne sur la suite
                    nOffset = nIndex + sChaineARechercher.length;
                }
                // positionne pour la recherche suivante
                nIndex += sChaineARechercher.length;
            }
        }
        // ajoute la fin du texte
        if (nOffset < sChaineOrigine.length) {
            sRes += sChaine.substring(nOffset, sChaine.length);
        }
        return sRes;
    }
    // Suppression d'une partie d'une chaine
    function __sChaineSupprime(sChaine, nPosition, nLongeur) {
        // si la position est au delà de la chaine, on retourne la chaine complète
        if (nPosition >= sChaine.length) {
            return sChaine;
        }
        // blinde la position
        if (nPosition < 0) {
            nPosition = 0;
        }
        // blinde la longeur
        if (nPosition + nLongeur > sChaine.length) {
            nLongeur = sChaine.length - nPosition;
        }
        var sRes = "";
        if (nPosition > 0) {
            sRes = sChaine.substring(0, nPosition);
        }
        if (nPosition + nLongeur < sChaine.length) {
            sRes += sChaine.substring(nPosition + nLongeur, sChaine.length);
        }
        return sRes;
    }
    clWDStd.sChaineSupprime = function sChaineSupprime(oChaine, oParam1, oParam2) {
        var sChaine = String(oChaine);
        switch (typeof oParam1) {
            // syntaxe avec une chaine
            case "string":
                var nOption = typeof (oParam2) === "undefined" ? 0 /* SENS_NORMAL */ : parseInt(String(oParam2), 10);
                return __sChaineSupprimeSousChaine(sChaine, oParam1, nOption);
            // syntaxe avec position
            case "number":
                var nPosition = oParam1;
                var nLongeur = parseInt(String(oParam2), 10);
                return __sChaineSupprime(sChaine, nPosition - 1, nLongeur);
            // syntaxe avec plusieurs chaines
            default:
                // si on a un tableau de chaines
                if (clWDTableau.__bEstTableau(oParam1)) {
                    var sRes_1 = sChaine;
                    var nOption_2 = typeof (oParam2) === "undefined" ? 0 /* SENS_NORMAL */ : parseInt(String(oParam2), 10);
                    // supprime chaque chaine du tableau
                    oParam1.forEach(function (oChaineCourante) {
                        sRes_1 = __sChaineSupprimeSousChaine(sRes_1, String(oChaineCourante), nOption_2);
                    });
                    return sRes_1;
                }
        }
        return sChaine;
    };
})();
// Fonction WL ChaineIncrémente
clWDStd.sChaineIncremente = function sChaineIncremente(oChaine, oPosition) {
    // la chaine de départ
    var sChaine = String(oChaine);
    // formatage de l'option
    var nOption;
    if (typeof oPosition !== "number") {
        nOption = -1 /* NON_DEFINI */;
    }
    else {
        nOption = oPosition;
    }
    var nIndice = 0;
    var sChaineSansIndice;
    var sRes = "";
    // si le numérique est à la fin de la chaine
    if (nOption !== 0 /* SENS_NORMAL */) {
        // parcours la chaine de droite à gauche
        var nPos = sChaine.length - 1;
        while (nPos > 0 && EstNumerique(sChaine[nPos]) && sChaine[nPos] !== " ") {
            nPos--;
        }
        // 2 cas :
        // - soit l'option a été fixée en sens inverse et dans ce cas même si la chaine ne contient pas d'indice, il faut en ajouter un ou incrémenter l'indice existant
        // - soit l'option n'a pas été fixée et dans ce cas, si il n'y a pas d'incice à la fin, il ne faut pas en ajouter un maintenant, 
        //	 il faudra vérifier si il y a un indice à incrémenter au début
        if (nOption === 1 /* SENS_INVERSE */ || nPos < sChaine.length - 1) {
            // récupération de l'indice à incrémenter
            nIndice = Number(sChaine.substring(nPos + 1)) + 1;
            // récupération de la chaine sans l'indice
            sChaineSansIndice = sChaine.substring(0, nPos + 1);
            // création de la chaine résultat
            sRes = sChaineSansIndice + nIndice;
        }
    }
    // si le numérique est au début de la chaine ou si pas encore trouvé
    if (nOption === 0 /* SENS_NORMAL */ || (nOption === -1 /* NON_DEFINI */ && sRes == "")) {
        // parcours la chaine de gauche à droite
        var nPos = 0;
        while (nPos < sChaine.length && EstNumerique(sChaine[nPos]) && sChaine[nPos] !== " ") {
            nPos++;
        }
        // si l'option n'est pas spacifié et qu'il n'y a pas de numérique au début
        // (si on est ici, c'et qu'il n'y a pas de numérique à la fin non plus)
        // il faut ajouter un indice à la fin
        if (nOption === -1 /* NON_DEFINI */ && nPos == 0) {
            return sChaine + "1";
        }
        // si il y a un indice
        if (nPos >= 0) {
            // récupération de l'indice à incrémenter
            nIndice = Number(sChaine.substring(0, nPos)) + 1;
            // récupération de la chaine sans l'indice
            sChaineSansIndice = sChaine.substring(nPos);
            // création de la chaine résultat
            sRes = nIndice + sChaineSansIndice;
        }
    }
    // si la chaine ne contient pas de numérique au début ou à la fin
    // on en ajoute un
    if (sRes === "") {
        sRes = sChaine + "1";
    }
    return sRes;
};
// Fonctions WL SansCaractère(), SansCaractèreDroite(), SansCaractèreGauche()
(function () {
    var SANS_GAUCHE = 0x00000001;
    var SANS_DROITE = 0x00000002;
    var SANS_INTERIEUR = 0x00000004;
    function __sSupprimeCaractere(sChaine, sListeCaract, nPosition) {
        var sRes = String(sChaine);
        var sCaract = sListeCaract.replace("\\", "\\\\").replace("]", "\\]").replace("^", "\\^");
        var oRegExp;
        // suppression des caractères à gauche
        if (nPosition & SANS_GAUCHE) {
            oRegExp = new RegExp("^[" + sCaract + "]+");
            sRes = sRes.replace(oRegExp, "");
        }
        // suppression des caractères à droite
        if (nPosition & SANS_DROITE) {
            oRegExp = new RegExp("[" + sCaract + "]+$");
            sRes = sRes.replace(oRegExp, "");
        }
        // suppression des caractères à l'interieur
        if (nPosition & SANS_INTERIEUR) {
            // début de la chaine à ne pas modifier
            var tabDebut = sRes.match(new RegExp("^[" + sCaract + "]+", "g"));
            var nPositionDebut = (tabDebut === null) ? 0 : tabDebut[0].length;
            // fin de la chaine à ne pas modifier 
            var tabFin = sRes.match(new RegExp("[" + sCaract + "]+$", "g"));
            var nPositionFin = (tabFin === null) ? sRes.length : (sRes.length - tabFin[0].length);
            // modification de la chaine intérieure
            if (nPositionFin > nPositionDebut) {
                oRegExp = new RegExp("[" + sCaract + "]", "g");
                sRes = sRes.substring(nPositionDebut, nPositionFin).replace(oRegExp, "");
            }
            // chaine finale
            sRes = ((tabDebut === null) ? "" : tabDebut[0]) + sRes + ((tabFin === null) ? "" : tabFin[0]);
        }
        return sRes;
    }
    // Fonction WL SansCaractère()
    clWDStd.sSansCaractere = function sSansCaractere(oChaine, oListeCaract, oPosition) {
        var nPosition;
        // position par défaut
        if (typeof oPosition === "number") {
            nPosition = oPosition;
        }
        else {
            nPosition = SANS_GAUCHE | SANS_DROITE;
        }
        return __sSupprimeCaractere(String(oChaine), String(oListeCaract), nPosition);
    };
    // Fonction WL SansCaractèreGauche()
    clWDStd.sSansCaractereGauche = function sSansCaractereGauche(oChaine, oListeCaract) {
        return __sSupprimeCaractere(String(oChaine), String(oListeCaract), SANS_GAUCHE);
    };
    // Fonction WL SansCaractèreDroite()
    clWDStd.sSansCaractereDroite = function sSansCaractereDroite(oChaine, oListeCaract) {
        return __sSupprimeCaractere(String(oChaine), String(oListeCaract), SANS_DROITE);
    };
})();
// Fonction WL Tronque()
clWDStd.sTronque = function sTronque(oChaine, oNbCaract, oType) {
    // si le type n'a pas été défini, on prend la valeur par défaut
    // true = nombreDeCaractèreAConserver
    // false = nombreDeCaractèreASupprimer
    var bType = true;
    if (typeof oType === "boolean") {
        bType = oType;
    }
    var sChaine = String(oChaine);
    var nNbCaract = parseInt(String(oNbCaract), 10);
    // calcul de l'indice de fin
    var nIndiceFin = bType ? nNbCaract : sChaine.length - nNbCaract;
    if (nIndiceFin <= 0) {
        return "";
    }
    if (nIndiceFin >= sChaine.length) {
        return sChaine;
    }
    return sChaine.slice(0, nIndiceFin);
};
// Fonction WL TailleCommune
clWDStd.nTailleCommune = function nTailleCommune(eChaine1, eChaine2, eOption) {
    var nOption;
    if (typeof eOption === "number") {
        nOption = eOption;
    }
    else {
        nOption = 0 /* SENS_NORMAL */;
    }
    var sChaine1;
    var sChaine2;
    // pour une recherche sans tenir compte de la casse et des accents
    if ((nOption & 4 /* SANS_CASSE */) != 0) {
        var nOption_3 = 16 /* SansCasse */ | 32 /* Majuscule */ | 4 /* SansAccent */;
        sChaine1 = ChaineFormate(eChaine1, nOption_3);
        sChaine2 = ChaineFormate(eChaine2, nOption_3);
    }
    // pour une recherche avec casse et accent
    else {
        sChaine1 = String(eChaine1);
        sChaine2 = String(eChaine2);
    }
    var nLongueur = 0;
    var nIndice1 = 0;
    var nIndice2 = 0;
    var nLongueur1 = sChaine1.length;
    var nLongueur2 = sChaine2.length;
    // sens de parcours
    var nDecalage = 1;
    if ((nOption & 1 /* SENS_INVERSE */) !== 0) {
        // en sens inverse il faut commence par la fin
        nIndice1 = nLongueur1 - 1;
        nIndice2 = nLongueur2 - 1;
        // décalages en arrière
        nDecalage = -1;
    }
    // parcours les chaines jusqu'à arriver sur la fin de l'une d'entre elles
    while (nLongueur1 > 0 && nLongueur2 > 0) {
        // si les deux caractères sont identiques
        if (sChaine1[nIndice1] === sChaine2[nIndice2]) {
            // caractère suivant (ou précédent)
            nIndice1 += nDecalage;
            nIndice2 += nDecalage;
            nLongueur1--;
            nLongueur2--;
            // un caractère en commun en plus
            nLongueur++;
        }
        else {
            // fin du parcours
            break;
        }
    }
    // en mot complet, il faut supprimer les espaces et les ponctuations qui entourent le résultat
    if ((nOption & 2 /* MOT_COMPLET */) !== 0) {
        // indice de départ pour le parcours
        nIndice1 -= nDecalage;
        // supprime les espaces et les caractères de ponctuation à droites 
        // puis à gauche (d'où la boucle) ou inversement selon le sens
        for (var n = 0; n < 2; n++) {
            // on remonte les caractères, il ne faut pas prendre 
            // en compte les espaces et les caractères de ponctuation
            while (nLongueur > 0 && clWDStd.__bEstPonctuationOuEspace(sChaine1[nIndice1])) {
                // on revient en arrière
                nIndice1 -= nDecalage;
                nLongueur--;
            }
            // change de sens et recommence
            nIndice1 = ((nOption & 1 /* SENS_INVERSE */) !== 0 ? sChaine1.length - 1 : 0);
            nDecalage = -nDecalage;
        }
    }
    return nLongueur;
};
// Fonction WL XMLExtraitChaine
clWDStd.sXMLExtraitChaine = function sXMLExtraitChaine(eCodeXML, eBalise, eIndice, eOption) {
    var snXMLExact = 0x00000001;
    var snXMLIgnoreLaCasse = 0x00000010;
    // formatage des paramètres
    var sCodeXML = String(eCodeXML);
    var sBalise = String(eBalise);
    var nIndice = 1;
    if (typeof eIndice === "number") {
        nIndice = eIndice;
    }
    var nOption = snXMLExact;
    if (typeof eOption == "number") {
        nOption = eOption;
    }
    //indice valide ?
    if (nIndice <= 0) {
        throw new WDErreur(204);
    }
    //on construit les balises à rechercher
    var sTagDebut = "<" + sBalise;
    var sTagFin = "</" + sBalise + ">";
    var sTravail = sCodeXML;
    //gestion de la sensibilité à la casse
    if (nOption & snXMLIgnoreLaCasse) {
        sTravail = sTravail.toUpperCase();
        sTagDebut = sTagDebut.toUpperCase();
        sTagFin = sTagFin.toUpperCase();
    }
    var nPosDebut = -1;
    //recherche de la balise de début
    for (var i = 0; i < nIndice; i++) {
        // on boucle tant que le tag d'ouverture ne nous satisfait pas
        do {
            //position de la balise de début
            nPosDebut = sTravail.indexOf(sTagDebut, nPosDebut + 1);
            if (nPosDebut === -1) {
                break;
            }
            //on récupère le dernier caractère
            var sCarac = sTravail.charAt(nPosDebut + sTagDebut.length);
            //si c'est un espace ou ">" ou "/" (balise sans contenu), on sort, on a trouvé une balise valable
            if (sCarac === " " || sCarac === ">" || sCarac === "/") {
                break;
            }
        } while (true);
        //balise non trouvé
        if (nPosDebut === -1) {
            return "";
        }
    }
    var sResultat = "";
    //balise trouvé
    if (nPosDebut !== -1) {
        //on recherche le fin de la première balise
        var nPosFinDebut = sTravail.indexOf(">", nPosDebut + 1);
        if (nPosFinDebut !== -1) {
            //est ce que juste avant, il y a un "/" => oui, on a une balise autofermante
            if (sTravail.charAt(nPosFinDebut - 1) === "/") {
                //on ne fait rien
            }
            else {
                //on recherche la balise de fin
                var nPosFin = sTravail.indexOf(sTagFin, nPosDebut + 1);
                //balise de fin trouvée ?
                if (nPosFin != -1) {
                    //on extrait ce qu'il y a entre les deux balises
                    sResultat = sCodeXML.substring(nPosFinDebut + 1, nPosFin);
                }
            }
        }
    }
    return sResultat;
};
// Fonctions WL SexagésimalVersDécimal(), DécimalVersSexagésimal()
(function () {
    var STR_DEGRE = "\xB0";
    var TableApostrophes = "'\u2019";
    var nNB_APOSTROPHES = 2; // Nombres d'apostrophes différentes
    // Retourne un tableau de 3 entiers
    // [ Nombre de degres , Nombre de minutes , Nombre de secondes ]
    // Si la première valeur est égale à -1, la fonction a échouée
    function __TabChaineVersSexagesimal(sChaine) {
        // vérifie le type du paramètre
        if (typeof sChaine !== "string") {
            return null;
        }
        // table des indices des symboles 0->°, 1->' , 2-> ''
        var nTableIndice = [-1, -1, -1];
        // initialise l'indice à -1.
        var nIndiceDernierSymboleTrouve = -1;
        // On récupère la position du symbole des degres
        nTableIndice[0] = sChaine.indexOf(STR_DEGRE);
        // recherche une double apostrophe parmi toutes
        var nIndiceApostropheCourant = 0;
        var sDoubleApostrophe = "";
        while (nTableIndice[2] == -1 && nIndiceApostropheCourant < nNB_APOSTROPHES) {
            // On construit la chaine de double apostrophes
            sDoubleApostrophe = TableApostrophes.charAt(nIndiceApostropheCourant);
            sDoubleApostrophe += TableApostrophes.charAt(nIndiceApostropheCourant);
            // On récupère la position du symbole des secondes
            nTableIndice[2] = sChaine.indexOf(sDoubleApostrophe);
            nIndiceApostropheCourant++;
        }
        // si aucune double apostrophe ne correspond, on cherche le caractère double quote
        if (nTableIndice[2] == -1) {
            nTableIndice[2] = sChaine.indexOf("\"");
        }
        nIndiceApostropheCourant = 0;
        // On recherche la position de l'apostrophe parmi toutes les apostrophes
        // Tant que :
        // On a pas trouvé l'apostrophe
        // OU on a trouvé la même position que la double
        // ET on est encore dans la table des apostrophes
        while ((nTableIndice[1] == -1 || nTableIndice[1] == nTableIndice[2]) && nIndiceApostropheCourant < nNB_APOSTROPHES) {
            // On récupère la position du symbole des minutes
            nTableIndice[1] = sChaine.indexOf(TableApostrophes.charAt(nIndiceApostropheCourant));
            nIndiceApostropheCourant++;
        }
        // Ss l'indice des minutes est le même que celui des secondes, on remet celui des minutes à non trouvé
        if (nTableIndice[1] == nTableIndice[2]) {
            nTableIndice[1] = -1;
        }
        if ((nTableIndice[1] != -1 && nTableIndice[0] > nTableIndice[1]) || // Les degrès ont été trouvés après les minutes 
            (nTableIndice[2] != -1 && nTableIndice[0] > nTableIndice[2])) // Les degrès ont été trouvés après les secondes
         {
            // on ne prend pas les degrès en compte
            nTableIndice[0] = -1;
        }
        var TableV = new Array();
        for (var i = 0; i < 3; i++) {
            // init la valeur de la table de resultat
            TableV[i] = 0;
            // si le symbole a été trouvé et est après le premier symbole
            if (nTableIndice[i] != 0 && nTableIndice[i] > nIndiceDernierSymboleTrouve) {
                // si on est bien dans la chaine
                if (nIndiceDernierSymboleTrouve + 1 < sChaine.length) {
                    var sCur = sChaine.substr(nIndiceDernierSymboleTrouve + 1);
                    if (i < 2) {
                        TableV[i] += parseInt(sCur, 10);
                    }
                    else {
                        TableV[i] += parseFloat(sCur);
                    }
                    // si on a un nombre négatif c'est une erreur
                    // ses minutes et les secondes ne peuvent pas dépasser 59
                    if (TableV[i] < 0 || (i > 0 && (TableV[i] >= 60))) {
                        TableV[0] = -1;
                        return TableV;
                    }
                }
                nIndiceDernierSymboleTrouve = nTableIndice[i];
            }
        }
        if (nIndiceDernierSymboleTrouve === -1) {
            TableV[0] = -1;
        }
        return TableV;
    }
    // Fonction WL SexagesimalVersDecimal()
    clWDStd.SexagesimalVersDecimal = function SexagesimalVersDecimal(oChaine) {
        // vérification du format du paramètre
        if (typeof oChaine !== "string") {
            return 0;
        }
        var sChaine = oChaine;
        var nMultiplicateur = 1;
        // si la chaine commence par un '-'
        if (sChaine.charAt(0) === '-') {
            // le multiplicateur est négatif
            nMultiplicateur = -1;
            // avance le pointeur de chaine de 1
            sChaine = sChaine.substr(1);
        }
        // analyse de la chaine donnée pour avoir les degrès, minutes, secondes
        var TableV = __TabChaineVersSexagesimal(sChaine);
        // echec
        if (TableV[0] === -1) {
            return 0;
        }
        var fResultat = 0;
        fResultat += (TableV[0] % 360);
        fResultat += TableV[1] / 60.0;
        fResultat += TableV[2] / 3600.0;
        fResultat *= nMultiplicateur;
        return fResultat;
    };
    // Formate un nombre
    function __sFormatNumber(nValeur, nNbDecimal) {
        var sRes = nValeur.toString();
        var nNbZeroAAjouter = nNbDecimal - sRes.length;
        for (var i = 0; i < nNbZeroAAjouter; i++) {
            sRes = "0" + sRes;
        }
        return sRes;
    }
    // Fonction WL SexagesimalVersDecimal()
    clWDStd.sDecimalVersSexagesimal = function sDecimalVersSexagesimal(oDecimal) {
        // récupération de la valeur à convertir
        var fDecimal = 0;
        switch (typeof oDecimal) {
            case "number":
                fDecimal = oDecimal;
                break;
            case "string":
                fDecimal = parseFloat(oDecimal);
                break;
            default:
                return "";
        }
        var nDegres = 0; // Degrès
        var nMinutes = 0; // Minutes
        var nSecondes = 0; // Secondes
        // buffer du resultat "(-)_ _ _°_ _'_ _''" 11=3+1+2+1+2+2+1
        // prend le modulo sur 360°
        nDegres = (fDecimal < 0 ? Math.ceil(fDecimal) : Math.floor(fDecimal));
        fDecimal -= nDegres;
        nDegres = nDegres % 360;
        var bNegatif = (fDecimal < 0);
        fDecimal = Math.abs(fDecimal);
        if (fDecimal !== 0) {
            fDecimal *= 60;
            nMinutes = (fDecimal < 0 ? Math.ceil(fDecimal) : Math.floor(fDecimal));
            fDecimal -= nMinutes;
            if (fDecimal != 0) {
                fDecimal *= 60;
                // arrondi 
                nSecondes = Math.round(fDecimal);
                // si l'arrondi donne 60 secondes
                if (nSecondes >= 60) {
                    // augmente les minutes
                    nMinutes += 1;
                    // diminue les secondes
                    nSecondes -= 60;
                }
            }
            // si on a plus de 60 minutes
            if (nMinutes >= 60) {
                // augmente les degrès si positif, sinon on les diminue.
                nDegres += (nDegres > 0) ? 1 : -1;
                // diminue les minutes
                nMinutes -= 60;
            }
        }
        // construction de la chaine finale
        var sSigne = bNegatif ? "-" : "";
        if (nDegres < 0) {
            nDegres = -nDegres;
        }
        return sSigne + __sFormatNumber(nDegres, 3) + STR_DEGRE + __sFormatNumber(nMinutes, 2) + "'" + __sFormatNumber(nSecondes, 2) + "''";
    };
})();
// Fonctions WL SexagésimalVersDécimal(), DécimalVersSexagésimal()
(function () {
    var urlProtocole = 0x0001;
    var urlUtilisateur = 0x0002;
    var urlMotDePasse = 0x0004;
    var urlDomaine = 0x0008;
    var urlPort = 0x0010;
    var urlRessource = 0x0020;
    var urlNomRessource = 0x0040;
    var urlExtensionRessource = 0x0080;
    var urlRequete = 0x0100;
    var urlFragment = 0x0200;
    // Ajoute une partie de l'URL à la chaine finale
    function __sAjoutePartie(sChaine, TabRes, nIndice, nPortion, nPartie) {
        // si la portion n'existe pas ou si la portion n'a pas été demandée
        if (nIndice >= TabRes.length || (nPortion & nPartie) === 0 || TabRes[nIndice] === undefined) {
            // retourne la chaine d'origine
            return sChaine;
        }
        // concatène la chaine
        return sChaine + TabRes[nIndice];
    }
    // Fonction WL URLExtraitChemin()
    clWDStd.sURLExtraitChemin = function sURLExtraitChemin(oURL, oPartie) {
        // les paramètres
        var sURL = String(oURL);
        var nPartie = parseInt(String(oPartie), 10);
        if (sURL === "") {
            return "";
        }
        var sRegExp = "^(([^:/@.?#]*):)?\\/?\\/?(([^:/@]*)?:?([^@]*)?@)?([^:/@?#]*)?(:([0-9]*))?((\\/(.*\\/)*)?([^/.?#]+)?(\\.([^/?#]*))?)?(\\?([^#]*))?(#(.*))?$";
        var TabRes = sURL.match(sRegExp);
        if (TabRes === null) {
            return "";
        }
        var sRes = "";
        // protocole
        sRes = __sAjoutePartie(sRes, TabRes, 2, nPartie, urlProtocole);
        // utilisateur
        sRes = __sAjoutePartie(sRes, TabRes, 4, nPartie, urlUtilisateur);
        // mot de passe				    
        sRes = __sAjoutePartie(sRes, TabRes, 5, nPartie, urlMotDePasse);
        // domaine					    
        sRes = __sAjoutePartie(sRes, TabRes, 6, nPartie, urlDomaine);
        // port						    
        sRes = __sAjoutePartie(sRes, TabRes, 8, nPartie, urlPort);
        // chemin ressource			    
        sRes = __sAjoutePartie(sRes, TabRes, 10, nPartie, urlRessource);
        // nom ressource				    
        sRes = __sAjoutePartie(sRes, TabRes, 12, nPartie, urlNomRessource);
        // extension ressource		    
        sRes = __sAjoutePartie(sRes, TabRes, 13, nPartie, urlExtensionRessource);
        // requête					    
        sRes = __sAjoutePartie(sRes, TabRes, 16, nPartie, urlRequete);
        // fragment					    
        sRes = __sAjoutePartie(sRes, TabRes, 18, nPartie, urlFragment);
        return sRes;
    };
})();
// Fonctions WL DonneGUID(), DonneIdentifiant(), DonneUUID() et DonneUUID256()
(function () {
    var gnIdentifiant = 1;
    // options de DonneGUID
    var guidBrut = 0; // suite de 16 caractères hexadécimaux ("CD9FE4B6AE1D448CB157D9EA074726CF")
    var guidBrut256 = 2; // suite de 32 caractères hexadécimaux ("bd05db772a9970c1d91adf8f86a7217ad65c64cf95b8cc6bc10cad69432f0473")
    var guidFormate = 1; // formaté pour un affichage avec des séparateurs ("{CD9FE4B6-AE1D-448c-B157-D9EA074726CF}")
    // Remplace les caractères x et y d'une chaine par des valeurs hexa aléatoires
    function __sGenereGUIDFormat(sFormat) {
        return sFormat.replace(/[xy]/g, function (c) {
            var nValRandom = Math.random() * 16 | 0;
            var nRes = (c == 'x' ? nValRandom : (nValRandom & 0x3 | 0x8));
            return nRes.toString(16);
        });
    }
    // Conversion d'un numérique en hexa
    function __sNum2Hexa4(nNum) {
        // conversion en hexa
        var sRes = nNum.toString(16);
        // complète la chaine avec des 0
        while (sRes.length < 4) {
            sRes = "0" + sRes;
        }
        return sRes;
    }
    // Génération d'un GUID
    function __sGenereGUID(nOption) {
        // si la crypto n'est pas disponible, il faut créer le GUID avec les nombres aléatoires de Math
        if (typeof (window.crypto) == "undefined" || typeof (window.crypto.getRandomValues) == "undefined" || nOption === guidBrut256) {
            // selon l'option de formatage
            switch (nOption) {
                case guidBrut: return __sGenereGUIDFormat("xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx");
                case guidBrut256: return __sGenereGUIDFormat("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
                default:
                case guidFormate: return __sGenereGUIDFormat("xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx");
            }
        }
        var buf = new Uint16Array(8);
        window.crypto.getRandomValues(buf);
        // GUID brut
        if (nOption === guidBrut) {
            return (__sNum2Hexa4(buf[0]) + __sNum2Hexa4(buf[1]) + __sNum2Hexa4(buf[2]) + __sNum2Hexa4(buf[3]) + __sNum2Hexa4(buf[4]) + __sNum2Hexa4(buf[5]) + __sNum2Hexa4(buf[6]) + __sNum2Hexa4(buf[7]));
        }
        // GUID formaté
        return (__sNum2Hexa4(buf[0]) + __sNum2Hexa4(buf[1]) + "-" + __sNum2Hexa4(buf[2]) + "-" + __sNum2Hexa4(buf[3]) + "-" + __sNum2Hexa4(buf[4]) + "-" + __sNum2Hexa4(buf[5]) + __sNum2Hexa4(buf[6]) + __sNum2Hexa4(buf[7]));
    }
    // Fonction WL DonneGUID()
    clWDStd.sDonneGUID = function sDonneGUID(oOption) {
        var nOption = guidFormate;
        if (typeof oOption === "number") {
            nOption = oOption;
        }
        return (nOption === guidFormate ? "{" + __sGenereGUID(nOption) + "}" : __sGenereGUID(nOption));
    };
    // Fonction WL DonneIdentifiant()
    clWDStd.nDonneIdentifiant = function nDonneIdentifiant() {
        return gnIdentifiant++;
    };
    // Fonction WL DonneUUID()
    clWDStd.sDonneUUID = function sDonneUUID() {
        return __sGenereGUID(guidFormate);
    };
    // Fonction WL DonneUUID256()
    clWDStd.sDonneUUID256 = function sDonneUUID256() {
        return __sGenereGUID(guidBrut256);
    };
})();
// Fonction sCalculeCrc16()
(function () {
    // Variables pour le Crc
    var TableCrc16;
    function __tabGetCRC16() {
        if (undefined === TableCrc16) {
            TableCrc16 = new Array(256);
            for (var i = 0; i < 256; i++) {
                var k = i << 8;
                var nCrc = 0;
                for (var j = 0; j < 8; j++) {
                    // si le bit "le plus a gauche" de ( nCrc ^ k ) n'est pas nul (0x80000000 c'est un 1 et 31 0 en binaire)
                    if ((nCrc ^ k) & 0x8000) {
                        nCrc = ((nCrc << 1) ^ 0x1021) & 0xffff;
                    }
                    else {
                        nCrc <<= 1;
                    }
                    k <<= 1;
                }
                TableCrc16[i] = nCrc & 0xffff;
            }
        }
        return TableCrc16;
    }
    function __nGetNextCRC16(tabCRC16, nCRC16) {
        return tabCRC16[(nCRC16 >> 8) & 0xff] ^ ((nCRC16 << 8) & 0xff00);
    }
    // Fonction WL sCalculeCrc16()
    clWDStd.nCalculeCrc16 = function nCalculeCrc16(oValeur) {
        var sValeur = String(oValeur);
        var tabCRC16 = __tabGetCRC16();
        var nCRC16 = 0;
        var nLongueur = sValeur.length;
        for (var i = 0; i < nLongueur; i++) {
            nCRC16 = __nGetNextCRC16(tabCRC16, nCRC16) ^ (sValeur.charCodeAt(i) & 0xff);
        }
        // Force l'update pour le zéro binaire de la chaine qui est calculé par le serveur.
        return __nGetNextCRC16(tabCRC16, nCRC16) /*^ (0 & 0xff)*/;
    };
})();
// Fonction sCalculeCrc32()
(function () {
    // Table associe au polynome 0x04c11db7
    var gTablePolynome = [
        0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
        0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988, 0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,
        0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
        0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
        0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
        0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
        0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
        0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,
        0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
        0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,
        0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E, 0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
        0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
        0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
        0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
        0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
        0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,
        0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
        0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
        0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
        0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,
        0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
        0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79,
        0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236, 0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F,
        0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,
        0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
        0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38, 0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21,
        0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
        0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,
        0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2, 0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB,
        0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,
        0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF,
        0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94, 0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
    ];
    // Fonction sCalculeCrc32()
    clWDStd.nCalculeCrc32 = function nCalculeCrc32(oValeur, oCRCPartiel) {
        if (oCRCPartiel === void 0) { oCRCPartiel = 0; }
        var sValeur = String(oValeur);
        var nCRCPartiel = parseInt(String(oCRCPartiel));
        // Mise à la valeur initiale (0xFFFFFFFF dans le cas d'un nouveau calcul)
        var nCRC = nCRCPartiel ^ 0xFFFFFFFF;
        // Boucle de calcul
        var nLongueur = sValeur.length;
        for (var i = 0; i < nLongueur; i++) {
            nCRC = ((nCRC >> 8) & 0x00FFFFFF) ^ gTablePolynome[sValeur.charCodeAt(i) ^ (nCRC & 0xFF)];
        }
        // Mise à la valeur finale
        nCRC ^= 0xFFFFFFFF;
        // Et Renvoi de cette valeur
        // Comme (x ^ 0xFFFFFFFF) ^ 0xFFFFFFFF = x, on peux facilement réutiliser le résultat du calcul pour le reinjecter en tant que CRC partiel
        return nCRC;
    };
})();
// Fonction NombreEnLettres
(function () {
    //// Chaine de base pour les centimes si la monnaie est spécifiée
    //var _NA_;
    // retourne true si la chaîne commence par une voyelle en français
    function __bInitialeVoyelleFR(sChaine) {
        if (sChaine.length === 0) {
            return false;
        }
        var sCar = sChaine.charAt(0).toLowerCase();
        return (sCar === "a" || sCar === "e" || sCar === "i" || sCar === "o" || sCar === "u" || sCar === "y");
    }
    // Ajoute un espace à une chaine si elle n'est pas vide
    function __sAjouteEspaceSiNonVide(sChaine) {
        if (sChaine !== "") {
            return sChaine + " ";
        }
        return sChaine;
    }
    // Renvoie la chaine de caractères correspondant à un entier inférieur à 1000 en français
    function __sParseEntierInfAMille(nNombre, nPow10) {
        // Variable de resultat
        var sResultat = "";
        // Si on est dans les milliers, et que le nombre est 1
        if (nPow10 === 3 && nNombre === 1) {
            // On renvoi une chaine vide ( on dit "mille" pas "un mille"
            return sResultat;
        }
        // On doit ajouter un s ?
        var bAjouterS = false;
        // Le nombre de dizaine est supérieur à 1 ?
        var bPlusieursDizaines = false;
        // Variable servant aux divisions
        var nResultDiv = 0;
        // Cas particulier des 80 - 90
        var bCasParticulier90 = false;
        // Si on a des centaines
        if (nNombre >= 100) {
            // Nombre de centaines
            nResultDiv = Math.floor(nNombre / 100);
            // On ne dit pas "un cent" mais "cent"
            if (nResultDiv !== 1) {
                // On ajoute le nombre de centaines à la chaine
                sResultat += WDSTD_CONST.UNITES.CHIFFRES[nResultDiv - 1];
                // On a plusieurs centaines
                bAjouterS = true;
            }
            // On ajoute " cent"
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            sResultat += WDSTD_CONST.UNITES.CENT;
            nNombre = nNombre - nResultDiv * 100;
        }
        // Si les dizaines sont plus grandes que 2
        if (nNombre >= 20) {
            // Nombre de dizaines
            nResultDiv = Math.floor(nNombre / 10);
            bAjouterS = false;
            bPlusieursDizaines = true;
            bCasParticulier90 = false;
            // ajoute un s si 80
            if (nResultDiv === 8) {
                bAjouterS = true;
            }
            // traite 9x comme 80 + 1x
            else if (nResultDiv === 9) {
                nResultDiv = 8;
                bCasParticulier90 = true;
            }
            // traite 7x comme 60 + 1x
            else if (nResultDiv === 7) {
                nResultDiv = 6;
            }
            // On ajoute le nom de la dizaine
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            sResultat += WDSTD_CONST.UNITES.DIZAINES[nResultDiv - 2];
            nNombre = nNombre - nResultDiv * 10;
        }
        // Le reste est compris entre 1 et 19
        if (nNombre > 0) {
            if (bPlusieursDizaines) {
                // Si le nombre fini par un ou 11 et n'est pas un cas particulier
                if ((nNombre == 1 || nNombre == 11) && !bCasParticulier90) {
                    sResultat += " et ";
                }
                else {
                    sResultat += "-";
                }
            }
            else {
                sResultat = __sAjouteEspaceSiNonVide(sResultat);
            }
            sResultat += WDSTD_CONST.UNITES.CHIFFRES[nNombre - 1];
            bAjouterS = false;
        }
        // Rien ne suis cent donc on ajoute un "s"
        if (bAjouterS) {
            sResultat += "s";
        }
        return sResultat;
    }
    // Renvoie la chaine de caractères correspondant à un entier inférieur à 1000 en anglais
    function __sParseEntierInfAMilleAG(nNombre, nPow10, bResultatGlobalVide) {
        // Variable de resultat
        var sResultat = "";
        // Le nombre de dizaine est supérieur à 1 ?
        var bPlusieursDizaines = false;
        // Variable servant aux divisions
        var nResultDiv = 0;
        // Si on a des centaines
        if (nNombre >= 100) {
            // Nombre de centaines
            nResultDiv = Math.floor(nNombre / 100);
            // On ajoute le nombre de centaines à la chaine
            sResultat += WDSTD_CONST.UNITES.CHIFFRES[nResultDiv - 1];
            // On ajoute " hundred"
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            sResultat += WDSTD_CONST.UNITES.CENT;
            nNombre = nNombre - nResultDiv * 100;
        }
        // Si il y a déjà des centaines dans la chaine ou que le résultat global n'est pas vide
        // et qu'on est dans les unités
        if ((sResultat !== "" || !bResultatGlobalVide) && nNombre > 0 && nPow10 === 0) {
            // On ajoute " and"
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            sResultat += "and";
        }
        if (nNombre >= 20) {
            // Calcul du nombre de dizaines
            nResultDiv = Math.floor(nNombre / 10);
            bPlusieursDizaines = true;
            // On ajoute le nom de la dizaine
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            sResultat += WDSTD_CONST.UNITES.DIZAINES[nResultDiv - 2];
            nNombre = nNombre - nResultDiv * 10;
        }
        // Le reste est compris entre 1 et 19
        if (nNombre > 0) {
            if (bPlusieursDizaines) {
                sResultat += "-";
            }
            else {
                sResultat = __sAjouteEspaceSiNonVide(sResultat);
            }
            sResultat += WDSTD_CONST.UNITES.CHIFFRES[nNombre - 1];
        }
        return sResultat;
    }
    // Ajoute la valeur du nombre à traiter à la chaine résultat en fonction de la puissance de 10 du nombre à traiter
    function __sParseMillierEtAjouteAuResultat(sResultat, nNombreATraiter, nPow10) {
        var sResultatPartiel = "";
        // Si le nombre est 0 aucune modification du résultat
        if (nNombreATraiter == 0) {
            return ""; // On sort
        }
        // Si le nombre est 1 à 10^3 en français ( cas du 1000 )
        if (_NA_ === 5 && nNombreATraiter === 1 && nPow10 === 3) {
            // On ajoute " mille" au résultat
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            sResultat += WDSTD_CONST.UNITES.MILLIERS[0];
            return sResultat;
        }
        // Français
        if (_NA_ === 5) {
            sResultatPartiel = __sParseEntierInfAMille(nNombreATraiter, nPow10);
        }
        // Anglais
        else {
            // Un nombre a déja été ajouté au contenu ( non vide et différent de la chaine - )
            var bResultatGlobalVide = (sResultat === "" || sResultat === WDSTD_CONST.UNITES.MOINS);
            sResultatPartiel = __sParseEntierInfAMilleAG(nNombreATraiter, nPow10, bResultatGlobalVide);
        }
        // Français
        if (_NA_ === 5) {
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            // On ajoute la chaine
            sResultat += sResultatPartiel;
            // Si on se trouve dans les mille et que la chaine fini par "s" ( cents / quatre-vingts )
            if (nPow10 == 3 && sResultat.charAt(sResultat.length - 1) === "s" && sResultat.lastIndexOf("trois") !== sResultat.length - 5) {
                // On enleve le "s"
                sResultat = sResultat.substr(0, sResultat.length - 1);
            }
            // Si on se trouve au dela des milliers
            if (nPow10 >= 3) {
                // On ajoute les milliers
                sResultat = __sAjouteEspaceSiNonVide(sResultat);
                sResultat += WDSTD_CONST.UNITES.MILLIERS[Math.floor(nPow10 / 3) - 1];
                // Si le nombre est supérieur à 1 et que l'on est au dessus des mille ( car mille invariable )
                if (nNombreATraiter > 1 && nPow10 > 3) {
                    sResultat += "s";
                }
            }
        }
        // Anglais
        else {
            // On ajoute la chaine
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            sResultat += sResultatPartiel;
            // Si on se trouve au dela des milliers
            if (nPow10 > 0) {
                // On ajoute les milliers
                sResultat = __sAjouteEspaceSiNonVide(sResultat);
                sResultat += WDSTD_CONST.UNITES.MILLIERS[Math.floor(nPow10 / 3) - 1];
            }
        }
        return sResultat;
    }
    // Parse toute la partie entiere d'un nombre donnée
    function __sParsePartieEntiere(nNombre) {
        // Si le nombre est 0
        if (nNombre == 0) {
            // On renvoie la chaine zero correspondant à la langue
            return WDSTD_CONST.UNITES.ZERO;
        }
        var sResultat = "";
        // Si c'est un nombre négatif
        if (nNombre < 0) {
            // On met le moins correspondant à la langue dans la chaine
            sResultat = WDSTD_CONST.UNITES.MOINS;
            // On passe nNombre en positif	
            nNombre *= -1;
        }
        // On récupère la puissance de 10 du nombre
        var nPuissance = Math.round(Math.log(nNombre) / Math.LN10);
        // Nombre à traiter
        var nNombreATraiter = 0;
        // Variable de boucle
        // On récupère le plus grand millier du nombre
        var i = Math.floor(nPuissance / 3) * 3;
        var nNombreMilliers = Math.pow(10, i);
        // Traitement principal
        do {
            // Résultat entier de la division
            nNombreATraiter = Math.floor(nNombre / nNombreMilliers);
            // On ajoute le résultat du millier
            sResultat = __sParseMillierEtAjouteAuResultat(sResultat, nNombreATraiter, i);
            // On réduit nNombre au millier inférieur
            nNombre -= nNombreATraiter * nNombreMilliers;
            // On décrémente l'indice
            i = i - 3;
            // On divise le nombre en milliers par 1000 ( on diminue la puissance de 3 )
            nNombreMilliers /= 1000;
        } while (i >= 0 && nNombre !== 0); // Pour tout intervalle de 10^3
        // On renvoie le résultat
        return sResultat;
    }
    // Récupère une chaine de caractères contenant ou non un "(s)"
    function __sDonneMonnaie(sMonnaie, bPluriel) {
        // On cherche la position du (s) dans la chaine
        var nPositionS = sMonnaie.indexOf("(s)");
        // Si on ne l'as pas trouvé
        if (nPositionS == -1) {
            // On renvoie la chaine complète
            return sMonnaie;
        }
        // Variable de résultat
        var sResultat = "";
        // On prend la partie avant le (s)
        sResultat = sMonnaie.substring(0, nPositionS);
        if (bPluriel) {
            // On ajoute le s
            sResultat += "s";
        }
        // On ajoute la partie après le (s)
        sResultat += sMonnaie.substring(nPositionS + 3);
        // On renvoie le résutlat
        return sResultat;
    }
    // Fonction sCalculeCrc32()
    clWDStd.sNombreEnLettres = function sNombreEnLettres(oNombre, oMonnaie, oCentieme) {
        if (oMonnaie === void 0) { oMonnaie = ""; }
        if (oCentieme === void 0) { oCentieme = ""; }
        // paramètres de la fonction
        if (typeof oNombre !== "number") {
            return "";
        }
        var nNombre = oNombre;
        var sMonnaie = String(oMonnaie);
        var sCentieme = String(oCentieme);
        var sResultat = "";
        var sTamponResultat = "";
        // La monnaie a été fournie ?
        var bMonnaieFournie = (sMonnaie !== "");
        // Recup de la partie décimale
        var nPartieDecimale = clWDUtil.oPartieDecimale(nNombre);
        nPartieDecimale = Math.floor((nPartieDecimale * 100) + 0.5);
        // récupération de la partie entière
        nNombre = clWDUtil.oPartieEntiere(nNombre);
        if (nNombre < 0 && nPartieDecimale !== 0) {
            nNombre++;
        }
        // Si la partie décimale est 100
        if (nPartieDecimale === 100) {
            // On ajoute 1 à l'unité et on met la partie décimale à 0
            nNombre += 1;
            nPartieDecimale = 0;
        }
        // On parse la partie entière
        sTamponResultat = __sParsePartieEntiere(nNombre);
        // On ajoute le résultat dans la chaine
        sResultat = sTamponResultat; // "dix"
        // Si l'argument de monnaie a été fourni
        var bPluriel = (nNombre >= 2 || nNombre <= -2);
        // Si la monnaie a été renseignée
        if (bMonnaieFournie) {
            // On ajoute un espace si il le faut
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            // Si la langue est française
            if (_NA_ === 5) {
                // Le nombre n'as pas de partie entière inférieure au million et n'est pas nul
                var bFiniParMillionOuPlus = (nNombre % 1000000 === 0 && nNombre !== 0);
                // La devise commence par une Voyelle ?
                var bDeviseCommenceParVoyelle = (__bInitialeVoyelleFR(sMonnaie));
                // Si le nombre fini par des millions et que la monnaie commence par une voyelle
                if (bFiniParMillionOuPlus && bDeviseCommenceParVoyelle) {
                    // On ajoute d' à la chaine
                    sResultat += "d'";
                }
                // Si le nombre fini par des millions uniquement
                else if (bFiniParMillionOuPlus) {
                    // On ajoute de à la chaine
                    sResultat += "de ";
                }
            }
            // On ajoute la monnaie
            sResultat += __sDonneMonnaie(sMonnaie, bPluriel);
        }
        // Si il n'y a pas de partie décimale on sort
        if (nPartieDecimale === 0) {
            return sResultat;
        }
        // L'argument Monnaie n'a pas été fourni
        if (!bMonnaieFournie) {
            // On ajoute un espace
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            // On ajoute virgule ou point en fonction de la langue
            sResultat += WDSTD_CONST.UNITES.VIRGULE;
        }
        // On parse la partie décimale obtenu ( les centièmes )
        sTamponResultat = __sParsePartieEntiere(nPartieDecimale);
        // Defensif
        if (sTamponResultat === "") {
            return sResultat;
        }
        // Si les centièmes ont été renseignés
        if (sCentieme !== "") {
            // On ajoute un espace
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            // On ajoute et ou and en fonction de la langue
            sResultat += (_NA_ === 5 ? "et" : "and");
        }
        // On ajoute un espace
        sResultat = __sAjouteEspaceSiNonVide(sResultat);
        // On ajoute le résultat dans la chaine
        sResultat += sTamponResultat;
        // Si les centièmes sont spécifiés
        if (sCentieme !== "") {
            // On ajoute un espace
            sResultat = __sAjouteEspaceSiNonVide(sResultat);
            // On ajoute la désignation des centièmes
            sResultat += (__sDonneMonnaie(sCentieme, (nPartieDecimale >= 2)));
        }
        return sResultat;
    };
})();
