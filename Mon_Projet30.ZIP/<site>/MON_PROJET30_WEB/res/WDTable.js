// WDTable.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - La page
///#GLOBALS _PAGE_
// - StdAction.js
///#GLOBALS _JCL _JSL
// - WDUtil.js
///#GLOBALS bIE bIEQuirks nIE bIEQuirks9Max bIEAvec11 bFF bCrm bSfr bEdge bTouch WDStyleCache
// - WDAjax.js
///#GLOBALS clWDAJAXMain
// - WDChamp.js
///#GLOBALS WDChamp
// - WDDrag.js
///#GLOBALS WDDrag WDDragTouch
// - WDTableZRCommun.js
///#GLOBALS clWDTableDefs WDTableColonne WDPopupSaisieTRF WDCelluleSaisie WDSelection WDAffichageColonnes WDTableZRNavigateur WDTableZRCommun WDTableClassique
// - WD.js
///#GLOBALS NSPCS

// Classe representant une requete pour du cache
function WDCacheRequete (oChampTable)
{
	// Table liee a la requete
	this.m_oChampTable = oChampTable;

	// Debut de la requete
	this.m_oDate = new Date();
};

WDCacheRequete.prototype =
{
	// Valeur par defaut des variables : mis dans le prototype
	m_nColonneTri: -1, // Tri demande
	m_nLigne: -1, 	// Ligne modifie
	m_nIdRequeteAJAX: undefined, // Objet de requete AJAX
	sCommandeAjax_LignesTable: "LIGNESTABLE",
	sCommandeAjax_LignesTriTable: "LIGNESTRITABLE",
	sCommandeAjax_ParCourtAP: "PARCOURTAP",
	sCommandeAjax_RechercheTable: "RECHERCHETABLE",
	sCommandeAjax_FiltreTable: "FILTRETABLE",
	sCommandeAjax_AnnuleFiltreTable: "ANNULEFILTRETABLE",
	sCommandeAjax_DeplaceColonne: "DEPLACECOLONNE",
	sCommandeAjax_ModifTable: "MODIFTABLE",
	sParametreAjax_ColonneLien: "WD_TABLE_COL_LIEN_",
	sParametreAjax_Debut: "WD_TABLE_DEBUT_",
	sParametreAjax_Nombre: "WD_TABLE_NOMBRE_",
	sParametreAjax_CleEnreg: "WD_TABLE_CLEENREG_",
	sParametreAjax_CleEnreg_Pos: "WD_TABLE_CLEENREG_POS_",
	sParametreAjax_CleEnregAP: "WD_TABLE_CLEENREGAP_",
	sParametreAjax_CleEnregAP_Pos: "WD_TABLE_CLEENREGAP_POS_",
	sParametreAjax_TriAWP: "WD_TABLE_TRIAWP_",
	sParametreAjax_ColTri: "WD_TABLE_COL_TRI_",
	sParametreAjax_Recherche_Marge: "WD_TABLE_RECHERCHE_MARGE_",
	sParametreAjax_Recherche_Nombre: "WD_TABLE_RECHERCHE_NOMBRE_",
	sParametreAjax_Recherche_Col: "WD_TABLE_RECHERCHE_COL_",
	sParametreAjax_Recherche_Valeur: "WD_TABLE_RECHERCHE_VAL_",
	sParametreAjax_Deplace_Col: "WD_TABLE_DEPLACE_COLONNE_",
	sParametreAjax_Deplace_Pos: "WD_TABLE_DEPLACE_POSITION_",
	sParametreAjax_Filtre_Filtre: "WD_TABLE_FILTRE_FILTRE_",

	// Nom du champ
	_sGetNomChamp: function()
	{
		return encodeURIComponent(this.m_oChampTable.m_sAliasChamp);
	},

	// Contruit le bout de requete supplementaire transmit en AWP
	sConstuitAWP: function(bSelection)
	{
		// Contruit le bout de requete pour la continuation du parcourt en arriere plan dans les pages AWP
		var sRequete = this.sConstuitPosAP();

		// Ajoute le tri courant de la table
		if (clWDAJAXMain.m_bPageAWP)
		{
			if (this.m_oChampTable.m_nColonneTriePre > -1)
			{
				sRequete += "&" + this.sParametreAjax_TriAWP + "=" + encodeURIComponent((this.m_oChampTable.m_bTriCroissantPre ? "+" : "-") + this.m_oChampTable.m_nColonneTriePre);
			}
			var oChampData = this.m_oChampTable.oGetElementByName(document, "_DATA");
			if (oChampData)
			{
				var sData = oChampData.value;
				if (sData && sData.length)
				{
					sRequete += "&" + this._sGetNomChamp() + "_DATA=" + encodeURIComponent(sData);
				}
			}

			// Ajoute la selection de la table : on utilise le champ special ajoute a la page pour transmettre la selection complete au serveur
			// sans perturber le reste
			if (!bSelection)
			{
				var sSelection = clWDAJAXMain.sConstruitValeurChamp(this.m_oChampTable.m_oChampFormulaireSelAWP);
				if (sSelection.length)
				{
					sRequete += "&" + sSelection;
				}
			}
		}

		return sRequete;
	},

	// Contruit le bout de requete pour la continuation du parcourt en arriere plan dans les pages AWP
	sConstuitPosAP: function()
	{
		// Si pas de position : fin
		if (0 === this.m_oChampTable.m_sCleParcourtAP.length)
		{
			return "";
		}

		// Meme si on a fini le parcourt car il faut se replacer sur le serveur

		// Sinon ajoute les informations qui vont bien
		return "&" + this.sParametreAjax_CleEnregAP_Pos + "=" + this.m_oChampTable.m_nNbLignes + "&" + this.sParametreAjax_CleEnregAP + "=" + encodeURIComponent(this.m_oChampTable.m_sCleParcourtAP);
	},

	// Construit la requete pour la recherche dans une table
	sConstuitRequeteRechercheTable: function(nNombre, nMarge, sRecherche)
	{
		//	- Commande AJAX (non specifique)
		var sRequete = this.sCommandeAjax_RechercheTable + "=" + this._sGetNomChamp();
		// Nouvelle serie d'ordres
		sRequete += "&" + this.sParametreAjax_Recherche_Marge + "=" + nMarge;
		sRequete += "&" + this.sParametreAjax_Recherche_Nombre + "=" + nNombre;
		sRequete += "&" + this.sParametreAjax_Recherche_Col + "=" + this.m_nColonneTri;
		sRequete += "&" + this.sParametreAjax_Recherche_Valeur + "=" + encodeURIComponent(sRecherche);

		// Ajoute la position du parcours en AP si besoin
		sRequete += this.sConstuitAWP(false);

		// On renvoie la requete creee
		return sRequete;
	},

	// Construit la requete pour le filtre dans une table
	sConstuitRequeteFiltreTable: function(nNombre, nMarge, nColonneFiltre, nFiltre, sFiltre)
	{
		//	- Commande AJAX (non specifique)
		var sRequete = this.sCommandeAjax_FiltreTable + "=" + this._sGetNomChamp();
		// Nouvelle serie d'ordres
		sRequete += "&" + this.sParametreAjax_Recherche_Marge + "=" + nMarge;
		sRequete += "&" + this.sParametreAjax_Recherche_Nombre + "=" + nNombre;
		// GP 24/09/2013 : A voir s'il ne faut pas donner aussi la colonne tri�e en plus
		sRequete += "&" + this.sParametreAjax_Recherche_Col + "=" + nColonneFiltre;
		sRequete += "&" + this.sParametreAjax_Filtre_Filtre + "=" + nFiltre;
		sRequete += "&" + this.sParametreAjax_Recherche_Valeur + "=" + encodeURIComponent(sFiltre);

		// Ajoute la position du parcours en AP si besoin
		sRequete += this.sConstuitAWP(false);

		// On renvoie la requete creee
		return sRequete;
	},

	// Construit la requete pour le filtre dans une table
	sConstuitRequeteAnnuleFiltreTable: function(nNombre, nMarge, nColonneFiltre)
	{
		//	- Commande AJAX (non specifique)
		var sRequete = this.sCommandeAjax_AnnuleFiltreTable + "=" + this._sGetNomChamp();
		// Nouvelle serie d'ordres
		sRequete += "&" + this.sParametreAjax_Recherche_Marge + "=" + nMarge;
		sRequete += "&" + this.sParametreAjax_Recherche_Nombre + "=" + nNombre;
		// GP 24/09/2013 : A voir s'il ne faut pas donner aussi la colonne tri�e en plus
		sRequete += "&" + this.sParametreAjax_Recherche_Col + "=" + nColonneFiltre;

		// Ajoute la position du parcours en AP si besoin
		sRequete += this.sConstuitAWP(false);

		// On renvoie la requete creee
		return sRequete;
	},

	// Construit la requete pour d�placement des colonnes dans une table
	sConstuitRequeteDeplaceColonneTable: function(nColonne, nPosition)
	{
		//	- Commande AJAX (non specifique)
		var sRequete = this.sCommandeAjax_DeplaceColonne + "=" + this._sGetNomChamp();
		// GP 24/09/2013 : A voir s'il ne faut pas donner aussi la colonne tri�e en plus
		sRequete += "&" + this.sParametreAjax_Deplace_Col + "=" + nColonne;
		sRequete += "&" + this.sParametreAjax_Deplace_Pos + "=" + nPosition;

		// Ajoute la position du parcours en AP si besoin
		sRequete += this.sConstuitAWP(false);

		// On renvoie la requete creee
		return sRequete;
	},


	// Construit la requete pour recuperer les lignes d'une table
	sConstuitRequeteLignesTable: function(bTriCroissant, nCleEnregPos, sCleEnreg)
	{
		var sRequete = "";
		//	- Commande AJAX (non specifique)
		// Si on en demande pas juste le nombre de lignes
		if ((this.m_oSegment.m_nDebut != -1) && (this.m_oSegment.m_nTaille != -1))
		{
			// Selon si on demande un tri de colonnes
			sRequete = ((this.m_nColonneTri > -1) ? this.sCommandeAjax_LignesTriTable : this.sCommandeAjax_LignesTable) + "=" + this._sGetNomChamp();
			//	- contexte d'execution (specifique)
			sRequete += "&" + this.m_oSegment.m_nDebut + "=" + this.m_oSegment.m_nTaille;
			//	- Ordre de tri (specifique)
			if (this.m_nColonneTri >= 0)
			{
				// La syntaxe de la requete de tri est maintenant de la forme WD_TABLE_COL_TRI_=[-]NumeroColonne
				sRequete += "&" + this.sParametreAjax_ColTri + "=" + (bTriCroissant ? "" : "-") + this.m_nColonneTri;
			}
		}
		else
		{
			sRequete = this.sCommandeAjax_ParCourtAP + "=" + this._sGetNomChamp();
		}

		// Ajoute la position du parcours en AP si besoin
		sRequete += this.sConstuitAWP(false);

		//	- Cle de la ligne si disponible (Table/ZRs AWP)
		if (sCleEnreg.length > 0)
		{	// On doit encode la cle car elle peut contenir des + et des = qui sont decode/remplace lors de la reception du POST
			sRequete += "&" + this.sParametreAjax_CleEnreg_Pos + "=" + nCleEnregPos;
			sRequete += "&" + this.sParametreAjax_CleEnreg + "=" + encodeURIComponent(sCleEnreg);
		}

		// On renvoie la requete creee
		return sRequete;
	},

	// Construit la le debut de la requete pour la modification dans une table/ZR
	// oContenu :	- Tableau des valeurs de la ligne du cache pour les tables
	//				- Chaine avec le POST des champs de la ligne pour les ZR
	sConstuitRequeteModifLigne: function(bZR, oContenu, sCleEnreg)
	{
		//	- Commande AJAX (non specifique)
		var sRequete = this.sCommandeAjax_ModifTable + "=" + this._sGetNomChamp();
		//	- Numero de ligne
		sRequete += "&" + "LIGNE" + "=" + this.m_nLigne;
		//	- Cle de la ligne si disponible (Table/ZRs AJAX)
		if (sCleEnreg.length > 0)
		{	// On doit encode la cle car elle peut contenir des + et des = qui sont decode/remplace lors de la reception du POST
			sRequete += "&" + this.sParametreAjax_CleEnreg + "=" + encodeURIComponent(sCleEnreg);
		}

		// Ajoute la position du parcours en AP si besoin
		sRequete += this.sConstuitAWP(false);

		// Valeurs (Specifiques)
		if (bZR)
		{
			if ("" != oContenu)
			{
				sRequete += "&" + oContenu;
			}
		}
		else
		{
			var tabParamValeur = new Array(oContenu.length);
			var i;
			var nLimiteI = oContenu.length;
			for (i = 0; i < nLimiteI; i++)
			{
				if ((oContenu[i].m_nValeur !== undefined) && (oContenu[i].m_nValeur !== -1))
				{
					tabParamValeur[i] = "C" + i + "=" + oContenu[i].m_nValeur;
				}
				else
				{
					tabParamValeur[i] = "C" + i + "=" + encodeURIComponent(oContenu[i].m_sValeur);
				}
			}
			sRequete += "&" + tabParamValeur.join("&");
		}

		// On renvoie le debut de la requete creee
		return sRequete;
	},

	// Construit la requete pour la selection dans une table
	sConstuitRequeteSelection: function sConstuitRequeteSelection(nColonneClic, nDebut, nNombre, sCleEnreg)
	{
		//	- Detail
		var sRequete = this.sParametreAjax_Debut + "=" + nDebut + "&" + this.sParametreAjax_Nombre + "=" + nNombre;
		//	- Colonne lien si besoin : On met le parametre en indic WL pour detecter les problemes dans le serveur
		sRequete += "&" + this.sParametreAjax_ColonneLien + "=" + (nColonneClic != -1 ? nColonneClic + 1 : "");
		//	- Cle de la ligne si disponible (Table/ZRs AJAX)
		if (sCleEnreg.length > 0)
		{	// On doit encode la cle car elle peut contenir des + et des = qui sont decode/remplace lors de la reception du POST
			sRequete += "&" + this.sParametreAjax_CleEnreg + "=" + encodeURIComponent(sCleEnreg);
		}

		// Ajoute la position du parcours en AP si besoin
		sRequete += this.sConstuitAWP(true);

		// On renvoie la requete creee
		return sRequete;
	},

	// Construit la requete pour l'enroule/deroule de ligne de la table hierarchique
	sConstuitRequeteEnrouleDeroule: function sConstuitRequeteEnrouleDeroule()
	{
		// Ajoute la position du parcours en AP si besoin
		return this.sConstuitAWP(false);
	},

	// Gestion generique d'une requete
	bEnvoiRequete: function bEnvoiRequete(fEnvoi, tabArguments)
	{
		// Envoi la requete
		var nResultat = fEnvoi.apply(this, tabArguments);

		// On s'ajoute au cache si il n'y a pas d'erreur
		if (nResultat !== false)
		{
			this.m_nIdRequeteAJAX = nResultat;
			return true;
		}
		else
		{
			return false;
		}
	},

	// Valeur par defaut des variables : mis dans le prototype
	nEnvoiRequete: function nEnvoiRequete(oSegment, nColonneTri, bTriCroissant, nCleEnregPos, sCleEnreg)
	{
		// Nombre de lignes demandes
		this.m_oSegment = oSegment;
		// Tri demande
		this.m_nColonneTri = nColonneTri;

		// On demande les (nFin - nDebut) lignes a partir de nDebut
		return clWDAJAXMain.nAJAXRecupereLignesTable(this, this.sConstuitRequeteLignesTable(bTriCroissant, nCleEnregPos, sCleEnreg));
	},

	nEnvoiRequeteRecherche: function nEnvoiRequeteRecherche(nNombre, nMarge, nColonneTri, sValeur)
	{
		// Tri demande
		this.m_nColonneTri = nColonneTri;

		// On demande les (nFin - nDebut) lignes a partir de nDebut
		return clWDAJAXMain.nAJAXRecupereLignesTable(this, this.sConstuitRequeteRechercheTable(nNombre, nMarge, sValeur));
	},

	nEnvoiRequeteFiltre: function nEnvoiRequeteFiltre(nNombre, nMarge, nColonneFiltre, nFiltre, sValeur)
	{
		// On demande les (nFin - nDebut) lignes a partir de nDebut
		return clWDAJAXMain.nAJAXRecupereLignesTable(this, this.sConstuitRequeteFiltreTable(nNombre, nMarge, nColonneFiltre, nFiltre, sValeur));
	},

	nEnvoiRequeteAnnuleFiltre: function nEnvoiRequeteAnnuleFiltre(nNombre, nMarge, nColonneSansFiltre)
	{
		// On demande les (nFin - nDebut) lignes a partir de nDebut
		return clWDAJAXMain.nAJAXRecupereLignesTable(this, this.sConstuitRequeteAnnuleFiltreTable(nNombre, nMarge, nColonneSansFiltre));
	},

	nEnvoiRequeteDeplaceColonne: function nEnvoiRequeteDeplaceColonne(nColonne, nPosition)
	{
		return clWDAJAXMain.nAJAXRecupereLignesTable(this, this.sConstuitRequeteDeplaceColonneTable(nColonne, nPosition));
	},

	// Envoi une requete de modification d'une ligne de table/ZR
	// oContenu :	- Tableau des valeurs de la ligne du cache pour les tables
	//				- Chaine avec le POST des champs de la ligne pour les ZR
	nEnvoiRequeteModifLigne: function nEnvoiRequeteModifLigne(nLigneAbsolue, bZR, oContenu, sCleEnreg)
	{
		this.m_nLigne = nLigneAbsolue;

		// On demande les (nFin - nDebut) lignes a partir de nDebut
		return clWDAJAXMain.nAJAXRecupereLignesTable(this, this.sConstuitRequeteModifLigne(bZR, oContenu, sCleEnreg));
	},

	nEnvoiRequeteSelection: function nEnvoiRequeteSelection(nColonneClic, sAliasColonneClic, nDebut, nNombre, sCleEnreg, sTarget)
	{
		var bSubmit = false;
		var bAJAX = true;
		if (-1 !== nColonneClic)
		{
			switch (this.m_oChampTable.nGetOptionLienColonne(nColonneClic))
			{
			case 0:
				// Pas lien impossible
				break;
			case 1:
				// Lien simple : ne change rien
				break;
			case 2:
				// Lien submit
				bSubmit = true;
				break;
			case 3:
				// Lien non AJAX
				bAJAX = false;
				break;
			case 4:
				// Lien non AJAX submit
				bSubmit = true;
				bAJAX = false;
				break;
			}
		}

		if (bAJAX)
		{
			// On demande les (nFin - nDebut) lignes a partir de nDebut
			return clWDAJAXMain.nAJAXRecupereLignesTableSelection(this, this.sConstuitRequeteSelection(nColonneClic, nDebut, nNombre, sCleEnreg), bSubmit);
		}
		else
		{
			var sNomBlank = undefined;
			var sOptions = undefined;
			// On ne demande aucune lignes, on indique le clic sur la ligne de la table
			// Comme on n'est pas AJAX, il n'y a pas besoin de demander des lignes
			if (bSubmit)
			{
				_JSL(_PAGE_, sAliasColonneClic, sTarget || "_self", sNomBlank, sOptions, "CLICTABLE;" + sAliasColonneClic);
			}
			else
			{
				// GP 27/11/2015 : TB92228 : Demande la suppression des param�tres
				var sURL = clWDUtil.sGetPageAction(undefined, true);
				// _JCL fait un appel de _CFI qui g�re le cas de deux "?" et remplace le second par un "&"
				sURL += "?" + clWDAJAXMain.sCommandeWDAction + "=" + "CLICTABLE;" + sAliasColonneClic;
				sURL += "&" + this.m_oChampTable.m_sAliasChamp + "=" + this.m_oChampTable._vsGetValeurChampFormulaire();
				// La valeur retourn�e par sConstuitAWP inclus le "&" si besoin
				sURL += this.sConstuitAWP(true);
				_JCL(sURL, sTarget, sNomBlank, sOptions);
			}
			// Pour ne pas mettre la requete dans la liste des requ�tes (ce n'est pas une vraie requ�te AJAX)
			return false;
		}
	},

	nEnvoiRequeteEnrouleDeroule: function nEnvoiRequeteEnrouleDeroule(nLigneAbsolue/*, sCleEnreg*/)
	{
		// On demande les (nFin - nDebut) lignes a partir de nDebut
		return clWDAJAXMain.nAJAXRecupereLignesTableEnrouleDeroule(this, nLigneAbsolue, this.sConstuitRequeteEnrouleDeroule());
	},

	// Traite la reponse du serveur
	ActionListe: function(oXMLLignes)
	{
		// Si on a ete supprime : notre pointeur sur la table est null
		if (this.m_oChampTable)
		{
			// Puis demande au cache de nous supprimer en sauvant notre pointeur sur la table car celui-ci va etre mis a null
			var oChampTable = this.m_oChampTable;
			this.SupprimeRequete(false);

			// Remplis le cache et met a jour l'affichage
			// GP 19/10/2012 : QW224195 : Maintenant c'est this.m_nLigne et pas this.m_nLigne > 1
			oChampTable.bActionListeDepuisAJAX(oXMLLignes, this.m_nLigne);
		}
	},

	// Calcule si notre requete est encore valide
	bEstValide: function()
	{
		// On calcule la difference avec la date courante : limite => 10 secondes
		return (new Date()).getTime() - this.m_oDate.getTime() <= 10000;
	},

	// Se supprime soit meme
	SupprimeRequete: function SupprimeRequete(bReinitTable)
	{
		// Sauve le pointeur sur la table
		var oChampTable = this.m_oChampTable;
		if (undefined === oChampTable)
		{
			return;
		}
		// Se libere
		oChampTable.m_oCache.SupprimeRequete(this);

		// Et reinit la table au besoin
		if (bReinitTable)
		{
			// On ne le fait pas immediatement pour ne pas flooder le serveur
			// GP 24/08/2012 : Si il y a plusieurs requetes en parall�le inutile de faire plusieurs reset
			// => Changement de nSetTimeout en nSetTimeoutUnique
			oChampTable.nSetTimeoutUnique("Reinit", 2000);
		}
	}
};

// Classe representant une ligne de cache modifiee
function WDTableCacheLigneModifie(oCacheLigne)
{
	// Sauve la ligne de cache
	this.m_oCacheLigne = oCacheLigne;

	// Change la ligne pointe par la ligne physique
	this.m_oCacheLigne.m_oLigneHTML.SwapLigneCache(this.m_oCacheLigne.m_nColonneHTML, this);

	// Initialise le tableau des valeurs modifiees
	this.m_tabValeursChaine = new Array(oCacheLigne.m_tabValeurs.length);
	// Et le tableau des valeurs entieres (Combo/Interrupteur)
	this.m_tabValeursEntier = new Array(oCacheLigne.m_tabValeurs.length);
};

WDTableCacheLigneModifie.prototype.bLigneVirtuelle = true;

// Recupere la ligne dans le HTML
WDTableCacheLigneModifie.prototype.vnGetLigneHTML = function vnGetLigneHTML(/*nLigneAbsolue*/)
{
	return this.m_oCacheLigne.vnGetLigneHTML.apply(this.m_oCacheLigne, arguments);
};

// Recupere la colonne dans le HTML
WDTableCacheLigneModifie.prototype.vnGetColonneHTML = function vnGetColonneHTML()
{
	return this.m_oCacheLigne.vnGetColonneHTML.apply(this.m_oCacheLigne, arguments);
};

// Recupere la position absolue de la ligne
WDTableCacheLigneModifie.prototype.vnGetPosAbsolue = function vnGetPosAbsolue()
{
	return this.m_oCacheLigne.vnGetPosAbsolue.apply(this.m_oCacheLigne, arguments);
};

// Recupere le contenu d'une cellule
WDTableCacheLigneModifie.prototype.oGetValeurCellule = function oGetValeurCellule(nColonne, bPourEntier)
{
	if (this.m_tabValeursChaine[nColonne])
	{
		return bPourEntier ? this.m_tabValeursEntier[nColonne] : this.m_tabValeursChaine[nColonne];
	}
	else
	{
		return this.m_oCacheLigne.oGetValeurCellule.apply(this.m_oCacheLigne, arguments);
	}
};

// Indique que l'on a change la valeur de la colonne donnee
WDTableCacheLigneModifie.prototype.SetValeurCellule = function SetValeurCellule(nColonne, pfGetValeurNouvelle)
{
	if (nColonne < this.m_tabValeursChaine.length)
	{
		this.m_tabValeursChaine[nColonne] = pfGetValeurNouvelle(false);
		this.m_tabValeursEntier[nColonne] = pfGetValeurNouvelle(true);
	}
};

// Renvoie le tableaux des options d'une cellule combo
WDTableCacheLigneModifie.prototype.tabContenuCellule = function tabContenuCellule()
{
	return this.m_oCacheLigne.tabContenuCellule.apply(this.m_oCacheLigne, arguments);
};

// Recupere la cle d'un enreg
WDTableCacheLigneModifie.prototype.sGetCleEnreg = function sGetCleEnreg()
{
	return this.m_oCacheLigne.sGetCleEnreg.apply(this.m_oCacheLigne, arguments);
};

// Met le contenu dans une ligne du HTML
WDTableCacheLigneModifie.prototype.vbMAJLigne = function vbMAJLigne(oChampTable, nLigneAbsolue, tabValeursChaineModifie, bSelection)
{
	// Met la valeur depuis la ligne en cache
	return this.m_oCacheLigne.vbMAJLigne.apply(this.m_oCacheLigne, [oChampTable, nLigneAbsolue, this.m_tabValeursChaine, bSelection]);
};

// Detache la ligne
WDTableCacheLigneModifie.prototype.DetacheEtVide = function DetacheEtVide(oChampTable)
{
	this.m_oCacheLigne.DetacheEtVide(oChampTable);
};

// Valide les changements fait dans la ligne
WDTableCacheLigneModifie.prototype.bValideChangement = function bValideChangement(oChampTable, oTableCache, nLigneAbsolue)
{
	var bChangement = false;

	var tabValeursChaine = this.m_tabValeursChaine;
	var tabValeursEntier = this.m_tabValeursEntier;

	// Place les valeurs dans la ligne du cache
	var i;
	var nLimiteI = tabValeursChaine.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (tabValeursChaine[i] !== undefined)
		{
			bChangement |= this.m_oCacheLigne.bChangementValeur(i, tabValeursChaine[i], tabValeursEntier[i]);
		}
	}

	// Construit une requete pour le serveur s'il y a eu des changement
	if (bChangement)
	{
		oTableCache.CreeRequeteModifLigne(oChampTable, nLigneAbsolue, false, this.m_oCacheLigne.m_tabValeurs);
		return true;
	}
	return false;
};

// Fixe la hauteur de la ligne
WDTableCacheLigneModifie.prototype.bSetHauteur = function bSetHauteur()
{
	return this.m_oCacheLigne.bSetHauteur.apply(this.m_oCacheLigne, arguments); ;
};

// Lit la hauteur de la ligne
WDTableCacheLigneModifie.prototype.nGetHauteur = function nGetHauteur(/*oChampTable*/)
{
	return this.m_oCacheLigne.nGetHauteur.apply(this.m_oCacheLigne, arguments);
};
WDTableCacheLigneModifie.prototype.nGetHauteurDirect = function nGetHauteurDirect()
{
	return this.m_oCacheLigne.nGetHauteurDirect.apply(this.m_oCacheLigne, arguments);
};

// Change le style de la ligne
WDTableCacheLigneModifie.prototype.SetStyle = function SetStyle(/*tabStyleClasses*//*, nStyle*//*, oChampTable/*, nLigneAbsolue*//*, oEvent*//*, bSelection*/)
{
	return this.m_oCacheLigne.SetStyle.apply(this.m_oCacheLigne, arguments);
};

// Classe representant une ligne de cache
function WDTableCacheLigne (oXMLLigne, oChampTable, nLigne)
{
	// Si on est dans le constructeur pour la declaration de l'heritage
	if (!oXMLLigne)
	{
		return;
	}

	// Si on a un attribut de style de la ligne : on le stocke
	this.m_sStyleCouleur = clWDAJAXMain.sXMLGetAttributSafe(oXMLLigne, this.XML_STYLE_COULEUR, "");
	this.m_sStyleCouleurFond = clWDAJAXMain.sXMLGetAttributSafe(oXMLLigne, this.XML_STYLE_COULEURF, "");
	this.m_sCleEnreg = clWDAJAXMain.sXMLGetAttributSafe(oXMLLigne, this.XML_CLEENREG, "");
	// On ne doit prendre this.XML_LIGNE_POSABSOLUE que s'il est disponible
	this.m_nPosAbsolue = clWDAJAXMain.nXMLGetAttributSafe(oXMLLigne, this.XML_LIGNE_POSABSOLUE, nLigne);

	// Traite le cas des ruptures si elles existent
	var oXMLRupture = oXMLLigne.getElementsByTagName(this.XML_RUPTURES);
	if (oXMLRupture && oXMLRupture.length)
	{
		// Le contenu des ruptures
		this.m_oValeursRuptures = {};
		var oXMLRuptureHaut = oXMLRupture[0].getElementsByTagName(this.XML_RUPTURES_HAUT);
		if (oXMLRuptureHaut && oXMLRuptureHaut.length)
		{
			this.m_oValeursRuptures.m_sHaut = clWDAJAXMain.sXMLGetValeur(oXMLRuptureHaut[0]);
		}
		var oXMLRuptureBas = oXMLRupture[0].getElementsByTagName(this.XML_RUPTURES_BAS);
		if (oXMLRuptureBas && oXMLRuptureBas.length)
		{
			this.m_oValeursRuptures.m_sBas = clWDAJAXMain.sXMLGetValeur(oXMLRuptureBas[0]);
		}
	}

	// La valeurs
	var oXMLLigneChildNodes = oXMLLigne.childNodes;
	// Si on a une balise RUPTURES (normalement a la fin) il faut ignorer le dernier fils
	var i;
	var nLimiteI = oXMLLigneChildNodes.length - (this.m_oValeursRuptures ? 1 : 0);
	var tabValeurs = new Array(nLimiteI);
	for (i = 0; i < nLimiteI; i++)
	{
		// Optim ???
		var oXMLCellule = oXMLLigneChildNodes[i];

		var oCellule = {};

		// Si on a un attribut de style de la cellule : on le stocke
		oCellule.m_sStyleCouleur = clWDAJAXMain.sXMLGetAttributSafe(oXMLCellule, this.XML_STYLE_COULEUR, "");
		oCellule.m_sStyleCouleurFond = clWDAJAXMain.sXMLGetAttributSafe(oXMLCellule, this.XML_STYLE_COULEURF, "");

		this._vPlaceXMLDansCellule(oXMLCellule, oCellule, i, oChampTable);

		tabValeurs[i] = oCellule;
	}
	this.m_tabValeurs = tabValeurs;

	// GP 16/10/2014 : QW249545 : D�plac� depuis WDZRCacheLigne
	// Sinon contenu vide (par exemple si la ligne est repliee)
	this.m_nNbRepliee = clWDAJAXMain.nXMLGetAttributSafe(oXMLLigne, clWDAJAXMain.XML_CHAMP_LIGNES_NBREPLIEES, 0);
};

//WDTableCacheLigne.prototype.XML_STYLE = "STYLE";
WDTableCacheLigne.prototype.XML_STYLE_COULEUR = "COULEUR";
WDTableCacheLigne.prototype.XML_STYLE_COULEURF = "COULEURFOND";
WDTableCacheLigne.prototype.XML_CLEENREG = "CLEENREG";
WDTableCacheLigne.prototype.XML_LIGNE_POSABSOLUE = "POSABSOLUE";
WDTableCacheLigne.prototype.XML_RUPTURES = "RUPTURES";
WDTableCacheLigne.prototype.XML_RUPTURES_HAUT = "HAUT";
WDTableCacheLigne.prototype.XML_RUPTURES_BAS = "BAS";
WDTableCacheLigne.prototype.m_oVide = { m_sValeur:"", m_sStyleCouleur:"", m_sStyleCouleurFond:"", m_nValeur:-1, m_sCleEnreg:"" };
WDTableCacheLigne.prototype.m_nValeur = -1;
WDTableCacheLigne.prototype.m_nHauteur = -1;

// Place le contenu du XML dans une cellule
WDTableCacheLigne.prototype._vPlaceXMLDansCellule = function _vPlaceXMLDansCellule(oXMLCellule, oCellule, nColonne, oChampTable)
{
	oCellule.m_sValeur = clWDAJAXMain.sXMLGetValeur(oXMLCellule);

	if (clWDAJAXMain.bXMLAttributExiste(oXMLCellule, "BULLE"))
	{
		oCellule.m_sBulle = clWDAJAXMain.sXMLGetAttribut(oXMLCellule, "BULLE");
	}

	// Proprietes specifiques
	switch (oChampTable.eColonneTypeIDObjet(nColonne))
	{
	case WDChamp.prototype.ms_nIDObjetCombo:
		// Combo
		// Regarde si la cellule n'a pas un ..Contenu specifique
		// Il faut respecter la casse : "OPTION"
		var tabOptions = clWDAJAXMain.tabXMLGetTableauValeur(oXMLCellule, "OPTION");

		// Si non : prend la valeur generale de la colonne comme valeur
		if (!tabOptions)
		{
			tabOptions = oChampTable.tabColonneCombo(nColonne);
		}

		// Et memorise le contenu dans tous les cas
		oCellule.m_tabOptions = tabOptions;

		if (tabOptions)
		{
			var nOption = clWDUtil.nDansTableau(tabOptions, oCellule.m_sValeur);
			if (clWDUtil.nElementInconnu != nOption)
			{
				oCellule.m_nValeur = nOption;
			}
		}
		else
		{
			// Pas de tableau des options : saturation
			oCellule.m_nValeur = -1;
		}
		break;

	case WDChamp.prototype.ms_nIDObjetInterrupteur:
		// Interrupteur
		oCellule.m_nValeur = parseInt(oCellule.m_sValeur, 10);
		break;

	case WDChamp.prototype.ms_nIDObjetImage:
		// Image
		break;

	case WDChamp.prototype.ms_nIDObjetCellule:
		// Cellule (colonne conteneur)
		var oXMLCelluleChildNodes = oXMLCellule.childNodes;

		// Si on est dans le cas d'une ZR on lit la balise millieu
		if ((oXMLCelluleChildNodes.length === 3) && (oXMLCelluleChildNodes[1].nodeName === clWDAJAXMain.XML_CHAMP_LIGNES_LIGNE_CORPS))
		{
			oCellule.m_sValeur = clWDAJAXMain.sXMLGetValeur(oXMLCelluleChildNodes[1]);
		}
		break;

	default:	// Autres : fait comme le champ de saisie => Pas de break
	case WDChamp.prototype.ms_nIDObjetSaisie:
		// Saisie
		break;
	}
};

// Recupere la ligne dans le HTML
WDTableCacheLigne.prototype.vnGetLigneHTML = function vnGetLigneHTML(nLigneAbsolue)
{
	return nLigneAbsolue;
};

// Recupere la colonne dans le HTML
WDTableCacheLigne.prototype.vnGetColonneHTML = function vnGetColonneHTML()
{
	return 0;
};

// Recupere la position absolue de la ligne
WDTableCacheLigne.prototype.vnGetPosAbsolue = function vnGetPosAbsolue()
{
	return this.m_nPosAbsolue;
};

// Si la ligne est repliee (ligne est invisible mais ses ruptures oui)
// Utilis� pour supprimer les lignes ensuites
// Retourne le nombre de ligne a ignorer ensuite (attention en serveur le nombre de lignes repli�es inclus la ligne courante, ici ce n'est pas le cas)
// En revanche, c'est identique pour le nombre de lignes enroul�es qui n'inclus jamais la ligne courante
WDTableCacheLigne.prototype.vnGetNbReplieesOuEnroulees = function vnGetNbReplieesOuEnroulees()
{
	// GP 16/10/2014 : QW249545 : Fusionn�e avec WDZRCacheLigne.prototype.vnGetNbReplieesOuEnroulees
//	// Jamais sur une table
//	return 0;
	// Se place par rapport a la premiere ligne affichee
	// GP 20/07/2012 : On fait donc -1
	return this.m_nNbRepliee - 1;
};
WDTableCacheLigne.prototype.vnGetNbReplieesInclusSelf = function vnGetNbReplieesInclusSelf()
{
	return this.m_nNbRepliee;
};

// Recupere le contenu d'une cellule
WDTableCacheLigne.prototype.oGetValeurCellule = function oGetValeurCellule(nColonne, bPourEntier)
{
	var oValeur = (nColonne < this.m_tabValeurs.length) ? this.m_tabValeurs[nColonne] : this.m_oVide;
	return bPourEntier ? oValeur.m_nValeur : oValeur.m_sValeur;
};

// Renvoie le tableaux des options d'une cellule combo
WDTableCacheLigne.prototype.tabContenuCellule = function tabContenuCellule(nColonne)
{
	return this.m_tabValeurs[nColonne].m_tabOptions;
};

// Recupere la cle d'un enreg
WDTableCacheLigne.prototype.sGetCleEnreg = function sGetCleEnreg()
{
	return this.m_sCleEnreg;
};

// Met le contenu du cache dans une ligne du HTML
WDTableCacheLigne.prototype.vbMAJLigne = function vbMAJLigne(oChampTable, nLigneAbsolue, tabValeursChaineModifie, bSelection)
{
	var bPasZR = !oChampTable.vbZR();
	// Calcule si la ligne est selectionnee
	// Dans les ZR il n'y a pas de style de ligne selectionnee donc on ne doit pas supprimer les couleurs locales
	// GP 16/03/2021 : QW336315 : On ne veux vraiment pas du cas ZR car on ne force pas la couleur de fond. Le style est appliqu� correctement.
	var bSelectedSansZR = bPasZR && oChampTable.vbLigneEstSelectionneeSansZR(nLigneAbsolue);

	// Si le numero est HORS du HTML, n'affiche pas la ligne
	if (!this.m_oLigneHTML)
	{
		return false;
	}

	var bSelectionALaCellule = oChampTable.__bSelectionALaCellule();

	// Met le style dans la ligne
	var nColonneHTML = this.vnGetColonneHTML();
	var oLigneHTML = this.m_oLigneHTML.oGetLigneLogiqueHTML(nColonneHTML);
	// Pas de couleur de fond sur la ligne en pr�sence de s�lection � la cellule.
	this.SetCouleurObjet(oChampTable.m_sCSSTexteStyleSelectionCouleurFond, oLigneHTML, bSelectedSansZR && !bSelectionALaCellule, this);

	var bSansRepliees = true;

	if (bPasZR)
	{
		// Affiche ou masque la cellule selon son repliement
		// On modifie la racine de la ligne pour ne pas avoir de blanc
		bSansRepliees = 0 === this.vnGetNbReplieesInclusSelf();
		clWDUtil.SetDisplay(oLigneHTML, bSansRepliees);
	}

	if (bSansRepliees)
	{
		var tabValeurs = this.m_tabValeurs;
		var tabRedimensionnementDesImages = [];

		// On parcours les valeur pour les mettre dans le HTML
		var i = -1;
		var nLimiteI = tabValeurs.length;
		var oCellule;
		while ((oCellule = this.m_oLigneHTML.oGetCellule(nColonneHTML, (++i), oChampTable)) || (i < nLimiteI))
		{
			if (oCellule)
			{
				var oValeur = (i < nLimiteI) ? tabValeurs[i] : this.m_oVide;
				// Remplit la cellule
				var sValeur = oValeur.m_sValeur;
				if (tabValeursChaineModifie && (undefined !== tabValeursChaineModifie[i]))
				{
					sValeur = tabValeursChaineModifie[i];
				}
				// OUT : tabRedimensionnementDesImages
				oChampTable.vRemplitCellule(oCellule, sValeur, oValeur.m_sBulle, nLigneAbsolue, i, this, bSelection, tabRedimensionnementDesImages);

				oCellule = oCellule.parentNode;
				// 65479 Si on est dans dans une table avec hauteur variable, il faut prendre un niveau au dessus
				// GP 08/10/2015 : TB93916 : Valable aussi si on n'a pas la hauteur de ligne variable (en particulier la manipulation pour l'alignement) pour s'adapter au contenu de la ligne)
//				if (bPasZR && oChampTable.bGetHauteurLigneVariable())
				if (bPasZR)
				{
					// GP 10/06/2015 : TB92912 : Il y a des niveaux suppl�mentaires si il y a un alignement. Explication par GF avec un extrait de code de WDxxxHTML.
					// //On a besoin d'une table de cadrage vertical si table AJAX, cadrage vertical de colonne d�fini autre que haut et que style texte d�fini (sinon style texte incorrect)
					// BOOL bTableCadrageVertical = m_bAJAX && bCadrageVerticalDefiniAutreQueHaut(eCadrageVertical(pclColonne)) && bStyleTexteDefini(pclColonne->pclStyleGen(),&clStyleDiffLigne);
					// Les divers tests sont pour �tre sur d'�tre dans ce cas particulier et de ainsi ne pas faire de r�gressions. Peut-�tre sont-ils trop restrictifs.
					if (clWDUtil.bBaliseEstTag(oCellule, "td") && (oCellule === oCellule.parentNode.firstElementChild) && (!oCellule.nextElementSibling) && clWDUtil.bBaliseEstTag(oCellule.parentNode.parentNode.parentNode.parentNode, "div"))
					{
						oCellule = oCellule.parentNode.parentNode.parentNode.parentNode;
					}

					oCellule = oCellule.parentNode;
				}
				// GP 24/01/2013 : (1 < vnGetNbLignesLogiquesParLignePhysique()) n'est possible que sur les ZRs.
				// Donc avoir les deux tests a vrai est impossible : je commente le code
//				// 66352 Ou si on est dans une ZR avec colonne mutiples (uniquement si la ligne est affichee sinon on colorie les lignes invisibles)
//				if (1 < oChampTable.vnGetNbLignesLogiquesParLignePhysique())
//				{
//					// GP 24/01/2013 : Demande de GF pour les fonds des lignes de ZRs avec un cadre/style (nouveaut� 18 F+1)
//					// Les lignes de ZRs multi colonnes ont leur couleur de fond appliqu�es sur le td, car c'est l� qu'est �galement appliqu�e la class (style)
//					if (bPasZR)
//					{
//						oCellule = oCellule.firstElementChild;
//					}
//				}

				var bSelectionDeLaCellule = bSelectedSansZR;
				// En pr�sence de s�lection � la cellule, la couleur de fond est uniquement sur les cellules s�lectionn�es.
				if (bSelectionDeLaCellule && bSelectionALaCellule)
				{
					bSelectionDeLaCellule = oChampTable.bLigneEstSelectionnee(nLigneAbsolue, i);
				}

				// Et met son style
				this.SetCouleurObjet(oChampTable.m_sCSSTexteStyleSelectionCouleurFond, oCellule, bSelectionDeLaCellule, oValeur);
			}
		}

		// GP 27/05/2016 : QW273505 : Dans le cas des hauteurs de lignes variables, il faut faire le calcul de la hauteur des images quand toute la ligne est remplie pour avoir la vraie hauteur.
		// En effet si le nouveau contenu de la ligne est moins haut, la nouvelle hauteur n'est connue que � la fin
		clWDUtil.bForEach(tabRedimensionnementDesImages, function (pfRedimensionnementUneImage)
		{
			pfRedimensionnementUneImage();
			return true;
		});
	}

	// Remplit les ruptures
	// On n'utilise pas les valeurs modifie pour les ruptures
	oChampTable.RemplitRuptures(this.m_oLigneHTML, nColonneHTML, this.m_oValeursRuptures);

	return true;
};

// Detache la ligne
WDTableCacheLigne.prototype.DetacheEtVide = function DetacheEtVide(oChampTable)
{
	if (this.m_oLigneHTML)
	{
		this.m_oLigneHTML.DetacheEtVide(this.m_nColonneHTML, oChampTable);
	}
};

// Indique que l'on a change la valeur de la colonne donnee
// Normalement on ne passe pas ici
WDTableCacheLigne.prototype.SetValeurCellule = clWDUtil.m_pfVide;

// Defini la couleur d'un objet
WDTableCacheLigne.prototype.SetCouleurObjet = function SetCouleurObjet(sCSSTexteStyleSelectionCouleurFond, oObjet, bSelectedSansZR, oCouleur)
{
	// GP 29/10/2012 : QW223341, QW223239 : C'est utile : la couleur de fond prend toute la place de la ligne
	// C'est maintenant inutile. on reforce le style de la ligne selectionne au plus bas niveau
//	// Si le style de la ligne selectionne est vide, on accepte la couleur de l'element
//	oCouleur = ((undefined !== this.m_sCSSTexteStyleSelection) && bSelectedSansZR) ? this.m_oVide : oCouleur;
	var sStyleCouleurFond = oCouleur.m_sStyleCouleurFond;
	if (bSelectedSansZR && (undefined != sCSSTexteStyleSelectionCouleurFond))
	{
		sStyleCouleurFond = sCSSTexteStyleSelectionCouleurFond;
	}

	// Recupere les objets de manipulation du style
	var oStyle = oObjet.style;

	// Couleur
	if (oStyle.color != oCouleur.m_sStyleCouleur)
	{
		oStyle.color = oCouleur.m_sStyleCouleur;
	}

	// Couleur de fond
	if (oStyle.backgroundColor != sStyleCouleurFond)
	{
		oStyle.backgroundColor = sStyleCouleurFond;
	}
	// GP 07/05/2019 : TB109412 : Il faut mettre le s�parateur sur la colonne de redimensionnement.
	// Attention, l'ordre est : cellule, bordure, redimensionnment, cellule. Donc il faut manipuler le s�parateur AVANT
	// GP 22/05/2019 : TB312419 : Il faut le faire dans tous les cas sinon un site d'une ligne pr�c�dente reste dans les lignes "sans surcharges".
	var oCellulePrecedente = oObjet.previousElementSibling;
	if (oCellulePrecedente && clWDUtil.bAvecClasse(oCellulePrecedente, "wbtablesep"))
	{
		var oStyleCellulePrecedente = oCellulePrecedente.style;
		if (oStyleCellulePrecedente.backgroundColor != sStyleCouleurFond)
		{
			oStyleCellulePrecedente.backgroundColor = sStyleCouleurFond;
		}
	}
};

// Indique que l'on a change la valeur de la colonne donnee
WDTableCacheLigne.prototype.bChangementValeur = function bChangementValeur(nColonne, sValeur, nValeur)
{
	var tabValeurs = this.m_tabValeurs;

	// Si la colonne existe et change
	if ((nColonne < tabValeurs.length) && !(tabValeurs[nColonne].m_sValeur === sValeur))
	{
		tabValeurs[nColonne].m_sValeur = sValeur;
		tabValeurs[nColonne].m_nValeur = nValeur;
		return true;
	}
	return false;
};

// Fixe la hauteur de la ligne
WDTableCacheLigne.prototype.bSetHauteur = function bSetHauteur(nHauteur)
{
	var nOldHauteur = this.m_nHauteur;
	this.m_nHauteur = nHauteur;
	return nOldHauteur !== nHauteur;
};

// Lit la hauteur de la ligne
WDTableCacheLigne.prototype.nGetHauteur = function nGetHauteur(oChampTable)
{
	// GP 13/11/2014 : QW251202 : Calcule la hauteur si possible
	if (-1 == this.m_nHauteur)
	{
		this.m_nHauteur = oChampTable.nCalculeHauteurLigne(this.m_oLigneHTML);
	}

	return this.nGetHauteurDirect();
};
WDTableCacheLigne.prototype.nGetHauteurDirect = function nGetHauteurDirect()
{
	return this.m_nHauteur;
};

// Change le style de la ligne
WDTableCacheLigne.prototype.SetStyle = function SetStyle(tabStyleClasses, nStyle, oChampTable, nLigneAbsolue, oEvent, bSelection)
{
	// Modifie le style de la ligne
	if (this.m_oLigneHTML)
	{
		this.m_oLigneHTML.SetStyle(oChampTable, this.m_nColonneHTML, tabStyleClasses, nStyle, nLigneAbsolue);
		// GP 03/10/2012 : Vu avec les champ rating : on ne fait la MAJ que sur les tables. Sur les ZR il n'y a pas besoin de refaire les couleurs
		if (oChampTable._vbAvecCouleurDeFondSelection())
		{
			// Et force la MAJ si la ligne est pleine : ce qui est normalement le cas puisqu'on est ici
			this.m_oLigneHTML.bMAJSiPlein(this.m_nColonneHTML, oChampTable, nLigneAbsolue, oEvent, bSelection);
		}
	}
};

// Representation d'un segment de lignes entre 0 et nMax
function Segment (nDebut, nTaille, nMax)
{
	this.m_nDebut = nDebut;
	this.m_nTaille = nTaille;

	// On commence forcement a zero
	if (this.m_nDebut < 0)
	{	// Sauf que -1, -1 est autorise
		if ((this.m_nDebut != -1) && (this.m_nTaille != -1))
		{
			// Ainsi que zero en taille
			if (this.m_nTaille != 0)
			{
				this.m_nTaille += this.m_nDebut;
			}
			this.m_nDebut = 0
		}
	}

	// Et on se limite a nMax lignes si besoin
	if (nMax >= 0)
	{
		if (this.m_nDebut >= nMax)
		{
			// Se vide
			delete this.m_nDebut;
			delete this.m_nTaille;
			return;
		}

		// Limite le nombre de lignes
		if ((this.m_nDebut + this.m_nTaille > nMax) && (this.m_nTaille != 0))
		{
			this.m_nTaille = nMax - this.m_nDebut;
		}
	}
};

// Valeur par defaut
Segment.prototype.m_nDebut = -1;
Segment.prototype.m_nTaille = 0;

// Calcule l'intersection avec un autre segment, se modifie pour ne contenir que la partie non interceptee
// Renvoie vrai si le segment resultat est vide
// On ne peut englober un precedent segment
Segment.prototype.bIntersecte = function bIntersecte(oSegment)
{
	// Si vide => Fini
	if ((this.m_nDebut === -1) || (this.m_nTaille <= 0))
	{
		return true;
	}

	// Si toutes les lignes dans l'autre segment
	if (oSegment && (0 === oSegment.m_nTaille))
	{
		// Se vide
		delete this.m_nDebut;
		delete this.m_nTaille;
		return true;
	}

	// Si l'autre est vide=> Fini
	if ((!oSegment) || (-1 === oSegment.m_nDebut) || (oSegment.m_nTaille <= 0))
	{
		return false;
	}
	// Si on est dedans => Fini
	if ((this.m_nDebut >= oSegment.m_nDebut) && (this.m_nDebut + this.m_nTaille <= oSegment.m_nDebut + oSegment.m_nTaille))
	{
		// Se vide
		delete this.m_nDebut;
		delete this.m_nTaille;
		return true;
	}
	// Si on est avant avec intersection
	else if ((this.m_nDebut < oSegment.m_nDebut) && (this.m_nDebut + this.m_nTaille > oSegment.m_nDebut))
	{
		// Se vide du surplus
		this.m_nTaille = oSegment.m_nDebut - this.m_nDebut;
		return false;
	}
	// Si on est apres avec intersection
	else if ((this.m_nDebut >= oSegment.m_nDebut) && (this.m_nDebut < oSegment.m_nDebut + oSegment.m_nTaille) && (this.m_nDebut + this.m_nTaille > oSegment.m_nDebut + oSegment.m_nTaille))
	{
		// Deplace le debut
		this.m_nTaille -= oSegment.m_nDebut + oSegment.m_nTaille - this.m_nDebut;
		this.m_nDebut = oSegment.m_nDebut + oSegment.m_nTaille;
		return false;
	}
	return false;
};

// Indique si le segment est vide
Segment.prototype.bEstVide = function bEstVide()
{
	return (this.m_nTaille < 0) || ((this.m_nDebut < 0) && (this.m_nDebut + this.m_nTaille <= 0));
};

// Classe representant un le cache
function WDTableCache (oChampTable, fCacheLigne)
{
	if (oChampTable)
	{
		// Recalcule les marges
		this.RecalculeMarges(oChampTable);

		this.m_fCacheLigne = fCacheLigne;

		// Et aucunes lignes de cache
		this.m_tabLignes = [];

		// Le tableaux des zones demandes
		this.m_tabRequetes = [];
	}
};

WDTableCache.prototype.m_nDebutCache = -1; // Au debut on a un cache vide
WDTableCache.prototype.XML_LIGNE = "LIGNE";
WDTableCache.prototype.XML_LIGNE_NUMERO = "NUMERO";

// Recalcule le nombre d'elements de marge dans le cache par rapport a la position de la premiere ligne affichee
WDTableCache.prototype.RecalculeMarges = function RecalculeMarges(oChampTable)
{
	// Si pas de limite au nombre de ligne => Fini
	if (!oChampTable.bGetSansLimite())
	{
		var nNbLignesPage = oChampTable.m_nNbLignesPage;
		var nPagesMargeMin = oChampTable.m_nPagesMargeMin;
		var nPagesMargeMax = oChampTable.m_nPagesMargeMax;
		var nPagesMargeRequete = oChampTable.m_nPagesMargeRequete;

		// Nombre minimum de marge dans le cache avant de refaire une demande
		this.m_nLignesMargeMinAvant = nPagesMargeMin * nNbLignesPage;
		this.m_nLignesMargeMinTaille = (nPagesMargeMin * 2 + 1) * nNbLignesPage + 2;
		// Nombre maximum de marge dans le cache avant de virer du cache
		this.m_nLignesMargeMaxAvant = nPagesMargeMax * nNbLignesPage;
		this.m_nLignesMargeMaxApres = (nPagesMargeMax + 1) * nNbLignesPage + 2;
		// Marge mimimum lors de requetes de lignes dans le cache
		this.m_nLignesMargeRequeteAvant = Math.min(nPagesMargeRequete * nNbLignesPage, this.m_nLignesMargeMaxAvant);
		this.m_nLignesMargeRequeteTaille = Math.min((nPagesMargeRequete * 2 + 1) * nNbLignesPage + 2, this.m_nLignesMargeMaxAvant + this.m_nLignesMargeMaxApres);
	}
};

// Remplit le cache avec des donnees si besoin
WDTableCache.prototype.bRemplitCache = function bRemplitCache(oChampTable, bForce, nColonneTri, bTriCroissant, bPourTri)
{
	// Force si on a un tri
	if (nColonneTri > -1)
	{
		// Invalide completement le cache ce qui equivant a bForce = ture
		this.m_tabLignes.length = 0;
		delete this.m_nDebutCache;
	}

	var oSegment;

	var nDebut = oChampTable.m_nDebut;

	// Si on est dans le cas sans limite de lignes : on demande toujours toutes les lignes
	if (oChampTable.bGetSansLimite())
	{
		oSegment = new Segment(0, 0);
	}
	else
	{
		var nNbLignes = oChampTable.m_nNbLignes;

		// On demande par defaut les valeurs autour de la position donnee en se limitant au nombre de lignes de la table
		var oCacheMin = new Segment(Math.max(0, nDebut - this.m_nLignesMargeMinAvant), this.m_nLignesMargeMinTaille, bForce ? -1 : nNbLignes);
		// On demande un mimimun de lignes apres la fin pour el cas ou celle-ci change
		// GP 13/02/2015 : QW253905 : Si on n'a pas assez de ligne pour remplir l'�cran actuellement, inutile de faire une demande
		var nMax = -1;
		if (!bForce)
		{
			nMax = nNbLignes;
			if (oChampTable.m_nNbLignesPage <= nNbLignes)
			{
				nMax += this.m_nLignesMargeMinTaille;
			}
		}
		oSegment = new Segment(Math.max(0, nDebut - this.m_nLignesMargeRequeteAvant), this.m_nLignesMargeRequeteTaille, nMax);

		// Si le cache est non vide, et que l'on ne force pas on regarde ce qu'il manque et on le demande
		if ((this.m_nDebutCache != -1) && (!bForce))
		{
			// Si on a assez de lignes dans le cache
			var oCache = new Segment(Math.max(0, this.m_nDebutCache), this.m_tabLignes.length);
			if (oCacheMin.bIntersecte(oCache))
			{
				return false;
			}

			// Puis on regarde si notre requete intersecte les precedentes demandes
			if (this.bIntersecteAnciennesRequetes(oCacheMin, nColonneTri > -1, bPourTri))
			{
				return true;
			}

			// On intersecte la requete avec le cache courant
			oSegment.bIntersecte(oCache);
		}
	}

	// Si il n'y a pas intersection : on intersecte la requete minimale avec le cache actuel et les requetes en cours pour avori la requete minimale
	if (!this.bIntersecteAnciennesRequetes(oSegment, nColonneTri > -1, bPourTri))
	{
		// En mode AWP : Trouve l'enreg le plus proche dans le cache pour se positionner dessus
		var nCleEnregPos = -1;
		var sCleEnreg = "";
		if (clWDAJAXMain.m_bPageAWP)
		{
			if ((this.m_nDebutCache >= 0) && !oChampTable.bGetSansLimite())
			{
				// Si le debut du cache est avant la zone en requete
				if (this.m_nDebutCache < oSegment.m_nDebut)
				{
					// On prend le plus proche dans le cache
					nCleEnregPos = Math.min(this.m_nDebutCache + this.m_tabLignes.length - 1, oSegment.m_nDebut - 1);
				}
				else
				{
					nCleEnregPos = Math.max(this.m_nDebutCache, oSegment.m_nDebut + oSegment.m_nTaille);
				}
				sCleEnreg = this.sGetCleEnregLigne(nCleEnregPos);
			}

			// Si on n'a pas de positionnement : utilise la cle fournis pour la position de debut
			if ((-1 < nDebut)
				&& (oChampTable.m_sCleDebut)
				&& ((-1 === nCleEnregPos) || (Math.abs(nDebut - oSegment.m_nDebut) < Math.abs(nDebut - nCleEnregPos))))
			{
				nCleEnregPos = nDebut;
				sCleEnreg = oChampTable.m_sCleDebut;
			}
		}

		// Cree la requete qui va bien
		this.CreeRequete(oChampTable, oSegment, nColonneTri, bTriCroissant, nCleEnregPos, sCleEnreg);

		return true;
	}
	else
	{
		return false;
	}
};

// Calcule l'intersection d'une requete avec les requetes precedentes
// Renvoie vrai si la requetes resultat est vide
WDTableCache.prototype.bIntersecteAnciennesRequetes = function bIntersecteAnciennesRequetes(oSegment, bForce, bPourTri)
{
	// Vire les anciennes requetes qui sont en timeout
	this.PurgeAnciennesRequetes(bForce);

	// Regarde si il y a intersection avec de precedente requetes
	var i;
	var nLimiteI = this.m_tabRequetes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		// Si la requete intersecte le segment et devient vide
		if (oSegment.bIntersecte(this.m_tabRequetes[i].m_oSegment))
		{
			return true;
		}

		// Ne gere pas le cas de l'englobement
	}

	// GP 23/11/2015 : TB94049 : Dans le cas du tri il faut toujours faire un appel du serveur sinon le tri se perd
	if (oSegment.bEstVide() && bPourTri)
	{
		oSegment.m_nDebut = 0;
		oSegment.m_nTaille = 1;
	}

	return oSegment.bEstVide();
};

// Gestion generique d'une requete
WDTableCache.prototype.bEnvoiRequete = function bEnvoiRequete(fEnvoi, oChampTable, tabArguments)
{
	// Creation de la requete
	var oRequete = new WDCacheRequete(oChampTable);
	// Envoi de la requete
	if (oRequete.bEnvoiRequete(fEnvoi, tabArguments))
	{
		this.m_tabRequetes.push(oRequete);
		return true;
	}
	else
	{
		return false;
	}
};

// Verifie si il y a besoin d'envoyer une requete et la cree si besoin
WDTableCache.prototype.CreeRequete = function CreeRequete(oChampTable, oSegment, nColonneTri, bTriCroissant, nCleEnregPos, sCleEnreg)
{
	// Cree une requete que l'on envoie
	this.bEnvoiRequete(WDCacheRequete.prototype.nEnvoiRequete, oChampTable, [oSegment, nColonneTri, bTriCroissant, nCleEnregPos, sCleEnreg]);
};

// Creer une requete de recherche
WDTableCache.prototype.CreeRequeteRecherche = function CreeRequeteRecherche(oChampTable, nColonneTri, sValeur)
{
	// Cree une requete que l'on envoie
	// On ne cree pas la meme requete si on est en nombre de ligne limite par page ou pas
	// Si on est en nombre de ligne illimite this.m_nLignesMargeRequeteAvant n'existe pas
	this.bEnvoiRequete(WDCacheRequete.prototype.nEnvoiRequeteRecherche, oChampTable, [oChampTable.m_nNbLignesPage, this.m_nLignesMargeRequeteAvant ? this.m_nLignesMargeRequeteAvant : 0, nColonneTri, sValeur]);
};

// Cr�er une requ�te de filtre
WDTableCache.prototype.CreeRequeteFiltre = function CreeRequeteFiltre(oChampTable, nColonneTri, nFiltre, sValeur)
{
	// Cree une requete que l'on envoie
	// On ne cree pas la meme requete si on est en nombre de ligne limite par page ou pas
	// Si on est en nombre de ligne illimite this.m_nLignesMargeRequeteAvant n'existe pas
	this.bEnvoiRequete(WDCacheRequete.prototype.nEnvoiRequeteFiltre, oChampTable, [oChampTable.m_nNbLignesPage, this.m_nLignesMargeRequeteAvant ? this.m_nLignesMargeRequeteAvant : 0, nColonneTri, nFiltre, sValeur]);
};

// Cr�er une requ�te pour annuler le filtre
WDTableCache.prototype.CreeRequeteAnnuleFiltre = function CreeRequeteAnnuleFiltre(oChampTable, nColonneTri)
{
	// Cree une requete que l'on envoie
	// On ne cree pas la meme requete si on est en nombre de ligne limite par page ou pas
	// Si on est en nombre de ligne illimite this.m_nLignesMargeRequeteAvant n'existe pas
	this.bEnvoiRequete(WDCacheRequete.prototype.nEnvoiRequeteAnnuleFiltre, oChampTable, [oChampTable.m_nNbLignesPage, this.m_nLignesMargeRequeteAvant ? this.m_nLignesMargeRequeteAvant : 0, nColonneTri]);
};

// Cr�er une requ�te pour d�placer une colonne
WDTableCache.prototype.CreeRequeteDeplaceColonne = function CreeRequeteDeplaceColonne(oChampTable, nColonne, nPosition)
{
	// Cree une requete que l'on envoie
	// On ne cree pas la meme requete si on est en nombre de ligne limite par page ou pas
	// Si on est en nombre de ligne illimite this.m_nLignesMargeRequeteAvant n'existe pas
	this.bEnvoiRequete(WDCacheRequete.prototype.nEnvoiRequeteDeplaceColonne, oChampTable, [nColonne, nPosition]);
};

// Creer une requete de modification de ligne
// oContenu :	- Tableau des valeurs de la ligne du cache pour les tables
//				- Chaine avec le POST des champs de la ligne pour les ZR
WDTableCache.prototype.CreeRequeteModifLigne = function CreeRequeteModifLigne(oChampTable, nLigneAbsolue, bZR, oContenu)
{
	// Cree une requete de modification que l'on envoie
	this.bEnvoiRequete(WDCacheRequete.prototype.nEnvoiRequeteModifLigne, oChampTable, [nLigneAbsolue, bZR, oContenu, this.sGetCleEnregLigne(nLigneAbsolue)]);
};

// Creer une requete de selection de ligne
// GP 30/06/2015 : TB93061 : Retourne true si la requete a �t� ajout� dans la table des requ�tes (donc si la requ�te lanc� est AJAX)
WDTableCache.prototype.bCreeRequeteSelection = function bCreeRequeteSelection(oChampTable, nColonneClic, sAliasColonneClic, sTarget)
{
	// GP 28/01/2014 : QW241060 : Pourquoi on redemande tous le cache ?
	// Au moins dans le cas completement en cache et sans limites, je ne retourne la que la s�lection.
	// Si la s�lection change d'autres lignes, cala d�clenche une double modification.
	var nDebut = this.m_nDebutCache;
	var nNombre = this.m_tabLignes.length;
	if (oChampTable.bGetSansLimite() && (1 === oChampTable.m_tabSelection.length))
	{
		nDebut = oChampTable.m_tabSelection[0].m_nLigne;
		nNombre = 1;
	}

	// Envoi la requete de recherche
	return this.bEnvoiRequete(WDCacheRequete.prototype.nEnvoiRequeteSelection, oChampTable, [nColonneClic, sAliasColonneClic, nDebut, nNombre, this.sGetCleEnregLigne(this.m_nDebutCache), sTarget]);
};

// Creer une requete d'enroule/deroule
WDTableCache.prototype.CreeRequeteEnrouleDeroule = function CreeRequeteEnrouleDeroule(oChampTable, nLigneAbsolue)
{
	// Cree une requete de modification que l'on envoie
	this.bEnvoiRequete(WDCacheRequete.prototype.nEnvoiRequeteEnrouleDeroule, oChampTable, [nLigneAbsolue, this.sGetCleEnregLigne(nLigneAbsolue)]);
};

// Calcule la cle d'enreg a utiliser
WDTableCache.prototype.sGetCleEnregLigne = function sGetCleEnregLigne(nLigneAbsolue)
{
	// Recupere la cle de l'enreg si besoin
	// Si la ligne est dans le cache (Normalement c'est toujours le cas)
	if (this.bDansPlageCache(nLigneAbsolue))
	{
		var oLigne = this.m_tabLignes[nLigneAbsolue - this.m_nDebutCache];
		if (oLigne)
		{
			return oLigne.sGetCleEnreg();
		}
	}
	return "";
};

// Vire les anciennes requetes qui sont en timeout
WDTableCache.prototype.PurgeAnciennesRequetes = function PurgeAnciennesRequetes(bForce)
{
	var i;
	var nLimiteI = this.m_tabRequetes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (!this.m_tabRequetes[i].bEstValide() || bForce)
		{
			delete this.m_tabRequetes[i].m_oChampTable;
			// On commence par rechercher la requete
			var oRequete = clWDAJAXMain.GetWDAJAXRequete(this.m_tabRequetes[i].m_nIdRequeteAJAX);
			// Si on trouve la requete, on l'annule
			if (oRequete)
			{
				oRequete.Annule();
			}
			oRequete = undefined;

			// Vire la requete du tableau
			this.m_tabRequetes.splice(i, 1);
			// Ne pas oublier le -- sinon on saute une requete
			i--;
			nLimiteI--;
		}
	}
};

// Supprime une requete
WDTableCache.prototype.SupprimeRequete = function SupprimeRequete(oRequete)
{
	// Recherche la requete selon un critere de date et de numero de requete AJAX
	var i;
	var nLimiteI = this.m_tabRequetes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if ((this.m_tabRequetes[i].m_oDate.getTime() == oRequete.m_oDate.getTime()) && (this.m_tabRequetes[i].m_nIdRequeteAJAX == oRequete.m_nIdRequeteAJAX))
		{
			delete this.m_tabRequetes[i].m_oChampTable;
			// Vire la requete du tableau
			this.m_tabRequetes.splice(i, 1);
			// Et fini
			return;
		}
	}
};

// Indique si une requete de tri existe dans le cache
WDTableCache.prototype.bAvecRequeteTri = function bAvecRequeteTri()
{
	// Recherche la requete selon un critere de date et de numero de requete AJAX
	var i;
	var nLimiteI = this.m_tabRequetes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (this.m_tabRequetes[i].m_nColonneTri > -1)
		{
			// On a trouve une requete
			return true;
		}
	}
	return false;
};

// Decide si la ligne numero nLigne a sa place dans le cache
// Si non => Renvoi -1
// Si oui => Fait de la place eventuelle dans le cache et renvoi la place de cette ligne
WDTableCache.prototype.__nPlaceLigneCache = function __nPlaceLigneCache(oChampTable, nLigne)
{
	// Si on est pas en nombre de ligne illimite on teste si la ligne est hors cache
	if (!oChampTable.bGetSansLimite())
	{
		// Si la ligne est trop loin de la ligne courante => Fini
		var nDebut = oChampTable.m_nDebut;
		if ((nLigne < nDebut - this.m_nLignesMargeMaxAvant) || (nLigne >= nDebut + this.m_nLignesMargeMaxApres))
		{
			return -1;
		}
	}

	// Si on n'a pas encore de cache : on l'initialise
	if (-1 === this.m_nDebutCache)
	{
		//assert(0 === this.m_tabLignes.length);
		this.m_tabLignes.push(null);
		// La ligne est au d�but
		this.m_nDebutCache = nLigne;
		return 0;
	}

	var i;
	var nLimiteI;
	// Sinon on agrandi le tableau au besoin
	// Si la ligne est avant le debut du cache
	if (nLigne < this.m_nDebutCache)
	{
		// Si on est "proche" du cache (=> Une partie du cache est
		// On ajoute un tableau vide au debut
		// Insere le nombre d'entre vides qui vont bien et les initialise a zero
		nLimiteI = this.m_nDebutCache - nLigne;
		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabLignes.unshift(null);
		}
		// La ligne est au d�but
		this.m_nDebutCache = nLigne;
		return 0;
	}
	else if (nLigne >= this.m_nDebutCache + this.m_tabLignes.length)
	{
		// Si la ligne est apres la fin
		nLimiteI = nLigne - this.m_nDebutCache - this.m_tabLignes.length + 1;
		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabLignes.push(null);
		}
		// Pas de decalage du debut
	}
	else if ((nLigne - this.m_nDebutCache < this.m_tabLignes.length) && (this.m_tabLignes[nLigne - this.m_nDebutCache] != null))
	{	// La ligne est dans la place : on supprime par securite la ligne du cache
		delete this.m_tabLignes[nLigne - this.m_nDebutCache].m_tabValeurs;
		this.m_tabLignes[nLigne - this.m_nDebutCache] = null;
	}

	// Renvoie la distance au debut
	return nLigne - this.m_nDebutCache;
};

// Recoit des donnees du serveur et le met dans le cache et analysant le XML des donnees
WDTableCache.prototype.RemplitCacheLignes = function RemplitCacheLignes(oChampTable, oXMLLignes)
{
	// Si le debut n'est pas dans le cache c'est que l'on recoit une ancienne requete
	// Et donc la MAJ ne peu pas se faire bien (on ne connait pas l'origine) donc on le calcule
	var bNoteMAJLigne = this.bDansPlageCache(oChampTable.m_nDebut);

	// Met a jour le cache avec chaque ligne
	var oXMLLigne = oXMLLignes.firstChild;
	while (oXMLLigne != null)
	{
		// Lit le numero de la ligne
		//assert(XMLLigne.nodeName == this.XML_LIGNE);
		var nLigne = parseInt(clWDAJAXMain.sXMLGetAttribut(oXMLLigne, this.XML_LIGNE_NUMERO), 10);

		// Decide si on doit mettre la ligne dans le cache et fait la place si necessaire dans celui-ci
		// On recoit le numero de position dans le cache (ou -1)
		var nPosCacheLigne = this.__nPlaceLigneCache(oChampTable, nLigne);
		if (nPosCacheLigne != -1)
		{
			//assert(this.m_tabLignes[nPosCacheLigne] == null);
			// Ajoute la ligne dans le cache
			this.m_tabLignes[nPosCacheLigne] = new this.m_fCacheLigne(oXMLLigne, oChampTable, nLigne);

			// Si la dernier ligne a des lignes repliees apres, supprimes les lignes suivantes si besoin
			// GP 20/07/2012 : Compare a z�ro car n'inclus plus la ligne courante dans le compte
			var nGetNbReplieesOuEnroulees = this.m_tabLignes[nPosCacheLigne].vnGetNbReplieesOuEnroulees();
			if (0 < nGetNbReplieesOuEnroulees)
			{
				var nPosAbsolueLimite = this.m_tabLignes[nPosCacheLigne].vnGetPosAbsolue() + nGetNbReplieesOuEnroulees;
				// GP 20/07/2012 : Compare avec un <= au lieu d'un < pour tenir compte que la valeur n'inclus plus la ligne courante.
				while (this.m_tabLignes[nPosCacheLigne + 1] && (this.m_tabLignes[nPosCacheLigne + 1].vnGetPosAbsolue() <= nPosAbsolueLimite))
				{
					this.m_tabLignes.splice(nPosCacheLigne + 1, 1);
				}
			}

			// Si la ligne est visible : force sa MAJ
			if (bNoteMAJLigne)
			{
				oChampTable.NoteMAJLigne(nLigne);
			}
			// Si la ligne est repliee, invalide les elements dans le repliement (il ne sont pas transmis par le serveur
		}

		// Passe a la ligne suivante
		oXMLLigne = oXMLLigne.nextSibling;
	}
};

// Vide le cache des donnees inutiles
WDTableCache.prototype.SupprimeLignesInutiles = function SupprimeLignesInutiles(oChampTable)
{
	// Si pas encore de cache => Fini
	if (-1 === this.m_nDebutCache)
	{
		return;
	}

	var tabLignes = this.m_tabLignes;

	// Si on est en nombre illimite de lignes : supprime les lignes qui sont apres la fin
	if (oChampTable.bGetSansLimite())
	{
		if (tabLignes.length > oChampTable.m_nNbLignes)
		{
			tabLignes.splice(oChampTable.m_nNbLignes);
		}
		return;
	}

	var nDebut = oChampTable.m_nDebut;
	// Si tous le cache est avant la zone de marge => Supprime le cache
	// Si le cache est apres la zone de marge => Supprime le cache
	if ((this.m_nDebutCache + tabLignes.length <= nDebut - this.m_nLignesMargeMaxAvant) || (this.m_nDebutCache >= nDebut + this.m_nLignesMargeMaxApres))
	{
		tabLignes.length = 0;
		delete this.m_nDebutCache;
		return;
	}

	// Si le debut du cache est avant la zone de marge (Et donc avec une zone de recouvrement au vu des test precedents) : supprime le cache en trop
	if (this.m_nDebutCache < nDebut - this.m_nLignesMargeMaxAvant)
	{
		tabLignes.splice(0, nDebut - this.m_nLignesMargeMaxAvant - this.m_nDebutCache);
		this.m_nDebutCache = nDebut - this.m_nLignesMargeMaxAvant;
	}

	// Si on a trop de cache vers la fin (Et donc avec une zone de recouvrement au vu des test precedents) : supprime le cache en trop
	if (this.m_nDebutCache + tabLignes.length >= nDebut + this.m_nLignesMargeMaxApres)
	{
		// GP 19/03/2013 : Ici le calcul est faux : on supprime trop de lignes
		// Si this.m_nDebutCache < nDebut, on veux garder (nDebut - this.m_nDebutCache + this.m_nLignesMargeMaxApres) lignes
		//	=> Les lignes avant et this.m_nLignesMargeMaxApres apr�s
		// Si this.m_nDebutCache = nDebut, on veux garder this.m_nLignesMargeMaxApres lignes
		//	=> this.m_nLignesMargeMaxApres apr�s
		//	=> Calcul �quivalent � (nDebut - this.m_nDebutCache + this.m_nLignesMargeMaxApres) car nDebut = this.m_nDebutCache
		// Si this.m_nDebutCache > nDebut, on veux garder (this.m_nLignesMargeMaxApres - (this.m_nDebutCache - nDebut) lignes
		//	=> Calcul �quivalent � (nDebut - this.m_nDebutCache + this.m_nLignesMargeMaxApres)
//		tabLignes = tabLignes.splice(this.m_nLignesMargeMaxApres);
		tabLignes.splice(nDebut - this.m_nDebutCache + this.m_nLignesMargeMaxApres);
	}
	// Si on des lignes qui n'existent plus
	if (this.m_nDebutCache + tabLignes.length > oChampTable.m_nNbLignes)
	{
		tabLignes.splice(oChampTable.m_nNbLignes - this.m_nDebutCache);
	}

	// GP 19/03/2013 : TB80800 : On peut avoir un cache avec des trous. ????
	// Soit c'est un bug, soit c'est un cas particulier : on a le cache minimum, un "trou", et quelques lignes de avant qui sont dans la zone maximale
	// ... | Affichage | Apres obligatoire | Apres optionnel | Apres supprim�
	//		xxxxxxxxxxx xxxxxxxxxxxxxxxxxxx x             xxx
	//														^ viens d'un affichage pr�c�dent
	// Si on fait ensuite un d�calage petit, la fin est supprim�e et il reste les null.
	// => On supprime le vide en d�but et fin.
	// Note : on ne le fait que si on est en mode "nombre de lignes limit�" ce qui est le cas ici
	while (tabLignes.length && !tabLignes[0])
	{
		tabLignes.splice(0, 1);
		this.m_nDebutCache++;
	}
	while (tabLignes.length && !tabLignes[tabLignes.length - 1])
	{
		tabLignes.splice(tabLignes.length - 1, 1);
	}
	// RAZ du d�but du cache si un des calculs pr�cedent a vider le cache
	if (0 === tabLignes.length)
	{
		delete this.m_nDebutCache;
	}
};

// Recupere une ligne dans le cache
WDTableCache.prototype.oGetLigne = function oGetLigne(nLigneAbsolue)
{
	// Si la ligne n'est pas dans le cache : fini
	// Si la ligne n'est pas dans le cache => fini aussi
	if (!this.bDansPlageCache(nLigneAbsolue))
	{
		return null;
	}
	return this.m_tabLignes[nLigneAbsolue - this.m_nDebutCache];
};

// Met a jour la ligne donnee en fonction des elements dans le cache
// nLigneAbsolue est le numero de ligne, nLigneRelative est le numero de ligne parmis les lignes affiches
WDTableCache.prototype.bMAJLigne = function bMAJLigne(oChampTable, nLigneAbsolue, bSelection)
{
	var oLigne = this.oGetLigne(nLigneAbsolue);
	if (oLigne)
	{
		// Demande a la ligne de cache
		return oLigne.vbMAJLigne(oChampTable, nLigneAbsolue, undefined, bSelection);
	}
	return false;
};

// Recupere le contenu d'une cellule
WDTableCache.prototype.oGetValeurCellule = function oGetValeurCellule(nLigneAbsolue, nColonne, bPourEntier)
{
	var oLigne = this.oGetLigne(nLigneAbsolue);
	if (oLigne)
	{
		// Demande a la ligne de cache
		return oLigne.oGetValeurCellule(nColonne, bPourEntier);
	}
	return bPourEntier ? -1 : "";
};

// Renvoie le tableaux des options d'une cellule combo
WDTableCache.prototype.tabContenuCellule = function tabContenuCellule(nLigneAbsolue, nColonne)
{
	var oLigne = this.oGetLigne(nLigneAbsolue);
	if (oLigne)
	{
		// Demande a la ligne de cache
		return oLigne.tabContenuCellule(nColonne);
	}
	// Si la ligne n'est pas dans le cache : fini
	return null;
};

// Indique si une ligne est dans la zone normalement couverte par le cache
WDTableCache.prototype.bDansPlageCache = function bDansPlageCache(nLigne)
{
	// Le ligne ne doit pas etre avant ou apres
	return (nLigne >= this.m_nDebutCache) && (nLigne < this.m_nDebutCache + this.m_tabLignes.length);
};

// Indique que l'on a change la valeur de la colonne donnee
// nLigne est en valeur absolue
WDTableCache.prototype.SetValeurCellule = function SetValeurCellule(nLigne, nLigneRelative, nColonne, pfGetValeurNouvelle)
{
	// Si pas de cache => Fini c'est qu'il y a eu une erreur fatale => reset de la table
	if (-1 === this.m_nDebutCache)
	{
		return;
	}

	// Trouve le numerode ligne dans le cache
	var nLigneCache = nLigne - this.m_nDebutCache;

	// Si la ligne est dans le cache on la modifie
	if ((nLigneCache <= this.m_tabLignes.length) && (this.m_tabLignes[nLigneCache] != null))
	{
		this.m_tabLignes[nLigneCache].SetValeurCellule(nColonne, pfGetValeurNouvelle);
	}
};

// Et notifie le serveur de la validation d'une ligne
// nLigne est en valeur absolue
WDTableCache.prototype.bValideChangement = function bValideChangement(oChampTable, nLigneAbsolue)
{
	var oLigneCache = this.m_tabLignes[nLigneAbsolue - this.m_nDebutCache];
	// Valide le changement sur la ligne virtuelle
	if (oLigneCache && oLigneCache.bLigneVirtuelle)
	{
		return oLigneCache.bValideChangement(oChampTable, this, nLigneAbsolue);
	}
	return false;
};

// Supprime les lignes virtuelles
WDTableCache.prototype.SupprimeLignesVirtuelles = function SupprimeLignesVirtuelles()
{
	// On parcours nos lignes de cache et supprime les lignes virtuelles
	var i;
	var nLimiteI = this.m_tabLignes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oLigne = this.m_tabLignes[i];
		// Si c'est une ligne virtuelle
		if (oLigne && oLigne.bLigneVirtuelle)
		{
			// Remet la ligne normale
			this.m_tabLignes[i] = oLigne.m_oCacheLigne;
			// Change la ligne pointe par la ligne physique
			oLigne.m_oCacheLigne.m_oLigneHTML.SwapLigneCache(oLigne.m_oCacheLigne.m_nColonneHTML, oLigne.m_oCacheLigne);

			// Supprime les membres
			delete oLigne.m_oCacheLigne;
			delete oLigne.m_tabValeurs;
			oLigne = undefined;
		}
	}
};

// Cree la ligne virtuelle si besoin
// nLigne est en valeur absolue
WDTableCache.prototype.bCreeLigneVirtuelle = function bCreeLigneVirtuelle(nLigneAbsolue)
{
	// Calcule la position absolue dans le tableau
	var nLigneRelativeDebutCache = nLigneAbsolue - this.m_nDebutCache;
	if (this.m_tabLignes[nLigneRelativeDebutCache])
	{
		if (!this.m_tabLignes[nLigneRelativeDebutCache].bLigneVirtuelle)
		{
			this.m_tabLignes[nLigneRelativeDebutCache] = new WDTableCacheLigneModifie(this.m_tabLignes[nLigneRelativeDebutCache]);
		}
		return true;
	}
	else
	{
		return false;
	}
};

// Fixe la hauteur d'une ligne
WDTableCache.prototype.bSetHauteur = function bSetHauteur(nLigneAbsolue, nHauteur)
{
	var oLigne = this.oGetLigne(nLigneAbsolue);
	if (oLigne)
	{
		// Modifie la ligne
		return oLigne.bSetHauteur(nHauteur);
	}
	return false;
};

// Lit la hauteur de la ligne
WDTableCache.prototype.nGetHauteur = function nGetHauteur(oChampTable, nLigneAbsolue)
{
	var oLigne = this.oGetLigne(nLigneAbsolue);
	if (oLigne)
	{
		// Demande a la ligne de cache
		return oLigne.nGetHauteur(oChampTable);
	}
	// Si la ligne n'est pas dans le cache : fini
	return -1;
};

// Convertit les coordonees visible <=> absolue
WDTableCache.prototype.nPosAbsolue2PosVisible = function nPosAbsolue2PosVisible(nLignePosAbsolue)
{
	// Si la valeur n'est pas dans le cache
	// GP 11/02/2014 : QW242532 : En PHP, on recoit des donn�es invalide et donc on arrive ici avec un tableau des lignes incomplet.
	if (	(0 === this.m_tabLignes.length)
		||	!this.m_tabLignes[0]
		||	(nLignePosAbsolue < this.m_tabLignes[0].vnGetPosAbsolue())
		||	!this.m_tabLignes[this.m_tabLignes.length - 1]
		||	(nLignePosAbsolue > this.m_tabLignes[this.m_tabLignes.length - 1].vnGetPosAbsolue()))
	{
		return nLignePosAbsolue;
	}

	// On parcours nos lignes de cache et supprime les lignes virtuelles
	var i;
	var nLimiteI = this.m_tabLignes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oLigne = this.m_tabLignes[i];
		// Si c'est une ligne virtuelle
		if (oLigne && (oLigne.vnGetPosAbsolue() === nLignePosAbsolue))
		{
			return i + this.m_nDebutCache;
		}
	}
	return nLignePosAbsolue;
};
WDTableCache.prototype.nPosVisible2PosAbsolue = function nPosVisible2PosAbsolue(nLignePosVisible)
{
	if (0 === this.m_tabLignes.length)
	{
		return nLignePosVisible;
	}

	var oLigne = this.oGetLigne(nLignePosVisible);
	if (oLigne)
	{
		// Retourne la valeur de la ligne
		return oLigne.vnGetPosAbsolue();
	}
	// GP 13/11/2014 : QW251211 : Si on ne trouve pas il faut retourner -1. Sinon on a plusieurs lignes pour le m�me indice visible en cas de repliement
//	return nLignePosVisible;
	return -1;
};

// Classe de base des colonnes
function WDTableAJAXColonne (oXMLColonne, nRangCreation)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		var sAlias = clWDAJAXMain.sXMLGetAttributSafe(oXMLColonne, this.XML_ALIAS, "ALIAS");
		var eTypeWL = clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_TYPEWL, 16);
		var tabProprietesSpecifiques =
		[
			// tabProprietesSpecifiques :
			// - 0 : Type de la colonne (= saisie, interrupteur, etc)
			clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, clWDAJAXMain.XML_CHAMP_ATT_TYPE, WDChamp.prototype.ms_nIDObjetSaisie),
			// - 1 : Triable
			clWDAJAXMain.bXMLGetAttributSafe(oXMLColonne, this.XML_TRI),
			// - 2 : Recherche
			clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_RECHERCHE),
			// - 3 : Filtre si filtre actif
			clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_FILTRE),
			// - 4 : Visible
			// C'est potentiellement une s�rie de valeur avec la visiblit� par tranche.
//			clWDAJAXMain.bXMLGetAttributSafe(oXMLColonne, this.XML_VISIBLE),
			clWDAJAXMain.sXMLGetAttributSafe(oXMLColonne, this.XML_VISIBLE, "0"),
			// - 5 : Saisissable
			clWDAJAXMain.bXMLGetAttributSafe(oXMLColonne, this.XML_SAISISSABLE),
			// - 6 : D�placable
			clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_DEPLACE, 0),
			// - 7 : Rang de cr�ation
			nRangCreation,
			// - 8 : Position d'affichage
			clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_POSAFFICHE, nRangCreation),
			// - 9 : Largeur (pour la persistance entre les affichages de la page pour une table AJAX
			clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_LARGEUR, undefined),
			// - 10 : Options de la colonne (dans le cas d'une colonne de type combo (sinon null)
			clWDAJAXMain.tabXMLGetTableauValeur(oXMLColonne, "OPTION"),
			// - 11 : Si la colonne est ajustable
			clWDAJAXMain.bXMLGetAttributSafe(oXMLColonne, this.XML_AJUSTABLE),
			// - 12 : Couleur
			undefined,
			// - 13 : CouleurFond
			undefined,
			// - 14 : Mode d'affichage des images (pour les colonnes images)
			// Le mode historique est imgAdapteCentre (Homot�tique sans agrandissement)
			clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_MODEAFFICHAGE, this.ms_eAdapteCentre)
		];
		WDTableColonne.prototype.constructor.apply(this, [sAlias, eTypeWL, tabProprietesSpecifiques]);

		// Propriete generiques
		this.m_sBulle = clWDAJAXMain.sXMLGetAttributSafe(oXMLColonne, this.XML_BULLE, null);
		this.m_sTitre = clWDAJAXMain.sXMLGetAttributSafe(oXMLColonne, this.XML_TITRE, null);
		this.m_bCurseurDefaut = undefined;

		// Proprietes specifiques
		switch (tabProprietesSpecifiques[0])
		{
		case WDChamp.prototype.ms_nIDObjetCombo:
			// Combo
			break;

		case WDChamp.prototype.ms_nIDObjetInterrupteur:
			// Interrupteur
			break;

		default:
			// Autres
			// Force le type
			this.m_eTypeIDObjet = WDChamp.prototype.ms_nIDObjetSaisie;
			// Et fait comme le champ de saisie et de la champ image => Pas de break;
		case WDChamp.prototype.ms_nIDObjetImage:
			// Image
			// Pas saisissable
			// => G�r� dans WDTableColonne.prototype.bGetSaisissable

			// Et fait comme le champ de saisie => Pas de break
		case WDChamp.prototype.ms_nIDObjetSaisie:
			// Saisie
			// Gestion des liens
			this.m_nLien = clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_LIEN, 0);
			if (this.m_nLien != 0)
			{
				this.m_nEtatLien = clWDAJAXMain.nXMLGetAttributSafe(oXMLColonne, this.XML_ETATLIEN, 0);
			}
			break;

		case WDChamp.prototype.ms_nIDObjetCellule:
			// Cellule (colonne conteneur)
			break;
		}
	}
};

// Declare l'heritage
WDTableAJAXColonne.prototype = new WDTableColonne();
// Surcharge le constructeur qui a ete efface
WDTableAJAXColonne.prototype.constructor = WDTableAJAXColonne;

// Valeur par defaut des proprietes
WDTableAJAXColonne.prototype.m_nLien = 0; // Type de lien : sans
WDTableAJAXColonne.prototype.m_nEtatLien = 0; // Etat du lien : actif
// Constantes
WDTableAJAXColonne.prototype.XML_ALIAS = "ALIAS";
WDTableAJAXColonne.prototype.XML_TYPEWL = "TYPEWL";
WDTableAJAXColonne.prototype.XML_SAISISSABLE = "SAISISSABLE";
WDTableAJAXColonne.prototype.XML_VISIBLE = "VISIBLE";
WDTableAJAXColonne.prototype.XML_LIEN = "LIEN";
WDTableAJAXColonne.prototype.XML_ETATLIEN = "ETATLIEN";
WDTableAJAXColonne.prototype.XML_BULLE = "BULLE";
WDTableAJAXColonne.prototype.XML_TITRE = "TITRE";
WDTableAJAXColonne.prototype.XML_TRI = "TRI";
WDTableAJAXColonne.prototype.XML_RECHERCHE = "RECHERCHE";
WDTableAJAXColonne.prototype.XML_FILTRE = "FILTRE";
WDTableAJAXColonne.prototype.XML_LARGEUR = "LARGEUR";
WDTableAJAXColonne.prototype.XML_DEPLACE = "DEPLACE";
WDTableAJAXColonne.prototype.XML_POSAFFICHE = "POSAFFICHE";
WDTableAJAXColonne.prototype.XML_AJUSTABLE = "AJUSTABLE";
WDTableAJAXColonne.prototype.XML_MODEAFFICHAGE = "MODEAFFICHAGE";

// Classe de base de l'etat d'une ligne
function WDEtatLigne(oChampTable, nLigneHTML)
{
	// On initialise les elements
	if (oChampTable)
	{
		// La ligne physique (balise TR + par defaut invisible)
		this.m_oLignePhysique = oChampTable.oGetIDElement(nLigneHTML);
		this.m_nLigneHTML = nLigneHTML;

		// Les lignes logiques de la ligne
		var i;
		var nLimiteI = oChampTable.vnGetNbLignesLogiquesParLignePhysique();
		this.m_tabLignesLogiques = new Array(nLimiteI);
		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabLignesLogiques[i] = {
				// Par defaut ligne invisible et non remplie
				m_oLigneCache : null,
				// Si on n'a plus d'une colonne manipule les cellules sinon manipule les lignes
				m_oLigneLogique: (nLimiteI > 1) ? oChampTable.oGetIDElement(nLigneHTML, i) : this.m_oLignePhysique,
				// Pas encore affiche
				// GP 01/12/2012 : TB79848 : Ajout de (oChampTable.bGetSansLimite() && (1 < oChampTable.vnGetNbLignesLogiquesParLignePhysique()) && (0 < oChampTable.nGetNbRuptures()))
				// pour le cas des ZRs sans limites, multicolonnes et avec ruptures.
				m_bJamaisAffiche: !oChampTable.vbZR() || (oChampTable.bGetSansLimite() && (1 < oChampTable.vnGetNbLignesLogiquesParLignePhysique()) && (0 < oChampTable.nGetNbRuptures()))
			};
		}
		this.m_tabCacheCelluleHTML = [];

		// Et les ruptures
		this.RecalculeObjetsRuptures(oChampTable, nLigneHTML);
	}
};

// Pas de classe de base
//// Declare l'heritage
//WDEtatLigne.prototype = new xxx();
//// Surcharge le constructeur qui a ete efface
//WDEtatLigne.prototype.constructor = WDEtatLigne;

WDEtatLigne.prototype.oGetLigneLogique = function oGetLigneLogique(nColonneHTML)
{
	return this.m_tabLignesLogiques[nColonneHTML];
};

WDEtatLigne.prototype.oGetLigneLogiqueHTML = function oGetLigneLogiqueHTML(nColonneHTML)
{
	return this.m_tabLignesLogiques[nColonneHTML].m_oLigneLogique;
};

// Recupere une cellule pour les donnees
WDEtatLigne.prototype.oGetCellule = function oGetCellule(nColonneHTML, nColonne, oChampTable)
{
	// Selon si on a :
	// - Une ligne logique par ligne physique mais plusieurs colonnes (cas des tables)
	// - Une ligne logique par ligne physique et une colonne (ZR mono colonnes)
	// - Plusieurs lignes logiques par ligne physique mais une colonne (ZR multi colonnes)
	var nColonneHTMLEffective;
	if (this.m_tabLignesLogiques.length <= 1)
	{
		nColonneHTMLEffective = nColonne;
	}
	else if (0 === nColonne)
	{
		nColonneHTMLEffective = nColonneHTML;
	}
	else
	{
		// Pour avoir la condition de sortie de la boucle de remplissage des lignes
		return null;
	}
	return this.oGetCelluleHTML(oChampTable, nColonneHTMLEffective);
};

// Mise a jour des pointeurs des ruptures
WDEtatLigne.prototype.RecalculeObjetsRuptures = function RecalculeObjetsRuptures(oChampTable, nLigneHTML)
{
	// Et les ruptures
	// Les ruptures n'existent qu'une seule fois par ligne physique
	if (oChampTable.nGetNbRuptures() > 0)
	{
		this.m_oRupturesHaut = oChampTable.oGetIDElement(WDTable.prototype.ID_RUPTURE_HAUT, nLigneHTML);
		this.m_oRupturesBas = oChampTable.oGetIDElement(WDTable.prototype.ID_RUPTURE_BAS, nLigneHTML);
	}
};

// Invalide l'etat de toutes les lignes
WDEtatLigne.prototype.nInvalide = function nInvalide(oChampTable, nPositionAbsolue, bForce, oEvent)
{
	var i;
	var nLimiteI = this.m_tabLignesLogiques.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (this.bPlein(i) || bForce)
		{
			this.MasqueLigne(i, oChampTable, nPositionAbsolue, oEvent, oChampTable.m_tabStyle, oChampTable.__nGetStylePourLigne(nPositionAbsolue));
			nPositionAbsolue++;
		}
	}
	return nPositionAbsolue;
};

// Change la ligne entre une ligne virtuelle et une ligne reelle
WDEtatLigne.prototype.SwapLigneCache = function SwapLigneCache(nColonneHTML, oLigneCache)
{
	this.m_tabLignesLogiques[nColonneHTML].m_oLigneCache = oLigneCache;
};

// Modifie le style de la ligne
WDEtatLigne.prototype.SetStyle = function SetStyle(oChampTable, nColonneHTML, tabStyleClasses, nStyle, nLigneAbsolue)
{
	function __SetStyleUnElement(oElement, nStyle)
	{
		var sClassesInitial = oCible.className;
		// Si ce n'est pas un �l�ment.
		if (undefined === oCible.className)
		{
			return;
		}

		var tabClasses = clWDUtil.tabSplitClasses(sClassesInitial);
		// Supprimes TOUTES les classes possibles.
		clWDUtil.bForEach(tabStyleClasses, function (sClasses)
		{
			clWDUtil.bForEach(clWDUtil.tabSplitClasses(sClasses), function (sClasse)
			{
				clWDUtil.SupprimeDansTableau(tabClasses, sClasse, true);
				return true;
			});
			return true;
		});
		// Puis ajoute les classes du style demand�. Pas besoin de v�rifier les doublons car on a supprimer toutes les classes de tous les styles de tabStyleClasses.
		var sClassesFinal = ((undefined === nStyle) ? tabClasses : tabClasses.concat(clWDUtil.tabSplitClasses(tabStyleClasses[nStyle]))).join(" ");
		if (sClassesInitial !== sClassesFinal)
		{
			oCible.className = sClassesFinal;
		}
	}

	// GP 24/01/2013 : Demande de GF pour les fonds des lignes de ZRs avec un cadre/style (nouveaut� 18 F+1)
	var oCible = this.oGetLigneLogiqueHTML(nColonneHTML);
	// Pour les ZR ajax, la class doit �trer plac�e dans le td et non le tr pour une meilleure application du style (en particulier les bordures)
	if (oChampTable.vbZR())
	{
		// GP 01/09/2014 : Code juste ? Au vu des corrections dans WDTableCacheLigne.prototype.vbMAJLigne (et report� dans WDTable.prototype.vVideCellule))
		// On peut se demander si le code ci dessous est valide.

		// GP 25/01/2013 : m_oLigneLogique manipule diff�rent �l�ment si on est dans une ZR AJAX avec une seule colonne ou plusieurs colonnes
		// (voir l'init de m_oLigneLogique). On doit toujours se replacer sur le td et non sur le tr pour un bonne application du style (en particulier les bordures)
		if (1 < oChampTable.vnGetNbLignesLogiquesParLignePhysique())
		{
			// En multi colonne oCible pointe sur le div indic�, il faut donc remonter au td directement parent
			// (= la valeur de retour de oChampTable.oGetIDElement(nLigneHTML, i))
			oCible = oCible.parentNode;
		}
		else
		{
			// En simple colonne oCible pointe sur le tr, il faut donc descendre au td 1er fils
			oCible = oCible.firstElementChild;
		}
	}

	// Si on est � la s�lection � la cellule : applique la s�lection sur la cellule uniquement
	if (oChampTable.__bSelectionALaCellule())
	{
		// Supprime le style de TOUTES les cellules.
		clWDUtil.bForEach(oCible.childNodes, function (oCelluleHTML)
		{
			__SetStyleUnElement(oCelluleHTML, undefined);
			return true;
		});

		// Fixe le style sur la cellule et pas sur la ligne.
		if (2 === nStyle)
		{
			var oCelluleColonne;
			for (var nColonne = -1; (oCelluleColonne = this.oGetCellule(nColonneHTML, nColonne, oChampTable)); nColonne++)
			{
				if (oChampTable.bLigneEstSelectionnee(nLigneAbsolue, nColonne))
				{
					__SetStyleUnElement(oCelluleColonne, nStyle);
				}
			}
			// Et ne modifie pas la ligne;
			return;
		}
	}

	__SetStyleUnElement(oCible, nStyle);
};

// Indique si une ligne est pleine
WDEtatLigne.prototype.bPlein = function bPlein(nColonneHTML)
{
	return !!this.m_tabLignesLogiques[nColonneHTML].m_oLigneCache;
};

// Indique si une ligne n'a jamais ete affiche. L'appel supprime le flag jamais affiche
WDEtatLigne.prototype.bJamaisAffiche = function bJamaisAffiche(nColonneHTML)
{
	var bJamaisAffiche = this.m_tabLignesLogiques[nColonneHTML].m_bJamaisAffiche;
	if (bJamaisAffiche)
	{
		this.m_tabLignesLogiques[nColonneHTML].m_bJamaisAffiche = false;
	}
	return bJamaisAffiche;
};

// Force la MAJ si la ligne est pleine
WDEtatLigne.prototype.bMAJSiPlein = function bMAJSiPlein(nColonneHTML, oChampTable, nLigneAbsolue, oEvent, bSelection)
{
	var oLigneCache = this.m_tabLignesLogiques[nColonneHTML].m_oLigneCache;
	if (oLigneCache)
	{
		return this.bMAJ(nColonneHTML, oLigneCache, oChampTable, nLigneAbsolue, oEvent, bSelection);
	}
	return false;
};

// MAJ d'une ligne
WDEtatLigne.prototype.bMAJ = function bMAJ(nColonneHTML, oLigneCache, oChampTable, nLigneAbsolue, oEvent, bSelection)
{
	var bRes;
	// Notifie la table de la MAJ => fait dans les fonctions internes

	if (oLigneCache)
	{
		this.AfficheLigne(nColonneHTML, oLigneCache, oChampTable, nLigneAbsolue, oEvent);

		// Maj
		bRes = oLigneCache.vbMAJLigne(oChampTable, nLigneAbsolue, undefined, bSelection);
	}
	else
	{
		this.MasqueLigne(nColonneHTML, oChampTable, nLigneAbsolue, oEvent);
		bRes = true;
	}

	// Notifie la table de la MAJ
	oChampTable.PostMAJLigne(oLigneCache, nLigneAbsolue, bSelection);

	return bRes;
};

// Se detache d'une ligne du cahce (et la vide
WDEtatLigne.prototype.DetacheEtVide = function DetacheEtVide(nColonneHTML, oChampTable)
{
	// Se detache
	this.Detache(nColonneHTML);
	// Et vide la ligne
	oChampTable.vVideCellule(this, nColonneHTML);
};

// Se detache d'une ligne du cache
WDEtatLigne.prototype.Detache = function Detache(nColonneHTML)
{
	this.DetacheO(this.m_tabLignesLogiques[nColonneHTML])
};

// Se detache d'une ligne du cache
WDEtatLigne.prototype.DetacheO = function DetacheO(oLigneLogique)
{
	// La ligne est vide ou va etre videe
	if (oLigneLogique.m_oLigneCache)
	{
		delete oLigneLogique.m_oLigneCache.m_oLigneHTML;
		delete oLigneLogique.m_oLigneCache.m_nColonneHTML;
		oLigneLogique.m_oLigneCache = null;
	}
};

// Affiche une ligne
WDEtatLigne.prototype.AfficheLigne = function AfficheLigne(nColonneHTML, oLigneCache, oChampTable, nLigneAbsolue, oEvent)
{
	var oLigneLogique = this.m_tabLignesLogiques[nColonneHTML];

	// Notifie les champs fils
	oChampTable.PreMAJLigne(oLigneLogique, oEvent);

	// Si la ligne du cache n'est pas la meme que la ligne actuelle
	if (oLigneLogique.m_oLigneCache != oLigneCache)
	{
		// Se detache si besoin
		this.DetacheO(oLigneLogique);
		// Et detache aussi la nouvelle ligne si besoin
		oLigneCache.DetacheEtVide(oChampTable);
		// Et s'attache
		oLigneLogique.m_oLigneCache = oLigneCache;
		oLigneCache.m_oLigneHTML = this;
		oLigneCache.m_nColonneHTML = nColonneHTML;
	}

	// Affiche la cellule
	oLigneLogique.m_oLigneLogique.style.visibility = "inherit";

	// Affiche la ligne complete
	this.vAfficheLigne(oChampTable);
};

// Masque une ligne
WDEtatLigne.prototype.MasqueLigne = function MasqueLigne(nColonneHTML, oChampTable, nLigneAbsolue, oEvent, tabStyleClasses, nStyle)
{
	// La ligne est vide ou va etre videe
	var oLigneLogique = this.m_tabLignesLogiques[nColonneHTML];

	// Notifie les champs fils
	oChampTable.PreMAJLigne(oLigneLogique, oEvent);

	// Se detache si besoin
	this.DetacheO(oLigneLogique);

	// Maj
	oChampTable.vVideCellule(this, nColonneHTML);

	// Vide les ruptures si on est sur la premiere colonne
	if (0 === nColonneHTML)
	{
		oChampTable.VideRuptures(this);
	}

	// Vide les cellules maintenant (pour avoir le fond de la ligne affiche (couleur + redimensionnement)) : fait au dessus
	// Garde l'ancien code pour les ZRs pour le moment
	if (oChampTable.vbZR())
	{
		// Masque la cellule
		oLigneLogique.m_oLigneLogique.style.visibility = "hidden";
	}
	else if (undefined !== tabStyleClasses)
	{
		this.SetStyle(oChampTable, nColonneHTML, tabStyleClasses, nStyle, nLigneAbsolue);
	}


	// L'objet parent a souvent recue la couleur
	if (clWDUtil.bBaliseEstTag(oLigneLogique.m_oLigneLogique.parentNode, "td"))
	{
		oLigneLogique.m_oLigneLogique.parentNode.style.backgroundColor = "transparent";
	}
	// GP 19/02/2013 : QW227832 : Ici la couleur n'est pas sur le parent mais sur la ligne en cas de s�lection
	// GP 20/02/2013 : TBSauf qu'il faut vider la valeur et pas la forcer pour le pas masquer la valeur du style
	if (clWDUtil.bBaliseEstTag(oLigneLogique.m_oLigneLogique, "tr"))
	{
		oLigneLogique.m_oLigneLogique.style.backgroundColor = "";
	}

	// Masque la ligne complete si besoin
	this.vAfficheLigne(oChampTable);
};

// Affiche/Masque la ligne si besoin
WDEtatLigne.prototype.vAfficheLigne = function vAfficheLigne(oChampTable)
{
	if (oChampTable.vbZR())
	{
		this.m_oLignePhysique.style.visibility = this.m_tabLignesLogiques[0].m_oLigneCache ? "inherit" : "hidden";
		// GP 01/12/2012 : TB79848 : Ajout de (oChampTable.bGetSansLimite() && (1 < oChampTable.vnGetNbLignesLogiquesParLignePhysique()) && (0 < oChampTable.nGetNbRuptures()))
		if (oChampTable.bGetSansLimite() && (1 < oChampTable.vnGetNbLignesLogiquesParLignePhysique()) && (0 < oChampTable.nGetNbRuptures()))
		{
			clWDUtil.SetDisplay(this.m_oLignePhysique, undefined != this.m_tabLignesLogiques[0].m_oLigneCache);
		}
	}
	else
	{
		this.m_oLignePhysique.style.visibility = "";
	}
};

// Cache des cellules en coordonees HTML
WDEtatLigne.prototype.oGetCelluleHTML = function oGetCelluleHTML(oChampTable, nColonneHTML)
{
	var oCellule = this.m_tabCacheCelluleHTML[nColonneHTML];
	if (oCellule)
	{
		return oCellule;
	}
	else
	{
		oCellule = oChampTable.oGetIDElement(this.m_nLigneHTML, nColonneHTML);
		this.m_tabCacheCelluleHTML[nColonneHTML] = oCellule;
		return oCellule;
	}
};
// Acc�s direct au cache des cellules
WDEtatLigne.prototype.tabGetCelluleHTMLCache = function tabGetCelluleHTMLCache()
{
	return this.m_tabCacheCelluleHTML;
};

// Classe de base de l'etat des lignes
function WDEtatLignes (oChampTable, nNbLignesHTML)
{
	if (oChampTable)
	{
		var i;
		var nLimiteI = nNbLignesHTML;
		this.m_tabEtatLignes = new Array(nNbLignesHTML);
		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabEtatLignes[i] = new WDEtatLigne(oChampTable, i);
		}
	}
};

// Pas de classe de base
//// Declare l'heritage
//WDEtatLignes.prototype = new xxx();
//// Surcharge le constructeur qui a ete efface
//WDEtatLignes.prototype.constructor = WDEtatLignes;

// Mise a jour des pointeurs des ruptures
WDEtatLignes.prototype.RecalculeObjetsRuptures = function RecalculeObjetsRuptures(oChampTable)
{
	var i;
	var nLimiteI = this.m_tabEtatLignes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		this.m_tabEtatLignes[i].RecalculeObjetsRuptures(oChampTable, i);
	}
};

// Invalide l'etat de toutes les lignes
WDEtatLignes.prototype.Invalide = function Invalide(oChampTable, nPositionAbsolue, nDebut, bForce, oEvent)
{
	var i;
	var nLimiteI = this.m_tabEtatLignes.length;
	for (i = nDebut; i < nLimiteI; i++)
	{
		nPositionAbsolue = this.m_tabEtatLignes[i].nInvalide(oChampTable, nPositionAbsolue, bForce, oEvent);
	}
};

// Recupere le nombre de lignes
WDEtatLignes.prototype.nGetNbEtatLignes = function nGetNbEtatLignes()
{
	return this.m_tabEtatLignes.length;
};

// Recupere une ligne donnee
WDEtatLignes.prototype.oGetEtatLigne = function oGetEtatLigne(nLigneHTML)
{
	return this.m_tabEtatLignes[nLigneHTML];
};

// Cache des cellules en coordonees HTML
WDEtatLignes.prototype.oGetCelluleHTML = function oGetCelluleHTML(oChampTable, nLigneHTML, nColonneHTML)
{
	// GP 04/02/2014 : QW242266 : Uniquement si la ligne existe
	var oEtatLigne = this.oGetEtatLigne(nLigneHTML);
	return oEtatLigne ? oEtatLigne.oGetCelluleHTML(oChampTable, nColonneHTML) : null;
};

// Classe manipulant la table
// La table n'a normalement jamais de table/zr parente
function WDTable(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDTableZRCommun.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ sXMLLignes, eCacheLimite, nHauteurLigne, nPagesMargeMin, nPagesMargeMax, eTypeSelection, tabStyle, tabImagesTriRechercheFiltre, bHauteurLigneVariable ]
		var sXMLLignes = tabParametresSupplementaires[0];
		var eCacheLimite = tabParametresSupplementaires[1];
		var nHauteurLigne = tabParametresSupplementaires[2];
		var nPagesMargeMin = tabParametresSupplementaires[3];
		var nPagesMargeMax = tabParametresSupplementaires[4];
		var eTypeSelection = tabParametresSupplementaires[5];
		var tabStyle = tabParametresSupplementaires[6];
		var tabImagesTriRechercheFiltre = tabParametresSupplementaires[7];
		var bHauteurLigneVariable = tabParametresSupplementaires[8];

		// Donnees de base
		this.m_sXMLLignesInitial = sXMLLignes;
		this.m_eCacheLimite = eCacheLimite; // Si on limite le nombre de ligne dans la page
		this.m_nHauteurLigne = nHauteurLigne;
		// Si on est en nombre limite de ligne
		if (!this.bGetSansLimite())
		{
			this.m_nPagesMargeMin = nPagesMargeMin;	// Nombre minimum de lignes dans le cache avant la premiere ligne affiche (Ou apres la denriere)
			this.m_nPagesMargeMax = nPagesMargeMax;	// Nombre maximum de lignes coserve dans le cache avant la premiere ligne
			this.m_nPagesMargeRequete = parseInt((nPagesMargeMax + nPagesMargeMin) / 2, 10);
		}
		this.m_eTypeSelection = eTypeSelection;	// Type de selection autorisee

		// Tableau des noms de styles
		this.m_tabStyle = tabStyle;

		// Gestion des images et du champ de saisie pour le tri, la recherche et le filtrage dans les colonnes.
		// Uniquement si on est une table
		if (tabImagesTriRechercheFiltre)
		{
			// tabImagesTriRechercheFiltre :
			// - 0 : Images pour les tri : 3 images (pas de tri, tri croissant, tri d�croissant)
			// - 1 : Images pour la recherche : 3 images (recherche, recherche en survol, recherche en saisie)
			// - 2 : Images pour le filtre : 3 images (filtre, filtre en survol, filtre en saisie)
			// - 3 : Images pour le d�placement des colonnes : 2 images (fl�che vers la droite, fl�che vers la gauche)
			this.m_tabFleches = tabImagesTriRechercheFiltre.splice(3, 1)[0];
			this.m_oPopupSaisieTRF = new WDPopupSaisieTRF(this, tabImagesTriRechercheFiltre);
		}

		this.m_bHauteurLigneVariable = bHauteurLigneVariable;

		// Cache du style de la largeur des colonnes
		this.m_oStyleCacheLargeur = new WDStyleCache(true);
		this.m_oStyleCacheLargeur.Creation();
		this.m_oStyleCacheLargeur.CreationFin();

		this.m_tabImagesNonAffichee = [];
		// Cache de la taille des images : index� sur le chemin de l'image. Les images dynamiques ne sont pas incluses
		this.m_tabCacheTailleImage = [];

		this.m_oValideLigneTableZR = null;
		this.m_oDonneFocusTableZR = null;
		// Ne supprime plus m_oMAJDivPosParentScroll : lui donne une valeur par d�faut
		this.m_oMAJDivPosParentScroll = null;
		this.m_bAncrageLargeur = true;
		this.m_bAncrageHauteur = true;
		// Par compatibilit� avec ce qui �tait fait avant (lecture direct du membre) on prend false comme valeur initiale pour ne pas avoir un recalcul suppl�mentaire.
		this.m_bDebordeLargeur = false;

		this.m_oTitrePosPixel = null;
		this.m_bTitrePosPixelParentLargeur_QW269772 = false;

		// Nombre d'initialisation
		this.m_nNbInits = 0;

		// Visibilit� des masques (evite de changer inutilement la visibilit� et la taille)
		// undefined pour forcer le SetDisplay au premier affichage
		this.m_bVisibleMasque = undefined;
		this.m_bVisibleMasqueTransparent = undefined;

		// Se declare dans la table globale des Tables/ZRs AJAX
		this.ms_tabTablesZRs.DeclareChamp(this);

		// GP 08/01/2018 : TB106614 : Transforme l'anti r�entrance en global (Ce n'est pas clair pourquoi on a cette r�entrance en 23).
//		// GP 22/11/2017 : Vu avec TB104223 : anti r�entrance
//		this.m_bDansPostMAJLignes = false;

		// GP 24/11/2017 : TB105752 : on m�morise les changements pr�c�dents
		this.m_oContenuPourValideLigneTableZRSuivant = {};

		this.m_bDansOnSelectLigneExterne = false;

		// Tableau des filtres (lors de cet affichage de la page) par colonne.
		this.m_tabFiltres = [];

		// S'abonne � la notification de changement de tranche (dans le framework V2)
		// => Temporaire : dans le framework v2, les champs recoivent la notification par vOnChangementTranche
		// GP 08/11/2016 : QW279635 : Si la page est RWD, on inclus syst�matiquement le framework V2. Donc plus besoin de tester NSPCS.
		if (clWDUtil.bRWD)
		{
			var oThis = this;
			NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(function ()
			{
				// GP 06/12/2019 : TB115740 : Uniquement si l'initialisation du champ a �t� faite.
				if (oThis.m_oMasque)
				{
					oThis.vOnChangementTranche.apply(oThis, arguments);
				}
			});
		}


		// Ne rien mettre ici qui doit etre remit a zero dans l'init
	}
};

// Declare l'heritage
WDTable.prototype = new WDTableZRCommun();
// Surcharge le constructeur qui a ete efface
WDTable.prototype.constructor = WDTable;

// GP 08/01/2018 : TB106614 : Transforme l'anti r�entrance en global (Ce n'est pas clair pourquoi on a cette r�entrance en 23).
WDTable.prototype.m_bDansPostMAJLignes = false;

// Membres statique/valeurs par defaut
// Donnees semi-dynamique
WDTable.prototype.m_nFacteurAscenseur = 1;		// Le facteur multiplicateur de la barre de defilement (Pour les tables tres tres grandes)
// La limite des barres d'outils n'est pas la meme selon le navigateur
// - IE			134217727	ou 0x7FFFFFF
// - Firefox	71582788	ou 0x4444444
WDTable.prototype.m_nLimiteHauteur = (bIE ? ((nIE >= 8) ? 1342177 : 134217727) : 71582788);
WDTable.prototype.m_nColonneTrie = -1;
WDTable.prototype.m_nColonneTriePre = -1;			// Indication de tri que l'on a recu du serveur
WDTable.prototype.m_bTriCroissant = true;
WDTable.prototype.m_bTriCroissantPre = true;		// Indication de tri que l'on a recu du serveur
WDTable.prototype.m_bFinTrouve = false;				// Si la fin de la table est connue
WDTable.prototype.m_sCleParcourtAP = "";			// Par defaut pas de cle pour le positionnement du parcour en arriere plan
WDTable.prototype.m_bRetourServeurSelection = true;	// Par defaut on notifie le serveur de chaque selection
WDTable.prototype.m_bMasqueVisible = false;
WDTable.prototype.m_nNbRuptures = 0; 			// Nombre de ruptures par defaut (evite un tentative de AMJ si la table n'a pas de ruptures)

WDTable.prototype.ms_oNotifications = new (clWDUtil.WDNotifications)();
WDTable.prototype.ms_oNotificationsSansLimites = new (clWDUtil.WDNotifications)();

// Enumerations de de l'etat de la table au niveau des limites
WDTable.prototype.ms_nCachePartiel = 0; 		// Cache limit� + ascenseur calcul�
WDTable.prototype.ms_nCacheComplet = 1; 		// Cache complet + sans ascenseur
WDTable.prototype.ms_nCacheCompletAscenseur = 2; // Cache limit� + ascenseur natif

WDTable.prototype.XML_NOMBRE = "NOMBRE";
WDTable.prototype.XML_FIN = "FIN";
WDTable.prototype.XML_DEBUT = "DEBUT";
WDTable.prototype.XML_CLEENREGAP = "CLEENREGAP";
WDTable.prototype.XML_SELECTIONS = "SELECTIONS";
WDTable.prototype.XML_SELECTIONS_CELLULE = "CELLULE";
WDTable.prototype.XML_COLONNES = "COLONNES";
WDTable.prototype.XML_LIGNES = "LIGNES";
WDTable.prototype.XML_SELECTION = "SELECTION";
WDTable.prototype.XML_SELECTION_COLONNE = "COLONNE";
WDTable.prototype.XML_COLONNE = "COLONNE";
WDTable.prototype.XML_ERREUR = "ERREUR";
WDTable.prototype.XML_TRI = "TRI";
WDTable.prototype.XML_SENS = "SENS";
WDTable.prototype.XML_DESACTIVESERSEL = "DESACTIVESERSEL";
WDTable.prototype.XML_TYPESELECTION = "TYPESELECTION";
WDTable.prototype.XML_DATA = "DATA";
//WDTable.prototype.XML_HAUTEURLIGNEVARIABLE = "HAUTEURLIGNEVARIABLE";
WDTable.prototype.XML_COLHIERARCHIQUE = "COLHIERARCHIQUE";
//WDTable.prototype.XML_VALMEM = "VALMEM";
WDTable.prototype.ID_SCROLLBAR = "SB";
WDTable.prototype.ID_TABLEINTERNE = "TB";
WDTable.prototype.ID_CHARGEMENT_IMG = "LOAD";
WDTable.prototype.ID_MASQUE = "MASQUE";
WDTable.prototype.ID_MASQUETRANSPARENT = "MASQUETR";
WDTable.prototype.ID_RUPTURE_HAUT = "H";
WDTable.prototype.ID_RUPTURE_BAS = "B";
WDTable.prototype.SEL_SEPARATEUR = ";";
WDTable.prototype.SEL_SEPARATEUR_COLONNE = "|";

// Classe de cache
WDTable.prototype.vCacheLigne = WDTableCacheLigne;

// Fin de l'init (Apres le parcours du HTML)
WDTable.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDTableZRCommun.prototype.Init.apply(this, arguments);

	// Ajoute/patch le style pour la ligne selectionnee
	this.__CreeStyleLigneSelectionne();

	// Trouve les �l�ments de la zone d'affichage principale
	this.m_oMasque = this.oGetIDElement(this.ID_MASQUE);
	this.m_oMasqueTransparent = this.oGetIDElement(this.ID_MASQUETRANSPARENT);
	this.m_oHote = this.oGetIDElement(this.ID_TABLEINTERNE);

	// GP 20/01/2016 : TB94880 : On force le redimensionnement en deux temps si la page contient d'autres tables (ancr�es)
	// => En effet si on a plus de une table la taille de la premi�re donne l'espace de la seconde et r�ciproquement
	// GP 06/04/2016 : TB102527 : Aussi en pr�sence de plans dans firefox
	this.m_bAncrageTimer = (bIEAvec11 && clWDUtil.bHTML5) || (bFF && this.m_oHote && clWDUtil.bDansPlan(this.m_oHote));
	// GP 30/11/2016 : TB100039 : Pour le premier affichage, on peut ne pas le faire en deux temps m�me si la page contient d'autres tables
	this.m_bPremierAncrage = true;

	// Table AJAX avec ascenseur mais toutes les donn�es : on s�pare m_oDivPos et son parent : m_oDivPos est inutile en mode sans limite
	// (et en mode ascenseur avec toutes les donn�es qui est une variante du mode sans limites
	switch (this.m_eCacheLimite)
	{
	case this.ms_nCachePartiel:
		this.m_oDivPos = this.oGetIDElement(clWDTableDefs.ID_POSITION_PIXEL);
		this.m_oDivPosParent = this.m_oDivPos.parentNode;
		break;
	case this.ms_nCacheCompletAscenseur:
		this.m_oDivPosParent = this.m_oHote.parentNode;
		break;
	case this.ms_nCacheComplet:
		this.m_oDivPosParent = this.m_oHote.parentNode;
		break;
	}

	// Calcule si on a un ancrage en largeur
	var oDivPosParentParent = this.m_oDivPosParent.parentElement;
	this.m_bAncrageLargeur = this.__bDimensionAvecAncrage(this.m_oDivPosParent.style.width, oDivPosParentParent && oDivPosParentParent.style.width);
	// GP 06/02/2014 : TB85543 : Et pas d'ancrage nom plus sur les tables AJAX avec cache partiel
	// GP 03/02/2014 : QW242094 : Si une table toute en cache n'est pas ancr�e, il ne faut pas bidouiller sa hauteur !!!
	if (!this.bGetSansLimiteStrict())
	{
		this.m_bAncrageHauteur = this.__bDimensionAvecAncrage(this.m_oDivPosParent.style.height, null);
	}


	// Pour le W3C : la gestion du scroll et du redimensionnement est faite ici par code
	var oThis = this;
	var oTitrePosPixel = this.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_POSITION_PIXEL);
	if (oTitrePosPixel)
	{
		this.m_oTitrePosPixel = oTitrePosPixel;
		// GP 20/07/2015 : TB93763 : Remplacement de oTitrePosPixel par oThis.m_oTitrePosPixel.
		// En effet oThis.m_oTitrePosPixel est recalcul� dans _vtabGenereLignesHTML pour le cas IE (en fait IE8 et autres, mais pas IE11 en edge)
		this.m_oDivPosParent.onscroll = function() { oThis.m_oTitrePosPixel.parentNode.scrollLeft = oThis.m_oDivPosParent.scrollLeft; };
	}

	// GP 06/09/2012 : On ne change pas (avis avec LH et GB) : On respecte l'interface des mac
//	// GP 06/09/2012 : TB78976 : Change le style pour safari (et chrome) sous mac
//	if ((bSfr || bCrm) && bMac)
//	{
//		this.m_oDivPosParent.className += "WDTableWKMac";
//	}

	// Fonction de defilement : uniquement si on a un ascenseur
	if (!this.bGetSansLimite())
	{
		// Fonction de defilement
		this.m_fScroll = function(oEvent) { oThis.DeplaceTable(oEvent || event); };

		// La scroll bar et le div positionnable
		this.m_oAscenseur = this.oGetIDElement(this.ID_SCROLLBAR);
		this.m_oAscenseurParent = this.m_oAscenseur.parentNode;

		// GP 06/09/2012 : On ne change pas (avis avec LH et GB) : On respecte l'interface des mac
//		// GP 06/09/2012 : TB78976 : Change le style pour safari (et chrome) sous mac
//		if ((bSfr || bCrm) && bMac)
//		{
//			this.m_oAscenseurParent.className += "WDTableWKMac";
//		}

		// Initialise la roulette ou le deplacement par le doigt
		this.InitForceDefilement(this.m_oDivPosParent);
	}

	// Initialise le HTML de la ligne en le lisant du fichier Mais uniquement lors de la prmiere init
	// (Lors des suivante le commentair en'existe surement plus)
	this._vInitHTMLLigne();

	// GP 17/01/2014 : D�plac� ici car car appel d�clenche une r�entrance en IE8-, r�entrance qui utilise m_oAscenseurParent et m_oSourceHTML qui doivent donc �tre d�finis.
	// Force un premier affichage/dimensionnement des masques
	this.AfficheMasques(false, true);

	// GP 07/01/2016 : TB93214 : Probl�me avec "_DEB" : ici on lit la valeur initiale (valeur du serveur) et on fait une conversion WL -> C
	// Et effectivement le serveur �crit "1" pour le d�but de la table.
	var oChampDeb = this.oGetElementByName(document, "_DEB");
	var nDebut = 0;
	var sCleDebut;
	if (oChampDeb)
	{
		var nTempDebut = this.nGetDebut(oChampDeb.value);
		if (!isNaN(nTempDebut))
		{
			// Valeur WL => valeur C
			nDebut = nTempDebut - 1;
			var sTempDebutCle = this.sGetDebutCle(oChampDeb.value);
			if (sTempDebutCle)
			{
				sCleDebut = sTempDebutCle;
			}
		}
	}

	// Recupere la selection (Uniquement en mode AWP)
	var sSelection;
	if (clWDAJAXMain.m_bPageAWP && this.m_oChampFormulaire)
	{
		sSelection = this.m_oChampFormulaire.value;

		// On cree un deuxieme champ a cote qui a le meme nom avec un _ en plus pour avoir la selection dans le format que l'on veux
		// (Indice en base 0 separe par des ;) sans perturbe le comportement des autres fonctions
		// On ajoute le champ a la page comme ceci il sera automatiquement place dans TOUS les submit (AJAX ou NON)
		var oFormulaireSelAWP = document.createElement("input");
		oFormulaireSelAWP.type = "hidden";
		oFormulaireSelAWP.name = this.m_oChampFormulaire.name + "_SEL";
		oFormulaireSelAWP.id = oFormulaireSelAWP.name;
		this.m_oChampFormulaireSelAWP = this.m_oChampFormulaire.parentNode.appendChild(oFormulaireSelAWP);
	}

	// Puis appele la fonction avec les donnees de reinitialisation
	this.Reinit(-1, nDebut, sSelection, sCleDebut, this.m_sXMLLignesInitial);
};

// Methode d'initialisation generale de la classe (ne s'execute que lors de l'init de la premi�re instance de ce type)
WDTable.prototype._vInitInitiale = function _vInitInitiale()
{
	// Appel de la methode de la classe de base
	WDTableZRCommun.prototype._vInitInitiale.apply(this, arguments);

	if (clWDUtil.s_ForceReflowDialogueParent)
	{
		this.s_AddNotification(clWDUtil.s_ForceReflowDialogueParent, false);
	}
//	// GP 18/03/2013 : QW231074 :Si on est :
//	// - Avec un mode nombre de ligne illimit� (= la taille change)
//	// - Sous IE
//	// - En HTML5
//	// => On notifie le code de resize de la g�n�ration HTML
//	this.s_AddNotification(clWDUtil.s_ForceRecalculAncrages, true);

// GP 06/09/2012 : On ne change pas (avis avec LH et GB) : On respecte l'interface des mac
//	// GP 06/09/2012 : TB78976 : Change le style pour safari (et chrome) sous mac
//	if ((bSfr || bCrm) && bMac)
//	{
//		// Creation d'un feuille de style globale avec le style de correction
//		var oFeuilleStyleGlobale = clWDUtil.oCreeFeuilleStyle();
//		clWDUtil.CreeStyle(oFeuilleStyleGlobale, ".WDTableWKMac::-webkit-scrollbar", "-webkit-appearance: none; width: 11px; height: 11px;");
//		clWDUtil.CreeStyle(oFeuilleStyleGlobale, ".WDTableWKMac::-webkit-scrollbar-thumb", "border-radius: 8px; border: 2px solid white; background-color: rgba(0, 0, 0, .5);");
//	}

	// S'auto efface pour ne plus etre appele
	WDTable.prototype._vInitInitiale = clWDUtil.m_pfVide;
};

//////////////////////////////////////////////////////////////////////////
// M�thodes de l'interface des tables/zones r�p�t�es

// Click sur une ligne de zone repetee
WDTable.prototype.vTableZROnSelectLigne = function vTableZROnSelectLigne(nLigneAbsolueBase1, oEvent)
{
	try
	{
		// GP 30/04/2018 : TB103858 : Les actions externes ne doivent pas d�clencher l'entr�e en saisie
		var bDansOnSelectLigneExterneOld = this.m_bDansOnSelectLigneExterne;
		this.m_bDansOnSelectLigneExterne = true;

		this._OnSelectLigneAbsolue(nLigneAbsolueBase1 - 1, 0, oEvent);
	}
	finally
	{
		this.m_bDansOnSelectLigneExterne = bDansOnSelectLigneExterneOld;
	}
};

// Valide la ligne selectionnee et envoie la modification au serveur
WDTable.prototype.vTableZROnValideLigne = function vTableZROnValideLigne(oEvent, oChamp/*, oValeur*/)
{
	// Recupere l'ID de la cellule depuis son numero de le ligne (pas d'information de colonne car on est pas dans une table)
	// GP 03/10/2012 : On passe maintenant par _vsGetIDCellule qui utilise l'ID ALIAS_LIGNEHTML_COLONNEHTML
	// Car les id ALIAS_LIGNELOGIQUERELATIVE sont en double...
	var nLigne = this.m_tabSelection[0].m_nLigne;
	var oLigneCache = this.m_oCache.oGetLigne(nLigne);
	var sCelluleId;
	// GP 27/11/2014 : QW252227 : Dans le cas des tables, on ne trouve pas la bonne cellule avec _vsGetIDCellule
	if (oChamp && !this.vbZR())
	{
		var oChampFormulaire = oChamp.m_oChampFormulaire;
		if (oChampFormulaire)
		{
			var sCelulleIdBase = this.m_sAliasChamp + "_" + nLigne + "_";
			var nLimiteColonnes = this.m_tabColonnes.length;
			for (var nColonne = 0; nColonne < nLimiteColonnes; nColonne++)
			{
				var oElement = document.getElementById(sCelulleIdBase + nColonne);
				if (oElement && clWDUtil.bEstFils(oChampFormulaire, oElement))
				{
					sCelluleId = sCelulleIdBase + nColonne;
					break;
				}
			}
		}
	}
	if (undefined === sCelluleId)
	{
		sCelluleId = this._vsGetIDCellule(oLigneCache, nLigne, 0);
	}

	// La selection contient les numero de ligne en valeur absolue et pas en valeur affichee
//	this._OnValideLigneTableZR(new WDValideLigneTableZR(this.sGetIDCellule(this.nAbsolue2Visible2Relative(nLigne)), nLigne, true, ""));
	// -1 : Pas de timer
	this._OnValideLigneTableZR(new WDValideLigneTableZR(sCelluleId, nLigne, true, undefined, -1));
};

// Donne le mode de s�lection de la table/zone r�p�t�e
WDTable.prototype.veGetModeSelection = function veGetModeSelection()
{
	return this.m_eTypeSelection;
};
WDTable.prototype.vbSaisieSansSelection = function vbSaisieSansSelection(nColonne)
{
	// GP 23/05/2016 : TB97877 : Pour avoir la saisie sans s�lection : il ne faut pas avoir de s�lection mais aussi que la colonne soit saisissable
	// Le fait que la colonne soit saisissable a d�j� �t� v�rifie mais pas sur tous les chemins
	if (WDSelection.prototype.ms_nSelectionSans == this.veGetModeSelection())
	{
		// V�rifie que la colonne est saisissable
		return this._oGetColonne(nColonne).m_bSaisissable;
	}
	else
	{
		return false;
	}
};



// Recupere l'ID de la cellule depuis son numero de le ligne et de son information de colonne dans le cas des tables
WDTable.prototype._vsGetIDCellule = function _vsGetIDCellule(oLigneCache, nLigneAbsolue, nColonneSiTable)
{
	// GP 04/12/2015 : TB91441 : On recoit donc maintenant la colonne en param�tre dans le cas des tables
//	// GP 24/11/2015 : TB94063/TB93674 :
//	// - Dans le cas d'une table oLigneCache.vnGetColonneHTML() retourne toujours 0 ce qui fait que l'on manipule exclusivement les champs de la premi�re colonne
//	// => On manipule donc toujours les champs de la premi�re colonne de la premi�religne
	return this._sGetIDCellule(oLigneCache, nLigneAbsolue, nColonneSiTable);
};
// Recupere l'ID de la cellule depuis son numero de le ligne et de son information de colonne dans le cas des tables
WDTable.prototype._sGetIDCellule = function _sGetIDCellule(oLigneCache, nLigneAbsolue, nColonne)
{
	// GP 24/11/2015 : TB94063/TB93674 :
	// - Dans le cas d'une table oLigneCache.vnGetLigneHTML(this.m_nDebut) retourne toujours la premi�re ligne ce qui fait que l'on manipule exclusivement les champs de la premi�re ligne
	return this.oGetIDCelluleRel(oLigneCache.vnGetLigneHTML(nLigneAbsolue) - this.nGetLigneHTMLDebut(), nColonne).id;
//	return this.oGetIDCelluleRel(oLigneCache.vnGetLigneHTML(this.m_nDebut) - this.nGetLigneHTMLDebut(), oLigneCache.vnGetColonneHTML()).id;
//	return this.sGetNomElement(this.sGetSuffixeIDElement.apply(this, arguments));
//	return this.sGetNomElement(this.sGetSuffixeIDElement(oLigneCache.vnGetLigneHTML(this.m_nDebut) - this.nGetLigneHTMLDebut(), oLigneCache.vnGetColonneHTML()));
};

// Class utilitaire pour la validation des lignes
function WDValideLigneTableZR(sCelluleId, nLigneAbsolue, bChangement, oContenuPourValideLigneTableZRSuivant, nTimer)
{
	this.m_nLigneAbsolue = nLigneAbsolue;
	this.m_sCelluleId = sCelluleId;
	this.m_bChangement = bChangement;
	// Recupere le formulaire a la main
	this.m_oContenu = clWDAJAXMain.oCompleteValeurPage(clWDUtil.tabGetElements(document.getElementById(sCelluleId), false), oContenuPourValideLigneTableZRSuivant || {});
	this.m_nTimer = nTimer;
}

// Valide une ligne de table et envoie la modification au serveur
WDTable.prototype.OnValideLigneTableZR = function OnValideLigneTableZR(oEvent, tabParametres)
{
	var sCelluleId = tabParametres[0];
	var nLigneAbsolue = tabParametres[1];
	var bChangement = tabParametres[2];

	// Si on a un contenu pr�c�dent : force un changement
	var oContenuPourValideLigneTableZRSuivant = this.m_oContenuPourValideLigneTableZRSuivant;
	if (0 < Object.getOwnPropertyNames(oContenuPourValideLigneTableZRSuivant).length)
	{
		bChangement = true;
		// RAZ du membre
		this.m_oContenuPourValideLigneTableZRSuivant = {};
	}

	// Si on est dans un lien n'active uniquement si on a recu le focus APRES une modification
	if (this.bEstLienOuImageDansLien(oEvent))
	{
		if (!this.m_bValideLigneTableZRCelluleDansLien)
		{
			return;
		}
		else
		{
			// Pour ne plus influencer le prochain passage
			delete this.m_bValideLigneTableZRCelluleDansLien;
		}
	}

	// GP 06/09/2012 : TB78540 : Filtr� dans _OnValideLigneTableZR pour que OnFocusLigneTableZR d�tecte le cas
//	// Si pas de changement : fini
//	if (!bChangement)
//	{
//		return;
//	}

	// Pour les gestion du champ qui prend le focus on se fait un SetTimeout (imm�diat)
	// Comme ca le onfocus a le temps de traiter le cas et de nous bloquer
	// Seulement si on n'a pas deja un timeout
	if (null == this.m_oValideLigneTableZR)
	{
		this.m_oValideLigneTableZR = new WDValideLigneTableZR(sCelluleId, nLigneAbsolue, bChangement, oContenuPourValideLigneTableZRSuivant, this.nSetTimeout(this._OnValideLigneTableZRTimer, clWDUtil.ms_oTimeoutImmediat));
	}
};

// Valide une ligne de table et envoie la modification au serveur
WDTable.prototype._OnValideLigneTableZRTimer = function _OnValideLigneTableZRTimer()
{
	// Recuperation et suppression des proprietes
	var oValideLigneTableZR = this.m_oValideLigneTableZR;
	this.m_oValideLigneTableZR = null;

	// GP 08/11/2017 : TB105322 : Si on a un submit complet de la page en attente, on le laisse passer en priorit�.
	// Dans le cas de la fiche une modification d'un champ d'une ZR provoque un submit et l'appel de OnValideLigneTableZR.
	// Si le setTimeout du submit passe en premier pas de probl�me, l'appel est synchrone et d�clenche la MAJ de la table.
	// Si le setTimeout de OnValideLigneTableZR passe en premier : probl�me et �chec de la MAj de la table.
	if (clWDUtil.bForEach(clWDAJAXMain.m_tabRequetes, function(oRequete)
	{
		return 2 != oRequete.nOption;
	}))
	{
		// Et envoi la requete
		this._OnValideLigneTableZR(oValideLigneTableZR);
	}
};
// Annule un appel en attente de _OnValideLigneTableZRTimer
WDTable.prototype._AnnuleValideLigneTableZRTimer = function _AnnuleValideLigneTableZRTimer()
{
	if (null !== this.m_oValideLigneTableZR)
	{
		clWDUtil.ClearTimeout(this.m_oValideLigneTableZR.m_nTimer);
		this.m_oValideLigneTableZR = null;
	}
};

// Valide une ligne de table et envoie la modification au serveur
WDTable.prototype._OnValideLigneTableZR = function _OnValideLigneTableZR(oValideLigneTableZR)
{
	// GP 06/09/2012 : TB78540 : Filtre le changement ici pour que OnFocusLigneTableZR d�tecte le cas
	if (false == oValideLigneTableZR.m_bChangement)
	{
		return;
	}

	// Et envoi la requete
	// Uniquement si on a des valeurs sinon le serveur fait une erreur de manque de valeurs
	var oContenu = oValideLigneTableZR.m_oContenu;
	if (oContenu)
	{
		var sContenu = clWDAJAXMain.sConstruitValeursChamps(oContenu);
		if (sContenu.length > 0)
		{
			this.m_oCache.CreeRequeteModifLigne(this, oValideLigneTableZR.m_nLigneAbsolue, true, sContenu);
		}
	}
};

// Indique qu'une ligne donnee de la ZR a recu le focus
WDTable.prototype.OnFocusLigneTableZR = function OnFocusLigneTableZR(oEvent, tabParametres)
{
	var sCelluleId = tabParametres[0];
	var nLigneAbsolue = tabParametres[1];
	var nNumElement = tabParametres[2];
	var nColonne = tabParametres[3];

	// GP 27/09/2013 : TB84173 : Si on a un DonneFocus en attente : ne fait rien
	// !!! Ce changement a probablement des effets de bord d�plaisant. Mais le cas est rare donc sans meilleure correct je laisse !!!
	if (0 != clWDUtil.eGetEtatFocus())
	{
		return;
	}

	var bAttendMAJTablePourDonnerFocus = false;

	// Si on a un traitement de focus en attente
	var oValideLigneTableZR = this.m_oValideLigneTableZR;
	if (null !== oValideLigneTableZR)
	{
		// Si ce traitement de focus est pour la m�me ligne : le bloque
		// GP 24/11/2017 : TB105752 : Si on est sur une table avec plusieurs colonnes conteneurs, l'ID des cellules est diff�rent par conteneur. Il ne faut donc pas utiliser cette information.
		if (	(	(!this.vbZR())
				||	(oValideLigneTableZR.m_sCelluleId == sCelluleId))
			&&	(oValideLigneTableZR.m_nLigneAbsolue == nLigneAbsolue))
		{
			// GP 06/09/2012 : M�morise le changement si on a plusieurs champ
			if (oValideLigneTableZR.m_bChangement)
			{
				this.m_oContenuPourValideLigneTableZRSuivant = oValideLigneTableZR.m_oContenu;
			}
			// Si on est dans un lien n'active uniquement si on a recu le focus APRES une modification
			if (this.bEstLienOuImageDansLien(oEvent))
			{
				this.m_bValideLigneTableZRCelluleDansLien = true;
			}
			this._AnnuleValideLigneTableZRTimer();
			// GP 06/09/2012 : TB78540 : Ici on sort (pour ne pas perdre le focus si a deux champs sur la ligne)
			// et plus loin on donne le focus dans tous les cas au premier champ
			return;
		}
		else
		{
			// On a un appel de OnValideLigneTableZR en attente.
			// Cet appel va envoyer une requ�te de MAJ de ligne vers le serveur. La r�ponse va d�clencher la MAJ compl�te de la table/ZR.
			// Ce qui risque de nous faire perdre le focus nouvellement plac�.
			// 2 corrections possible :
			// - Ne plus faire la MAJ compl�te de la table.
			// - Attente la MAJ compl�te de la table pour donner le focus.
			// => On fait la seconde car la premi�re pr�sente trop de risques.
			bAttendMAJTablePourDonnerFocus = true;
		}
	}

	// GP 19/10/2012 : QW224195 : G�re aussi le focus dans le cas sans limites
	var nDefilement = this.__nGetDefilementPourAfficherLigne(nLigneAbsolue);

	// GP 06/09/2012 : TB78540 : (nDefilement != 0) : Filtr� dans DonneFocusTableZR qui donne le focus dans tous les cas
	// GP 12/07/2012 : En revanche il y a un probl�me : la ligne a �t d�plac� donc le sCelluleId n'est plus valide
	this.m_oDonneFocusTableZR = new WDDonneFocusTableZR(nDefilement/*, sCelluleId*/, nLigneAbsolue, nNumElement, nColonne);
	if (!bAttendMAJTablePourDonnerFocus)
	{
		// Et note de redonner le focus avec deplacement
		this.nSetTimeout(this.DonneFocusTableZR, clWDUtil.ms_nTimeoutNonImmediat20);
	}
	else
	{
		// Ne fait rien, c'est la MAJ des lignes qui va faire l'appel de DonneFocusTableZR
	}
};

WDTable.prototype.__nGetDefilementPourAfficherLigne = function __nGetDefilementPourAfficherLigne(nLigneAbsolue)
{
	if (!this.bGetSansLimite())
	{
		// Si la ligne est au debut et a moitie visible ou a la fin : force le defilement
		if ((nLigneAbsolue === this.m_nDebut) && (parseInt(this.m_oDivPos.style.top, 10) < 0))
		{
			return parseInt(this.m_oDivPos.style.top, 10);
		}
		else if (nLigneAbsolue >= (this.m_nDebut + this.m_nNbLignesPage))
		{
			return parseInt(this.m_oAscenseur.style.height, 10) / (this.m_nNbLignes / this.vnGetNbLignesLogiquesParLignePhysique());
		}
	}

	// GP 04/12/2017 : QW294219 : R�gression introduite par la correction de TB105771
	// Il faut renvoyer 0 dans tous les autres cas (et pas undefined s'il manque le return)
	return 0;
};

function WDDonneFocusTableZR(nDefilement/*, sCelluleId*/, nLigneAbsolue, nNumElement, nColonne)
{
	this.m_nDefilement = nDefilement;
//	this.m_sCelluleId = sCelluleId);
	this.m_nLigneAbsolue = nLigneAbsolue;
	this.m_nNumElement = nNumElement;
	// La colonne est utilis� dans le cas des tables
	this.m_nColonne = nColonne;
}

// Redonne le focus a un champ de la ZR sur une ligne donnee
WDTable.prototype.DonneFocusTableZR = function DonneFocusTableZR()
{
	var oDonneFocusTableZR = this.m_oDonneFocusTableZR;
	this.m_oDonneFocusTableZR = null;
	// Si un appel de la MAJ des lignes est pass�, on n'a plus this.m_oDonneFocusTableZR
	if (null === oDonneFocusTableZR)
	{
		return;
	}

	// GP 06/09/2012 : TB78540 : Filtr� ici et pas dans l'appelant (donne le focus dans tous les cas)
	// Si on a un defilement
	if (oDonneFocusTableZR.m_nDefilement)
	{
		this.__nForceDefilement(oDonneFocusTableZR.m_nDefilement, null, false);
	}

	// Donne le focus au champ
	var oLigneCache = this.m_oCache.oGetLigne(oDonneFocusTableZR.m_nLigneAbsolue);
	// 28/06/2018 : TB109368 : Si on a supprim� la ligne. Par exemple si on �tait sur la derni�re ligne et qu'elle s'est auto supprim�e, on ne peut pas donner le focus.
	// Le sympt�me de ce cas est le fait que oLigneCache est null.
	if (oLigneCache)
	{
		// GP 12/07/2012 : En revanche il y a un probl�me : la ligne a �t d�plac� donc le sCelluleId n'est plus valide
		var sCelluleId = this._vsGetIDCellule(oLigneCache, oDonneFocusTableZR.m_nLigneAbsolue, oDonneFocusTableZR.m_nColonne);
		var tabContenu = clWDUtil.tabGetElements(document.getElementById(sCelluleId), false);
		// GP 12/07/2012 : TB77947 : Ce calcul est n'importe quoi. sCelluleId est cellule de la ligne logique.
		// Donc il n'y a pas de d�callage. On donne direct le focus au premier �l�ment
	//	var nNumElement = (oLigneCache.vnGetLigneHTML(nLigneAbsolue) - this.nGetLigneHTMLDebut()) * this.vnGetNbLignesLogiquesParLignePhysique() + oLigneCache.vnGetColonneHTML();
	//	var nNumElement = 0;
		if (tabContenu && tabContenu[oDonneFocusTableZR.m_nNumElement])
		{
			try
			{
				// GP 03/09/2018 : TB109930 : Gestion d'un syst�me de priorit�. Un appel de DonneFocus en WL sera toujours prioritaire.
				clWDUtil.DonneFocus(tabContenu[oDonneFocusTableZR.m_nNumElement], true);
			}
			catch (e)
			{
			}
		}
	}
};

// Indique si le champ source d'un evenement est un lien ou une image dans un lien
WDTable.prototype.bEstLienOuImageDansLien = function bEstLienOuImageDansLien(oEvent)
{
	// Si on est dans un lien n'active uniquement si on a recu le focus APRES une modification
	if (!oEvent)
	{
		return false;
	}
	var oChamp = clWDUtil.oGetTarget(oEvent);
	switch (clWDUtil.sGetTagName(oChamp))
	{
	// Selon le cas (on peut avoir une image dans le lien et alors la source est l'image et pas le lien)
	case "img":
		return clWDUtil.bBaliseEstTag(oChamp.parentNode, "a");
	case "a":
		return true;
	default:
		return false;
	}
};

// Notifications pour le fin de MAJ
WDTable.prototype.s_AddNotification = function s_AddNotification(pfNotification, bSansLimiteSeulement)
{
	(bSansLimiteSeulement ? WDTable.prototype.ms_oNotificationsSansLimites : WDTable.prototype.ms_oNotifications).AddNotification(pfNotification);
};

// Enumerations de de l'etat de la table au niveau des limites
// Retourne l'ancien bool�en m_bSansLimite
WDTable.prototype.bGetSansLimite = function bGetSansLimite()
{
	switch (this.m_eCacheLimite)
	{
	case this.ms_nCacheComplet:
	case this.ms_nCacheCompletAscenseur:
		return true;
	default:
		return false;
	}
};
WDTable.prototype.bGetSansLimiteStrict = function bGetSansLimiteStrict()
{
	return this.m_eCacheLimite == this.ms_nCacheComplet;
};
WDTable.prototype.bGetCacheCompletAscenseur = function bGetCacheCompletAscenseur()
{
	return this.m_eCacheLimite == this.ms_nCacheCompletAscenseur;
};
// Indique si on peut avoir un ascenseur
WDTable.prototype.bAscenseurPossible = function bAscenseurPossible()
{
	switch (this.m_eCacheLimite)
	{
	case this.ms_nCachePartiel:
	case this.ms_nCacheCompletAscenseur:
		return true;
	default:
		return false;
	}
};

// Ajoute/patch le style pour la ligne selectionnee
WDTable.prototype.__CreeStyleLigneSelectionne = function __CreeStyleLigneSelectionne()
{
	var sStyleSelection = this.m_tabStyle[2];
	if (0 < sStyleSelection.length)
	{
		// GP 27/02/2015 : QW255386 : Parse les surcharges de styles
		var oStyleCSS = {};
		var oThis = this;
		// Maintenant que l'on a le style de s�lection sur les ZRs, on peut avoir un style plus compliqu� ici avec plusieurs classes.
		clWDUtil.bForEach(sStyleSelection.split(" "), function (sStyle)
		{
			if (sStyle !== "")
			{
				oThis.__ParseCSSTexteStyleSelection("." + sStyle, oStyleCSS);
			}
			return true;
		});
		// Ce n'est pas clair quel est le pr�fixe dans quels cas : teste les deux, une seul sera non vide
		this.__ParseCSSTexteStyleSelection("#ctz" + this.m_sAliasChamp + " ." + sStyleSelection, oStyleCSS);
		this.__ParseCSSTexteStyleSelection("#con-" + this.m_sAliasChamp + " ." + sStyleSelection, oStyleCSS);

		var tabCSSTexteStyleSelection = [];
		clWDUtil.bForEachIn(oStyleCSS, function(sCle, sValeur)
		{
			tabCSSTexteStyleSelection.push(sCle + ":" + sValeur);
			return true;
		});
		var sCSSTexteStyleSelection = tabCSSTexteStyleSelection.join(";");
		if (0 < sCSSTexteStyleSelection.length)
		{

			this.m_sCSSTexteStyleSelection = sCSSTexteStyleSelection;
			this.m_tabCSSTexteCelluleSelection = [];
		}
	}
};
// Charge un style pour les lignes s�lectionn�es : ignore les background-xxx qui sont geres autrement et correctement
// Retourne un objet : cl�+valeur
WDTable.prototype.__ParseCSSTexteStyleSelection = function __ParseCSSTexteStyleSelection(sSelecteur, oStyleCSS)
{
	var sBackground = "background-";
	var sColor = "color";
	var sImage = "image";

	// Supprime les background-xxx qui sont geres autrement et correctement
	var oThis = this;
	clWDUtil.bForEach(clWDUtil.sGetCSSTexte(sSelecteur).split(";"), function(sStyle)
	{
		if (0 < sStyle.length)
		{
			// Ne fait pas un slpit pour le cas ou l'on a plus de un : un entre cl�e et valeur et un (ou plusieurs) dans la valeur
			var nPositionDeuxPoints = sStyle.indexOf(":");
			if (0 < nPositionDeuxPoints)
			{
				var sCle = clWDUtil.sSupprimeEspaces(sStyle.substr(0, nPositionDeuxPoints));
				var sValeur = clWDUtil.sSupprimeEspacesDebutFin(sStyle.substr(nPositionDeuxPoints + 1));
				if (sBackground == sCle.substr(0, sBackground.length).toLowerCase())
				{
					if (sColor == sCle.substr(sBackground.length, sColor.length).toLowerCase())
					{
						// On fait les appels dans l'ordre de priorit� sur les divers s�lecteur donc le plus prioritaire est appel� en dernier et �crase les m_sCSSTexteStyleSelectionCouleurFond pr�c�dent si besoin)
						oThis.m_sCSSTexteStyleSelectionCouleurFond = sValeur;
					}
					// GP 08/10/2015 : TB93923
					else if (sImage == sCle.substr(sBackground.length).toLowerCase())
					{
						// Seulement si oThis.m_sCSSTexteStyleSelectionCouleurFond est encore non d�fini
						if (undefined === oThis.m_sCSSTexteStyleSelectionCouleurFond)
						{
							oThis.m_sCSSTexteStyleSelectionCouleurFond = "";
						}
					}
					// Ignore ce style : ne l'ajoute pas � oStyles
				}
				else
				{
					// Ajoute le style dans oStyles
					// On fait les appels dans l'ordre de priorit� sur les divers s�lecteur donc le plus prioritaire est appel� en dernier et �crase la valeur pr�c�dente si besoin
					oStyleCSS[sCle] = sValeur;
				}
			}
		}

		return true;
	});
};

// Recupere le debut depuis une valeur
WDTable.prototype.nGetDebut = function nGetDebut(sValeur)
{
	return parseInt(sValeur, 10);
};

// Recupere la cle du debut depuis une valeur
WDTable.prototype.sGetDebutCle = function sGetDebutCle(sValeur)
{
	sValeur = sValeur + "";
	if (sValeur.indexOf(";") > -1)
	{
		return sValeur.substring(sValeur.indexOf(";") + 1);
	}
	return null;
};

// Recupere le HTML d'une ligne dans la table
WDTable.prototype._vInitHTMLLigne = function _vInitHTMLLigne()
{
	// Recupere la balise table.
	// Code JSON pour les tables, code HTML pour les ZRs
	this.m_oSourceHTML = clWDUtil.oEvalJSON(clWDUtil.sGetHTMLDansCommentaire(this.m_oHote));
};

// Code commun a premiere init mais aussi au init suivantes
WDTable.prototype.Reinit = function Reinit(nColonneTrie, nDebut, sSelection, sCleDebut, sXMLLignes)
{
	// Si trop d'init (ie trop d'erreurs) : on arrete
	if (++this.m_nNbInits > 16)
	{
		return;
	}

	// Affecte la colonne de tri
	if (!(nColonneTrie === undefined))
	{
		this.m_nColonneTrie = nColonneTrie;
		this.m_nColonneTriePre = nColonneTrie;
	}

	// Donnees dynamique qui doivent etre redefinie lors de la recreation de la table
	this.SetDebut(0); 				// Premiere ligne affiche
	this.m_nNbLignes = 0; 			// Nombre de lignes total de la table
	if (this.m_oAffichageColonnes)
	{
		this.m_oAffichageColonnes.LibereTitres();
	}
	if (this.m_tabFleches)
	{
		// Tables seulement : gestionnaire de redimensionnement des colonnes
		this.m_oAffichageColonnes = new WDAffichageColonnes(this, this.m_tabFleches, this.m_oStyleCacheLargeur);
		// Tables seulement : gestion de la saisie
		this.m_oCelluleSaisie = new WDCelluleAJAXSaisie(this);
	}
	this.m_tabSelection = []; 		// Tableau des lignes selectionnees
	this.m_tabColonnes = []; 		// Les proprietes des colonnes
	this.m_nNbLignesPage = this.bGetSansLimite() ? 0 : -1; // Nombre de ligne dans la page
	this.m_oCache = new WDTableCache(this, this.vCacheLigne); // Notre cache

	// Restaure la selection si demande
	if (sSelection)
	{
		var tabSelection = this.m_tabSelection;
		clWDUtil.bForEachThis(sSelection.split(this.SEL_SEPARATEUR), this, function (sUneSelection)
		{
			var tabLigneColonne = sUneSelection.split(WDTable.prototype.SEL_SEPARATEUR_COLONNE);
			var nLigne = parseInt(tabLigneColonne[0], 10);
			if (isNaN(nLigne))
			{
				// Valeur invalide : fin du parsing.
				return false;
			}

			// Ajoute la ligne
			// Le cas ou tabLigneColonne[1] n'existe pas est g�r� par __oConstruitUneSelection.
			tabSelection.push(this.__oConstruitUneSelection(nLigne, parseInt(tabLigneColonne[1], 10)));

			return true;
		});

		// Met la valeur dans le formulaire
		// GP 25/10/2021 : Il n'y avais pas le +1 avant ! Mais il est dans WDTable.prototype.bLigneDeselectionne...
		this._vSetValeurChampFormulaire(tabSelection.length > 0 ? (tabSelection[tabSelection.length - 1].m_nLigne /*+ 1*/) : "");
	}

	// Puis on initialise ce qui depend de la taille de la zone cliente :
	// Membre, defilement, HTML des lignes etc
	// En forcant la recuperation du chache
	// 0 = Reinit, 1 = Display, 2 = Resize
	this.OnResizeTable(0, nDebut, sCleDebut, sXMLLignes);
};

// Initialise le deplacement par le doigt
WDTable.prototype.InitForceDefilement = function InitForceDefilement(oCible)
{
	var oThis = this;
	if (bTouch)
	{
		new WDDragTouch(function(nOffsetX, nOffsetY, oEvent)
		{
			// D�filement de la table (nOffsetY a d�j� �t� "invers�")
			oThis.__bForceDefilement(nOffsetY, oEvent);
			// D�filement horizontal si besoin
			if (oThis._vbGetDebordeLargeur())
			{
				// "+" car nOffsetX a d�j� �t� "invers�"
				oCible.scrollLeft = Math.max(0, oCible.scrollLeft + nOffsetX);
			}
		}, oCible);
	}
	else
	{
		clWDUtil.AttacheDetacheEvent(true, oCible, bFF ? 'DOMMouseScroll' : 'mousewheel', function __OnForceDefilement(oEvent)
		{
			// Defilement par ma roulette
			oEvent = oEvent || event;
			var nDeplacement;
			if (oEvent.wheelDelta)
			{
				// IE
				nDeplacement = -oEvent.wheelDelta / 180 * oThis.m_nHauteurLigne;
			}
			else
			{
				// Firefox
				nDeplacement = (oEvent.detail ? oEvent.detail : 0) * 20;
			}

			return oThis.__bForceDefilement(nDeplacement, oEvent);
		}, WDDrag.prototype.ms_oCaptureSansPassiveSans);
	}
};

// Defilement par la zone d'affichage (Roulette ou au doigt)
WDTable.prototype.__bForceDefilement = function __bForceDefilement(nDeplacement, oEvent)
{
	// Uniquement si on a des lignes affichees
	if ((0 != this.m_nNbLignes) && (0 != nDeplacement))
	{
		// Gestion specifique de l'evenement roulette SI il y a deplacement (pour les ZRs)
		nDeplacement = this.__nForceDefilement(nDeplacement, oEvent, true);

		// Uniquement si on a un deplacement
		if (nDeplacement != 0)
		{
			// S'il y a eu deplacement : Evite la remonte de l'evenement et empeche la propagation de l'evenement
			return clWDUtil.bStopPropagationCond(oEvent, (nDeplacement != 0));
		}
	}
	// Gestion native de l'event
	return true;
};

// Gestion sepcifique de l'evenement roulette SI il y a deplacement
WDTable.prototype.__nForceDefilement = function __nForceDefilement(nDeplacement, oEvent, bCallbackSiDeplacement)
{
	// Si pas de possibilite de defilement : fini
	var nHauteurAscenseur = parseInt(this.m_oAscenseur.style.height, 10);
	if (nHauteurAscenseur <= this.m_oAscenseurParent.clientHeight)
	{
		return 0;
	}

	var nAnciennePosition = this.m_oAscenseurParent.scrollTop;
	var nNouvellePosition;
	// Deplace l'ascenseur
	if (nAnciennePosition + nDeplacement < 0)
	{
		nNouvellePosition = 0;
	}
	else if (nAnciennePosition + nDeplacement > nHauteurAscenseur - this.m_oAscenseurParent.clientHeight)
	{
		nNouvellePosition = nHauteurAscenseur - this.m_oAscenseurParent.clientHeight;
	}
	else
	{
		nNouvellePosition = nAnciennePosition + nDeplacement;
	}

	// Appel de la callback
	// Utilise nNouvellePosition (meme si c'est parfois faux) car sinon cela declenche un appel du scroll (juste la lecture de scrollTop suffit
	if (bCallbackSiDeplacement && (nNouvellePosition != nAnciennePosition))
	{
		this._vForceDefilement(oEvent);
	}

	// Deplacement de l'ascenseur
	this.m_oAscenseurParent.scrollTop = nNouvellePosition;
	this.DeplaceTable(oEvent);

	// Renvoie le deplacement reel
	return this.m_oAscenseurParent.scrollTop - nAnciennePosition;
};

WDTable.prototype._vForceDefilement = clWDUtil.m_pfVide;

// Met a jour le nombre de lignes
WDTable.prototype.bMAJNbLignesVisibles = function bMAJNbLignesVisibles(bMAJLignes, bTestUniquement, bForce)
{
	clWDUtil.WDDebug.DebutFonction("bMAJNbLignesVisibles");

	// Invalide la valeur actuelle du d�bordement en largeur
	this._vInvalideDebordeLargeur();

	// Calcule le nombre de ligne a afficher et met a jour ce nombre si besoin
	if (this.bGetSansLimite())
	{
		// @@@
//		// GP 27/01/2014 : Pour avoir l'alignement des titres
//		// Applique la visibilite des colonnes
//		this.AfficheColonnes();

		clWDUtil.WDDebug.FinFonction();
		return false;
	}

	// Redimensionne l'ascenseur si besoin
	this.RedimAscenseur();

	// Et le nombre a changer
	var bNbLignesChange = this.bCalculeLigneAffiche(bTestUniquement) || bForce;
	// Si c'est seulement un test : sort direct
	if (bTestUniquement)
	{
		clWDUtil.WDDebug.FinFonction();
		return bNbLignesChange;
	}

	if (bNbLignesChange)
	{
		// Reaffiche les lignes
		this.__GenereLignesHTML();
		this.InitEtatLignes(this.m_nNbLignesHTML);

		// Applique la visibilite des colonnes
		this.AfficheColonnes();

		// Force le recalcul des marges
		this.m_oCache.RecalculeMarges(this);
	}

	// Met a jour l'ascenseur de droite (Ajout d'une hauteur fixe pour l'ascenseur si besoin)
	this.MAJAscenseur();

	// Et met a jour l'affichage si besoin
	if (bMAJLignes && bNbLignesChange)
	{
		this.bMAJLignes();
	}

	clWDUtil.WDDebug.FinFonction();
	return bNbLignesChange;
};

// Recoit un redimensionnement de la table principale
WDTable.prototype.OnResizeTable = function OnResizeTable(nDisplayOuResize, nDebut, sCleDebut, sXMLLignes)
{
	clWDUtil.WDDebug.DebutFonction("OnResizeTable");

	// GP 27/01/2014 : Factoris� ici
	var bMAJDifferee;
	// GP 08/02/2018 : QW296033 : Le code des ancrages superposable de IE en RWD, force une notification de changement de tranche au chargement.
	// Cette notification est maintenant asynchrone et l'ordre des appels avec les appels asynchrone de cette classe ne tombent plus bien (= cela ne marche plus).
	// La correction simple est ne pas faire le remplissage maintenant si on est avec IE en RWD.
	if ((0 === nDisplayOuResize) && bIEAvec11 && clWDUtil.bRWD && sXMLLignes)
	{
		bMAJDifferee = true;
	}
	else
	{
		bMAJDifferee = this.__bMAJDivPosParentHauteur(nDisplayOuResize);
	}

	if ((!bMAJDifferee) || (undefined !== nDebut))
	{
		this.__OnResizeTable(nDisplayOuResize, nDebut, sCleDebut, sXMLLignes, false);
	}

	clWDUtil.WDDebug.FinFonction();
};
WDTable.prototype.__OnResizeTable = function __OnResizeTable(nDisplayOuResize, nDebut, sCleDebut, sXMLLignes, bForce)
{
	clWDUtil.WDDebug.DebutFonction("__OnResizeTable");

	// GP 21/01/2016 : QW268104 (OPTIM aussi) : Ne fait rien dans un resize si la table n'est pas ancr�e
	// 0 = Reinit, 1 = Display, 2 = Resize
	if ((!this.m_bAncrageLargeur) && (!this.m_bAncrageHauteur) && (2 == nDisplayOuResize))
	{
		clWDUtil.WDDebug.FinFonction();
		return;
	}

	// Met a jour le nombre de lignes
	this.bMAJNbLignesVisibles(false, false, bForce);

	// GP 25/11/2013 : Replace le code de redimensionnement original
	// Remet les colonnes comme il faut si besoin
	if (!this._vbGetDebordeLargeur() && this.m_oAffichageColonnes)
	{
		this.m_oAffichageColonnes.ColonnesRestaure();
	}

	// Si on a un nouveau debut a utiliser => Place la table a cet endroit
	// Force au passage le nombre de ligne de la table pour eviter que les verifs internes ne remettent le debut a zero
	// (La valeur provient du serveur donc a priori est valide)
	var bForceMAJAscenseur = false;
	if (nDebut && (nDebut > 1))
	{
		this.SetDebut(nDebut, sCleDebut);
		this.m_nNbLignes = nDebut + this.m_nNbLignesPage;

		if (!this.bGetSansLimite())
		{
			// Met a jour l'ascenseur de droite (Ajout d'une hauteur fixe pour l'ascenseur si besoin)
			this.MAJAscenseur(true);
			// GP 28/11/2013 : QW240015 : On a fait un calcul aproximatif du nombre de lignes, indique qu'il va falloir faire un calcul plus pr�cis apr�s la MAJ du contenu
			bForceMAJAscenseur = true;
		}
	}

	// Si on a un contenu initial, l'utilise pour le placer dans le cache
	var bAfficheMasque;
	if (sXMLLignes)
	{
		var oXML = this._oParseToXML(sXMLLignes);
		if (oXML && oXML.firstChild)
		{
			var oXMLLignes;
			// Avec IE on a une node en plus en premier : pour le document de type XML (on ne l'a pas avec les autres navigateur)
			if (oXML.firstChild.tagName == clWDAJAXMain.XML_LISTE)
			{
				oXMLLignes = oXML.firstChild;
			}
			else if (oXML.firstChild.nextSibling && (oXML.firstChild.nextSibling.tagName == clWDAJAXMain.XML_LISTE))
			{
				oXMLLignes = oXML.firstChild.nextSibling;
			}

			if (oXMLLignes)
			{
				bAfficheMasque = !this.bActionListe(oXMLLignes, bForceMAJAscenseur)
			}
		}
	}

	// GP 27/01/2014 : Si tout est dans le cache, bRemplitCache fait toujours une MAJ compl�te. C'est completement inutile dans le cas d'un redimensionnement
	else if (!this.bGetSansLimite())
	{
		// On ne force que dans l'initialisation donc pas dans l'affichage ou le redimensionnement
		// Et remplit finalement le cache si besoin => Cela va provoque une reception de donnee et un reaffichage
		// 0 = Reinit, 1 = Display, 2 = Resize
		if (!this.m_oCache.bRemplitCache(this, 0 === nDisplayOuResize, -1, this.m_bTriCroissant))
		{
			// GP 21/09/2017 : TB103251 : Pas d'appel r�entrant de __OnResizeTable. Sinon avec les ancrages IE on a :
			// OnResize > _vOnResize > OnResizeTable > __bMAJDivPosParentHauteur > Appel asynchrone de __MAJDivPosParentHauteur2
			// __MAJDivPosParentHauteur2 > __OnResizeTable > bMAJLignes > _vPostMAJLignes > LanceNotifications(AjoutHTML) > ... > DeclencheAncrage > Appel asynchrone de h100_set
			// h100_set > __OnScrollResize > ... > __s_OnScrollResize > ... > OnResize > _vOnResize > OnResizeTable > __OnResizeTable
			// GP 21/09/2017 : Pas sur que le r�sultat soit plus juste (...)
			try
			{
				var bValeurAnterieure = document.body.gbH100_set;
				if (bIEAvec11 && this.m_bAncrageHauteur && !bValeurAnterieure)
				{
					document.body.gbH100_set = true;
				}
				// Si le masque ne fait pas de requ�te, reaffiche les donn�es (d�clenche l'affichage du masque)
				this.bMAJLignes();
			}
			finally
			{
				if (bIEAvec11 && this.m_bAncrageHauteur && !bValeurAnterieure)
				{
					document.body.gbH100_set = bValeurAnterieure;
				}
			}
		}
		else
		{
			bAfficheMasque = true;
		}
	}

	if (bAfficheMasque)
	{
		this.AfficheMasque(bAfficheMasque, false);
	}

	clWDUtil.WDDebug.FinFonction();
};

// Transforme une chaine en XML (pour le parametre sXMLLignes de WDTable.Init
WDTable.prototype._oParseToXML = function _oParseToXML(sXML)
{
	if (window.DOMParser)
	{
		return (new DOMParser()).parseFromString(sXML, "text/xml");
	}
	else if (window.ActiveXObject)
	{
		var oXML = new ActiveXObject("MSXML.DomDocument");
		oXML.async = false;
		oXML.loadXML(sXML);
		return oXML;
	}
	else if (window.XMLHttpRequest)
	{
		var oParser = new XMLHttpRequest();
		oParser.open("GET", "data:application/xml;charset=utf-8," + encodeURIComponent(sXML), false);
		oParser.overrideMimeType("application/xml");
		oParser.send(null);
		return oParser;
	}
	else
	{
		return undefined;
	}
};

// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
WDTable.prototype.OnDisplay = function OnDisplay(oElementRacine, bAffiche)
{
	// Appel de la methode de la classe de base
	WDTableZRCommun.prototype.OnDisplay.apply(this, arguments);

	if (bAffiche && this.m_oDivPosParent && clWDUtil.bEstFils(this.m_oDivPosParent, oElementRacine))
	{
		// Puis on initialise ce qui depend de la taille de la zone cliente :
		// Membre, defilement, HTML des lignes etc
		// En forcant la recuperation du chache
		// 0 = Reinit, 1 = Display, 2 = Resize
		this.OnResizeTable(1);

		if (!this.bGetSansLimite())
		{
			// GP 08/04/2013 : MAJ ne vidant le cache du dessin
			this.MAJAscenseurRuptures(true);
		}
	}
};

// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
WDTable.prototype._vOnResize = function _vOnResize(/*oEvent*/)
{
	// Appel de la methode de la classe de base
	WDTableZRCommun.prototype._vOnResize.apply(this, arguments);

	// GP 08/01/2018 : TB106614 : Transforme l'anti r�entrance en global (Ce n'est pas clair pourquoi on a cette r�entrance en 23).
	// GP 22/11/2017 : Vu avec TB104223 : anti r�entrance
	// bActionListe > bMAJLignes > _vPostMAJLignes > LanceNotifications > ... > postWatchMedia > __OnScrollResize > ... > _vOnResize > ... > _vPostMAJLignes
//	if (this.m_bDansPostMAJLignes)
	if (WDTable.prototype.m_bDansPostMAJLignes)
	{
		return;
	}

	// En IE8-, la consultation des clientXxx/scrollXxx/offsetXxx declenche un appel de onscroll/onresize qui d�clenche des calculs erron�
	// (on n'est pas forc�ment correctement initialis� � ce point)
	if (this.m_bRedimensionneUnMasque)
	{
		return;
	}

	// Si les masques sont visibles, les redimensionnes
	if (this.m_bMasqueVisible)
	{
		// Normalement oMasque.parentNode == oMasqueTr.parentNode
		if (this.m_bVisibleMasque)
		{
			this.__RedimensionneUnMasque(this.m_oMasque);
		}
		if (this.m_bVisibleMasqueTransparent)
		{
			this.__RedimensionneUnMasque(this.m_oMasqueTransparent);
		}
	}

	// Puis on initialise ce qui depend de la taille de la zone cliente :
	// Membre, defilement, HTML des lignes etc
	// En forcant la recuperation du cache
	// 0 = Reinit, 1 = Display, 2 = Resize
	this.OnResizeTable(2);
};

// Indique si on a un ancrage dans une dimension
// GP 06/04/2017 : TB102637 : Mauvaise d�tection des champs ancr�s en largeur : dans une ZR this.m_oDivPosParent n'a pas de taille mais son parent oui
WDTable.prototype.__bDimensionAvecAncrage = function __bDimensionAvecAncrage(sDimensionPosParent, sDimensionPosParentParentPourVide)
{
	if ("" == sDimensionPosParent)
	{
		if (sDimensionPosParentParentPourVide)
		{
			return this.__bDimensionAvecAncrage(sDimensionPosParentParentPourVide, null);
		}
		else
		{
			return true;
		}
	}
	else
	{
		return -1 !== sDimensionPosParent.indexOf("%");
	}
};

WDTable.prototype.__bAncrageTimer = function __bAncrageTimer()
{
	if (this.m_bAncrageTimer)
	{
		return true;
	}

	// GP 05/04/2018 : QW298044 : En fait on n'a le probl�me que su un champ superposable : ne fait le timer que dans le cas d'un champ superposable.
	// GP 27/02/2018 : TB107395 : Temporaire en attendant le retour de GF : les ancrages sont maintenant syst�matiquement dans un requestAnimationFrame (au moins avec Chrome)
	// => Force le dessin en asynchrone.
	if ((bCrm || bFF) && document.getElementById("dww" + this.m_sAliasChamp))
	{
		return true;
	}

	// GP 25/01/2016 : TB95683 : Ou si on a un onglet dans la page.
	var pfOnglet = window["WDOnglet"];
	if (pfOnglet)
	{
		// On ne peux pas filtrer sur les onglets visibles car on passe ici dans l'initialtion de la table/zr et l'onglet n'est peut-�tre pas encore initialis� � ce moment.
		if (!clWDUtil.m_oChamps.bPourTousChamps(function(sAliasChamp, oChamp)
		{
			return !(oChamp instanceof pfOnglet);
		}))
		{
			// On a trouv� un onglet
			// On ne fait le calcul que une fois : passe m_bAncrageTimer � true
			this.m_bAncrageTimer = true;
			return true;
		}
	}

	// GP 30/11/2016 : TB100039 : Pour le premier affichage, on peut ne pas le faire en deux temps m�me si la page contient d'autres tables
	if (!this.m_bPremierAncrage)
	{
		// GP 20/01/2016 : TB94880 : Compte le nombre de tables
		var oThis = this;
		if (!this.ms_tabTablesZRs.bPourTousChamps(function(sAliasTable, oTable)
		{
			// GP 20/04/2017 :OPTIMS
			// - Utilise maintenant WDChamp.ms_tabTablesZRs. Si on trouve une autre table visible, alors il faut faire l'ancrage avec un timer.
			// - Uniquement si l'autre table est avec ancrage
			if ((oThis != oTable) && (oTable.m_bAncrageLargeur || oTable.m_bAncrageHauteur))
			{
				var oTableAutreHote = oTable.m_oHote;
				// GP 03/05/2018 : TB100343 : (Ce n'est pas la bonne correction mais je n'ai pas de meilleur id�e). Ignore les champs table/zone r�p�t�e sans contenu et superposable.
				// => Ils n'ont normalement pas d'influence.
				if (oTableAutreHote && clWDUtil.bEstDisplay(oTableAutreHote, document) && !(document.getElementById("dww" + oTable.m_sAliasChamp) && (0 === oTable.m_oHote.offsetHeight)))
				{
					// On a une autre table visible, il faut l'ancrage par timer, arret de l'it�ration
					return false;
				}
			}
			// Continue l'it�ration
			return true;
		}))
		{
			// On a trouv� une autre table visible
			// On ne fait le calcul que une fois : passe m_bAncrageTimer � true
			this.m_bAncrageTimer = true;
			return true;
		}
	}

	return this.m_bAncrageTimer;
};

// Fixe la hauteur de m_oDivPosParent
// Retourne TRUE si la MAJ est diff�r�e
WDTable.prototype.__bMAJDivPosParentHauteur = function __bMAJDivPosParentHauteur(nDisplayOuResize)
{
	var bMAJDifferee = false;
	var bAncrageLargeur = this.m_bAncrageLargeur;
	var bAncrageHauteur = this.m_bAncrageHauteur && this.bAscenseurPossible();

	if (bAncrageLargeur || bAncrageHauteur)
	{
		var oScroll;
		var bAncrageTimer = this.__bAncrageTimer();

		// GP 05/02/2014 : Comme on a plusieurs appels en IE, il faut prendre le premier scrollTop (avant le second appel qui donne 0)
		// GP 17/12/2015 : OPTIM : on �vite de lire les propri�t�s du DOM si on ne va pas les utiliser apr�s : test this.m_oMAJDivPosParentScroll ici
		// 0 = Reinit, 1 = Display, 2 = Resize
		if ((0 != nDisplayOuResize) && bAncrageTimer && !this.m_oMAJDivPosParentScroll)
		{
			oScroll = { m_nLeft: this.m_oDivPosParent.scrollLeft, m_nTop: this.m_oDivPosParent.scrollTop };
		}

		if (bAncrageLargeur)
		{
			// Place temporairement un taille plus petite pour avoir la taille correcte
			if (this.m_oTitrePosPixel)
			{
				this.m_oTitrePosPixel.parentNode.style.width = "1px";
			}
			this.m_oDivPosParent.style.width = "1px";
		}
		if (bAncrageHauteur)
		{
			this.m_oDivPosParent.style.height = "1px";
		}

		// GP 21/01/2014 : Et dans IE en mode HTML5, l'ancrage vertical est fait � la main et pour avoir le calcul correct il faut masquer les fils
		// GP 04/10/2016 : Ajout de "&& ((!bIEAvec11) || event)" => On ne fait le timeout que si :
		// - Soit on n'est pas avec IE (donc bAncrageTime est forc� pour une autre raison)
		// - Soit event est pr�sent (le 'event" global n'est disponible que dans IE) ce qui signifie que l'on est peut-�tre vraiment dans un redimensionnement
		if (bAncrageTimer && ((!bIEAvec11) || event))
		{
			if (bAncrageLargeur && this.m_oTitrePosPixel)
			{
				clWDUtil.SetDisplay(this.m_oTitrePosPixel, false);
			}
			clWDUtil.SetDisplay(this.m_oDivPosParent, false);

			// GP 05/02/2014 : Comme on a plusieur sappels en IE, il faut prendre les premiers scrollLeft + scrollTop (avant le second appel qui donne 0)
			if (oScroll)
			{
				this.m_oMAJDivPosParentScroll = oScroll;
			}

			this.nSetTimeoutUnique("__MAJDivPosParentHauteur2", clWDUtil.ms_nTimeoutNonImmediat100, nDisplayOuResize, bAncrageLargeur, bAncrageHauteur, true);
			bMAJDifferee = true;
		}
		else if (this.bGetTimeXXXExiste("__MAJDivPosParentHauteur2"))
		{
			// GP 21/09/2017 : TB103251 : Si on a un timeout en attente, le laisse faire le travail
			bMAJDifferee = true;
		}
		else
		{
			// GP 21/02/2017 : QW283915 : Retour en arri�re, rien ne marche et c'est presque pire
//			// GP 20/02/2017 : QW283915 : Si on a timeout en attente et que l'on force la version sans timeout en IE11, annule l'appel en timeout (qui ne sert a rien�
//			// GP 21/02/2017 : QW283915 : Version 2 : fait syst�matiquement
//			this.AnnuleTimeXXX("__MAJDivPosParentHauteur2", false);
			this.__MAJDivPosParentHauteur2(nDisplayOuResize, bAncrageLargeur, bAncrageHauteur, false);
		}
	}

	return bMAJDifferee;
};
WDTable.prototype.__MAJDivPosParentHauteur2 = function __MAJDivPosParentHauteur2(nDisplayOuResize, bAncrageLargeur, bAncrageHauteur, bParTimer)
{
	var oDivPosParent = this.m_oDivPosParent;
	var oDivPosParentX2 = oDivPosParent.parentNode;
	var oDivPosParentX6 = oDivPosParentX2.parentNode.parentNode.parentNode.parentNode;
	// GP 27/01/2014 : QW241837 : Le calcul de la hauteur echoue dans le cas : "tout en cache" + "ancrages" + "HTML 4" + IE
	// GP 29/11/2016 : TB100039 : A d�placer apr�s le code bParTimer ?
	var oTitrePosPixelParent;
	var nLargeurParentLibre;
	var nLargeurTitreLibre;
	if (bAncrageLargeur)
	{
		nLargeurParentLibre = this.__nCorrigeDimensionIEAncrage(function(oElement) { return oElement.offsetWidth; }, oDivPosParentX2, oDivPosParentX6);
		if (this.m_oTitrePosPixel)
		{
			oTitrePosPixelParent = this.m_oTitrePosPixel.parentNode;
			nLargeurTitreLibre = nLargeurParentLibre;
		}
	}
	// GP 21/01/2014 : Et dans IE en mode HTML5, l'ancrage vertical est fait � la main et pour avoir le calcul correct il faut masquer les fils
	if (bParTimer)
	{
		if (bAncrageLargeur && this.m_oTitrePosPixel)
		{
			clWDUtil.SetDisplay(this.m_oTitrePosPixel, true);
		}
		// Inutile de tester bAncrageLargeur || bAncrageHauteur, si on arrive dans cette fonction c'est que l'on en a au moins un des deux
		clWDUtil.SetDisplay(oDivPosParent, true);

		// GP 29/11/2016 : TB100039 : Calcul d�plac� en fin pour ne pas faire deux reflows.
//		// GP 17/12/2015 : Exigence sur l'ancrage des tables en largeur.
//		// Si on relit nHauteurParentLibre on n'obtient pas la m�me valeur que pr�c�dement et celle-ci est ici juste.
//		// => Fait une seconde lecture mais c'est incompr�hensible (probl�me de reflow ?)
	}
	var nHauteurParentLibre;
	if (bAncrageHauteur)
	{
		nHauteurParentLibre = this.__nCorrigeDimensionIEAncrage(function(oElement) { return oElement.offsetHeight; }, oDivPosParentX2, oDivPosParentX6);
	}

	// GP 21/01/2014 : Illogique mais dans Firefox, ici il faut tenir compte de l'�paisseur de bordure du parent (comme dans IEQuirks)
	if (bFF || (bIEAvec11 && clWDUtil.bHTML5))
	{
		var oDivPosParentX2CurrentStyle = clWDUtil.oGetCurrentStyle(oDivPosParentX2);
		if (nLargeurTitreLibre)
		{
			nLargeurTitreLibre -= this.s_nGetOffsetBorderPourWidth(clWDUtil.oGetCurrentStyle(oTitrePosPixelParent.parentNode));
		}
		if (nLargeurParentLibre)
		{
			nLargeurParentLibre -= this.s_nGetOffsetBorderPourWidth(oDivPosParentX2CurrentStyle);
		}
		if (nHauteurParentLibre)
		{
			nHauteurParentLibre -= this.s_nGetOffsetBorderPourHeight(oDivPosParentX2CurrentStyle);
		}
	}

	// GP 29/05/2015 : QW258192 : Il semble y avoir un probl�me d'arrondi avec Chrome 42+
	// Avec la repro en maximis� :
	// - nHauteurParentLibre est 724 (c'est oDivPosParent.parentNode.offsetHeight)
	// - Cela donne : cette taille a l'�l�ment, a son parent et l'ascenseur.
	// - En bidouillant dans le F12 :
	// >> Si on passe la taille a 723 => le parent passe � 723 et l'ascenseur disparait
	// >> Si on passe la taille a 720 => le parent passe � 724 et l'ascenseur disparait
	// Id�e : on d�tecte si l'affectation fait changer la hauteur totale
	var nLargeurDocument;
	var nHauteurDocument;
	// GP 07/04/2016 : TB97509 : Edge est d�tect� comme chrome. Il a ce m�me probl�me que chrome.
	// Sauf que la modification de la hauteur ne d�clenche pas le reflow !!!
	if (bEdge)
	{
		// C'est faux mais c'est le meilleur calcul trouv�
		if (nLargeurTitreLibre)
		{
			nLargeurTitreLibre--;
		}
		if (nLargeurParentLibre)
		{
			nLargeurParentLibre--;
		}
		if (nHauteurParentLibre)
		{
			nHauteurParentLibre--;
		}
	}
	else if (bCrm)
	{
		nLargeurDocument = document.body.scrollWidth;
		nHauteurDocument = document.body.scrollHeight;
	}

	this.__bAffecteProprieteSiValeurDefinie(oTitrePosPixelParent, "width", nLargeurTitreLibre);
	this.m_bTitrePosPixelParentLargeur_QW269772 = false;
	this.__bAffecteProprieteSiValeurDefinie(oDivPosParent, "width", nLargeurParentLibre);
	this.__bAffecteProprieteSiValeurDefinie(oDivPosParent, "height", nHauteurParentLibre);
	// Si la taille change pour +1 : affecte un de moins comme hauteur
	if (bCrm && !bEdge)
	{
		// GP 09/02/2016 : QW269058 : Uniquement en Quirks car c'est ce que d�crit la fiche.
		// Et uniquement au display ou resize et pas au premier affichage (car l'ascenseur n'est pas encore pr�sent)
		var nLargeurAscenseurVertical = 0;
		if ((0 != nDisplayOuResize) && (!clWDUtil.bHTML5) && this.m_oTitrePosPixel && this.bGetCacheCompletAscenseur())
		{
			// Fixe le margin de la zone de titre
			nLargeurAscenseurVertical = this._nGetLargeurAscenseurVertical(oDivPosParent);
		}

		// GP 09/02/2016 : QW269058 : L'erreur dans un sens peut faire apparaitre un ascenseur. Ce qui modifie la valeur dans l'autre dimensions d'une quantit� bien plus importante.
		// On fait par �tape en ne modifiant que le plus petit des deux � la fois
		var nOffsetX = -1;
		var nOffsetY = -1;
		for (var bModification = true; bModification; )
		{
			bModification = false;
			var nScrollWidth = document.body.scrollWidth;
			var nScrollHeight = document.body.scrollHeight;
			// GP 03/05/2016 : TB97941 : Si l'affichage est sans ascenseur (= on avait un ascenseur avant de fixer la taille)
			// => Ne fait rien.
			// Note : ce n'est probablement pas la bonne correction. Il doit y avoir un probl�me plus g�n�ral avec l'algo.
			if ((window.innerWidth < nScrollWidth) || (window.innerHeight < nScrollHeight))
			{
				var nDiffX = (nScrollWidth - nLargeurDocument) - nLargeurAscenseurVertical;
				var nDiffY = (nScrollHeight - nHauteurDocument);
				// GP 11/02/2016 : QW269595 : Il faut faire un test nDiffY <= 0 car si on a un ascenseur avec un ancrage dans un seul sens la dimension dans l'autre sens se r�duit.
				if (bAncrageLargeur && (0 < nDiffX) && ((nDiffX <= nDiffY) || (nDiffY <= 0)))
				{
					// GP 08/02/2018 : QW295812 : D�tecte si on fait des modifications pour ne pas partir en boucle infinie.
					bModification = this.__bAffecteProprieteSiValeurDefinie(oTitrePosPixelParent, "width", nLargeurTitreLibre, nOffsetX) || bModification;
					this.m_bTitrePosPixelParentLargeur_QW269772 = false;
					bModification = this.__bAffecteProprieteSiValeurDefinie(oDivPosParent, "width", nLargeurParentLibre, nOffsetX) || bModification;
					nOffsetX--;
				}
				// GP 11/02/2016 : QW269595 : Il faut faire un test nDiffX <= 0 car si on a un ascenseur avec un ancrage dans un seul sens la dimension dans l'autre sens se r�duit.
				if (bAncrageHauteur && (0 < nDiffY) && ((nDiffY <= nDiffX) || (nDiffX <= 0)))
				{
					// GP 08/02/2018 : QW295812 : D�tecte si on fait des modifications pour ne pas partir en boucle infinie.
					bModification = this.__bAffecteProprieteSiValeurDefinie(oDivPosParent, "height", nHauteurParentLibre, nOffsetY) || bModification;
					nOffsetY--;
				}
			}
		}
	}

	// GP 04/02/2014 : QW242234 : Corrige m_bDebordeLargeur selon le type du champ (pour les ZRs)
	// Dans le cas IE + HTML5 (on est dans un timer apr�s les autres calculs)
	if (bParTimer)
	{
		this.__OnResizeTable(nDisplayOuResize, undefined, undefined, undefined, false);
	}
	// GP 05/02/2014 : QW242296
	var oMAJDivPosParentScroll = this.m_oMAJDivPosParentScroll;
	if (oMAJDivPosParentScroll)
	{
		oDivPosParent.scrollLeft = oMAJDivPosParentScroll.m_nLeft;
		oDivPosParent.scrollTop = oMAJDivPosParentScroll.m_nTop;
		this.m_oMAJDivPosParentScroll = null;
	}

	this.__ForceReflowSafari();

	this.m_bPremierAncrage = false;
};
WDTable.prototype.__bAffecteProprieteSiValeurDefinie = function __bAffecteProprieteSiValeurDefinie(oObjet, sPropriete, nValeur, nOffset)
{
	if (undefined !== nValeur)
	{
		if (undefined !== nOffset)
		{
			nValeur += nOffset;
		}
		if (0 <= nValeur)
		{
			clWDUtil.SetDimensionPxStyle(nValeur, oObjet, sPropriete);
			return true;
		}
		else
		{
			return false;
		}
	}
	return false;
};
WDTable.prototype.__ForceReflowSafari = function __ForceReflowSafari()
{
	// GP 26/10/2016 : TB100057 : Force un reflow g�n�ral un fois apr�s le premier affichage sous Safari
	// GP 28/10/2016 : Version 2 : D�tecte uniquement Safari 9- et force un reflow dans tous les cas
	if (bSfr)
	{
		var oRes = (new RegExp("Version/\\s*(\\d+)\\.*(\\d+)")).exec(navigator.userAgent);
		if (oRes && oRes[1] && (parseInt(oRes[1], 10) < 10))
		{
			if (!this.m_bReflowTableSafari)
			{
				var oThis = this;
				clWDUtil.nSetTimeout(function()
				{
					try
					{
						oThis.m_bReflowTableSafari = true;
						oThis._vOnResize(null);
					}
					finally
					{
						oThis.m_bReflowTableSafari = false;

					}
				}, clWDUtil.ms_nTimeoutNonImmediat100);
			}
		}
	}
};

// GP 27/01/2014 : QW241837 : Le calcul de la hauteur echoue dans le cas : "tout en cache" + "ancrages" + "HTML 4" + IE
// < 4 est un choix arbitraire
WDTable.prototype.__nCorrigeDimensionIEAncrage = function __nCorrigeDimensionIEAncrage(pfFonctionDimension, oElement, oElementParent)
{
	var nDimension = pfFonctionDimension(oElement);
	// < 4 est un choix arbitraire
	// GP 24/04/2018 : TB107773 : Il semble que l'on a un probl�me similaire avec Safari
	if ((bIEAvec11 && (nDimension < 4)) || (bSfr && (0 === nDimension)))
	{
		nDimension = Math.max(nDimension, pfFonctionDimension(oElementParent));
	}
	return nDimension;
};

// Initialise le tableau de l'etat des lignes
WDTable.prototype.InitEtatLignes = function InitEtatLignes(nNbLignesHTML)
{
	this.m_oEtatLignes = new WDEtatLignes(this, nNbLignesHTML);
};

WDTable.prototype.__nNbLignesPage = function __nNbLignesPage(nHauteurLigne)
{
	var nHauteur = this.__nCorrigeDimensionIEAncrage(function(oElement) { return Math.min(oElement.clientHeight, oElement.scrollHeight); }, this.m_oDivPosParent.parentNode, this.m_oDivPosParent.parentNode.parentNode.parentNode.parentNode.parentNode);

	// Decalage a cause du debordement en largeur
	if (this._vbGetDebordeLargeur())
	{
		nHauteur -= 18;
	}

	// GP 27/01/2014 : QW241834 : Toujours au moins une ligne
	return Math.max(Math.floor(nHauteur / nHauteurLigne * this.vnGetNbLignesLogiquesParLignePhysique()), 1);
};

// Recalcule le nombre de ligne a afficher dans la page et change le nombre de lignes si besoin
// Renvoi vrai si le nombre de ligne a ete (Ou va si bTestUniquement est a vrai) changer
WDTable.prototype.bCalculeLigneAffiche = function(bTestUniquement)
{
	clWDUtil.WDDebug.DebutFonction("bCalculeLigneAffiche");
	//assert(!this.bGetSansLimite());

	var nNbLignesPage = this.__nNbLignesPage(this.m_nHauteurLigne);

	// Si le nombre de ligne change
	if (nNbLignesPage != this.m_nNbLignesPage)
	{
		// Si ce n'est pas seulement un test : met a jour la valeur
		if (!bTestUniquement)
		{
			this.m_nNbLignesPage = nNbLignesPage;
		}

		clWDUtil.WDDebug.FinFonction();
		return true;
	}

	clWDUtil.WDDebug.FinFonction();
	return false;
};

// Rafraichi la table
WDTable.prototype._vRefresh = function _vRefresh(nReset, nNouveauDebut, sCleNouveauDebut, sData, nNbLignes, oXMLFils, nTri, bSens)
{
	// Si reaffichage de la table
	switch (nReset)
	{
	case 1:
	case 2:
		// Annule la validation d'une ligne de table/ZR si la table/ZR est MAJ
		this._AnnuleValideLigneTableZRTimer();
		// GP 22/02/2017 : TB98935 : Il faut annuler le parcours en arri�re plan pr�c�dent
		delete this.m_bFinTrouve;
		delete this.m_sCleParcourtAP;
		break;
	}

	// Appel de la methode de la classe de base
	WDTableZRCommun.prototype._vRefresh.apply(this, arguments);

	// Indique s'il faut MAJ l'ascenseur
	var bMajAscenseur = false;
	// Si reaffichage de la table
	switch (nReset)
	{
	case 1:
		this.SetDebut(0);
		// Il n'y a pas d'ascenseur en mode sans limite
		if (!this.bGetSansLimite())
		{
			bMajAscenseur = true;
		}
		// Pas de break ???
	case 2:
		// Se repositionne si besoin
		if (nNouveauDebut > -1)
		{
			this.SetDebut(nNouveauDebut, sCleNouveauDebut);
			// On doit remettre l'ascenseur
			bMajAscenseur = true;
		}
		break;
	case 0:
	default:
		break;
	}

	// GP 18/03/2013 : QW231024 : Transmet le nouveau nombre de lignes pour avoir le bon calcul de l'ascenseur
	if ((undefined !== nNbLignes) && (nNbLignes != this.m_nNbLignes))
	{
		this.m_nNbLignes = nNbLignes;
		bMajAscenseur = true;
	}

	if (undefined !== sData)
	{
		this.oGetElementByName(document, "_DATA").value = sData;
	}

	// GP 26/03/2014 : TB73415 : Place la s�lection si besoin
	this.__RemplitSelonXML(oXMLFils);

	// Si on doit remettre l'ascenseur et que l'on a bien un ascenseur
	if (bMajAscenseur && !this.bGetSansLimite())
	{
		this.MAJAscenseur(true);
	}

	// GP 24/03/2021 : TB121388 : On redessine toujours le picto.
//	// Si on a l'attribut du numero de la colonne tri : actualise l'affichage
//	if (-1 < nTri)
	{
		// Actualise l'affichage des pictos
		this.__TriColonne(nTri, bSens);
	}

	// Vire le cache
	this.m_oCache.bRemplitCache(this, true, this.m_nColonneTrie, this.m_bTriCroissant);

	// Marque toutes les lignes comme invalide
	this.m_oEtatLignes.Invalide(this, this.m_nDebut, 0, false, null);
	// Et affiche le masque qui empeche la saisie
	this.AfficheMasque(true, true);
};

// Defini le debut de la table
WDTable.prototype.SetDebut = function(nNouveauDebut, sCleNouveauDebut)
{
//	// Arrondi selon le nombre de colonnes
//	var nNbLignesLogiquesParLignePhysique = this.vnGetNbLignesLogiquesParLignePhysique();
//	if (nNbLignesLogiquesParLignePhysique > 1)
//	{
//		nNouveauDebut = Math.floor(nNouveauDebut / nNbLignesLogiquesParLignePhysique);
//		// Normalement si sCleNouveauDebut <> null alors nNouveauDebut ne doit pas changer
//	}

	// GP 14/01/2014 : TB52406 : Dans les tables sans limite, le d�but est toujours 0
	if (this.bGetSansLimite() && (0 != nNouveauDebut))
	{
		return;
	}

	this.m_nDebut = nNouveauDebut;

	// GP 07/01/2016 : TB93214 : Probl�me avec "_DEB" : ici on ecrivait la valeur SANS faire de C -> WL
	// => Fait maintenant la conversion C -> WL
	var oChampDeb = this.oGetElementByName(document, "_DEB");
	if (oChampDeb)
	{
		oChampDeb.value = nNouveauDebut + 1;
	}

	// On peut ne pas avoir de cache au debut
	if (!sCleNouveauDebut && this.m_oCache)
	{
		var oLigneCache = this.m_oCache.oGetLigne(nNouveauDebut);
		if (oLigneCache)
		{
			sCleNouveauDebut = oLigneCache.sGetCleEnreg();
			if (0 === sCleNouveauDebut.length)
			{
				sCleNouveauDebut = null;
			}
		}
	}
	if (sCleNouveauDebut)
	{
		this.m_sCleDebut = sCleNouveauDebut;
		if (oChampDeb)
		{
			oChampDeb.value += ";" + sCleNouveauDebut;
		}
	}
	else
	{
		delete this.m_sCleDebut;
	}
};

// Envoie une requete de selection
WDTable.prototype.RequeteSelection = function RequeteSelection(nColonneClic)
{
	// Sauve la valeur du formulaire
	var sFormulaire = this._vsGetValeurChampFormulaire();
	// Et met la valeur complete
	this._vSetValeurChampFormulaire(this.sConstruitRequeteSelection());

	var sAliasColonneClic;
	var sTarget;
	if (-1 != nColonneClic)
	{
		sAliasColonneClic = this.m_tabColonnes[nColonneClic].m_sAlias;
		sTarget = this.m_tabColonnes[nColonneClic].m_sTarget;
	}

	// Creer une requete de modification de ligne
	// GP 30/06/2015 : TB93061 : Si la requete est non AJAX, le masque n'est plus jamais masqu�.
	// Donc dans le cas d'une requ�te non AJAX, on n'affiche pas le masque.
	// Inconv�nient : le masque fait un "anti r�p�tition" que l'on perd.
	var bAfficheMasque = this.m_oCache.bCreeRequeteSelection(this, nColonneClic, sAliasColonneClic, sTarget);

	// Restaure le formulaire
	this._vSetValeurChampFormulaire(sFormulaire);

	// Et affiche le masque qui empeche la saisie
	if (bAfficheMasque)
	{
		this.AfficheMasque(true, true);
	}
};

// Recupere le nombre de colonne de presentation
WDTable.prototype.vnGetNbLignesLogiquesParLignePhysique = function()
{
	return 1;
};

// On stocke la derniere ligne selectionnee dans le formulaire
WDTable.prototype._vSetValeurChampFormulaire = function _vSetValeurChampFormulaire(/*sValeur*/)
{
	// Appel de la classe de base (ecrit dans le champ formulaire)
	WDTableZRCommun.prototype._vSetValeurChampFormulaire.apply(this, arguments);

	// Et ecrit dans le champ cache spacial AWP si il est disponible
	if (this.m_oChampFormulaireSelAWP)
	{
		this.m_oChampFormulaireSelAWP.value = this.sConstruitRequeteSelection();
	}
};

// Indique si une ligne est selectionnee : renvoie son indice dans le tableau des selection ou -1 sinon
WDTable.prototype.nLigneSelectionnePosVisible = function nLigneSelectionnePosVisible(nLigneAbsolue, nColonneOuNaN)
{
	// Convertit la ligne ne numero de ligne avec position absolue
	return this.nLigneSelectionne(this.nPosVisible2PosAbsolue(nLigneAbsolue), nColonneOuNaN);
};

// Version avec un nombre corrige des lignes invsibles
WDTable.prototype.nLigneSelectionne = function nLigneSelectionne(nLignePosAbsolue, nColonneOuNaN)
{
	var nSelection = clWDUtil.nElementInconnu;
	var bSansSelectionALaCellule = !this.__bSelectionALaCellule();
	clWDUtil.bForEach(this.m_tabSelection, function (oUneSelection, nIndice)
	{
		if ((oUneSelection.m_nLigne === nLignePosAbsolue) && (bSansSelectionALaCellule || isNaN(nColonneOuNaN) || (oUneSelection.m_nColonne === nColonneOuNaN)))
		{
			nSelection = nIndice;
			return false;
		}
		return true;
	});
	return nSelection;
};

// Indique si une ligne est selectionnee + retourne faux dans le cas des ZRs
WDTable.prototype.bLigneEstSelectionnee = function bLigneEstSelectionnee(nLigneAbsolue, nColonneOuNaN)
{
	return clWDUtil.nElementInconnu !== this.nLigneSelectionnePosVisible(nLigneAbsolue, nColonneOuNaN);
};
WDTable.prototype.bLigneEstSelectionneePosAbsolue = function bLigneEstSelectionneePosAbsolue(nLigneAbsolue, nColonneOuNaN)
{
	return clWDUtil.nElementInconnu !== this.nLigneSelectionne(nLigneAbsolue, nColonneOuNaN);
};

// Et le param�tre
WDTable.prototype.vbLigneEstSelectionneeSansZR = function (nLigneAbsolue)
{
	// Et le num�ro de colonne ?
	return this.bLigneEstSelectionnee(nLigneAbsolue, NaN);
};

// Selectionne une ligne
// Indique si la ligne a ete selectionnee (Faux si la ligne etait deja selectionnee)
WDTable.prototype.__bLigneSelectionnePosVisible = function __bLigneSelectionnePosVisible(nLigneAbsolue, nColonne, bCodeNav, oEvent)
{
	// Convertit la ligne ne numero de ligne avec position absolue
	return this._bLigneSelectionne(this.nPosVisible2PosAbsolue(nLigneAbsolue), nLigneAbsolue, nColonne, bCodeNav, oEvent);
};

WDTable.prototype.__bSelectionALaCellule = function __bSelectionALaCellule()
{
	return 0 < this.m_nSelectionCellule;
};
WDTable.prototype.__oConstruitUneSelection = function __oConstruitUneSelection(nLignePosAbsolue, nColonneOuInvalide)
{
	var oUneSelection = { m_nLigne: nLignePosAbsolue };

	if (this.__bSelectionALaCellule() && !isNaN(nColonneOuInvalide))
	{
		oUneSelection.m_nColonne = nColonneOuInvalide;
	}

	return oUneSelection;
};

// Version interne
WDTable.prototype._bLigneSelectionne = function _bLigneSelectionne(nLignePosAbsolue, nLigneAbsolue, nColonne, bCodeNav, oEvent)
{
	// Ajoute la ligne
	this.m_tabSelection.push(this.__oConstruitUneSelection(nLignePosAbsolue, nColonne));
	// Si la ligne est visible : lui change son style
	// GP 23/02/2016 : TB89890 : On ne refuse pas la "s�lection" dans une table sans s�lection, on ne l'affiche juste pas
	if ((this.__bLigneEstVisible(nLigneAbsolue)) && (WDSelection.prototype.ms_nSelectionSans !== this.veGetModeSelection()))
	{
		// Demande a la ligne du cache de se mettre a jour
		var oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
		if (oLigneCache)
		{
			oLigneCache.SetStyle(this.m_tabStyle, 2, this, nLigneAbsolue, oEvent, true);
		}
	}

	// Et on stocke dans le membre de la page la derniere ligne selectionnee
	this._vSetValeurChampFormulaire(nLignePosAbsolue + 1);

	// Appel le PCode navigateur de selectionne de ligne
	if (bCodeNav)
	{
		this.RecuperePCode(this.ms_nEventNavSelectLigne)(oEvent);
	}

	return true;
};

// Deselectionne une ligne
// Indique si la ligne a ete selectionnee (Faux si la ligne etait deja selectionnee)
WDTable.prototype.bLigneDeselectionne = function(nIndiceTableau, oEvent)
{
	var tabSelection = this.m_tabSelection;

	// Si la ligne n'est pas dans le tableau
	if ((nIndiceTableau < 0) || (nIndiceTableau >= tabSelection.length))
	{
		return false;
	}

	// Recupere le numero de la ligne
	var nLignePosAbsolue = tabSelection[nIndiceTableau].m_nLigne;
	// Convertit la ligne ne numero de ligne avec position visible
	var nLigneAbsolue = this.nPosAbsolue2PosVisible(nLignePosAbsolue);

	// Et on vire la ligne du tableau
	tabSelection.splice(nIndiceTableau, 1);

	// Si la ligne est visible : lui change son style
	// GP 23/02/2016 : TB89890 : On ne refuse pas la "s�lection" dans une table sans s�lection, on ne l'affiche juste pas
	if ((this.__bLigneEstVisible(nLigneAbsolue)) && (WDSelection.prototype.ms_nSelectionSans != this.veGetModeSelection()))
	{
		// Demande a la ligne du cache de se mettre a jour
		var oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
		if (oLigneCache)
		{
			oLigneCache.SetStyle(this.m_tabStyle, this.__nGetStylePourLigne(nLigneAbsolue), this, nLigneAbsolue, oEvent, false);
		}
	}

	// On met a jour l'eventuel element du formulaire
	this._vSetValeurChampFormulaire(tabSelection.length > 0 ? (tabSelection[tabSelection.length - 1].m_nLigne + 1) : "");

	// Supprimee
	return true;
};

// Deselectionne tous
WDTable.prototype.bLigneDeselectionneTous = function bLigneDeselectionneTous(nLigneGardeAbsolue, nColonneOuNaN, oEvent)
{
	var bChangement = false;
	var tabSelection = this.m_tabSelection;
	var nPos = 0;

	while (tabSelection.length > nPos)
	{
		// Uniquement si ce n'est pas la ligne filtree
		var oUneSelection = tabSelection[nPos];
		if ((nLigneGardeAbsolue !== oUneSelection.m_nLigne) || (this.__bSelectionALaCellule() && (isNaN(nColonneOuNaN) || (oUneSelection.m_nColonne !== nColonneOuNaN))))
		{
			bChangement = this.bLigneDeselectionne(nPos, oEvent);
		}
		else
		{
			nPos++;
		}
	}
	return bChangement;
};

// Calcule la partie de selection transmise dans la requete
WDTable.prototype.sConstruitRequeteSelection = function()
{
	// On ne peut toujours pas utiliser Array.map a cause de IE en mode HTML4...
//	return this.m_tabSelection.map(function (oUneSelection) { return xxx; }).join(this.SEL_SEPARATEUR);
	var tabSelection = [];
	clWDUtil.bForEachThis(this.m_tabSelection, this, function (oUneSelection)
	{
		var sUneSelection = String(oUneSelection.m_nLigne);
		if (!isNaN(oUneSelection.m_nColonne))
		{
			sUneSelection += this.SEL_SEPARATEUR_COLONNE + oUneSelection.m_nColonne;
		}
		tabSelection.push(sUneSelection);
		return true;
	});
	return tabSelection.join(this.SEL_SEPARATEUR);
};

// Indique si une ligne est visible
WDTable.prototype.__bLigneEstVisible = function __bLigneEstVisible(nLigneAbsolue)
{
	if (this.bGetSansLimite())
	{
		return nLigneAbsolue < this.m_nNbLignes;
	}
	else
	{
		return (nLigneAbsolue >= this.m_nDebut) && (nLigneAbsolue <= this.m_nDebut + this.m_nNbLignesPage + 1);
	}
};

// Traite la r�ponse du serveur, version pour les donnees de l'AJAX qui peuvent changer l'affichage
WDTable.prototype.bActionListeDepuisAJAX = function bActionListeDepuisAJAX(oXMLLignes, nLigneAbsolue)
{
	// Remplis le cache et met a jour l'affichage
	if (this.bActionListe(oXMLLignes))
	{
		// Et on demande la MAJ de la ligne si besoin
		if (nLigneAbsolue > -1)
		{
			if (this.__bLigneEstVisible(nLigneAbsolue))
			{
				this.MAJLigne(nLigneAbsolue);
			}
		}
	}
};

// Traite la reponse du serveur : remplissage du cache et affichage des donnees si besoin
WDTable.prototype.bActionListe = function bActionListe(oXMLLignes, bForceMAJAscenseur)
{
	// Sauve l'ancien nombre de lignes
	var nAncienNbLignes = this.m_nNbLignes;
	// Relit le nombre de ligne total de la table (Cas d'une table fichier)
	this.m_nNbLignes = parseInt(clWDAJAXMain.sXMLGetAttribut(oXMLLignes, this.XML_NOMBRE), 10);
	// Puis le place dans l'element du formulaire pour une utilisation en JS (TB53093)
	var oChampOcc = document.getElementsByName("_" + this.sGetNomElement("_OCC"))[0];
	if (oChampOcc)
	{
		oChampOcc.value = this.m_nNbLignes;
	}

	// Regarde si on doit ne pas notifier le serveur des selections
	if (clWDAJAXMain.bXMLAttributExiste(oXMLLignes, this.XML_DESACTIVESERSEL))
	{
		this.m_bRetourServeurSelection = false;
	}

	// GP 23/11/2015 : TB94048 : MAJ du mode de s�lection
	this.m_eTypeSelection = clWDAJAXMain.nXMLGetAttributSafe(oXMLLignes, this.XML_TYPESELECTION, this.m_eTypeSelection);

	if (clWDAJAXMain.bXMLAttributExiste(oXMLLignes, this.XML_DATA))
	{
		document.getElementsByName(this.sGetNomElement("_DATA"))[0].value = clWDAJAXMain.sXMLGetAttribut(oXMLLignes, this.XML_DATA)
	}

	// Utilise la valeur d'�dition maintenant
//	// Si la hauteur de ligne est variable (favorise le vrai si la valeur est absente)
//	this.m_bHauteurLigneVariable = clWDAJAXMain.bXMLGetAttributSafe_Vrai(oXMLLignes, this.XML_HAUTEURLIGNEVARIABLE);

	// Charge les propri�t�s sp�cifiques
	this._vActionListeSpecifique(oXMLLignes);

	// (Zones r�p�t�es) Recupere le nombre de ruptures
	var nOldRuptures = this.m_nNbRuptures;
	this.m_nNbRuptures = clWDAJAXMain.nXMLGetAttributSafe(oXMLLignes, clWDAJAXMain.XML_CHAMP_LIGNES_RUPTURES, 0);

	var bAvecColonnesInvisiblesOuEchangees = false;

	// Si on affiche toutes les lignes : cree le HTML et redimensionne les tableaux d'etat
	if (this.bGetSansLimite())
	{
		// GP 18/12/2015 : TB95654 : C'est inutile dans les tables aussi. Ne le fait plus que dans les tables hi�rarchiques.
		// GP 04/02/2014 : QW242264 : Pas dans les tables avec ascenseur non plus sinon on perd le scroll
		// On ne le fait que si le nombre de ligne a change ou dans les tables (Inutile ?)
		// Dans les ZR cela gene la saisie en cascade
//		if ((nAncienNbLignes != this.m_nNbLignes) || (!this.vbZR() && !this.bGetCacheCompletAscenseur()))
		if ((nAncienNbLignes != this.m_nNbLignes) || (window["WDTableHierarchique"] && (this instanceof WDTableHierarchique)))
		{
			// GP 25/11/2015 : QW266376 : Retour en arri�re car cela pose trop de probl�mes
//			// GP 24/11/2015 : Vu avec TB93836 : cela ne sert a rien de faire l'initialisation ici dans le cas sans limite.
//			// D�port� plus loin en forcant le flag bAvecColonnesInvisiblesOuEchangees
//			bAvecColonnesInvisiblesOuEchangees = true;
			this.__GenereLignesHTML();
			this.InitEtatLignes(this.m_nNbLignesHTML);

			// Applique la visibilite des colonnes
			this.AfficheColonnes();
		}
		else if (0 === this.m_nNbLignes)
		{
			// Si on a pas de ligne dans une ZR sans limite : on doit quand meme creer le tableau de m_tabEtatLignes
			this.InitEtatLignes(0);
		}
	}

	// Si on a l'attribut du numero de la colonne tri : actualise l'affichage
	if (clWDAJAXMain.bXMLAttributExiste(oXMLLignes, this.XML_TRI))
	{
		this.m_nColonneTriePre = clWDAJAXMain.nXMLGetAttribut(oXMLLignes, this.XML_TRI);
		this.m_bTriCroissantPre = clWDAJAXMain.bXMLGetAttributSafe(oXMLLignes, this.XML_SENS);

		// GP 19/05/2015 : QW257258 : Et redessine le picto de tri quand on a fini de redessiner les titres de colonnes
		// => D�plac� plus bas
//		// Actualise l'affichage des pictos
//		this.__TriColonne(this.m_nColonneTriePre, this.m_bTriCroissantPre);
	}
	else
	{
		delete this.m_nColonneTriePre;
		delete this.m_bTriCroissantPre;
	}

	// .. Si on n'a pas le nombre total de ligne : note d'envoyer une requete pour faire le parcours en arriere plan
	this.m_bFinTrouve = clWDAJAXMain.bXMLGetAttributSafe(oXMLLignes, this.XML_FIN);
	this.m_sCleParcourtAP = clWDAJAXMain.sXMLGetAttributSafe(oXMLLignes, this.XML_CLEENREGAP, "");

	// (Zones r�p�t�es) Si le nombre de rupture a changer : il faut remettre a jour les pointeurs vers le HTML
	// (Cest le cas en cas de premier affichage, les HTML des lignes est deja cree AVANT de savoir qu'il y a des ruptures
	// Il faut le faire apres la creation des lignes (cas sans limite)
	if (this.m_nNbRuptures != nOldRuptures)
	{
		// GP 25/11/2015 : QW266376 : Retour en arri�re car cela pose trop de probl�mes
//		// GP 25/11/2015 : QW266335 : Li� � "Vu avec TB93836". Ici le HTML de la table n'est pas forc�ment encode disponible.
//		// Mais ce n'est pas grave, on va juste se noter de faire ce qu'il faut
//		bAvecColonnesInvisiblesOuEchangees = true;
		this.m_oEtatLignes.RecalculeObjetsRuptures(this);
	}

	// Si on recoit une commande de reset : l'execute
	var bDebut = clWDAJAXMain.bXMLAttributExiste(oXMLLignes, this.XML_DEBUT);
	var nDebut;
	var sDebutCle;
	if (bDebut)
	{
		var sDebut = clWDAJAXMain.sXMLGetAttribut(oXMLLignes, this.XML_DEBUT);
		nDebut = this.nGetDebut(sDebut);
		sDebutCle = this.sGetDebutCle(sDebut);
	}
	switch (clWDAJAXMain.nXMLGetAttributSafe(oXMLLignes, clWDAJAXMain.XML_CHAMP_REFRESH_RESETTABLE, 0))
	{
		case 1:
			// Si on a l'attribut de position : se place au bon endroit (Utiliser par la recherche
			if (bDebut)
			{
				this._vRefresh(1, nDebut, sDebutCle);
			}
			else
			{
				this._vRefresh(1, -1);
			}
			return false;
		case 2:
			this._vRefresh(2, -1);
			return false;
		default:
			// Si on a l'ttribut de position : se place au bon endroit (Utiliser par la recherche
			if (bDebut)
			{
				this.SetDebut(nDebut, sDebutCle);
			}
			break;
	}

	// Vide le cache des donnees inutiles
	this.m_oCache.SupprimeLignesInutiles(this);

	// GP 08/03/2021 : TB121012 : Il faut d�tecter si on a des colonnes invisibles MODIFIES.
//	// GP 13/04/2015 : TB92145 : Il faut r�afficher les colonnes si on avait des colonnes invisibles avant
//	// - a = a || b;
//	//	=> Evite de faire le calcul si a est d�j� a true;
//	// - this.m_tabColonnes peut changer apr�s this.__RemplitSelonXML
//	// - !clWDUtil.bForEach(..., return x);
//	//	=> Si on trouve une colonne invisible on retourne false, ce qui arrete le parcours et qui fait retourner false
//	bAvecColonnesInvisiblesOuEchangees = bAvecColonnesInvisiblesOuEchangees || !clWDUtil.bForEach(this.m_tabColonnes, function(oColonne)
//	{
//		return oColonne.bGetVisible();
//	});
	// Evite de faire le calcul si bAvecColonnesInvisiblesOuEchangees est d�j� � true;
	var tabVisibiliteColonneAvant = [];
	if (!bAvecColonnesInvisiblesOuEchangees)
	{
		// On n'utilise pas Array.prototype.map qui n'est pas disponible en IE avec HTML 4.
		clWDUtil.bForEach(this.m_tabColonnes, function (oColonne)
		{
			tabVisibiliteColonneAvant.push(oColonne.bGetVisible());
			return true;
		});
	}

	// On lance le parcours des nodes filles
	this.__RemplitSelonXML(oXMLLignes.firstChild);

	// GP 27/01/2015 : TB90885 : Si on n'est pas sans limites, que le nouveau nombre de lignes est inf�rieur au nombre de lignes affich�es :
	// D�clenche un recalcul des lignes affich�es (car par exemple du repliement de ligne qui fait de la place bas)
	if (!this.bGetSansLimite() && (this.m_nNbLignes < nAncienNbLignes) && (this.m_nNbLignes < this.m_nNbLignesHTML))
	{
		this.bMAJNbLignesVisibles(false, false, true);
	}

	// Met a jour les pictos de tri de la table (maintenant que l'on a recu la liste des colonnes)
	// Uniquement si on a la classe de gestion du tri de la recherche et du filtrage (toujours pour les tables, jamais pour les ZRs)
	var tabColonnes = this.m_tabColonnes;
	// GP 25/08/2014 : TB88515 : D�plac� apr�s la gestion du d�placement des colonnes sinon celle-ci annule cette action.
//	if (this.m_oPopupSaisieTRF)
//	{
//		this.m_oPopupSaisieTRF.AjouteLienImages(tabColonnes);
//	}
	if (this.m_oAffichageColonnes)
	{
		this.m_oAffichageColonnes.Init(tabColonnes);
		// - a = a || b;
		//	=> Evite de faire le calcul si a est d�j� a true;
		// - !clWDUtil.bForEach(..., return x);
		//	=> Si on trouve une colonne d�plac�e on retourne false, ce qui arrete le parcours et qui fait retourner false
		bAvecColonnesInvisiblesOuEchangees = bAvecColonnesInvisiblesOuEchangees || !clWDUtil.bForEach(tabColonnes, function(oColonne)
		{
			return oColonne.m_nRangCreation == oColonne.m_nPositionAffichage;
		});
		// GP 06/02/2014 : Inutile : fait par this.m_oAffichageColonnes.Init
//		this.m_oAffichageColonnes.InitTitres();
	}

	// GP 08/03/2021 : TB121012 : Il faut d�tecter si on a des colonnes invisibles MODIFIES.
//	// On veux d�tecter les colonnes invisibles :
//	// - a = a || b;
//	//	=> Evite de faire le calcul si a est d�j� a true;
//	// - !clWDUtil.bForEach(..., return x);
//	//	=> Si on trouve une colonne invisible on retourne false, ce qui arrete le parcours et qui fait retourner false
//	bAvecColonnesInvisiblesOuEchangees = bAvecColonnesInvisiblesOuEchangees || !clWDUtil.bForEach(tabColonnes, function(oColonne)
//	{
//		return oColonne.bGetVisible();
//	});
	bAvecColonnesInvisiblesOuEchangees = bAvecColonnesInvisiblesOuEchangees || !clWDUtil.bForEach(this.m_tabColonnes, function (oColonne, nColonne)
	{
		return tabVisibiliteColonneAvant[nColonne] === oColonne.bGetVisible();
	});
	if (bAvecColonnesInvisiblesOuEchangees)
	{
		// Lib�re imm�diatement le DnD sur les titres
		if (this.m_oAffichageColonnes)
		{
			this.m_oAffichageColonnes.LibereTitres();
		}

		this.__GenereLignesHTML(true);

		// Et replace le DnD sur les nouveau titres
		if (this.m_oAffichageColonnes)
		{
			this.m_oAffichageColonnes.InitTitres();
		}

		this.InitEtatLignes(this.m_nNbLignesHTML);

		// Applique la visibilite des colonnes
		this.AfficheColonnes();
	}

	// GP 19/05/2015 : QW257258 : Redessine le picto de tri quand on a fini de redessiner les titres de colonnes
	// GP 24/03/2021 : TB121388 : On redessine toujours le picto.
//	if (undefined != this.m_nColonneTriePre)
	{
		// Actualise l'affichage des pictos
		this.__TriColonne(this.m_nColonneTriePre, this.m_bTriCroissantPre);
	}

	if (this.m_oPopupSaisieTRF)
	{
		this.m_oPopupSaisieTRF.AjouteLienImages(tabColonnes);
	}

	// Si on a un ascenseur
	if (!this.bGetSansLimite())
	{
		// GP 28/11/2013 : QW240015 : Utilise le flag transmis
		bForceMAJAscenseur |= bDebut;
		// Met a jour la bare de defilement et les lignes visible a l'ecran
		// Sauf si on a des ruptures (sera fait APRES la MAJ de l'ecran sinon l'ascenseur utilise des anciennes donnees et un effet de yoyo apparait)
		// Sauf aussi si la hauteur des lignes est variables
		// Mais on le force si la MAJ est force
		if (bForceMAJAscenseur || !this.bGetHauteurLigneVariable())
		{
			this.MAJAscenseur(bForceMAJAscenseur);
		}
	}

	// Et met a jour l'affichage
	var bManqueLignes = this.bMAJLignes();

	// GP 03/12/2015 : TB90868
	if (null !== this.m_oDonneFocusTableZR)
	{
		this.DonneFocusTableZR();
	}

	// Si on a un ascenseur et des ruptures, MAJ retarde (apres affichage) de l'ascenseur
	if (!this.bGetSansLimite() && this.bGetHauteurLigneVariable())
	{
		// GP 29/10/2012 : A priori les valeurs sont immediatement correctes
//		// GP 24/08/2012 : Dans le cas des tables hi�rarchiques on peut avoir deux MAJ
//		// => Cela ne sert a rien de faire le calcul deux fois : Passage de nSetTimeout en nSetTimeoutUnique
//		this.nSetTimeoutUnique("MAJAscenseurRuptures", clWDUtil.ms_oTimeoutImmediat);
		this.MAJAscenseurRuptures();
	}

	// GP 14/01/2014 : Si on est sans limite, force l'affichage de la ligne s�lectionn�e
	if (this.bGetSansLimite() && bDebut)
	{
		location.hash = "#" + this.sGetNomElement(this.sGetSuffixeIDElement(nDebut));
	}

	// GP 02/03/2015 : TB83206 : Si on est une table avec limites, que le nombre de ligne de la table � chang� pendant l'appel et que l'on peut afficher plus de lignes
	if ((!this.bGetSansLimite()) && (nAncienNbLignes < this.m_nNbLignes) && bManqueLignes)
	{
		this.m_oCache.bRemplitCache(this, false, this.m_nColonneTrie, this.m_bTriCroissant);
	}

	// Essaie de chercher la fin si besoin
	if (this.m_bFinTrouve == false)
	{
		this.ChercheFin();
	}

	// Si on n'a pas de requ�tes
	if ((0 === this.m_oCache.m_tabRequetes.length) && this.m_oCelluleSaisie)
	{
		this.m_oCelluleSaisie.OnMAJDonnees();
	}

	this.__ForceReflowSafari();

	return true;
};

// parse une partie du XML qui contient les donn�es
WDTable.prototype.__RemplitSelonXML = function __RemplitSelonXML(oXMLFils)
{
	while (oXMLFils != null)
	{
		// Selon le type d'action
		switch (oXMLFils.nodeName)
		{
		case this.XML_LIGNES:
			// Remplit le cache avec les donnees recues
			this.m_oCache.RemplitCacheLignes(this, oXMLFils);
			break;
		case this.XML_SELECTIONS:
			// Selection
			this.RemplitSelection(oXMLFils);
			break;
		case this.XML_COLONNES:
			// Remplit les proprietes des colonnes
			this.RemplitColonnes(oXMLFils);
			break;
		case this.XML_ERREUR:
			// Affiche une erreur
			this.AfficheErreur(oXMLFils);
			break;
		}
		// On passe au fils suivant
		oXMLFils = oXMLFils.nextSibling;
	}
};

// Charge les propri�t�s sp�cifiques
//WDTable.prototype._vActionListeSpecifique = function _vActionListeSpecifique(oXMLLignes)
WDTable.prototype._vActionListeSpecifique = clWDUtil.m_pfVide;

// Indique si la hauteur des lignes est variables
WDTable.prototype.bGetHauteurLigneVariable = function bGetHauteurLigneVariable()
{
	return this.m_bHauteurLigneVariable || (this.m_nNbRuptures > 0);
};

// Recepere le style CSS a utiliser pour la hauteur des lignes :
// - table : "height"
// - ZR : "height" pour le mode quirks, "min-height" pour le reste
WDTable.prototype._vsGetCSSLigneHeight = function _vsGetCSSLigneHeight()
{
	return "height";
};

// Indique si on a une couleur de fond pour la s�lection de la ligne
// => Oui dans les tables. On devrait �tre plus pr�cis mais il faudrait avoir les couleurs de fond des styles.
WDTable.prototype._vbAvecCouleurDeFondSelection = clWDUtil.m_pfVide;

// Genere le nombre de ligne HTML qui va bien pour afficher le tableau
WDTable.prototype.__GenereLignesHTML = function __GenereLignesHTML(bAvecEntetes)
{
	// Cree des nouvelles lignes
	if (this.bGetSansLimite())
	{
		// GP 01/12/2012 : TB79848 : Dans le cas d'une table sans limite, si toutes les lignes ne sont pas pleines (donc il faut des ruptures), la division
		// par this.vnGetNbLignesLogiquesParLignePhysique() fait qu'il manque des lignes � la fin
		// Donc on ne divise pas (il y alors parfois trop de lignes) que l'on masque ensuite.
		if (0 < this.nGetNbRuptures())
		{
			// Inutile de tester en plus this.vnGetNbLignesLogiquesParLignePhysique() > 1 car cela arrive au m�me
			this.m_nNbLignesHTML = this.m_nNbLignes;
		}
		else
		{
			this.m_nNbLignesHTML = Math.ceil(this.m_nNbLignes / this.vnGetNbLignesLogiquesParLignePhysique());
		}
	}
	else
	{
		this.m_nNbLignesHTML = Math.ceil((this.m_nNbLignesPage / this.vnGetNbLignesLogiquesParLignePhysique()) + 2);
	}

	var tabHTMLLigne = this._vtabGenereLignesHTML(bAvecEntetes);

	this.__PlaceDansTable(this.m_oHote, tabHTMLLigne);
	if (bIE)
	{
		// MAJ de this.m_oHote qui a �t� recr��
		this.m_oHote = this.oGetIDElement(this.ID_TABLEINTERNE);
	}
};

// Code commun entre WDTable.prototype._vtabGenereLignesHTML et WDZR.prototype._vtabGenereLignesHTML
WDTable.prototype._sCorrigeHTMLLigne = function _sCorrigeHTMLLigne(sHTMLLigne)
{
	// Remplace le mot cle de l'ancien mode par celui du nouveau mode
	sHTMLLigne = sHTMLLigne.replace(new RegExp("\\[%" + this.m_sAliasChamp + "%\\]", "g"), "[%_INDICE_%]");
	sHTMLLigne = sHTMLLigne.replace(/\[%_INDICE_;1%\]/g, "[%_INDICE_%]");
	// Remplace le mot de hauteur par le "height"/"min-height" qui va bien
	sHTMLLigne = sHTMLLigne.replace(/\[%_CSS_HEIGHT_%\]/g, this._vsGetCSSLigneHeight);

	// GP 26/08/2015 : QW260482 : Si on est un clone on peut avoir des [%ALIAS_ORIGINAL..ALIAS%] qui trainent
	var sAliasOriginal = clWDUtil.sGetAliasDeEffectif(this.m_sAliasChamp);
	if (sAliasOriginal != this.m_sAliasChamp)
	{
		sHTMLLigne = sHTMLLigne.replace(new RegExp("\\[%" + sAliasOriginal + "\\.\\.ALIAS%\\]", "g"), this.m_sAliasChamp);
	}

	return sHTMLLigne;
};

// Genere le nombre de ligne HTML qui va bien pour afficher le tableau
WDTable.prototype._vtabGenereLignesHTML = function _vtabGenereLignesHTML(bAvecEntetes)
{
	// Recupere le HTML des lignes
	var oSourceHTML = this.m_oSourceHTML;
	var oSourceHTMLTBody = oSourceHTML.tbody;

	// Construit le HTML des lignes, normalement on a une seule ligne mod�le (on a plusieurs lignes uniquement dans les titres avec des surent�tes)
//	var sHTMLColGroup = this.__sConstruitHTML(oSourceHTMLTBody.colgroup, false);
	var sHTMLLigne = this._sCorrigeHTMLLigne(this.__sConstruitHTML(oSourceHTMLTBody.contenu[0], false));

	// Le tableau du HTML des lignes
	var nLimiteI = this.m_nNbLignesHTML;
//	var tabHTMLLigne = new Array(nLimiteI + 1);
//	tabHTMLLigne[0] = sHTMLColGroup
	var tabHTMLLigne = new Array(nLimiteI);
	var i;
	for (i = 0; i < nLimiteI; i++)
	{
		// Construit le HTML de la nouvelle ligne
		// Remplacer les balises indiquant le numero de ligne
//		tabHTMLLigne[i + 1] = sHTMLLigne.replace(/\[%_INDICE_%\]/g, i);
		tabHTMLLigne[i] = sHTMLLigne.replace(/\[%_INDICE_%\]/g, i);
		// Pas de remplacement des commentaires (deja fait au chargement du HTML)
	}

	// GP 17/11/2013 : Uniquement si la table est avec des titres de colonnes
	if (bAvecEntetes && this.m_oTitrePosPixel)
	{
		var oSourceHTMLTHead = oSourceHTML.thead;
		// Construit le HTML des lignes, normalement on a une seule ligne mod�le (on a plusieurs lignes uniquement dans les titres avec des surent�tes)
//		var tabHTMLTitre = [this.__sConstruitHTML(oSourceHTMLTHead.colgroup, true)];
		var tabHTMLTitre = [];
		var tabContenuTitre = oSourceHTMLTHead.contenu;
		var nLigneTitre;
		var nLimiteLigneTitre = tabContenuTitre.length;
		for (nLigneTitre = 0; nLigneTitre < nLimiteLigneTitre; nLigneTitre++)
		{
			tabHTMLTitre.push(this.__sConstruitHTML(tabContenuTitre[nLigneTitre], true));
		}

		this.__PlaceDansTable(this.m_oTitrePosPixel, tabHTMLTitre);

		// GP 07/04/2015 : TB91615 : Et place le titre des colonnes
		clWDUtil.bForEachThis(this.m_tabColonnes, this, function (oColonne, nColonne)
		{
			if (oColonne && oColonne.bGetVisible())
			{
				var oTitreColonne = this.oGetIDElement(clWDTableDefs.ID_TITRE, nColonne);
				if (oTitreColonne && (null != oColonne.m_sTitre))
				{
					// GP 09/04/2015 : QW256989 : On eput avoir une table pour le centrage
					if (oTitreColonne.firstElementChild && clWDUtil.bBaliseEstTag(oTitreColonne.firstElementChild, "table"))
					{
						var tabTD = oTitreColonne.getElementsByTagName("td");
						if (tabTD && tabTD[0])
						{
							oTitreColonne = tabTD[0];
						}
					}
					oTitreColonne.innerHTML = clWDUtil.sEncodeInnerHTML(oColonne.m_sTitre, true);
				}
			}
			return true;
		});

		if (bIE)
		{
			this.m_oTitrePosPixel = this.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_POSITION_PIXEL);
		}
	}

	return tabHTMLLigne;
};
WDTable.prototype.__sConstruitHTML = function __sConstruitHTML(oContenuLigne, bPourTitre)
{
	var tabHTML = [];
	// G�n�re le d�but de la ligne
	tabHTML.push(oContenuLigne.debut);

	// G�n�re les colonnes
	var tabContenuColonnes = oContenuLigne.contenu;
	if (this.m_oAffichageColonnes && this.m_oAffichageColonnes.m_tabPositionAffichage.length)
	{
		var tabPositionAffichage = this.m_oAffichageColonnes.m_tabPositionAffichage;
		var nColonneAffichage;
		var nLimiteColonneAffichage = tabPositionAffichage.length;
		for (nColonneAffichage = 0; nColonneAffichage < nLimiteColonneAffichage; nColonneAffichage++)
		{
			var oColonne = tabPositionAffichage[nColonneAffichage].m_oColonne;
			var sContenu = tabContenuColonnes[oColonne.m_nRangCreation];
			// Inutile de faire les calculs si le contenu est vide (et cela permet de g�rer du m�me coup le cas "vide" cr�� par les surent�tes de colonnes.
			if (sContenu)
			{
				// GP 25/11/2013 : Replace le code de redimensionnement original
				// Seulement si la colonne est affich�e
				var bAffiche = false;
				if (oColonne.bGetVisible())
				{
					bAffiche = true;
				}
				else if (bPourTitre)
				{
					// GP 22/11/2019 : QW319451 : La visiblit� des titres est pris en charge par le style en RWD.
					if (clWDUtil.bRWD)
					{
						bAffiche = true;
					}
					else
					{
						// GP 30/04/2018 : TB102450 : La colonne n'est pas affich�e. Mais c'est peut-�tre un sur ent�te sur plusieurs colonnes dont une des colonne est affich�e : Regarde les colonnes suivantes.
						for (var nColonneAffichageSuivant = nColonneAffichage + 1; nColonneAffichageSuivant < nLimiteColonneAffichage; nColonneAffichageSuivant++)
						{
							var oColonneSuivante = tabPositionAffichage[nColonneAffichageSuivant].m_oColonne;
							var sContenuColonneSuivante = tabContenuColonnes[oColonneSuivante.m_nRangCreation];
							if (!sContenuColonneSuivante)
							{
								if (oColonneSuivante.bGetVisible())
								{
									bAffiche = true;
								}
							}
							else
							{
								break;
							}
						}
					}
				}
			}


			if (bAffiche)
			{
				// G�n�re le contenu de la colonne en trouvant son HTML � sa position de cr�ation
				tabHTML.push(tabContenuColonnes[oColonne.m_nRangCreation]);
			}
		}
	}
	else
	{
		var nColonneContenu;
		var nLimiteColonneContenu = tabContenuColonnes.length;
		var tabColonnes = this.m_tabColonnes;
		for (nColonneContenu = 0; nColonneContenu < nLimiteColonneContenu; nColonneContenu++)
		{
			// GP 27/10/2014 : QW250619 : On ne filtre pas. Si on n'a pas de colonne invisibles, le code n'est jamais MAJ.
			// Donc ici si on n'a pas de colonne, on affiche (au lieu de ne pas afficher) car this.m_tabColonnes n'est disponible au premier calcul.
			// GP 24/10/2014 : Il faut filtrer les colonnes invisibles
			if ((!tabColonnes[nColonneContenu]) || tabColonnes[nColonneContenu].bGetVisible())
			{
				// G�n�re le contenu de la colonne en trouvant son HTML � sa position de cr�ation
				tabHTML.push(tabContenuColonnes[nColonneContenu]);
			}
		}
	}

	// G�n�re la fin de la ligne
	tabHTML.push(oContenuLigne.fin);

	return tabHTML.join("");
};
WDTable.prototype.__PlaceDansTable = function __PlaceDansTable(oTable, tabHTML)
{
	// Supprime les lignes actuelles
	clWDUtil.SupprimeFils(oTable);

	// Et selon le navigateur on recree la table differement
	if (bIE)
	{
		// Pour IE

		// Recupere le HTML
		var sHTMLTable = oTable.outerHTML;
		sHTMLTable = clWDAJAXMain.sSupprimeEspacements(sHTMLTable);

		// Et contruit le HTML global
		oTable.outerHTML = sHTMLTable.substr(0, sHTMLTable.length - "</TABLE>".length) + tabHTML.join("") + "</TABLE>";
	}
	else
	{
		var oRange = document.createRange();
		oRange.setStart(oTable, 0);
		oTable.appendChild(oRange.createContextualFragment(tabHTML.join("")));
		// Force le reflow de la page car sinon firefox ne le fait pas bien (Au moins jusqu'a la version
		oTable.style.width = oTable.style.width;
	}
};

// Remplit la table des lignes selectionnees
WDTable.prototype.RemplitSelection = function(oXMLSelections)
{
	// Supprime la selection memorise courante
	this.bLigneDeselectionneTous(-1, NaN);

	// M�morise si on est en s�lection � la cellule.
	this.m_nSelectionCellule = clWDAJAXMain.nXMLGetAttributSafe(oXMLSelections, this.XML_SELECTIONS_CELLULE, 0);

	// Met a jour le cache des selections
	var oXMLSelection = oXMLSelections.firstChild;
	while (oXMLSelection)
	{
		// Lit le numero de la ligne
		//assert(XMLLigne.nodeName == this.XML_SELECTION);
		var nSelection = clWDAJAXMain.nXMLGetValeur(oXMLSelection);
		var nColonne = parseInt(clWDAJAXMain.nXMLGetAttributSafe(oXMLSelection, this.XML_SELECTION_COLONNE, ""), 10);
		// Les numeros recu sont deja corrige des lignes invisibles
		// Seulement si la ligne n'existe pas encore
		if (clWDUtil.nElementInconnu === this.nLigneSelectionne(nSelection, nColonne))
		{
			// Convertit la ligne ne numero de ligne avec position absolue
			this._bLigneSelectionne(nSelection, this.nPosAbsolue2PosVisible(nSelection), nColonne, false);
		}

		// Passe a la selection suivante
		oXMLSelection = oXMLSelection.nextSibling;
	}
};

// Recupere le nombres de ruptures
WDTable.prototype.nGetNbRuptures = function nGetNbRuptures()
{
	return this.m_nNbRuptures;
};

// Remplit les proprietes des colonnes
WDTable.prototype.RemplitColonnes = function(oXMLColonnes)
{
	// Vide la liste des colonnes
	var tabColonnes = [];
	var tabFiltres = [];

	// Puis parse le XML
	for (var oXMLColonne = oXMLColonnes.firstChild; oXMLColonne; oXMLColonne = oXMLColonne.nextSibling)
	{
		var nColonne = tabColonnes.length;

		// Lit le numero de la ligne
		//assert(XMLLigne.nodeName == this.XML_COLONNE);
		tabColonnes.push(new WDTableAJAXColonne(oXMLColonne, nColonne));

		// GP 04/11/2021 : QW445332 : Transmet la valeur actuelle de la recherche/du filtrage (clValeurFiltre).
		// Si on ne transmet pas la valeur, en cas de rafraichissement de la page, on perd le contenu (maintenu localement de WDTable.m_tabFiltres et donc on n'affiche plus l'option de suppression du filtre).
		if (clWDAJAXMain.bXMLAttributExiste(oXMLColonne, "FILTRE_VALEUR"))
		{
			tabFiltres[nColonne] = clWDAJAXMain.sXMLGetAttribut(oXMLColonne, "FILTRE_VALEUR");
		}
	}
	this.m_tabColonnes = tabColonnes;
	this.m_tabFiltres = tabFiltres;

	// Applique la visibilite des colonnes
	this.AfficheColonnes();
};

// Applique la visibilite des colonnes
WDTable.prototype.AfficheColonnes = function()
{
	// Initialise les styles
	this.m_oStyleCacheLargeur.CreationAjout();

	// GP 27/01/2014 : Force l'alignement si on peut avoir un ascenseur
	var bPremiereLargeur = true;
	if (this.bGetCacheCompletAscenseur())
	{
		this.m_oAffichageColonnes.__ColonnesFige_StyleEnCreation();
		bPremiereLargeur = false;
	}

	var tabColonnes = this.m_tabColonnes;
	var i;
	var nLimiteI = tabColonnes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oColonne = tabColonnes[i];
		this.AfficheColonne(i, oColonne.bGetVisible());
		// GP 25/11/2013 : Replace le code de redimensionnement original
		// Si besoin fixe la dimension de la colonne
		if ((0 < oColonne.m_nLargeur) && this.m_oAffichageColonnes)
		{
			// M�morise les largeurs si la premi�re modification
			if (bPremiereLargeur)
			{
				this.m_oAffichageColonnes.__ColonnesFige_StyleEnCreation();
				bPremiereLargeur = false;
			}
			// Et fixe les colonnes
			this.m_oAffichageColonnes.__SetDimColonne(oColonne, oColonne.m_nLargeur);
		}
	}

	// Applique les styles
	this.m_oStyleCacheLargeur.CreationFin();
};

// Calcule le nombre de niveau dans l'encadrement de la cellule
WDTable.prototype.nGetNbNiveauAutourCellule = function nGetNbNiveauAutourCellule(oCellule)
{
	// Pour certains style la generation ajoute un niveau de tables
	if (clWDUtil.bBaliseEstTag(oCellule.parentNode, "td") && (oCellule.parentNode.style.cssText != ""))
	{
		return 2 + 4;
	}
	else
	{
		return 2;
	}
};

// Effectue les modifications de visibilite requise sur les colonnes
WDTable.prototype.AfficheColonne = function(nColonne, bAffiche)
{
	// Affiche ou pas le titre de la colonne
	this.AfficheCellule(clWDTableDefs.ID_TITRE, nColonne, 2, bAffiche, true);

	// Si la colonne n'existe pas (Pas de ligne visible) alors on ne fait rien
	var oPremiereCellule = this.oGetIDElement(0, nColonne);
	if (!oPremiereCellule)
	{
		return;
	}

	var nNiveau = this.nGetNbNiveauAutourCellule(oPremiereCellule);

	// Defini la taille de la colonne cote donnees
	// Si le style est deje OK ne fait rien
	var oDiv = this.__oGetParent(oPremiereCellule, nNiveau);
	var oCelluleCurrentStyle = clWDUtil.oGetCurrentStyle(oDiv);
	if (oCelluleCurrentStyle.display == clWDUtil.sGetDisplayPourAffiche(oDiv, bAffiche))
	{
		return;
	}

	// Applique le style sur les lignes
	var i;
	var nLimiteI = this.m_oEtatLignes.nGetNbEtatLignes();
	for (i = 0; i < nLimiteI; i++)
	{
		this.AfficheCellule(i, nColonne, nNiveau, bAffiche, false);
	}
};

// Effectue les modifications de visibilite requise sur une cellule
WDTable.prototype.AfficheCellule = function(nLigne, nColonne, nNiveau, bAffiche, bPourTitre)
{
	function __AfficheCellule(oCellule, bAffiche)
	{
		if (oCellule)
		{
			// On est sur le TD parent
			clWDUtil.SetDisplay(oCellule, bAffiche);
			var oTDSuivant = oCellule.nextElementSibling;
			// Il faut aussi rendre invisible la colonne de redimensionnement
			if (oTDSuivant && (0 === oTDSuivant.id.length))
			{
				clWDUtil.SetDisplay(oTDSuivant, bAffiche);
			}
		}
	}

	// Recupere le DIV
	var oCellule = this.oGetIDElement(nLigne, nColonne);
	oCellule = this.__oGetParent(oCellule, nNiveau);
	// Et l'affiche
	__AfficheCellule(oCellule, bAffiche);
	// GP 25/11/2019 : QW319451 : Il y a une seconde ligne sur les titres (de hauteur z�ro mais qui donne les largeurs).
	if (oCellule && bPourTitre)
	{
		var nCelluleIndex = oCellule.cellIndex;
		var oTRParent = oCellule.parentNode;
		// "0 <= nCelluleIndex" : teste le cas undefined car 0 <= undefined retourne false.
		if ((0 <= nCelluleIndex) && oTRParent)
		{
			var oTRSuivant = oTRParent.nextElementSibling;
			if (oTRSuivant && oTRSuivant.cells)
			{
				__AfficheCellule(oTRSuivant.cells[nCelluleIndex], bAffiche);
			}
		}
	}
};

// Remonte les parents
WDTable.prototype.__oGetParent = function __oGetParent(oElement, nNiveau)
{
	while (oElement && (nNiveau-- > 0))
	{
		oElement = oElement.parentNode;
	}
	return oElement;
};

// Affiche un erreur sur les tables
WDTable.prototype.AfficheErreur = function(oXMLErreur)
{
	// Recupere le texte de l'erreur
	alert(clWDAJAXMain.sXMLGetValeur(oXMLErreur));
};

// Vide une cellule de table
// La suppression des ruptures est fait par l'appel parent
WDTable.prototype.vVideCellule = function vVideCellule(oEtatLigne/*, nColonne*/)
{
	// GP 23/05/2013 : TB81588 : Si une colonne est invisible on ne trouve pas sa cellule.
	// Donc si la colonne est invisible au milieu de la table, on ne vide pas les colonnes suivantes
	// Il faut donc faire le calcule pour toutes les colonnes

	// GP 01/09/2014 : On ne peut pas �tre dans une zone r�p�t�e, la fonction est red�finie dans WDZR et ne fait pas l'appel de la classe de base
	clWDUtil.WDDebug.assert(!this.vbZR());

	// Si on arrive ici c'est que l'on a remplit la ligne : on utilise directement le cache
	var tabCacheCelluleHTML = oEtatLigne.tabGetCelluleHTMLCache();

//	// On parcours les valeur pour les mettre dans le HTML
//	var i = -1;

//	while (oCellule = oEtatLigne.oGetCelluleHTML(this, (++i)))
	var oThis = this;
	clWDUtil.bForEachIn(tabCacheCelluleHTML, function (sCle, oCellule)
	{
		if (oCellule)
		{
			// Supprime le contenu actuel
			clWDUtil.SupprimeFils(oCellule);

			// GP 17/09/2012 : TB79043
			oCellule = oCellule.parentNode;
			// 65479 Si on est dans dans une table avec hauteur variable, il faut prendre un niveau au dessus
			// GP 08/10/2015 : TB93916 : Valable aussi si on n'a pas la hauteur de ligne variable (en particulier la manipulation pour l'alignement) pour s'adapter au contenu de la ligne)
//			if (!oThis.vbZR() && oThis.bGetHauteurLigneVariable())
			if (!oThis.vbZR())
			{
				// GP 09/10/2015 : TB93916 : Il faut mettre aussi ici le code de TB92912.
				// GP 10/06/2015 : TB92912 : Il y a des niveaux suppl�mentaires si il y a un alignement. Explication par GF avec un extrait de code de WDxxxHTML.
				// //On a besoin d'une table de cadrage vertical si table AJAX, cadrage vertical de colonne d�fini autre que haut et que style texte d�fini (sinon style texte incorrect)
				// BOOL bTableCadrageVertical = m_bAJAX && bCadrageVerticalDefiniAutreQueHaut(eCadrageVertical(pclColonne)) && bStyleTexteDefini(pclColonne->pclStyleGen(),&clStyleDiffLigne);
				// Les divers tests sont pour �tre sur d'�tre dans ce cas particulier et de ainsi ne pas faire de r�gressions. Peut-�tre sont-ils trop restrictifs.
				if (clWDUtil.bBaliseEstTag(oCellule, "td") && (oCellule == oCellule.parentNode.firstElementChild) && (!oCellule.nextElementSibling) && clWDUtil.bBaliseEstTag(oCellule.parentNode.parentNode.parentNode.parentNode, "div"))
				{
					oCellule = oCellule.parentNode.parentNode.parentNode.parentNode;
				}

				oCellule = oCellule.parentNode;
			}

			// GP 01/09/2014 : Report de la correction de WDTableCacheLigne.prototype.vbMAJLigne => Ce qui d�clenche le fait de commenter le tout
			// (1 < vnGetNbLignesLogiquesParLignePhysique()) n'est possible que sur les ZRs : donc avoir les deux tests a vrai est impossible : je commente le code
//			// 66352 Ou si on est dans une ZR avec colonne mutiples (uniquement si la ligne est affichee sinon on colorie les lignes invisibles)
//			if (1 < oThis.vnGetNbLignesLogiquesParLignePhysique())
//			{
//				// GP 01/09/2014 : Report de la correction de WDTableCacheLigne.prototype.vbMAJLigne
//				// GP 24/01/2013 : Demande de GF pour les fonds des lignes de ZRs avec un cadre/style (nouveaut� 18 F+1)
//				// Les lignes de ZRs multi colonnes ont leur couleur de fond appliqu�es sur le td, car c'est l� qu'est �galement appliqu�e la class (style)
//				if (!oChampTable.vbZR())
//				{
//					oCellule = oCellule.firstElementChild;
//				}
//			}

			// Et supprime sa couleur
			oCellule.style.backgroundColor = "";
			// GP 17/09/2012 : Cela ne semble pas la bonne correction mais je garde le code au cas ou
			// + Il ne faut pas tenir compte de oThis.m_tabCSSTexteCelluleSelection
//			// GP 17/09/2012 : TB79043 : Et on supprime le style css de la cellule
//			oCellule.style.cssText = "";
		}

		return true;
	});
};

// Remplit une cellule de la table
// OUT : tabRedimensionnementDesImages
WDTable.prototype.vRemplitCellule = function vRemplitCellule(oCellule, sValeur, sBulleCellule, nLigneAbsolue, nColonne, oLigneCache, bSelection, tabRedimensionnementDesImages)
{
	// L'ajout des ruptures est fait par l'appel parent

	// L'element cree
	var oElement;
	var oThis = this;
	var oCelluleStyle = oCellule.style;

	// Mise en cache
	var oColonne = this._oGetColonne(nColonne);
	var eColonneTypeIDObjet = this.eColonneTypeIDObjet(nColonne);
	var nEtatLien = oColonne.m_nEtatLien;

	// Place la bulle de la colonne
	if (sBulleCellule)
	{
		oCellule.title = sBulleCellule;
	}
	else if (oColonne.m_sBulle)
	{
		oCellule.title = oColonne.m_sBulle;
	}
	else
	{
		oCellule.removeAttribute("TITLE", 0);
	}

	var bChecked = false;
	var bEcraseContenu = true;

	// A faire avant le remplissage (pour le cas des images qui modifie le style CSS de la cellule)
	// Si on est selectionne, change le style de la cellule
	var bAvecCSSTexteStyleSelection = undefined !== this.m_sCSSTexteStyleSelection;
	if (bAvecCSSTexteStyleSelection)
	{
		var sCSSTexteBase = this.m_tabCSSTexteCelluleSelection[oCellule.id];
		if (bSelection)
		{
			if (undefined === sCSSTexteBase)
			{
				sCSSTexteBase = clWDUtil.sGetCSSTexteElement(oCellule);
				this.m_tabCSSTexteCelluleSelection[oCellule.id] = sCSSTexteBase;
			}
			oCelluleStyle.cssText = sCSSTexteBase + this.m_sCSSTexteStyleSelection
		}
		else
		{
			// Evite de placer le style si la ligne n'etait pas selectionnee
			if (undefined !== sCSSTexteBase)
			{
				oCelluleStyle.cssText = sCSSTexteBase;
				// Evite de placer
				delete this.m_tabCSSTexteCelluleSelection[oCellule.id];
			}
		}
	}

	var i;
	var nLimiteI;

	// Selon le type de la colonne
	switch (eColonneTypeIDObjet)
	{
	// Interrupteur
	case this.ms_nIDObjetInterrupteur:
		// Si la colonne est invisible on ne place pas le champ cache sinon on fait perdre le focus au champ en cours de saisie (IE)
		if (false == oColonne.bGetVisible())
		{
			break;
		}
		// Creation d'un objet input avec type="checkbox"
		oElement = document.createElement("input");
		oElement.type = "checkbox";
		// Coche ?
		bChecked = (sValeur == "1");
		// Calcul du nom et affectation a NAME et a ID
		var sName = this.sGetSuffixeIDElement(nLigneAbsolue, this.m_sAliasChamp, nColonne);
		oElement.name = sName;
		oElement.id = sName;
		// Si saissisable
		if (this.bColonneSaisissable(nColonne))
		{
			oElement.onclick = function(oEvent) { oThis.ClickInterrupteur(oEvent || event, oElement, nLigneAbsolue, nColonne); return clWDUtil.bStopPropagation(oEvent); };
		}
		else
		{
			oElement.disabled = true;
		}

		// Centre l'interrupteur dans le parent
		oCelluleStyle.textAlign = "center";
		oCelluleStyle.verticalAlign = "middle";
		break;

	// Colonne image
	case this.ms_nIDObjetImage:
		// Creer un champ image avec la bonne source
		if (sValeur.length > 0)
		{
			// Sauf si bAvecCSSTexteStyleSelection car on a alors perdu la moitie du CSS de positionnement de l'image
			if (!bAvecCSSTexteStyleSelection)
			{
				// GP 25/06/2016 : TB97811/QW273390 : OPTIM : si on a d�j� la bonne image, ne fait rien.
				// src transforme la valeur (chemin relatif en chemin absolu : on garde la valeur initiale dans un attribut)
				var oPremierFils = oCellule.firstElementChild;
				if (oPremierFils && (!oPremierFils.nextElementSibling) && (oPremierFils.getAttribute("data-webdev-src-initial") == sValeur))
				{
					// Ne fait rien : garde l'image actuelle qui est d�j� valide
					bEcraseContenu = false;
					break;
				}
			}

			// Regarde si la taille de l'image n'est pas dans le cache
			var tabTailleImage = this.m_tabCacheTailleImage[sValeur];

			var oImage = document.createElement("img");
			if (undefined === tabTailleImage)
			{
				// GP 26/05/2016 : QW273455 : On peut avoir un redimensionnement entre le remplissage et l'affichage des images.
				// On a alors les images pr�c�dentes dans this.m_tabImagesNonAffichee. Li�s � la m�me cellule. On supprime donc les anciennes images du tableau.
				clWDUtil.bForEach(this.m_tabImagesNonAffichee, function (oImageEtCelluleNonAffichee, nIndice)
				{
					if (oImageEtCelluleNonAffichee.m_oCellule == oCellule)
					{
						// D�branche la callback de chargement
						oImageEtCelluleNonAffichee.m_oImage[oColonne.ms_sEventPourChargementImage] = null;
						oImageEtCelluleNonAffichee.m_oImage[oColonne.ms_sEventPourEchec] = null;
						// Supprime l'image du tableau.
						oThis.m_tabImagesNonAffichee.splice(nIndice, 1);
						// Arret de la recherche :
						// - On a supprim� un �l�ment donc l'it�ration est d�phas�e
						// - Il en peut pas avoir de doublon puisque l'ajout dans le tableau v�rifie les doublons
						return false;
					}
					return true;
				});
				var oImageEtCellule = { m_oImage : oImage, m_oCellule : oCellule };
				this.m_tabImagesNonAffichee.push(oImageEtCellule);
				// GP 28/11/2013 : Il faur brancher le onload AVANT le .src sinon on ne recoit pas le onload si l'image est d�j� dans le cache (car le chargement est imm�diat)
				// Dans l'appel "this" est l'image
				// GP 22/11/2017 : Note : on pourrait mettre le branchement APRES l'affectation du SRC. Pour le cas ou l'image est en cache, img.complete permet de le savoir et de d�clencher directement
				// l'appel sans passer par un evenement (asynchrone)
				oImage[oColonne.ms_sEventPourChargementImage] = function(oEvent) { oThis._OnRedimImage(oEvent || event, this, oImageEtCellule); };
				// GP 22/11/2017 : TB103861 : Il faut aussi d�tecter les �chec sinon on n'affiche jamais l'ascenseur
				oImage[oColonne.ms_sEventPourEchec] = function(oEvent) { oThis._OnEchecChargementImage(oEvent || event, this, oImageEtCellule); };
			}
			oImage.setAttribute("data-webdev-mode-affichage", oColonne.nGetModeAffichageImage(this));
			oImage.className = oColonne.ms_sClasseImage;
			oImage.src = sValeur;
			oImage.setAttribute("data-webdev-src-initial", sValeur);
			// L'image sera de toutes fa�ons dessin�e en transparent (utilisation de l'image de fond de la cellule parent)
			oImage.style.opacity = 0;
			if (!this.m_bHauteurLigneVariable)
			{
				oCelluleStyle.minHeight = "10000px";
			}
			if (undefined !== tabTailleImage)
			{
				// Oui le chargement de l'image est fini : dessin effectif de l'image
				// GP 27/05/2016 : QW273505 : Dans le cas des hauteurs de lignes variables, il faut faire le calcul de la hauteur des images quand toute la ligne est remplie pour avoir la vraie hauteur.
				// En effet si le nouveau contenu de la ligne est moins haut, la nouvelle hauteur n'est connue que � la fin
				tabRedimensionnementDesImages.push(function () { WDTableZRNavigateur.prototype.__s_RedimImage(oImage, oCellule, tabTailleImage, true, false); });
				// GP 27/05/2016 : QW273512 : __s_RedimImage ajoute l'�l�ment dans son parent mais APRES avoir calcul� la taille :
				// - Il est donc inutile de le faire ici aussi
				// - Depuis QW273505, le calcul est fait apr�s le remplissage de la ligne, il faut donc faire l'ajout apr�s le calcul
				// => Il suffit donc de ne rien faire.
//				oElement = oImage;
			}

			// Si la colonne est lien actif
			if ((this.nGetOptionLienColonne(nColonne) > 0) && ((0 === nEtatLien) || (nEtatLien == 5)))
			{
				oImage.onclick = function(oEvent) { oThis.OnColonneLien(nLigneAbsolue, nColonne, oEvent || event); };
			}
		}
		break;

	// Colonne combo (liste de valeurs)
	case this.ms_nIDObjetCombo:
		// Pas de brak; car comme colonne en saisie pour ce qui est de l'affichage => Simple texte

	// Colonne "simple" : colonne en saisie
	case this.ms_nIDObjetSaisie:
	default:
		// Si la colonne n'est pas lien : remplit simplement la cellule
		switch (this.nGetOptionLienColonne(nColonne))
		{
		default:
		case 0:
			// Si on est en mode hauteur de ligne variable et que le contenu contient des RC, on les restectes
			if (this.m_bHauteurLigneVariable && ((-1 != sValeur.indexOf("\r")) || (-1 != sValeur.indexOf("\n"))))
			{
				// Creation d'un span conteneur
				oElement = document.createElement("span");
				// Remplace les \r\n par des <br />
				var tabLignesTexte = sValeur.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
				nLimiteI = tabLignesTexte.length;
				for (i = 0; i < nLimiteI; i++)
				{
					if (i > 0)
					{
						oElement.appendChild(document.createElement("br"));
					}
					oElement.appendChild(document.createTextNode(tabLignesTexte[i]));
				}
			}
			else
			{
				// Si on est en encodage latin-1 (Donc pas en UTF-8) : On encode les caracteres > 127
				// Pas besoin de le faire en UTF-8 car il on deja ete encode pour avoir au final la bonne valeur unicode
				oElement = document.createTextNode(sValeur);
			}
			break;
		case 1: // Lien AJAX
		case 2: // Lien AJAX avec submit
		case 3: // Lien
		case 4: // Lien avec submit
			// Sinon on rajoute un lien autour
			oElement = document.createElement("a");

			// Calcule l'etat du lien
			switch (nEtatLien)
			{
			default:
			case 0: // Actif
			case 5: // AffSansSel
				oElement.href = "javascript:void(0);";
				oElement.onclick = function(oEvent) { oThis.OnColonneLien(nLigneAbsolue, nColonne, oEvent || event); };
				// GP 01/07/2016 : TB98731 : Hack pour avoir une destination dans la colonne : l'�dition g�n�re un lien que l'on ignore. On va essayer de trouver le target dans ce lien.
				if (undefined == oColonne.m_sTarget)
				{
					// On en fait le calcul que une seule fois : place une valeur par d�faut pour ne plus jamais le faire
					oColonne.m_sTarget = "";
					var oPremierFilsLien = oCellule.firstElementChild;
					if (oPremierFilsLien && clWDUtil.bBaliseEstTag(oPremierFilsLien, "a"))
					{
						var sTarget = oPremierFilsLien.getAttribute("target");
						var sHref = oPremierFilsLien.getAttribute("href");
						if (sTarget && (0 < sTarget.length))
						{
							oColonne.m_sTarget = sTarget;
						}
						else if (sHref && ("javascript:" == sHref.substr(0, 11)))
						{
							var sNomFonction = sHref.substr(11).split("(")[0];
							sTarget = String(sNomFonction.length && window[sNomFonction]).split(",")[6];
							if (sTarget)
							{
								var sTargetLongueur = sTarget.length;
								// GP 06/02/2018 : TB107204 : La cible extraite est une chaine donc avec les ' ou " autour.
								if (2 <= sTargetLongueur)
								{
									var sDebut = sTarget.charAt(0);
									var sFin = sTarget.charAt(sTargetLongueur - 1);
									if ((sDebut == sFin) && (("'" == sDebut) || ("\"" == sDebut)))
									{
										sTarget = sTarget.substr(1, sTargetLongueur - 2);
									}
								}
								if (sTarget)
								{
									oColonne.m_sTarget = sTarget;
								}
							}
						}
					}
				}
				break;
			case 4: // Grise
				oElement.disabled = true;
				// Pas de 'break;' : grise => DISABLED + READONLY
			case 1: // Lecture seule
				// On ne met pas de HREF pour ne pas avoir le soulignement du lien
				oElement.readOnly = true;
				break;
			}
			oElement.innerHTML = clWDUtil.sEncodeInnerHTML(sValeur, true);
			break;
		}
		break;

	case WDChamp.prototype.ms_nIDObjetCellule:
		// Cellule (colonne conteneur)
		oCellule.innerHTML = sValeur;
		bEcraseContenu = false;
		this._SetOnXxxSurChampsCellule(oCellule, nLigneAbsolue, nColonne);
		break;
	}

	// GP 03/05/2016 : Ce n'est plus le cas avec les vers r�centes de IE/Edge
//	// Si le noeud est de type lien, on supprime son evenement onclick car dans les garbages
//	// collector de IE n'arrivent pas a detecter la reference circulaire (entre l'objet DOM et
//	// l'objet JS) dans ce cas precis. Et au final l'objet n'est pas libere
//	var tabLiens = oCellule.getElementsByTagName("a");
//	nLimiteI = tabLiens.length;
//	for (i = 0; i < tabLiens; i++)
//	{
//		tabLiens[i].onclick = null;
//	}
	// Supprime le contenu actuel (sauf dans le cas de la colonne conteneur
	if (bEcraseContenu)
	{
		clWDUtil.SupprimeFils(oCellule);
	}

	// Attention : dans le cas des images : oElement est NULL : l'image n'est donc pas ajout�e
	if (oElement)
	{
		// Et ajoute l'element. On perd la selection de la case a cocher (????)
		oElement = oCellule.appendChild(oElement);
		// Fait un simple test pour la restauration car de toute facon soit c'est undefined, a false ou a true
		// Comme la valeur par defaut est false on n'a pas de probleme
		if (bChecked)
		{
			oElement.checked = true;
		}
	}

	// Mise en cache du r�sultat du calcul pour la colonne. A chaque r�ception des donn�es du serveur la colonne est recr�e.
	if (undefined === oColonne.m_bCurseurDefaut)
	{
		// Si la colonne n'est pas saisissable : affiche un autre curseur
		// GP 10/04/2015 : TB88324 : Et sauf si la colonne a un style de curseur particulier.
		oColonne.m_bCurseurDefaut = ((!this.bColonneSaisissable(nColonne)) && ("auto" == clWDUtil.oGetCurrentStyle(oCellule).cursor))
	}
	// GP 03/05/2016 : OPTIM : Il est rapide de lire un style et lent de le modifier. On teste si le curseur n'est pas d�j� le curseur par d�faut.
	if (oColonne.m_bCurseurDefaut && ("default" != oCelluleStyle.cursor))
	{
		oCelluleStyle.cursor = "default";
	}
};

// Changement de tranche
WDTable.prototype.vOnChangementTranche = function vOnChangementTranche(/*oEvent*//*, nTrancheDepuisDefautBase1*/)
{
	// Force un redessin.
	this.__OnResizeTable(2, undefined, undefined, undefined, true);
};


// D�tection des changements dans une cellule
WDTable.prototype._SetOnXxxSurChampsCellule = function _SetOnXxxSurChampsCellule(oCellule, nLigneAbsolue, nColonne)
{
	var sCelluleId = oCellule.id;

	// Puis on hook le onblur de tous les champs de la selection
	var tabElements = clWDUtil.tabGetElements(oCellule, true);
	var i;
	var nLimiteI = tabElements.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oElement = tabElements[i];

		var bOnBlurSeul = oElement.onchange === undefined;
		clWDUtil.SetOnXxx(oElement, "onblur", this, this.OnValideLigneTableZR, [sCelluleId, nLigneAbsolue, bOnBlurSeul]);
		if (false == bOnBlurSeul)
		{
			// GP 10/12/2013 : TB83991
			// GP 04/02/2014 : TB85981 : Uniquement sur les interrupteurs
			// GP 10/04/2014 : TB86931 : Avec IE8 et moins m�me en mode non quirks, le comportement est comme quirks ici
			// GP 26/02/2015 : TB90868 : Sauf que il ne faut appliquer le code que au interrupteurs : c'est quirks ou IE8- sur un interrupteur
			var sAction = (bIEQuirks || (bIE && (nIE < 9))) && clWDUtil.bBaliseEstTag(oElement, "input") && ("checkbox" == oElement.type.toLowerCase()) ? "onclick" : "onchange";
			clWDUtil.SetOnXxx(oElement, sAction, this, this.OnValideLigneTableZR, [sCelluleId, nLigneAbsolue, true]);
		}

		// On doit passer par une fonction pour les valeurs des variables sinon on a la valeurs de i lors de sa destruction
		clWDUtil.SetOnXxx(oElement, "onfocus", this, this.OnFocusLigneTableZR, [sCelluleId, nLigneAbsolue, i, nColonne]);
	}
};

// Vide les ruptures
WDTable.prototype.VideRuptures = function VideRuptures(oEtatLigne)
{
	// Vide les ruptures uniquement si on est sur la premiere colonnes
	if (this.nGetNbRuptures() > 0)
	{
		this.VideUneRupture(oEtatLigne.m_oRupturesHaut);
		this.VideUneRupture(oEtatLigne.m_oRupturesBas);
	}
};

// Vide une cellule de rupture
WDTable.prototype.VideUneRupture = function VideUneRupture(oRupture)
{
	// La rupture n'existe pas toujours (colonne autre que la premiere pour le haut)
	if (oRupture)
	{
		// Supprime le contenu
		// Supprimer les evenements des elements formulaires pour les reference circulaires entre le DOM et le JS ?
		clWDUtil.SupprimeFils(oRupture);

		// Et masque la cellule
		clWDUtil.SetDisplay(oRupture.parentNode, false);
	}
};

// Remplit les ruptures
WDTable.prototype.RemplitRuptures = function RemplitRuptures(oEtatLigne, nColonneHTML, oValeursRuptures)
{
	// Remplit les ruptures uniquement si on est sur la premiere colonne
	// C'est inutile de le faire pour les autres colonne :
	// - Dans une table, les colonnes appartiennent a la meme ligne
	// - Dans une ZRs (multicolones), la ligne change s'il y a une rupture
	if (this.nGetNbRuptures() > 0)
	{
		oValeursRuptures = oValeursRuptures ? oValeursRuptures : {};
		// Seul la premire ligne logique peu afficher une rupture
		this.RemplitUnRupture(oEtatLigne.m_oRupturesHaut, oValeursRuptures.m_sHaut, 0 === nColonneHTML);
		// On vide systematiquement pour les bas de ruptures
		// Il faudra peut-etre etre plus precis (bug ? si on met a jour un element au millieu d'une ligne)
		this.RemplitUnRupture(oEtatLigne.m_oRupturesBas, oValeursRuptures.m_sBas, true);
	}
};

// Replit une cellule de rupture
WDTable.prototype.RemplitUnRupture = function RemplitUnRupture(oRupture, sValeur, bVide)
{
	// La rupture n'existe pas toujours (colonne autre que la premiere pour le haut)
	if (oRupture)
	{
		// Vide le contenu actuel de la rupture si demande
		if (bVide)
		{
			this.VideUneRupture(oRupture);
		}

		// Remplit la rupture
		if (sValeur && sValeur.length)
		{
			// GP 28/08/2017 : Suppression des NSUtil.sEncodeInnerHTML(Chaine, false, true) qui ne font rien (sauf la conversion en chaine qui est inutile)
			oRupture.innerHTML = sValeur;
			// Normalement oRupture est un TD
			clWDUtil.SetDisplay(oRupture.parentNode, true);
		}
	}
};

// Gestion de la modification des interrupteurs
// GP 02/03/2015 : TB91448 : Le num�ro de ligne n'est pas un num�ro de ligne absolue mais un num�ro de ligne visible
//WDTable.prototype.ClickInterrupteur = function ClickInterrupteur(oEvent, oInterrupteur, nLigneAbsolue, nColonne)
WDTable.prototype.ClickInterrupteur = function ClickInterrupteur(oEvent, oInterrupteur, nLigneVisible, nColonne)
{
//	var nLigneRelative = this.nAbsolue2Visible2Relative(nLigneAbsolue);
	var nLigneRelative = this.nVisible2Relative(nLigneVisible);

	// Cree la ligne virtuelle si besoin
	if (this.bCreeLigneVirtuelle(nLigneRelative))
	{
		// Si on �tait en saisie sur cette ligne, passe � la cellule suivante
		if (this.m_oCelluleSaisie.bSaisieEnCoursDansCellule(nLigneRelative, nColonne))
		{
			this.m_oCelluleSaisie.SaisieFin(true, true, this.m_oCelluleSaisie.ms_nColonneSuivante, oEvent);
			// Bloque l'ev�nement de click (sinon on va perdre le focus du champ suivant)
			this.m_bBloqueClickSurLigne = true;
			return;
		}

		// Valide le changement
		this.SetValeurCellule(nLigneRelative, nColonne, function (bEntier)
		{
			if (oInterrupteur.checked)
			{
				return bEntier ? 1 : "1";
			}
			else
			{
				return bEntier ? 0 : "0";
			}
		});
		// Et notifie le serveur
		this.bValideChangement(nLigneRelative);
		// Et on demande la MAJ de la ligne
//		this.bMAJLigne(nLigneAbsolue);
		this.bMAJLigne(nLigneVisible);
		// Supprime la ligne virtuelle
		this.SupprimeLignesVirtuelles();
	}
};

// Envoie une requete (Via un timer) pour avoir la fin du fichier apres une petite temporisation
// Verifie si on n'a pas une requete normale en cours pour ne pas lancer la requete de remplissage
// On ne peut etre a la fin car on remplit en arriere plan
WDTable.prototype.ChercheFin = function()
{
	// Si on a deja une requete en cours => Ne fait rien
	// Ou si on connait la fin
	if ((this.m_oCache.m_tabRequetes.length > 0) || this.m_bFinTrouve)
	{
		return;
	}

	// Note d'envoier une requete aux serveur dans ce domaine dans une seconde
	// GP 24/08/2012 : Passage de nSetTimeout en nSetTimeoutUnique
	this.nSetTimeoutUnique("EnvoieChercheFin", 1000);
};

// Envoie un requte pour calculer la fin
WDTable.prototype.EnvoieChercheFin = function EnvoieChercheFin()
{
	// Si on a deja une requete en cours => Ne fait rien
	// Ou si on connait la fin (Requete arrive entre temps)
	if ((this.m_oCache.m_tabRequetes.length > 0) || this.m_bFinTrouve)
	{
		return;
	}

	// Cree une requete que l'on envoie
	this.m_oCache.CreeRequete(this, new Segment(-1, -1), -1, true, -1, "")
};

// Rafraichit une ligne
WDTable.prototype.bMAJLigne = function bMAJLigne (nLigneVisible)
{
	return this.m_oCache.bMAJLigne(this, nLigneVisible, this.vbLigneEstSelectionneeSansZR(nLigneVisible));
};
WDTable.prototype.bMAJLigneRel = function bMAJLigneRel (nLigneRelative)
{
	return this.bMAJLigne(this.nRelative2Visible(nLigneRelative));
};

// GP 05/11/2014 : QW251178 : On doit tenir compte des lignes enroul�es
WDTable.prototype.nRelative2Visible = function nRelative2Visible(nLigneRelative)
{
	return nLigneRelative + this.m_nDebut;
};
WDTable.prototype.nVisible2Relative = function nVisible2Relative(nLigneVisible)
{
	return nLigneVisible - this.m_nDebut;
};
WDTable.prototype.nRelative2Visible2Absolue = function nRelative2Visible2Absolue(nLigneRelative)
{
	return this.nPosVisible2PosAbsolue(this.nRelative2Visible(nLigneRelative));
};
WDTable.prototype.nAbsolue2Visible2Relative = function nAbsolue2Visible2Relative(nLigneAbsolue)
{
	return this.nVisible2Relative(this.nPosAbsolue2PosVisible(nLigneAbsolue));
};

// GP 07/01/2016 : TB95868 : L'exemple LST (83 ?) WW_TABLEINFOXY utilise nRelative2Absolue : le r�exporte
//// GP 23/07/2015 : WDxxxHtml g�n�re maintenant nRelative2Visible2Absolue
//// GP 17/11/2014 : QW251789 : nRelative2Absolue est r�f�renc� par le JS g�n�r� par la HTML (s�lection de la ligne en cas d'action)
//// GP 18/03/2015 : TB91810 : Ce n'est pas nAbsolue2Visible2Relative mais bien nRelative2Visible2Absolue
WDTable.prototype.nRelative2Absolue = WDTable.prototype.nRelative2Visible2Absolue;

WDTable.prototype.__nGetStylePourLigne = function __nGetStylePourLigne(nLigneAbsolue)
{
	// Il faut vraiment faire ce calcul, car on peut avoir un num�ro de ligne � -1 (Vu en essayant QW445966) : nLigneAbsolue % 2 ne convient pas cas -1 % 2 => -1.
	return (0 === (nLigneAbsolue % 2)) ? 0 : 1;
};

// Rafraichit les lignes visible si besoin
WDTable.prototype.bMAJLignes = function bMAJLignes(oEvent)
{
	// Parcours les lignes invalides
	var i;
	var nNumPlein = 0;
	var nLimiteI = this.m_oEtatLignes.nGetNbEtatLignes();
	var nLimiteJ = this.vnGetNbLignesLogiquesParLignePhysique();
	var nLigneAbsolue = this.m_nDebut;
	// Commence � -1 pour avoir la bonne valeur apr�s le ++ dans la boucle interne.
	var nPosAbsoluePourStyle = -1;
	var oLigneCache;
	var nDernierNbRepliees = 0;
	var nNbRepliees = 0;
	var nDernierI;
	var nDernierJ;
	for (i = 0; i < nLimiteI; i++)
	{
		// Recupere la ligne
		var oEtatLigne = this.oGetEtatLigne(i);

		// Parcours les lignes logiques
		// Sur la premiere cellule il y a forcement du contenu
		var j;
		for (j = 0; j < nLimiteJ; j++, nLigneAbsolue++)
		{
			// Pour le cas sans ligne (nLigneAbsolue >= this.m_nNbLignes) ou sans cache (pas oLigneCache)
			nPosAbsoluePourStyle++;

			var bJamaisAffiche = oEtatLigne.bJamaisAffiche(j);
			if (nLigneAbsolue >= this.m_nNbLignes)
			{
				// Si la ligne est visible => La masque
				if (bJamaisAffiche || oEtatLigne.bPlein(j))
				{
					oEtatLigne.MasqueLigne(j, this, nLigneAbsolue, oEvent, this.m_tabStyle, this.__nGetStylePourLigne(nPosAbsoluePourStyle));
				}
				// Mais c'est un cas ou il faut compter la ligne comme pleine
				nNumPlein++;
			}
			else
			{
				// Affiche la ligne
				oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
				if (oLigneCache)
				{
					// GP 26/03/2018 : TB107971/TB107974 : oLigneCache  a un membre m_nPosAbsolue qui contient le num�ro absolue de la ligne.
					// => Resynchronise la valeur de nPosAbsoluePourStyle
					nPosAbsoluePourStyle = oLigneCache.m_nPosAbsolue;

					nDernierNbRepliees = oLigneCache.vnGetNbReplieesOuEnroulees();
					// -1 Car il ne faut pas compter la ligne elle meme qui est repliee mais dont on affiche le titre
					if (0 < nDernierNbRepliees)
					{
						// GP 20/07/2012 : Plus de -1 car le calcul n'inclus plus la ligne courante maintenant
						nNbRepliees += nDernierNbRepliees;
					}
					nDernierI = i;
					nDernierJ = j;
					// Si on change de ligne (rupture)
					if (oLigneCache.vnGetColonneHTML() != j)
					{
						for (; j < nLimiteJ; j++)
						{
							oEtatLigne.MasqueLigne(j, this, nLigneAbsolue, oEvent);
							// On compte quand meme les cellules comme pleines pour avoir le total a la fin
							nNumPlein++;
						}
						break;
					}
				}
				var bSelection = this.vbLigneEstSelectionneeSansZR(nLigneAbsolue);
				oEtatLigne.bMAJ(j, oLigneCache, this, nLigneAbsolue, oEvent, bSelection);

				// Met le style de la ligne
				// Ligne "impaire" (La numerotation commence a zero pour la ligne 1)
				var nStyle = this.__nGetStylePourLigne(nPosAbsoluePourStyle);
				// Si la ligne est selectionne, on met un style particulier s'il y en a un
				if (((undefined !== this.m_sCSSTexteStyleSelection) || (undefined !== this.m_sCSSTexteStyleSelectionCouleurFond)) && bSelection)
				{
					nStyle = 2;
				}

				oEtatLigne.SetStyle(this, j, this.m_tabStyle, nStyle, nLigneAbsolue);

				// Compte le nombre de lignes OK
				if (oEtatLigne.bPlein(j))
				{
					nNumPlein++;
				}
			}
		}
	}

	if ((nNbRepliees > 0) && ((nNumPlein + nNbRepliees) >= this.m_nNbLignes))
	{
		for (i = nDernierI; i < nLimiteI; i++)
		{
			++nLigneAbsolue;
			for (j = nDernierJ + 1; j < nLimiteJ; j++)
			{
				oEtatLigne.MasqueLigne(j, this, nLigneAbsolue, oEvent);
				// On compte quand meme les cellules comme pleines pour avoir le total a la fin
				nNumPlein++;
			}
			nDernierJ = -1;
		}
	}

	// Effectue les op�rations apr�s MAJ des lignes
	this._vPostMAJLignes();

	var nLimiteIJ = nLimiteI * nLimiteJ;
	// Il doit y avoir un probleme dans l'algo quand tout est repliee
	// De toutes facon si on a un nombre de plein plus grand que la limite il y a un probleme
	// On traite specifiquement le cas
	if ((0 < nNbRepliees) && (nNumPlein != nLimiteIJ))
	{
		nNumPlein = nLimiteIJ;
	}
	var bManqueLignes = nNumPlein != nLimiteIJ;

	// Affiche eventuellement le masque
	this.AfficheMasque(bManqueLignes, false);

	return bManqueLignes;
};

WDTable.prototype._vPostMAJLignes = function _vPostMAJLignes()
{
	// GP 08/01/2018 : TB106614 : Transforme l'anti r�entrance en global (Ce n'est pas clair pourquoi on a cette r�entrance en 23).
	// GP 22/11/2017 : Vu avec TB104223 : anti r�entrance
//	if (this.m_bDansPostMAJLignes)
	if (WDTable.prototype.m_bDansPostMAJLignes)
	{
		return;
	}
	
	try
	{
		// GP 08/01/2018 : TB106614 : Transforme l'anti r�entrance en global (Ce n'est pas clair pourquoi on a cette r�entrance en 23).
//		this.m_bDansPostMAJLignes = true;
		WDTable.prototype.m_bDansPostMAJLignes = true;

		// Lance les notifications g�n�rales
		this.ms_oNotifications.LanceNotifications(this, this.m_oDivPosParent);
		// Notifie aussi de la modification du HTML de la page
		clWDUtil.m_oNotificationsAjoutHTML.LanceNotifications(this, this.m_oDivPosParent);

		// Et les notifications pour les tables/ZRs sans limites
		if (this.bGetSansLimite())
		{
			this.ms_oNotificationsSansLimites.LanceNotifications(this, this.m_oDivPosParent);

			// Notifie du redimensionnement
			clWDUtil.m_oNotificationsRedimensionnement.LanceNotifications(this, this.m_oDivPosParent);
		}

		// Si la fonction existe dans la page : effectue les operations apres submit AJAX
		if (typeof window.FinSubmitAJAX == "function")
		{
			FinSubmitAJAX();
		}
	}
	finally
	{
		// GP 08/01/2018 : TB106614 : Transforme l'anti r�entrance en global (Ce n'est pas clair pourquoi on a cette r�entrance en 23).
//		this.m_bDansPostMAJLignes = false;
		WDTable.prototype.m_bDansPostMAJLignes = false;
	}
};

WDTable.prototype.AfficheMasque = function(bVisible, bMasqueTransparent)
{
	// Si il y a des requetes de tri en attente dans le cache : force le masque
	if (this.m_oCache.bAvecRequeteTri())
	{
		bVisible = true;
	}

	// Si l'etat du masque ne change pas on ne fait rien pour ne pas changer les animations
	if (this.m_bMasqueVisible == bVisible)
	{
		return;
	}

	// Sauve l'etat du masque
	this.m_bMasqueVisible = bVisible;

	// Affiche les masques qui vont bien
	this.AfficheMasques(bMasqueTransparent, false);

	// Si on ne force pas le masque d'attente alors on se note de l'afficher peut etre dans quelques instants
	if (bMasqueTransparent)
	{
		this.nSetTimeout(this.AfficheMasques, 1000, false, false);
	}
};

// Affiche les masque si besoin
WDTable.prototype.AfficheMasques = function(bMasqueTransparent, bPremierAffichage)
{
	// GP 29/11/2016 : TB100039 : Optimisation de la fonction :
	// - Regroupe la fonction
	// - Ne retaille que le masque visible
	// - Regroupe les calculs en premier et les affectations ensuite
	// - Les masques non affich�s sont en display:none donc leur taille et position n'a AUCUNE importance.
	var oMasque = this.m_oMasque;
	var oMasqueTransparent = this.m_oMasqueTransparent;
	var bVisibleMasque = false;
	var bVisibleMasqueTransparent = false;
	if (this.m_bMasqueVisible)
	{
		// Un des deux masque va �tre visible
		var oMasqueVisible;
		if (bMasqueTransparent)
		{
			bVisibleMasqueTransparent = true;
			oMasqueVisible = oMasqueTransparent;
		}
		else
		{
			bVisibleMasque = true;
			oMasqueVisible = oMasque;
		}
		// On deplace enventuellement le champ si il va etre visible.
		oMasqueVisible.style.left = oMasque.parentNode.scrollLeft;

		// Retaille les masque si besoin
		this.__RedimensionneUnMasque(oMasqueVisible);
	}

	// Si on n'a pas toutes les lignes ou s'il y a des requetes en cours => L'affiche
	// !== pour le cas undefined au premier affichage
	if (bVisibleMasque !== this.m_bVisibleMasque)
	{
		clWDUtil.SetDisplay(oMasque, bVisibleMasque);
		this.m_bVisibleMasque = bVisibleMasque;
	}
	if (bVisibleMasqueTransparent !== this.m_bVisibleMasqueTransparent)
	{
		clWDUtil.SetDisplay(oMasqueTransparent, bVisibleMasqueTransparent);
		this.m_bVisibleMasqueTransparent = bVisibleMasqueTransparent;
	}

	// GP 25/10/2012 : Supprime le visibility : hidden de la g�n�ration
	// Uniquement au premier affichage
	if (bPremierAffichage)
	{
		this.m_oMasque.style.visibility = "";
		this.m_oMasqueTransparent.style.visibility = "";
	}
};

// Redimensionne les masques
WDTable.prototype.__RedimensionneUnMasque = function __RedimensionneUnMasque(oMasque)
{
	// En IE8-, la consultation des clientXxx/scrollXxx/offsetXxx declenche un appel de onscroll/onresize qui d�clenche des calculs erron�
	// (on n'est pas forc�ment correctement initialis� � ce point)
	try
	{
		this.m_bRedimensionneUnMasque = true;

		var oMasqueStyle = clWDUtil.oGetCurrentStyle(oMasque);
		var oMasqueParentNode = oMasque.parentNode;
		// GP 07/02/2014 : QW242390 : Ce code a des effets bizarres en IEQuirks : le d�sactive
		if (!bIEQuirks)
		{
			oMasque.style.height = "1px";
			var nHauteur = this._nGetOffsetHeight(oMasqueParentNode, oMasqueStyle);
			if (this.bGetSansLimiteStrict())
			{
				// GP 03/02/2014 : QW241949 : Bizarrement avec Chrome, ici, en mode sans limites, ont a une valeur invalide par _nGetOffsetHeight
				nHauteur = Math.min(nHauteur, oMasqueParentNode.scrollHeight);
			}

			// GP 16/01/2014 : C'est l'inverse, il faut supprimer la bordure en IEQuirks ?
			// Dans tous les cas c'est faux en chrome + HTML5
			oMasque.style.width = Math.max(this._nGetOffsetWidth(oMasqueParentNode, oMasqueStyle), 0) + "px";
			oMasque.style.height = Math.max(nHauteur, 0) + "px";

			if (this.bGetSansLimiteStrict())
			{
				// GP 03/02/2014 : QW241949 : Bizarrement avec Chrome, ici, en mode sans limites, ont a une valeur invalide par _nGetOffsetHeight
				var sPosition = oMasqueParentNode.style.position;
				oMasqueParentNode.style.position = "";
				// Lecture pour faire un reflow
				oMasqueParentNode.offsetHeight;
				oMasqueParentNode.style.position = sPosition;
			}
		}
		else
		{
			// Ancien code pour le mode IEQuirks
			oMasque.style.width = Math.max(this._nGetOffsetWidth(oMasqueParentNode, oMasqueStyle), 0) + "px";
			oMasque.style.height = Math.max(this._nGetOffsetHeight(oMasqueParentNode, oMasqueStyle), 0) + "px";
		}
	}
	finally
	{
		this.m_bRedimensionneUnMasque = false;
	}
};

// Notifie les champs qu'une ligne va etre masque
WDTable.prototype._MasqueLigneInterne = function _MasqueLigneInterne(nLigneAbsolue, bLigneSelectionnee, oEvent)
{
	this.m_tabChampsFils._AppelMethodePtr(WDChamp.prototype.OnLigneTableZRMasque, [nLigneAbsolue + 1, bLigneSelectionnee, oEvent]);
};

// Recupere les valeurs de la zone de l'ascenseur en tenant compte du facteur multiplicatif
WDTable.prototype.nGetAscenseurParentScrollTop = function()
{
	var oScrollTop = this.m_nAscenseurParentScrollTop ? this.m_nAscenseurParentScrollTop : this.m_oAscenseurParent.scrollTop;
	if (this.m_nFacteurAscenseur == 1)
	{
		// Si il n'y a pas de facteur multiplicatif, on retourne la valeur directement
		// Il y un cas particulier pour eviter les calculs abusifs et les division par zero dans le cas ou toutes les lignes sont visibles
		return oScrollTop;
	}
	else
	{
		// s = scrollTop, f = facteur multiplication, Nv = nombre de lignes visible, Nt = nombre de lignes total, h = hauteur d'une ligne
		// Pourquoi ?
		// ScrollTop * f est une bonne aproximation
		// Sauf que la zone ne defile que jusqu'a la hauteur visible de la zone (ScrollTop = HauteurTotale - HauteurVisible)
		// Cette zone depend de la table/ZR et ne TIENT pas compte du facteur multiplicatif ce qui fait que l'on ne peut scroller que jusqu'a (f - 1) page de la fin.
		// Donc il faut un facteur correctif pour tenir compte de cette hauteur.
		// Mais ce facteur commence a zero (il ne faut pas decaler de (f - 1) page en haut)
		// Donc (f - 1) est module par la position dans la table
		// En faut cette formule est factorisee et la valeur hauteur de ligne n'est pas prise en compte (calcule par l'appelant)
		// La formule originale est la suivante :
		//			  s * f   Nv * (f - 1) * s * f	 s * f		  Nv * (f - 1)
		// Position = ----- + -------------------- = ----- * (1 + ------------)
		//				h		 (Nt - Nv) * h		   h			Nt - Nv
		return oScrollTop * this.m_nFacteurAscenseur * (1 + this.m_nNbLignesPage * (this.m_nFacteurAscenseur - 1) / (this.m_nNbLignes - this.m_nNbLignesPage));
	}
};

// Affecte le deplacement de l'ascenseur en differe
WDTable.prototype.SetAscenseurParentScrollTop = function(fNouvellePositionSansCorrection, nNbLignesPageReel)
{

	// Cas general (pas de facteur multiplicatif)
	var fNouvellePosition = fNouvellePositionSansCorrection;
	if (this.m_nFacteurAscenseur > 1)
	{
		fNouvellePosition = fNouvellePositionSansCorrection / this.m_nFacteurAscenseur;
		fNouvellePosition *= 1 - nNbLignesPageReel * (this.m_nFacteurAscenseur - 1) / (this.m_nNbLignes - nNbLignesPageReel);
	}

	// Si la position change
	var nNouvellePosition = Math.max(Math.floor(fNouvellePosition), 0);
	// Gere le cas de deux appel en serie : utilisation de nSetTimeoutUnique et comparaison a la valeur memoriser
	var nAnciennePosition = (this.m_nAscenseurParentScrollTop !== undefined) ? this.m_nAscenseurParentScrollTop : this.m_oAscenseurParent.scrollTop;
	if (nAnciennePosition != nNouvellePosition)
	{
		this.m_nAscenseurParentScrollTop = nNouvellePosition;
//		this.nSetTimeoutUnique("SetAscenseurParentScrollTopCallBack", 500, nNouvellePosition);
		this.SetAscenseurParentScrollTopCallBack(nNouvellePosition);
	}
};

// Affecte le deplacement de l'ascenseur
WDTable.prototype.SetAscenseurParentScrollTopCallBack = function(nNouvellePosition)
{
	delete this.m_nAscenseurParentScrollTop;
	this.m_oAscenseurParent.scrollTop = nNouvellePosition;
};

// Invalide la valeur actuelle du d�bordement en largeur
WDTable.prototype._vInvalideDebordeLargeur = function _vInvalideDebordeLargeur()
{
	this.m_bDebordeLargeur = undefined;
};
// Lecture du d�bordement en largeur
WDTable.prototype._vbGetDebordeLargeur = function _vbGetDebordeLargeur()
{
	// Si la valeur a �t� invalid�, la recalcule
	if (undefined === this.m_bDebordeLargeur)
	{
		// GP 31/01/2014 : QW241837 : Probl�me de calcul faux en IE quirks : il suffit de lire deux fois la valeur pour avoir la bonne...
		// Donc avecc cette commande, le calcul de this.m_bDebordeLargeur devient correct
		if (bIEQuirks)
		{
			this.m_oDivPosParent.scrollWidth;
		}

		// Met a jour le flag de debordement en largeur
		this.m_bDebordeLargeur = (this.m_oDivPosParent.scrollWidth > this.m_oDivPosParent.clientWidth);

		// Probleme avec IE en mode auto : on force le mode scroll
		if (bIE && this.bGetSansLimite())
		{
			if (this.m_bDebordeLargeur)
			{
				if (this.m_oDivPosParent.style.overflowX == "auto")
				{
					this.m_oDivPosParent.style.overflowX = "scroll";
					// GP 31/01/2014 : Probl�me de reflow qui fausse le calcul en IE quirks : il faut revenir en arri�re ici si on n'a plus le d�bordement
					this.m_bDebordeLargeurIEForceScroll = true;
				}
			}
			else if (this.m_bDebordeLargeurIEForceScroll)
			{
				this.m_bDebordeLargeurIEForceScroll = false;
				this.m_oDivPosParent.style.overflowX = "auto";
			}
		}

		// GP 30/11/2016 : TB100039 : OPTIM : Si on a d�j� m_bDebordeLargeur � true, inutile de tenter de lire le style pour placer this.m_bDebordeLargeur � true
		if (!this.m_bDebordeLargeur)
		{
			// Si l'ascenseur horizontal a ete force : il faut en tenir compte
			if ((this.m_oDivPosParent.style.overflowX === "scroll") || (this.m_oDivPosParent.style.overflow === "scroll"))
			{
				this.m_bDebordeLargeur = true;
			}
		}

		// Pour les tables tout en m�moire fait aussi la synchro horizontale (elle n'est pas faite par le remplissage)
		if (this.m_oTitrePosPixel && this.bGetCacheCompletAscenseur())
		{
			// Fixe le margin de la zone de titre
			var nLargeurAscenseurVertical = this._nGetLargeurAscenseurVertical(this.m_oDivPosParent);
			var oTitrePosPixelParent = this.m_oTitrePosPixel.parentNode;

			// GP 21/01/2016 : QW267749 : Modifie la largeur du parent en cas d'ancrage horizontal (dans __MAJDivPosParentHauteur2 la largeur de l'ascenseur n'est pas encore disponible
			// GP 23/02/2016 : QW269772 : Il en faut faire la r�duction en largeur que une seule fois (on passe ici dans d'autres cas que le redimensionnement)
			if (this.m_bAncrageLargeur && !this.m_bTitrePosPixelParentLargeur_QW269772)
			{
				var sLargeur = oTitrePosPixelParent.style.width;
				if ("" != sLargeur)
				{
					var nLargeur = parseInt(sLargeur, 10);
					if (!isNaN(nLargeur))
					{
						this.__bAffecteProprieteSiValeurDefinie(oTitrePosPixelParent, "width", nLargeur, -nLargeurAscenseurVertical);
						this.m_bTitrePosPixelParentLargeur_QW269772 = true;
					}
				}
			}

			// GP 21/11/2013 : QW238685 : margin-right ne fonctionne pas, il faut manipuler le parent sur padding-right
			// GP 04/02/2014 : QW242234 : Sur le parent du parent pour les 100%
			oTitrePosPixelParent.parentNode.style.paddingRight = (nLargeurAscenseurVertical <= 0) ? "" : (nLargeurAscenseurVertical + "px");
		}
	}

	return this.m_bDebordeLargeur;
};

// Redimensionne l'ascenseur si besoin
WDTable.prototype.RedimAscenseur = function RedimAscenseur()
{
	clWDUtil.WDDebug.DebutFonction("RedimAscenseur");

	// D�j� fait avant car il existe aussi en mode sans limites
//	// Invalide la valeur actuelle du d�bordement en largeur
//	this._vInvalideDebordeLargeur();

	// Reduit le div de l'ascenseur vertical si besoin
	// GP 30/11/2012 : QW?????? : this.m_oAscenseurParent.parentNode.parentNode	 est un tr
	// div < td < tr
	// Avec IE en HTML5, son clientHeight est de 0
	// Pourquoi on ne prend pas le TD ? normalement il est de la m�me hauteur. Et lui a un clientHeight correct
	// GP 05/02/2014 : On a aussi un clientHeight de 0 dans certains cas avec IE en HTML5.
	var nClientHeight;
	// GP 25/04/2014 : QW244863 : Uniquement si on a un ancrage en hauteur
	if (bIEAvec11 && !clWDUtil.bHTML5 && this.m_bAncrageHauteur)
	{
		// GP 22/04/2014 : QW244359
		nClientHeight = this.m_oAscenseurParent.parentNode.parentNode.parentNode.clientHeight;
	}
	else
	{
		nClientHeight = this.m_oAscenseurParent.parentNode.clientHeight;
		if (this.__bAncrageTimer() && (0 === nClientHeight))
		{
			// GP 30/03/2015 : QW256697 : Probl�me de reflow avec IE avec ancrage en HTML5
			// Parfois, l'ascenseur et mal dessin�
			if (this.m_bAncrageHauteur)
			{
				var oParentParentParent = this.m_oAscenseurParent.parentNode.parentNode;
				var sPosition = oParentParentParent.style.position;
				if (sPosition == "relative")
				{
					oParentParentParent.style.position = "absolute";
					oParentParentParent.offsetHeight;
					oParentParentParent.style.position = sPosition;
				}
			}
			nClientHeight = this.m_oAscenseurParent.parentNode.offsetHeight;
			if (0 === nClientHeight)
			{
				nClientHeight = this.m_oAscenseurParent.parentNode.scrollHeight;
			}
		}
	}
	var nNouvelleHauteur = nClientHeight - this._nGetHauteurAscenseurHorizontal(this.m_oDivPosParent);
	// GP 05/02/2014 : QW241926 : Il faut tenir compte de la bordure de la cellule a cot� avec le contenu principal
	if (bIEAvec11 && clWDUtil.bHTML5)
	{
		nNouvelleHauteur -= this.s_nGetOffsetBorderPourWidth(clWDUtil.oGetCurrentStyle(this.m_oDivPosParent.parentNode));
	}

	// Si la hauteur est de z�ro, ignore lecalcul (probl�me de 100% avec IE)
	if (nNouvelleHauteur < 1)
	{
		if (bIEAvec11 && (this.m_oAscenseurParent.style.height != ""))
		{
			return;
		}
		nNouvelleHauteur = 1;
	}

	var sNouvelleHauteur = nNouvelleHauteur + "px";
	// On ne change pas la taille sinon cela deplace l'ascenseur
	if (this.m_oAscenseurParent.style.height != sNouvelleHauteur)
	{
		this.m_oAscenseurParent.style.height = sNouvelleHauteur;
		// GP 22/04/2014 : QW244359
		if (bIEAvec11 && !clWDUtil.bHTML5 && this.m_bAncrageHauteur)
		{
			this.m_oAscenseurParent.parentNode.style.height = sNouvelleHauteur;
		}
	}

	clWDUtil.WDDebug.FinFonction();
};

// Lit la hauteur de la ligne
// (on ne doit pas etre en mode sans limite)
WDTable.prototype.__nGetHauteurLigne = function __nGetHauteurLigne(nLigneAbsolue)
{
	return this.m_oCache.nGetHauteur(this, nLigneAbsolue);
};

// GP 30/10/2012 : Autre m�thode pour la premi�re en cas ou le cache n'est pas en phase si on force le d�filement
WDTable.prototype.__nGetHauteurPremiereLigne = function __nGetHauteurPremiereLigne()
{
	var oEtatLigne = this.oGetEtatLigne(0);
	if (oEtatLigne)
	{
		var oEtatLigneLogique = oEtatLigne.oGetLigneLogique(0);
		if (oEtatLigneLogique)
		{
			var oLigneCache = oEtatLigneLogique.m_oLigneCache;
			if (oLigneCache)
			{
				return oLigneCache.nGetHauteurDirect();
			}
		}
	}

	return -1;
};

// Position la zone de placement au pixel en tenant compte de la hauteur de la premiere ligne
WDTable.prototype.nGetDivPosTop = function nGetDivPosTop()
{
	// Recupere la valeur originale en conservant la partie decimale
	var sPos = this.m_oDivPos.style.top;
	if (0 === sPos.length)
	{
		return 0;
	}
	var fPos = parseFloat(sPos);

	// Si la table/ZR inclus des elements de hauteur variable
	if (this.bGetHauteurLigneVariable())
	{
		// Et que :
		// La hauteur de la premiere ligne est connue
		// Ce n'est pas la hauteur par defaut
		var nHauteurLigne = this.__nGetHauteurPremiereLigne();
		if ((nHauteurLigne != -1) && (nHauteurLigne != this.m_nHauteurLigne))
		{
			// Alors on calcul le deplacement original
			fPos = fPos * this.m_nHauteurLigne / nHauteurLigne;
		}
	}

	return parseInt(fPos, 10);
};

// Position la zone de placement au pixel en tenant compte de la hauteur de la premiere ligne
WDTable.prototype.SetDivPosTop = function SetDivPosTop(nPosition)
{
	var fPos = nPosition;
	// Si la table/ZR inclus des elements de hauteur variable
	if (this.bGetHauteurLigneVariable())
	{
		// Et que :
		// La hauteur de la premiere ligne est connue
		// Ce n'est pas la hauteur par defaut
		var nHauteurLigne = this.__nGetHauteurPremiereLigne();

		// GP 29/10/2012 : On a pas besoin de faire un calcul diff�r�
//		if (nHauteurLigne != -1)
//		{
//			if (nHauteurLigne != this.m_nHauteurLigne)
//			{
//				// Alors on calcul le deplacement original
//				fPos = fPos * nHauteurLigne / this.m_nHauteurLigne;
//			}
//		}
//		else
//		{
//			// La hauteur de la ligne est inconnue
//			// Declenche le calcul et la MAJ differee
//			this.nSetTimeoutUnique("CalculeHauteurLigne", clWDUtil.ms_oTimeoutImmediat, nPosition);
//		}

		if (-1 == nHauteurLigne)
		{
			// GP 29/10/2012 : On a pas besoin de faire un calcul diff�r�
			// La hauteur de la ligne est inconnue
			// Declenche le calcul
			this._bCalculeHauteurLigne();
			nHauteurLigne = this.__nGetHauteurPremiereLigne();
		}
		// GP 24/11/2013 : QW239663 : Ici ce n'est pas this.m_nHauteurLigne mais this.nGetLastHauteurLigneMoyenne()
		// En effet, lors des appels on a d�j� tenu compte de la hauteur de ligne moyenne dans le d�placement (et le scroll de la table en tient compte aussi
//		var nHauteurLigneMoyenne = this.m_nHauteurLigne;
		var nHauteurLigneMoyenne = this.nGetLastHauteurLigneMoyenne();
		// GP 30/03/2016 : QW270816 : Ajout de (nHauteurLigne != -1) comme dans nGetDivPosTop sinon si aucune des lignes n'est encore affich� (c'est le cas d'un scroll rapide) on utilise "-1"
		if ((nHauteurLigne != -1) && (nHauteurLigne != nHauteurLigneMoyenne))
		{
			// Alors on calcul le deplacement original
			fPos = fPos * nHauteurLigne / nHauteurLigneMoyenne;
		}
	}

	this.m_oDivPos.style.top = fPos + "px";
};

WDTable.prototype._vnGetOffset = function _vnGetOffset(oLignePhysique, bExact)
{
	// Si on est pas en "quirks mode", il faut tenir compte des bordure du parent si on est dans un table (pas de bordure dans les ZRs)
	if (!bIEQuirks)
	{
		// On ne prend que la bordure du bas car les bordures sont fusionnees
		// GP 30/04/2018 : TB103841 : Le calcul est faux :
		// - Il faut prendre le style (borderBottomWidth est sur le style).
		// - Cette bordure est sur les cellules et pas sur la ligne.
		// - Selon les navigateurs ont peut avoir une hauteur de 0.5px qui est fusionn� avec la ligne d'apr�s.
		// => Mais on ne change rien pour ne pas faire de r�gression sur le calcul du d�filement qui semble plus ou moins correct.
		// => On changera ici quand on aura un vrai bug sur les hauteurs de lignes
		if (bExact)
		{
			var tabCells = oLignePhysique.cells;
			if (tabCells && tabCells[0])
			{
				return Math.ceil(this.s_dGetOffset(clWDUtil.oGetCurrentStyle(tabCells[0]).borderBottomWidth));
			}
		}
		else
		{
			return Math.floor(this.s_dGetOffset(oLignePhysique.borderBottomWidth));
		}
	}
	return 0;
};

// Sur chaque redimensionnement des images on doit recalculer la hauteur des lignes !!!
WDTable.prototype._OnRedimImage = function _OnRedimImage(oEvent, oImage, oImageEtCellule)
{
	clWDUtil.WDDebug.assert(oImage == oImageEtCellule.m_oImage, "Image invalide");

	var tabImagesNonAffichee = this.m_tabImagesNonAffichee;

	// L'image n'est pas (encore) dans le HTML : en revanche son futur parent doit y �tre.
	// On d�tecte les image qui n'ont plus besoin d'�tre affich� au fait que leur parent n'est plus affich�
	var oCellule = oImageEtCellule.m_oCellule;
	if (!clWDUtil.bEstDansDocument(oCellule))
	{
		// Supprime l'image du tableau des images non affich�es
		clWDUtil.SupprimeDansTableau(tabImagesNonAffichee, oImageEtCellule);
		return;
	}

	// Regarde si le chargement de l'image est fini
	var sSrc = oImage.getAttribute("data-webdev-src-initial");
	// Tente une lecture dans le cache (pour le cas ou l'on a plusieurs fois la m�me image dans la page)
	var tabTailleImage = this.m_tabCacheTailleImage[sSrc];
	if (!tabTailleImage)
	{
		tabTailleImage = WDTableZRNavigateur.prototype.s_tabImageChargement(oImage);
	}
	if (null !== tabTailleImage)
	{
		// Si l'image n'est pas g�n�r� ajoute la taille dans le cache
		if (-1 === sSrc.indexOf("&IMAGE"))
		{
			this.m_tabCacheTailleImage[sSrc] = tabTailleImage;
		}
		// Oui le chargement de l'image est fini : dessin effectif de l'image
		WDTableZRNavigateur.prototype.__s_RedimImage(oImage, oCellule, tabTailleImage, true, false);

		// Et supprime l'image du tableau des images non affich�es
		clWDUtil.SupprimeDansTableau(tabImagesNonAffichee, oImageEtCellule);
	}

	// Recalcul de l'ascenseur
	this._OnAscenseurRedimImage();
};

// GP 22/11/2017 : TB103861 : Il faut aussi d�tecter les �chec sinon on n'affiche jamais l'ascenseur
WDTable.prototype._OnEchecChargementImage = function _OnEchecChargementImage(oEvent, oImage, oImageEtCellule)
{
	clWDUtil.WDDebug.assert(oImage === oImageEtCellule.m_oImage, "Image invalide");

	// Supprime l'image du tableau des images non affich�es
	clWDUtil.SupprimeDansTableau(this.m_tabImagesNonAffichee, oImageEtCellule);

	// Recalcul de l'ascenseur
	this._OnAscenseurRedimImage();
};

// Lance le timer de recalcul de l'ascenseur
WDTable.prototype._OnAscenseurRedimImage = function _OnAscenseurRedimImage()
{
	// GP 21/11/2013 : Et recalcule la hauteur des lignes si toutes les images sont affich�es
	// GP 12/12/2013 : Vu avec TB85121 : On on n'a pas d'ascenseur en nombre de lignes illimit�s
	// GP 05/02/2014 : QW242093 : On a aussi un calcul en hauteur de ligne fixe pour faire le redimensionnement
	if (!this.bGetSansLimite() && (0 === this.m_tabImagesNonAffichee.length))
	{
		// On a attendu trop longtemps l'affichage des images : fait un recalcul de l'ascenseur
		this.m_tabImagesNonAffichee = [];

		if (this.m_bHauteurLigneVariable)
		{
			this.MAJAscenseurRuptures(true, true);
		}
	}
};

// Calcule la hauteur des lignes visibles
WDTable.prototype._bCalculeHauteurLigne = function _bCalculeHauteurLigne(bRecalculeHauteur0, bRecalculeHauteurToujours)
{
	var bModifie = false;

	// Pour toutes les lignes affichees
	var i;
	var nLimiteI = this.m_oEtatLignes.nGetNbEtatLignes();
	for (i = 0; i < nLimiteI; i++)
	{
		// Si la ligne est visible
		var oEtatLigne = this.oGetEtatLigne(i);
		if (oEtatLigne.bPlein(0))
		{
			// Recupere sa hauteur et la fixe
			var oLigneCache = oEtatLigne.oGetLigneLogique(0).m_oLigneCache;
			var nHauteur = oLigneCache.nGetHauteurDirect();
			if ((-1 === nHauteur) || (bRecalculeHauteur0 && (0 === nHauteur)) || bRecalculeHauteurToujours)
			{
				// Fixe la hauteur
				bModifie |= oLigneCache.bSetHauteur(this.nCalculeHauteurLigne(oEtatLigne));
			}
		}
	}

	return bModifie;
};
// Calcule la hauteur d'une ligne
WDTable.prototype.nCalculeHauteurLigne = function nCalculeHauteurLigne(oEtatLigne)
{
	var nHauteurTotale = oEtatLigne.m_oLignePhysique.offsetHeight;

	// Si on est pas en "quirks mode", il faut tenir compte des bordure du parent si on est dans un table (pas de burdure dans les ZRs)
	nHauteurTotale += this._vnGetOffset(oEtatLigne.m_oLignePhysique, false);

	// Il faut aussi tenir compte de la hauteur des ruptures
	nHauteurTotale += this._nCalculeHauteurRupturesLigne(oEtatLigne);

	return nHauteurTotale;
};
// Calcule la hauteur des ruptures dans une ligne
WDTable.prototype._nCalculeHauteurRupturesLigne = function _nCalculeHauteurRupturesLigne(oEtatLigne)
{
	var nHauteurRuptures = 0;
	if (this.nGetNbRuptures() > 0)
	{
		// La rupture n'existe pas toujours (colonne autre que la premiere pour le haut)
		if (oEtatLigne.m_oRupturesHaut)
		{
			nHauteurRuptures += oEtatLigne.m_oRupturesHaut.parentNode.offsetHeight;
		}
		if (oEtatLigne.m_oRupturesBas)
		{
			nHauteurRuptures += oEtatLigne.m_oRupturesBas.parentNode.offsetHeight;
		}
	}

	return nHauteurRuptures;
};

//// Callback pour calculer la hauteur des lignes visibles
//WDTable.prototype.CalculeHauteurLigne = function CalculeHauteurLigne(nPosition)
//{
//	this._bCalculeHauteurLigne();
//	// Reforce le positionnement de l'affichage
//	this.SetDivPosTop(nPosition);
//};

// Recupere la dernier hauteur de ligne
WDTable.prototype.nGetLastHauteurLigneMoyenne = function nGetLastHauteurLigneMoyenne()
{
	return this.m_nLastHauteurLigneMoyenne ? this.m_nLastHauteurLigneMoyenne : this.m_nHauteurLigne;
};

WDTable.prototype.nGetLastNbLignesLogiquesParLignePhysiqueMoyen = function nGetLastNbLignesLogiquesParLignePhysiqueMoyen()
{
	return this.m_nLastNbLignesLogiquesParLignePhysiqueMoyen ? this.m_nLastNbLignesLogiquesParLignePhysiqueMoyen : this.vnGetNbLignesLogiquesParLignePhysique();
};

// Calcule la hauteur moyenne des lignes affichees
WDTable.prototype.nGetHauteurLigneMoyenne = function nGetHauteurLigneMoyenne()
{
	if (this.bGetHauteurLigneVariable())
	{
		var nHauteurLigneTotale = 0;
		var nHauteurLigneNb = 0;
		var i;
		var nLimiteI = this.m_oEtatLignes.nGetNbEtatLignes();
		for (i = 0; i < nLimiteI; i++)
		{
			var oEtatLigne = this.oGetEtatLigne(i);
			if (oEtatLigne.oGetLigneLogique(0).m_oLigneCache)
			{
				var nHauteurLigne = oEtatLigne.oGetLigneLogique(0).m_oLigneCache.nGetHauteurDirect();
				if (nHauteurLigne && nHauteurLigne > 0)
				{
					nHauteurLigneTotale += nHauteurLigne;
					nHauteurLigneNb++;
				}
			}
		}
		if (nHauteurLigneNb > 0)
		{
			// Quand on a des ruptures, la hauteur de ligne moyenne est inferieure...
			return Math.ceil(nHauteurLigneTotale / nHauteurLigneNb);
		}
		else
		{
			// Si on a une ancienne hauteur de ligne moyenne, l'utilise pour que l'ascenseur ne joue pas au yoyo
			if (this.m_nLastHauteurLigneMoyenne && (this.m_nLastHauteurLigneMoyenne > 0))
			{
				return this.m_nLastHauteurLigneMoyenne;
			}
		}
	}
	// Autres cas (hauteur non variable ou valeur incalculable
	return this.m_nHauteurLigne;
};

// Calcule le nombre de ligne logique par ligne physique moyen
WDTable.prototype.nGetNbLignesLogiquesParLignePhysiqueMoyen = function nGetNbLignesLogiquesParLignePhysiqueMoyen()
{
	var nGetNbLignesLogiquesParLignePhysique = this.vnGetNbLignesLogiquesParLignePhysique();

	if (this.nGetNbRuptures() > 0)
	{
		var nLigneLogiqueTotale = 0;
		var nLignePhysique = 0;
		var i;
		var nLimiteI = this.m_oEtatLignes.nGetNbEtatLignes();
		for (i = 0; i < nLimiteI; i++)
		{
			var oEtatLigne = this.oGetEtatLigne(i);
			// Parcours les lignes logiques
			var j;
			var nLimiteJ = nGetNbLignesLogiquesParLignePhysique;
			for (j = 0; j < nLimiteJ; j++)
			{
				if (oEtatLigne.bPlein(j))
				{
					// Si c'est la premiere colonne compte la ligne
					if (0 === j)
					{
						nLignePhysique++;
					}
					// Compte la colonne
					nLigneLogiqueTotale++;
				}
			}
		}
		if (nLignePhysique > 0)
		{
			return Math.min(nLigneLogiqueTotale / nLignePhysique, nGetNbLignesLogiquesParLignePhysique);
		}
		else
		{
			return nGetNbLignesLogiquesParLignePhysique;
		}
	}
	else
	{
		// Si on n'a pas de rupture le calcul est simple
		return nGetNbLignesLogiquesParLignePhysique;
	}
};

// Met a jour la bare de defilement et les lignes visible a l'ecran pour les ruptures
WDTable.prototype.MAJAscenseurRuptures = function MAJAscenseurRuptures(bRecalculeHauteur0, bRecalculeHauteurToujours)
{
	// Sauf si on a encore des images a afficher
	if (0 === this.m_tabImagesNonAffichee.length)
	{
		// Calcule la hauteur des lignes
		if (this._bCalculeHauteurLigne(bRecalculeHauteur0, bRecalculeHauteurToujours))
		{
			// MAJ de l'ascenseur
			this.MAJAscenseur();
		}
	}
};

// Met a jour la bare de defilement et les lignes visible a l'ecran
WDTable.prototype.MAJAscenseur = function MAJAscenseur(bForceMAJ, bDepuisDeplaceTable)
{
	clWDUtil.WDDebug.DebutFonction("MAJAscenseur");

	// Invalide la valeur actuelle du d�bordement en largeur
	this._vInvalideDebordeLargeur();

	// Redimensionne l'ascenseur si besoin
	this.RedimAscenseur();

	// Si on force alors on place la ligne au debut
	if (bForceMAJ)
	{
		this.SetDivPosTop(0);
	}

	// Force le zero deplacement au parent de la position au pixel
	this.m_oDivPosParent.scrollTop = "0px";

	// Calcule la hauteur moyenne des lignes affichees
	var nHauteurLigneMoyenne = this.nGetHauteurLigneMoyenne();

	// On calcule la nouvelle hauteur si besoin
	// Si on a plus d'une logique par ligne physique, il faut en tenir compte pour afficher entierement la derniere ligne
	var nNouvelleHauteur;
	var nNbLignesLogiquesParLignePhysiqueMoyen = this.nGetNbLignesLogiquesParLignePhysiqueMoyen();
	if (nNbLignesLogiquesParLignePhysiqueMoyen > 1)
	{
		nNouvelleHauteur = Math.floor(nHauteurLigneMoyenne * Math.ceil(this.m_nNbLignes / nNbLignesLogiquesParLignePhysiqueMoyen));
	}
	else
	{
		nNouvelleHauteur = Math.floor(nHauteurLigneMoyenne * this.m_nNbLignes);
	}
	// Si zero ligne ou probleme de nombre de lignes
	if (nNouvelleHauteur <= 0)
	{
		nNouvelleHauteur = 1;
	}
	// Si la nouvelle hauteur est trop importante pour le navigateur : on utilise un facteur d'echelle
	this.m_nFacteurAscenseur = Math.ceil(nNouvelleHauteur / this.m_nLimiteHauteur);
	if (this.m_nFacteurAscenseur > 1)
	{
		nNouvelleHauteur = Math.floor(nNouvelleHauteur / this.m_nFacteurAscenseur);
	}

	// Deplace eventuellement la table si besoin (En cas de fichier raccourci)
	var nDebut;
	var nNbLignesPageReel = (nHauteurLigneMoyenne === this.m_nHauteurLigne) ? this.m_nNbLignesPage : this.__nNbLignesPage(nHauteurLigneMoyenne);
	if ((this.m_nDebut > 0) && (this.m_nNbLignes - this.m_nDebut < nNbLignesPageReel))
	{
		// Calcule le debut exact en tenant compte des lignes avec rupture en base
		nDebut = this.m_nNbLignes - nNbLignesPageReel;
		if (nDebut < 0)
		{
			nDebut = 0;
			// Les hauteurs de lignes ont put deplacer l'ascenseur
			this.SetAscenseurParentScrollTop(0, nNbLignesPageReel);
		}
		this.SetDebut(nDebut);
	}

	// On change la hauteur si besoin
	var nHauteurAscenseur = parseInt(this.m_oAscenseur.style.height, 10);
	if ((nHauteurAscenseur != nNouvelleHauteur) || bForceMAJ)
	{
		// Calcule si on doit MAJ la position
		var nDivPosTop = this.nGetDivPosTop();
		var bSetAscenseurParentScrollTop = (Math.floor(((this.m_oAscenseurParent.scrollTop * this.m_nFacteurAscenseur) - nDivPosTop) / nHauteurLigneMoyenne) != this.m_nDebut) || bForceMAJ;

		// GP 18/03/2013 : GP ici avant car si on a jout� une ligne on scrolle "apr�s la fin" car on n'a pas encore agrandit l'ascenseur
		this.m_oAscenseur.style.height = nNouvelleHauteur + "px";

		if (bSetAscenseurParentScrollTop)
		{
			// On ne tient plus compte du facteur de correction c'est integre dans SetAscenseurParentScrollTop
			// De meme que le fait de derterminer si la position change
			// Defini la position de la scroll bar en fonction du debut
			var fNouvellePosition = (this.m_nDebut / nNbLignesLogiquesParLignePhysiqueMoyen) * nHauteurLigneMoyenne + nDivPosTop;
			this.SetAscenseurParentScrollTop(fNouvellePosition, nNbLignesPageReel);
		}
		// GP 18/03/2013 : GP d�plac� avant car si on a jout� une ligne on scrolle "apr�s la fin" car on n'a pas encore agrandit l'ascenseur
//		this.m_oAscenseur.style.height = nNouvelleHauteur + "px";
	}
	this.m_nLastHauteurLigneMoyenne = nHauteurLigneMoyenne;
	this.m_nLastNbLignesLogiquesParLignePhysiqueMoyen = nNbLignesLogiquesParLignePhysiqueMoyen;

	// Et met si besoin l'evenement sur le scrolling
	if (!this.m_oAscenseurParent.onscroll)
	{
		this.m_oAscenseurParent.onscroll = this.m_fScroll;
	}

	if (!bDepuisDeplaceTable && (undefined != nDebut))
	{
		// Deplace la table => Provoque un rappel a nous meme mais comme on s'est modifie pour ne plus verifier notre condition
		// Pas plus de un appel recursif
		this.DeplaceTable(undefined, nDebut);
	}

	clWDUtil.WDDebug.FinFonction();
};

// Calcule le nouveau debut logique de la page
WDTable.prototype.nGetDebutLogique = function nGetDebutLogique(nDebutPhysique)
{
	// Effectue le calcul avec une simple regle de trois
	// C'est la valeur resultat si on n'a pas de ruptures ou que le calcule echoue
	var nDebutLogique = nDebutPhysique * this.nGetLastNbLignesLogiquesParLignePhysiqueMoyen();

	// Si on a des ruptures, tente de calculer la vrai premiere ligne en fonction de la derniere premiere ligne connue
	if (this.nGetNbRuptures() > 0)
	{
		// Parcours les lignes logiques depuis le debut actuel tant que l'on n'est pas sur le debut de la ligne physique
		var nLigneAbsolue = this.m_nDebut;
		var oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
		if (oLigneCache)
		{
			var nSens = nDebutPhysique > oLigneCache.vnGetLigneHTML() ? 1 : -1;
			while ((nLigneAbsolue >= 0) && (nLigneAbsolue < this.m_nNbLignes))
			{
				if (!oLigneCache)
				{
					// On n'a pas la ligne, prend la ligne calculee
					break;
				}
				// Si on est sur la bonne ligne
				if ((oLigneCache.vnGetLigneHTML() == nDebutPhysique) && (0 === oLigneCache.vnGetColonneHTML()))
				{
					// Memorise le resultat
					nDebutLogique = nLigneAbsolue;
					break;
				}
				// On n'est pas sur la bonne ligne
				// Continue la recherche
				nLigneAbsolue += nSens;

				// Recupere la ligne suivante
				oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
			}
		}
	}

	return nDebutLogique;
};

// Deplacement de la table
WDTable.prototype.DeplaceTable = function DeplaceTable(oEvent, nDebut)
{
	// Finie la saisie si besoin
	if (this.m_oCelluleSaisie && this.m_oCelluleSaisie.bSaisieEnCours())
	{
		this.m_oCelluleSaisie.SaisieFin(true, false, undefined, oEvent);
	}

	// Force le zero deplacement au parent de la position au pixel
	this.m_oDivPosParent.scrollTop = "0px";

	var nAscenseurParentScrollTop = this.nGetAscenseurParentScrollTop();

	// Defini la position du debut en fonction de l'ascenseur
	var nNouveauDebutPhysique = Math.floor(nAscenseurParentScrollTop / this.nGetLastHauteurLigneMoyenne());

	// Calcule le nouveau debut logique de la page

	// Recupere le debut en ligne logique et pas en ligne physique
	var nNouveauDebutLogique = this.nGetDebutLogique(nNouveauDebutPhysique);

	// Si on n'a pas bouger : fini
	if (nNouveauDebutLogique === this.m_nDebut)
	{
		// Deplace au pixel le div de la table
		this.SetDivPosTop(Math.floor((nNouveauDebutPhysique * this.nGetLastHauteurLigneMoyenne()) - nAscenseurParentScrollTop));

		// Si on n'est pas en d�placement forc�
		if (undefined === nDebut)
		{
			return;
		}
	}

	// Si la ligne selectionnee est DANS la zone deplacee, on la notifie
	if ((0 < this.m_tabSelection.length) && (-1 !== this.m_tabSelection[0].m_nLigne))
	{
		// GP 27/03/2018 : TB108030 (suite de TB107971/TB107974) : L'appel de nPosAbsolue2PosVisible me semble faux. le num�ro de ligne � utiliser est bien le vrai num�ro de ligne.
		this._MasqueLigneInterne(this.m_tabSelection[0].m_nLigne, true, oEvent);
	}

	// Sinon defini de debut
	this.SetDebut(nNouveauDebutLogique);

	// Invalide les lignes et les reaffiche si elles sont disponible
	var bAfficheMasque = false;
	var i;
	var nLimiteI = this.m_oEtatLignes.nGetNbEtatLignes();
	var nLimiteJ = this.vnGetNbLignesLogiquesParLignePhysique();
	var nLigneAbsolue = this.m_nDebut;
	var oLigneCache;
	for (i = 0; (i < nLimiteI) && (nLigneAbsolue < this.m_nNbLignes); i++)
	{
		// Recupere la ligne
		var oEtatLigne = this.oGetEtatLigne(i);

		// Parcours les lignes logiques
		// Sur la premiere cellule il y a forcement du contenu
		for (var j = 0; (j < nLimiteJ) && (nLigneAbsolue < this.m_nNbLignes); j++, nLigneAbsolue++)
		{
			// Affiche la ligne
			oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
			if (oLigneCache)
			{
				// Si on change de ligne (rupture)
				if (oLigneCache.vnGetColonneHTML() != j)
				{
					for (; j < nLimiteJ; j++)
					{
						oEtatLigne.MasqueLigne(j, this, nLigneAbsolue, oEvent);
					}
					break;
				}
			}

			// GP 03/05/2016 : OPTIM : Ce code n'est fait que pour avoir une id�e de ce qui est affich� et pour le cas ou l'on demande du cache.
			// => Ne fait pas le bMAJ dans un premier temps.
//			oEtatLigne.bMAJ(j, oLigneCache, this, nLigneAbsolue, oEvent, this.vbLigneEstSelectionneeSansZR(nLigneAbsolue));
			// Tout ce calcul reviens a �valuer oLigneCache car bPlein est a vrai si on a un m_oLigneCache dans la cellule j.
			// => C'est ce que l'on viens de fixer ci dessous dans le bMAJ.
//			var bPlein = oEtatLigne.bPlein(j);
//			// Et si on a pas la ligne on le note pour redemander les valeurs
//			bAfficheMasque = bAfficheMasque || ((!bPlein) && !oLigneCache);
			bAfficheMasque = bAfficheMasque || (!oLigneCache);
		}
	}
	// Masque les lignes restantes dans le cas (rare) ou l'ascenseur est faux (grandes variations locale de la hauteur des lignes)
	this.m_oEtatLignes.Invalide(this, -1, i + 1, true, oEvent);

	// Affiche le masque si besoin
	this.AfficheMasque(bAfficheMasque, false);

	// Vide le cache invalide
	this.m_oCache.SupprimeLignesInutiles(this);

	// Annule un precedent SetTimeout si besoin
	this.AnnuleTimeXXX("RemplitCacheDiff", false);

	// Si le cache est vide => C'est que l'on a un gros deplacement
	// => Effectue une requete differe pour ne pas en faire 50
	if (-1 === this.m_oCache.m_nDebutCache)
	{
		// Et lance la requete en differe (300ms)
		this.nSetTimeoutUnique("RemplitCacheDiff", 300);
	}
	else
	{
		// Si besoin demande du cache
		this.m_oCache.bRemplitCache(this, false, -1, this.m_bTriCroissant);
	}

	// Et met a jour l'affichage
	this.bMAJLignes(oEvent);

	// GP 07/12/2012 : TB68591 : Si on est en bas force un recalcul des hauteur pour �tre bien positionn�
	if (this.bGetHauteurLigneVariable())
	{
		var nScrollHeight = this.m_oAscenseurParent.scrollHeight;
		var nClientHeight = this.m_oAscenseurParent.clientHeight;
		if ((nClientHeight < nScrollHeight) && (nScrollHeight <= (this.m_oAscenseurParent.scrollTop + nClientHeight)))
		{
			// Met a jour la Ascenseur
			// Second param�tre � true : obligatoire sinon on a une r�cursion infinie...
			this.MAJAscenseur(false, true);
		}
	}

	// Code deplace APRES l'appel de SetDebut et le remplissage des lignes pour avoir lenouveau debut et les lignes affichees
	// Deplace au pixel le div de la table
	this.SetDivPosTop(Math.floor((nNouveauDebutPhysique * this.nGetLastHauteurLigneMoyenne()) - this.nGetAscenseurParentScrollTop()));
};

// Fonction de requete differee
WDTable.prototype.RemplitCacheDiff = function()
{
	// Demande du cache
	this.m_oCache.bRemplitCache(this, false);
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis le HTML

// Gestion du redimensionnement d'une colonne : appel lors du onmousedown
WDTable.prototype.OnRedimCol = function OnRedimCol(oEvent, nColonne, nLargeurMinimale)
{
	// Appel notre gestionnaire de redimensionnement
	this.m_oAffichageColonnes.bOnMouseDown(oEvent, nColonne, nLargeurMinimale);
};

// Lien sur une colonne lien
// GP 02/03/2015 : TB93683 : Comme TB91448 : Le num�ro de ligne n'est pas un num�ro de ligne absolue mais un num�ro de ligne visible
//WDTable.prototype.OnColonneLien = function OnColonneLien(nLigneAbsolue, nColonne, oEvent)
WDTable.prototype.OnColonneLien = function OnColonneLien(nLigneVisible, nColonne, oEvent)
{
	// Pour l'instant : rebondi sur la selection simple de ligne
	var nLignePosAbsolue = this.nPosVisible2PosAbsolue(nLigneVisible);
	this._OnSelectLigneAbsolue(nLignePosAbsolue, nColonne, oEvent, true);
};

// Actualise l'affichage du tri de colonne
// Force le defilement de la ZR
// Renvoi le deplacement reel
// Click sur une ligne
WDTable.prototype.OnSelectLigne = function OnSelectLigne(nLigneRelative, nColonne, oEvent)
{
	// Si on est en saisie dans cette colonne
	if (this.m_oCelluleSaisie && this.m_oCelluleSaisie.bSaisieEnCoursDansCellule(nLigneRelative, nColonne))
	{
		return;
	}

	// GP 05/11/2014 : QW251178 : Il semble que l'appel correct est nRelative2Visible2Absolue
	var nLigneVisible = this.nRelative2Visible(nLigneRelative);
	var nLignePosAbsolue = this.nPosVisible2PosAbsolue(nLigneVisible);
	this._OnSelectLigne(nLigneRelative, nLigneVisible, nLignePosAbsolue, nColonne, oEvent, false);
};
WDTable.prototype._OnSelectLigneAbsolue = function _OnSelectLigneAbsolue(nLignePosAbsolue, nColonne, oEvent, bColonneLien)
{
	// GP 13/11/2014 : QW251318 : On a besoin des trois valeurs
	var nLigneVisible = this.nPosAbsolue2PosVisible(nLignePosAbsolue);
	var nLigneRelative = this.nVisible2Relative(nLigneVisible);
	this._OnSelectLigne(nLigneRelative, nLigneVisible, nLignePosAbsolue, nColonne, oEvent, bColonneLien);
};
// GP 13/11/2014 : QW251318 : On a besoin des trois valeurs
// nLigneRelative : Ligne en comptant a l'�cran
// nLigneVisible : Ligne en comptant depuis le d�but du cache
// nLignePosAbsolue : Num�ro de ligne absolu en comptant toutes les lignes
WDTable.prototype._OnSelectLigne = function _OnSelectLigne(nLigneRelative, nLigneVisible, nLignePosAbsolue, nColonne, oEvent, bColonneLien)
{
	// GP 23/05/2016 : TB97877 : On autorise la saisie sans s�lection si la colonne est saisissable
	if ((WDSelection.prototype.ms_nSelectionSans === this.veGetModeSelection()) && !this.vbSaisieSansSelection(nColonne))
	{
		return;
	}

	// Si on a une requete en cours : la modification de la selection va etre ecrase donc on l'interdit
	if (this.m_oCache.m_tabRequetes.length > 0)
	{
		return;
	}

	// Si on a bloquer la s�lection
	if (this.m_bBloqueClickSurLigne)
	{
		delete this.m_bBloqueClickSurLigne;
		return;
	}

	// Si la ligne n'est pas dans le cache (on affiche des lignes vide en fin de table maintenant)
	// GP 13/11/2014 : QW251318 : Il faut utiliser nLigneVisible et pas nLignePosAbsolue
	if (this.m_nNbLignes <= nLigneVisible)
	{
		return;
	}

	var bCtrl = oEvent && !bColonneLien && oEvent.ctrlKey;
	var bShift = oEvent && !bColonneLien && oEvent.shiftKey;

	var bChangementSelection = false;
	// GP 23/02/2016 : TB89890 : On ne refuse pas la "s�lection" dans une table sans s�lection, on ne l'affiche juste pas
	var bSelectionSimple = bColonneLien || (WDSelection.prototype.ms_nSelectionMultiple !== this.veGetModeSelection());

	// Si on est en selection simple ou que ctrl et shift ne sont pas enfonce (Selection multiple): supprime les autres selections
	// Sauf la ligne en cours de selection car elle doit rester selectionnee
	if (bSelectionSimple || (!bCtrl && !bShift))
	{
		bChangementSelection = this.bLigneDeselectionneTous(nLignePosAbsolue, nColonne, oEvent);
	}
	// GP 09/01/2014 : QW241165 : Non car sinon on ne peut pas cliquer dans la colonne voisine + d�j� filtr�e avec bSaisieEnCoursDansCellule
	//	// Si on est en saisie et que la selection ne change pas : fin
	//	if (!bChangementSelection && this.m_oCelluleSaisie && this.m_oCelluleSaisie.bSaisieEnCours())
	//	{
	//		return;
	//	}

	// Regarde si la ligne est selectionne
	var nRang;
	// Decide si on va deselectionne la ligne si elle est selectionne
	if (clWDUtil.nElementInconnu !== (nRang = this.nLigneSelectionne(nLignePosAbsolue, nColonne, oEvent)))
	{
		// bCtrl est a faux si la colonne est lien donc c'est OK
		if (bCtrl)
		{
			// Deselectionne la ligne
			bChangementSelection = this.bLigneDeselectionne(nRang, oEvent);
		}
		// Et reselection de la la ligne si la colonne est lien
		if (bColonneLien)
		{
			bChangementSelection = this._bLigneSelectionne(nLignePosAbsolue, nLigneVisible, nColonne, true, oEvent);
		}
	}
	else
	{
		// Dans le cas de la selection multiple on traite les touches shift et Ctrl
		// Ctrl => Rien a faire on ajoute simplement a la selection
		// Shift => On ajoute tout entre la premiere selectionne si elle existe et la nouvelle
		// GP 17/10/2013 : @@@ Ce n'est pas derni�re s�lectionn�e plutot ?
		if (!bSelectionSimple && bShift && this.m_tabSelection.length)
		{
			// GP 06/10/2015 : TB94643 : Il y a un probl�me suite � la correction de WDTableCache.prototype.nPosVisible2PosAbsolue pour QW251211
			// Ici on passe de la ligne absolue � la ligne visible pour les bornes et ensuite on repasse � la ligne absolue pour les valeur dans l'intervalle
			// Sauf que si les ligne ne sont pas dans le cache WDTableCache.prototype.nPosVisible2PosAbsolue retourne -1 lors de cette derni�re conversion.
			// => Ecriture du code pour utiliser les num�ros de ligne en position absolues
			// Pile :
			// WDTableCache.prototype.nPosVisible2PosAbsolue
			// WDTable.prototype.nPosVisible2PosAbsolue
			// WDTable.prototype.__bLigneSelectionnePosVisible
			// WDTable.prototype._OnSelectLigne
//			var nSelection = this.nPosAbsolue2PosVisible(this.m_tabSelection[0]);
//			var nLigneAbsolue = this.nPosAbsolue2PosVisible(nLignePosAbsolue);
//			var nSens = (nSelection < nLignePosAbsolue) ? 1 : -1;
//			for (nSelection += nSens; nSelection != nLigneAbsolue; nSelection += nSens)
//			{
//				// Selectionne les lignes si besoin
//				bChangementSelection |= this.__bLigneSelectionnePosVisible(nSelection, nColonne, true, oEvent);
//			}
			var nSelectionLigne = this.m_tabSelection[0].m_nLigne;
			var nSens = (nSelectionLigne < nLignePosAbsolue) ? 1 : -1;
			for (nSelectionLigne += nSens; nSelectionLigne !== nLignePosAbsolue; nSelectionLigne += nSens)
			{
				// Selectionne les lignes si besoin
				bChangementSelection |= this._bLigneSelectionne(nSelectionLigne, this.nPosAbsolue2PosVisible(nSelectionLigne), nColonne, true, oEvent);
			}
		}

		// Selectionne la ligne
		// (si on est pass� dans le cas "shift", on n'a pas s�lectionn�e la ligne (test !=) et sinon on n'a pas s�lectionn�e la ligne
		bChangementSelection |= this._bLigneSelectionne(nLignePosAbsolue, nLigneVisible, nColonne, true, oEvent);
	}

	// Gere une eventuelle entree en saisie dans la ligne
	if (this.m_oCelluleSaisie)
	{
		this.m_oCelluleSaisie.OnClickCellule(nLigneRelative, nColonne, bChangementSelection, oEvent);
	}

	// Envoie une requete au serveur demandant le refraichissement de la ligne donnee si il y a eu une nouvelle selection
	if ((bChangementSelection || bColonneLien) && (this.m_bRetourServeurSelection))
	{
		this.RequeteSelection(bColonneLien ? nColonne : -1);
	}
};

// Gestionnaire du tri des colonnes
WDTable.prototype.OnTriColonne = function OnTriColonne(nColonne, oEvent)
{
	var bTriCroissant;
	if (nColonne == this.m_nColonneTrie)
	{
		// Si la colonne �tait d�j� la colonne tri�e, on inverse sont sens de tri
		bTriCroissant = !this.m_bTriCroissant;
	}
	else
	{
		// Sinon on fait un tri croissant
		bTriCroissant = true
	}

	// Affiche le picto dans la colonne de tri
	this.__TriColonne(nColonne, bTriCroissant);

	// Lance une requete pour le tri en bloquant l'affichage
	// Ici nColonne == this.m_nColonneTrie et bTriCroissant == this.m_bTriCroissant
	this.m_oCache.bRemplitCache(this, false, nColonne, bTriCroissant, true);

	this.__InvalidePourTRF(oEvent);
};

WDTable.prototype.__TriColonne = function __TriColonne(nColonne, bTriCroissant)
{
	var nColonneTriePrecedente = this.m_nColonneTrie;

	// Memorise notre colonne comme trie
	this.m_nColonneTrie = nColonne;
	this.m_bTriCroissant = bTriCroissant;

	// GP 29/10/2013 : QW238105 : this.m_oPopupSaisieTRF n'existe que dans les tables, pas dans les ZRs
	if (this.m_oPopupSaisieTRF)
	{
		// Change l'image de la colonne pr�c�dente (qui n'est plus tri�e)
		if ((-1 != nColonneTriePrecedente) && (nColonne != nColonneTriePrecedente))
		{
			this.m_oPopupSaisieTRF.AfficheImageTri(nColonneTriePrecedente, undefined);
		}
		// Change l'image de la colonne nouvellement tri�e
		this.m_oPopupSaisieTRF.AfficheImageTri(nColonne, bTriCroissant);
	}
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis WDPopupSaisieTRF

// Lance la recherche sur une colonne
// Impl�ment� dans WDTable et WDTableNavigateur
WDTable.prototype.OnRecherche = function OnRecherche(oEvent, nColonne, sValeur)
{
	this.m_oCache.CreeRequeteRecherche(this, nColonne, sValeur);

	this.__InvalidePourTRF(oEvent);
};

// Lance le filtrage sur une colonne
WDTable.prototype.OnFiltre = function OnFiltre(oEvent, nColonne, nFiltre, sValeur)
{
	this.m_tabFiltres[nColonne] = sValeur;
	this.m_oCache.CreeRequeteFiltre(this, nColonne, nFiltre, sValeur);

	this.__InvalidePourTRF(oEvent);
};

// Annule le filtre
WDTable.prototype.OnAnnuleFiltre = function OnAnnuleFiltre(oEvent, nColonne)
{
	this.m_tabFiltres[nColonne] = undefined;

	// Cr�e une requ�te d'annulation du filtre
	this.m_oCache.CreeRequeteAnnuleFiltre(this, nColonne);

	this.__InvalidePourTRF(oEvent);
};

// Indique le filtre sur la colonne
WDTable.prototype.sGetFiltrePourColonne = function (nColonne)
{
	return this.m_tabFiltres[nColonne] || "";
};

WDTable.prototype._oGetColonne = function _oGetColonne(nColonne)
{
	return this.m_tabColonnes[nColonne];
};

// Invalide la table pour le tri, la recherche ou le filtre
WDTable.prototype.__InvalidePourTRF = function __InvalidePourTRF(oEvent)
{
	// Marque toutes les lignes comme invalide
	this.m_oEtatLignes.Invalide(this, this.m_nDebut, 0, false, oEvent);
	// Et affiche le masque qui empeche la saisie
	this.AfficheMasque(true, true);
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis WDCelluleSaisie/WDCelluleAJAXSaisie

// Indique le type de la colonne
WDTable.prototype.eColonneTypeIDObjet = function eColonneTypeIDObjet(nColonne)
{
	// Sinon on renvoie la valeur dans le tableau
	return this._oGetColonne(nColonne).m_eTypeIDObjet;
};

// Indique si la colonne donnee est saisissable
WDTable.prototype.bColonneSaisissable = function bColonneSaisissable(nColonne)
{
	// Si la colonne n'est pas dans le tableau => Pas saisissable
	if ((nColonne >= this.m_tabColonnes.length) || (nColonne < 0))
	{
		return false;
	}

	// Sinon on renvoie la valeur dans le tableau
	return this.m_tabColonnes[nColonne].bGetSaisissable();
};

// Si la hauteur des lignes est variable, on prend la hauteur effective de la ligne
WDTable.prototype.nGetHauteurLigneRel = function nGetHauteurLigneRel(nLigneRelative, bSansRupture, bInterne)
{
	var nHauteurLigne = -1;
	var oEtatLigne = this.oGetEtatLigne(nLigneRelative);
	if (this.bGetHauteurLigneVariable())
	{
		if (this.bGetSansLimite())
		{
			// Recupere la hauteur de la ligne depuis le debut
			// En mode sans limite ligne relative <=> ligne absolue
			nHauteurLigne = oEtatLigne.m_oLignePhysique.offsetHeight + this._vnGetOffset(oEtatLigne.m_oLignePhysique, false);
		}
		else
		{
			// Retourne -1 si la hauteur de la ligne est inconnue
			var nLigneAbsolue = this.nRelative2Visible(nLigneRelative);
			nHauteurLigne = this.__nGetHauteurLigne(nLigneAbsolue);
			if ((-1 != nHauteurLigne) && bSansRupture)
			{
				// GP 21/07/2017 : TB104084 : C'est bien �videment nLigneRelative qu'il faut utiliser et pas nLigneAbsolue
				nHauteurLigne -= this._nCalculeHauteurRupturesLigne(this.oGetEtatLigne(nLigneRelative));
			}
		}
	}

	nHauteurLigne = Math.max(nHauteurLigne, this.m_nHauteurLigne);
	if (bInterne)
	{
		nHauteurLigne -= this._vnGetOffset(oEtatLigne.m_oLignePhysique, true)
	}
	return nHauteurLigne;
};

WDTable.prototype._nGetNbColonnes = function _nGetNbColonnes()
{
	return this.m_tabColonnes.length;
};

// Recupere le contenu d'une cellule
WDTable.prototype.sGetValeurCellule = function sGetValeurCellule(nLigneRelative, nColonne)
{
	return this.m_oCache.oGetValeurCellule(this.nRelative2Visible(nLigneRelative), nColonne, false);
};
WDTable.prototype.nGetValeurCellule = function nGetValeurCellule(nLigneRelative, nColonne)
{
	return this.m_oCache.oGetValeurCellule(this.nRelative2Visible(nLigneRelative), nColonne, true);
};

// Indique que l'on a change la valeur de la colonne donnee
WDTable.prototype.SetValeurCellule = function SetValeurCellule(nLigneRelative, nColonne, pfGetValeurNouvelle)
{
	// Par securite uniquement si la colonne n'est pas saisissable (Normalement c'est toujours le cas)
	if (this.bColonneSaisissable(nColonne))
	{
		// On met la valeur dans le cache et on le marque comme modifie
		this.m_oCache.SetValeurCellule(this.nRelative2Visible(nLigneRelative), nLigneRelative, nColonne, pfGetValeurNouvelle);
	}
};

// Renvoie le tableaux des options d'une cellule combo
WDTable.prototype.tabContenuCellule = function tabContenuCellule(nLigneRelative, nColonne)
{
	// Regarde si la cellule a une contenu personnalise
	var tabOptions = this.m_oCache.tabContenuCellule(this.nRelative2Visible(nLigneRelative), nColonne);
	// Si non, retourne le contenu normal de la combo
	return tabOptions ? tabOptions : this.tabColonneCombo(nColonne);
};

// Recupere une cellule depuis son numero de le ligne et de son information de colonne dans le cas des tables
WDTable.prototype.oGetIDCelluleRel = function oGetIDCelluleRel(nLigneRelative, nColonne)
{
	// nLigneHTML et nLigneRelative sont identiques car l'une manipule les lignes HTML, l'autres les lignes relative a la premiere ligne HTML
	// Ajout d'un cache dans les lignes HTML
	return this.m_oEtatLignes.oGetCelluleHTML(this, nLigneRelative, nColonne);
};

// Cree la ligne virtuelle si besoin
WDTable.prototype.bCreeLigneVirtuelle = function bCreeLigneVirtuelle(nLigneRelative)
{
	return this.m_oCache.bCreeLigneVirtuelle(this.nRelative2Visible(nLigneRelative));
};

// Supprime les lignes virtuelles
WDTable.prototype.SupprimeLignesVirtuelles = function()
{
	this.m_oCache.SupprimeLignesVirtuelles();
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis WDAffichageColonnes

// Indique que l'ordre des colonnes a chang�
WDTable.prototype.ChangeOrdreColonne = function ChangeOrdreColonne(bDepuisIHM, oColonne)
{
	// Lib�re imm�diatement le DnD sur les titres
	this.m_oAffichageColonnes.LibereTitres();

	// Dessin synchrone
	this.__GenereLignesHTML(true);
	this.bMAJNbLignesVisibles(true, false, true);

	// Et replace lde DnD sur les nouveau titres
	this.m_oAffichageColonnes.InitTitres();

	// Notifie le serveur de l'�change des colonnes
	this.m_oCache.CreeRequeteDeplaceColonne(this, oColonne.m_nRangCreation, oColonne.m_nPositionAffichage);
};

// Indique si la colonne donnee est lien
WDTable.prototype.nGetOptionLienColonne = function nGetOptionLienColonne(nColonne)
{
	// Si la colonne n'est pas dans le tableau => Pas saisissable
	if ((nColonne >= this.m_tabColonnes.length) || (nColonne < 0))
	{
		return WDTableAJAXColonne.prototype.m_nLien;
	}

	// Sinon on renvoie la valeur dans le tableau
	return this.m_tabColonnes[nColonne].m_nLien;
};

//// Indique l'etat de la colonne donnee lien
//WDTable.prototype.nColonneEtatLien = function nColonneEtatLien(nColonne)
//{
//	// Si la colonne n'est pas dans le tableau => Pas saisissable
//	if ((nColonne >= this.m_tabColonnes.length) || (nColonne < 0))
//	{
//		return WDTableAJAXColonne.prototype.m_nEtatLien;
//	}

//	// Sinon on renvoie la valeur dans le tableau
//	return this.m_tabColonnes[nColonne].m_nEtatLien;
//};

// Renvoie le tableau des options d'une colonne COMBO
WDTable.prototype.tabColonneCombo = function tabColonneCombo(nColonne)
{
	// Si la colonne n'est pas dans le tableau => tableau vide
	if ((nColonne >= this.m_tabColonnes.length) || (nColonne < 0))
	{
		return WDTableColonne.prototype.m_tabOptions;
	}

	// Sinon on renvoie la valeur dans le tableau
	return this.m_tabColonnes[nColonne].m_tabOptions;
};

// Action avant la MAJ d'une ligne
WDTable.prototype.PreMAJLigne = function PreMAJLigne(oLigneLogique, oEvent)
{
	// GP 27/03/2018 : TB108030 (suite de TB107971/TB107974) : oLigneCachePrecedent a un membre m_nPosAbsolue qui contient le num�ro absolue de la ligne. C'est ce num�ro qu'il faut utiliser.
	// Si oLigneCachePrecedent est null, c'est que la ligne n'�tait pas affich�, il n'y a pas besoin de faire le PreMAJLigne
	var oLigneCachePrecedent = oLigneLogique.m_oLigneCache;
	if (oLigneCachePrecedent)
	{
		// Indique que la ligne est masque aux champs fils
		// Note : plusieurs endroits invalident m_bPlein sans faire ces appels
		// Ils ne concernent normalement que les tables
		this._MasqueLigneInterne(oLigneCachePrecedent.m_nPosAbsolue, this.bLigneEstSelectionneePosAbsolue(oLigneCachePrecedent.m_nPosAbsolue, NaN), oEvent)
	}
};

// Action apres la MAJ d'une ligne
WDTable.prototype.PostMAJLigne = function PostMAJLigne(oLigneCache, nLigneAbsolue, bSelection)
{
	// Indique que la ligne est affichee aux champs fils
	// GP 26/03/2018 : TB107971/TB107974 : oLigneCache  a un membre m_nPosAbsolue qui contient le num�ro absolue de la ligne.
	// GP 29/03/2018 : QW297857/QW297860 : oLigneCache peut �tre null (si la ligne � �t� demand�e au serveur mais n'est pas encore disponible).
	var nPosAbsolue = oLigneCache ? oLigneCache.m_nPosAbsolue : nLigneAbsolue;
	this.m_tabChampsFils._AppelMethodePtr(WDChamp.prototype.OnLigneTableZRAffiche, [nPosAbsolue + 1, bSelection]);
};

WDTable.prototype.nGetLigneHTMLDebut = function nGetLigneHTMLDebut()
{
	return this.m_oCache.oGetLigne(this.m_nDebut).vnGetLigneHTML(this.m_nDebut);
};

// Recupere la ligne d'etat d'une ligne absolue donnee
WDTable.prototype.oGetEtatLigne = function oGetEtatLigne(nLigneRelative)
{
	return this.m_oEtatLignes.oGetEtatLigne(nLigneRelative);
};

// Note que la ligne devra etre MAJ si elle est visible
WDTable.prototype.NoteMAJLigne = function NoteMAJLigne(nLigneAbsolue)
{
	// Si la ligne est visible : lui change son style
	if (this.__bLigneEstVisible(nLigneAbsolue))
	{
		// Trouve la ligne physique de la ligne
		var oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
		if (oLigneCache)
		{
			this.oGetEtatLigne(oLigneCache.vnGetLigneHTML(nLigneAbsolue) - this.nGetLigneHTMLDebut()).Detache(oLigneCache.vnGetColonneHTML());
		}
	}
};

// Demande la MAJ de la ligne absolue
WDTable.prototype.MAJLigne = function MAJLigne(nLigneAbsolue, oEvent)
{
	// Trouve la ligne physique de la ligne
	var oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
	if (oLigneCache)
	{
		this.oGetEtatLigne(oLigneCache.vnGetLigneHTML(nLigneAbsolue) - this.nGetLigneHTMLDebut()).bMAJ(oLigneCache.vnGetColonneHTML(), oLigneCache, this, nLigneAbsolue, oEvent, this.vbLigneEstSelectionneeSansZR(nLigneAbsolue));

		// Effectue les op�rations apr�s MAJ des lignes
		this._vPostMAJLignes();
	}
};

// Convertit les coordonees visible <=> absolue
WDTable.prototype.nPosAbsolue2PosVisible = function nPosAbsolue2PosVisible(nLignePosAbsolue)
{
	// Effectue la recherche dans le cache
	if (nLignePosAbsolue != -1)
	{
		return this.m_oCache.nPosAbsolue2PosVisible(nLignePosAbsolue);
	}
	else
	{
		return -1;
	}
},
WDTable.prototype.nPosVisible2PosAbsolue = function nPosVisible2PosAbsolue(nLignePosVisible)
{
	// Recupere la ligne absolue de la ligne du cache
	if (nLignePosVisible != -1)
	{
		return this.m_oCache.nPosVisible2PosAbsolue(nLignePosVisible);
	}
	else
	{
		return -1;
	}
},

// Et notifie le serveur de la validation d'une ligne
WDTable.prototype.bValideChangement = function bValideChangement(nLigneRelative)
{
	return this.m_oCache.bValideChangement(this, this.nRelative2Visible(nLigneRelative));
};

WDTable.prototype._xvoGetInfoXY = function _xvoGetInfoXY()
{
	// Utilise le code de WDTableClassique.
	var oResultat = WDTableClassique.prototype._xvoGetInfoXY.apply(this, arguments);
	if (-1 !== oResultat.nLigne)
	{
		// Et applique l'offset de la ligne de d�part.
		var oChampDeb = this.oGetElementByName(document, "_DEB");
		oResultat.nLigne += this.nGetDebut(oChampDeb.value);
	}
	return oResultat;
};

//////////////////////////////////////////////////////////////////////////
// WDCelluleAJAXSaisie
function WDCelluleAJAXSaisie()
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDCelluleSaisie.prototype.constructor.apply(this, arguments);

		// m_nLigne est une ligne RELATIVE !!!
	}
};

// Declare l'heritage
WDCelluleAJAXSaisie.prototype = new WDCelluleSaisie();
// Surcharge le constructeur qui a ete efface
WDCelluleAJAXSaisie.prototype.constructor = WDCelluleAJAXSaisie;

WDCelluleAJAXSaisie.prototype.m_nDiffClick = 1000; 	// Au mimimun un double click en 1 seconde

//////////////////////////////////////////////////////////////////////////
// Classes utilitaires (tri, menu, recherche etc)
//	WDCelluleSaisie
//		M�thodes internes g�n�rales

// Recupere la cellule
WDCelluleAJAXSaisie.prototype._voGetCellule = function _voGetCellule()
{
	// m_nLigne est une ligne RELATIVE (ou WL selon le type de table) !!!
	return this.m_oChampTable.oGetIDCelluleRel(this.m_nLigne, this.m_nColonne);
};

// Trouve la hauteur d'une ligne
WDCelluleAJAXSaisie.prototype._vnGetHauteurLigne = function _vnGetHauteurLigne()
{
	// GP 30/04/2018 : TB103841 : On veux la hauteur interne pas la hauteur totale
	return this.m_oChampTable.nGetHauteurLigneRel(this.m_nLigne, true, true);
};

// Demande la MAJ de la ligne
// Retourne vrai si la table va �tre redessin�e
WDCelluleAJAXSaisie.prototype._vbMAJLigne = function _vbMAJLigne(bValideChangement)
{
	var bChangement = false;

	// Si on a pas une colonne saisissable ou que l'on indique de ne pas continuer : valide le changement
	if (bValideChangement)
	{
		bChangement = this.m_oChampTable.bValideChangement(this.m_nLigne);
	}

	this.m_oChampTable.bMAJLigneRel(this.m_nLigne);

	return bChangement;
};

// Cr�ation de la ligne virtuelle (toujours en r�ussite)
WDCelluleAJAXSaisie.prototype._vbCreeLigneVirtuelle = function _vbCreeLigneVirtuelle()
{
	return this.m_oChampTable.bCreeLigneVirtuelle(this.m_nLigne);
};

// Supprime la ligne virtuelle
WDCelluleAJAXSaisie.prototype._vSupprimeLignesVirtuelles = function _vSupprimeLignesVirtuelles()
{
	this.m_oChampTable.SupprimeLignesVirtuelles();
};

// GP 27/11/2013 : QW239976 : Il faut faire la conversion vers la valeur interne dans la saisie des tables navigateur mais pas des tables AJAX
WDCelluleAJAXSaisie.prototype._vbAvecMasqueModele = function _vbAvecMasqueModele()
{
	return false;
};
