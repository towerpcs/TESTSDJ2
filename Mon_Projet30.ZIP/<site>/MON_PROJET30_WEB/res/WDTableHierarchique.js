// WDTableHierarchique.js
/*! 27.0.1.0  */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - La page
///#GLOBALS _WD_
// - WDAjax.js
///#GLOBALS clWDAJAXMain
// - WDTableZRCommun.js
///#GLOBALS WDTableCacheLigne WDTable

// Ligne dans une table hierarchique
function WDTableHierarchiqueCacheLigne(oXMLLigne/*, oObjetTableHierarchique*//*, nLigne*/)
{
	if (oXMLLigne)
	{
		// Appel le constructeur de la classe de base
		WDTableCacheLigne.prototype.constructor.apply(this, arguments);

		// Sinon contenu vide (par exemple si la ligne est repliee)
		this.m_nNbEnroulees = clWDAJAXMain.nXMLGetAttributSafe(oXMLLigne, this.XML_LIGNE_NBENROULEES, 0);

		// Recupere la profondeur (= le retrait dans le dessin)
		this.m_nProfondeur = clWDAJAXMain.nXMLGetAttributSafe(oXMLLigne, this.XML_LIGNE_PROFONDEUR, 0);
		// Recupere si la ligne est d�roule
		this.m_bDeroule = clWDAJAXMain.bXMLGetAttributSafe(oXMLLigne, this.XML_LIGNE_DEROULE, 0);
		// Recupere si la ligne est une feuille
		this.m_bFeuille = clWDAJAXMain.bXMLGetAttributSafe(oXMLLigne, this.XML_LIGNE_FEUILLE, 0);

		// Indique aussi l'image de repliement/d�pliement
		if (clWDAJAXMain.bXMLAttributExiste(oXMLLigne, this.XML_LIGNE_IMAGEENROULEDEROULE))
		{
			this.m_sImageEnrouleDeroule = clWDAJAXMain.sXMLGetAttribut(oXMLLigne, this.XML_LIGNE_IMAGEENROULEDEROULE);
		}
	}
}

// Declare l'heritage
WDTableHierarchiqueCacheLigne.prototype = new WDTableCacheLigne();
// Surcharge le constructeur qui a ete efface
WDTableHierarchiqueCacheLigne.prototype.constructor = WDTableHierarchiqueCacheLigne;

WDTableHierarchiqueCacheLigne.prototype.XML_LIGNE_NBENROULEES = "NBENROULEES";
WDTableHierarchiqueCacheLigne.prototype.XML_LIGNE_PROFONDEUR = "PROFONDEUR";
WDTableHierarchiqueCacheLigne.prototype.XML_LIGNE_DEROULE = "DEROULE";
WDTableHierarchiqueCacheLigne.prototype.XML_LIGNE_FEUILLE = "FEUILLE";
WDTableHierarchiqueCacheLigne.prototype.XML_LIGNE_IMAGEENROULEDEROULE = "IMAGEENROULEDEROULE";

//_vPlaceXMLDansCellule
//vnGetLigneHTML
//vnGetColonneHTML

// Si la ligne est repliee (ligne est invisible mais ses ruptures oui)
// Utilis� pour supprimer les lignes ensuites
// Retourne le nombre de ligne a ignorer ensuite (attention en serveur le nombre de lignes repli�es inclus la ligne courante, ici ce n'est pas le cas)
// En revanche, c'est identique pour le nombre de lignes enroul�es qui n'inclus jamais la ligne courante
WDTableHierarchiqueCacheLigne.prototype.vnGetNbReplieesOuEnroulees = function vnGetNbReplieesOuEnroulees()
{
	return this.m_nNbEnroulees;
};
// GP 16/10/2014 : Ajout� pour ne pas casser le code existant
WDTableHierarchiqueCacheLigne.prototype.vnGetNbReplieesInclusSelf = function vnGetNbReplieesInclusSelf()
{
	return 0;
};

// Trouve l'image d'enroul�/d�roul�
WDTableHierarchiqueCacheLigne.prototype.sGetImageEnrouleDeroule = function sGetImageEnrouleDeroule(oObjetTableHierarchique)
{
	if (this.m_sImageEnrouleDeroule)
	{
		// Si on a une image forc�e
		return _WD_ + this.m_sImageEnrouleDeroule;
	}
	else if (this.m_bFeuille || !this.m_bDeroule)
	{
		// Si c'est une feuille ou si c'est ferm� : ferm�
		return oObjetTableHierarchique.sGetImageEnrouleDefaut();
	}
	else
	{
		return oObjetTableHierarchique.sGetImageDerouleDefaut();
	}
};
// Trouve l'image de +/-
WDTableHierarchiqueCacheLigne.prototype.sGetImagePlusMoins = function sGetImagePlusMoins(oObjetTableHierarchique, /*OUT*/oDetails)
{
	if (this.m_bFeuille)
	{
		return oObjetTableHierarchique.sGetImageFeuille(/*OUT*/oDetails);
	}
	else if (this.m_bDeroule)
	{
		return oObjetTableHierarchique.sGetImageMoins(/*OUT*/oDetails);
	}
	else
	{
		return oObjetTableHierarchique.sGetImagePlus(/*OUT*/oDetails);
	}
};

// Classe manipulant une table hi�rarchique
// La table n'a normalement jamais de table/zr parente
function WDTableHierarchique(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDTable.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ sXMLLignes, eCacheLimite, nHauteurLigne, nPagesMargeMin, nPagesMargeMax, eTypeSelection, tabStyle, tabImagesTriRechercheFiltre, bHauteurLigneVariable ]

		// Ne rien mettre ici qui doit etre remit a zero dans l'init
	}
}

// Declare l'heritage
WDTableHierarchique.prototype = new WDTable();
// Surcharge le constructeur qui a ete efface
WDTableHierarchique.prototype.constructor = WDTableHierarchique;

WDTableHierarchique.prototype.XML_LISTE_IMAGEENROULE = "IMAGEENROULE";
WDTableHierarchique.prototype.XML_LISTE_IMAGEDEROULE = "IMAGEDEROULE";
WDTableHierarchique.prototype.XML_LISTE_IMAGEPLUSMOINS = "IMAGEPLUSMOINS";

WDTableHierarchique.prototype.ms_sClasseBoutonPM = "WDTH-BoutonPM";
WDTableHierarchique.prototype.ms_nMarginRightImage = 6;
WDTableHierarchique.prototype.ms_tabImageDefaut = {
	ms_sImageFeuille: "vide.gif",
	ms_sImagePlus: "plus.gif",
	ms_sImageMoins: "moins.gif",
	ms_sImageEnroule: "d_closed.gif",
	ms_sImageDeroule: "d_open.gif"
};

// Classe de cache
WDTableHierarchique.prototype.vCacheLigne = WDTableHierarchiqueCacheLigne;

// Initialisation
WDTableHierarchique.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDTable.prototype.Init.apply(this, arguments);

};

// Methode d'initialisation generale de la classe (ne s'execute que lors de l'init de la premi�re instance de ce type)
WDTableHierarchique.prototype._vInitInitiale = function _vInitInitiale()
{
	// Appel de la methode de la classe de base
	WDTable.prototype._vInitInitiale.apply(this, arguments);

	// Prechargement des images
	for (var sImage in this.ms_tabImageDefaut)
	{
		if (this.ms_tabImageDefaut.hasOwnProperty(sImage))
		{
			// GP 18/07/2012 : Factorisation du pr�chargement
			WDTableHierarchique.prototype[sImage] = clWDUtil.sCheminImageRes(undefined, this.ms_tabImageDefaut[sImage]);
		}
	}

	// S'auto efface pour ne plus etre appele
	WDTableHierarchique.prototype._vInitInitiale = clWDUtil.m_pfVide;
};

// Charge les propri�t�s sp�cifiques
WDTableHierarchique.prototype._vActionListeSpecifique = function _vActionListeSpecifique(oXMLLignes)
{
	// Appel de la methode de la classe de base
	WDTable.prototype._vActionListeSpecifique.apply(this, arguments);

	// (Tables hi�rarchiques) Num�ro de la colonne hi�rarchique
	this.m_nColonneHierarchique = clWDAJAXMain.nXMLGetAttributSafe(oXMLLignes, this.XML_COLHIERARCHIQUE, 0);

	// Indique aussi l'image de repliement/d�pliement
	delete this.m_sImageEnroule;
	if (clWDAJAXMain.bXMLAttributExiste(oXMLLignes, this.XML_LISTE_IMAGEENROULE))
	{
		this.m_sImageEnroule = clWDAJAXMain.sXMLGetAttribut(oXMLLignes, this.XML_LISTE_IMAGEENROULE);
	}
	delete this.m_sImageDeroule;
	if (clWDAJAXMain.bXMLAttributExiste(oXMLLignes, this.XML_LISTE_IMAGEDEROULE))
	{
		this.m_sImageDeroule = clWDAJAXMain.sXMLGetAttribut(oXMLLignes, this.XML_LISTE_IMAGEDEROULE);
	}

	// Calcule les param�tres pour l'image plus/moins/feuille
	delete this.m_oImagePlusMoins;
	var sImagePlusMoins = clWDAJAXMain.sXMLGetAttributSafe(oXMLLignes, this.XML_LISTE_IMAGEPLUSMOINS, "");
	if (0 < sImagePlusMoins.length)
	{
		var tabImagePlusMoins = sImagePlusMoins.split(";");
		this.m_oImagePlusMoins =
		{
			m_sImage: _WD_ + tabImagePlusMoins[0],
			m_nNbImages: parseInt(tabImagePlusMoins[1], 10),
			m_nNbEtats: parseInt(tabImagePlusMoins[2], 10),
			m_nLargeurUneImage: parseInt(tabImagePlusMoins[3], 10),
			m_nHauteurUneImage: parseInt(tabImagePlusMoins[4], 10)
		};
	}
};

// Vide une cellule de ZR
WDTableHierarchique.prototype.vVideCellule = function vVideCellule(oEtatLigne/*, nColonne*/)
{
	// GP 24/08/2015 : TB92889 : si la colonne hi�rarchique est invisible (!!!) on n'a pas la cellule
	// On n'a pas le probl�me dans vRemplitCellule car on teste l'existance de la cellule avant l'affichage
	var oCelluleHTML = oEtatLigne.oGetCelluleHTML(this, this.m_nColonneHierarchique);
	if (oCelluleHTML)
	{
		// Supprime les onclick de l'image du +/-
		clWDUtil.bForEach(oCelluleHTML.getElementsByTagName("img"), function(oImage)
		{
			// Gestion des anciennes fonctions : non on supprime l'element
			oImage.onclick = null;

			return true;
		});
	}

	// Appel de la classe de base
	WDTable.prototype.vVideCellule.apply(this, arguments);
};

// Remplit une cellule de la table
WDTableHierarchique.prototype.vRemplitCellule = function vRemplitCellule(oCellule, sValeur, sBulleCellule, nLigneAbsolue, nColonne, oLigneCache/*, bSelection, tabRedimensionnementDesImages*/)
{
	// Appel de la classe de base
	WDTable.prototype.vRemplitCellule.apply(this, arguments);

	// Si on est dans la colonne hi�rarchique : ajout des images et des boutons
	if (nColonne === this.m_nColonneHierarchique)
	{
		// On insere au debut dans l'ordre inverse (on ajoute toujours au debut)

		// Ajoute l'image de la ligne
		this.__AjouteImageRepertoire(oCellule, oLigneCache.sGetImageEnrouleDeroule(this));
		// Ajoute l'image de +/-
		// oLigneCache.m_nProfondeur * 10 : Decale la colonne en fonction de la colonne du champ
		// GP 19/07/2012 : Ajout d'un blanc tournant de 2 pixels suppl�mentaires
		var oDetails = {};
		this.__AjouteImagePlusMoins(oCellule, oLigneCache.sGetImagePlusMoins(this, oDetails), oLigneCache.m_nProfondeur, oDetails);
	}
};

// Calcule l'image enroul�e et d�roul�e par d�faut (= si la ligne ne surcharge pas cette image)
WDTableHierarchique.prototype.sGetImageEnrouleDefaut = function sGetImageEnrouleDefaut()
{
	if (this.m_sImageEnroule)
	{
		// Si on a une image forc�e
		return _WD_ + this.m_sImageEnroule;
	}
	else
	{
		return this.ms_sImageEnroule;
	}
};
WDTableHierarchique.prototype.sGetImageDerouleDefaut = function sGetImageDerouleDefaut()
{
	if (this.m_sImageDeroule)
	{
		// Si on a une image forc�e
		return _WD_ + this.m_sImageDeroule;
	}
	else
	{
		return this.ms_sImageDeroule;
	}
};

// Calcule les images plus, moins et de feuille
WDTableHierarchique.prototype.__sGetImagePlusMoins = function __sGetImagePlusMoins(nImage, nEtat, sImageDefaut, bInvisibleSiDefaut, /*OUT*/oDetails)
{
	if (this.m_oImagePlusMoins && (nImage < this.m_oImagePlusMoins.m_nNbImages))
	{
		oDetails.m_nPositionX = this.m_oImagePlusMoins.m_nLargeurUneImage * nImage;
		oDetails.m_nPositionY = this.m_oImagePlusMoins.m_nLargeurUneImage * nEtat;
		oDetails.m_bDefaut = false;
		oDetails.m_bInvisible = false;
		return this.m_oImagePlusMoins.m_sImage;
	}
	else
	{
		oDetails.m_bDefaut = true;
		oDetails.m_bInvisible = bInvisibleSiDefaut;
		return sImageDefaut;
	}
};
WDTableHierarchique.prototype.sGetImagePlus = function sGetImagePlus(/*OUT*/oDetails)
{
	return this.__sGetImagePlusMoins(0, 0, this.ms_sImagePlus, false, /*OUT*/oDetails);
};
WDTableHierarchique.prototype.sGetImageMoins = function sGetImageMoins(/*OUT*/oDetails)
{
	return this.__sGetImagePlusMoins(1, 0, this.ms_sImageMoins, false, /*OUT*/oDetails);
};
WDTableHierarchique.prototype.sGetImageFeuille = function sGetImageFeuille(/*OUT*/oDetails)
{
	return this.__sGetImagePlusMoins(2, 0, this.ms_sImageFeuille, true, /*OUT*/oDetails);
};

// Ajoute une image au debut
WDTableHierarchique.prototype.__AjouteImageRepertoire = function __AjouteImageRepertoire(oCellule, sImage)
{
	// Cr�ation de l'image
	var oImage = document.createElement("img");
	oImage.src = sImage;

	// Ajoute le div au debut du conteneur
	return this.__oAjouteImageDebut(oCellule, oImage);
};
WDTableHierarchique.prototype.__AjouteImagePlusMoins = function __AjouteImagePlusMoins(oCellule, sImage, nProfondeur, oDetails)
{
	// Cr�ation du lien
	var oElement = document.createElement("img");
	if (oDetails.m_bDefaut)
	{
		oElement.src = sImage;
	}
	else
	{
		oElement.src = this.ms_sImageFeuille;
		oElement.style.backgroundImage = clWDUtil.sGetURICSS(sImage);
		// "-" Car on travaille en offset de backgroundImage/backgroundPosition
		oElement.style.backgroundPosition = "-" + oDetails.m_nPositionX + "px -" + oDetails.m_nPositionY + "px";
		oElement.style.height = (oDetails.m_bDefaut ? 10 : this.m_oImagePlusMoins.m_nHauteurUneImage) + "px";
	}
	var nLargeur = oDetails.m_bDefaut ? 9 : this.m_oImagePlusMoins.m_nLargeurUneImage;
	oElement.style.width = nLargeur + "px";
	oElement.style.marginLeft = (2 + nProfondeur * (nLargeur + this.ms_nMarginRightImage)) + "px";
	if (oDetails.m_bInvisible)
	{
		oElement.style.visibility = "hidden";
	}
	oElement.className = this.ms_sClasseBoutonPM;
	return this.__oAjouteImageDebut(oCellule, oElement);
};

WDTableHierarchique.prototype.__oAjouteImageDebut = function __oAjouteImageDebut(oCellule, oElement)
{
	oElement.style.marginRight = this.ms_nMarginRightImage + "px";
	oElement.align = "absmiddle";

	// Ajoute le div au debut du conteneur
	if (0 === oCellule.childNodes.length)
	{
		return oCellule.appendChild(oElement);
	}
	else
	{
		// GP 18/11/2020 : QW332508 : Ici il faut firstChild et pas firstElementChild. Car on veux ins�rer avant le texte simple qui n'est pas un HTMLElement.
		return oCellule.insertBefore(oElement, oCellule.firstChild);
	}
};

// Click sur une ligne de zone repetee
WDTableHierarchique.prototype.OnSelectLigne = function OnSelectLigne(nLigneRelative, nColonne, oEvent/*, bColonneLien*/)
{
	var bEnrouleDeroule = clWDUtil.oGetOriginalTarget(oEvent).className === this.ms_sClasseBoutonPM;

	// Appel de la classe de base
	// GP 27/08/2012 : On envoi quand m�me la requ�te pour la s�lection : le moteur fait trop de trucs sur la s�lection.
	// Il est impossible de faire la s�lection correctement sur l'action d'enroule/d�roule sur le serveur
	WDTable.prototype.OnSelectLigne.apply(this, arguments);

	// Si le clic est sur l'image du +/-
	if (bEnrouleDeroule)
	{
		var nLigneAbsolue = this.nRelative2Visible2Absolue(nLigneRelative);

		// @@@ PCode

		this.m_oCache.CreeRequeteEnrouleDeroule(this, nLigneAbsolue);
	}
};
