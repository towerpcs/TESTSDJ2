// WDTablesNavigateur.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS WDStyleCache WDErreur
// - WDChamp.js
///#GLOBALS WDChamp
// - WDDeplacement.js
///#GLOBALS WDPosition WDPositionColonnes
// - WDTableZRCommun.js
///#GLOBALS clWDTableDefs WDRupture WDAttribut WDTableColonne WDLigne WDTableZRNavigateur WDPopupSaisieTRF WDCelluleSaisie WDAffichageColonnes WDTableClassique

// Code sp�cifique aux tables navigateur

//////////////////////////////////////////////////////////////////////////
// WDTableRupture
// => Rupture de table navigateur
// H�rite de WDRupture
// => Rien de sp�cifique par rapport � WDRupture
var WDTableRupture = WDRupture;

//////////////////////////////////////////////////////////////////////////
// WDTableNavColonne
// => Colonne de table navigateur
// H�rite de WDTableColonne
function WDTableNavColonne(/*sAlias*//*, eTypeWL*//*, tabProprietesSpecifiques*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDTableColonne.prototype.constructor.apply(this, arguments);

		// GP 18/11/2013 : QW239210 : Plus maintenant. C'est l'�dition qui nous donne le contenu de la colonne (affect� depuis tabProprietesSpecifiques dans WDTableColonne)
//		// Contenu de la combo
//		this.m_tabOptions = [];
	}
}

// Declare l'heritage
WDTableNavColonne.prototype = new WDTableColonne();
// Surcharge le constructeur qui a ete efface
WDTableNavColonne.prototype.constructor = WDTableNavColonne;

// <R�sultat> = ListeCherche(<Colonne>)
WDTableNavColonne.prototype.nCherche = function nCherche(sValeur, bRechercheIdentique, nDebut)
{
	return clWDUtil.nDansTableauFct(this.m_tabOptions, clWDUtil.fGetCompare(bRechercheIdentique ? clWDUtil.nRechercheIdentique : clWDUtil.nRechercheCommencePar), sValeur, nDebut);
};
// <R�sultat> = ListeOccurrence(<Colonne>)
WDTableNavColonne.prototype.nGetOccurrence = function nGetOccurrence()
{
	return this.m_tabOptions.length;
};
// ListeAjoute(<Colonne>)
// ListeInsere(<Colonne>)
WDTableNavColonne.prototype.Insere = function Insere(sValeur, nPositionC)
{
	// GP 14/05/2018 : TB106719 : Accepte les RC dans la valeur (il faut normalises les s�parateurs).
	var tabLignes = sValeur.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
	var tabOptions = this.m_tabOptions;
	clWDUtil.bForEach(tabLignes, (nPositionC < this.nGetOccurrence()) ? function(sUneLigne)
	{
		// nPositionC++ pour faire l'insertion dans l'ordre.
		tabOptions.splice(nPositionC++, 0, sUneLigne);
		return true;
	} : function(sUneLigne)
	{
		tabOptions.push(sUneLigne);
		return true;
	});
};
// ListeModifie(<Colonne>)
WDTableNavColonne.prototype.Modifie = function Modifie(sValeur, nPositionC)
{
	this.m_tabOptions[nPositionC] = sValeur;
};
// ListeSupprime(<Colonne>)
WDTableNavColonne.prototype.Supprime = function Supprime(nPositionC)
{
	this.m_tabOptions.splice(nPositionC, 1);
};
// ListeSupprimeTout(<Colonne>)
WDTableNavColonne.prototype.SupprimeTout = function SupprimeTout()
{
	// GP 25/04/2018 : QW106719 : Il ne faut pas faire un delete mais simplement supprimer le contenu du tableau (il faut garder le tableau valide et si possible sans le r�affecter).
	this.m_tabOptions.length = 0;
};

// Retourne la position demand� ou dernier �l�ment + 1 si la valeur est invalide
WDTableNavColonne.prototype.nGetPositionC = function nGetPositionC(nPositionWL)
{
	var nOccurrence = this.nGetOccurrence();
	if ((undefined === nPositionWL) || (nPositionWL < 1) || (nOccurrence < nPositionWL))
	{
		return nOccurrence;
	}
	else
	{
		return nPositionWL - 1;
	}
};

// Retourne la position demand� ou une exception si la valeur est invalide
WDTableNavColonne.prototype.xnGetPositionC = function xnGetPositionC(nPositionWL)
{
	var nOccurrence = this.nGetOccurrence();
	if ((undefined === nPositionWL) || (nPositionWL < 1) || (nOccurrence < nPositionWL))
	{
		// Erreur fatale WL :
		// "L'indice sp�cifi� %1 est invalide : les valeurs valides sont comprises entre %2 et %3."
		throw new WDErreur(301, nPositionWL, 1, nOccurrence);
	}
	else
	{
		return nPositionWL - 1;
	}
};

//////////////////////////////////////////////////////////////////////////
// WDTableAttribut
// => Attribut (automatique) de table navigateur
// H�rite de WDAttribut
// => Rien de sp�cifique par rapport � WDAttribut
var WDTableAttribut = WDAttribut;

//////////////////////////////////////////////////////////////////////////
// WDTableLigne
// => Ligne de table navigateur
// H�rite de WDLigne
// => Rien de sp�cifique par rapport � WDLigne
var WDTableLigne = WDLigne;

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
// => Table
// H�rite de WDTableZRNavigateur

// Manipulation d'une zone repetee galerie
// La table n'a normalement jamais de table/zr parente
function WDTableNavigateur(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		// Format de tabParametresSupplementaires attendu par WDTableZRNavigateur : [ oParametres, oDonnees, eTypeSelection ]
		WDTableZRNavigateur.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees, eTypeSelection, tabStyle, tabImagesTriRechercheFiltre, bHauteurLigneVariable ]
//		var eTypeSelection = tabParametresSupplementaires[2];
		var tabStyle = tabParametresSupplementaires[3];
		var tabImagesTriRechercheFiltre = tabParametresSupplementaires[4];
		var bHauteurLigneVariable = tabParametresSupplementaires[5];

		// tabImagesTriRechercheFiltre :
		// - 0 : Images pour les tri : 3 images (pas de tri, tri croissant, tri d�croissant)
		// - 1 : Images pour la recherche : 3 images (recherche, recherche en survol, recherche en saisie)
		// - 2 : Images pour le filtre : 3 images (filtre, filtre en survol, filtre en saisie)
		// - 3 : Images pour le d�placement des colonnes : 2 images (fl�che vers la droite, fl�che vers la gauche)
		var tabFleches = tabImagesTriRechercheFiltre.splice(3, 1)[0];

		// Cache du style de la largeur des colonnes
		this.m_oStyleCacheLargeur = new WDStyleCache(true);
		this.m_oStyleCacheLargeur.Creation();
		this.m_oStyleCacheLargeur.CreationFin();

		this.m_tabStyle = tabStyle;
		// Gestion des images pour le tri, la recherche et le filtre
		this.m_oPopupSaisieTRF = new WDPopupSaisieTRF(this, tabImagesTriRechercheFiltre);
		// Gestion des colonnes
		this.m_oAffichageColonnes = new WDAffichageColonnes(this, tabFleches, this.m_oStyleCacheLargeur);
		// Saisie dans les cellules
		this.m_oCelluleSaisie = new WDCelluleSaisie(this);

		this.m_bHauteurLigneVariable = bHauteurLigneVariable;
	}
};

// Declare l'heritage
WDTableNavigateur.prototype = new WDTableZRNavigateur();
// Surcharge le constructeur qui a ete efface
WDTableNavigateur.prototype.constructor = WDTableNavigateur;

WDTableNavigateur.prototype.ms_nTicAffichage = 0;
WDTableNavigateur.prototype.ms_nTicCreation = 0;

// Initialisation :
WDTableNavigateur.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDTableZRNavigateur.prototype.Init.apply(this, arguments);

	// Affiche les images du tri
	this.m_oPopupSaisieTRF.AjouteLienImages(this.m_tabColonnes);
	// Informe de l'�tat des colonnes
	this.m_oAffichageColonnes.Init(this.m_tabColonnes);

	// GP 17/11/2013 : Uniquement si la table est avec des titres de colonnes
	if (this.m_oTitrePosPixel)
	{
		// Synchro des d�filements
		var oThis = this;
		// Utilise oThis.m_Xxx pour avoir toujours la derni�re valeur
		(this.m_oHote.parentNode.onscroll = function() { oThis.__SynchroniseTitreScroll(); });
	}
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	M�thodes surcharg�es
//		WDChamp

// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
WDTableNavigateur.prototype._vOnResize = function _vOnResize(/*oEvent*/)
{
	// Appel de la methode de la classe de base
	WDTableZRNavigateur.prototype._vOnResize.apply(this, arguments);

	// V�rifie si la zone cliente a un ascenseur vertical et fait la synchro avec la zone de titre
	this.__SynchroniseTitre();
};

// Trouve les divers elements : liaison avec le HTML
WDTableNavigateur.prototype._vLiaisonHTML = function _vLiaisonHTML(sSuffixeFormulaire, sSuffixeHote)
{
	// Il doit y avoir une meilleure solution (en particulier deplacer le code lie au ZR dans WDChamp mais cela va faire des effets de bord a l'init)
	WDTableZRNavigateur.prototype._vLiaisonHTML.apply(this, [sSuffixeFormulaire, sSuffixeHote]);

	// La g�n�ration a potentiellement red�fini (ecriture de .outerHTML) les titres
	(this.m_oTitrePosPixel = this.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_POSITION_PIXEL));
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	M�thodes surcharg�es
//		WDTableZRNavigateur

// Cr�� un nouvel objet colonne/attribut (qui d�rive donc de WDColonne)
WDTableNavigateur.prototype._vNewColonne = WDTableNavColonne;
// Cr�� un nouvel objet attribut automatique (qui d�rive donc de WDAttribut)
WDTableNavigateur.prototype._vNewAttributAutomatique = WDTableAttribut;
// Cr�e un nouvel objet colonne/attribut (qui d�rive donc de WDRupture)
WDTableNavigateur.prototype._vNewRupture = WDTableRupture;
// Cr�e un nouvel objet ligne
WDTableNavigateur.prototype._vLigne = WDTableLigne;

// Notifie que le champ va �tre redessin�
// oInformationAffiche : objet remplit par _vPreAffiche et lut par _voPostAffiche
WDTableNavigateur.prototype._vPreAffiche = function _vPreAffiche(oInformationAffiche)
{
	// GP 22/11/2013 : QW239684 : Si on a une saisie dans la table : d�tache le formulaire
	oInformationAffiche.m_bCelluleSaisie = this.m_oCelluleSaisie.bDetacheFormulaire();

	// Et appel ensuite de la methode de la classe de base
	// Si on �tait dans le formulaire : plus rien n'a le focus.
	// Si on �tait pas dans le formulaire mais dans un champ d'un colonne de table conteneur (ou d'une rupture), on on d�tectera le focus
	WDTableZRNavigateur.prototype._vPreAffiche.apply(this, [oInformationAffiche]);
};

// Notifie que le champ a �t� redessin� :
// - Hook les onblur/onchange des elements (ZRs)
// - Notifie les champs de l'affichage des lignes (ZRs)
// - Redonne le focus (ZRs)
// - Recalul la zone des titres (tables)
// oInformationAffiche : objet remplit par _vPreAffiche et lut par _voPostAffiche
WDTableNavigateur.prototype._vPostAffiche = function _vPostAffiche(oInformationAffiche)
{
	// Appel de la methode de la classe de base
	WDTableZRNavigateur.prototype._vPostAffiche.apply(this, [oInformationAffiche]);

	// GP 26/04/2018 : TB104916 : Semble ne plus �tre d'actualit�, l'appel du code est directement dans l'action donc avec ce branchement tout est fait en double.
//	// GP 24/11/2013 : QW239209 : Branche les PCodes utilisateur des colonnes
//	this.__BranchePCodesColonnes();

//	// Applique les largeurs des colonnes
//	this.m_oAffichageColonnes.AppliqueLargeurVisibleCorps();

	// V�rifie si la zone cliente a un ascenseur vertical et fait la synchro avec la zone de titre
	this.__SynchroniseTitre();

	// GP 22/11/2013 : QW239684 : Si on a une saisie dans la table : reattache le formulaire
	this.m_oCelluleSaisie.AttacheFormulaire(oInformationAffiche.m_bCelluleSaisie);
};

// G�n�re une ligne du HTML
WDTableNavigateur.prototype._vHTMLGenereLigne = function _vHTMLGenereLigne(nLigne, nLigneAffiche, oLigne, tabHTML)
{
	// Pour avoir la g�n�ration d'une ligne, il faut g�n�rer le contenu de la ligne
	var oContenuLigne = this.m_oElementsHTML.tbody.contenu[0];

	// G�n�re les composantes de la ligne
	this.__HTMLGenereLigne(nLigne, nLigneAffiche, oLigne, oContenuLigne, tabHTML);
};

// Gen�re la ligne des titres
WDTableNavigateur.prototype._vTableAfficheTitres = function _vTableAfficheTitres()
{
	// GP 17/11/2013 : Uniquement si la table est avec des titres de colonnes
	if (this.m_oTitrePosPixel)
	{
		// On fait la g�n�ration des titres
		var tabHTML = [];

		// Ajoute les lignes
		var tabContenuLignesTitre = this.m_oElementsHTML.thead.contenu;
		var nLigneTitre;
		var nLimiteLigneTitre = tabContenuLignesTitre.length;
		for (nLigneTitre = 0; nLigneTitre < nLimiteLigneTitre; nLigneTitre++)
		{
			this.__HTMLGenereLigne(0, 1, null, tabContenuLignesTitre[nLigneTitre], tabHTML);
		}

		// On va changer l'ordre des colonnes :
		// - Lib�ration du lien entre les pictos de tri/recherche/filtre et le JS
		this.m_oPopupSaisieTRF.SupprimeLienImages(this.m_tabColonnes.length);
		// - Lib�ration du lien entre le HTML des colonnes et le DnD
		this.m_oAffichageColonnes.LibereTitres();

		// Place le HTML dans la zone de titre
		this._HTMLAffiche(this.m_oTitrePosPixel, tabHTML);

		// On viens de changer l'ordre des colonnes :
		// - Recr�ation du lien entre le HTML des colonnes et le DnD
		this.m_oAffichageColonnes.InitTitres();
		// - Recr�ation du lien entre les pictos de tri/recherche/filtre et le JS
		this.m_oPopupSaisieTRF.AjouteLienImages(this.m_tabColonnes);

		// Notifie de la modification du HTML
		clWDUtil.m_oNotificationsAjoutHTML.LanceNotifications(this, this.m_oTitrePosPixel);
	}
};

// MAJ des pictos de recherche, tri et filtre sur changement du tri, de la recherche ou du filtre
WDTableNavigateur.prototype._vInvalidePourTRF = function _vInvalidePourTRF(nColonne, bCroissant)
{
	if (undefined !== nColonne)
	{
		this.m_oPopupSaisieTRF.AfficheImageTri(nColonne, bCroissant);
	}
	else
	{
		// false : les onXxx sont encore branch�s
		this.m_oPopupSaisieTRF.AjouteLienImages(this.m_tabColonnes, true);
	}
};

// Parse le HTML re�u de la g�n�ration HTML
WDTableNavigateur.prototype._voHTMLParse = function _voHTMLParse(sSourceHTML)
{
	// GP 15/10/2013 : Le contenu du HTML est maintenant du JSON avec comme structure :
	// <Objet g�n�ral> = { thead: <Objet table>, tbody: <Objet table> }
//	// <Objet table> = { colgroup: <Objet ligne>, contenu: <Tableau d'objet lignes> }
	// <Objet table> = { contenu: <Tableau d'objet lignes> }
	// <Tableau d'objet lignes> = [ <Objet ligne>, <Objet ligne>, ..., <Objet ligne> ]
	// <Objet ligne> = { debut: <Chaine>, contenu: [ <Chaine>, <Chaine>, ..., <Chaine> ], fin: <Chaine> }
	//
	// Nombre d'objet lignes dans le contenu de :
	// - thead : autant d'objet ligne que de lignes dans le titre
	// - tbody : une et une seule ligne
	//
	// Si (dans le thead) on a des cellules qui prenent plusieurs colonnes/lignes, on place "" dans les cellules qui n'ont pas de HTML
	var oSourceHTML = clWDUtil.oEvalJSON(sSourceHTML);

	// La valeur retourn�e � la m�me structure que oSourceHTML sauf que chaque �l�ment a �t� pars� (donc au lieu d'avoir des chaines on a un tableau de HTML)
	// Chaque �l�ment est un tableau d'objets :
	// - Balise fixe :			{ vVersHTML : this.VersHTML_Fixe, m_sValeur : (Valeur chaine) }
	// - Balise dynamique		{ vVersHTML : this.VersHTML_Propriete, m_oPropriete : { <m_nColonne> <, m_ePropriete> <, m_eConversion> }
	//																					^				^				^
	//																			Si sur attribut			^			Si conversion
	//																						Si propriete (sur ZR)
	// - Balise condition		{ vVersHTML : this.VersHTML_Condition, m_sValeur : (Valeur chaine a tester), m_bDifferent : <!= au lieu de ==>, m_tabElementsHTML: <Tableau interne>, m_oPropriete : <Idem balise dynamique> }
	return this.__oHTMLParseElement(oSourceHTML);
};

// Indique si on a une couleur de fond pour la s�lection de la ligne
// => Oui dans les tables. On devrait �tre plus pr�cis mais il faudrait avoir les couleurs de fond des styles.
WDTableNavigateur.prototype._vbAvecCouleurDeFondSelection = clWDUtil.m_pfVide;

// CodeHTML32 : Colspan a utiliser pour la cellule des ruptures dans une table
WDTableNavigateur.prototype._vnGetColSpanRupture = function _vnGetColSpanRupture()
{
	// GP 28/11/2014 : QW252618 : M�me algo que en code serveur : nombre de colonnes visibles + nombre de colonne redimensionnable (- 1 sur la derni�re colonne est redimensionnable)
	var nColSpanRupture = 0;
	var bDernierColonneVisibleEstRedimensionnable = false;
	clWDUtil.bForEach(this.m_tabColonnes, function(oColonne)
	{
		// GP 02/03/2020 : QW323507 : Ignore les attributs qui n'ont pas bGetVisible (car ils sont forc�ment invisibles).
		if ((oColonne instanceof WDTableColonne) && oColonne.bGetVisible())
		{
			nColSpanRupture++;
			if (oColonne.m_bAjustable)
			{
				nColSpanRupture++;
				bDernierColonneVisibleEstRedimensionnable = true;
			}
			else
			{
				bDernierColonneVisibleEstRedimensionnable = false;
			}
		}
		return true;
	});
	if (bDernierColonneVisibleEstRedimensionnable)
	{
		nColSpanRupture--;
	}
	return nColSpanRupture;
};

// Trouve la valeur (de programmation) pour la lecture depuis le WL
WDTableNavigateur.prototype._voGetProprieteColonneAvecIndicePourWL = function _voGetProprieteColonneAvecIndicePourWL(nColonne, nLigne, ePropriete)
{
	// GP 03/01/2017 : TB106187 : Si on est dans le code de onchange/onblur d'une colonne de table, il faut utiliser la valeur saisie.
	// GP 08/07/2021 : TB122731 : Uniquement si c'est sur la colonne en saisie.
	if ((this.XML_CHAMP_PROP_NUM_VALEUR == ePropriete) && this.m_oCelluleSaisie.bGetPourPCodeSortie() && (this.m_oCelluleSaisie.m_nColonne == nColonne))
	{
		return this.__oGetValeurPourCellule(nLigne, nColonne, this.m_oCelluleSaisie.pfGetValeurNouvelle())
	}
	else
	{
		return WDTableZRNavigateur.prototype._voGetProprieteColonneAvecIndicePourWL.apply(this, arguments);
	
	}
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//		M�thodes internes g�n�rales

// GP 26/04/2018 : TB104916 : Semble ne plus �tre d'actualit�, l'appel du code est directement dans l'action donc avec ce branchement tout est fait en double.
//// GP 24/11/2013 : QW239209 : Branche les PCodes utilisateur des colonnes
//WDTableNavigateur.prototype.__BranchePCodesColonnes = function __BranchePCodesColonnes()
//{
//	clWDUtil.bForEachThis(this.m_tabColonnes, this, function(oColonne)
//	{
//		// Selon le type de la colonne
//		switch (oColonne.m_eTypeIDObjet)
//		{
//		case WDChamp.prototype.ms_nIDObjetCombo:
//			// Combo : le champ n'existe pas (uniquement pendant la saisie)
//			break;
//
//		case WDChamp.prototype.ms_nIDObjetInterrupteur:
//			// Interrupteur : se brancher sur le HTML (de chaque ligne)
//			this.__BranchePCodesColonneInterrupteur(oColonne);
//			break;
//
//		case WDChamp.prototype.ms_nIDObjetImage:
//			// Image : se brancher sur le HTML
//			this.__BranchePCodesColonneImage(oColonne);
//			break;
//
//		case WDChamp.prototype.ms_nIDObjetSaisie:
//			// Saisie : le champ n'existe pas (uniquement pendant la saisie)
//			break;
//		}
//
//		// Continue sur la colonne suivante
//		return true;
//	});
//};
//WDTableNavigateur.prototype.__BranchePCodesColonneInterrupteur = function __BranchePCodesColonneInterrupteur(oColonne)
//{
//	// Interrupteur : se brancher sur le HTML (de chaque ligne) pour focus, change et blur
//	this.__BrancheUnPCodeUneColonne(oColonne, this.ms_nEventNavBlur, "blur", "input");
//	this.__BrancheUnPCodeUneColonne(oColonne, this.ms_nEventNavChange, "change", "input");
//	this.__BrancheUnPCodeUneColonne(oColonne, this.ms_nEventNavFocus, "focus", "input");
//};
//WDTableNavigateur.prototype.__BranchePCodesColonneImage = function __BranchePCodesColonneImage(oColonne)
//{
//	// Image : se brancher sur le HTML (de chaque ligne) pour onload et onclick
//	this.__BrancheUnPCodeUneColonne(oColonne, this.ms_nEventNavClick, "click", "img");
//	this.__BrancheUnPCodeUneColonne(oColonne, this.ms_nEventNavLoad, "load", "img");
//};
//WDTableNavigateur.prototype.__BrancheUnPCodeUneColonne = function __BrancheUnPCodeUneColonne(oColonne, eEvent, sEvent, sBalise)
//{
//	// Regarde si un PCode est d�fini
//	var fPCode = clWDUtil.pfGetTraitementDirect(oColonne.m_sAlias, eEvent);
//	if (fPCode)
//	{
//		// Branche le(s) PCode(s) pour chaque ligne (affich�e)
//		var nLigneWL = 1;
//		var oDiv;
//		var nColonne = oColonne.m_nRangCreation;
//		while ((oDiv = this.oGetIDElement(nLigneWL, nColonne)))
//		{
//			var tabElements = oDiv.getElementsByTagName(sBalise);
//			// Passe par une fonction pour faire une closure sur l'indice de ligne
//			// Normalement il n'y a que un seul �l�ment par cellule
//			this.__BrancheUnPCodeUnElement(tabElements[0], sEvent, fPCode, this._nLigneWLLigne(nLigneWL));
//			nLigneWL++;
//		}
//	}
//};
//WDTableNavigateur.prototype.__BrancheUnPCodeUnElement = function __BrancheUnPCodeUnElement(oElement, sEvent, fPCode, nLigne)
//{
//	// Branche directement (au lieu de faire un AttacheDetacheEvent) pour ne paas avoir a d�tacher
//	var oThis = this;
//	oElement["on" + sEvent] = function(oEvent) { return oThis.__oAppelPCodeSurLigne(nLigne, fPCode, oEvent || event); }
//};

// V�rifie si la zone cliente a un ascenseur vertical et fait la synchro avec la zone de titre
WDTableNavigateur.prototype.__SynchroniseTitre = function __SynchroniseTitre()
{
	// GP 17/11/2013 : Uniquement si la table est avec des titres de colonnes
	if (this.m_oTitrePosPixel)
	{
		var oHoteParent = this.m_oHote.parentNode;
		var oTitreParent = this.m_oTitrePosPixel.parentNode;

		// Fixe le margin de la zone de titre
		var nLargeurAscenseurVertical = this._nGetLargeurAscenseurVertical(oHoteParent);
		// GP 21/11/2013 : QW238685 : margin-right ne fonctionne pas, il faut manipuler le parent sur padding-right
		oTitreParent.parentNode.style.paddingRight = (nLargeurAscenseurVertical <= 0) ? "" : (nLargeurAscenseurVertical + "px");

		// Synchronise le scroll du titre
		this.__SynchroniseTitreScroll();
	}
};

// Synchronise le scroll du titre
WDTableNavigateur.prototype.__SynchroniseTitreScroll = function __SynchroniseTitreScroll()
{
	// Pas besoin de filtrer sur this.m_oTitrePosPixel, le filtre a d�j� �t� fait avant
	this.m_oTitrePosPixel.parentNode.scrollLeft = this.m_oHote.parentNode.scrollLeft;
};

// G�n�re une ligne du HTML
WDTableNavigateur.prototype.__HTMLGenereLigne = function __HTMLGenereLigne(nLigne, nLigneAffiche, oLigne, oContenuLigne, tabHTML)
{
	// Si on est dans les titres nLigne et oLigne sont non d�finis

	// G�n�re le d�but de la ligne
	this.__HTMLGenere(nLigne, nLigneAffiche, oLigne, oContenuLigne.debut, tabHTML);

	// GP 28/11/2014 : QW252618 : Si la ligne est repli� : ne l'affiche pas
	// GP 19/04/2017 : TB97537 : oLigne est invalide dans le cas de la ligne de titre
	if ((!oLigne) || oLigne.bGetDeroule())
	{
		// G�n�re les colonnes
		var tabPositionAffichage = this.m_oAffichageColonnes.m_tabPositionAffichage;
		var tabContenuColonnes = oContenuLigne.contenu;
		var nColonneAffichage;
		var nLimiteColonneAffichage = tabPositionAffichage.length;
		for (nColonneAffichage = 0; nColonneAffichage < nLimiteColonneAffichage; nColonneAffichage++)
		{
			var oColonne = tabPositionAffichage[nColonneAffichage].m_oColonne;
			// Seulement si la colonne est affich�e
			if (oColonne.bGetVisible())
			{
				// G�n�re le contenu de la colonne en trouvant son HTML � sa position de cr�ation
				this.__HTMLGenere(nLigne, nLigneAffiche, oLigne, tabContenuColonnes[oColonne.m_nRangCreation], tabHTML);
			}
		}
	}

	// G�n�re la fin de la ligne
	this.__HTMLGenere(nLigne, nLigneAffiche, oLigne, oContenuLigne.fin, tabHTML);
};

// Parse le HTML d�crit dans un element (on ne connait pas encore le type de l'�l�ment
WDTableNavigateur.prototype.__oHTMLParseElement = function __oHTMLParseElement(oSourceHTML)
{
	// Si l'�l�ment est un tableau
	if (oSourceHTML instanceof Array)
	{
		return this.__oHTMLParseTableau(oSourceHTML);
	}
	else if ("string" === typeof oSourceHTML)
	{
		return this.__oHTMLParseChaine(oSourceHTML);
	}
	else if (oSourceHTML instanceof Object)
	{
		return this.__oHTMLParseObjet(oSourceHTML);
	}
	else
	{
		// Impossible
		return {};
	}
};

// Parse le HTML d�crit dans un element de type "Array"
WDTableNavigateur.prototype.__oHTMLParseTableau = function __oHTMLParseTableau(tabSourceHTML)
{
	var tabSourceHTMLParse = [];

	var nElement;
	var nLimiteElement = tabSourceHTML.length;
	for (nElement = 0; nElement < nLimiteElement; nElement++)
	{
		tabSourceHTMLParse.push(this.__oHTMLParseElement(tabSourceHTML[nElement]));
	}

	return tabSourceHTMLParse;
};

// Parse le HTML d�crit dans un element de type "string"
WDTableNavigateur.prototype.__oHTMLParseChaine = WDTableZRNavigateur.prototype.__tabHTMLParse;

// Parse le HTML d�crit dans un element de type "objet"
WDTableNavigateur.prototype.__oHTMLParseObjet = function __oHTMLParseObjet(oSourceHTML)
{
	var oSourceHTMLParse = {};

	// Parse chacun des �l�ments
	for (var sCle in oSourceHTML)
	{
		if (oSourceHTML.hasOwnProperty(sCle))
		{
			oSourceHTMLParse[sCle] = this.__oHTMLParseElement(oSourceHTML[sCle]);
		}
	}

	return oSourceHTMLParse;
};

// Appele une propri�t� sur une colonne combo
WDTableNavigateur.prototype._xoGetColonneComboSelonAlias = function _xoGetColonneComboSelonAlias (sAliasColonne, bModifieTable)
{
	if (bModifieTable)
	{
		// Si on modifie la table, lance le r�affichage (qui n'est pas instantann�)
		this._TableAffiche();
	}

	// Retourne la colonne pour effectu� la modification dessus.
	return this._xoGetColonneSelonAlias(sAliasColonne);
};

// Indique si une colonne est la derni�re colonne visible (par ordre d'affichage)
// nColonne est le num�ro de la colonne dans l'ordre de cr�ation
WDTableNavigateur.prototype.bDerniereColonneVisible = function bDerniereColonneVisible(nColonne)
{
	return this.m_oAffichageColonnes.bDerniereColonneVisible(this._oGetColonne(nColonne).m_nPositionAffichage);
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis le HTML

// GP 18/11/2013 : On ne fait il est plus simple de ne rien bloquer et de laisser l'�venement se propager
//WDTableNavigateur.prototype.bClickInterrupteur = function bClickInterrupteur(oEvent, oInterrupteur, nLigneC, nColonne)
WDTableNavigateur.prototype.OnClickInterrupteur = function OnClickInterrupteur(oEvent, oInterrupteur, nLigneC, nColonne)
{
	this.SetValeurCellule(nLigneC, nColonne, function (bEntier)
	{
		if (oInterrupteur.checked)
		{
			return bEntier ? 1 : "1";
		}
		else
		{
			return bEntier ? 0 : "0";
		}
	});

	// GP 18/11/2013 : On ne fait il est plus simple de ne rien bloquer et de laisser l'�venement se propager
//	// GP 18/11/2013 : QW239195 : Redessine la ligne (car on bloque la propagation de l'�venement
//	this._TableAfficheLigne(nLigneC);
//
//	return clWDUtil.bStopPropagation(oEvent);
};

// Gestion du redimensionnement d'une colonne : appel lors du onmousedown
WDTableNavigateur.prototype.OnRedimCol = function OnRedimCol(oEvent, nColonne, nTailleMinimale)
{
	// Appel notre gestionnaire de redimensionnement
	this.m_oAffichageColonnes.bOnMouseDown(oEvent, nColonne, nTailleMinimale);
};

// Click sur une ligne
WDTableNavigateur.prototype.OnSelectLigne = function OnSelectLigne(nLigneWL, nColonne, oEvent, bColonneLien)
{
	this.m_oSelection.OnSelectLigne(this._nLigneWLLigne(nLigneWL, undefined, undefined, undefined, true), nColonne, oEvent, bColonneLien);
};

// Gestionnaire du tri des colonnes
WDTableNavigateur.prototype.OnTriColonne = function OnTriColonne(nColonne/*, oEvent*/)
{
	// Si la colonne n'est pas tri�e, tri en croissant
	var bCroissant = true;
	// Si la colonne est d�j� tri�e, inverse son tri
	var nRangColonneTri = clWDUtil.nDansTableauFct(this.m_tabTri, this.__s_bCompareRTFParColonne, nColonne);
	if (clWDUtil.nElementInconnu != nRangColonneTri)
	{
		bCroissant = !this.m_tabTri[nRangColonneTri].m_bCroissant;
	}

	// Tri sur la colonne (fait le r�affichage et le redessin des pictos)
	this._TriSurUneColonne(nColonne, bCroissant);
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis WDPopupSaisieTRF

// Lance la recherche sur une colonne
WDTableNavigateur.prototype.OnRecherche = function OnRecherche(oEvent, nColonne, sValeur)
{
	// Annule le filtre sur cette colonne (d�clenche un r�affichage)
	var bFiltreChange = this._bDesactiveFiltreUneColonne(nColonne);
	// Si cette colonne �tait filtr�e : r�applique le filtre SANS afficher la table
	// (la recherche dans la colonne peut d�clencher un tri qui fait un r�affichage)
	this._Refiltre(bFiltreChange, false);

	// Tri de la colonne
	this._TriSurUneColonne(nColonne, true);

	// Recherche la ligne dans la table
	// 0 : Commence sur la premi�re ligne
	var nLigne = this.__nLigneCherche([nColonne], sValeur, clWDUtil.nRechercheCommencePar, 0);

	// S�lectionne la ligne recherch�e (ou la premi�re ligne
	if (this.ms_nLigneInvalide != nLigne)
	{
		this.m_oSelection.ReinitSelection(nLigne);
	}

	// Affichage de la table : depuis le d�but et affiche la ligne trouv� (affiche le d�but de la table si non trouv�)
	this._TableAfficheLigne(0, nLigne);
};

// Lance le filtrage sur une colonne
WDTableNavigateur.prototype.OnFiltre = function OnFiltre(oEvent, nColonne, nFiltre, sValeur)
{
	// Ajout du filtre
	this._ActiveFiltre(nColonne, nFiltre, sValeur)
};

// Annule le filtre
WDTableNavigateur.prototype.OnAnnuleFiltre = function OnAnnuleFiltre(oEvent, nColonne)
{
	// D�sactive le filtre sur cette colonne
	var bFiltreChange = this._bDesactiveFiltreUneColonne(nColonne);
	// Si cette colonne �tait filtr�e : r�applique le filtre et affiche la table
	this._Refiltre(bFiltreChange, true);
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis WDCelluleSaisie

// Indique le type de la colonne
WDTableNavigateur.prototype.eColonneTypeIDObjet = function eColonneTypeIDObjet(nColonne)
{
	// Sinon on renvoie la valeur dans le tableau
	return this.m_tabColonnes[nColonne].m_eTypeIDObjet;
};

// Indique si la colonne donnee est saisissable
WDTableNavigateur.prototype.bColonneSaisissable = function bColonneSaisissable(nColonne)
{
//	// Si la colonne n'est pas dans le tableau => Pas saisissable
//	if ((nColonne >= this.m_tabColonnes.length) || (nColonne < 0))
//	{
//		return false;
//	}

	// @@@ Ne tient pas compte des colonnes lien pour le moment
//	// Si la colonne est lien elle n'est pas saisissable
//	if (this.m_tabColonnes[nColonne].m_nLien != 0)
//	{
//		return false;
//	}

	// Sinon on renvoie la valeur dans le tableau
	return this.m_tabColonnes[nColonne].bGetSaisissable();
};

// Recupere le contenu d'une cellule
WDTableNavigateur.prototype.sGetValeurCellule = function sGetValeurCellule(nLigne, nColonne)
{
	// Demande la valeur affich�e (on va afficher la valeur dans la cellule de la table)
	// GP 18/05/2015 : QW257874 : Demande la valeur affich�e puisque l'on va �tre en saisie dans le champ
	return this._oGetProprieteColonneAvecIndice(nColonne, nLigne, nLigne, this.XML_CHAMP_PROP_NUM_VALEUR, true);
};
WDTableNavigateur.prototype.nGetValeurCellule = function nGetValeurCellule(nLigne, nColonne)
{
	// Demande la valeur affich�e (on va afficher la valeur dans la cellule de la table)
	// Normalement inutile ici (on est une valeur num�rique, la valeur affich�e ne change pas)
	var oValeur = this._oGetProprieteColonneAvecIndice(nColonne, nLigne, nLigne, this.XML_CHAMP_PROP_NUM_VALEUR);
	// Si la valeur actuelle est un num�rique
	switch (typeof oValeur)
	{
	case "number":
		// - 1 : Passage en indice C
		return oValeur - 1;
	default:
		return this.m_tabColonnes[nColonne].nCherche(oValeur, true, 0);
	}
};

// Indique que l'on a change la valeur de la colonne donnee
WDTableNavigateur.prototype.SetValeurCellule = function SetValeurCellule(nLigne, nColonne, pfGetValeurNouvelle)
{
	this.m_tabLignes[nLigne].tabGetValeurs()[nColonne] = this.__oGetValeurPourCellule(nLigne, nColonne, pfGetValeurNouvelle);
};
// Conversion de la valeur saisie vers la valeur interne
WDTableNavigateur.prototype.__oGetValeurPourCellule = function __oGetValeurPourCellule(nLigne, nColonne, pfGetValeurNouvelle)
{
	switch (this.eColonneTypeIDObjet(nColonne))
	{
	case WDChamp.prototype.ms_nIDObjetCombo:
		// Si la valeur actuelle est un num�rique, �crit le num�rique, sinon �crit la chaine
		switch (typeof this.m_tabLignes[nLigne].tabGetValeurs()[nColonne])
		{
		case "number":
			// + 1 : Passage en indice WL
			return pfGetValeurNouvelle(true) + 1;
		default:
			break;
	}
	// Pas de break;
	default:
		return pfGetValeurNouvelle(false);
	}
};

// Renvoie le tableaux des options d'une cellule combo
WDTableNavigateur.prototype.tabContenuCellule = function tabContenuCellule(nLigne, nColonne)
{
	// Dans le futur, si on code ..Contenu sur les cellules de table, ici il faudra consulter le ..Contenu de la cellule
	return this.m_tabColonnes[nColonne].m_tabOptions;
};

// Recupere la cellule
WDTableNavigateur.prototype.oGetIDCelluleRel = function oGetIDCelluleRel(nLigne, nColonne)
{
	// m_nLigne est une ligne RELATIVE (ou WL selon le type de table) !!!
	return this.oGetIDElement(this._nLigneLigneWL(nLigne), nColonne);
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis WDAffichageColonnes

// Indique que l'ordre des colonnes a chang�
WDTableNavigateur.prototype.ChangeOrdreColonne = function ChangeOrdreColonne(bDepuisIHM/*, oColonne*/)
{
	// D�clenche la m�morisation de l'ordre des colonnes
	if (bDepuisIHM)
	{
		var oPosition = new WDPositionColonnes(null);
		oPosition.vSauve(this.m_tabColonnes);
		WDPosition.prototype.s_Ajoute(oPosition, this.m_sAliasChamp);
	}

	// Redessine la table et indiquant de conserver le scroll et de redessiner les titres de colonnes
	this._TableAffiche(clWDTableDefs.ms_nOptionTAPreserveScroll + clWDTableDefs.ms_nOptionTARedessineTitre);
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Interface des tables (impl�ment�s dans WDTable et WDTableNavigateur)
//		Appel depuis WDPositionColonnes

WDTableNavigateur.prototype.SetColonnePositionAffichage = function SetColonnePositionAffichage(tabPositionAffichage)
{
	var nLimiteColonne = tabPositionAffichage.length;

	// GP 19/11/2013 : Valide le tableau : on s'assure que le contenu est valable pour cette table
	if ((nLimiteColonne == this.m_tabColonnes.length) && clWDUtil.bForEach(tabPositionAffichage, function(nPositionAffichage) { return (0 <= nPositionAffichage) && (nPositionAffichage < nLimiteColonne); }))
	{
		// Lib�ration du lien entre le HTML des colonnes et le DnD
		this.m_oAffichageColonnes.LibereTitres();

		var nColonne;
		for (nColonne = 0; nColonne < nLimiteColonne; nColonne++)
		{
			this.m_tabColonnes[nColonne].m_nPositionAffichage = tabPositionAffichage[nColonne];
		}

		// RAZ du tableau de this.m_oAffichageColonnes
		this.m_oAffichageColonnes.Init(this.m_tabColonnes);

		// Indique que l'ordre des colonnes a chang�
		this.ChangeOrdreColonne(false);
	}
};

//////////////////////////////////////////////////////////////////////////
// WDTableNavigateur
//	Acc�s pour le WL

WDTableNavigateur.prototype.DeplaceColonne = function DeplaceColonne(sAliasColonne, nPositionAffichageNewWL)
{
	// Validation des param�tres :
	// - Recherche la colonne
	// GP 15/11/2013 : QW238712 : On doit transmettre � DeplaceColonne la colonne, pas le num�ro de la colonne.
	var oColonne = this._xoGetColonneSelonAlias(sAliasColonne);
	// - Recherche la destination
	var nNbColonnes = this._nGetNbColonnes();
	if ((nPositionAffichageNewWL < 1) || (nNbColonnes < nPositionAffichageNewWL))
	{
		// Erreur fatale WL :
		// "L'indice sp�cifi� %1 est invalide : les valeurs valides sont comprises entre %2 et %3."
		throw new WDErreur(301, nPositionAffichageNewWL, 1, nNbColonnes);
	}
	// Appel de la m�thode interne
	this.m_oAffichageColonnes.DeplaceColonne(oColonne, nPositionAffichageNewWL - 1);
};

// Donne l'ordre de cr�ation ou d'affichage d'une colonne
WDTableNavigateur.prototype.IndiceColonne = function IndiceColonne(sAliasColonne, nInformation)
{
	// Validation des param�tres :
	// - Recherche la colonne
	var nColonne = this._xnGetColonneSelonAlias(sAliasColonne);
	// - G�re les param�tres optionnnels WL
	if (undefined === nInformation)
	{
		nInformation = this.ms_nTicCreation;
	}

	switch (nInformation)
	{
	case this.ms_nTicAffichage:
		// Affichage
		// GP 08/11/2013 : QW238721 : Retourne un indice WL
		return this.m_tabColonnes[nColonne].m_nPositionAffichage + 1;
	default:
		// Pas d'erreur (le code serveur ne fait rien ou lance un warning)
	case this.ms_nTicCreation:
		// Cr�ation
		// GP 08/11/2013 : QW238721 : Retourne un indice WL
		return nColonne + 1;
	}
};

// Indique si on est en cours de saisie dans la table
WDTableNavigateur.prototype.SaisieEnCours = function SaisieEnCours()
{
	// Si on est en cours de saisie dans une cellule ou si on est en saisie dans la recherche
	return this.m_oPopupSaisieTRF.bSaisieEnCours() || this.m_oCelluleSaisie.bSaisieEnCours();
};

// Lance la saisie dans la recherche/filtrage d'une colonne
WDTableNavigateur.prototype.SaisieLoupe = function SaisieLoupe(sAliasColonne, nFiltre, sValeurInitiale)
{
	// Trouve la colonne
	var nColonne = this._xnGetColonneSelonAlias(sAliasColonne);
	// GP 08/11/2013 : QW238739 : Autorise la syntaxe avec un seul param�tre
	if (undefined === nFiltre)
	{
		nFiltre = 0;
	}
	// GP 15/11/2013 : QW238757 : Et il faut g�rer le cas ou il manque le troisi�me param�tre est absent
	if (undefined === sValeurInitiale)
	{
		sValeurInitiale = "";
	}
	// Et entre en saisie dans cette colonne
	// GP 15/11/2013 : QW238757 : Et il faut g�rer le cas ou il manque le troisi�me param�tre est absent
	this.m_oPopupSaisieTRF.OnSaisieLoupe(null, nColonne, nFiltre, sValeurInitiale);
};

// <R�sultat> = ListeCherche(<Colonne>)
WDTableNavigateur.prototype.ChercheDansColonne = function ChercheDansColonne(sAliasColonne, sValeur, bRechercheIdentique, nDebutWL)
{
	// bRechercheIdentique : param�tre optionnel
	if (undefined === bRechercheIdentique)
	{
		// Param�tre non sp�cifiqu�
		bRechercheIdentique = true;
	}
	else
	{
		// Conversion en bool�en
		bRechercheIdentique = !!bRechercheIdentique;
	}

	// nDebut : param�tre optionnel
	var nDebutC;
	if (undefined === nDebutWL)
	{
		// Param�tre non sp�cifiqu�
		nDebutC = 0;
	}
	else
	{
		// Conversion en entier et passage en indice C
		nDebutC = parseInt(nDebutWL, 10) - 1;
	}

	// false : ne modifie pas la table
	var nLigne = this._xoGetColonneComboSelonAlias(sAliasColonne, false).nCherche(sValeur, bRechercheIdentique, nDebutC);
	return (this.ms_nLigneInvalide != nLigne) ? nLigne + 1 : nLigne;
};
// <R�sultat> = ListeOccurrence(<Colonne>)
WDTableNavigateur.prototype.OccurrenceDansColonne = function OccurrenceDansColonne(sAliasColonne)
{
	// false : ne modifie pas la table
	return this._xoGetColonneComboSelonAlias(sAliasColonne, false).nGetOccurrence();
};
// ListeAjoute(<Colonne>)
WDTableNavigateur.prototype.AjouteDansColonne = function AjouteDansColonne(sAliasColonne, sValeur)
{
	// Ins�re � la fin
	this.InsereDansColonne(sAliasColonne, sValeur);
};
// ListeInsere(<Colonne>)
WDTableNavigateur.prototype.InsereDansColonne = function InsereDansColonne(sAliasColonne, sValeur, nPositionWL)
{
	// true : modifie la table
	var oColonne = this._xoGetColonneComboSelonAlias(sAliasColonne, true);
	oColonne.Insere(sValeur, oColonne.nGetPositionC(nPositionWL));
};
// ListeModifie(<Colonne>)
WDTableNavigateur.prototype.ModifieDansColonne = function ModifieDansColonne(sAliasColonne, sValeur, nPositionWL)
{
	// true : modifie la table
	var oColonne = this._xoGetColonneComboSelonAlias(sAliasColonne, true);
	oColonne.Modifie(sValeur, oColonne.xnGetPositionC(nPositionWL));
};
// ListeSupprime(<Colonne>)
WDTableNavigateur.prototype.SupprimeDansColonne = function SupprimeDansColonne(sAliasColonne, nPositionWL)
{
	// true : modifie la table
	var oColonne = this._xoGetColonneComboSelonAlias(sAliasColonne, true);
	oColonne.Supprime(oColonne.xnGetPositionC(nPositionWL));
};
// ListeSupprimeTout(<Colonne>)
WDTableNavigateur.prototype.SupprimeToutDansColonne = function SupprimeToutDansColonne(sAliasColonne)
{
	// true : modifie la table
	this._xoGetColonneComboSelonAlias(sAliasColonne, true).SupprimeTout();
};

WDTableNavigateur.prototype._xvoGetInfoXY = WDTableClassique.prototype._xvoGetInfoXY;
