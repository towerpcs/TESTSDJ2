// WDTableZRCommun.js
/*! 27.0.2.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - La page
///#GLOBALS _PU_
// - StdAction.js
///#GLOBALS _JCL _JGE
// - WDUtil.js
///#GLOBALS bIE bIEQuirks nIE bIEQuirks9Max bIEAvec11 bFF WDPopupSaisie WDErreur WDToastBase
// - WDChamp.js
///#GLOBALS WDChamp WDChampParametresHote WDMenuContextuel
// - WDDrag.js
///#GLOBALS WDDrag WDDnDNatif
// - WWConstanteX.js
///#GLOBALS TABLE_EXPORT TABLE_FILTRE
// - Autres
///#GLOBALS $

// Code commun aux :
// - Tables navigateur
// - Zone r�p�t�es navigateur
// - Tables AJAX
// => Partage des classes de bases
// => Partage des classes utilitaires (tri, menu, recherche etc)

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	clWDTableDefs
//		Constantes et algo statiques des tables et zones r�p�tees
var clWDTableDefs =
{
	ID_POSITION_PIXEL: "POS",
	ID_TITRE: "TITRES",
	ID_TRI: "TRI",
	ID_RECHERCHE: "RECH",
	ID_FORMAT: "FORMAT",

	ms_nOptionTAMontreLigne: (1 << 0),
	ms_nOptionTAPreserveScroll: (1 << 1),
	ms_nOptionTARedessineTitre: (1 << 2)
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDRupture
//		Rupture de table/zone r�p�t�e navigateur
// H�rite de clWDUtil.WDObjet
function WDRupture (sAliasHaut, sAliasBas, nColonne, bVisibleHaut, bVisibleBas)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		clWDUtil.WDObjet.prototype.constructor.apply(this, [sAliasHaut]);

		this.m_sAliasBas = sAliasBas;
		this.m_nColonne = nColonne;
		this.m_bVisibleHaut = bVisibleHaut;
		this.m_bVisibleBas = bVisibleBas;
	}
};

// Declare l'heritage
WDRupture.prototype = new clWDUtil.WDObjet();
// Surcharge le constructeur qui a ete efface
WDRupture.prototype.constructor = WDRupture;

// Recupere un PCode navigateur de la rupture
WDRupture.prototype.RecuperePCode = function RecuperePCode(ePCodeNav, bHaut)
{
	return clWDUtil.pfGetTraitement(bHaut ? this.m_sAlias : this.m_sAliasBas, ePCodeNav);
};

// Indique si la rupture est visible
WDRupture.prototype.bVisible = function bVisible(bHaut)
{
	return bHaut ? this.m_bVisibleHaut : this.m_bVisibleBas;
};

// M�thode "autre" des tables : pour avoir TableIndiceRupture et ZoneR�p�t�eIndiceRupture sur toutes les tables/zone r�p�t�es
WDRupture.prototype.s_nGetIndice = function s_GetIndice(sAliasTable, bHaut, nIndiceRupture, nIndiceWL)
{
	if (bHaut)
	{
		var sBaseAliasRuptureHaut = sAliasTable + "-H-" + nIndiceRupture + "-";
		for (var nIndiceWLPourTest = nIndiceWL; 0 < nIndiceWLPourTest; nIndiceWLPourTest--)
		{
			// Si la rupture est pr�sente : on a notre indice.
			if (document.getElementById(sBaseAliasRuptureHaut + nIndiceWLPourTest))
			{
				return nIndiceWLPourTest;
			}
		}
	}
	else
	{
		var sBaseAliasRuptureBas = sAliasTable + "-B-" + nIndiceRupture + "-";
		var nIndiceWLLimite = WDChamp.prototype.s_nGetTableZROccurrence(sAliasTable);
		for (var nIndiceWLPourTest = nIndiceWL; nIndiceWLPourTest <= nIndiceWLLimite; nIndiceWLPourTest++)
		{
			// Si la rupture est pr�sente : on a notre indice.
			if (document.getElementById(sBaseAliasRuptureBas + nIndiceWLPourTest))
			{
				return nIndiceWLPourTest;
			}
		}
	}
	// Non trouv�
	return nIndiceWL;
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDColonne
//		Colonne de table/zone r�p�t�e navigateur
// H�rite de clWDUtil.WDObjet
function WDColonne(sAlias, eTypeWL, sAliasPourConversion)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		clWDUtil.WDObjet.prototype.constructor.apply(this, [sAlias]);

		// 16 = DSTRW
		this.m_eTypeWL = (undefined !== eTypeWL) ? eTypeWL : 16;

		// Regarde si on n'a pas une fonction de conversion
		var sNomConversionVersAffichage = "_SET_" + sAliasPourConversion + "_1";
		var sNomConversionDepuisAffichage = "_GET_" + sAliasPourConversion + "_1";
		// Si la cible est un champ (cas RAISON_CHAMP_MASQUE dans WDJs.dll) on ne manipule pas les sous-�l�ment.
		// Si la cible est une colonne (cas RAISON_COLONNE_MASQUE dans WDJs.dll) on manipule les sous-�l�ment.
		// Note : il faudrait faire un code plus robuste (y compris ne pas mettre le _C dans le cas des colonnes)
		if (sAlias == sAliasPourConversion)
		{
			sNomConversionVersAffichage += "_I";
			sNomConversionDepuisAffichage += "_I";
		}
		sNomConversionVersAffichage += "_C";
		sNomConversionDepuisAffichage += "_C";
		this.m_pfConversionVersAffichage = window[sNomConversionVersAffichage];
		this.m_pfConversionDepuisAffichage = window[sNomConversionDepuisAffichage];
	}
};

// Declare l'heritage
WDColonne.prototype = new clWDUtil.WDObjet();
// Surcharge le constructeur qui a ete efface
WDColonne.prototype.constructor = WDColonne;

// Transformation en valeur "interne" (= valeur de programmation = valeur sans mise en forme)
WDColonne.prototype.oGetValeurInterne = function oGetValeurInterne(oValeur, bPourNouvelleLigneVirtuelle)
{
	if (oValeur !== undefined)
	{
		// Normalement impossible dans le cas bPourNouvelleLigneVirtuelle
		return this._voGetValeurInterne(oValeur);
	}
	else
	{
		return this._voGetValeurDefaut(bPourNouvelleLigneVirtuelle);
	}
};
WDColonne.prototype._voGetValeurInterne = function _voGetValeurInterne(oValeur)
{
	// Temporaire : si c'est un booleen on le garde en booleen, il sera convertit bien assez tot
	switch (typeof oValeur)
	{
	case "boolean":
		return oValeur;
	default:
		// GP 13/02/2013 : QW228908 : Utilise le type du cast
		return clWDUtil.oConversionType(oValeur, this.m_eTypeWL);
	}
};
// Valeur par d�faut
WDColonne.prototype._voGetValeurDefaut = function _voGetValeurDefaut(/*bPourNouvelleLigneVirtuelle*/)
{
	return "";
};

// Retourne la m�thode de comparaison pour le tri selon les options de la colonne
WDColonne.prototype.fGetCompare = function fGetCompare(nTypeRecherche)
{
	return clWDUtil.fGetCompare(nTypeRecherche);
};

// Lit une propri�t� de la colonne
WDColonne.prototype.vsLitPropriete = function vsLitPropriete(oChamp, nColonne, nLigne, nLigneAffiche, oLigne, ePropriete, bValeurAffichee)
{
	switch (ePropriete)
	{
	default:
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR:
		// Retourne la valeur d'affichage de la colonne
		return this.oGetValeurAvecLigne(nColonne, oLigne, bValeurAffichee);
	}
};

// Lit la valeur de colonne
WDColonne.prototype.oGetValeurAvecLigne = function oGetValeurAvecLigne(nColonne, oLigne, bValeurAffichee)
{
	var oValeur = oLigne.tabGetValeurs()[nColonne];

	// Si on demande la valeur affich�e et que l'on a une fonction de conversion
	if (bValeurAffichee && this.m_pfConversionVersAffichage)
	{
		oValeur = this.m_pfConversionVersAffichage(oValeur);
	}
	return oValeur;
};

WDColonne.prototype.bEstTexte = function bEstTexte()
{
	switch (this.m_eTypeWL)
	{
	case 16: // WLT_DSTRW
	case 17: // WLT_CARA
	case 18: // WLT_PSTRA
	case 19: // WLT_DSTRA
//	case 20: // WLT_SQLQUERYW
//	case 21: // WLT_PASCAL
//	case 22: // WLT_FIXE
//	case 23: // WLT_ASCIIZ
	case 81: // WLT_CARW
	case 110: // WLT_PSTRW
	case 134: // WLT_SQLQUERYA
		return true;
	default:
		return false;
	}
};
WDColonne.prototype.bEstNumerique = function bEstNumerique()
{
//	return (WLT_UI1 <= this.m_eTypeWL) && (this.m_eTypeWL <= WLT_HWND);
	return (2 <= this.m_eTypeWL) && (this.m_eTypeWL <= 15);
};
WDColonne.prototype.bEstDateHeure = function bEstDateHeure()
{
	switch (this.m_eTypeWL)
	{
	case 24: // WLT_DATEW
	case 25: // WLT_TIMEW
	case 26: // WLT_DATETIME
	case 27: // WLT_DUREE
	case 128: // WLT_DATEA
	case 129: // WLT_TIMEA
		return true;
	default:
		return false;
	}
};

//////////////////////////////////////////////////////////////////////////
// WDAttribut
// => Attribut de table/zone r�p�t�e navigateur
// H�rite de WDColonne
function WDAttribut(sAlias, eTypeWL, tabProprietesSpecifiques)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		var sAliasChampAssocie = tabProprietesSpecifiques[1];

		// Appel le constructeur de la classe de base
		WDColonne.prototype.constructor.apply(this, [sAlias, eTypeWL, sAliasChampAssocie && sAliasChampAssocie.length ? sAliasChampAssocie : sAlias]);

		// GP 18/02/2015 : QW254943 : Effectue la conversion vers la propri�t� principale une seule fois
		// Normalement c'est inutile car tous les chemins d'appels font la conversion (en particulier dans CConversionN1::__GenereAttributAutomatique)
		this.m_eProprieteAssocie = WDTableZRNavigateur.prototype.s_eGetProprietePrincipale(tabProprietesSpecifiques[0], tabProprietesSpecifiques[2]);
		this.m_sAliasChampAssocie = sAliasChampAssocie;
		this.m_eTypeChampAssocie = tabProprietesSpecifiques[2];
	}
};

// Declare l'heritage
WDAttribut.prototype = new WDColonne();
// Surcharge le constructeur qui a ete efface
WDAttribut.prototype.constructor = WDAttribut;

// Transformation en valeur "interne" (= valeur de programmation = valeur sans mise en forme)
//	=> oValeur est d�fini
WDAttribut.prototype._voGetValeurInterne = function _voGetValeurInterne(oValeur)
{
	switch (this.m_eProprieteAssocie)
	{
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_VISIBLE:
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEGRAS:
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEITALIQUE:
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICESOULIGNE:
		// On gere aussi le false en chaine (pour la concatenation en chaine de la constante false par le JS)
		return clWDUtil.bCastToBoolAvecChaine(oValeur);
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_ETAT:
		var oTemp = parseInt(oValeur + "", 10);
		if ((oTemp != WDChamp.prototype.ms_eEtatActif) && (oTemp != WDChamp.prototype.ms_eEtatLectureSeule) && (oTemp != WDChamp.prototype.ms_eEtatGrise))
		{
			oTemp = WDChamp.prototype.ms_eEtatActif;
		}
		return oTemp;
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICETAILLE:
		// Une taille chaine est possible
	default:
		// Appel de la methode de la classe de base
		return WDColonne.prototype._voGetValeurInterne.apply(this, arguments);
	}
};

// Valeur par d�faut
WDAttribut.prototype._voGetValeurDefaut = function _voGetValeurDefaut(/*bPourNouvelleLigneVirtuelle*/)
{
	switch (this.m_eProprieteAssocie)
	{
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_VISIBLE:
		return true;
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_ETAT:
		return WDChamp.prototype.ms_eEtatActif;
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEGRAS:
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEITALIQUE:
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICESOULIGNE:
		return false;
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICETAILLE:
		return 0;
	default:
		// Appel de la methode de la classe de base
		return WDColonne.prototype._voGetValeurDefaut.apply(this, arguments);
	}
};

// Lit une propri�t� de l'attribut
WDAttribut.prototype.vsLitPropriete = function vsLitPropriete(oChamp, nColonne, nLigne, nLigneAffiche, oLigne, ePropriete, bValeurAffichee)
{
	switch (ePropriete)
	{
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR:
	default:
		// Retourne la valeur d'affichage de la colonne
		// GP 14/04/2015 : TB81890 : Il tenir compte de la demande de valeur affich�e ou de valeur m�moris�e
		var oPropriete = this.oGetValeurAvecLigne(nColonne, oLigne, bValeurAffichee);
		// GP 10/03/2014 : TB83408
		if (bValeurAffichee)
		{
			switch (this.m_eProprieteAssocie)
			{
			case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR:
				// GP 20/02/2015 : QW255097 : Suite � QW254943, m_eProprieteAssocie contient maintenant ..Valeur dans le cas d'un champ image et pas ..Image
				if (WDChamp.prototype.ms_nIDObjetImage != this.m_eTypeChampAssocie)
				{
					break;
				}
				// Pas de break;
			case WDChamp.prototype.XML_CHAMP_PROP_NUM_IMAGE:
			case WDChamp.prototype.XML_CHAMP_PROP_NUM_VIGNETTE:
				oPropriete = clWDUtil.sGetCheminImage(oPropriete);
			}
		}
		return oPropriete;
	}
};

//////////////////////////////////////////////////////////////////////////
// WDTableColonne
// => Colonne de table (AJAX ou navigateur)
// H�rite de WDColonne
function WDTableColonne(sAlias, eTypeWL, tabProprietesSpecifiques)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDColonne.prototype.constructor.apply(this, [sAlias, eTypeWL, sAlias]);

		// tabProprietesSpecifiques :
		// - 0 : Type de la colonne (= saisie, interrupteur, etc)
		this.m_eTypeIDObjet = tabProprietesSpecifiques[0];
		// - 1 : Triable
		this.m_bTri = tabProprietesSpecifiques[1];
		// - 2 : Recherche
		this.m_nRecherche = tabProprietesSpecifiques[2];
		// - 3 : Filtre si filtre actif
		this.m_nFiltre = tabProprietesSpecifiques[3];
		// - 4 : Visible
		// C'est potentiellement une s�rie de valeur avec la visiblit� par tranche.
		// Note : la conversion en cha�ne n'est est utile pour le cas d'une page interne 24- fusionn�e dans une page 25+.
//		this.m_bVisible = tabProprietesSpecifiques[4];
		var oVisible = tabProprietesSpecifiques[4];
		// GP 21/11/2019 : QW320203: Array.prototype.map n'est pas disponible dans IE en mode HTML4.
//		this.m_tabVisible = ("boolean" === typeof oVisible) ? [oVisible] : String(oVisible).split(";").map(function (sVisible) { return "1" === sVisible; });
		this.m_tabVisible = ("boolean" === typeof oVisible) ? [oVisible] : (function ()
		{
			var tabVisibleChaines = String(oVisible);
			var tabVisible = new Array(tabVisibleChaines.length);
			clWDUtil.bForEach(tabVisibleChaines.split(";"), function (sVisible, nIndice)
			{
				tabVisible[nIndice] = "1" === sVisible;
				return true;
			});
			return tabVisible;
		})();
		// - 5 : Saisissable
		this.m_bSaisissable = tabProprietesSpecifiques[5];
		// - 6 : D�placable
		this.m_eDeplaceInsere = tabProprietesSpecifiques[6];
		// - 7 : Rang de cr�ation
		this.m_nRangCreation = tabProprietesSpecifiques[7];
		// - 8 : Position d'affichage
		this.m_nPositionAffichage = tabProprietesSpecifiques[8];
		// - 9 : Largeur (pour la persistance entre les affichages de la page pour une table AJAX
		this.m_nLargeur = tabProprietesSpecifiques[9];
		// - 10 : Options de la colonne (dans le cas d'une colonne de type combo (sinon null)
		// Si le tableau n'existe pas => c'est que l'on a une saturation : met la colonne en lecture seule
		// => G�r� dans WDTableColonne.prototype.bGetSaisissable
		this.m_tabOptions = tabProprietesSpecifiques[10];
		// - 11 : Si la colonne est ajustable
		this.m_bAjustable = tabProprietesSpecifiques[11];
		// - 12 : Couleur
		this.m_sCouleur = tabProprietesSpecifiques[12];
		// - 13 : CouleurFond
		this.m_sCouleurFond = tabProprietesSpecifiques[13];
		// - 14 : Mode d'affichage des images (pour les colonnes images)
		this.m_nModeAffichage = tabProprietesSpecifiques[14];
	}
};

// Declare l'heritage
WDTableColonne.prototype = new WDColonne();
// Surcharge le constructeur qui a ete efface
WDTableColonne.prototype.constructor = WDTableColonne;

// Pseudo valeur de filtre pour la recherche
WDTableColonne.prototype.ms_nFiltreRecherche = 0;
WDTableColonne.prototype.ms_nFiltreEgal = 31978;
WDTableColonne.prototype.ms_nFiltreCommencePar = 31979;
WDTableColonne.prototype.ms_nFiltreContient = 31980;
WDTableColonne.prototype.ms_nFiltreTerminePar = 31981;
WDTableColonne.prototype.ms_nFiltreDifferent = 31982;
WDTableColonne.prototype.ms_nFiltreNeCommencePasPar = 31983;
WDTableColonne.prototype.ms_nFiltreNeContientPas = 31984;
WDTableColonne.prototype.ms_nFiltreNeTerminePasPar = 31985;
WDTableColonne.prototype.ms_nFiltreSuperieur = 31986;
WDTableColonne.prototype.ms_nFiltreSuperieurOuEgal = 31987;
WDTableColonne.prototype.ms_nFiltreInferieur = 31988;
WDTableColonne.prototype.ms_nFiltreInferieurOuEgal = 31989;
//WDTableColonne.prototype.ms_nFiltreVide = 32048;

WDTableColonne.prototype.ms_nDISans = 0;
WDTableColonne.prototype.ms_nDIGauche = 1;
WDTableColonne.prototype.ms_nDIDroite = 2;
WDTableColonne.prototype.ms_nDIGaucheDroite = 3;
WDTableColonne.prototype.ms_nDIDeplace = 4;

// Mode d'affichage des images
// - Affichage en 100%, offset personnalis�
WDTableColonne.prototype.ms_eNormal = 1;
// - Affichage en 100%, centr�
WDTableColonne.prototype.ms_eCentre = 2;
// - Affichage �tir� du rectangle d'origine pour occuper toute la zone de destination
WDTableColonne.prototype.ms_eEtire = 3;
// - Affichage r�p�t� du rectangle d'origine pour occuper toute la zone toute la zone de destination
WDTableColonne.prototype.ms_eRepete = 4;
// - Affichage etir� homoth�tique du rectangle d'origine pour occuper au mieux la zone de destination
WDTableColonne.prototype.ms_eHomothetique = 5;
// - Idem homoth�tique mais centr�
WDTableColonne.prototype.ms_eHomothetiqueCentre = 6;
// - Idem homoth�tique, mais garde la plus petite proportion au lieu de la plus grande
WDTableColonne.prototype.ms_eHomothetiqueLarge = 7;
// -  Idem homoth�tique centr�, mais garde la plus petite proportion au lieu de la plus grande
WDTableColonne.prototype.ms_eHomothetiqueCentreLarge = 8;
// - Affichage en 100% s'il y a la place, Homoth�tique sinon
WDTableColonne.prototype.ms_eAdapte = 9;
// - Comme le pr�c�dent mais centr�
WDTableColonne.prototype.ms_eAdapteCentre = 10;
// - Le navigateur effectue une homoth�tie selon la largeur et pousse la hauteur du champ (la largeur peut �tre fixe ou ancr�e au navigateur, la hauteur est ancr�e au contenu)
WDTableColonne.prototype.ms_eNavigateurHomothetiqueLargeur = 11;
// - Le navigateur adapte la largeur (100% s'il y a la place, homoth�tique sinon) et pousse la hauteur du champ (la hauteur et la largeur sont ancr�es au contenu)
WDTableColonne.prototype.ms_eNavigateurAdapteLargeur = 12;
// - Le navigateur effectue une homoth�tie selon la largeur et tronque selon la hauteur du champ (la largeur et hauteur peuvent �tre fixes ou ancr�es au navigateur)
WDTableColonne.prototype.ms_eNavigateurHomothetiqueLargeurDebordementHauteur = 13;
// - Le navigateur adapte la largeur (100% s'il y a la place, homoth�tique sinon) et tronque selon la hauteur du champ (la largeur est au contenu, la hauteur peut �tre fixe ou ancr�e au navigateur)
WDTableColonne.prototype.ms_eNavigateurAdapteLargeurDebordementHauteur = 14;

// Recup�re l'evenement a utiliser pour brancher le redimensionnement sur le chargement d'une image dans une colone
WDTableColonne.prototype.ms_sEventPourChargementImage = (bIE ? "onreadystatechange" : "onload");
WDTableColonne.prototype.ms_sEventPourEchec = "onerror";
WDTableColonne.prototype.ms_sClasseImage = "wbColImage";

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableColonne
//		M�thodes surcharg�es de WDColonne

// Transformation en valeur "interne" (= valeur de programmation = valeur sans mise en forme)
WDTableColonne.prototype._voGetValeurInterne = function _voGetValeurInterne(oValeur)
{
	// Selon le type de la colonne
	switch (this.m_eTypeIDObjet)
	{
	case WDChamp.prototype.ms_nIDObjetCombo:
		// Combo : conserve les entiers en entiers et les chaines en chaines
		switch (typeof oValeur)
		{
		case "string":
		case "number":
			return oValeur;
		default:
			// Retourne la valeur comme la classe de base
			break;
		}
		break;

	case WDChamp.prototype.ms_nIDObjetInterrupteur:
		// Interrupteur : bool�en
		// On gere aussi le false en chaine (pour la concatenation en chaine de la constante false par le JS)
		return clWDUtil.bCastToBoolAvecChaine(oValeur);

	case WDChamp.prototype.ms_nIDObjetImage:
		// Image : chaine
		return oValeur + "";

	case WDChamp.prototype.ms_nIDObjetSaisie:
		// GP 13/02/2013 : QW228908 : Utilise le type du cast
		return clWDUtil.oConversionType(oValeur, this.m_eTypeWL);
	}

	return WDColonne.prototype._voGetValeurInterne.apply(this, arguments);
};
// Valeur par d�faut
WDTableColonne.prototype._voGetValeurDefaut = function _voGetValeurDefaut(bPourNouvelleLigneVirtuelle)
{
	// Selon le type de la colonne
	switch (this.m_eTypeIDObjet)
	{
	case WDChamp.prototype.ms_nIDObjetCombo:
		// Combo/liste de valeur
		// GP 16/01/2014 : QW241485 : Pas de valeur pour la combo d'une ligne virtuelle de table
		return bPourNouvelleLigneVirtuelle ? 0 : 1;

	case WDChamp.prototype.ms_nIDObjetInterrupteur:
		// Interrupteur : bool�en
		return false;

	case WDChamp.prototype.ms_nIDObjetImage:
		// Image : chaine
		return "";

	case WDChamp.prototype.ms_nIDObjetSaisie:
		// GP 13/02/2013 : QW228908 : Utilise le type du cast
		return clWDUtil.oConversionType("", this.m_eTypeWL);
	}
};

// R�cup�re la fonction de filtrage associ�e au filtre
WDTableColonne.prototype.s_xfGetFiltre = function s_xfGetFiltre(nFiltre)
{
	switch (nFiltre)
	{
	case this.ms_nFiltreEgal:
		return clWDUtil.s_bEgal;
	case this.ms_nFiltreCommencePar:
		return clWDUtil.s_bCommencePar;
	case this.ms_nFiltreContient:
		return clWDUtil.s_bContient;
	case this.ms_nFiltreTerminePar:
		return clWDUtil.s_bTerminePar;
	case this.ms_nFiltreDifferent:
		return clWDUtil.s_bDifferent;
	case this.ms_nFiltreNeCommencePasPar:
		return clWDUtil.s_bNeCommencePasPar;
	case this.ms_nFiltreNeContientPas:
		return clWDUtil.s_bNeContientPas;
	case this.ms_nFiltreNeTerminePasPar:
		return clWDUtil.s_bNeTerminePasPar;
	case this.ms_nFiltreSuperieur:
		return clWDUtil.s_bSuperieur;
	case this.ms_nFiltreSuperieurOuEgal:
		return clWDUtil.s_bSuperieurOuEgal;
	case this.ms_nFiltreInferieur:
		return clWDUtil.s_bInferieur;
	case this.ms_nFiltreInferieurOuEgal:
		return clWDUtil.s_bInferieurOuEgal;
//	case this.ms_nFiltreVide:
//		return clWDUtil.;
	default:
		// Erreur fatale WL :
		// "La valeur de la constante (%1) est invalide avec cette fonction.",
		throw new WDErreur(303, nFiltre);
	}
};

// Get/Set le mode de filtrage de la colonne (0 = recherche, 319xx = filtrage)
WDTableColonne.prototype.nGetFiltre = function nGetFiltre()
{
	return this.m_nFiltre;
};

WDTableColonne.prototype.SetFiltre = function SetFiltre(nFiltre)
{
	this.m_nFiltre = nFiltre;
};

// Indique si la colonne est visible (dans la tranche courante)
WDTableColonne.prototype.bGetVisible = function bGetVisible()
{
	// Le ..Visible que l'on re�oit est d�j� une valeur compos�e : c'est ..Visible et non masqu� dans la tranche.
	var nTrancheIndiceC = clWDUtil.bRWD ? ($.wb.nGetTrancheActiveIndiceWL(true) - 1) : 0;
	var bVisible = this.m_tabVisible[nTrancheIndiceC];
	// Le !! c'est pour le cas "undefined" de la valeur � l'indice 0 (n'arrive normalement pas).
	return (undefined !== bVisible) ? bVisible : !!(this.m_tabVisible[0]);
};

// Indique si la colonne est saisissable
WDTableColonne.prototype.bGetSaisissable = function bGetSaisissable()
{
	// Test le plus simple : si la colonne n'est pas saisissable
	if (!this.m_bSaisissable)
	{
		return false;
	}

	// Proprietes specifiques
	switch (this.m_eTypeIDObjet)
	{
	case WDChamp.prototype.ms_nIDObjetCombo:
		// Si le tableau n'existe pas => c'est que l'on a une saturation : met la colonne en lecture seule
		if (!this.m_tabOptions || (0 == this.m_tabOptions.length))
		{
			return false;
		}
		break;
	case WDChamp.prototype.ms_nIDObjetImage:
		// Jamais saisissable
		return false;
	case WDChamp.prototype.ms_nIDObjetSaisie:
		// Si la colonne est lien elle n'est pas saisissable
		if ((undefined !== this.m_nLien) && (0 != this.m_nLien))
		{
			return false;
		}
		break;
	}

	// Saisie autoris�e
	return true;
};

// Selon les possibilit�s de la colonne
WDTableColonne.prototype.bColonneInsereGauche = function bColonneInsereGauche()
{
	switch (this.m_eDeplaceInsere)
	{
	case this.ms_nDIGauche:
	case this.ms_nDIGaucheDroite:
	case this.ms_nDIDeplace:
		return true;
	default:
		return false;
	}
};
WDTableColonne.prototype.bColonneInsereDroite = function bColonneInsereDroite()
{
	switch (this.m_eDeplaceInsere)
	{
	case this.ms_nDIDroite:
	case this.ms_nDIGaucheDroite:
	case this.ms_nDIDeplace:
		return true;
	default:
		return false;
	}
};
WDTableColonne.prototype.bColonneInsereGaucheDroite = function bColonneInsereGaucheDroite()
{
	return this.ms_nDISans != this.m_eDeplaceInsere;
};
WDTableColonne.prototype.bColonneDeplace = function bColonneDeplace()
{
	return this.ms_nDIDeplace == this.m_eDeplaceInsere;
};

// Retourne le mode d'affichage de la colonne : inclus un flag pour le cas de la table avec hauteur de ligne adapt� au contenu.
WDTableColonne.prototype.nGetModeAffichageImage = function nGetModeAffichageImage(oChamp)
{
	return this.m_nModeAffichage + (oChamp.m_bHauteurLigneVariable ? 0x100 : 0);
};

// Lit une propri�t� de la colonne
WDTableColonne.prototype.vsLitPropriete = function vsLitPropriete(oChamp, nColonne, nLigne, nLigneAffiche, oLigne, ePropriete, bValeurAffichee)
{
	switch (ePropriete)
	{
	case WDTableZRNavigateur.prototype.ms_nAttributTriable:
		return this.m_bTri;
	case WDTableZRNavigateur.prototype.ms_nAttributRecherchable:
		return 0 < this.m_nRecherche;
	case WDTableZRNavigateur.prototype.ms_nAttributDerniereVisible:
		return oChamp.bDerniereColonneVisible(nColonne);
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR:
		// Lit la valeur de
		var oValeur = WDColonne.prototype.vsLitPropriete.apply(this, arguments);
		if (bValeurAffichee)
		{
			switch (this.m_eTypeIDObjet)
			{
			case WDChamp.prototype.ms_nIDObjetCombo:
				// Combo : retourne les chaines directement et fait la conversion des entiers en la valeur affich�e
				return this.__sLitValeurCombo(oValeur);

			case WDChamp.prototype.ms_nIDObjetInterrupteur:
				// Interrupteur : g�n�re le HTML
				return this.__sLitValeurInterrupteur(oValeur, oChamp, nColonne, nLigne);

			case WDChamp.prototype.ms_nIDObjetImage:
				// Image : g�n�re le HTML
				return this.__sLitValeurImage(oValeur, oChamp);

			case WDChamp.prototype.ms_nIDObjetSaisie:
				// Saisie : g�n�re le HTML (si on est un lien) ou la valeur
				return this.__sLitValeurSaiseOuLien(oValeur);
			}
		}
		return oValeur;
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEUR:
		// Si on demande la couleur de la colonne ou d'une cellule
		return this.__sLitCouleurColonneCellule(oChamp, nColonne, oLigne, nLigne, nLigneAffiche, false, bValeurAffichee);
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURFOND:
		// Si on demande la couleur de fond de la colonne ou d'une cellule
		return this.__sLitCouleurColonneCellule(oChamp, nColonne, oLigne, nLigne, nLigneAffiche, true, bValeurAffichee);
	default:
		return WDColonne.prototype.vsLitPropriete.apply(this, arguments);
	}
};
WDTableColonne.prototype.__sLitValeurCombo = function __sLitValeurCombo(oValeur)
{
	// Combo : retourne les chaines directement et fait la conversion des entiers en la valeur affich�e
	switch (typeof oValeur)
	{
	case "string":
		return oValeur;
	case "number":
		// La valeur est en indice WL
		if (this.m_tabOptions && (1 <= oValeur) && (oValeur <= this.m_tabOptions.length))
		{
			return this.m_tabOptions[oValeur - 1];
		}
		// GP 19/11/2013 : QW239263 : Retourne vide si l'option n'est pas dans la combo
		return "";
	// Default impossible (cast la valeur en �criture)
	}
	return oValeur;
};
WDTableColonne.prototype.__sLitValeurInterrupteur = function __sLitValeurInterrupteur(oValeur, oChamp, nColonne, nLigne)
{
	var tabHTML = ["<input type=\"checkbox\""];
	if (oValeur)
	{
		tabHTML.push(" checked");
	}
	if (this.bGetSaisissable())
	{
		// GP 18/11/2013 : On ne fait il est plus simple de ne rien bloquer et de laisser l'�venement se propager
		tabHTML.push(" onclick=\"oGetObjetChamp(\'");
		tabHTML.push(oChamp.m_sAliasChamp);
		tabHTML.push("\').OnClickInterrupteur(event,this,");
		tabHTML.push(nLigne);
		tabHTML.push(",");
		tabHTML.push(nColonne);
		tabHTML.push(");\"");
	}
	else
	{
		tabHTML.push(" disabled");
	}
	tabHTML.push(">");

	return tabHTML.join("");
};
WDTableColonne.prototype.__sLitValeurImage = function __sLitValeurImage(oValeur, oChamp)
{
	var tabHTML = [];

	// Creer un champ image avec la bonne source
	if (0 < oValeur.length)
	{
		tabHTML.push("<img src=\"");
		// GP 10/03/2014 : (Vu en corrigeant TB83408) Utilisation de clWDUtil.sGetCheminImage
		tabHTML.push(clWDUtil.sGetCheminImage(oValeur + ""));
//		tabHTML.push(_WD_);
//		tabHTML.push(oValeur);
		tabHTML.push("\" data-webdev-mode-affichage=\"");
		tabHTML.push(this.nGetModeAffichageImage(oChamp));
		tabHTML.push("\" class=\"");
		tabHTML.push(this.ms_sClasseImage);
		// L'image sera de toutes fa�ons dessin�e en transparent (utilisation de l'image de fond de la cellule parent)
		tabHTML.push("\" style=\"opacity:0\" ");

//		// @@@ Si la colonne est lien actif
//		if ((this.nColonneLien(nColonne) > 0) && ((this.nColonneEtatLien(nColonne) == 0) || (this.nColonneEtatLien(nColonne) == 5)))
//		{
//			oElement.onclick = function(oEvent) { oThis.OnColonneLien(nLigneAbsolue, nColonne, oEvent || event); };
//		}

		tabHTML.push(this.ms_sEventPourChargementImage);
		tabHTML.push("=\"WDTableZRNavigateur.prototype.s_RedimImageChargement(this);\">");
	}

	return tabHTML.join("");
};
WDTableColonne.prototype.__sLitValeurSaiseOuLien = function __sLitValeurSaiseOuLien(oValeur)
{
	// @@@ G�rer le cas des liens ici
	// GP 11/02/2014 : QW242548 : Encode la valeur pour �tre du HTML
	return clWDUtil.sEncodeInnerHTML(oValeur, true);
};

// Demande la couleur/couleur de fond de la colonne ou d'une cellule
WDTableColonne.prototype.__sLitCouleurColonneCellule = function __sLitCouleurColonneCellule(oChamp, nColonne, oLigne, nLigne, nLigneAffiche, bCouleurFond, bValeurAffichee)
{
	var sCouleurColonne = bCouleurFond ? this.m_sCouleurFond : this.m_sCouleur;

	// Si on demande la couleur de la colonne
	if (!oLigne)
	{
		return sCouleurColonne || "";
	}
	else
	{
		// On demande la couleur pour une cellule.
		// L'ordre de priorit� des couleurs (fond/texte) est (du plus au moins prioritaire):
		// - Couleur de ligne s�lectionn�e (style d'�dition)
		// - Couleur de la cellule (programmation)
		// - Couleur de la ligne (programmation)
		// - Couleur de la colonne (programmation)
		// - Couleur de la colonne (style d'�dition)
		// - Couleur de la ligne (style (pair/impair) d'�dition)
		// (- Couleur de la table (style d'�dition, fond seulement ?))
		// (- Couleur des conteneur de la table (style d'�dition, fond seulement ?))

		// - Couleur de ligne s�lectionn�e (style d'�dition) (uniquement pour le HTML)
		// Normalement on ne passe pas ici pour les tables AJAX, mais ontest quand m�me oChamp.m_oSelection au cas ou (non pr�sent dans les tables AJAX)
		if (bValeurAffichee && oChamp.m_oSelection && oChamp.m_oSelection.bGetLigneEstSelectionnee(nLigne))
		{
			var oStyleLigneSelectionne = oChamp.m_oStyleLigneSelectionne;
			var sCouleurLigneSelectionne = bCouleurFond ? oStyleLigneSelectionne.m_sCouleurFond : oStyleLigneSelectionne.m_sCouleur;
			if (sCouleurLigneSelectionne && sCouleurLigneSelectionne.length)
			{
				return sCouleurLigneSelectionne;
			}
		}

		// - Couleur de la cellule (programmation)
		var tabCouleurCellules = bCouleurFond ? oLigne.m_tabCouleurFond : oLigne.m_tabCouleur;
		if (tabCouleurCellules && tabCouleurCellules[nColonne] && tabCouleurCellules[nColonne].length)
		{
			return tabCouleurCellules[nColonne];
		}

		// - Couleur de la ligne (programmation)
		var sCouleurLigne = bCouleurFond ? oLigne.m_sCouleurFond : oLigne.m_sCouleur;
		if (sCouleurLigne && sCouleurLigne.length)
		{
			return sCouleurLigne;
		}

		// - Couleur de la colonne (programmation)
		// - Couleur de la colonne (style d'�dition)
		if (sCouleurColonne && sCouleurColonne.length)
		{
			return sCouleurColonne;
		}

		// - Couleur de la ligne (style (pair/impair) d'�dition)
		var oStyleLignePairImpair = ((nLigneAffiche % 2) == 0) ? oChamp.m_oStyleLigneImpair : oChamp.m_oStyleLignePair;
		var sCouleurLignePairImpair = bCouleurFond ? oStyleLignePairImpair.m_sCouleurFond : oStyleLignePairImpair.m_sCouleur;
		if (sCouleurLignePairImpair && sCouleurLignePairImpair.length)
		{
			return sCouleurLignePairImpair;
		}

		// (- Couleur de la table (style d'�dition, fond seulement ?))
		// (- Couleur des conteneur de la table (style d'�dition, fond seulement ?))
		return "";
	}
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDLigne
//		Ligne de table/zone rep�t�e navigateur
// On g�re les ruptures m�me si elle ne sont pas disponible dans les tables car elle le seront probablement un jour.
function WDLigne (nNbColonnes, bLigneVirtuelle)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Tableaux des valeurs
		this.m_tabValeurs = new Array(nNbColonnes);
		// Etat d'enroulement de la ligne : complement deroule
		// Pour le cache de l'etat, on ne garde par un flag par rupture effective mais on a le flag en general et il n'est lut que si on a une rupture
		// Plus on stocke l'etat dans un entier et on lit les bits (ce qui limite en pratique a 32 ruptures)
		// Cela evite des couteux tableaux d'etats
		this.m_nDeroule = this.ms_nTous;
		// Pareil pour les ruptures
		// L'etat sera MAJ lors de l'ajout dans la table
		this.m_nRupturesHaut = this.ms_nRien;
		this.m_nRupturesBas = this.ms_nRien;
		// Indique que la ligne a ete modifie (pour le PCode d'affichage : oui a la creation)
		this.m_bPCodeAffichage = false;
		this.m_bModifieRuptures = true;
		// V�rifie le filtre
		this.m_bVerifieFiltre = true;

		// Si la ligne est la ligne virtuelle
		this.m_bLigneVirtuelle = bLigneVirtuelle;
	}
};

WDLigne.prototype.ms_nRien = 0;
WDLigne.prototype.ms_nTous = (0xFFFFFFFF | 0); // Pour avoir -1 en entier

// Lecture des propri�t�s : construit un objet avec les valeurs effectives
WDLigne.prototype.oGetPropriete = function oGetPropriete(oStyleLigneSelectionne, oStyleLignePairImpair)
{
	var oProprietes = {};

	// On ne passe ici que pour la programmation.
//	if (bValeurAffichee && oStyleLigneSelectionne)
//	{
//		if (oStyleLigneSelectionne.m_sCouleur && oStyleLigneSelectionne.m_sCouleur.length)
//		{
//			oProprietes.m_sCouleur = oStyleLigneSelectionne.m_sCouleur;
//		}
//		if (oStyleLigneSelectionne.m_sCouleurFond && oStyleLigneSelectionne.m_sCouleurFond.length)
//		{
//			oProprietes.m_sCouleurFond = oStyleLigneSelectionne.m_sCouleurFond;
//		}
//	}

	// - Couleur de la ligne (programmation)
	if (!oProprietes.m_sCouleur && this.m_sCouleur && this.m_sCouleur.length)
	{
		oProprietes.m_sCouleur = this.m_sCouleur;
	}
	if (!oProprietes.m_sCouleurFond && this.m_sCouleurFond && this.m_sCouleurFond.length)
	{
		oProprietes.m_sCouleurFond = this.m_sCouleurFond;
	}

	// - Couleur de la ligne (style (pair/impair) d'�dition)
	if (!oProprietes.m_sCouleur && oStyleLignePairImpair.m_sCouleur && oStyleLignePairImpair.m_sCouleur.length)
	{
		oProprietes.m_sCouleur = oStyleLignePairImpair.m_sCouleur;
	}
	if (!oProprietes.m_sCouleurFond && oStyleLignePairImpair.m_sCouleurFond && oStyleLignePairImpair.m_sCouleurFond.length)
	{
		oProprietes.m_sCouleurFond = oStyleLignePairImpair.m_sCouleurFond;
	}

	return oProprietes;
};

// Lecture des valeurs
WDLigne.prototype.tabGetValeurs = function tabGetValeurs()
{
	return this.m_tabValeurs;
};

// Lecture des couleurs
WDLigne.prototype.tabGetCouleur = function tabGetCouleur()
{
	if (!this.m_tabCouleur)
	{
		this.m_tabCouleur = new Array(this.tabGetValeurs().length);
	}
	return this.m_tabCouleur;
};
WDLigne.prototype.tabGetCouleurFond = function tabGetCouleurFond()
{
	if (!this.m_tabCouleurFond)
	{
		this.m_tabCouleurFond = new Array(this.tabGetValeurs().length);
	}
	return this.m_tabCouleurFond;
};

// Indique que la ligne est modifie
WDLigne.prototype.SetModifieRuptures = function SetModifieRuptures(bRuptures)
{
	this.m_bModifieRuptures = this.m_bModifieRuptures || bRuptures;
};
WDLigne.prototype.bGetClearPCodeAffichage = function bGetClearPCodeAffichage()
{
	var bPCodeAffichage = this.m_bPCodeAffichage;
	this.m_bPCodeAffichage = true;
	return !bPCodeAffichage;
};
WDLigne.prototype.bGetClearModifieRuptures = function bGetClearModifieRuptures()
{
	var bModifieRuptures = this.m_bModifieRuptures;
	this.m_bModifieRuptures = false;
	return bModifieRuptures;
};

// Indique si on a une rupture
WDLigne.prototype.nGetRuptures = function nGetRuptures(bHaut)
{
	return bHaut ? this.m_nRupturesHaut : this.m_nRupturesBas;
};
WDLigne.prototype.bGetRupture = function bGetRupture(nRupture, bHaut)
{
	// Il faut aussi tester les ruptures precedentes
	return this.bGetRuptureDirect(nRupture, bHaut) || ((0 < nRupture) && this.bGetRupture(nRupture - 1, bHaut));
};
WDLigne.prototype.bGetRuptureDirect = function bGetRuptureDirect(nRupture, bHaut)
{
	return 0 != (this.nGetRuptures(bHaut) & (1 << nRupture));
};

// Indique si la rupture est visible
WDLigne.prototype.bGetRuptureVisible = function bGetRuptureVisible(nRupture, bHaut)
{
	// Si la ligne est enroule
	if (!this.bGetDeroule())
	{
		if (bHaut)
		{
			// Haut : Il ne faut pas que la ligne soit enroule sur une rupture precedente
			for (var nRupturePrecedente = nRupture - 1; 0 <= nRupturePrecedente; nRupturePrecedente--)
			{
				if (0 == (this.m_nDeroule & (1 << nRupturePrecedente)))
				{
					return false;
				}
			}
		}
		else
		{
			// Bas : il ne faut pas que la ligne soit enroule
			return false;
		}
	}

	return this.bGetRupture(nRupture, bHaut);
};

WDLigne.prototype.bGetDeroule = function bGetDeroule()
{
	return this.ms_nTous == this.m_nDeroule;
};

WDLigne.prototype.CopieEnrouleDeroule = function CopieEnrouleDeroule(oLigne, nRupture)
{
	var nBit = 1 << nRupture;
	if (0 == (oLigne.m_nDeroule & nBit))
	{
		// Enroule
		this.m_nDeroule &= ~nBit;
	}
	else
	{
		// Deroule
		this.m_nDeroule |= nBit;
	}
};

// Notifie de la suppression de la ligne
WDLigne.prototype.OnSupprime = function OnSupprime()
{
	// Libere explictement la memoire
	this.m_tabValeurs.length = 0;
};

// Enroule/deroule une rupture de la ligne
WDLigne.prototype.EnrouleDeroule = function EnrouleDeroule(nRupture, bDeroule, bRecursif)
{
	var nBit = 1 << nRupture;
	// Calcule l'inversion si besoin
	if (bDeroule === undefined)
	{
		bDeroule = (0 == (this.m_nDeroule & nBit));
	}
	if (bDeroule)
	{
		this.m_nDeroule |= nBit;
		// Plus deroule si demande les ruptures precedentes
		if (bRecursif && (0 < nRupture))
		{
			this.EnrouleDeroule(nRupture - 1, bDeroule, bRecursif);
		}
	}
	else
	{
		this.m_nDeroule &= ~nBit;
	}
};

// Indique si la ligne est enroul� sur une ruptur�
WDLigne.prototype.bEstEnroule = function bEstEnroule(nRupture)
{
	var nBit = 1 << nRupture;
	return 0 == (this.m_nDeroule & nBit);
};

// Fixe les ruptures
WDLigne.prototype.SetRupturesHaut = function SetRupturesHaut(nRuptures)
{
	// Prepare au deroule les ruptures modifiees
	var nDeroule = this.m_nRupturesHaut ^ nRuptures;

	this.m_nRupturesHaut = nRuptures;
	// Deroule les ruptures modifiees
	this.m_nDeroule |= nDeroule;
};
WDLigne.prototype.SetRupturesBas = function SetRupturesBas(nRuptures)
{
	this.m_nRupturesBas = nRuptures;
};

// Si la ligne v�rifie le filtre
WDLigne.prototype.bGetVerifieFiltre = function bGetVerifieFiltre()
{
	// La ligne virtuelle v�rifie toujours le filtre
	return this.m_bVerifieFiltre || this.bGetLigneVirtuelle();
};
WDLigne.prototype.SetVerifieFiltre = function SetVerifieFiltre(bVerifieFiltre)
{
	this.m_bVerifieFiltre = bVerifieFiltre;
};

// Gestion de la ligne virtuelle
WDLigne.prototype.bGetLigneVirtuelle = function bGetLigneVirtuelle()
{
	return this.m_bLigneVirtuelle;
};
WDLigne.prototype.RAZLigneVirtuelle = function RAZLigneVirtuelle()
{
	this.m_bLigneVirtuelle = false;
};
//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		Table/zone rep�t�e navigateur
// H�rite de WDChampParametresHote

// La table n'a normalement jamais de table/zr parente
function WDTableZRNavigateur(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChampParametresHote.prototype.constructor.apply(this, arguments);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees, eTypeSelection ]
		var eTypeSelection = tabParametresSupplementaires[2];

		// S�lection
		this.m_oSelection = new WDSelection(this, eTypeSelection);
		// Tableaux des colonnes/attributs
		this.m_tabColonnes = [];
		// Tableaux des ruptures
		this.m_tabRuptures = [];
		// Tableaux des lignes
		this.m_tabLignes = [];
		this.m_nNbLignesWL = 0;
		// Tri (tableau d'objets)
		this.m_tabTri = [];
		// Filtre (tableau d'objets)
		this.m_tabFiltre = [];

		// Par d�faut pas d'options pour l'affichage
		this.m_nTAOptions = 0;

		this.m_bDansOnSelectLigneExterne = false;

		// Se declare dans la table globale des Tables/ZRs AJAX
		this.ms_tabTablesZRs.DeclareChamp(this);
	}
};

// Declare l'heritage
WDTableZRNavigateur.prototype = new WDChampParametresHote();
// Surcharge le constructeur qui a ete efface
WDTableZRNavigateur.prototype.constructor = WDTableZRNavigateur;

WDTableZRNavigateur.prototype.ms_nLigneInvalide = -1;
WDTableZRNavigateur.prototype.ms_nColonneInvalide = -1;
WDTableZRNavigateur.prototype.ms_sDynO = "[%";
WDTableZRNavigateur.prototype.ms_sDynF = "%]";
WDTableZRNavigateur.prototype.ms_sDynSi = "[%SI%]";
WDTableZRNavigateur.prototype.ms_sDynAlors = "[%ALORS%]";
WDTableZRNavigateur.prototype.ms_sDynSinon = "[%SINON%]";
WDTableZRNavigateur.prototype.ms_sDynFin = "[%FIN%]";
WDTableZRNavigateur.prototype.ms_sInclureHautRupture = "INCLURE_HAUTRUPTURE";
WDTableZRNavigateur.prototype.ms_sInclureBasRupture = "INCLURE_BASRUPTURE";
WDTableZRNavigateur.prototype.ms_sCodeHTML30 = "CODEHTML_30_";
WDTableZRNavigateur.prototype.ms_sCodeHTML31 = "CODEHTML_31_";
WDTableZRNavigateur.prototype.ms_sCodeHTML32 = "CODEHTML_32";
WDTableZRNavigateur.prototype.ms_sConditionEgal = "=";
WDTableZRNavigateur.prototype.ms_sConditionDifferent = "!=";
WDTableZRNavigateur.prototype.ms_sPropriete = "..";
WDTableZRNavigateur.prototype.ms_sConversion = ";";
WDTableZRNavigateur.prototype.ms_nAttributRuptureLigneDebut = -1;
WDTableZRNavigateur.prototype.ms_nAttributRuptureLigneFin = -2;
WDTableZRNavigateur.prototype.ms_nAttributLigneRepliee = -3;
WDTableZRNavigateur.prototype.ms_nAttributIncludeHautRupture = -4;
WDTableZRNavigateur.prototype.ms_nAttributIncludeBasRupture = -5;
WDTableZRNavigateur.prototype.ms_nAttributLignePaire = -6;
WDTableZRNavigateur.prototype.ms_nAttributTriable = -7;
WDTableZRNavigateur.prototype.ms_nAttributRecherchable = -8;
WDTableZRNavigateur.prototype.ms_nAttributSelected = -9;
WDTableZRNavigateur.prototype.ms_nAttributDerniereVisible = -10;
WDTableZRNavigateur.prototype.ms_nAttributCodeHTML30 = -11;
WDTableZRNavigateur.prototype.ms_nAttributCodeHTML31 = -12;
WDTableZRNavigateur.prototype.ms_nAttributCodeHTML32 = -13;
WDTableZRNavigateur.prototype.ms_nAttributExiste = -14;

WDTableZRNavigateur.prototype.ms_nConversionPoliceGras = 4;
WDTableZRNavigateur.prototype.ms_nConversionPoliceItalique = 5;
WDTableZRNavigateur.prototype.ms_nConversionPoliceSouligne = 6;
WDTableZRNavigateur.prototype.ms_nConversionPoliceTaille = 7;
WDTableZRNavigateur.prototype.ms_nConversionBackgroundImage = 20;

WDTableZRNavigateur.prototype.ms_nTdEchange = 0x80000000;

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		M�thodes surcharg�es : WDChamp

// Initialisation
WDTableZRNavigateur.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype.Init.apply(this, arguments);

	// Applique les parametres que l'on a re�u lors de l'initialisation
	this._vAppliqueParametres();

	// Parse le HTML
	this.__HTMLParse();

	// Jamais utilis�s
//	// Initialise la valeur des champs cache
//	this.m_oChampDeb.value = "1";
//	this.m_oChampOcc.value = "0";
	// Et initialise la gestion de la s�lection (�crit dans le champ formulaire)
	this.m_oSelection.Init();
};

// Affectation de la valeur
WDTableZRNavigateur.prototype.SetValeur = function SetValeur(oEvent, sValeur/*, oChamp*/)
{
	// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
	WDChampParametresHote.prototype.SetValeur.apply(this, arguments);

	// sValeur est la nouvelle s�lection
	// oChamp est le champ formulaire

	// Effectue une s�lection
	this.m_oSelection.ReinitSelection(this._xnLigneWLLigne(sValeur));

	// Retourne la s�lection courante
	return this._nGetSelection();
};

// Lecture de la valeur
WDTableZRNavigateur.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp)
{
	// sValeur est la valeur dans le champ formulaire
	// oChamp est le champ formulaire

	// Si on est dans le PCode d'affichage de ligne, on retourne le num�ro de ligne courant
	sValeur = this._nLigneLigneWL(this._nGetSelection());

	// Appel de la methode de la classe de base et retour de son resultat
	return WDChampParametresHote.prototype.GetValeur.apply(this, [oEvent, sValeur, oChamp]);
};

// Lit une propri�t�
WDTableZRNavigateur.prototype.GetProp = function GetProp(eProp/*, oEvent*//*, oValeur*//*, oChamp*/)
{
	switch (eProp)
	{
	case this.XML_CHAMP_PROP_NUM_OCCURRENCE:
		return this._nGetNbLignesWL();
	default:
		// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
		return WDChampParametresHote.prototype.GetProp.apply(this, arguments);
	}
};

// Ecrit une propri�t�
//WDTableZRNavigateur.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp/*, oXMLAction*/)

// Trouve les divers elements : liaison avec le HTML
WDTableZRNavigateur.prototype._vLiaisonHTML = function _vLiaisonHTML(sSuffixeFormulaire, sSuffixeHote)
{
	// Ignore l'implementation avec _DATA de WDChampParametres
	sSuffixeFormulaire = "";

	// Il doit y avoir une meilleure solution (en particulier deplacer le code lie au ZR dans WDChamp mais cela va faire des effets de bord a l'init)
	WDChampParametresHote.prototype._vLiaisonHTML.apply(this, [sSuffixeFormulaire, sSuffixeHote]);

	// Jamais utilis�s
//	// Recupere les differents champs caches
//	this.m_oChampDeb = this.oGetElementByName(document, "_DEB");
//	this.m_oChampOcc = document.getElementsByName("_" + this.m_sAliasChamp + "_OCC")[0];
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		M�thodes surcharg�es : WDChampParametres

// _voFusionneDonne => Pas de fusion des donn�es

// Applique les param�tres du champ (initisation uniquement : pas de fusion des donn�es)
WDTableZRNavigateur.prototype._vAppliqueParametres = function _vAppliqueParametres(/*oParametreFusion*/)
{
	// Analyse les param�tres
	var oParametres = this.m_oParametres;
	clWDUtil.bForEachThis(oParametres.m_tabColonnes, this, function(oColonne)
	{
		this.m_tabColonnes.push(new (this._vNewColonne)(oColonne.m_sAlias, oColonne.m_eTypeWL, oColonne.m_tabProprietesSpecifiques));
		return true;
	});
	clWDUtil.bForEachThis(oParametres.m_tabRuptures, this, function(oRupture)
	{
		this.m_tabRuptures.push(new (this._vNewRupture)(oRupture.m_sAlias, oRupture.m_sAliasBas, this._nGetColonneSelonAlias(oRupture.m_sAliasColonne), oRupture.m_bVisibleHaut, oRupture.m_bVisibleBas));
		return true;
	});
	// m_tabSurEntetes = Tableau de tableau (un tableau par ligne), avec pour chaque cellule la taille horizontale � droite.
	// Si on est au milieu d'une cellule la taille �crite est la taille restante
	this.m_tabSurEntetes = oParametres.m_tabSurEntetes;
	// Si on est avec la ligne de saisie automatique
	this.m_bSaisieCascade = oParametres.m_bSaisieCascade;
	// Si la table a une ligne virtuelle, l'ajoute maintenant
	if (this.m_bSaisieCascade)
	{
		this.__AjouteLigneVirtuelle();
	}
	// Style des lignes
	this.m_oStyleLigneImpair = oParametres.m_oStyleLigneImpair;
	this.m_oStyleLignePair = oParametres.m_oStyleLignePair;
	this.m_oStyleLigneSelectionne = oParametres.m_oStyleLigneSelectionne;

	// Autres propri�t�s de la table

	// Analyse le contenu :
	//	{
	//		// Table : autres propri�t�s
	//		m_sCouleurFond : xxx,
	//		...,
	//		// Table : contenu : les lignes
	//		m_tabLignes : [
	//			{
	//				// Ligne : autres propri�t�s
	//				m_sCouleurFond : xxx,
	//				m_bSelectionnee : true,
	//				...,
	//				// Ligne : contenu : les cellules
	//				m_tabCellules : [
	//					{
	//						// Cellule : autres propri�t�s
	//						m_sCouleurFond : xxx,
	//						...,
	//						// Cellule : contenu : la valeur
	//						m_oContenu : xxx
	//					},
	//					...
	//				]
	//			},
	//			...
	//		]
	//	}
	// Le contenu est trait� apr�s le code de onload de la page
	var oDonnees = this.m_oDonnees;
	// Autres propri�t�s de la table

	// Evite de consommer de la m�moire
	oParametres.m_tabColonnes = null;
	oParametres.m_tabRuptures = null;
	// (Converse les autres param�tres et donn�es)
};

WDTableZRNavigateur.prototype.AjouteDonnees = function AjouteDonnees()
{
	var oDonnees = this.m_oDonnees;
	// Le contenu est trait� apr�s le code de onload de la page => ici
	clWDUtil.bForEachThis(oDonnees.m_tabLignes, this, function(oLigne)
	{
		var tabValeurs = [];
		clWDUtil.bForEach(oLigne.m_tabCellules, function(oCellule)
		{
			tabValeurs.push(oCellule.m_oContenu);
			return true;
		});
		// Sans tri : ajoute dans l'ordre du serveur
		this._nLigneInsere(false, tabValeurs);
		return true;
	});
	// Autres propri�t�s de la table

	// Evite de consommer de la m�moire
	oDonnees.m_tabLignes = null;
	// (Converse les autres param�tres et donn�es)
};
// Ajoute la ligne virtuelle
WDTableZRNavigateur.prototype.__AjouteLigneVirtuelle = function __AjouteLigneVirtuelle()
{
	this.m_tabLignes.push(new (this._vLigne)(this._nGetNbColonnes(), true));
	// Modifie la ligne (provoque le reaffichage)
	// true : pour ne pas entrer en modification lors de l'ajout d'une nouvelle ligne virtuelle (on a forc�ment une autre modification)
	// GP 16/01/2014 : QW241490 : Utilisation d'un nouveau flag
	this.__LigneModifie([], this.m_tabLignes.length - 1, undefined, true);
};

//////////////////////////////////////////////////////////////////////////
// M�thodes surcharg�es
//	WDTableZRNavigateur
//		Interface des table/ZRs

// Click sur une ligne de zone repetee
WDTableZRNavigateur.prototype.vTableZROnSelectLigne = function vTableZROnSelectLigne(nLigneAbsolueBase1, oEvent)
{
	try
	{
		// GP 30/04/2018 : TB103858 : Les actions externes ne doivent pas d�clencher l'entr�e en saisie
		var bDansOnSelectLigneExterneOld = this.m_bDansOnSelectLigneExterne;
		this.m_bDansOnSelectLigneExterne = true;

		this._vSetValeurChampFormulaire(nLigneAbsolueBase1);

		// GP 24/04/2018 : TB104282 : Il ne faut pas que modifier le champ formulaire, il faut aussi s�lectionner la ligne dans la gestion interne.
		var nLigne = this._xnLigneWLLigne(nLigneAbsolueBase1, this._nGetSelection());
		this.m_oSelection.bSelectAucun(oEvent, nLigne);
		this.m_oSelection.bSelectPlus(nLigne, true, oEvent);
	}
	finally
	{
		this.m_bDansOnSelectLigneExterne = bDansOnSelectLigneExterneOld;
	}
};

// Valide la ligne selectionnee et envoie la modification au serveur
WDTableZRNavigateur.prototype.vTableZROnValideLigne = function vTableZROnValideLigne(oEvent, oChamp, oValeur)
{
	// MAJ de l'attribut
	if (oChamp)
	{
		// Trouve l'attribut sur la valeur
		var nAttribut = this._nGetColonneSelonAlias(oChamp.m_sAliasAttribut);
		if (undefined !== nAttribut)
		{
			// Appel de la m�thode de modification
			this.__OnLigneModifieFormulaire(oEvent, [nAttribut, this._nGetSelection(), oValeur])
		}
	}
};

// Donne le mode de s�lection de la table/zone r�p�t�e
WDTableZRNavigateur.prototype.veGetModeSelection = function veGetModeSelection()
{
	return this.m_oSelection.m_eTypeSelection;
};
WDTableZRNavigateur.prototype.vbSaisieSansSelection = function vbSaisieSansSelection(nColonne)
{
	// GP 23/05/2016 : TB97877 : Pour avoir la saisie sans s�lection : il ne faut pas avoir de s�lection mais aussi que la colonne soit saisissable
	// Le fait que la colonne soit saisissable a d�j� �t� v�rifie mais pas sur tous les chemins
	if (WDSelection.prototype.ms_nSelectionSans == this.veGetModeSelection())
	{
		// V�rifie que la colonne est saisissable
		return this._oGetColonne(nColonne).m_bSaisissable;
	}
	else
	{
		return false;
	}
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		M�thodes virtuelles pures

//_vNewColonne
//_vNewAttributAutomatique
//_vNewRupture
//_vLigne
//_vHTMLGenereLigne
//_vInvalidePourTRF
//_voHTMLParse
//_vbAvecCouleurDeFondSelection

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		M�thodes internes g�n�rales

// Indique si le chargement d'une image est fini
WDTableZRNavigateur.prototype.s_tabImageChargement = function s_tabImageChargement(oImage)
{
	if (bIE && (oImage.readyState != "complete"))
	{
		return null;
	}

	// R�cupere les dimensions
	var nImageX = (bIEQuirks9Max ? 0 : oImage.naturalWidth) || oImage.width || oImage.offsetWidth;
	var nImageY = (bIEQuirks9Max ? 0 : oImage.naturalHeight) || oImage.height || oImage.offsetHeight;
	if ((0 == nImageX) || (0 == nImageY))
	{
		return null;
	}

	// M�morise les tailles dans le champ image
	// Format : "<Taille X>,<Taille Y>"
	clWDUtil.WDDebug.assert(!clWDUtil.bHasAttribute(oImage, "data-webdev-dimensions-initiales"), "Dimensions d\xE9j\xE0 pr\xE9sentes");
	oImage.setAttribute("data-webdev-dimensions-initiales", nImageX + "," + nImageY);

	// L'image est transparente d�s sa cr�ation
	clWDUtil.WDDebug.assert("0" == oImage.style.opacity, "Image non transparente");

	return [nImageX, nImageY];
};

// Redimensionne une image en respectant les options d'affichage
// Pour "WDTableColonne.prototype.__sLitValeurImage"
WDTableZRNavigateur.prototype.s_RedimImageChargement = function s_RedimImageChargement(oImage)
{
	var tabTailleImage = WDTableZRNavigateur.prototype.s_tabImageChargement(oImage);
	if (tabTailleImage)
	{
		// GP 27/05/2016 : QW273513 : On est dans le cas des tables navigateur. Le minHeight de la cellule parente n'a pas �t� fait.
		var nModeAffichageEtHauteurLigneVariable = parseInt(oImage.getAttribute("data-webdev-mode-affichage"), 10);
		var bHauteurLigneVariable = !!(nModeAffichageEtHauteurLigneVariable & 0x100);
		if (!bHauteurLigneVariable)
		{
			oImage.parentNode.style.minHeight = "10000px";
		}

		// Appel de la m�thode interne
		WDTableZRNavigateur.prototype.__s_RedimImage(oImage, oImage.parentNode, tabTailleImage, true, false);
	}
};
// Redimensionne une image en respectant les options d'affichage
// => Version au d�but du redimensionnement de la colonne (uniquement en cas de hauteur de ligne variable)
WDTableZRNavigateur.prototype.s_bRedimImageDebutRedimCol = function s_bRedimImageDebutRedimCol(oImage)
{
	// R�cup�re l'attribut dans l'image
	var sDataRedim = oImage.getAttribute("data-webdev-dimensions-initiales");
	if (null != sDataRedim)
	{
		var tabDataRedim = String(sDataRedim).split(",");
		if (tabDataRedim && (2 == tabDataRedim.length))
		{
			var nImageX = parseInt(tabDataRedim[1], 10);
			var nImageY = parseInt(tabDataRedim[1], 10);
			if (!(isNaN(nImageX) || isNaN(nImageY)))
			{
				// Supprime les dimensions
				var oImageStyle = oImage.style;
//				oImageStyle.width = "0";
				oImage.style.height = "0";
			}
		}
	}

	return true;
};

// Redimensionne une image en respectant les options d'affichage
// => Version � la fin pour le redimensionnement de la colonne
WDTableZRNavigateur.prototype.s_bRedimImageFinRedimCol = function s_bRedimImageFinRedimCol(oImage)
{
	// R�cup�re l'attribut dans l'image
	var sDataRedim = oImage.getAttribute("data-webdev-dimensions-initiales");
	if (null != sDataRedim)
	{
		var tabDataRedim = String(sDataRedim).split(",");
		if (tabDataRedim && (2 == tabDataRedim.length))
		{
			var tabTailleImage = [parseInt(tabDataRedim[0], 10), parseInt(tabDataRedim[1], 10)];
			if (!(isNaN(tabTailleImage[0]) || isNaN(tabTailleImage[1])))
			{
				// Appel de la m�thode interne
				WDTableZRNavigateur.prototype.__s_RedimImage(oImage, oImage.parentNode, tabTailleImage, false, false);
			}
		}
	}
	return true;
};
// Redimensionne une image en respectant les options d'affichage
// => Version interne
WDTableZRNavigateur.prototype.__s_RedimImage = function __s_RedimImage(oImage, oCellule, tabTailleImage, bPremierAffichageImage, bSecondAppelPourIE)
{
	// Avec IE, on est appel� sur des �l�ments qui ne sont pas dans le document
	if (bIEAvec11 && (!clWDUtil.bEstDansDocument(oCellule)))
	{
		return;
	}
	// On ne fait aucun blindage :
	// - parseInt de toute valeur invalide retourne NaN
	// - NaN & (~(0x100)) retourne 0
	// - 0 - 1 retourne -1
	// - ([])[-1] retourne undefined.
	var nModeAffichageEtHauteurLigneVariable = parseInt(oImage.getAttribute("data-webdev-mode-affichage"), 10);
	var eModeAffichage = (nModeAffichageEtHauteurLigneVariable & (~(0x100))) || WDTableColonne.prototype.ms_eAdapteCentre;
	var bHauteurLigneVariable = !!(nModeAffichageEtHauteurLigneVariable & 0x100);

	var oParentCellule = oCellule.parentNode;
	var nDispoX = oParentCellule.clientWidth;
	var nDispoY = oParentCellule.clientHeight;
	// Dans le cas de hauteur de ligne variable on ne peut pas fixer une hauteur importante : lit la hauteur de la ligne.
	// Mais dans les test cette valeur est l�g�rement erron�e (de 1)
	if (bHauteurLigneVariable)
	{
		// GP 30/05/2016 : QW273529 : Avec IE, nDispoX est a z�ro en hauteur de ligne variable
		// Tente de se ratrapper avec le parent
		if (bIEAvec11 && (0 == nDispoX))
		{
			nDispoX = oParentCellule.parentNode.clientWidth;
		}

		nDispoY = Math.max(oParentCellule.parentNode.clientHeight, nDispoY);
	}
	else
	{
		// GP 20/02/2018 : TB104823 : Ce n'est pas clair pourquoi dans le cas de la fiche, le syst�me de dimensionnement dans ce cas ne fonctionne pas avec la taille forc� de 10000.
		// (C'est peut-�tre li� au mode d'affichage).
		if (10000 == nDispoY)
		{
			// Tente de remonter 5 parent (depuis la cellule, donc 4 depuis oParentCellule) : pour trouver le div au dessus : qui a la taille r�ellement disponible.
			for (var oParent = oParentCellule.parentNode, nNiveau = 0; oParent && (nNiveau < 4); oParent = oParent.parentNode, nNiveau++)
			{
				var nDispoYParent = oParent.clientHeight;
				if (nDispoYParent && (nDispoYParent < nDispoY))
				{
					nDispoY = nDispoYParent;
					break;
				}
			}
		}
	}

	// GP 30/05/2016 : QW273529 : Avec IE, on est appel� sur des �l�ments dont le reflow n'a pas encore �t� fait.
	if (bIEAvec11 && (0 == nDispoX) && (0 == nDispoY))
	{
		// On limite le nombre d'appel car chaque appel provoque la capture de la pile. Donc si pour une raison inconnue, le reflo n'est jamais fait,
		// ou si la taille est vraiment de (0, 0) on fait exploser la m�moire.
		if (!bSecondAppelPourIE)
		{
			clWDUtil.nSetTimeout(function()
			{
				WDTableZRNavigateur.prototype.__s_RedimImage(oImage, oCellule, tabTailleImage, bPremierAffichageImage, true);
			}, clWDUtil.ms_oTimeoutImmediat);
		}
		return;
	}

	// Passe image en arri�re plan
	var oCelluleStyle = oCellule.style;
	// Si c'est le premier affichage de cette image (= hors redimensionnement de colonne) : il faut fixer le fond
	if (bPremierAffichageImage)
	{
		// GP 27/05/2016 : QW273499 : Cette ligne doit �tre dans tous les cas et pas uniquement le "hauteur des lignes adapt� au contenu"
		oCelluleStyle.backgroundRepeat = "no-repeat";
		oCelluleStyle.backgroundImage = "url('" + oImage.src + "')";
		if (!bHauteurLigneVariable)
		{
			oCelluleStyle.minHeight = "";
		}
	}

	// L'image est "invisible" et ce que l'on manipule est son parent
	var nFacteurImageY = WDTableZRNavigateur.prototype.__s_nRedimImageInterne(oCelluleStyle, eModeAffichage, tabTailleImage, nDispoX, nDispoY);

	var oImageStyle = oImage.style;
	// Fixe la largeur sur la largeur disponible (le style fait le reste)
	oImageStyle.width = nDispoX + "px";
	// Fixe la hauteur sur la hauteur disponible ou la hauteur de l'image (en cas de ligne adapt� au contenu et d'image plus grande)
	var nFinalY = nDispoY;
	if (bHauteurLigneVariable)
	{
		if (1 == nFacteurImageY)
		{
			// Si on ne modifie pas la hauteur de l'image, la hauteur final doit prendre toutes la ligne et doit donc �tre le plus grand entre la ligne et l'image.
		}
		else
		{
			// nFacteurImageY est modifi� dans le cas d'une image homoth�tique.
			clWDUtil.WDDebug.assert(nFacteurImageY < 1, "nFacteurImageY est normalement inf\xE9rieur a 1");
			// GP 27/05/2016 : QW273509  : Mais la r�duction de la largeur de l'image a changer sa hauteur. Ce qui a peut-�tre chang� la hauteur de la ligne
			// => Il faut refaire le calcul.
			nDispoY = Math.max(oCellule.parentNode.parentNode.clientHeight, oCellule.parentNode.clientHeight);
		}
		nFinalY = Math.max(nDispoY, Math.round(tabTailleImage[1] * nFacteurImageY));
	}
	oImageStyle.height = nFinalY + "px";

	// Ajoute l'image au parent si ce n'est pas d�j� fait
	if (!oImage.parentNode)
	{
		oCellule.appendChild(oImage);
	}
};
WDTableZRNavigateur.prototype.__s_nRedimImageInterne = function __s_nRedimImageInterne(oCelluleStyle, eModeAffichage, tabTailleImage, nDispoX, nDispoY)
{
	var nImageX = tabTailleImage[0];
	var nImageY = tabTailleImage[1];
	var nFacteurImageY = 1;

	switch (eModeAffichage)
	{
	case WDTableColonne.prototype.ms_eNormal:
		// - Affichage en 100%, offset personnalis�
		// Rien
		break;
	case WDTableColonne.prototype.ms_eCentre:
		// - Affichage en 100%, centr�
		oCelluleStyle.backgroundPosition = "center center";
		break;
	case WDTableColonne.prototype.ms_eEtire:
		// - Affichage �tir� du rectangle d'origine pour occuper toute la zone de destination
		oCelluleStyle.backgroundSize = "100% 100%";
		break;
	case WDTableColonne.prototype.ms_eRepete:
		// - Affichage r�p�t� du rectangle d'origine pour occuper toute la zone toute la zone de destination
		oCelluleStyle.backgroundRepeat = "repeat";
		break;
	case WDTableColonne.prototype.ms_eHomothetiqueCentre:
		// - Idem homoth�tique mais centr�
		oCelluleStyle.backgroundPosition = "center center";
		// Pas de break;
	case WDTableColonne.prototype.ms_eHomothetique:
		// - Affichage etir� homoth�tique du rectangle d'origine pour occuper au mieux la zone de destination
		oCelluleStyle.backgroundSize = "contain";
		// Si il y a une r�duction en largeur, on fait une r�duction en hauteur
		if (nDispoX < nImageX)
		{
			// On ne teste pas le cas de nDispoY < nImageY
			// En effet nFacteurImageY ne sert que dans le cas de hauteur de ligne adapt� au contenu. Or de ce cas la hauteur ne peux pas �tre le facteur limitant
			nFacteurImageY = nDispoX / nImageX;
		}
		break;
	case WDTableColonne.prototype.ms_eHomothetiqueCentreLarge:
		// -  Idem homoth�tique centr�, mais garde la plus petite proportion au lieu de la plus grande
		oCelluleStyle.backgroundPosition = "center center";
		// Pas de break;
	case WDTableColonne.prototype.ms_eHomothetiqueLarge:
		// - Idem homoth�tique, mais garde la plus petite proportion au lieu de la plus grande
		oCelluleStyle.backgroundSize = "cover";
		// On ne teste rien
		// En effet nFacteurImageY ne sert que dans le cas de hauteur de ligne adapt� au contenu. Or de ce cas la hauteur ne peux pas �tre le facteur limitant
//		// Si il y a une r�duction en largeur, on fait une r�duction en hauteur
//		if (nDispoX < nImageX)
//		{
//			nFacteurImageY = nDispoX / nImageX;
//		}
		break;
	case WDTableColonne.prototype.ms_eAdapte:
		// - Affichage en 100% s'il y a la place, Homoth�tique sinon
		if ((nDispoX < nImageX) || (nDispoY < nImageY))
		{
			// GP 26/05/2016 : TB98419 : Selon la dimension/l'image, si une cellule passe du mode "normal" au mode "homoth�tique", il faut supprimer la trace du mode "normal"
			// => Aucun style dans le mode "normal"

			// Appel r�cursif mais avec WDTableColonne.prototype.ms_eHomothetique
			nFacteurImageY = WDTableZRNavigateur.prototype.__s_nRedimImageInterne(oCelluleStyle, WDTableColonne.prototype.ms_eHomothetique, tabTailleImage, nDispoX, nDispoY)
		}
		else
		{
			// GP 26/05/2016 : TB98419 : Selon la dimension/l'image, si une cellule passe du mode "homoth�tique" au mode "normal", il faut supprimer la trace du mode "homothetique"
			oCelluleStyle.backgroundSize = "";
			// Appel r�cursif mais avec WDTableColonne.prototype.ms_eNormal
			nFacteurImageY = WDTableZRNavigateur.prototype.__s_nRedimImageInterne(oCelluleStyle, WDTableColonne.prototype.ms_eNormal, tabTailleImage, nDispoX, nDispoY)
		}
		break;
	default:
	case WDTableColonne.prototype.ms_eAdapteCentre:
		// - Comme le pr�c�dent mais centr�
		if ((nDispoX < nImageX) || (nDispoY < nImageY))
		{
			// GP 26/05/2016 : TB98419 : Selon la dimension/l'image, si une cellule passe du mode "centr�" au mode "homoth�tique centr�", il faut supprimer la trace du mode "centr�"
			// => Inutile de faire un RAZ de backgroundPosition qui est modifi� par les deux modes
//			oCelluleStyle.backgroundPosition = "";

			// Appel r�cursif mais avec WDTableColonne.prototype.ms_eHomothetiqueCentre
			nFacteurImageY = WDTableZRNavigateur.prototype.__s_nRedimImageInterne(oCelluleStyle, WDTableColonne.prototype.ms_eHomothetiqueCentre, tabTailleImage, nDispoX, nDispoY)
		}
		else
		{
			// GP 26/05/2016 : TB98419 : Selon la dimension/l'image, si une cellule passe du mode "homoth�tique centr�" au mode "centr�", il faut supprimer la trace du mode "homoth�tique centr�"
			// => Inutile de faire un RAZ de backgroundPosition qui est modifi� par les deux modes
//			oCelluleStyle.backgroundPosition = "";
			oCelluleStyle.backgroundSize = "";

			// Appel r�cursif mais avec WDTableColonne.prototype.ms_eCentre
			nFacteurImageY = WDTableZRNavigateur.prototype.__s_nRedimImageInterne(oCelluleStyle, WDTableColonne.prototype.ms_eCentre, tabTailleImage, nDispoX, nDispoY)
		}
		break;
//	case WDTableColonne.prototype.ms_eNavigateurHomothetiqueLargeur:
//		// - Le navigateur effectue une homoth�tie selon la largeur et pousse la hauteur du champ (la largeur peut �tre fixe ou ancr�e au navigateur, la hauteur est ancr�e au contenu)
//		break;
//	case WDTableColonne.prototype.ms_eNavigateurAdapteLargeur:
//		// - Le navigateur adapte la largeur (100% s'il y a la place, homoth�tique sinon) et pousse la hauteur du champ (la hauteur et la largeur sont ancr�es au contenu)
//		break;
//	case WDTableColonne.prototype.ms_eNavigateurHomothetiqueLargeurDebordementHauteur:
//		// - Le navigateur effectue une homoth�tie selon la largeur et tronque selon la hauteur du champ (la largeur et hauteur peuvent �tre fixes ou ancr�es au navigateur)
//		break;
//	case WDTableColonne.prototype.ms_eNavigateurAdapteLargeurDebordementHauteur:
//		// - Le navigateur adapte la largeur (100% s'il y a la place, homoth�tique sinon) et tronque selon la hauteur du champ (la largeur est au contenu, la hauteur peut �tre fixe ou ancr�e au navigateur)
//		break;
	}

	return nFacteurImageY;
};

// Nombre de colonnes/attributs
WDTableZRNavigateur.prototype._nGetNbColonnes = function _nGetNbColonnes()
{
	return this.m_tabColonnes.length;
};
// Nombre de ruptures
WDTableZRNavigateur.prototype._nGetNbRuptures = function _nGetNbRuptures()
{
	return this.m_tabRuptures.length;
};
// Nombre de lignes
WDTableZRNavigateur.prototype._nGetNbLignes = function _nGetNbLignes()
{
	return this.m_tabLignes.length;
};
// Nombre de lignes r�el pour le WL dans le cas d'une table/zone r�p�t�e filtr�e
WDTableZRNavigateur.prototype._nGetNbLignesWL = function _nGetNbLignesWL()
{
	return this.m_nNbLignesWL;
};

// Une colonne
WDTableZRNavigateur.prototype._oGetColonne = function _oGetColonne(nColonne)
{
	return this.m_tabColonnes[nColonne];
};

// Recherche une colonne/attribut par alias
WDTableZRNavigateur.prototype._nGetColonneSelonAlias = function _nGetColonneSelonAlias(sAlias)
{
	return clWDUtil.WDObjet.prototype.s_nChercheParAlias(this.m_tabColonnes, sAlias);
};
// Recherche une rupture par alias
WDTableZRNavigateur.prototype._nGetRuptureSelonAlias = function _nGetRuptureSelonAlias(sAlias)
{
	return clWDUtil.WDObjet.prototype.s_nChercheParAlias(this.m_tabRuptures, sAlias);
};

// Recherche un attribut par champ associ� et propri�t�. Retourne l'indice de l'attribut
WDTableZRNavigateur.prototype.__nGetAttributSelonChampEtPropriete = function __nGetAttributSelonChampEtPropriete(sAliasChamp, ePropriete)
{
	return clWDUtil.nDansTableauFct(this.m_tabColonnes, function(oColonneOuAttribut)
	{
		// GP 17/02/2015 : QW254941 : autorise aussi les "colonnes"
		// Attention, this n'est pas d�fini ici, il faut bien utilis� WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR
		// GP 18/02/2015 : QW254943 : Appel de s_eGetProprietePrincipale : la g�n�ration HTML r�f�rence parfois des propri�t�s serveur sans �quivalent en JS (par exemple ..Libell�)
		return	(oColonneOuAttribut instanceof WDAttribut) && (oColonneOuAttribut.m_sAliasChampAssocie == sAliasChamp) && (oColonneOuAttribut.m_eProprieteAssocie == WDTableZRNavigateur.prototype.s_eGetProprietePrincipale(ePropriete, oColonneOuAttribut.m_eTypeChampAssocie))
			||	(oColonneOuAttribut instanceof WDTableColonne) && (oColonneOuAttribut.m_sAlias == sAliasChamp) && (WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR == ePropriete);
	});
};

// Effectue la conversion vers la propri�t� principale (selon le type de champ)
// Utilise le m�me code que dans CChampTable::s_eGetProprietePrincipale et CConversionN1::__GenereAttributAutomatique
WDTableZRNavigateur.prototype.s_eGetProprietePrincipale = function s_eGetProprietePrincipale (eProprieteServeur, eTypeChamp)
{
	// Selon le type de l'objet
	switch (eTypeChamp)
	{
	case WDChamp.prototype.ms_nIDObjetLibelle:
		// Champ libell� : ..Libelle est �quivalent � ..Valeur
		switch (eProprieteServeur)
		{
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLE:
			return WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR;
		}
		break;

	case WDChamp.prototype.ms_nIDObjetBouton:
		// Champ bouton : ..Libelle est �quivalent � ..Valeur
		switch (eProprieteServeur)
		{
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLE:
			return WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR;
		}
		break;

	case WDChamp.prototype.ms_nIDObjetImage:
	case this.XML_CHAMP_TYPE_MAPAREA:
	case this.XML_CHAMP_TYPE_VIGNETTE:
	case this.XML_CHAMP_TYPE_GRAPHE:
	case this.XML_CHAMP_TYPE_CAPTCHA:
	case WDChamp.prototype.ms_nIDObjetCodeBarre:
		// Champ image : ..Image est �quivalent � ..Valeur
		switch (eProprieteServeur)
		{
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_IMAGE:
			return WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR;
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLE:
			return WDChamp.prototype.XML_CHAMP_PROP_NUM_TEXTEALTERNATIF;
		}
		break;

	// GP 27/03/2015 : A ajouter un jour
////	case ID_IFRAME_DEST:			// Non car d�rive de CSuperChamp
////	case ID_IFRAME_SOURCE:			// Non car d�rive de CSuperChamp
////	case ID_CHAMPTIROIR:			// Non car red�fini ..Valeur
//	case ID_CELLULE:
////	case ID_SUPERCHAMP:				// Non car red�fini ..Valeur
////	case ID_MODELEDECHAMP_SOURCE:	// Non car d�rive de CSuperChamp
////	case ID_MODELEDECHAMP_DEST:		// Non car d�rive de CSuperChamp
//	case ID_CELLULEMISEENPAGE:
////	case ID_POPUP_DEST:				// Non car d�rive de CSuperChamp
//	case ID_ZONETEXTERICHE:
//	case ID_TDB:
//		// GP 27/03/2015 : QW253172 : Ajout de la correspondance ..Valeur <=> ..LibelleHTML sur les champs cellules et d�riv�es
//		// Sauf ceux qui red�finissent ..Valeur et pour lequel ..Valeur n'est plus ..LibelleHTML (par exemple CSuperChamp et ses d�riv�es)
//		switch (ePropriete)
//		{
//		case LIBELLEHTML_WEB:
//			if (rclChamp->bGetPositionnementFlux())
//				return VALEUR;
//			break;
//		}
//		break;
	}

	return eProprieteServeur;
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		Calculs pour l'affichage

// Recalcul les ruptures pour une ligne
WDTableZRNavigateur.prototype.__RupturesEntreLignes = function __RupturesEntreLignes(oLigne1, oLigne2, nLigne1, nLigne2)
{
	var nRuptures = WDLigne.prototype.ms_nTous;
	var tabRuptures = this.m_tabRuptures;
	if (oLigne1 && oLigne2)
	{
		nRuptures = WDLigne.prototype.ms_nRien;
		var tabValeurs1 = oLigne1.tabGetValeurs();
		var tabValeurs2 = oLigne2.tabGetValeurs();
		var i;
		var nLimiteI = this._nGetNbRuptures();
		var bUnRuptureAffichee = false;
		for (i = 0; i < nLimiteI; i++)
		{
			var nColonne = tabRuptures[i].m_nColonne;
			// GP 02/05/2018 : TB100578 : Si on a une rupture, il faut afficher toutes les ruptures inf�rieures.
			if (bUnRuptureAffichee || (tabValeurs1[nColonne] != tabValeurs2[nColonne]))
			{
				// Les valeurs sont diff�rentes : on affiche la rupture.
				nRuptures |= (1 << i);
				bUnRuptureAffichee = true;
			}
		}
	}
	else
	{
		// Premiere (oLigne2) ou derniere ligne (oLigne1). nRuptures indique d�j� que l'on affiche toutes les ruptures
		nRuptures = WDLigne.prototype.ms_nTous;
	}

	var nRupturesPrecedente;
	if (oLigne1)
	{
		nRupturesPrecedente = oLigne1.nGetRuptures(false);
		oLigne1.SetRupturesBas(nRuptures);
		// Execute les PCodes d'affichage des ruptures
		this.__AppelPCodeAffichageRuptures(nLigne1, nRuptures, nRupturesPrecedente, false);
	}
	if (oLigne2)
	{
		nRupturesPrecedente = oLigne2.nGetRuptures(true);
		oLigne2.SetRupturesHaut(nRuptures);
		// Execute les PCodes d'affichage des ruptures
		this.__AppelPCodeAffichageRuptures(nLigne2, nRuptures, nRupturesPrecedente, true);
	}
};

// Appel des PCodes d'affichage des ruptures
WDTableZRNavigateur.prototype.__AppelPCodeAffichageRuptures = function __AppelPCodeAffichageRuptures(nLigne, nRuptures, nRupturesPrecedente, bHaut)
{
	var tabRuptures = this.m_tabRuptures;
	var i;
	var nLimiteI = tabRuptures.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (nRuptures & (1 << i))
		{
			this.__AppelPCodeAffichage(nLigne, tabRuptures[i].RecuperePCode(this.ms_nEventNavAffichageLigne, bHaut));
		}
	}
};

// Gere les lignes modifiee :
// - Recalcul des ruptures
// - PCode d'affichage
WDTableZRNavigateur.prototype.__TableAfficheCalculs = function __TableAfficheCalculs(nLigneDepuis)
{
	var tabLignes = this.m_tabLignes;
	var i;
	var nLimiteI = this._nGetNbLignes();

	// - PCode d'affichage (avant le calcul des ruptures)
	var fPCode = this.RecuperePCode(this.ms_nEventNavAffichageLigne);
	for (i = nLigneDepuis; i < nLimiteI; i++)
	{
		if (tabLignes[i].bGetClearPCodeAffichage())
		{
			this.__AppelPCodeAffichage(i, fPCode);
		}
	}

	// Calcul des ruptures
	if (0 < this._nGetNbRuptures())
	{
		// On commence a la ligne precedente (pour la rupture entre la ligne precedente et la premiere ligne reaffichee
		for (i = (0 < nLigneDepuis) ? (nLigneDepuis - 1) : nLigneDepuis; i < nLimiteI; i++)
		{
			var oLigne = tabLignes[i];
			if (oLigne.bGetClearModifieRuptures())
			{
				// Si on est sur la premiere ligne le traite aussi comme un cas particulier (sinon le haut de la premiere ligne n'est pas affiche)
				if (i == 0)
				{
					this.__RupturesEntreLignes(undefined, oLigne, undefined, 0);
				}
				var oLigneSuivante = (i < (nLimiteI - 1)) ? tabLignes[i + 1] : undefined;
				this.__RupturesEntreLignes(oLigne, oLigneSuivante, i, i + 1);
			}
		}
	}
};

// Appel un PCode d'affichage
WDTableZRNavigateur.prototype.__AppelPCodeAffichage = function __AppelPCodeAffichage(nLigne, fPCode)
{
	if (fPCode != clWDUtil.m_pfVide)
	{
		try
		{
			// Note que l'on est en PCode d'affichage (pas de reentrance)
			var bEnPCodeAffichageLigne = this.m_bEnPCodeAffichageLigne;
			this.m_bEnPCodeAffichageLigne = true;

			return this.__oAppelPCodeSurLigne(nLigne, fPCode);
		}
		finally
		{
			this.m_bEnPCodeAffichageLigne = bEnPCodeAffichageLigne;
		}
	}
};

// Appel un PCode en forcant la ligne courante de l'�l�ment
WDTableZRNavigateur.prototype.__oAppelPCodeSurLigne = function __oAppelPCodeSurLigne(nLigne, fPCode, oEvent)
{
	if (fPCode != clWDUtil.m_pfVide)
	{
		try
		{
			// Force la s�lection
			var nForceSelectionInitial = this.nGetForceSelection();
			this.ForceSelection(nLigne);
			// Appel la methode sur la ligne
			return this._voAppelPCodeSurLigne(nLigne, fPCode, oEvent);
		}
		finally
		{
			// Libere la s�lection
			this.m_oSelection.ForceSelection(nForceSelectionInitial);
		}
	}
};
WDTableZRNavigateur.prototype._voAppelPCodeSurLigne = function _voAppelPCodeSurLigne(nLigne, fPCode, oEvent)
{
	// Appel simple du PCode
	return fPCode(oEvent);
};

// Notifie de la modication de la ruptures
WDTableZRNavigateur.prototype.__OnLigneModificationRuptures = function __OnLigneModificationRuptures(nLigne)
{
	// Si on demande de modifier la ligne "invalide", c'est que la premier ligne doit etre modifiee
	if (this.ms_nLigneInvalide == nLigne)
	{
		// Traite ensuite comme cas particuler dans __TableAfficheCalculs
		nLigne = 0;
	}
	var oLigne = this.m_tabLignes[nLigne];
	if (oLigne)
	{
		oLigne.SetModifieRuptures(true);
	}
};

// Notifie de la modication des lignes (recalcul les ruptures)
WDTableZRNavigateur.prototype.__OnLigneModification = function __OnLigneModification(nLigne, nLigneMontre, bSansReaffichage, bPourNouvelleLigneVirtuelle)
{
	var oLigne = this.m_tabLignes[nLigne];

	// Si la ligne est la ligne virtuelle, la transforme en ligne normale, puis ajoute une nouvelle ligne virtuelle
	// bSansReaffichage : pour ne pas entrer en modification lors de l'ajout d'une nouvelle ligne virtuelle (on a forc�ment une autre modification)
	if (!bPourNouvelleLigneVirtuelle && oLigne.bGetLigneVirtuelle())
	{
		oLigne.RAZLigneVirtuelle();
		this.__AjouteLigneVirtuelle();
		// Le nombre de ligne a changer
		this._OnNbLignesChange();
	}

	// GP 14/01/2014 : Si la table est tri�e, il ne faudrait par retirer la table si la colonne modifi�e est une colonne tri�e ?

	// On note aussi de recalculer la rupture entre la ligne precedente et la ligne
	this.__OnLigneModificationRuptures(nLigne - 1);
	this.__OnLigneModificationRuptures(nLigne);

	// Recalcule si la ligne respecte le filtre
	if (this._bAvecFiltre())
	{
		var bVerifieFiltreOld = oLigne.bGetVerifieFiltre();
		var oVerifieFiltreNew = this._bVerifieFiltre(oLigne.tabGetValeurs());
		oLigne.SetVerifieFiltre(oVerifieFiltreNew);

		// Le nombre de ligne effectivement affich� a chang�
		if (bVerifieFiltreOld != oVerifieFiltreNew)
		{
			this._OnNbLignesChange();
		}
	}

	this._TableAfficheLigne(nLigne, nLigneMontre, bSansReaffichage);
};

// Modifie une ligne avec un tableau de valeurs
// Version interne avec les parametres validees
WDTableZRNavigateur.prototype.__LigneModifie = function __LigneModifie(tabValeurs, nLigne, bSansReaffichage, bPourNouvelleLigneVirtuelle)
{
	// Formate le tableau selon les attributs/colonnes
	var tabLigneValeurs = this.m_tabLignes[nLigne].tabGetValeurs();
	var tabColonnes = this.m_tabColonnes;
	var i;
	var nLimiteI = tabColonnes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		tabLigneValeurs[i] = tabColonnes[i].oGetValeurInterne(tabValeurs[i], bPourNouvelleLigneVirtuelle);
	}

	// Notifie de la modication des lignes (recalculs, PCode et reaffichage)
	this.__OnLigneModification(nLigne, undefined, bSansReaffichage, bPourNouvelleLigneVirtuelle);
};

// Ecrit le contenu du HTML dans la balise parent
WDTableZRNavigateur.prototype._HTMLAffiche = function _HTMLAffiche(oHote, tabHTML)
{
	// Vide la cellule et supprime les elements JavaScript pour les reference circulaires entre le DOM et le JS
	clWDUtil.SupprimeFilsEtOnFocus(oHote, false);

	// A factoriser avec WDTable::_vGenereLignesHTML
	if (bIE && clWDUtil.bBaliseEstTag(oHote, "table"))
	{
		var tabHTMLHote = (oHote.outerHTML + "").split("><");
		oHote.outerHTML = tabHTMLHote[0] + ">" + tabHTML.join("") + "<" + tabHTMLHote[tabHTMLHote.length - 1];
	}
	else
	{
		oHote.innerHTML = tabHTML.join("");
	}

	// Trouve l'hote (potentiellement ecrase par le outerHTML)
	this._vLiaisonHTML();
};

// Affiche la table/zone r�p�t�e depuis un point donne
WDTableZRNavigateur.prototype.__TableAffiche = function __TableAffiche(nLigneDepuis)
{
	// Notifie que le champ va �tre redessin�
	// oInformationAffiche : objet remplit par _vPreAffiche et lut par _voPostAffiche
	var oInformationAffiche = {};
	this._vPreAffiche(oInformationAffiche);

	// Gere les lignes modifiee :
	// - Recalcul des ruptures
	// - PCode d'affichage
	this.__TableAfficheCalculs(nLigneDepuis);

	var tabHTML = [];

	var tabLignes = this.m_tabLignes;
	var nLigne;
	var nLigneAffiche = 0;
	var nLimiteLigne = this._nGetNbLignes();
	for (nLigne = 0; nLigne < nLimiteLigne; nLigne++)
	{
		var oLigne = tabLignes[nLigne];
		// Uniquement si la ligne v�rifie le filtre. Si la ligne ne v�rifie pas le filtre, elle n'est pas affich�e
		if (!oLigne.bGetVerifieFiltre())
		{
			continue;
		}
		this._vHTMLGenereLigne(nLigne, nLigneAffiche, oLigne, tabHTML);
		// Compte le nombre de ligne affich�e (pour la couleur de fond des lignes)
		nLigneAffiche++;
	}

	// Place le HTML dans la zone cliente du corps
	this._HTMLAffiche(this.m_oHote, tabHTML);

	// Si le champ est superposable, IE ne le redessine pas bien
	if (bIEQuirks)
	{
		var oExterne = _JGE(this.m_sAliasChamp, document, true, false);
		if (oExterne && (clWDUtil.oGetCurrentStyle(oExterne).position == "absolute"))
		{
			oExterne.className = oExterne.className;
		}
	}

	// Notifie que le champ a �t� redessin� :
	// - Hook les onblur/onchange des elements (ZRs)
	// - Notifie les champs de l'affichage des lignes (ZRs)
	// - Redonne le focus (ZRs)
	// - Recalul la zone des titres (tables)
	// oInformationAffiche : objet remplit par _vPreAffiche et lut par _voPostAffiche
	this._vPostAffiche(oInformationAffiche);

	// Notifie aussi de la modification du HTML de la page
	clWDUtil.m_oNotificationsAjoutHTML.LanceNotifications(this, this.m_oHote);
};

// Notifie que le champ va �tre redessin�
// oInformationAffiche : objet remplit par _vPreAffiche et lut par _voPostAffiche
WDTableZRNavigateur.prototype._vPreAffiche = function _vPreAffiche(oInformationAffiche)
{
	// Conserve le focus
	this.__MemoriseFocus(oInformationAffiche);

	// GP 17/11/2012 : Notifie les champs de la disparition des lignes ?
};

// Conserve le focus
WDTableZRNavigateur.prototype.__MemoriseFocus = function __MemoriseFocus(oInformationAffiche)
{
	// Conserve le focus
	try
	{
		var oFocus = document.activeElement;
		if (oFocus && clWDUtil.bEstFils(oFocus, this.m_oHote))
		{
			var sFocusNom = oFocus.name;
			if (sFocusNom && sFocusNom.length)
			{
				var nFocusIndice = clWDUtil.nDansTableau(document.getElementsByName(sFocusNom), oFocus);
				if (clWDUtil.nElementInconnu == nFocusIndice)
				{
					nFocusIndice = 0;
				}
				oInformationAffiche.m_sFocusNom = sFocusNom;
				oInformationAffiche.m_nFocusIndice = nFocusIndice;
			}
		}
	}
	catch (e)
	{
	}
};

// Notifie que le champ a �t� redessin� :
// - Hook les onblur/onchange des elements (ZRs)
// - Notifie les champs de l'affichage des lignes (ZRs)
// - Redonne le focus (ZRs)
// - Recalul la zone des titres (tables)
// oInformationAffiche : objet remplit par _vPreAffiche et lut par _voPostAffiche
WDTableZRNavigateur.prototype._vPostAffiche = function _vPostAffiche(oInformationAffiche)
{
	// Hook les onblur/onchange des champs formulaire de la ZR (sans les liens)
	this.__SetOnBlurChange();

	// GP 17/11/2012 : QW226177
	// Notifie les champs de l'affichage des lignes (pour les ZRs)
	this.__OnAffichageLignes();

	// Replace le focus
	this.__ReplaceFocus(oInformationAffiche);
};

// Hook les onblur/onchange des champs formulaire de la ZR (sans les liens)
WDTableZRNavigateur.prototype.__SetOnBlurChange = function __SetOnBlurChange()
{
	var tabElements = clWDUtil.tabGetElements(this.m_oHote, false);
	var i;
	var nLimiteI = tabElements.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oElement = tabElements[i];
		// Si on est dans un champ formulaire, le nom de l'element est de la forme "zrl_LIGNE_ATTRIBUT"
		var tabRes = [];
		if (clWDUtil.bEstAliasAttributZR(oElement, tabRes))
		{
			var nLigne = this._nLigneWLLigne(tabRes[0]);
			var nColonne = this._nGetColonneSelonAlias(tabRes[1]);
			if ((nLigne !== undefined) && (nColonne !== undefined))
			{
				var sOnXxx = (undefined !== oElement.onchange) ? "onchange" : "onblur";
				// GP 26/11/2012 : QW226710 : R�gression cr�e par l'ajout de vTableZROnValideLigne. Ici sElementNom ne sert a rien et fait interf�rence
//				clWDUtil.SetOnXxx(oElement, sOnXxx, this, this.__OnLigneModifieFormulaire, [nColonne, nLigne, sElementNom], true);
				clWDUtil.SetOnXxx(oElement, sOnXxx, this, this.__OnLigneModifieFormulaire, [nColonne, nLigne], true);
				// GP 06/11/2021 : QW445785 : Intercepte "oninput" : appel d�s qu'il y a une modification et c'est assez t�t pour avoir la bonne valeur dans le cas du input g�n�ral pour l'�v�nement de modification du champ.
//				// GP 30/11/2016 : TB98347 : Intercepte aussi keyup pour faire une MAJ plus tot
//				// Note : on n'intercepte pas keypress car la valeur du champ n'a pas encore �t� MAJ pendant l'�v�nement
				if (undefined !== oElement.oninput)
				{
					clWDUtil.SetOnXxx(oElement, "oninput", this, this.__OnLigneModifieFormulaire, [nColonne, nLigne], true);
				}
			}
		}
	}
};

// Indique que un champ formulaire a ete modifie dans la ligne
WDTableZRNavigateur.prototype.__OnLigneModifieFormulaire = function __OnLigneModifieFormulaire(oEvent, tabParametres)
{
	var nColonne = tabParametres[0];
	var nLigne = tabParametres[1];
	var oValeur;

	var oColonne = this.m_tabColonnes[nColonne];

	// Si on est dans un appel via vTableZROnValideLigne
	if (2 < tabParametres.length)
	{
		oValeur = oColonne.oGetValeurInterne(tabParametres[2]);
	}
	else
	{
		// Lit la valeur de l'element
		var oChamp = clWDUtil.oGetTarget(oEvent);
		oValeur = oChamp.value;
		switch (oChamp.type.toLowerCase())
		{
		case "checkbox":
			// Ne fonctionne pas (comme en serveur) en cas de multiple coche
			oValeur = !!oChamp.checked;
			break;
		case "radio":
			// On recoit la selection pour celui selectionne et la deselection pour l'autre
			if (!oChamp.checked)
			{
				return;
			}
			break;
		// select-multiple inutilisable dans une ZR
		case "select-multiple":
		case "select-one":
			oValeur = (oChamp.selectedIndex != -1) ? parseInt(oChamp.options[oChamp.selectedIndex].value, 10) : -1;
			break;
		case "text":
			if (oColonne.m_pfConversionDepuisAffichage)
			{
				oValeur = oColonne.m_pfConversionDepuisAffichage(oValeur);
			}
			break;
		default:
			break;
		}
	}

	this.m_tabLignes[nLigne].tabGetValeurs()[nColonne] = oValeur;

	// Notifie de la modication des lignes (recalcul les ruptures)
	// GP 30/03/2021 : TB110195 : La saisie devient impossible si on r�affiche toujours (puisque chaque frappe d�clenche un r�affichage) en pr�sence de ruptures.
	// => Regarde si la colonne/l'attribut est li� � un rupture.
	// Si on trouve une rupture qui correspond, on fait un break, donc clWDUtil.bForEach retourne false qui est la valeur attendue (sinon retourne true (y compris sans ruptures)
	var bSansReaffichage = clWDUtil.bForEach(this.m_tabRuptures, function (oRupture)
	{
		return oRupture.m_nColonne !== nColonne;
	});
	this.__OnLigneModification(nLigne, this.ms_nLigneInvalide, bSansReaffichage);
};

// GP 17/11/2012 : QW226177
// Notifie les champs de l'affichage des lignes (pour les ZRs)
WDTableZRNavigateur.prototype.__OnAffichageLignes = function __OnAffichageLignes()
{
	var nSelection = this._nGetSelection();
	// Compte aussi le nombre r�el de ligne affich�e (en cas de filtre)
	var nLigneWL = 0;
	var tabLignes = this.m_tabLignes;
	var nLigne;
	var nLimiteLigne = this._nGetNbLignes();
	for (nLigne = 0; nLigne < nLimiteLigne; nLigne++)
	{
		// Si la ligne est visible (= respecte le filtre)
		if (tabLignes[nLigne].bGetVerifieFiltre())
		{
			nLigneWL++;
			// Logiquement nLigneWL == this._nLigneLigneWL(nLigne)
			this.m_tabChampsFils._AppelMethodePtr(WDChamp.prototype.OnLigneTableZRAffiche, [nLigneWL, nLigne == nSelection]);
		}
	}
};

// Replace le focus
WDTableZRNavigateur.prototype.__ReplaceFocus = function __ReplaceFocus(oInformationAffiche)
{
	if (oInformationAffiche.m_nFocusIndice !== undefined)
	{
		this.nSetTimeoutUnique("__SetFocus", clWDUtil.ms_oTimeoutImmediat, oInformationAffiche);
	}
};

// Replace le focus perdu par le reaffichage
WDTableZRNavigateur.prototype.__SetFocus = function __SetFocus(oInformationAffiche)
{
	if (oInformationAffiche.m_nFocusIndice !== undefined)
	{
		try
		{
			document.getElementsByName(oInformationAffiche.m_sFocusNom)[oInformationAffiche.m_nFocusIndice].focus();
		}
		catch (e)
		{
		}
	}
};

// Indique que le nombre de lignes a changer et qu'il faut faire une MAJ de m_nNbLignesWL
WDTableZRNavigateur.prototype._OnNbLignesChange = function _OnNbLignesChange()
{
	// GP 22/11/2013 : A optimiser un jour, pour ne faire que un appel en fin des suppressions ou en optimisant avec un flag de validit� de la valeur
	// et ne faire le calcul que lors de la lecture de la valeur m_nNbLignesWL

	// Calcule le nombre de lignes disponibles pour l'utilisateur
	var nNbLignesWL;
	if (this._bAvecFiltre())
	{
		// Avec un filtre : compte les lignes non filtr�es
		nNbLignesWL = 0;
		var tabLignes = this.m_tabLignes;
		var nLigne;
		var nLimiteLigne = this._nGetNbLignes();
		for (nLigne = 0; nLigne < nLimiteLigne; nLigne++)
		{
			// Si la ligne est visible (= respecte le filtre)
			if (tabLignes[nLigne].bGetVerifieFiltre())
			{
				nNbLignesWL++;
			}
		}
	}
	else
	{
		// Sans filtre : compte toutes les lignes
		nNbLignesWL = this._nGetNbLignes();
	}

	// On ne compte pas la ligne virtuelle dans les lignes du WL
	if (this.m_bSaisieCascade)
	{
		nNbLignesWL--;
	}

	this.m_nNbLignesWL = nNbLignesWL;
};

// Supprime une ligne
WDTableZRNavigateur.prototype._bLigneSupprime = function _bLigneSupprime(nLigne)
{
	var oLigne = this.m_tabLignes[nLigne];

	// Supprime la ligne (Supprime aussi la ligne de la s�lection)
	oLigne.OnSupprime();
	this.m_tabLignes.splice(nLigne, 1);

	// Impossible de supprimer la ligne virtuelle : la recr�e a vide
	if (oLigne.bGetLigneVirtuelle())
	{
		this.__AjouteLigneVirtuelle();
	}

	// GP 22/11/2013 : QW239647 : Indique que le nombre de ligne a chang�
	// GP 22/11/2013 : A optimiser un jour, pour ne faire que un appel en fin des suppressions ou en optimisant avec un flag de validit� de la valeur
	// et ne faire le calcul que lors de la lecture de la valeur m_nNbLignesWL
	this._OnNbLignesChange();

	// Notifie la s�lection de la suppression de la ligne (d�cale le reste de la s�lection, et �ventuellement res�lectionne la ligne (visible) suivante)
	this.m_oSelection.OnLigneSupprime(nLigne);

	// On note aussi de recalculer la rupture entre la ligne precedente et la ligne
	this.__OnLigneModificationRuptures(nLigne - 1);

	// Retourne une valeur pour le bForEachThis de SupprimeSelect
	return true;
};

// Supprime toutes les lignes
WDTableZRNavigateur.prototype._LigneSupprimeTout = function _LigneSupprimeTout()
{
	// Supprime toutes la s�lection
	this.m_oSelection.bSelectAucun();

	// Supprime toutes les lignes
	clWDUtil.bForEach(this.m_tabLignes, function(oLigne)
	{
		oLigne.OnSupprime();
		return true;
	});

	// Et vide le tableau
	this.m_tabLignes.length = 0;

	// Recr�ation de la lligne virtuelle si besoin
	if (this.m_bSaisieCascade)
	{
		this.__AjouteLigneVirtuelle();
	}

	this._OnNbLignesChange();

	// Reaffiche la table depuis le debut
	this._TableAffiche();
};

// Fonction de comparaison pour le tri
WDTableZRNavigateur.prototype.__s_nTriCompare = function __s_nTriCompare(oLigne1, oLigne2, tabTri)
{
	// La ligne virtuelle est toujours en dernier
	if (oLigne1.bGetLigneVirtuelle())
	{
		return 1;
	}
	if (oLigne2.bGetLigneVirtuelle())
	{
		return -1;
	}

	// Compare selon les criteres de tri
	var tabValeurs1 = oLigne1.tabGetValeurs();
	var tabValeurs2 = oLigne2.tabGetValeurs();
	var i;
	var nLimiteI = tabTri.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oTri = tabTri[i];
		var nRes = oTri.m_fCompare(tabValeurs1[oTri.m_nColonne], tabValeurs2[oTri.m_nColonne]);
		// Si les valeurs ne sont pas egales
		if (0 != nRes)
		{
			// Si on inverse
			return oTri.m_bCroissant ? nRes : -nRes;
		}
	}
	// Egaux
	return 0;
};

// Recherche une ligne
WDTableZRNavigateur.prototype.__nLigneCherche = function __nLigneCherche(tabNumColonnes, sRecherche, nTypeRecherche, nLigneDebut)
{
	// GP 22/04/2016 : QW272683 : si nLigneDebutWL est apr�s la fin du fichier il ne faut pas faire une recherche du d�but (= partout) mais pas de recherche
	if (this.ms_nLigneInvalide != nLigneDebut)
	{
		// Pr�pare les param�tres par colonne
		var tabParametres = [];
		var tabColonnes = this.m_tabColonnes;
		clWDUtil.bForEach(tabNumColonnes, function(nColonne)
		{
			// Trouve la colonne, normalise la valeur recherchee et trouve la fonction de comparaison
			var oColonne = tabColonnes[nColonne];
			tabParametres.push({
				oColonne: oColonne,
				nColonne: nColonne,
				oRecherche: oColonne.oGetValeurInterne(sRecherche),
				fCompare: oColonne.fGetCompare(nTypeRecherche)
			});

			return true;
		});

		// Optimisation possible : en cas de table triee faire une recherche dichotomique

		// Recherche dans les lignes
		var tabLignes = this.m_tabLignes;
		var nLigne;
		var nLimiteLigne = this._nGetNbLignes();
		for (nLigne = nLigneDebut; nLigne < nLimiteLigne; nLigne++)
		{
			var oLigne = tabLignes[nLigne];

			// Uniquement si la ligne v�rifie le filtre. Si la ligne ne v�rifie pas le filtre, elle n'est pas affich�e
			if (!oLigne.bGetVerifieFiltre())
			{
				continue;
			}

			if (!clWDUtil.bForEach(tabParametres, function(oParametre)
			{
				// GP 12/09/2013 : Inversion on doit bien recherche que la valeur de la colonne commence par la valeur recherch�e et pas l'inverse
				// false : on d�sire la valeur de programmation
				// En cas de valeur �gale :
				// - oParametre.fCompare retourne 0
				// - la fonction retourne false
				// - clWDUtil.bForEach arrete le parcours et retourne false
				// - la fonction retourn nLigne
				return 0 != oParametre.fCompare(oParametre.oColonne.oGetValeurAvecLigne(oParametre.nColonne, oLigne, false), oParametre.oRecherche);
			}))
			{
				return nLigne;
			}
		}
	}

	return this.ms_nLigneInvalide;
};

// Retourne une propri�t� (pour le parsing du HTML)
WDTableZRNavigateur.prototype._vsLitPropriete = function _vsLitPropriete(nLigne, nLigneAffiche, oLigne, ePropriete, oParametre/*, bPourCondition*/)
{
	switch (ePropriete)
	{
	case this.XML_CHAMP_PROP_NUM_VALEUR:
		// Inutile de faire le calcul on a d�j� la valeur dans nLigneAffiche
		// Donne la ligne en indice WL
//		return this._nLigneLigneWL(nLigne);
		return nLigneAffiche + 1;

	case this.XML_CHAMP_PROP_NUM_COULEURFOND:
		// Si la ligne a une couleur de fond (non disponible en WL navigateur actuellement)
		if (oLigne.m_sCouleurFond !== undefined)
		{
			return oLigne.m_sCouleurFond;
		}
		return "";

	case this.ms_nAttributRuptureLigneDebut:
		// GP 17/10/2013 : On compte en ligne affich�e : nLigneAffiche
		// Il n'y a pas encore de lignes invisibles
		// Donc c'est une simple division
		return 0 === (nLigneAffiche % this.m_nNbLignesLogiquesParLignePhysique);
	case this.ms_nAttributRuptureLigneFin:
		// Il n'y a pas encore de lignes invisibles
		// Donc c'est une simple division
		return (nLigneAffiche % this.m_nNbLignesLogiquesParLignePhysique) == (this.m_nNbLignesLogiquesParLignePhysique - 1);

	case this.ms_nAttributLigneRepliee:
		return !this.m_tabLignes[nLigne].bGetDeroule();

	case this.ms_nAttributIncludeHautRupture:
		return this.__bGetRuptureVisible(nLigne, oParametre, true);
	case this.ms_nAttributIncludeBasRupture:
		return this.__bGetRuptureVisible(nLigne, oParametre, false);

	case this.ms_nAttributLignePaire:
		// GP 17/10/2013 : On compte en ligne affich�e : nLigneAffiche
		// nLigneAffiche commence � 0. La premi�re ligne (indice C : 0, indice WL : 1) est une ligne impaire
		// donc il faut comparer a 1
		return 1 === (nLigneAffiche % 2);

	case this.ms_nAttributSelected:
		// GP 15/11/2013 : Non ne fait. Modifi� par GF. On recoit toujours le texte sans l'espace
//		// GP 15/11/2013 : QW239107 : Il est important d'avoir l'espace au d�but
		return this.m_oSelection.bGetLigneEstSelectionnee(nLigne) ? "SELECTED" : "";

	case this.ms_nAttributCodeHTML30:
		// CodeHTML30 : Nombre de rowspan pour un surentete
		return this.__nGetNbCOLPSANPourCelluleSurEntete(oParametre);
	case this.ms_nAttributCodeHTML31:
		// CodeHTML31 : Colonne redimensionn�e par un surentete
		return this.__nGetColonneRedimPourCelluleSurEntete(oParametre);
	case this.ms_nAttributCodeHTML32:
		// CodeHTML32 : Colspan a utiliser pour la cellule des ruptures dans une table
		return this._vnGetColSpanRupture();
	case this.ms_nAttributExiste:
		// Regarde si un attribut automatique de ce nom existe
		return this.__bGetAttributAutomatiqueExiste(oParametre);

	default:
		return "";
	}
};

// Indique si la rupture est visible
WDTableZRNavigateur.prototype.__bGetRuptureVisible = function __bGetRuptureVisible(nLigne, nRupture, bHaut)
{
	// Si la rupture est invisible
	if (!this.m_tabRuptures[nRupture].bVisible(bHaut))
	{
		return false;
	}
	// Rebond sur la methode de la ligne
	return this.m_tabLignes[nLigne].bGetRuptureVisible(nRupture, bHaut);
};

// CodeHTML30 : Nombre de rowspan pour un surentete
WDTableZRNavigateur.prototype.__nGetNbCOLPSANPourCelluleSurEntete = function __nGetNbCOLPSANPourCelluleSurEntete(nCelluleSurEntete)
{
	var nNbColonnesEdition = this._nGetNbColonnes();
	var nColonne = nCelluleSurEntete % nNbColonnesEdition;
	// GP 26/11/2013 : La division donne un nombre r�el si on ne se ramene pas sur un multiple de nNbColonnesEdition
//	var nLigne = nCelluleSurEntete / nNbColonnesEdition;
	var nLigne = (nCelluleSurEntete - nColonne) / nNbColonnesEdition;
	var nNbColonnes = this.m_tabSurEntetes[nLigne][nColonne];

	// COLPSAN actuel. On doit compter les colonnes pour le redimensionnement, uniquement si on n'est pas sur la derni�re colonne.
	// - nColSpanSiDernier : COLSPAN si la derni�re colonne trouv�e est la derni�re
	// - nColSpanSiPasDernier : COLSPAN si la derni�re colonne trouv�e n'est pas la derni�re (= avec la colonne s�parateur si elle existe)
	var nColSpanSiDernier = 0;
	var nColSpanSiPasDernier = 0;

	while (0 < nNbColonnes)
	{
		// Normalement la valeur re�ue est une valeur calcul�e par la g�n�ration HTML, donc valide
		// On fait quand m�me quelques v�rifications

		// Comme on ne peut pas changer l'ordre des colonnes si elle partage un surent�te, on peut faire le calcul uniquement avec l'ordre de cr�ation.
		var oColonne = this._oGetColonne(nColonne);
		// Si la colonne est visible, on incr�mente le COLSPAN
		if (oColonne.bGetVisible())
		{
			// On repart de la valeur nColSpanSiPasDernier puisque la colonne pr�c�dente n'est pas la derni�re
			nColSpanSiDernier = nColSpanSiPasDernier + 1;
			nColSpanSiPasDernier = nColSpanSiPasDernier + 1;
			if (oColonne.m_bAjustable)
			{
				nColSpanSiPasDernier++;
			}
		}

		// Colonne suivante
		nColonne++;
		nNbColonnes--;
	}

	return nColSpanSiDernier;
};

// CodeHTML31 : Colonne redimensionn�e par un surentete
WDTableZRNavigateur.prototype.__nGetColonneRedimPourCelluleSurEntete = function __nGetColonneRedimPourCelluleSurEntete(nCelluleSurEntete)
{
	var nNbColonnesEdition = this._nGetNbColonnes();
	var nColonne = nCelluleSurEntete % nNbColonnesEdition;
	// GP 26/11/2013 : La division donne un nombre r�el si on ne se ramene pas sur un multiple de nNbColonnesEdition
//	var nLigne = nCelluleSurEntete / nNbColonnesEdition;
	var nLigne = (nCelluleSurEntete - nColonne) / nNbColonnesEdition;
	var nNbColonnes = this.m_tabSurEntetes[nLigne][nColonne];

	// Trouve la derni�re colonne visible dans la cellule (on commence donc la recherche depuis la fin)
	for (var nColonneDerniere = nColonne + nNbColonnes - 1; nColonne <= nColonneDerniere; nColonneDerniere--)
	{
		// Normalement la valeur re�ue est une valeur calcul�e par la g�n�ration HTML, donc valide
		// On fait quand m�me quelques v�rifications

		// Comme on ne peut pas changer l'ordre des colonnes si elle partage un surent�te, on peut faire le calcul uniquement avec l'ordre de cr�ation.
		var oColonne = this._oGetColonne(nColonne);
		// Si la colonne est visible, comme elle est plus � droite de la colonne pr�c�dente, on la m�morise
		if (oColonne.bGetVisible())
		{
			return nColonneDerniere;
		}
	}

	// On n'a trouv� aucune colonne valide, retourne le num�ro de la pr�mi�re colonne
	return nColonne;
};

// CodeHTML32 : Colspan a utiliser pour la cellule des ruptures dans une table
WDTableZRNavigateur.prototype._vnGetColSpanRupture = function _vnGetColSpanRupture()
{
	// Qui renvoyer ? On retourne une valeur HTML invalide pour le moment
	return "";
};

// EXISTE_ : V�rifie si un attribut automatique de cet alias existe
WDTableZRNavigateur.prototype.__bGetAttributAutomatiqueExiste = function __bGetAttributAutomatiqueExiste(sAlias)
{
	return !!this._nGetColonneSelonAlias(sAlias);
};

// Indique si une ligne v�rifie le filtre
WDTableZRNavigateur.prototype._bVerifieFiltre = function _bVerifieFiltre(tabValeurs)
{
	// Si on ne v�rifie pas le filtre, oFiltre.m_fFiltre retourne false, ce qui d�clenche un return false dans clWDUtil.bForEach
	// Si on n'a aucun crit�re de filtre, clWDUtil.bForEach retourne true ce qui est correct.
	return clWDUtil.bForEach(this.m_tabFiltre, function(oFiltre)
	{
		return oFiltre.m_fFiltre(tabValeurs[oFiltre.m_nColonne], oFiltre.m_sValeur);
	});
};

// Trouve la valeur (affich� pour la valeur) d'une colonne/ligne
WDTableZRNavigateur.prototype._oGetProprieteColonneAvecIndice = function _oGetProprieteColonneAvecIndice(nColonne, nLigne, nLigneAffiche, ePropriete, bValeurAffichee)
{
	return this._oGetColonne(nColonne).vsLitPropriete(this, nColonne, nLigne, nLigneAffiche, this.m_tabLignes[nLigne], ePropriete, bValeurAffichee)
};

// Trouve la valeur (de programmation) pour la lecture depuis le WL
WDTableZRNavigateur.prototype._voGetProprieteColonneAvecIndicePourWL = function _voGetProprieteColonneAvecIndicePourWL(nColonne, nLigne, ePropriete)
{
	return this._oGetProprieteColonneAvecIndice(nColonne, nLigne, nLigne, ePropriete, false);
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		M�thodes utilitaires pour les WL

// Modifie une ligne avec un tableau de valeurs
WDTableZRNavigateur.prototype._xLigneModifie = function _xLigneModifie(tabValeurs, oLigneWL)
{
	var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());
	// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne lance une exception
	// Modifie la ligne (provoque le reaffichage)
	this.__LigneModifie(tabValeurs, nLigne);
};

// Insere une ligne avec un tableau de valeurs
// Sans indice, insere a la fin (= ajout)
WDTableZRNavigateur.prototype._nLigneInsere = function _nLigneInsere(bTrie, tabValeurs, oLigneWL)
{
	// Si on a 3 param�tres c'est que l'on est dans une syntaxe "Ins�re" qui en WL accepte 0 pour la premi�re ligne...
	var nLigne = this._nLigneWLLigne(oLigneWL, undefined, undefined, undefined, undefined, 3 === arguments.length);
	if ((nLigne === undefined) && this.m_bSaisieCascade)
	{
		// Ajoute avant la ligne virtuelle
		nLigne = this._nGetNbLignes() - 1;
	}

	// Ajoute une ligne vide
	var oLigne = new (this._vLigne)(this._nGetNbColonnes());
	if (nLigne !== undefined)
	{
		// Ajoute au milieu
		this.m_tabLignes.splice(nLigne, 0, oLigne);
	}
	else
	{
		// Ajoute a la fin
		this.m_tabLignes.push(oLigne);
		nLigne = this._nGetNbLignes() - 1;
	}
	this._OnNbLignesChange();

	// Modifie la ligne (provoque le reaffichage)
	this.__LigneModifie(tabValeurs, nLigne);

	// Notifie la s�lection de l'insertion de la ligne (d�cale les lignes suivantes)
	this.m_oSelection.OnLigneInsere(nLigne);

	var i;
	var nLimiteI;
	if (bTrie)
	{
		// Lent mais juste : retrie la table si besoin
		this._TriEncore();
		// Si le numero de ligne change pendant le tri
		if (this.m_tabLignes[nLigne] != oLigne)
		{
			nLimiteI = this._nGetNbLignes();
			for (i = 0; i < nLimiteI; i++)
			{
				if (this.m_tabLignes[i] == oLigne)
				{
					nLigne = i;
					break;
				}
			}
		}

		// Modifie la ligne (provoque le reaffichage)
		this.__LigneModifie(tabValeurs, nLigne);
	}

	// Si la ligne est dans une rupture repliee, ajoute la ligne en repliee
	nLimiteI = this._nGetNbRuptures();
	if (0 < nLimiteI)
	{
		if (0 < nLigne)
		{
			// Copie l'etat d'enroulement de la ligne precedente pour les ruptures identiques
			var oLignePrecedente = this.m_tabLignes[nLigne - 1];
			for (i = 0; i < nLimiteI; i++)
			{
				if (oLigne.bGetRuptureDirect(i, true))
				{
					// Plus dans la meme zone de rupture
					break;
				}
				else
				{
					// Dans la meme zone de rupture : copie l'enroulement
					oLigne.CopieEnrouleDeroule(oLignePrecedente, i);
				}
			}
		}
		if (nLigne < (this._nGetNbLignes() - 1))
		{
			// Copie l'etat d'enroulement de la ligne precedente pour les ruptures identiques
			var oLigneSuivante = this.m_tabLignes[nLigne + 1];
			for (i = 0; i < nLimiteI; i++)
			{
				if (oLigneSuivante.bGetRuptureDirect(i, true))
				{
					// Plus dans la meme zone de rupture
					break;
				}
				else
				{
					// Dans la meme zone de rupture : copie l'enroulement
					oLigne.CopieEnrouleDeroule(oLigneSuivante, i);
				}
			}
		}
	}

	// Conversion en numero de ligne WL
	return this._nLigneLigneWL(nLigne);
};

// Redessine completement la table
WDTableZRNavigateur.prototype._TableAffiche = function _TableAffiche(nOptions, nParametre)
{
	// Ne fait pas de redessin si on le demande ou si on est deja en PCode d'affichage (donc en redessin)
	if (this.m_bEnPCodeAffichageLigne !== undefined)
	{
		return;
	}

	// On a besoin des param�tres en membre :
	// - _TableAfficheLigne fait des calculs avec m_nLigneAfficheSuivante
	// - OnChange d�clenche l'affichage (en synchrone) sans connaitre les param�tres

	// Affiche depuis le d�but de la table
	this.m_nLigneAfficheSuivante = 0;
	// Sauve les options
	if (undefined !== nOptions)
	{
		this.m_nTAOptions |= nOptions;
		this.m_nTAParametre = nParametre;
	}

	// Lance le SetTimeout (dans le cas ou le WL ne valide pas explicitement la MAJ)
	// GP 13/04/2018 : Vu en tracant TB99322 : Cr�ation d'une version optimis�e (la cr�ation du MessageChannel est couteuse et est faite en boucle)
	this.SetTimeoutUniqueO("_Affiche"/*, clWDUtil.ms_oTimeoutImmediat*/);
};

// Affiche la table/zone r�p�t�e depuis un point donne
WDTableZRNavigateur.prototype._TableAfficheLigne = function _TableAfficheLigne(nLigne, nLigneMontre, bSansReaffichage)
{
	// Ne fait pas de redessin si on le demande ou si on est deja en PCode d'affichage (donc en redessin)
	if (bSansReaffichage || (this.m_bEnPCodeAffichageLigne !== undefined))
	{
		return;
	}

	var nLigneAffiche = nLigne;
	// En fait on affiche depuis une ligne avant (la rupture a peut-etre ete modifiee)
	if (0 < nLigne)
	{
		nLigneAffiche--;
	}
	// Note que l'on devra afficher la ligne
	if (this.m_nLigneAfficheSuivante === undefined)
	{
		this.m_nLigneAfficheSuivante = nLigneAffiche;
	}
	else
	{
		this.m_nLigneAfficheSuivante = Math.min(nLigneAffiche, this.m_nLigneAfficheSuivante);
	}
	if ((undefined !== nLigneMontre) && (this.ms_nLigneInvalide != nLigneMontre))
	{
		// Montre toujours la derniere ligne demand�e
		this.m_nTAOptions |= clWDTableDefs.ms_nOptionTAMontreLigne;
		this.m_nTAParametre = nLigneMontre;
	}
	// Lance le SetTimeout (dans le cas ou le WL ne valide pas explicitement la MAJ)
	// GP 13/04/2018 : Vu en tracant TB99322 : Cr�ation d'une version optimis�e (la cr�ation du MessageChannel est couteuse et est faite en boucle)
	this.SetTimeoutUniqueO("_Affiche"/*, clWDUtil.ms_oTimeoutImmediat*/);
};

WDTableZRNavigateur.prototype._Affiche = function _Affiche()
{
	// Supprime le Timeout de meme nom s'il existe
	this.AnnuleTimeXXX("_Affiche", false);

	// Si on doit pr�server le scroll
	var nScrollTop;
	if (this.m_nTAOptions & clWDTableDefs.ms_nOptionTAPreserveScroll)
	{
		nScrollTop = this.m_oHote.parentNode.scrollTop;
	}

	// Redessin
	if (this.m_nTAOptions & clWDTableDefs.ms_nOptionTARedessineTitre)
	{
		this._vTableAfficheTitres();
	}
	this.__TableAffiche(this.m_nLigneAfficheSuivante);

	// Si on doit montrer une ligne (prioritaire sur clWDTableDefs.ms_nOptionTAPreserveScroll)
	if (this.m_nTAOptions & clWDTableDefs.ms_nOptionTAMontreLigne)
	{
		nScrollTop = this.oGetIDElement(this._nLigneLigneWL(this.m_nTAParametre)).offsetTop;
	}

	// Si finalement on doit montrer une ligne pr�cise
	if (undefined !== nScrollTop)
	{
		this.m_oHote.parentNode.scrollTop = nScrollTop;
	}
	this.m_nTAParametre = null;
	this.m_nTAOptions = 0;

	if (this.m_oCelluleSaisie)
	{
		this.m_oCelluleSaisie.OnMAJDonnees();
	}
};
WDTableZRNavigateur.prototype._vTableAfficheTitres = clWDUtil.m_pfVide;

// Indique un changement de s�lection
// bExecutePCode : C'est une s�lection (pas une d�selection) et on doit �x�cuter le PCode de s�lection
// (cas en s�lection initiale, s�lection apr�s un retri et s�lection par l'utilisateur)
WDTableZRNavigateur.prototype.OnChangementSelection = function OnChangementSelection(nLigne, bExecutePCode, oEvent)
{
	// Si on est en s�lection par l'utilisateur, ex�cute le PCode de s�lection de ligne
	if (bExecutePCode)
	{
		this.RecuperePCode(this.ms_nEventNavSelectLigne)(oEvent);
	}

	// GP 16/12/2013 : TB85165 : Si on est dans une ZR, ne redessine pas la table
	// En fait on ne redessine que si la couleur ne fond ne change pas.
	if (this.m_bDansSelectionExterne && this._vbAvecCouleurDeFondSelection())
	{
		this._vOnChangementSelectionSansRedessin(nLigne);
		return;
	}

	// Redessine la table pour cette ligne
	this._TableAfficheLigne(nLigne);
};
WDTableZRNavigateur.prototype._vOnChangementSelectionSansRedessin = clWDUtil.m_pfVide;

// Deplace/echange une/deux lignes
WDTableZRNavigateur.prototype._nLigneDeplace = function _nLigneDeplace(nLigneSource, nLigneDestination, bEchange, bMontre)
{
	var nLigneDestinationOriginale = nLigneDestination;

	// @@@ Interdit l'echange avec la ligne virtuelle

	var tabLignes = this.m_tabLignes;
	var oLigne = tabLignes[nLigneSource];
	if (bEchange)
	{
		tabLignes[nLigneSource] = tabLignes[nLigneDestination];
		tabLignes[nLigneDestination] = oLigne;
		// Modifie les lignes (provoque le reaffichage)
		this.__OnLigneModification(nLigneSource);
		this.__OnLigneModification(nLigneDestination, bMontre ? nLigneDestination : this.ms_nLigneInvalide);
	}
	else
	{
		// Normalement le r�sultat de splice est un tableau avec oLigne comme seul �l�ment
		tabLignes.splice(nLigneSource, 1);
		// Decale la destination si besoin
		if (nLigneSource < nLigneDestination)
		{
			nLigneDestination--;
		}
		tabLignes.splice(nLigneDestination, 0, oLigne);
		// Modifie les lignes (provoque le reaffichage)
		this.__OnLigneModification(nLigneDestination, bMontre ? nLigneDestination : this.ms_nLigneInvalide);
		// Modifie aussi les ruptures de la ligne avant la source
		this.__OnLigneModificationRuptures(nLigneSource - 1);
	}

	// Corrige la s�lection
	// Utilise la valeur de nLigneDestination non modifi�
	this.m_oSelection.OnLigneDeplace(nLigneSource, nLigneDestinationOriginale, bEchange);

	// Conversion en numero de ligne WL
	return this._nLigneLigneWL(nLigneDestination);
};

// Retourne la ligne selectionnee
WDTableZRNavigateur.prototype._nGetSelection = function _nGetSelection()
{
	return this.m_oSelection.nGetSelection();
};

// Retourne la ligne actuellement forc�e
WDTableZRNavigateur.prototype.nGetForceSelection = function nGetForceSelection()
{
	return this.m_oSelection.nGetForceSelection();
};
// Force la s�lection
WDTableZRNavigateur.prototype.ForceSelection = function ForceSelection(nSelection)
{
	return this.m_oSelection.ForceSelection(nSelection);
};

// Informations sur les ruptures
WDTableZRNavigateur.prototype._nIndiceRupture = function _nIndiceRupture(sAliasRupture, nLigne)
{
	// Trouve l'indice de la rupture
	var nRupture = this._nGetRuptureSelonAlias(sAliasRupture);
	if (nRupture !== undefined)
	{
		// Remonte les lignes
		var tabLignes = this.m_tabLignes;
		var i;
		for (i = nLigne; 0 <= i; i--)
		{
			if (tabLignes[i].bGetRupture(nRupture, true))
			{
				// Trouve
				return this._nLigneLigneWL(i);
			}
		}
		// Normalement n'arrive pas (sauve si on n'a pas de lignes ou pas de selection)
	}
	return this.ms_nLigneInvalide;
};

// Recherche une colonne par alias
WDTableZRNavigateur.prototype._xnGetColonneSelonAlias = function _xnGetColonneSelonAlias(sAliasColonne)
{
	var nColonne = this._nGetColonneSelonAlias(sAliasColonne);
	if (undefined === nColonne)
	{
		// Erreur fatale WL :
		// "Colonne <%1> inconnue."
		throw new WDErreur(302, sAliasColonne);
	}

	return nColonne;
};
WDTableZRNavigateur.prototype._xoGetColonneSelonAlias = function _xoGetColonneSelonAlias(sAliasColonne)
{
	// La colonne est forc�ment valide (_xnGetColonneSelonAlias fait une recherche dans la table pour trouver l'�l�ment)
	return this.m_tabColonnes[this._xnGetColonneSelonAlias(sAliasColonne)];
};

// Tri
WDTableZRNavigateur.prototype._Tri = function _Tri(sSensColonnes)
{
	// Annule le precedent tri
	this._TriAnnule();

	// Memorise le tri
	var bCroissant = true;
	var nColonne;
	var nLimite;
	switch (sSensColonnes)
	{
	case "-":
		bCroissant = false;
		// Pas de break
	case "+":
		// Tri sur toutes les colonnes/attributs
		nLimite = this._nGetNbColonnes();
		for (nColonne = 0; nColonne < nLimite; nColonne++)
		{
			this._ActiveTri(nColonne, bCroissant);
		}
		break;
	default:
		var tabSensColonnes = sSensColonnes.split("\t");
		nLimite = tabSensColonnes.length;
		var i;
		for (i = 0; i < nLimite; i++)
		{
			var sAliasColonne = tabSensColonnes[i];
			bCroissant = true;
			switch (sAliasColonne.substring(0, 1))
			{
			case "-":
				bCroissant = false;
				// Pas de break
			case "+":
				sAliasColonne = sAliasColonne.substring(1);
				break;
			default:
				break;
			}
			nColonne = this._xnGetColonneSelonAlias(sAliasColonne);
			// On ne peut pas recevoir undefined car dans ce cas _xnGetColonneSelonAlias lance une exception
			this._ActiveTri(nColonne, bCroissant);
		}
		break;
	}

	// Retri
	this._TriEncore();
};

// Ajoute le tri pour une colonne
WDTableZRNavigateur.prototype._ActiveTri = function _ActiveTri(nColonne, bCroissant)
{
	var oColonne = this.m_tabColonnes[nColonne];
	// On ne peut pas recevoir undefined car dans ce cas _xnGetColonneSelonAlias lance une exception
	this.m_tabTri.push({ m_fCompare: oColonne.fGetCompare(clWDUtil.nRechercheIdentique), m_nColonne: nColonne, m_bCroissant: bCroissant });

	// MAJ des pictos de recherche, tri et filtre sur changement du tri, de la recherche ou du filtre
	this._vInvalidePourTRF(nColonne, bCroissant);
};

// Tri sur une colonne unique
WDTableZRNavigateur.prototype._TriSurUneColonne = function _TriSurUneColonne(nColonne, bCroissant)
{
	// Tri de la colonne :
	// - Annule le precedent tri
	this._TriAnnule();
	// - Active le tri sur la colonne
	this._ActiveTri(nColonne, bCroissant);
	// - Effectue le tri
	this._TriEncore();
};

// Relance un tri (sans reinit de la s�lection)
WDTableZRNavigateur.prototype._TriEncore = function _TriEncore()
{
	// Uniquement si on a un tri
	var tabTri = this.m_tabTri;
	if (0 < tabTri.length)
	{
		this.m_tabLignes.sort(function() { return WDTableZRNavigateur.prototype.__s_nTriCompare(arguments[0], arguments[1], tabTri); });

		// R�init la s�lection (comme en code serveur) (uniquement si on a un tri)
		this.m_oSelection.ReinitSelection(0);
	}
};
WDTableZRNavigateur.prototype.SelectExterne = function SelectExterne(nIndiceWL)
{
	try
	{
		// GP 16/12/2013 : TB85165 : Temporaire : on ne redessine pas les ZRs
		clWDUtil.WDDebug.assert(undefined === this.m_bDansSelectionExterne, "Reentrance dans WDTableZRNavigateur.prototype.SelectExterne");
		var bDansSelectionExterne = this.m_bDansSelectionExterne;
		this.m_bDansSelectionExterne = true;

		// GP 01/09/2014 : Pour les tables avec colonnes conteneur et ruptures : Affine l'algo.
		// Si la s�lection est d�j� correcte, on ne fait rien
		this.m_oSelection.ReinitSelectionSansReselection(this._nLigneWLLigne(nIndiceWL));
	}
	finally
	{
		this.m_bDansSelectionExterne = bDansSelectionExterne;
	}
};

// MAJ des pictos de recherche, tri et filtre sur changement du tri, de la recherche ou du filtre
WDTableZRNavigateur.prototype._vInvalidePourTRF = clWDUtil.m_pfVide;

// Annule le tri
WDTableZRNavigateur.prototype._TriAnnule = function _TriAnnule()
{
	// Pour les colonnes qui sont actuellement tri�es
	var tabTri = this.m_tabTri;
	var nTri;
	var nLimiteTri = tabTri.length;
	for (nTri = 0; nTri < nLimiteTri; nTri++)
	{
		// MAJ des pictos de recherche, tri et filtre sur changement du tri, de la recherche ou du filtre
		this._vInvalidePourTRF(tabTri[nTri].m_nColonne);
	}

	this.m_tabTri.length = 0;
};

// Si on a un filtre
WDTableZRNavigateur.prototype._bAvecFiltre = function _bAvecFiltre()
{
	return 0 < this.m_tabFiltre.length;
};

// Annule le filtre
WDTableZRNavigateur.prototype._bFiltreAnnule = function _bFiltreAnnule()
{
	var bAvecFiltre = this._bAvecFiltre();
	this.m_tabFiltre.length = 0;
	return bAvecFiltre;
};

// Recherche une ligne
WDTableZRNavigateur.prototype._xnLigneCherche = function _xnLigneCherche(sAliasColonne, sRecherche, nTypeRecherche, nLigneDebut)
{
	// Trouve l'indice de la colonne
	var nColonne = this._xnGetColonneSelonAlias(sAliasColonne);
	// On ne peut pas recevoir undefined car dans ce cas _xnGetColonneSelonAlias lance une exception
	// Effectue la recherche
	var nLigneResultat = this.__nLigneCherche([nColonne], sRecherche, nTypeRecherche, nLigneDebut);

	// Conversion en numero de ligne WL
	return this._nLigneLigneWL(nLigneResultat);
};
WDTableZRNavigateur.prototype._xnLigneCherchePartout = function _xnLigneCherchePartout(sRecherche, nTypeRecherche, nLigneDebut)
{
	// Construit le tableau des colonnes recherch�es
	var tabColonnes = [];
	clWDUtil.bForEach(this.m_tabColonnes, function (oColonneOuAttribut, nColonne)
	{
		// S�lectionn les attributs et colonnes visibles.
		if ((function ()
		{
			if (oColonneOuAttribut instanceof WDAttribut)
			{
				switch (oColonneOuAttribut.m_eProprieteAssocie)
				{
				case WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR:
				case WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLE:
				case WDChamp.prototype.XML_CHAMP_PROP_NUM_CONTENU:
					return true;
				}
			}
			else if (oColonneOuAttribut instanceof WDTableColonne)
			{
				return oColonneOuAttribut.bGetVisible();
			}
			else
			{
				clWDUtil.WDDebug.assert(false, "oColonneOuAttribut n'est ni un attribut ni une colonne");
			}
			return false;
		})())
		{
			tabColonnes.push(nColonne);
		}
		return true;
	});

	// On ne peut pas recevoir undefined car dans ce cas _xnGetColonneSelonAlias lance une exception
	// Effectue la recherche
	var nLigneResultat = this.__nLigneCherche(tabColonnes, sRecherche, nTypeRecherche, nLigneDebut);

	// Conversion en numero de ligne WL
	return this._nLigneLigneWL(nLigneResultat);
};

// Enroule/deroule une ligne (Inverse si bDeroule n'est pas defini)
WDTableZRNavigateur.prototype._EnrouleDerouleI = function _EnrouleDerouleI(nLigne, nRupture, bDeroule, bRecursif, bAvecAffichage)
{
	var oLigne = this.m_tabLignes[nLigne];

	// Force le recalcul des ruptures sur la ligne
	this.__RupturesEntreLignes(this.m_tabLignes[nLigne - 1], oLigne, nLigne - 1, nLigne);

	// Uniquement si on a une rupture sur cette ligne
	if (oLigne.bGetRupture(nRupture, true))
	{
		// Enroule deroule la rupture sur la ligne (si la rupture declenche a la ligne)
		oLigne.EnrouleDeroule(nRupture, bDeroule, bRecursif);

		// Il faut enrouler toutes les lignes de la rupture
		var oLignePrecedente = oLigne;
		var i;
		var nLimiteI = this._nGetNbLignes();
		for (i = nLigne + 1; i < nLimiteI; i++)
		{
			// Force le recalcul des ruptures sur la ligne
			var oLigneSuivante = this.m_tabLignes[i];
			this.__RupturesEntreLignes(oLignePrecedente, oLigneSuivante, i - 1, i);

			// Si il n'y a pas de rupture
			if (!oLigneSuivante.bGetRupture(nRupture, true))
			{
				oLigneSuivante.EnrouleDeroule(nRupture, bDeroule, bRecursif);
				oLignePrecedente = oLigneSuivante;
			}
			else
			{
				break;
			}
		}

		// Reaffiche la table si demande
		if (bAvecAffichage)
		{
			this._TableAfficheLigne(nLigne);
		}
	}
};

// Enroule/deroule une ligne (Inverse si bDeroule n'est pas defini)
// Version qui lance une erreur si la table est vide
WDTableZRNavigateur.prototype._xEnrouleDeroule = function _xEnrouleDeroule(oLigneWL, sAliasRupture, bDeroule)
{
	var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());
	// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne lance une exception
	// Trouve l'indice de la rupture
	var nRupture;
	var bRecursif;
	if (sAliasRupture === undefined)
	{
		// Pour faire comme en code serveur et en WinDev : enroule depuis la rupture externe
		nRupture = (0 < this._nGetNbRuptures()) ? 0 : undefined;
		bRecursif = true;
	}
	else
	{
		nRupture = this._nGetRuptureSelonAlias(sAliasRupture);
		bRecursif = false;
	}
	if ((nRupture !== undefined) && (0 <= nRupture))
	{
		this._EnrouleDerouleI(nLigne, nRupture, bDeroule, bRecursif, true);
	}
};

// Enroule/deroule toutes les lignes
WDTableZRNavigateur.prototype._EnrouleDerouleTout = function _EnrouleDerouleTout(bDeroule)
{
	var i;
	var nLimiteI = this._nGetNbLignes();
	for (i = 0; i < nLimiteI; i++)
	{
		var j;
		var nLimiteJ = this._nGetNbRuptures();
		for (j = 0; j < nLimiteJ; j++)
		{
			// Sans affichage et avec recalcul uniquement pour la premiere rupture
			this._EnrouleDerouleI(i, j, bDeroule, true, false);
		}
	}

	// Reaffiche la table
	this._TableAffiche();
};

// Code commun de SelectPlus et SelectMoins
WDTableZRNavigateur.prototype._xnSelectPlusMoins = function _xnSelectPlusMoins(pfSelectPlusMoins, pfSelectTousAucun, tabLignes)
{
	// Valide chaque param�tre (si on en a) et le passe en indice C
	var nLigne;
	var nLimiteLignes = tabLignes.length;
	for (nLigne = 0; nLigne < nLimiteLignes; nLigne++)
	{
		// GP 04/10/2013 : La doc dit que -1 (= ligne s�lectionn�) est sans effet dans TableSelectMoins
		// => Dans la pratique cela doit fonctionne (au regard du code) en code serveur, donc on fait pareil
		tabLignes[nLigne] = this._xnLigneWLLigne(tabLignes[nLigne], this._nGetSelection());
	}

	// Ajoute/Supprime la s�lection
	// (En interne, nous notifie du changement de la s�lection)
	this.m_oSelection.xSelectPlusMoins(pfSelectPlusMoins, pfSelectTousAucun, tabLignes);

	return tabLignes.length ? tabLignes[0] : this.ms_nLigneInvalide;
};

// Retourne le filtre sur une colonne
WDTableZRNavigateur.prototype.sGetFiltrePourColonne = function sGetFiltrePourColonne(nColonne)
{
	// Recherche la colonne dans le tableau du filtre
	var oFiltre = clWDUtil.oDansTableauFct(this.m_tabFiltre, this.__s_bCompareRTFParColonne, nColonne, undefined);
	return (undefined !== oFiltre) ? oFiltre.m_sValeur : "";
};

// D�sactive le filtre sur une colonne
WDTableZRNavigateur.prototype._bDesactiveFiltreUneColonne = function _bDesactiveFiltreUneColonne(nColonne)
{
	// Recherche la colonne dans le tableau du filtre
	var nFiltre = clWDUtil.nDansTableauFct(this.m_tabFiltre, this.__s_bCompareRTFParColonne, nColonne);
	// Supprime la colonne du filtre si elle existe
	if (clWDUtil.nElementInconnu != nFiltre)
	{
		this.m_tabFiltre.splice(nFiltre, 1);

		// GP 20/11/2013 : QW238715 : D�plac� ici
		// GP 15/11/2013 : QW238715 : Avant OnAnnuleFiltre qui fait un redessin
		// Repasse la colonne en recherche
		var oColonne = this.m_tabColonnes[nColonne];
		oColonne.SetFiltre(oColonne.ms_nFiltreRecherche);

		// La colonne �tait filtr�e
		return true;
	}

	// La colonne n'�tait pas filtr�e
	return false;
};
WDTableZRNavigateur.prototype.__s_bCompareRTFParColonne = function __s_bCompareRTFParColonne(oFiltre, nColonne)
{
	return oFiltre.m_nColonne == nColonne;
};

// Active le filtre sur une colonne
WDTableZRNavigateur.prototype._ActiveFiltre = function _ActiveFiltre(nColonne, nFiltre, sValeur)
{
	// Recupere le filtre sur la colonne
	var fFiltre = WDTableColonne.prototype.s_xfGetFiltre(nFiltre);

	// D�sactive le filtre sur la colonne
	this._bDesactiveFiltreUneColonne(nColonne);

	// GP 15/11/2013 : QW239098 : Place le filtre dans la colonne (enf ait d�j� fait dans le cas de l'utilisation du menu)
	this.m_tabColonnes[nColonne].SetFiltre(nFiltre);

	// Active le filtre sur la colonne
	this.m_tabFiltre.push({ m_nColonne: nColonne, m_fFiltre: fFiltre, m_nFiltre: nFiltre, m_sValeur: sValeur });

	// Refiltre et r�affiche la table
	this._Refiltre(true, true);
};

// Refiltre la table
WDTableZRNavigateur.prototype._Refiltre = function _Refiltre(bFiltreChange, bAvecAffichage)
{
	// Uniquement si le filtre change
	if (bFiltreChange)
	{
		// GP 09/10/2013 : Toujours : si on a supprimer le filtre, il faut r�activer toutes les lignes
		var tabLignes = this.m_tabLignes;
		var nLigne;
		var nLimiteLigne = this._nGetNbLignes();
		for (nLigne = 0; nLigne < nLimiteLigne; nLigne++)
		{
			var oLigne = tabLignes[nLigne];
			oLigne.SetVerifieFiltre(this._bVerifieFiltre(oLigne.tabGetValeurs()));
		}

		// Le nombre de ligne affich� a chang�
		this._OnNbLignesChange();

		if (bAvecAffichage)
		{

			// R�affiche la table et recalcule toutes les ruptures
			this._TableAffiche();
		}

		// R�init la s�lection (comme en code serveur ???)
		this.m_oSelection.ReinitSelection(0);

		// GP 08/11/2013 : QW238715 : R�affiche les images de recherche/filtre : sans aucun parametre : reaffiche completement le filtre
		this._vInvalidePourTRF();
	}
};

// Retourne la ligne affich�e qui peut remplacer une ligne donn�e :
// - Recherche la premi�re ligne affich�e suivante
// - Si elle n'existe pas, recherche la premi�re ligne affich�e pr�c�dente
WDTableZRNavigateur.prototype.nGetLigneAfficheeAutour = function nGetLigneAfficheeAutour(nLigneDebut)
{
	var tabLignes = this.m_tabLignes;
	var nLigne;
	var nLimiteLigne = this._nGetNbLignes();
	for (nLigne = nLigneDebut; nLigne < nLimiteLigne; nLigne++)
	{
		if (tabLignes[nLigne].bGetVerifieFiltre())
		{
			return nLigne;
		}
	}
	// Aucune ligne ne v�rifie le filtre apr�s nLigneDebut : recherche avant
	for (nLigne = nLigneDebut - 1; 0 <= nLigne; nLigne--)
	{
		if (tabLignes[nLigne].bGetVerifieFiltre())
		{
			return nLigne;
		}
	}
	// Aucune ligne ne v�rifie le filtre
	return this.ms_nLigneInvalide;
};

// Conversion d'un numero de ligne WL en numero de ligne interne
WDTableZRNavigateur.prototype._nLigneWLLigne = function _nLigneWLLigne(oLigneWL, nLigneSiUndefined, nLigneSiInvalide, bAccepteLigneSelectionnee, bAccepteLigneVirtuelle, bAccepte0Pour1)
{
	var nLigneC;
	if (oLigneWL === undefined)
	{
		// Si l'indice indefini
		nLigneC = nLigneSiUndefined;
	}
	else
	{
		var nLigneWL = parseInt(oLigneWL, 10);
		if (bAccepteLigneSelectionnee && (nLigneWL === this.ms_nLigneInvalide))
		{
			// Retourne l'indice interne
			nLigneC = this._nGetSelection();
		}
		else if (isNaN(nLigneWL))
		{
			nLigneC = nLigneWL;
		}
		else if (bAccepte0Pour1 && (0 === nLigneWL))
		{
			nLigneC = 1;
		}
		else
		{
			nLigneC = nLigneWL - 1;
		}
	}

	// Si la valeur est definie (ou transformee en definie depuis indefinie)
	if (nLigneC !== undefined)
	{
		// Si la valeur est valide et dans les bornes (du nombre de ligne vu par l'utilisateur
		if (!isNaN(nLigneC) && (0 <= nLigneC) && ((nLigneC < this._nGetNbLignesWL()) || (bAccepteLigneVirtuelle && this.m_bSaisieCascade && (nLigneC == this._nGetNbLignesWL()))))
		{
			// Trouve le num�ro de ligne r�el (tient compte des lignes filtr�es)
			if (this._bAvecFiltre())
			{
				// Avec un filtre : compte les lignes non filtr�es
				var tabLignes = this.m_tabLignes;
				var nLigne;
				var nLimiteLignes = tabLignes.length;
				// Normalement la ligne demand� doit �tre affich�e (sinon elle n'est pas manipulable)
				// Donc un test avec < nLigneC et return oLigneWL + 1 doit suffir.
				// => On ne le fait pas. Comme cela si la ligne demand� n'est pas affich�e on a la ligne pr�c�dente
				for (nLigne = 0; nLigne <= nLimiteLignes; nLigne++)
				{
					if (tabLignes[nLigne].bGetVerifieFiltre() && (0 === nLigneC--))
					{
						return nLigne;
					}
				}
			}
			else
			{
				// Sans filtre : compte toutes les lignes
				return nLigneC;
			}
		}
		return nLigneSiInvalide;
	}
	else
	{
		return nLigneC;
	}
};

// Conversion d'un numero de ligne WL en numero de ligne interne
// Version qui lance une erreur si la table est vide
WDTableZRNavigateur.prototype._xnLigneWLLigne = function _xnLigneWLLigne(oLigneWL, nLigneSiUndefined, nLigneSiInvalide, bAccepteLigneSelectionnee)
{
	// En serveur les erreurs sont plus pr�cises (ERR_LIST_EMPTY/ERR_OUTOFBOUNDCROCHET/ERR_OUTOFBOUND/ERR_INVALIDPARAMINT) avec :
	// - Le nom du champ
	// - Le num�ro du param�tre
	// - Une erreur sur [] ou avec une fonction WL

	// Teste si la table est vide
	var nNbLignes = this._nGetNbLignes();
	if (0 === nNbLignes)
	{
		// Erreur fatale WL :
		// "L'indice sp�cifi� %1 est invalide : le champ est vide."
		throw new WDErreur(300, oLigneWL);
	}

	// @@@ Interdit la ligne virtuelle ???

	// Appel de la classe de base
	var nLigne = this._nLigneWLLigne(oLigneWL, nLigneSiUndefined, nLigneSiInvalide, bAccepteLigneSelectionnee);

	if (nLigne === nLigneSiInvalide)
	{
		// Erreur fatale WL :
		// "L'indice sp�cifi� %1 est invalide : les valeurs valides sont comprises entre %2 et %3."
		throw new WDErreur(301, oLigneWL, 1, nNbLignes);
	}

	return nLigne;
};

// Conversion d'un numero de ligne interne en numero de ligne WL
WDTableZRNavigateur.prototype._nLigneLigneWL = function _nLigneLigneWL(nLigneC)
{
	if (nLigneC != this.ms_nLigneInvalide)
	{
		if (this._bAvecFiltre())
		{
			// Avec un filtre : compte les lignes non filtr�es
			var tabLignes = this.m_tabLignes;
			var nLigne;
			var nLigneWL = 0;
			// Normalement la ligne demand� doit �tre affich�e (sinon elle n'est pas manipulable)
			// Donc un test avec < nLigneC et return nLigneWL + 1 doit suffir.
			// => On ne le fait pas. Comme cela si la ligne demand� n'est pas affich�e on a la ligne pr�c�dente
			for (nLigne = 0; nLigne <= nLigneC; nLigne++)
			{
				if (tabLignes[nLigne].bGetVerifieFiltre())
				{
					nLigneWL++;
				}
			}
			return nLigneWL;
		}
		else
		{
			// Sans filtre : compte toutes les lignes
			return nLigneC + 1;
		}
	}
	else
	{
		return this.ms_nLigneInvalide;
	}
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		Acc�s pour le WL

// Ajoute une ligne avec une chaine de valeurs
WDTableZRNavigateur.prototype.Ajoute = function Ajoute(sValeur)
{
	return this.ms_nLigneInvalide !== this._nLigneInsere(true, ("" + sValeur).split("\t"));
};

// Ajoute une ligne avec une serie de valeurs
WDTableZRNavigateur.prototype.AjouteLigne = function AjouteLigne()
{
	return this._nLigneInsere(true, this.__tabArgumentsVersTableau(arguments, 0));
};

// Modifie une ligne avec une chaine de valeurs
WDTableZRNavigateur.prototype.Modifie = function Modifie(sValeur, oLigneWL)
{
	this._xLigneModifie(("" + sValeur).split("\t"), oLigneWL);
};

// Modifie une ligne avec une serie de valeurs
WDTableZRNavigateur.prototype.ModifieLigne = function ModifieLigne(oLigneWL)
{
	this._xLigneModifie(this.__tabArgumentsVersTableau(arguments, 1), oLigneWL);
};

// Insere une ligne avec une chaine de valeurs
WDTableZRNavigateur.prototype.Insere = function Insere(sValeur, oLigneWL)
{
	// Pas de valeur de retour
	return this.ms_nLigneInvalide !== this._nLigneInsere(false, ("" + sValeur).split("\t"), oLigneWL);
};

// Insere une ligne avec une serie de valeurs
WDTableZRNavigateur.prototype.InsereLigne = function InsereLigne(oLigneWL)
{
	this._nLigneInsere(false, this.__tabArgumentsVersTableau(arguments, 1), oLigneWL);
};

// Deplace une ligne
WDTableZRNavigateur.prototype.DeplaceLigne = function DeplaceLigne(nSourceWL, nDestinationWL, nOperation)
{
	var nLigneSource = this._xnLigneWLLigne(nSourceWL, undefined, undefined, true);
	var nLigneDestination = this._xnLigneWLLigne(nDestinationWL, undefined, undefined, true);
	// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne lance une exception
	if (nLigneSource != nLigneDestination)
	{
		// Param�tres OK
		return this._nLigneDeplace(nLigneSource, nLigneDestination, 0 != (nOperation & this.ms_nTdEchange), 0 != (nOperation & 65536));
	}
	else
	{
		// On ne fait rien mais on retourne quand m�me l'indice (comme dans le code serveur)
		return nSourceWL;
	}
};

// Supprime une ligne
WDTableZRNavigateur.prototype.Supprime = function Supprime(oLigneWL)
{
	var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());
	// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne lance une exception
	this._bLigneSupprime(nLigne);
};

// Supprime toutes les lignes
WDTableZRNavigateur.prototype.SupprimeTout = function SupprimeTout()
{
	this._LigneSupprimeTout();
};

// Nombre d'occurrence de la zone repetee
WDTableZRNavigateur.prototype.Occurrence = function Occurrence(nIndicateur)
{
	// Valeur par defaut = Nb colonnes
	if (nIndicateur === undefined)
	{
		nIndicateur = 1
	}
	switch (nIndicateur)
	{
	case 1:
		// toTotal
		return this._nGetNbLignesWL();
	case 2:
		// toColonne
		return this._nGetNbColonnes();
	default:
		// Pas d'erreur (le code serveur ne fait rien ou lance un warning)
		return this.ms_nLigneInvalide;
	}
};

// Informations sur les ruptures
WDTableZRNavigateur.prototype.IndiceRupture = function IndiceRupture(sAliasRupture, oLigneWL)
{
	var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());
	// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne lance une exception
	return this._nIndiceRupture(sAliasRupture, nLigne);
};

// Tri
WDTableZRNavigateur.prototype.Trie = function Trie(sSensColonnes, bTrie)
{
	if (bTrie)
	{
		this._Tri(sSensColonnes);
	}
	else
	{
		this._TriAnnule();
	}
};

// Recherche
WDTableZRNavigateur.prototype.Cherche = function Cherche(sAliasColonne, sRecherche, nTypeRecherche, nLigneDebutWL)
{
	// GP 22/04/2016 : QW272683 : si nLigneDebutWL est apr�s la fin du fichier il ne faut pas faire une recherche du d�but (= partout) mais pas de recherche
	var nLigneDebut = this._nLigneWLLigne(nLigneDebutWL, 0, this.ms_nLigneInvalide);
	// Conversion des options WL en options internes
	switch (nTypeRecherche)
	{
	default:
		clWDUtil.WDDebug.assert(false, "WDTableZRNavigateur.prototype.Cherche : constante invalide : " + nTypeRecherche);
		// Pas de break;
	case clWDUtil.nRechercheDefaut:
		// rechercheD�faut => rechercheIdentique
		nTypeRecherche = clWDUtil.nRechercheIdentique;
		break;
	case false:
		// rechercheCommencePar : false dans l'ancienne syntaxe
		nTypeRecherche = clWDUtil.nRechercheCommencePar;
		break;
	case true:
		// rechercheIdentique : true dans l'ancienne syntaxe
		nTypeRecherche = clWDUtil.nRechercheIdentique;
		break;
	case clWDUtil.nRechercheCommencePar:
	case clWDUtil.nRechercheIdentique:
	case clWDUtil.nRechercheContient:
		break;
	}
	return this._xnLigneCherche(sAliasColonne, sRecherche, nTypeRecherche, nLigneDebut);
};
WDTableZRNavigateur.prototype.CherchePartout = function CherchePartout(sRecherche, nTypeRecherche, nLigneDebutWL)
{
	// GP 22/04/2016 : QW272683 : si nLigneDebutWL est apr�s la fin du fichier il ne faut pas faire une recherche du d�but (= partout) mais pas de recherche
	var nLigneDebut = this._nLigneWLLigne(nLigneDebutWL, 0, this.ms_nLigneInvalide);
	// Conversion des options WL en options internes
	switch (nTypeRecherche)
	{
	default:
		clWDUtil.WDDebug.assert(false, "WDTableZRNavigateur.prototype.Cherche : constante invalide : " + nTypeRecherche);
		// Pas de break;
	case clWDUtil.nRechercheDefaut:
		// rechercheD�faut => nRechercheContient
		nTypeRecherche = clWDUtil.nRechercheContient;
		break;
	case clWDUtil.nRechercheCommencePar:
		// rechercheCommencePar
	case clWDUtil.nRechercheIdentique:
		// rechercheIdentique
	case clWDUtil.nRechercheContient:
		// nRechercheContient
		break;
	}
	return this._xnLigneCherchePartout(sRecherche, nTypeRecherche, nLigneDebut);
};

// Enroule une rupture
WDTableZRNavigateur.prototype.Enroule = function Enroule(nLigneWL, sAliasRupture)
{
	this._xEnrouleDeroule(nLigneWL, sAliasRupture, false);
};

// Enroule tout
WDTableZRNavigateur.prototype.EnrouleTout = function EnrouleTout()
{
	this._EnrouleDerouleTout(false);
};

// Deroule une rupture
WDTableZRNavigateur.prototype.Deroule = function Deroule(nLigneWL, sAliasRupture)
{
	this._xEnrouleDeroule(nLigneWL, sAliasRupture, true);
};

// Deroule tout
WDTableZRNavigateur.prototype.DerouleTout = function DerouleTout()
{
	this._EnrouleDerouleTout(true);
};

// Inverse l'enroulement
WDTableZRNavigateur.prototype.EnrouleDeroule = function EnrouleDeroule(nLigneWL, sAliasRupture, oEventSiEnrouleDerouleParLeFond)
{
	// GP 17/02/2015 : QW254943 : Si on est en enroul�/d�roul� par le fond, on regarde si on est "dans le fond" = s'il n'y a pas de onclick entre nous et l'objet juste sous le clic
	if (oEventSiEnrouleDerouleParLeFond)
	{
		var oTarget = oEventSiEnrouleDerouleParLeFond.target;
		var oCurrentTarget = oEventSiEnrouleDerouleParLeFond.currentTarget;
		var oBody = document.body;
		while (oTarget && (oTarget != oCurrentTarget) && (oTarget != oBody))
		{
			if ((oTarget.hasAttribute && oTarget.hasAttribute("onclick")) || oTarget.onclick)
			{
				return;
			}
			oTarget = oTarget.parentNode;
		}
	}

	this._xEnrouleDeroule(nLigneWL, sAliasRupture);
};

// Lit le ..Enroule d'une rupture
WDTableZRNavigateur.prototype.bGetEnrouleRupture = function bGetEnrouleRupture(sAliasRupture, oLigneWL)
{
	// Trouve la rupture
	var nRupture = this._nGetRuptureSelonAlias(sAliasRupture);
	clWDUtil.WDDebug.assert(undefined !== nRupture, "Rupture non trouv\xE9e");

	// Trouve la ligne
	var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());

	// Si la ligne est repli�e sur la rupture ou une rupture au dessus.
	var oLigne = this.m_tabLignes[nLigne];
	for (; 0 <= nRupture; nRupture--)
	{
		if (oLigne.bEstEnroule(nRupture))
		{
			return true;
		}
	}
	return false;
};

// Ecrit le ..Enroule d'une rupture
WDTableZRNavigateur.prototype.SetEnrouleRupture = function SetEnrouleRupture(sAliasRupture, nLigneWL, bEnroule)
{
	this._xEnrouleDeroule(nLigneWL, sAliasRupture, !bEnroule);
};

// GP 15/11/2013 : QW239099 : Non disponible finalement (inutile et retourne des ALIAS ce qui n'est pas pratique)
//// Retourne la liste des colonnes filtr�es
//WDTableZRNavigateur.prototype.ColonnesFiltrees = function ColonnesFiltrees()
//{
//	// Construit le tri depuis this.m_tabFiltre
//	var tabColonneFiltree = [];
//	var tabColonnes = this.m_tabColonnes;
//	clWDUtil.bForEach(this.m_tabFiltre, function(oFiltre)
//	{
//		tabColonneFiltree.push(tabColonnes[oFiltre.m_nColonne].m_sAlias + "\t" + oFiltre.m_nFiltre + "\t" + oFiltre.m_sValeur);
//		return true;
//	});
//	return tabColonneFiltree.join("\r\n");
//};

// GP 15/11/2013 : QW239099 : Non disponible finalement (inutile et retourne des ALIAS ce qui n'est pas pratique)
//// Retourne la liste des colonnes tri�es
//WDTableZRNavigateur.prototype.ColonnesTriees = function ColonnesTriees()
//{
//	// Construit le tri depuis this.m_tabTri
//	var tabColonneTriees = [];
//	var tabColonnes = this.m_tabColonnes;
//	clWDUtil.bForEach(this.m_tabTri, function(oTri)
//	{
//		tabColonneTriees.push((oTri.m_bCroissant ? "" : "-") + tabColonnes[oTri.m_nColonne].m_sAlias);
//		return true;
//	});
//	return tabColonneTriees.join("\t");
//};

// D�sactive le filtre (sur la table ou sur une colonne)
WDTableZRNavigateur.prototype.DesactiveFiltre = function DesactiveFiltre(sAliasColonne)
{
	var bFiltreChange;

	// Si on a un nom de colonne
	if (undefined !== sAliasColonne)
	{
		// D�sactive le filtre sur cette colonne
		var nColonne = this._xnGetColonneSelonAlias(sAliasColonne);
		bFiltreChange = this._bDesactiveFiltreUneColonne(nColonne);
	}
	else
	{
		// D�sactive le filtre sur toute la table
		// Le filtre change si la table �tait filtr�e
		bFiltreChange = this._bFiltreAnnule();
	}

	// Refiltre et r�affiche la table
	this._Refiltre(bFiltreChange, true);
};

// GP 08/11/2013 : QW238719 : Non disponible finalement (inutile et retourne des ALIAS ce qui n'est pas pratique)
//// Enum�re les colonnes
//WDTableZRNavigateur.prototype.EnumereColonne = function EnumereColonne(nColonneIndiceWL)
//{
//	// Normalement un table a au moins une colonne : on ne test pas le cas z�ro colonnes.
//	var nNbColonnes = this._nGetNbColonnes();
////	if (0 == nNbLignes)
////	{
////		// Erreur fatale WL :
////		// "L'indice sp�cifi� %1 est invalide : le champ est vide."
////		throw new WDErreur(300, nLigneWL);
////	}
//	if ((1 <= nColonneIndiceWL) && (nColonneIndiceWL <= nNbColonnes))
//	{
//		return this.m_tabColonnes[nColonneIndiceWL - 1].m_sAlias;
//	}
//	else if (nColonneIndiceWL == (nNbColonnes + 1))
//	{
//		return "";
//	}
//	else
//	{
//		// Erreur fatale WL :
//		// "L'indice sp�cifi� %1 est invalide : les valeurs valides sont comprises entre %2 et %3."
//		throw new WDErreur(301, nColonneIndiceWL, 1, nNbColonnes + 1);
//	}
//};

// Retourne la ni�me ligne s�lectionnn�e
WDTableZRNavigateur.prototype.Select = function Select(nRangWL, nModeSelection)
{
	// G�re les param�tres optionnnels WL
	var nRangC = (undefined !== nRangWL) ? nRangWL - 1 : 0;
	if (undefined === nModeSelection)
	{
		nModeSelection = WDSelection.prototype.ms_nTsLigne;
	}

	return this._nLigneLigneWL(this.m_oSelection.xnSelect(nRangC, nModeSelection));
};

// D�selectionne les lignes (fonction en ...)
WDTableZRNavigateur.prototype.SelectMoins = function SelectMoins()
{
	this._xnSelectPlusMoins(this.m_oSelection.bSelectMoins, this.m_oSelection.bSelectAucun, arguments);
};

// Indique la s�lection
WDTableZRNavigateur.prototype.SelectOccurrence = function SelectOccurrence(nModeSelection)
{
	// G�re les param�tres optionnnels WL
	if (undefined === nModeSelection)
	{
		nModeSelection = WDSelection.prototype.ms_nTsLigne;
	}
	return this.m_oSelection.xnSelectOccurrence(nModeSelection);
};

// Selectionne les lignes (fonction en ...)
WDTableZRNavigateur.prototype.SelectPlus = function SelectPlus()
{
	var nLigne = this._xnSelectPlusMoins(this.m_oSelection.bSelectPlus, this.m_oSelection.SelectTous, arguments);

	// GP 06/02/2014 : TB85396 : Si on est en mono s�lection, montre la ligne
	// @@@ Faire un calcul plus pr�cis ? Mettre le code dans la s�lection et avoir un bool�en dans les param�tres ?
	if ((this.ms_nSelectionSimple != this.veGetModeSelection()) && (this.ms_nLigneInvalide != nLigne))
	{
		this._TableAfficheLigne(nLigne, nLigne);
	}
};

// Supprime les lignes s�lectionn�es
WDTableZRNavigateur.prototype.SupprimeSelect = function SupprimeSelect()
{
	// Le second param�tre prendra la valeur par d�faut
	// GP 18/11/2013 : QW239207 : En cas de s�lection simple, il ne faut faire qu'une suppression car on s�lectionne automatiquement la ligne la plus proche
	var nModeSelection = WDSelection.prototype.ms_nTsLigne;
	var tabSelection = [];
	var nSelect;
	var nSelectOccurrence = this.m_oSelection.xnSelectOccurrence(nModeSelection);
	for (nSelect = 0; nSelect < nSelectOccurrence; nSelect++)
	{
		tabSelection.push(this.m_oSelection.xnSelect(nSelect, nModeSelection));
	}

	clWDUtil.bForEachThis(tabSelection, this, this._bLigneSupprime);
};

// Active le filtre sur une colonne
WDTableZRNavigateur.prototype.ActiveFiltre = function ActiveFiltre(sAliasColonne, nFiltre, sValeur)
{
	// Active le filtre sur cette colonne
	this._ActiveFiltre(this._xnGetColonneSelonAlias(sAliasColonne), nFiltre, sValeur)
};

// Echange deux lignes de la table
WDTableZRNavigateur.prototype.EchangeLigne = function EchangeLigne(nSourceWL, nDestinationWL)
{
	// Rebond sur la fonction d�placement avec �change
	this.DeplaceLigne(nSourceWL, nDestinationWL, this.ms_nTdEchange);
};

// Acces WL au valeur des colonnes (lecture)
WDTableZRNavigateur.prototype.oGetValeurColonne = function oGetValeurColonne(sAliasColonne, ePropriete, oLigneWL)
{
	var nColonne = this._xnGetColonneSelonAlias(sAliasColonne);
	// Si on a une propriete qui n'est pas ..Valeur et que l'on n'a pas de num�ro de ligne : lecture de la propri�t� sur la colonne
	if ((ePropriete !== this.XML_CHAMP_PROP_NUM_VALEUR) && (undefined === oLigneWL))
	{
		return this._oGetColonne(nColonne).vsLitPropriete(this, nColonne, undefined, undefined, undefined, ePropriete, false);
	}
	else
	{
		// Lecture de la propri�t� sur la ligne
		var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());
		// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne et lancent _xnGetColonneSelonAlias une exception
		// GP 20/11/2013 : Vu avec QW238660 : Il faut demander la valeur affich�e.
		// Pour avoir les fonctions de conversion, la JS a besoin d'avoir le type de la colonne comme le type r�el (date/heure/etc)
		// Sauf que la JS place alors une fonction de conversion en lecture !!!
		// Donc quand on lit la valeur on fait :
		// Valeur interne (format WL)
		// => Valeur affichage (conversion dans _oGetProprieteColonneAvecIndice)
		// => Valeur WL (conversion par le cast en lecture)
		// Il faudra optimiser un jour.
		return this._voGetProprieteColonneAvecIndicePourWL(nColonne, nLigne, ePropriete);
	}
};
WDTableZRNavigateur.prototype.oGetProprieteCellule = function oGetProprieteCellule(nColonneWL, oLigneWL, ePropriete)
{
	if ((nColonneWL < 0) || (this._nGetNbColonnes() < nColonneWL))
	{
		// Erreur fatale WL :
		// "L'indice sp�cifi� %1 est invalide : les valeurs valides sont comprises entre %2 et %3."
		throw new WDErreur(301, nColonneWL, 1, this._nGetNbColonnes());
	}
	var nColonne = nColonneWL - 1;
	// Lecture de la propri�t� sur la ligne
	var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());
	// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne et lancent _xnGetColonneSelonAlias une exception
	return this._voGetProprieteColonneAvecIndicePourWL(nColonne, nLigne, ePropriete);
};

// Acces WL au valeur des colonnes (lecture)
WDTableZRNavigateur.prototype.oSetProprieteColonne = function oSetProprieteColonne(sAliasColonne)
{
	var nColonne = this._xnGetColonneSelonAlias(sAliasColonne);
	return this._oGetColonne(nColonne);
};

// Acces WL au lignes (lecture)
WDTableZRNavigateur.prototype.oGetLigne = function oGetLigne(oLigneWL)
{
	var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());

	var oStyleLigneSelectionne = this.m_oSelection.bGetLigneEstSelectionnee(nLigne) ? this.m_oStyleLigneSelectionne : undefined;
	var oStyleLignePairImpair = ((nLigne % 2) == 0) ? this.m_oStyleLigneImpair : this.m_oStyleLignePair;
	return this.m_tabLignes[nLigne].oGetPropriete(oStyleLigneSelectionne, oStyleLignePairImpair);
};

// Acces WL au lignes (ecriture)
WDTableZRNavigateur.prototype.oGetLigneSet = function oGetLigneSet(oLigneWL)
{
	var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());
	// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne lance une exception
	// Note la MAJ de la ligne (provoque le reaffichage)
	this.__OnLigneModification(nLigne);

	return this.m_tabLignes[nLigne];
};
WDTableZRNavigateur.prototype.tabGetLigneSet = function tabGetLigneSet(ePropriete, oLigneWL)
{
	// Note la ligne pour le rafraichissement en fin de PCode
	var oLigne = this.oGetLigneSet(oLigneWL);

	switch (ePropriete)
	{
	default:
	case this.XML_CHAMP_PROP_NUM_VALEUR:
		// GP 15/11/2013 : QW238723 : Il manquait un this. ici.
		return oLigne.tabGetValeurs();
	case this.XML_CHAMP_PROP_NUM_COULEUR:
		return oLigne.tabGetCouleur();
	case this.XML_CHAMP_PROP_NUM_COULEURFOND:
		return oLigne.tabGetCouleurFond();
	}
};

// Donne la valeur par d�faut pour un attribut (en attendant d'avoir la valeur par d�faut de chaque champ)
WDTableZRNavigateur.prototype.__oGetValeurDefautAttributAutomatique = function __oGetValeurDefautAttributAutomatique(sAliasChamp, ePropriete)
{
	// Si l'attribut n'existe pas, retourne la valeur par d�faut pour cette propri�t�
	// (= pas de cr�ation de l'attribut)
	switch (ePropriete)
	{
	default:
	case this.XML_CHAMP_PROP_NUM_VALEUR:
		return "";
	case this.XML_CHAMP_PROP_NUM_COULEUR:
		return "#000000";
	case this.XML_CHAMP_PROP_NUM_COULEURFOND:
		return "transparent";
	case this.XML_CHAMP_PROP_NUM_ETAT:
		return 0;
	case this.XML_CHAMP_PROP_NUM_VISIBLE:
		return true;
	case this.XML_CHAMP_PROP_NUM_IMAGE:
		return "";
	case this.XML_CHAMP_PROP_NUM_POLICEGRAS:
		return false;
	case this.XML_CHAMP_PROP_NUM_POLICEITALIQUE:
		return false;
	case this.XML_CHAMP_PROP_NUM_POLICESOULIGNE:
		return false;
	case this.XML_CHAMP_PROP_NUM_POLICETAILLE:
		// GP 20/03/2015 : TB86682 : Taille par d�faut en chaine
		return 12;
	case this.XML_CHAMP_PROP_NUM_VIGNETTE:
		return "";
	}
};

// Donne la valeur d'un attribut automatique
// ePropriete : propri�t� serveur !!!
WDTableZRNavigateur.prototype.SetAttributAutomatique = function SetAttributAutomatique(sAliasChamp, ePropriete, oLigneWL, eTypeChamp, eTypeWL, oValeur)
{
	// Trouve l'attribut automatique (en fait on trouve aussi les attribut normaux si le champ est manipul� comme s'il a un attribut automatique)
	var nIndiceAttribut = this.__nGetAttributSelonChampEtPropriete(sAliasChamp, ePropriete);

	// Si on ne trouve pas : cr�ation de l'attribut automatique
	if (clWDUtil.nElementInconnu == nIndiceAttribut)
	{
		// Cr�ation : l'indice du futur attribut est la taille actuelle du tableau des colonnes (qui est le tableau des attributs)
		nIndiceAttribut = this._nGetNbColonnes();
		var oAttribut = new (this._vNewAttributAutomatique)("ATT_" + sAliasChamp + "_" + ePropriete, eTypeWL, [ePropriete, sAliasChamp, eTypeChamp]);
		this.m_tabColonnes.push(oAttribut);
		// Redimensionnement des lignes et affectation de la valeur par d�faut dans les cellules
		var oValeurDefaut = this.__oGetValeurDefautAttributAutomatique(sAliasChamp, ePropriete);
		clWDUtil.bForEach(this.m_tabLignes, function (oLigne)
		{
			oLigne.m_tabValeurs.push(oValeurDefaut);
			return true;
		});
	}

	// Affectation de la valeur dans la ligne (ce que l'on affecte est la valeur de l'attribut)
	this.tabGetLigneSet(this.XML_CHAMP_PROP_NUM_VALEUR, oLigneWL)[nIndiceAttribut] = oValeur;
};
// Trouve la valeur d'un attribut automatique
// ePropriete : propri�t� serveur !!!
WDTableZRNavigateur.prototype.oGetAttributAutomatique = function oGetAttributAutomatique(sAliasChamp, ePropriete, oLigneWL)
{
	// Trouve l'attribut automatique (en fait on trouve aussi les attribut normaux si le champ est manipul� comme s'il a un attribut automatique)
	var nIndiceAttribut = this.__nGetAttributSelonChampEtPropriete(sAliasChamp, ePropriete);

	if (clWDUtil.nElementInconnu != nIndiceAttribut)
	{
		// Lecture de la propri�t� sur la ligne (ce que l'on affecte est la valeur de l'attribut)
		var nLigne = this._xnLigneWLLigne(oLigneWL, this._nGetSelection());
		return this._oGetProprieteColonneAvecIndice(nIndiceAttribut, nLigne, nLigne, this.XML_CHAMP_PROP_NUM_VALEUR, false);
	}
	else
	{
		// Si l'attribut n'existe pas, retourne la valeur par d�faut pour cette propri�t�
		// (= pas de cr�ation de l'attribut)
		return this.__oGetValeurDefautAttributAutomatique(sAliasChamp, ePropriete);
	}
};

// Demande l'affichage immediat de la table
WDTableZRNavigateur.prototype.OnChange = function OnChange()
{
	// GP 19/02/2014 : Fait un _TableAffiche pour ne pas refaire le dessin imm�diatement (sinon si on fai l'ajout dans une foncion appel�e par ligne,
	// alors on fait le redessin pour chaque ligne (= on dessine n*n/2 lignes).
	// _TableAffiche fait le filtre de this.m_bEnPCodeAffichageLigne
	this._TableAffiche();
//	// Si on n'est pas deja en PCode d'affichage (donc en redessin)
//	if (this.m_bEnPCodeAffichageLigne === undefined)
//	{
//		this._Affiche();
//	}
};

// Si un dessin est en attente, l'effectue imm�diatement (appel depuis le framework V2).
WDTableZRNavigateur.prototype.AfficheImmediat = function AfficheImmediat()
{
	if (this.bGetTimeXXXExiste("_Affiche"))
	{
		// L'appel de _Affiche d�clenche l'annulation du timer.
		this._Affiche();
	}
};

//////////////////////////////////////////////////////////////////////////
// Generateur HTML

// Parse le HTML
WDTableZRNavigateur.prototype.__HTMLParse = function __HTMLParse()
{
	// Trouve le source du HTML
	// - Table : objet JSON pour d�crire les titres et les colonnes
	// - ZR : HTML direct de chaque ligne
	var sSourceHTML = clWDUtil.sGetHTMLDansCommentaire(this.m_oHote);

	// M�thode de parsing interne
	this.m_oElementsHTML = this._voHTMLParse(sSourceHTML);
};

// Parse un morceau complet de HTML
WDTableZRNavigateur.prototype.__tabHTMLParse = function __tabHTMLParse(sSourceHTML)
{
	var tabElementsHTML = [];
	this.__nHTMLParseInterne(sSourceHTML, 0, tabElementsHTML);
	return tabElementsHTML;
};

// Parse le HTML (version interne :factorisation avec le code des [%SI%])
// Dans le cas des SI : tabElementsHTML est le tabeau de la partie [%ALORS%] et on re�oit en plus le tabElementsHTMLSinon qui est le tableau de la partie [%SINON%]
WDTableZRNavigateur.prototype.__nHTMLParseInterne = function __nHTMLParseInterne(sHTML, nDebut, tabElementsHTML, tabElementsHTMLSinon)
{
	while (1)
	{
		// Trouve le prochain [%
		var nPosition = sHTML.indexOf(this.ms_sDynO, nDebut);
		// Ajoute un bloc fixe si besoin
		nDebut = this.__nHTMLParseFixe(sHTML, nDebut, nPosition, tabElementsHTML);
		// Si on n'a plus de bloc : fini
		if (-1 == nPosition)
		{
			// Ici normalement nDebut == sHTML.length
			return nDebut;
		}
		// Ici normalement nDebut == nPosition
		// Si on a un [%FIN%] => fin du parsing de la condition
		if (sHTML.substr(nPosition, this.ms_sDynFin.length) == this.ms_sDynFin)
		{
			return nPosition + this.ms_sDynFin.length;
		}
		// Si on est sur un [%SI%]
		else if (sHTML.substr(nPosition, this.ms_sDynSi.length) == this.ms_sDynSi)
		{
			// Et parse la condition
			nDebut = this.__nHTMLParseSi(sHTML, nPosition, tabElementsHTML)
		}
		// Si on est sur un [%SINON%]
		else if (sHTML.substr(nPosition, this.ms_sDynSinon.length) == this.ms_sDynSinon)
		{
			// Ignore le [%SINON%] et change le tableau analys�
			nDebut += nPosition + this.ms_sDynSinon.length;
			tabElementsHTML = tabElementsHTMLSinon;
		}
		// Parse la valeur
		else
		{
			nDebut = this.__nHTMLParsePropriete(sHTML, nPosition, tabElementsHTML)
		}
	}
};

// - Balise fixe :			{ vVersHTML : this.VersHTML_Fixe, m_sValeur : (Valeur chaine) }
WDTableZRNavigateur.prototype.__nHTMLParseFixe = function __nHTMLParseFixe(sHTML, nDebut, nPosition, tabElementsHTML)
{
	var sValeur;
	if (-1 != nPosition)
	{
		sValeur = sHTML.substring(nDebut, nPosition);
	}
	else
	{
		sValeur = sHTML.substring(nDebut);
	}
	// Uniquement si on a une valeur
	if (sValeur.length > 0)
	{
		tabElementsHTML.push({ vVersHTML: this.VersHTML_Fixe, m_sValeur: sValeur });
	}
	return nDebut + sValeur.length;
};

// - Balise condition		{ vVersHTML : this.VersHTML_Condition, m_sValeur : (Valeur chaine a tester), m_bDifferent : <!= au lieu de ==>, m_tabElementsHTMLSi: <Tableau interne>, m_tabElementsHTMLSinon: <Tableau interne>, m_oPropriete : <Idem balise dynamique> }
WDTableZRNavigateur.prototype.__nHTMLParseSi = function __nHTMLParseSi(sHTML, nDebut, tabElementsHTML)
{
	var oElement = { vVersHTML: this.VersHTML_Condition, m_sValeur: "", m_bDifferent: false, m_tabElementsHTMLSi: [], m_tabElementsHTMLSinon: [], m_oPropriete: null };

	// Ignore le [%SI%]
	nDebut += this.ms_sDynSi.length;
	// Trouve le [%ALORS%]
	var nPositionAlors = sHTML.indexOf(this.ms_sDynAlors, nDebut);
	// Parse la condition
	var sCondition = sHTML.substring(nDebut, nPositionAlors);
	var nPositionCondition = sCondition.indexOf(this.ms_sConditionDifferent);
	var nPositionConditionFin;
	if (-1 == nPositionCondition)
	{
		nPositionCondition = sCondition.indexOf(this.ms_sConditionEgal);
		// Ne sera pas utilise si nPosition est invalide
		nPositionConditionFin = nPositionCondition + this.ms_sConditionEgal.length;
		oElement.m_bDifferent = false;
	}
	else
	{
		nPositionConditionFin = nPositionCondition + this.ms_sConditionDifferent.length;
		oElement.m_bDifferent = true;
	}
	if (-1 != nPositionConditionFin)
	{
		oElement.m_oPropriete = this.__oParsePropriete(sCondition.substring(0, nPositionCondition));
		oElement.m_sValeur = sCondition.substring(nPositionConditionFin, nPositionAlors);

		tabElementsHTML.push(oElement);
	}
	// Et analyse le contenu
	return this.__nHTMLParseInterne(sHTML, nPositionAlors + this.ms_sDynAlors.length, oElement.m_tabElementsHTMLSi, oElement.m_tabElementsHTMLSinon);
};

// Parse une propriete [%ALIAS_ZR<;format>%], [%ALIAS_ZR..PROP<;format>%], [%ALIAS_ATTRIBUT<;format>%]
// - Balise dynamique		{ vVersHTML : this.VersHTML_Propriete, m_oPropriete : { <m_nColonne> <, m_ePropriete> <, m_eConversion> }
//																					^				^				^
//																			Si sur attribut			^			Si conversion
//																					Si propriete (sur ZR)
WDTableZRNavigateur.prototype.__nHTMLParsePropriete = function __nHTMLParsePropriete(sHTML, nDebut, tabElementsHTML)
{
	// Ignore le [%
	nDebut += this.ms_sDynO.length;
	// Trouve le %]
	var nPosition = sHTML.indexOf(this.ms_sDynF, nDebut);
	// Parse la propriete
	tabElementsHTML.push({ vVersHTML: this.VersHTML_Propriete, m_oPropriete: this.__oParsePropriete(sHTML.substring(nDebut, nPosition)) });
	return nPosition + this.ms_sDynF.length;
};

// { <m_nColonne>/<m_oAttributAutomatique>, <m_ePropriete>, <m_eConversion> }
WDTableZRNavigateur.prototype.ms_oMatchAttAuto = /^ATT_(\w+)_(\d+)$/;
WDTableZRNavigateur.prototype.__oParsePropriete = function __oParsePropriete(sPropriete)
{
	var oPropriete = { m_nColonne: undefined, m_oAttributAutomatique: undefined, m_ePropriete: this.XML_CHAMP_PROP_NUM_VALEUR, m_eConversion: undefined };
	// Extrait la conversion
	// sPropriete est de la forme : ALIAS, ALIAS..PROP, ALIAS..PROP;CONV
	var nPositionConversion = sPropriete.indexOf(this.ms_sConversion);
	if (-1 != nPositionConversion)
	{
		oPropriete.m_eConversion = parseInt(sPropriete.substring(nPositionConversion + this.ms_sConversion.length), 10);
		// Extrait la conversion : pour n'avoir que deux formes : ALIAS, ALIAS..PROP
		sPropriete = sPropriete.substring(0, nPositionConversion);
	}
	// Extrait la propriete
	// sPropriete est de la forme : ALIAS, ALIAS..PROP
	var nPositionPropriete = sPropriete.indexOf(this.ms_sPropriete);
	if (-1 != nPositionPropriete)
	{
		var tabPourParametresOut = [];
		oPropriete.m_ePropriete = this.__eParsePPPropriete(sPropriete.substring(nPositionPropriete + this.ms_sPropriete.length), tabPourParametresOut);
		if (tabPourParametresOut[0] !== undefined)
		{
			oPropriete.m_oParametre = tabPourParametresOut[0];
		}
		// Extrait la propriete : pour n'avoir que une formes : ALIAS
		sPropriete = sPropriete.substring(0, nPositionPropriete);
	}
	// Alias
	// sPropriete est de la forme : ALIAS
	// G�re le cas des attribut automatiques
	// => Si la chaine est de la forme ATT_ALIAS_X alors on dit que c'est un attribut automatique et il faudra le r�soudre plus tard.
	// (on ne peut pas le cr�er ici car on n'a pas les informations sur le champ et sur la valeur par d�faut a utiliser)
	var oMatch = sPropriete.match(this.ms_oMatchAttAuto);
	if (null != oMatch)
	{
		oPropriete.m_oAttributAutomatique = { m_sAliasChamp: oMatch[1], m_ePropriete: parseInt(oMatch[2], 10) };
	}
	else
	{
		oPropriete.m_nColonne = this._nGetColonneSelonAlias(sPropriete);
	}
	return oPropriete;
};
WDTableZRNavigateur.prototype.__eParsePPPropriete = function __eParsePPPropriete(sPropriete, tabPourParametresOut)
{
	switch (sPropriete)
	{
	case "COULEUR":
		return this.XML_CHAMP_PROP_NUM_COULEUR;
	case "COULEURFOND":
		return this.XML_CHAMP_PROP_NUM_COULEURFOND;
	case "RUPTURELIGNE_DEBUT":
		return this.ms_nAttributRuptureLigneDebut;
	case "RUPTURELIGNE_FIN":
		return this.ms_nAttributRuptureLigneFin;
	case "LIGNEREPLIEE":
		return this.ms_nAttributLigneRepliee;
	case "LIGNEPAIRE":
		return this.ms_nAttributLignePaire;
	case "TRIABLE":
		return this.ms_nAttributTriable;
	case "RECHERCHABLE":
		return this.ms_nAttributRecherchable;
	case "SELECTED":
		return this.ms_nAttributSelected;
	case "DERNIEREVISIBLE":
		return this.ms_nAttributDerniereVisible;
	case this.ms_sCodeHTML32:
		return this.ms_nAttributCodeHTML32;
	default:
		if (this.__bParsePPProprieteDouble(sPropriete, tabPourParametresOut, this.ms_sInclureHautRupture, true))
		{
			return this.ms_nAttributIncludeHautRupture;
		}
		else if (this.__bParsePPProprieteDouble(sPropriete, tabPourParametresOut, this.ms_sInclureBasRupture, true))
		{
			return this.ms_nAttributIncludeBasRupture;
		}
		else if (this.__bParsePPProprieteDouble(sPropriete, tabPourParametresOut, this.ms_sCodeHTML30, true))
		{
			return this.ms_nAttributCodeHTML30;
		}
		else if (this.__bParsePPProprieteDouble(sPropriete, tabPourParametresOut, this.ms_sCodeHTML31, true))
		{
			return this.ms_nAttributCodeHTML31;
		}
		else if (this.__bParsePPProprieteDouble(sPropriete, tabPourParametresOut, "EXISTE_", false))
		{
			return this.ms_nAttributExiste;
		}

		// @@@
//		alert(sPropriete);
		return this.XML_CHAMP_PROP_NUM_VALEUR;
	}
};
WDTableZRNavigateur.prototype.__bParsePPProprieteDouble = function __bParsePPProprieteDouble(sPropriete, tabPourParametresOut, sNomPropriete, bProprieteEntiere)
{
	if (sPropriete.substr(0, sNomPropriete.length) == sNomPropriete)
	{
		var oParametre = sPropriete.substr(sNomPropriete.length);
		tabPourParametresOut[0] = bProprieteEntiere ? parseInt(oParametre, 10) : oParametre;
		return true;
	}
	return false;
};

// Genere le HTML
WDTableZRNavigateur.prototype.__HTMLGenere = function __HTMLGenere(nLigne, nLigneAffiche, oLigne, tabElementsHTML, tabHTML)
{
	var nElementHTML;
	var nLimiteI = tabElementsHTML.length;
	for (nElementHTML = 0; nElementHTML < nLimiteI; nElementHTML++)
	{
		tabElementsHTML[nElementHTML].vVersHTML.apply(this, [nLigne, nLigneAffiche, oLigne, tabElementsHTML[nElementHTML], tabHTML]);
	}
};

// Fonctions specialises pour les sous objets
WDTableZRNavigateur.prototype.VersHTML_Fixe = function VersHTML_Fixe(nLigne, nLigneAffiche, oLigne, oElement, tabHTML)
{
	tabHTML.push(oElement.m_sValeur);
};
WDTableZRNavigateur.prototype.VersHTML_Propriete = function VersHTML_Propriete(nLigne, nLigneAffiche, oLigne, oElement, tabHTML)
{
	// Trouve la valeur pour la ligne courante
	tabHTML.push(this.__sGetPropriete(nLigne, nLigneAffiche, oLigne, oElement.m_oPropriete, false));
};
WDTableZRNavigateur.prototype.VersHTML_Condition = function VersHTML_Condition(nLigne, nLigneAffiche, oLigne, oElement, tabHTML)
{
	var bRes = (oElement.m_sValeur == this.__sGetPropriete(nLigne, nLigneAffiche, oLigne, oElement.m_oPropriete, true));
	if (oElement.m_bDifferent ? !bRes : bRes)
	{
		this.__HTMLGenere(nLigne, nLigneAffiche, oLigne, oElement.m_tabElementsHTMLSi, tabHTML);
	}
	else if (oElement.m_tabElementsHTMLSinon)
	{
		this.__HTMLGenere(nLigne, nLigneAffiche, oLigne, oElement.m_tabElementsHTMLSinon, tabHTML);
	}
};

// Trouve la valeur d'une propriete (factorisation entre VersHTML_Propriete et VersHTML_Condition)
WDTableZRNavigateur.prototype.__sGetPropriete = function __sGetPropriete(nLigne, nLigneAffiche, oLigne, oPropriete, bPourCondition)
{
	var oValeur;

	// Lecture de m_oAttributAutomatique
	var oAttributAutomatique = oPropriete.m_oAttributAutomatique;
	if (oAttributAutomatique)
	{
		// Trouve l'attribut automatique (en fait on trouve aussi les attribut normaux si le champ est manipul� comme s'il a un attribut automatique)
		var nIndiceAttribut = this.__nGetAttributSelonChampEtPropriete(oAttributAutomatique.m_sAliasChamp, oAttributAutomatique.m_ePropriete);

		if (clWDUtil.nElementInconnu != nIndiceAttribut)
		{
			// Remplace m_oAttributAutomatique par la colonne
			oPropriete.m_oAttributAutomatique = undefined;
			oPropriete.m_nColonne = nIndiceAttribut;
		}
		else
		{
			// Si l'attribut n'existe pas, retourne la valeur par d�faut pour cette propri�t� (= pas de cr�ation de l'attribut)
			oValeur = this.__oGetValeurDefautAttributAutomatique(oAttributAutomatique.m_sAliasChamp, oAttributAutomatique.m_ePropriete);
		}
	}

	// { <m_nColonne>/<m_oAttributAutomatique>, <m_ePropriete>, <m_eConversion> }
	if (oPropriete.m_nColonne !== undefined)
	{
		// Lit la propri�t� sur la colonne
		oValeur = this.m_tabColonnes[oPropriete.m_nColonne].vsLitPropriete(this, oPropriete.m_nColonne, nLigne, nLigneAffiche, oLigne, oPropriete.m_ePropriete, true);
	}
	// Si on n'a pas d�j� une valeur par l'attribut automatique
	else if (undefined === oValeur)
	{
		oValeur = this._vsLitPropriete(nLigne, nLigneAffiche, oLigne, oPropriete.m_ePropriete, oPropriete.m_oParametre, bPourCondition);
	}

	return this.__sConversion(oValeur, oPropriete.m_eConversion);
};

// Conversion en ecriture
WDTableZRNavigateur.prototype.__sConversion = function __sConversion(oValeur, eConversion)
{
	if (eConversion !== undefined)
	{
		var oValeurEntier;
		switch (eConversion)
		{
		case this.ms_nConversionPoliceGras:
			// Conversion sp�ciale pour ..PoliceGras (Bool vers une valeur CSS ou en int)
			if (typeof oValeur == "boolean")
			{
				return oValeur ? "bold" : "normal";
			}
			// Autres cas : entier et chaine : sera cast� en chaine au final
			break;
		case this.ms_nConversionPoliceItalique:
			// Conversion sp�ciale pour ..PoliceItalique (Bool vers une valeur CSS)
			if (typeof oValeur == "boolean")
			{
				return oValeur ? "italic" : "normal";
			}
			// Autres cas (anormal) : entier et chaine : sera cast� en chaine au final
			break;
		case this.ms_nConversionPoliceSouligne:
			// Conversion sp�ciale pour ..PoliceSoulignee (Bool vers une valeur CSS)
			if (typeof oValeur == "boolean")
			{
				return oValeur ? "underline" : "none";
			}
			// Autres cas (anormal) : entier et chaine : sera cast� en chaine au final
			break;
		case this.ms_nConversionPoliceTaille:
			// Conversion sp�ciale pour ..PoliceTaille :
			// - Conversion des chaines qui sont des nombres
			if (typeof oValeur == "string")
			{
				oValeurEntier = parseInt(oValeur, 10);
				if (oValeurEntier == oValeur)
				{
					oValeur = oValeurEntier;
				}
			}
			// - Conversion des nombres qui ne sont pas z�ro
			if ((typeof oValeur == "number") || (0 != oValeur))
			{
				return oValeur + "pt";
			}
			break;
		case this.ms_nConversionBackgroundImage:
			// GP 22/11/2016 : QW280494 : Ajout de la conversion pour les images de fond.
			return clWDUtil.sGetCheminImage(oValeur, "none", true);
		default:
			// @@@
			break;
		}
	}
	return oValeur;
};

//////////////////////////////////////////////////////////////////////////
// Classes utilitaires (tri, menu, recherche etc)
//	WDPopupSaisieTRF
//		Gestion des images et du champ de saisie pour le tri, la recherche et le filtrage dans les colonnes.
//		TRF = TriRechercheFiltre
// oChampTable : champ qui impl�mente l'interface des tables :
//	- OnRecherche
//	- OnFiltre
//	- OnAnnuleFiltre
//	- oGetIDElement (Par l'interface des champs)
//	- _oGetColonne
var WDPopupSaisieTRF = (function ()
{
	"use strict";

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	WDMenuContextuelTRF
	//		Affichage du menu contextuel de recherche/filtre des tables et zone r�p�t�es
	var WDMenuContextuelTRF = (function ()
	{
		function __WDMenuContextuelTRF(oEvent, oGestionnaire, pfAction, nColonne, bTexte, bNumDateHeure, bAvecOptionSuppressionFiltre, pfCallbackSurFermeture)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// GP 28/10/2013 : QW237973 : Adapte les filtres propos�s
				var tabOptions = [];
				// WX27 : l'option de suppression du filtre n'est pr�sent� que si on a un filtre. Et si elle est pr�sent� c'est en premier.
				if (bAvecOptionSuppressionFiltre)
				{
					tabOptions.push(ms_oSupprimerFiltre);
				}
				// L'option de recherche est toujours en premier.
				tabOptions.push(ms_oRecherche);
				// Si on est en mode texte, on � l'option de filtre 'contient'.
				if (bTexte)
				{
					tabOptions.push(ms_oFiltreContient);
				}
				// Dans tous les cas, on place un s�parateur sur la derni�re option.
				tabOptions[tabOptions.length - 1].m_bSeparateur = true;
				// Ajoute ensuite le titre des filtres 'autres'".
				tabOptions.push(ms_oFiltreAutres);
				// Et les filtres autres
				clWDUtil.bForEach(ms_tabOptions, function (oOption)
				{
					// On ne filtre que les options qui changent le filtre
					if ((bTexte && oOption.m_bTexte) || (bNumDateHeure & oOption.m_bNumDateHeure))
					{
						tabOptions.push(oOption);
					}

					return true;
				});

				// M�morise les param�tres sp�cifiques
				this.m_oGestionnaire = oGestionnaire;
				this.m_pfAction = pfAction;
				this.m_nColonne = nColonne;

				// Appel le constructeur de la classe de base
				// Vu avec QW308055 : Il faut demander l'ouverture dans le sens automatique. Si on est compl�tement � droite (derni�re colonne), cela � du sens d'ouvrir vers la gauche.
//				WDMenuContextuel.prototype.constructor.apply(this, [oEvent, tabOptions, this.ms_eOuvreBasDroite, TABLE_FILTRE]);
				WDMenuContextuel.prototype.constructor.apply(this, [oEvent, tabOptions, this.ms_eOuvreSensAutomatique, TABLE_FILTRE, pfCallbackSurFermeture]);
			}
		}

		// Declare l'heritage
		__WDMenuContextuelTRF.prototype = new WDMenuContextuel();
		// Surcharge le constructeur qui a ete efface
		__WDMenuContextuelTRF.prototype.constructor = __WDMenuContextuelTRF;

		// Constantes
		// GP 24/09/2013 : Les valeurs des filtres sont les m�me que dans WDTableColonne, sauf que l'on est d�clar� avant donc on ne peut pas les utiliser
		var ms_oSupprimerFiltre = {
			m_nFiltre: -1,
			m_oLibelle: { m_sTraduction: "FILTRE_SUPPRIME", sLibelle: "Supprimer le filtre" },
			m_sImage: "TableFiltre.gif",
			// Avec un s�parateur.
			m_bSeparateur: true
		};
		var ms_oRecherche = {
			m_nFiltre: 0,
			m_oLibelle: { m_sTraduction: "RECHERCHE", sLibelle: "Rechercher" },
			m_sImage: "TableCherche.gif"
		};
		var ms_oFiltreContient = {
			m_nFiltre: WDTableColonne.prototype.ms_nFiltreContient,
			m_oLibelle: { m_sTraduction: "FILTRE_CONTIENT", sLibelle: "Contient" }
		};
		var ms_oFiltreAutres = {
			m_oLibelle: { m_sTraduction: "FILTRE", sLibelle: "Filtres :" },
			m_sImage: "TableFiltre.gif",
			m_bInactif: true
		};
		var ms_tabOptions =
			[
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreEgal,
					m_bTexte: true,
					m_bNumDateHeure: true,
					m_oLibelle: { m_sTraduction: "FILTRE_EGAL", sLibelle: "Est \xE9gal \xE0" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreCommencePar,
					m_bTexte: true,
					m_oLibelle: { m_sTraduction: "FILTRE_COMMENCE", sLibelle: "Commence par" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreTerminePar,
					m_bTexte: true,
					m_oLibelle: { m_sTraduction: "FILTRE_TERMINE", sLibelle: "Se termine par" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreDifferent,
					m_bTexte: true,
					m_bNumDateHeure: true,
					m_oLibelle: { m_sTraduction: "FILTRE_DIFFERENT", sLibelle: "Est diff\xE9rent de" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreNeCommencePasPar,
					m_bTexte: true,
					m_oLibelle: { m_sTraduction: "FILTRE_COMMENCE_PAS", sLibelle: "Ne commence pas par" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreNeContientPas,
					m_bTexte: true,
					m_oLibelle: { m_sTraduction: "FILTRE_CONTIENT_PAS", sLibelle: "Ne contient pas" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreNeTerminePasPar,
					m_bTexte: true,
					m_oLibelle: { m_sTraduction: "FILTRE_TERMINE_PAS", sLibelle: "Ne se termine pas par" },
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreSuperieur,
					m_bNumDateHeure: true,
					m_oLibelle: { m_sTraduction: "FILTRE_SUPERIEUR", sLibelle: "Sup\xE9rieur \xE0" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreSuperieurOuEgal,
					m_bNumDateHeure: true,
					m_oLibelle: { m_sTraduction: "FILTRE_SUPERIEUR_EGAL", sLibelle: "Sup\xE9rieur ou \xE9gal \xE0" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreInferieur,
					m_bNumDateHeure: true,
					m_oLibelle: { m_sTraduction: "FILTRE_INFERIEUR", sLibelle: "Inf\xE9rieur \xE0" }
				},
				{
					m_nFiltre: WDTableColonne.prototype.ms_nFiltreInferieurOuEgal,
					m_bNumDateHeure: true,
					m_oLibelle: { m_sTraduction: "FILTRE_INFERIEUR_EGAL", sLibelle: "Inf\xE9rieur ou \xE9gal \xE0" },
				}
			];
//			{
//				m_nFiltre: 32048,
//				m_oLibelle: { m_sTraduction: "FILTRE_VIDE", sLibelle: "Est vide" }
//			}

		// M�thodes virtuelles

		// Effectue l'action
		__WDMenuContextuelTRF.prototype._vAction = function _vAction(oEvent, oOptionSelection)
		{
			this.m_pfAction.apply(this.m_oGestionnaire, [oEvent, this.m_nColonne, oOptionSelection.m_nFiltre, ""]);
		};

		// M�thodes sp�cifiques

		// Recherche le libell� d'un mode de recherche/filtrag
		__WDMenuContextuelTRF.s_sGetLibelleFiltre = function s_sGetLibelleFiltre (nFiltre)
		{
			function __oGetLibelleFiltre ()
			{
				function __oGetLibelleSiFiltre (oFiltre)
				{
					return (oFiltre.m_nFiltre === nFiltre) ? oFiltre.m_oLibelle : undefined;
				}
				function __oGetLibelleSiFiltreTab (tabFiltres)
				{
					var oResultat /*= undefined*/;
					clWDUtil.bForEach(tabFiltres, function(oFiltre)
					{
						oResultat = __oGetLibelleSiFiltre(oFiltre);
						// Arret de l'it�ration d�s que l'on a trouv�.
						return undefined === oResultat;
					});
					return oResultat;
				}
				return /*__oGetLibelleSiFiltre(ms_oSupprimerFiltre)||*/ __oGetLibelleSiFiltre(ms_oRecherche) || __oGetLibelleSiFiltre(ms_oFiltreContient) /*|| __oGetLibelleSiFiltre(ms_oFiltreAutres)*/ || __oGetLibelleSiFiltreTab(ms_tabOptions);
			}

			var oFiltre = __oGetLibelleFiltre();
			if (oFiltre && TABLE_FILTRE)
			{
				var oTraduction = TABLE_FILTRE[oFiltre.m_sTraduction];
				if (oTraduction)
				{
					return oTraduction.sLibelle;
				}
			}
			return undefined;
		};

		return __WDMenuContextuelTRF;
	})();

	function __WDPopupSaisieTRF(oChampTable, tabImages)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDPopupSaisie.prototype.constructor.apply(this, [oChampTable, false]);

			// tabImages est un tableau de tableau : [ [ Tri neutre, tri croissant, tri d�croissant ], [ Recherche neutre, recherche survol, recherche saisie ], [ Filtre neutre, filtre survol, filtre saisie ] ]
			this.m_tabImages = tabImages;
			// Pr�chargement : clWDUtil.PrechargeImage g�re le cas du tableau et du tableau dans un tableau
			clWDUtil.PrechargeImage(tabImages);
		}
	}

	// Declare l'heritage
	__WDPopupSaisieTRF.prototype = new WDPopupSaisie();
	// Surcharge le constructeur qui a ete efface
	__WDPopupSaisieTRF.prototype.constructor = __WDPopupSaisieTRF;

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires (tri, menu, recherche etc)
	//	WDPopupSaisieTRF
	//		M�thodes internes

	// R�cup�re les images pour la recherche ou le filtre
	__WDPopupSaisieTRF.prototype.__tabGetImagesRechercheFiltre = function __tabGetImagesRechercheFiltre(oColonne)
	{
		switch (oColonne.m_nRecherche)
		{
		default:
//		case 0:
//			// Sans recherche ni filtre
		case 1:
		// Recherche seule
		case 2: // Recherche (filtre possible)
		case 3: // Filtre (recherche possible implicite)
			if (oColonne.ms_nFiltreRecherche == oColonne.nGetFiltre())
			{
				// Recherche
				return this.m_tabImages[1];
			}
			else
			{
				// Filtre
				return this.m_tabImages[2];
			}
		}
	};

	// Calcule l'image a afficher et la place dans le champ
	__WDPopupSaisieTRF.prototype.__AfficheImage = function __AfficheImage(oImage, nColonne, oColonne, nImage)
	{
		// On n'est normalement pas appel� si la colonne n'est pas recherchable/filtrable
		var tabImages = this.__tabGetImagesRechercheFiltre(oColonne);

		// Si on est sur la colonne en saisie, on prend l'image en saisie
		if ((undefined !== nColonne) && (nColonne === this.m_nColonneRecherche))
		{
			nImage = 2;
		}

		oImage.src = tabImages[nImage];
	};

	// Place les divers onXxx sur les images
	// (Pour avoir la closure correcte sur l'indice de la colonne)
	__WDPopupSaisieTRF.prototype.__AjouteOnXxxSurImages = function __AjouteOnXxxSurImages(nColonne/*, oImageTri*/, oImageRechercheFiltre, bRechercheEtFiltre, bTexte, bNumDateHeure)
	{
		var oThis = this;

//		if (oImageTri)
//		{
//
//		}

		if (oImageRechercheFiltre)
		{
			if (bRechercheEtFiltre)
			{
				// GP 04/11/2021 : QW445331 : On m�morise le dernier menu de la colonne pour ne pas l'ouvrir deux fois.
				var oDernierMenu = undefined;
				oImageRechercheFiltre.onclick = function (oEvent)
				{
					oEvent = oEvent || event;
					var oColonne = oThis.m_oChampParent._oGetColonne(nColonne);
					var nFiltre = oColonne.nGetFiltre();
					// Pour le moment on n'a pas pas la valeur pr�c�dente de la recherche/du filtre.
					var sValeurInitiale = oThis.m_oChampParent.sGetFiltrePourColonne(nColonne);

					// Si on est d�j� en saisie, affichage du menu.
					// Teste si on est en annulation de saisie (sur perte de focus) : auquel cas on annule celui-ci.
					if (oThis.bAvecEtAnnuleTimeoutAnnule() && (oThis.m_nColonneRecherche === nColonne))
					{
						// Masque le pr�c�dent menu.
						if (oDernierMenu)
						{
							oDernierMenu.__Masque();
						}
						// Cr�ation d'un menu contextuel.
						// Avec suppression du filtre si : on a un filtre actif (on ne filtre pas sur la valeur initiale car non fiable dans le cas des tables AJAX)
						oDernierMenu = new WDMenuContextuelTRF(oEvent
							, oThis
							, oThis.OnSaisieLoupe
							, nColonne
							, bTexte
							, bNumDateHeure
							, (oColonne.ms_nFiltreRecherche !== nFiltre) && ("" !== sValeurInitiale)
							, function ()
							{
								oDernierMenu = undefined;
							});
						// Replace le focus dans le champ de saisie.
						oThis.m_oSaisie.focus();
						return;
					}

					// On rentre directement en saisie avec la recherche/filtre actuel et la valeur actuelle du filtre si disponible.
					oThis.OnSaisieLoupe(oEvent, nColonne, nFiltre, sValeurInitiale);
					// Affiche une ic�ne pour le menu burger pour permettre de changer le mode.
//					xxx;
				};
			}
			else
			{
				oImageRechercheFiltre.onclick = function (oEvent) { oThis.OnRechercheColonne(oEvent || event, nColonne, this); };
			}
			oImageRechercheFiltre.onmouseover = function () { oThis.OnRechercheSurvol(nColonne, this, 1); };
			oImageRechercheFiltre.onmouseout = function () { oThis.OnRechercheSurvol(nColonne, this, 0); };
		}
	};

	// Supprime les divers onXxx des images
	function __SupprimeOnXxxSurImages(/*nColonne, *//*oImageTri, */oImageRechercheFiltre)
	{
//		if (oImageTri)
//		{
//
//		}

		if (oImageRechercheFiltre)
		{
			oImageRechercheFiltre.onmouseout = null;
			oImageRechercheFiltre.onmouseover = null;
			oImageRechercheFiltre.onclick = null;
		}
	};

	// Appel de .Debut
	__WDPopupSaisieTRF.prototype.__Debut = function __Debut(oEvent, oImage, nColonne, bValideSiActif, sValeurInitiale)
	{
		// Trouve le champ mod�le s'il existe
		var oChampModeleMasque = this.m_oChampParent.oGetIDElement(clWDTableDefs.ID_FORMAT, nColonne);
		// GP 07/03/2018 : QW296514 : Pour ne pas avoir le padding du parent (mis dans le style maintenant � 5px...) on se place aux niveau du td et pad du div fils.
		// Version avec un blindage suppl�mentaire qui v�rifie le type du parent
		var oConteneur = oImage.parentNode;
		var oOffsetParent;
		var nReductionLargeur;
		if (clWDUtil.bBaliseEstTag(oConteneur, "div") && clWDUtil.bBaliseEstTag(oConteneur.parentNode, "td"))
		{
			// GP 28/03/2018 : QW297778 : Le probl�me en remontant d'un niveau est que le offsetParent change (le div a un "position:relative").
			// Il faut donc tenir compte du fait que la cellule n'est plus forc�ment tout a gauche du conteneur.
			oOffsetParent = oConteneur.offsetParent;
			oConteneur = oConteneur.parentNode;
			// Comme on se place au niveau du parent, il faut quand m�me tenir compte du positionnement de l'image en plus sinon on colle trop � l'image.
			// Le calcul est : Largeur de l'image + position a gauche de l'image
			// Ce qui donne : oImage.offsetWidth + oImage.offsetParent.offsetWidth - (oImage.offsetLeft + oImage.offsetWidth)
			// Ce qui donne : oImage.offsetWidth + oImage.offsetParent.offsetWidth - oImage.offsetLeft - oImage.offsetWidth
			// Simplifi� en : oImage.offsetParent.offsetWidth - oImage.offsetLeft
			nReductionLargeur = oImage.offsetParent.offsetWidth - oImage.offsetLeft;
		}
		else
		{
			nReductionLargeur = oImage.offsetWidth;
			oOffsetParent = oImage.offsetParent;
		}

		// Tente de trouver la taille de la police utilis� dans le titre de la colonne.
		// => L'id�e est de rechercher un �l�ment avec comme classe ttALIAS (l'alias est l'alias de la colonne) et de prendre sa taille de police.
		var sTaillePolice;
		var tabTitres = clWDUtil.tabGetElementsByClass(oConteneur, "tt" + this.m_oChampParent._oGetColonne(nColonne).m_sAlias);
		if (tabTitres && tabTitres.length && tabTitres[0])
		{
			sTaillePolice = clWDUtil.oGetCurrentStyle(tabTitres[0]).fontSize;
		}

		// La dimension est maintenant la dimension du parent de l'image
		this.Debut(oEvent, oConteneur, oOffsetParent, nReductionLargeur, bValideSiActif, sValeurInitiale, oChampModeleMasque, sTaillePolice, [oImage, nColonne]);
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires (tri, menu, recherche etc)
	//	WDPopupSaisieTRF
	//		Interface avec les champs tables AJAX et navigateur

	// Affiche les pictos (= calcule la visibilit� des pictos) d'une colonne
	// tabColonnes est un tableau de d�riv�s de WDTableColonne
	__WDPopupSaisieTRF.prototype.AjouteLienImages = function AjouteLienImages(tabColonnes, bSansAjoutLien)
	{
		// Parcours toutes les colonnes
		var nColonne;
		var nNbColonnes = tabColonnes.length;
		for (nColonne = 0; nColonne < nNbColonnes; nColonne++)
		{
			var oColonne = tabColonnes[nColonne];

			// Affiche le picto de tri
			var oImageTri = this.m_oChampParent.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_TRI, nColonne);
			var bTri = oColonne.m_bTri;
			if (oImageTri)
			{
				clWDUtil.SetDisplay(oImageTri, bTri);
			}
			// Et le picto de recherche/filtrage
			var oImageRechercheFiltre = this.m_oChampParent.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_RECHERCHE, nColonne);
			var bRechercheEtOuFiltre = (0 < oColonne.m_nRecherche);
			var bRechercheEtFiltre = (1 < oColonne.m_nRecherche);
			if (oImageRechercheFiltre)
			{
				clWDUtil.SetDisplay(oImageRechercheFiltre, bRechercheEtOuFiltre);
				// Fait aussi le choix de l'image (pour les tables navigateurs)
				this.__AfficheImage(oImageRechercheFiltre, nColonne, oColonne, 0);
			}

			// Place les divers onXxx sur les images
			if (!bSansAjoutLien)
			{
				this.__AjouteOnXxxSurImages(nColonne
					/*, bTri ? oImageTri : null*/
					, bRechercheEtOuFiltre ? oImageRechercheFiltre : null
					, bRechercheEtFiltre
					, oColonne.bEstTexte()
					, oColonne.bEstNumerique() || oColonne.bEstDateHeure());
			}
		}
	};

	// Supprime le lien entre le JS et les pictos
	__WDPopupSaisieTRF.prototype.SupprimeLienImages = function SupprimeLienImages(nNbColonnes)
	{
		// Parcours toutes les colonnes
		var nColonne;
		for (nColonne = 0; nColonne < nNbColonnes; nColonne++)
		{
//			var oImageTri = this.m_oChampParent.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_TRI, nColonne);
			var oImageRechercheFiltre = this.m_oChampParent.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_RECHERCHE, nColonne);

			// Place les divers onXxx sur les images
			__SupprimeOnXxxSurImages(/*nColonne, *//*bTri ? oImageTri : null, */ oImageRechercheFiltre);
		}
	};

	// Actualise l'affichage du tri de colonne
	// bTriCroissant === undefined pour ne pas avoir de tri
	__WDPopupSaisieTRF.prototype.AfficheImageTri = function AfficheImageTri(nColonne, bCroissant)
	{
		var tabImagesTri = this.m_tabImages[0];

		// Change l'image de la colonne
		var oImageColonneNouvelle = this.m_oChampParent.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_TRI, nColonne);
		if (oImageColonneNouvelle)
		{
			oImageColonneNouvelle.src = (undefined !== bCroissant) ? (bCroissant ? tabImagesTri[1] : tabImagesTri[2]) : tabImagesTri[0];
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires (tri, menu, recherche etc)
	//	WDPopupSaisieTRF
	//		Impl�mentation des m�thodes de WDPopupSaisie

	// Debut de la saisie
	// nReductionLargeur : pour la saisie dans le champ table : on ne prend pas toute la largeur
	// Tableau des images (recherche ou tri !!!)
	__WDPopupSaisieTRF.prototype._vDebut = function _vDebut(oConteneurParent, oOffsetParent, nReductionLargeur, sValeurInitiale, oChampModeleMasque, sTaillePolice, tabParametresSpecifiques)
	{
		// Appel de la classe de base
		WDPopupSaisie.prototype._vDebut.apply(this, arguments);

		// D�code les parametres
		var oImage = tabParametresSpecifiques[0];
		var nColonneRecherche = tabParametresSpecifiques[1];

		// Colonne de recherche
		this.m_oImage = oImage;
		this.m_nColonneRecherche = nColonneRecherche;

		// On affiche l'image de recherche
		this.__AfficheImage(oImage, nColonneRecherche, this.m_oChampParent._oGetColonne(nColonneRecherche), 0);
	};

	// Valide la saisie
	__WDPopupSaisieTRF.prototype._vValide = function _vValide(oEvent, oValeur)
	{
		// Appel de la classe de base
		WDPopupSaisie.prototype._vValide.apply(this, arguments);

		// Appel de la m�thode interne (factoris� avec OnSaisieLoupe dans le cas de l'annulation)
		this.__Valide(oEvent, this.m_nColonneRecherche, oValeur, false);
	};
	// Version interne de la m�thode (factoris� avec OnSaisieLoupe dans le cas de l'annulation)
	__WDPopupSaisieTRF.prototype.__Valide = function __Valide(oEvent, nColonne, oValeur, bPourAnnulation)
	{
		var oColonne = this.m_oChampParent._oGetColonne(nColonne);

		// On ne fait pas la conversion pour une annulation (ne pard pas la valeur vide)
		if (!bPourAnnulation)
		{
			// GP 27/11/2013 : QW239976 : Il faut faire la conversion vers la valeur interne dans le cas de la recherche
			oValeur = this.__ConversionMasqueModele(oValeur, oColonne.m_sAlias, true);
		}
		// Conversion en chaine pour le test de la longueur
		var sValeur = oValeur + "";

		var nFiltre = oColonne.nGetFiltre();
		if (oColonne.ms_nFiltreRecherche == nFiltre)
		{
			// Si on est en mode recherche
			if (sValeur.length > 0)
			{
				// Lance la recherche
				this.m_oChampParent.OnRecherche(oEvent, nColonne, oValeur);
			}
			else
			{
				// Pour la recherche si la valeur est vide, on ne fait rien
			}
		}
		else
		{
			// Si on est en mode filtrage
			if (sValeur.length > 0)
			{
				// Lance le filtre
				this.m_oChampParent.OnFiltre(oEvent, nColonne, nFiltre, oValeur);
			}
			else
			{
				// Annule le filtre
				this.m_oChampParent.OnAnnuleFiltre(oEvent, nColonne);
			}
		}
	};

	// Annule la saisie
	__WDPopupSaisieTRF.prototype._vAnnule = function _vAnnule()
	{
		// Appel de la classe de base
		WDPopupSaisie.prototype._vAnnule.apply(this, arguments);

		// Supprime nos membres
		var oColonneRecherche = this.m_oChampParent._oGetColonne(this.m_nColonneRecherche);
		this.m_nColonneRecherche = null;
		var oImage = this.m_oImage;
		this.m_oImage = null;

		// On affiche l'image de recherche
		if (oImage && oColonneRecherche)
		{
			this.__AfficheImage(oImage, undefined, oColonneRecherche, 0);
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires (tri, menu, recherche etc)
	//	WDPopupSaisieTRF
	//		Interface avec le DOM

	// Clic sur l'image qui affiche la recherche/le filtre
	// GP 08/11/2021 : Attention ! Ne pas supprimer ! Utilis� par des tests auto de la qualit� (AffichageDeChamps)
	__WDPopupSaisieTRF.prototype.OnRechercheColonne = function OnRechercheColonne(oEvent, nColonneRecherche, oImage)
	{
		// Lance la recherche dans la colonne
		// true : valide si actif
		this.__Debut(oEvent, oImage, nColonneRecherche, true, "");
	};

	// Deplacement de la souris au dessus d'une image de recherche
	__WDPopupSaisieTRF.prototype.OnRechercheSurvol = function OnRechercheSurvol(nColonne, oImage, nImage)
	{
		// Appel le gestionnaire de saisie qui va g�rer l'�tat
		this.__AfficheImage(oImage, nColonne, this.m_oChampParent._oGetColonne(nColonne), nImage);
	};

	// Entr�e en saisie (pour le menu ou pour la fonction WL SaisieLoupe)
	__WDPopupSaisieTRF.prototype.OnSaisieLoupe = function OnSaisieLoupe(oEvent, nColonne, nFiltre, sValeurInitiale)
	{
		// Si le filtre demande est la suppression du filtre
		if (-1 == nFiltre)
		{
			// Annule le filtre
			this.__Valide(oEvent, nColonne, "", true);
			return;
		}

		// Annule le timeout (pour le cas d'un appel depuis le menu avec le champ de saisie affich�).
		this.bAvecEtAnnuleTimeoutAnnule();

		// Fixe le mode de filtrage de la colonne (0 = recherche, 319xx = filtrage)
		this.m_oChampParent._oGetColonne(nColonne).SetFiltre(nFiltre);

		var oImage = this.m_oChampParent.oGetIDElement(clWDTableDefs.ID_TITRE, clWDTableDefs.ID_RECHERCHE, nColonne);
		// Entre en s�lection avec la valeur par d�faut
		// false : annule une pr�c�dente saisie
		this.__Debut(oEvent, oImage, nColonne, false, sValeurInitiale);

		// Le toast ne rend pas bien : utilise un texte d'indication.
//		// On affiche un toast avec le mode actuel.
		var sLibelleFiltreOuUndefined = WDMenuContextuelTRF.s_sGetLibelleFiltre(nFiltre);
		if (undefined !== sLibelleFiltreOuUndefined)
		{
			if (this.m_oSaisie)
			{
				this.m_oSaisie.placeholder = sLibelleFiltreOuUndefined;
			}
//			WDToastBase.prototype.s_ToastAffiche(sLibelleFiltreOuUndefined);
		}
	};

	return __WDPopupSaisieTRF;
})();

//////////////////////////////////////////////////////////////////////////
// Classes utilitaires (tri, menu, recherche etc)
//	WDCelluleSaisie
//		Saisie dans une cellule
// oChampTable : champ qui impl�mente l'interface des tables :
// - eColonneTypeIDObjet
// - bColonneSaisissable
// - nGetHauteurLigneRel (uniquement WDCelluleAJAXSaisie)
// - _nGetNbColonnes
// - sGetValeurCellule
// - nGetValeurCellule
// - SetValeurCellule
// - tabContenuCellule
// - oGetIDCelluleRel
// - oGetIDElement
// - __OnLigneModification ou bMAJLigneRel(WDCelluleAJAXSaisie)
// - bValideChangement (uniquement WDCelluleAJAXSaisie)
// - bCreeLigneVirtuelle (uniquement WDCelluleAJAXSaisie)
// - SupprimeLignesVirtuelles (uniquement WDCelluleAJAXSaisie)
function WDCelluleSaisie(oChampTable)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		this.m_oChampTable = oChampTable;
		this.m_oEventPCodeSortie = null;

		// Construit les pointeurs des __bOnXxx
		var oThis = this;
		this.m_pfOnSubmit = function(oEvent) { return oThis.__bOnSubmit(oEvent || event); };
		this.m_pfOnBlur = function(oEvent) { return oThis.__bOnBlur(oEvent || event); };
		this.m_pfOnKeyDown = function(oEvent) { return oThis.__bOnKeyDown(oEvent || event); };
		this.m_pfOnChange = function(oEvent) { return oThis.__bOnChange(oEvent || event); };
		this.m_nLigne = WDTableZRNavigateur.prototype.ms_nLigneInvalide;
		this.m_nColonne = WDTableZRNavigateur.prototype.ms_nColonneInvalide;
	}
};

WDCelluleSaisie.prototype.ms_nColonneSuivante = -1;
WDCelluleSaisie.prototype.ms_nColonnePrecedente = -2;
WDCelluleSaisie.prototype.ms_nLigneSuivante = -3;
WDCelluleSaisie.prototype.ms_nLignePrecedente = -4;
WDCelluleSaisie.prototype.ms_nSaisieSans = 0;
WDCelluleSaisie.prototype.ms_nSaisieEnCours = 1;
WDCelluleSaisie.prototype.ms_nSaisieSansDocument = 2;
WDCelluleSaisie.prototype.ms_nContinueSaisieSans = 0;
WDCelluleSaisie.prototype.ms_nContinueSaisieLigneCourante = 1;
WDCelluleSaisie.prototype.ms_nContinueSaisieLignePrecedenteFin = 2;
WDCelluleSaisie.prototype.ms_nContinueSaisieLigneSuivanteDebut = 3;
WDCelluleSaisie.prototype.ms_nContinueSaisieLignePrecedente = 4;
WDCelluleSaisie.prototype.ms_nContinueSaisieLigneSuivante = 5;

//////////////////////////////////////////////////////////////////////////
// Classes utilitaires (tri, menu, recherche etc)
//	WDCelluleSaisie
//		Interface g�n�rale

// Indique si on est en saisie
WDCelluleSaisie.prototype.bSaisieEnCours = function bSaisieEnCours(bSansInterrupteur)
{
	switch (this.__eGetSaisieEnCours(bSansInterrupteur))
	{
	case this.ms_nSaisieSans:
		return false;
	case this.ms_nSaisieEnCours:
		return true;
	case this.ms_nSaisieSansDocument:
		// On a un formulaire mais il n'est pas dans le document : annule la saisie
		this.SaisieFin(false, false, WDTableZRNavigateur.prototype.ms_nColonneInvalide, null);
		return false;
	}
};

// Indique si on est en saisie dans la cellule demand�e
WDCelluleSaisie.prototype.bSaisieEnCoursDansCellule = function bSaisieEnCoursDansCellule(nLigne, nColonne)
{
	return this.bSaisieEnCours() && (nLigne == this.m_nLigne) && (nColonne == this.m_nColonne);
};

WDCelluleSaisie.prototype.__OnMAJDonneesTimeout = function __OnMAJDonneesTimeout(oTimeout)
{
	var oThis = this;
	clWDUtil.nSetTimeout(function() { oThis.OnMAJDonnees() }, oTimeout);
};

// Regarde s'il ne faut pas entrer saisie lors de l'affichage
WDCelluleSaisie.prototype.OnMAJDonnees = function OnMAJDonnees(oEvent)
{
	// Si on a le flag
	if (this.m_bEntreEnSaisieSurProchainAffichage)
	{
		// GP 24/11/2017 : TB105771 : s'assure que la ligne est visible.
		var nLigneVisible = this.m_nLigne;
		var oChampTable = this.m_oChampTable;
		// S'assure que la ligne est visible.
		if (window.WDTable && (oChampTable instanceof WDTable))
		{
			// Pour faire afficher la ligne, il faut un d�filement
			var nDefilement = oChampTable.__nGetDefilementPourAfficherLigne(nLigneVisible + oChampTable.m_nDebut);
			if (nDefilement)
			{
				var nDebutAvant = oChampTable.m_nDebut;
				oChampTable.__nForceDefilement(nDefilement, null, false);
				var nDebutApres = oChampTable.m_nDebut;
				// this.m_nLigne est relatif � la premi�re ligne affich�e. Donc il faut modifier m_nLigne selon le d�placeement effectif
				this.m_nLigne = nLigneVisible - nDebutApres + nDebutAvant;
				// Le dessin du defilement est asynchrone. Donc il faut se relancer pour donner le focus "plus tard".
				this.__OnMAJDonneesTimeout(clWDUtil.ms_nTimeoutNonImmediat20);
				return;
			}
		}

		// Entre en saisie
		this.OnClickCellule(nLigneVisible, this.m_nColonne, false, oEvent)
	}
	// Rien dans les tables navigateur pour le moment
};

// Gestion du click sur une cellule
WDCelluleSaisie.prototype.OnClickCellule = function OnClickCellule(nLigne, nColonne, bChangementSelection, oEvent)
{
	// Ne conserve jamais le flag this.m_bEntreEnSaisieSurProchainAffichage
	this.m_bEntreEnSaisieSurProchainAffichage = false;

	// Si la colonne est une colonne interrupteur => Ne fait rien. L'interrupteur se gere tout seul
	switch (this.m_oChampTable.eColonneTypeIDObjet(nColonne))
	{
	case WDChamp.prototype.ms_nIDObjetInterrupteur:
	case WDChamp.prototype.ms_nIDObjetImage:
		// Si on est en saisie : fini la saisie
		if (this.bSaisieEnCours())
		{
			this.SaisieFin(true, false, undefined, oEvent);
		}
		return;
	}

	// Si on est en saisie
	// GP 21/10/2013 : Parfois on a un formulaire valide mais qui n'est plus dans le document
	// Pour avoir le comportement d'avant, ici on ne fait plus le SaisieFin dans les cas autre que la colonne courante
//	if (this.bSaisieEnCours())
	switch (this.__eGetSaisieEnCours(false))
	{
	case this.ms_nSaisieEnCours:
		if (this.m_nLigne == nLigne)
		{
			if (this.m_nColonne == nColonne)
			{
				// On est en saisie sur la m�me ligne et la m�me colonne : ignore l'evenement, c'est que l'utilisateur a fait un clic dans la boite de saisie.
				return;
			}
		}
		// Pas de break;
	case this.ms_nSaisieSansDocument:
		if (this.m_nLigne == nLigne)
		{
			// On est en saisie sur la m�me ligne mais le clic n'est pas sur la m�me colonne : change la case
			this.SaisieFin(true, true, nColonne, oEvent);
		}
		else
		{
			// On est en saisie mais sur une autre ligne et une autre colonne : fin de la saisie
			this.SaisieFin(true, false, undefined, oEvent);
		}
		// Dans tous les cas, le traitement est fini
		return;
	}

	// Mise a jour de l'�tat
	this._SetEtat(nLigne, nColonne);

	// Et commence alors la saisie si la s�lection n'a pas chang� (si la s�lection a �t� chang�e, on ne fait pas une action suppl�mentaire)
	if (!bChangementSelection)
	{
		this.SaisieCommence(oEvent);
	}
	else if (this.m_oChampTable.vbSaisieSansSelection(nColonne))
	{
		// GP 23/02/2016 : TB89890 : Si on a une table en saisie mais sans s�lection on entre directement en saisie sur une s�lection
		this.m_bEntreEnSaisieSurProchainAffichage = true;
	}
};

// Valide et commence la saisie
WDCelluleSaisie.prototype.SaisieCommence = function SaisieCommence(oEvent)
{
	if (this.m_oChampTable.m_bDansOnSelectLigneExterne)
	{
		// GP 30/04/2018 : TB103858 : Si c'est une s�lection de ligne depuis un champ dans une colonne conteneur/une rupture. En amont le code n'a pas de colonne et passe abusivement en saisie.
		return;
	}

	// Uniquement si on n'est pas d�j� en saisie
	// (Le cas ou il fait annuler la saisie est trait� par OnClickCellule
	// Sans tenir compte des interrupteurs car si on est sur une colonne interrupteur, on a alors vrai comme r�ponse et on reste bloqu� dessus
	if (!this.bSaisieEnCours(true))
	{
		// Entre en saisie

		// Fin de l'intercepte du double clic
		this.__ClearOnDblClick();

		// Verifie que la colonne est saisissable
		// Et cree la ligne virtuelle
		if (!this.m_oChampTable.bColonneSaisissable(this.m_nColonne) || !this._vbCreeLigneVirtuelle())
		{
			this._ClearEtat();
			// Et sort direct
			return;
		}

		// Objet qui servira pour placer le formulaire
		var oParent = this._voGetCellule();

		// Regarde si la colonne est d'un type acceptable
		switch (this.m_oChampTable.eColonneTypeIDObjet(this.m_nColonne))
		{
		case WDChamp.prototype.ms_nIDObjetInterrupteur:
			// Interrupteur => L'interrupteur se g�re seul
			var oInterrupteur = oParent.getElementsByTagName("input")[0];
			// GP 03/02/2014 : QW242079 : Il faut g�rer le focus vers le champ suivant
			clWDUtil.AttacheDetacheEvent(true, oInterrupteur, "keydown", this.m_pfOnKeyDown);
			clWDUtil.DonneFocus(oInterrupteur);
			// GP 07/12/2012 : TB79556 : Appel du traitement navigateur
			this.__bOnXxxPourCodeNav(oEvent, oInterrupteur, WDChamp.prototype.ms_nEventNavFocus, "focus", false);
			return;
		}

		// Cree dynamiquement la zone de recherche
		var oFormSaisie = document.createElement("form");
		// Avec son action
		oFormSaisie.method = "post";
		oFormSaisie.action = "javascript:return false;";

		// Si la hauteur des lignes est variable, on prend la hauteur effective de la ligne
		var nHauteurLigne = this._vnGetHauteurLigne();
//		var nHauteurChamp = nHauteurLigne - 4;
		// bIEQuriks ou clWDUtil.bHTML5 ?
		var nHauteurChamp = nHauteurLigne - (bIEQuirks ? 4 : 0);

		// Puis on place le formulaire au bon endroit
		oFormSaisie.style.width = "100%";
		oFormSaisie.style.height = nHauteurChamp + "px";

		// Ensuite on fait le champs de saisie
		var oSaisie;
		// Regarde si la colonne est d'un type acceptable
		switch (this.m_oChampTable.eColonneTypeIDObjet(this.m_nColonne))
		{
		case WDChamp.prototype.ms_nIDObjetCombo:
			// Combo
			var nValeurCombo = this.m_oChampTable.nGetValeurCellule(this.m_nLigne, this.m_nColonne);

			oSaisie = document.createElement("select");
			// Ajoute les options
			var tabOptions = this.m_oChampTable.tabContenuCellule(this.m_nLigne, this.m_nColonne);
			var nOption;
			var nLimiteI = tabOptions.length;
			for (nOption = 0; nOption < nLimiteI; nOption++)
			{
				var oOption = document.createElement("option");
				oOption = oSaisie.appendChild(oOption);
				// GP 28/08/2017 : Suppression des NSUtil.sEncodeInnerHTML(Chaine, false, true) qui ne font rien (sauf la conversion en chaine qui est inutile)
				oOption.innerHTML = String(tabOptions[nOption]);
				oOption.value = nOption;
				if (nValeurCombo == nOption)
				{
					oOption.selected = true;
				}
			}
			break;

//		case WDChamp.prototype.ms_nIDObjetInterrupteur:
//			// Interrupteur => L'interrupteur se g�re seul
//			break;

//		case WDChamp.prototype.ms_nIDObjetImage:
//			// Image => Pas saissisable
//			break;

		case WDChamp.prototype.ms_nIDObjetSaisie:
		default:
			// Saisie et autres
			// GP 15/11/2013 : QW238664 : Force la valeur en chaine
			var sValeurCellule = this.m_oChampTable.sGetValeurCellule(this.m_nLigne, this.m_nColonne) + "";
			// Si le contenu de la cellule contient des RC
			if ((-1 != sValeurCellule.indexOf("\r")) || (-1 != sValeurCellule.indexOf("\n")))
			{
				oSaisie = document.createElement("textarea");
			}
			else
			{
				oSaisie = document.createElement("input");
				oSaisie.type = "text";
			}
			// On n'oublie pas la valeur
			oSaisie.value = sValeurCellule;

			// Si on a un champ mod�le pour la gestion du masque de saisie, copie ses propri�t�es
			this.__SetMasqueModele(oSaisie, this.m_oChampTable.oGetIDElement(clWDTableDefs.ID_FORMAT, this.m_nColonne));

			break;
		}

		// Pour la couleur de fond on remonte au parent qui est dans un div
		var oParentTable = oParent;
		while (clWDUtil.bBaliseEstTag(oParentTable, "div") && (oParentTable.style.backgroundColor == ""))
		{
			oParentTable = oParentTable.parentNode;
		}
		var oParentTypeCurrentStyle = clWDUtil.oGetCurrentStyle(oParentTable);

		// Et lui defini son style
		oSaisie.style.width = "100%";
		// Si on n'est pas en hauteur de ligne variable
		// Si la hauteur de la ligne est inconnue (nGetHauteurLigne retourne -1)
		// SI la hauteur est invalide
		oSaisie.style.height = nHauteurChamp + "px";
		oSaisie.style.borderWidth = "0";
		oSaisie.style.borderStyle = "solid";
		oSaisie.style.borderColor = oParentTypeCurrentStyle.backgroundColor;
		oSaisie.style.fontFamily = oParentTypeCurrentStyle.fontFamily;
		oSaisie.style.fontWeight = oParentTypeCurrentStyle.fontWeight;
		oSaisie.style.fontStyle = oParentTypeCurrentStyle.fontStyle;
		var sFontSize = oParentTypeCurrentStyle.fontSize;
		oSaisie.style.fontSize = sFontSize;
		// Si la hauteur du parent est faible : reduit la taille de la police
		if ((nHauteurChamp <= 18) && (nHauteurChamp > 0))
		{
			var nHauteurReduite = Math.max(nHauteurChamp - 4, 6);
			var bDoitUtiliserHauteurReduite = true;
			if (clWDUtil.s_bTerminePar(sFontSize, "px", false))
			{
				var nHauteurNormale = parseFloat(sFontSize);
				bDoitUtiliserHauteurReduite = isNaN(nHauteurNormale) || (nHauteurReduite < nHauteurNormale);
			}
			// GP 12/04/2019 : TB112838 : N'augmente pas la taille. Si la taille demand� est plus petite.
			if (bDoitUtiliserHauteurReduite)
			{
				oSaisie.style.fontSize = nHauteurReduite + "px";
			}
		}

		// On vide le contenu du parent pour que le positionnement soit bon
		clWDUtil.SupprimeFils(oParent);

		// Attache le champ a son parent
		oFormSaisie.appendChild(oSaisie);
		// On met le tout dans la cellule de recherche
		this.m_oFormulaire = oParent.appendChild(oFormSaisie);
		this.m_oSaisie = this.m_oFormulaire.elements[0];

		// Et la methode de validation qui renvoie toujours faux pour ne pas valider le formulaire
		clWDUtil.AttacheDetacheEvent(true, this.m_oFormulaire, "submit", this.m_pfOnSubmit);
		// Et gere la perte du focus et la touche echap
		clWDUtil.AttacheDetacheEvent(true, this.m_oSaisie, "blur", this.m_pfOnBlur);
		clWDUtil.AttacheDetacheEvent(true, this.m_oSaisie, "keydown", this.m_pfOnKeyDown);
		clWDUtil.AttacheDetacheEvent(true, this.m_oSaisie, "change", this.m_pfOnChange);

		// Sauve le handler de click de la cellule parent
		this.m_fOldClick = oParentTable.onclick;
		oParentTable.onclick = null;
		this.m_oParentTable = oParentTable;

		// Et donne le focus au champ de saisie
		clWDUtil.DonneFocus(this.m_oSaisie);
		// GP 07/12/2012 : TB79556 : Appel du traitement navigateur
		this.__bOnXxxPourCodeNav(oEvent, this.m_oSaisie, WDChamp.prototype.ms_nEventNavFocus, "focus", false);
	}
};

// Indique si on doit lire la valeur nouvelle pour un code de sortie
WDCelluleSaisie.prototype.bGetPourPCodeSortie = function bGetPourPCodeSortie()
{
	return this.m_oEventPCodeSortie && (false !== this.__bValideMasqueModele(this.m_oEventPCodeSortie));
};

// Fin de la saisie
// bValide : Valide ou annule la saisie
// bContinueSaisie (Uniquement si bValide = vrai) : Indique si on doit essayer de continuer la saisie
// nColonneSuivante (Uniquement si bValide et bContinue Saisie sont vrai) : Numero de la colonne ou donner le focus
WDCelluleSaisie.prototype.SaisieFin = function SaisieFin(bValide, bContinueSaisie, nColonneSuivante, oEvent)
{
	// Fin de l'intercepte du double clic
	this.__ClearOnDblClick();

	// Seulement si on a deja une recherche en cours : on la supprime
	switch (this.__eGetSaisieEnCours(false))
	{
	case this.ms_nSaisieSans:
		break;
	case this.ms_nSaisieSansDocument:
	case this.ms_nSaisieEnCours:
		var oInterrupteur;
	
		// GP 13/03/2014 : TB86472 : Certaines fonction de sortie de masque ne retourne rien. Donc on teste explicitement false et on accepte le reste (undefined par exemple)
		if (bValide && (false !== this.__bValideMasqueModele(oEvent)))
		{
			// Transformations selon le type du champ
			switch (this.m_oChampTable.eColonneTypeIDObjet(this.m_nColonne))
			{
			case WDChamp.prototype.ms_nIDObjetInterrupteur:
				// Interrupteur => L'interrupteur se g�re seul
				oInterrupteur = this._voGetCellule().getElementsByTagName("input")[0];
				break;
			}
			this.m_oChampTable.SetValeurCellule(this.m_nLigne, this.m_nColonne, this.pfGetValeurNouvelle());

			// Si on doit tenter de continuer la saisie
			if (bContinueSaisie)
			{
				// Si on a -1 : tente la colonne saisissable suivante
				// GP 07/12/2012 : G�re le d�placement inverse
				switch (nColonneSuivante)
				{
				case this.ms_nColonnePrecedente:
					nColonneSuivante = this.__nGetColonneSaisieSuivante(nColonneSuivante, -1, clWDUtil.s_bSuperieurOuEgal, 0);
					break;
				case this.ms_nColonneSuivante:
					nColonneSuivante = this.__nGetColonneSaisieSuivante(nColonneSuivante, 1, clWDUtil.s_bInferieur, this.m_oChampTable._nGetNbColonnes());
					break;
				case this.ms_nLigneSuivante:
					// Trait� plus loin
					break;
				case this.ms_nLignePrecedente:
					// Trait� plus loin
					break;
				}
			}
		}

		// Detache et supprime le formulaire du document
		if (oInterrupteur)
		{
			// GP 03/02/2014 : QW242079 : Il faut g�rer le focus vers le champ suivant
			clWDUtil.AttacheDetacheEvent(false, oInterrupteur, "keydown", this.m_pfOnKeyDown);
		}
		if (this.m_oSaisie)
		{
			clWDUtil.AttacheDetacheEvent(false, this.m_oSaisie, "change", this.m_pfOnChange);
			clWDUtil.AttacheDetacheEvent(false, this.m_oSaisie, "keydown", this.m_pfOnKeyDown);
			clWDUtil.AttacheDetacheEvent(false, this.m_oSaisie, "blur", this.m_pfOnBlur);
			clWDUtil.bHTMLVideDepuisVariable(this, "m_oSaisie");
		}
		if (this.m_oFormulaire)
		{
			clWDUtil.AttacheDetacheEvent(false, this.m_oFormulaire, "submit", this.m_pfOnSubmit);
			clWDUtil.bHTMLVideDepuisVariable(this, "m_oFormulaire");
		}

		// Restaure le handler de click de la cellule parent
		if (this.m_oParentTable)
		{
			this.m_oParentTable.onclick = this.m_fOldClick;
			this.m_fOldClick = null;
			this.m_oParentTable = null;
		}

		this.__ClearMasqueModele();

		// Et on demande la MAJ de la ligne
		var nContinueSaisie;
		switch (nColonneSuivante)
		{
		case this.ms_nLigneSuivante:
			nContinueSaisie = bContinueSaisie ? this.ms_nContinueSaisieLigneSuivante : this.ms_nContinueSaisieSans;
			break;
		case this.ms_nLignePrecedente:
			nContinueSaisie = bContinueSaisie ? this.ms_nContinueSaisieLignePrecedente : this.ms_nContinueSaisieSans;
			break;
		default:
			nContinueSaisie = this.__nContinueSaisie(bContinueSaisie, nColonneSuivante);
			break;
		}
		var bChangementValide = this._vbMAJLigne(bValide && (this.ms_nContinueSaisieLigneCourante != nContinueSaisie));

		// Si on a une colonne saisissable et que l'on n'a pas envoyer les changements : donne le
		switch (nContinueSaisie)
		{
		case this.ms_nContinueSaisieSans:
			// Fait le menage
			this._ClearEtat();
			break;
		case this.ms_nContinueSaisieLigneCourante:
			// Memorise la colonne
			// GP 28/10/2013 : QW238014 : On manipule bien m_nColonne
			this.m_nColonne = nColonneSuivante;

			// Et commence la saisie
			this.SaisieCommence(oEvent);
			return;
		case this.ms_nContinueSaisieLignePrecedenteFin:
			// Si on a une colonne valide pour entrer en saisie
			this.__PrepareSaisieLigneAutre(oEvent, -1, this.m_oChampTable._nGetNbColonnes(), clWDUtil.s_bSuperieurOuEgal, 0, bChangementValide);
			break;
		case this.ms_nContinueSaisieLigneSuivanteDebut:
			// Si on a une colonne valide pour entrer en saisie
			this.__PrepareSaisieLigneAutre(oEvent, 1, -1, clWDUtil.s_bInferieur, this.m_oChampTable._nGetNbColonnes(), bChangementValide);
			break;
		case this.ms_nContinueSaisieLignePrecedente:
			// Si on a une colonne valide pour entrer en saisie
			// "this.m_nColonne + 1" car la recherche va commencer � "nDebut (troisi�me param�tre) + nPas (second param�tre)" et on veux cibler exactement this.m_nColonne (et mettre le pas � 0 expose � des bugs si la cellule n'est pas disponible).
			this.__PrepareSaisieLigneAutre(oEvent, -1, this.m_nColonne + 1, clWDUtil.s_bSuperieurOuEgal, 0, bChangementValide);
			break;
		case this.ms_nContinueSaisieLigneSuivante:
			// Si on a une colonne valide pour entrer en saisie
			// "this.m_nColonne - 1" car la recherche va commencer � "nDebut (troisi�me param�tre) + nPas (second param�tre)" et on veux cibler exactement this.m_nColonne (et mettre le pas � 0 expose � des bugs si la cellule n'est pas disponible).
			this.__PrepareSaisieLigneAutre(oEvent, 1, this.m_nColonne - 1, clWDUtil.s_bInferieur, this.m_oChampTable._nGetNbColonnes(), bChangementValide);
			break;
		}

		break;
	}

	// Supprime la ligne virtuelle
	this._vSupprimeLignesVirtuelles();
};
// Lecture des valeurs nouvelles
WDCelluleSaisie.prototype.pfGetValeurNouvelle = function pfGetValeurNouvelle()
{
	var oThis = this;
	return function(bEntier)
	{
		return oThis.__oGetValeurNouvelle(bEntier);
	};
};
WDCelluleSaisie.prototype.__oGetValeurNouvelle = function __oGetValeurNouvelle (bEntier)
{
	// Transformations selon le type du champ
	switch (this.m_oChampTable.eColonneTypeIDObjet(this.m_nColonne))
	{
	case WDChamp.prototype.ms_nIDObjetCombo:
		// Combo
		var nValeur = parseInt(this.m_oSaisie.value, 10);
		if (bEntier)
		{
			return nValeur;
		}
		else
		{
			return this.m_oChampTable.tabContenuCellule(this.m_nLigne, this.m_nColonne)[nValeur];
		}

	case WDChamp.prototype.ms_nIDObjetInterrupteur:
		// Interrupteur => L'interrupteur se g�re seul
		var nValeur = this._voGetCellule().getElementsByTagName("input")[0].checked ? 1 : 0;
		if (bEntier)
		{
			return nValeur;
		}
		else
		{
			return String(nValeur);
		}

//	case WDChamp.prototype.ms_nIDObjetImage:  
//		// Image => Pas saissisable  
//		break;  

	case WDChamp.prototype.ms_nIDObjetSaisie:
	default:
		if (bEntier)
		{
			return -1;
		}
		else
		{
			return this.__ConversionMasqueModele(this.m_oSaisie.value, this.m_oChampTable._oGetColonne(this.m_nColonne).m_sAlias, this._vbAvecMasqueModele());
		}
	}
};

// GP 22/11/2013 : QW239684 : Si on a une saisie dans la table : d�tache le formulaire
WDCelluleSaisie.prototype.bDetacheFormulaire = function bDetacheFormulaire()
{
	if (this.bSaisieEnCours())
	{
		// Si on est en saisie sur un interrupteur on n'a pas de formulaire
		if (this.m_oFormulaire)
		{
			this.m_oFormulaire = this.m_oFormulaire.parentNode.removeChild(this.m_oFormulaire);
			return true;
		}
	}
	return false;
};

// GP 22/11/2013 : QW239684 : Si on a une saisie dans la table : d�tache le formulaire
WDCelluleSaisie.prototype.AttacheFormulaire = function AttacheFormulaire(bDetache)
{
	if (bDetache)
	{
		var oCellule = this._voGetCellule();
		clWDUtil.SupprimeFils(oCellule);
		this.m_oFormulaire = oCellule.appendChild(this.m_oFormulaire);
	}
};

//////////////////////////////////////////////////////////////////////////
// Classes utilitaires (tri, menu, recherche etc)
//	WDCelluleSaisie
//		M�thodes internes g�n�rales

// Recupere la cellule
WDCelluleSaisie.prototype._voGetCellule = function _voGetCellule()
{
	// m_nLigne est une ligne RELATIVE (ou WL selon le type de table) !!!
	var oDiv = this.m_oChampTable.oGetIDCelluleRel(this.m_nLigne, this.m_nColonne);
	return oDiv ? oDiv.parentNode.parentNode : null;
};

// MAJ de l'�tat
WDCelluleSaisie.prototype._SetEtat = function _SetEtat(nLigne, nColonne)
{
	// On supprime la precedente interception du double clic
	if ((WDTableZRNavigateur.prototype.ms_nLigneInvalide != this.m_nLigne) && (WDTableZRNavigateur.prototype.ms_nColonneInvalide != this.m_nColonne))
	{
		// Trouve bien la cellule pr�c�dente car this.m_nLigne et this.m_nColonne n'a pas encore �t� MAJ
		this.__ClearOnDblClick();
	}

	// Met a jour pour l'edition suivante
	this.m_nLigne = nLigne;
	this.m_nColonne = nColonne;

	// On intercepte le double clic qui lance directement la saisie si besoin
	this.__SetOnDblClick();
};

// Vide l'�tat
WDCelluleSaisie.prototype._ClearEtat = function _ClearEtat()
{
	// Replace la valeur par d�faut
	this.m_nLigne = WDTableZRNavigateur.prototype.ms_nLigneInvalide;
	this.m_nColonne = WDTableZRNavigateur.prototype.ms_nColonneInvalide;
};

// Trouve la hauteur d'une ligne
WDCelluleSaisie.prototype._vnGetHauteurLigne = function _vnGetHauteurLigne()
{
	// Lit directement la hauteur de la cellule
	return this._voGetCellule().clientHeight;
};

// Demande la MAJ de la ligne
// Retourne vrai si la table va �tre redessin�e
WDCelluleSaisie.prototype._vbMAJLigne = function _vbMAJLigne(/*bValideChangement*/)
{
	// On ne peut pas recevoir undefined car dans ce cas _xnLigneWLLigne lance une exception
	// Note la MAJ de la ligne (provoque le reaffichage)
	this.m_oChampTable.__OnLigneModification(this.m_nLigne);

	return true;
};

// Cr�ation de la ligne virtuelle (toujours en r�ussite)
WDCelluleSaisie.prototype._vbCreeLigneVirtuelle = clWDUtil.m_pfVide;
// Supprime la ligne virtuelle (toujours en r�ussite)
WDCelluleSaisie.prototype._vSupprimeLignesVirtuelles = clWDUtil.m_pfVide;

// GP 27/11/2013 : QW239976 : Il faut faire la conversion vers la valeur interne dans la saisie des tables navigateur mais pas des tables AJAX
// clWDUtil.m_pfVide retourne true
WDCelluleSaisie.prototype._vbAvecMasqueModele = clWDUtil.m_pfVide;

// Recherche la colonne suivante/pr�c�dente acceptable pour la suite de la saisie
WDCelluleSaisie.prototype.__nGetColonneSaisieSuivante = function __nGetColonneSaisieSuivante(nColonneSuivante, nPas, pfComparaison, nValeurLimite)
{
	var nColonneRecherche;
	for (nColonneRecherche = this.m_nColonne + nPas; pfComparaison(nColonneRecherche, nValeurLimite); nColonneRecherche += nPas)
	{
		if (this.m_oChampTable.bColonneSaisissable(nColonneRecherche))
		{
			// On va reprende a cette colonne
			return nColonneRecherche;
		}
	}
	return nColonneSuivante;
};

// Si on a une colonne valide pour entrer en saisie
WDCelluleSaisie.prototype.__PrepareSaisieLigneAutre = function __PrepareSaisieLigneAutre(oEvent, nPas, nDebut, pfComparaison, nValeurLimite, bChangementValide)
{
	var nLigne = this.m_nLigne + nPas;

	// Fait le menage
	this._ClearEtat();

	this.m_nLigne = nLigne;
	this.m_nColonne = nDebut;
	this.m_nColonne = this.__nGetColonneSaisieSuivante(-1, nPas, pfComparaison, nValeurLimite);
	// Si on trouve une colonne valide (sinon on recoit le premier param�tre de __nGetColonneSaisieSuivante qui permet de d�tecter le cas)
	if (-1 != this.m_nColonne)
	{
		this.m_bEntreEnSaisieSurProchainAffichage = true;
	}

	// GP 02/04/2015 : TB87945 : Si on n'a pas modifi� la ligne on ne retourne pas au serveur et donc on ne redessine pas la table et on n'entre donc pas en saisie dans la cellule suivante
	// => Passe directement en saisie
	if (!bChangementValide)
	{
		this.__OnMAJDonneesTimeout(clWDUtil.ms_oTimeoutImmediat);
	}
};

// Indique si on est en saisie
WDCelluleSaisie.prototype.__eGetSaisieEnCours = function __eGetSaisieEnCours(bSansInterrupteur)
{
	if (this.m_oFormulaire)
	{
		// V�rifie que le formulaire est dans le document
		if (clWDUtil.bEstDansDocument(this.m_oFormulaire))
		{
			// On a un formulaire qui est dans le document : on est ens saisie
			return this.ms_nSaisieEnCours;
		}
		else
		{
			return this.ms_nSaisieSansDocument;
		}
	}
	else if (!bSansInterrupteur && (0 <= this.m_nColonne) && (WDChamp.prototype.ms_nIDObjetInterrupteur == this.m_oChampTable.eColonneTypeIDObjet(this.m_nColonne)))
	{
		// GP 29/01/2014 : QW241146 : Les interrupteurs ne bloquent pas la saisie
		return this.ms_nSaisieEnCours;
	}
	else
	{

		return this.ms_nSaisieSans;
	}
};

// GP 21/10/2013 : Dans IE en mode quirks (y compris dans IE10) on a (click) + (double-click)
// Avec les autres navigateur et pas en mode quirks, on a (click) + ((click) + (doubleclick))
if (bIEQuirks)
{
	// Ecrit le le ondblclick
	WDCelluleSaisie.prototype.__SetOnDblClick = function __SetOnDblClick()
	{
		var oCellule = this._voGetCellule();
		if (oCellule)
		{
			if (!this.m_pfOnDblClick)
			{
				// GP 04/10/2013 : Refactoring : filtre le cas d�j� en saisie dans SaisieCommence
				var oThis = this;
				this.m_pfOnDblClick = function(oEvent) { oThis.SaisieCommence(oEvent || event); };
			}

			// GP 04/10/2013 : Refactoring : filtre le cas d�j� en saisie dans SaisieCommence
			oCellule.ondblclick = this.m_pfOnDblClick;
		}
	};
	// Supprime le le ondblclick
	WDCelluleSaisie.prototype.__ClearOnDblClick = function __ClearOnDblClick()
	{
		var oCellule = this._voGetCellule();
		if (oCellule)
		{
			oCellule.ondblclick = null;
		}
	};
}
else
{
	WDCelluleSaisie.prototype.__SetOnDblClick = clWDUtil.m_pfVide;
	// Supprime le le ondblclick
	WDCelluleSaisie.prototype.__ClearOnDblClick = clWDUtil.m_pfVide;
}

// onsubmit sur le formulaire
WDCelluleSaisie.prototype.__bOnSubmit = function __bOnSubmit(oEvent)
{
	this.SaisieFin(true, true, this.ms_nColonneSuivante, oEvent);
	return clWDUtil.bStopPropagation(oEvent);
};

// onblur sur un champ
WDCelluleSaisie.prototype.__bOnBlur = function __bOnBlur(oEvent)
{
	var oElement = clWDUtil.oGetTarget(oEvent);

	// GP 07/12/2012 : TB79556 : Appel du traitement navigateur
	this.__bAppelOnBlur(oEvent, oElement);

	this.SaisieFin(true, false, undefined, oEvent);
	return clWDUtil.bStopPropagation(oEvent);
};
WDCelluleSaisie.prototype.__bAppelOnBlur = function __bAppelOnBlur(oEvent, oElement)
{
	this.__bOnXxxPourCodeNav(oEvent, oElement, WDChamp.prototype.ms_nEventNavBlur, "blur", true);
};

// onkeydown sur un champ
WDCelluleSaisie.prototype.__bOnKeyDown = function __bOnKeyDown(oEvent)
{
	var oElement = clWDUtil.oGetTarget(oEvent);

	switch (oEvent.keyCode)
	{
	case 9:
		// Tab
		// GP 07/12/2012 : TB60939 : Gestion du shift + tab
		return this.__bOnEnchaineSaisieGD(oEvent, oElement, !oEvent.shiftKey);
	case 27:
		// Escape
		this.SaisieFin(false, undefined, undefined, oEvent);
		return clWDUtil.bStopPropagation(oEvent);
	// Ne fait pour le moment car on ne g�re pas le changement de ligne
//	case 33:
//		// Touche page up
//		return clWDUtil.bStopPropagation(oEvent);
//	case 34:
//		// Touche page down
//		return clWDUtil.bStopPropagation(oEvent);
	case 37:
		// Touche fl�che gauche
		return this.__bOnFlecheGaucheDroite(oEvent, oElement, false);
	case 38:
		// Touche fl�che haut
		return this.__bOnFlecheHautBas(oEvent, oElement, false);
	case 39:
		// Touche fl�che droite
		return this.__bOnFlecheGaucheDroite(oEvent, oElement, true);
	case 40:
		// Touche fl�che bas
		return this.__bOnFlecheHautBas(oEvent, oElement, true);
	default:
		return true;
	}
};

// GP 03/01/2018 : Vu avec TB106187 : Il faut faire le onchange et onblur en cas de perte du focus par le d�placement par les touches.
WDCelluleSaisie.prototype.__bOnEnchaineSaisieGD = function __bOnEnchaineSaisieGD(oEvent, oElement, bColonneSuivante)
{
	// Appel de onchange si modification.
	if (true)
	{
		var bAnnulation = this.__bAppelOnChange(oEvent, oElement);
		// Test de la valeur de retour.
		if (bAnnulation)
		{
			return bAnnulation;
		}
	}

	// Appel de onblur.
	this.__bAppelOnBlur(oEvent, oElement);

	this.SaisieFin(true, true, bColonneSuivante ? this.ms_nColonneSuivante : this.ms_nColonnePrecedente, oEvent);
	return clWDUtil.bStopPropagation(oEvent);
};

WDCelluleSaisie.prototype.__bOnEnchaineSaisieHB = function __bOnEnchaineSaisieHB(oEvent, oElement, bLigneSuivante)
{
	// Appel de onchange si modification.
	if (true)
	{
		var bAnnulation = this.__bAppelOnChange(oEvent, oElement);
		// Test de la valeur de retour.
		if (bAnnulation)
		{
			return bAnnulation;
		}
	}

	// Appel de onblur.
	this.__bAppelOnBlur(oEvent, oElement);

	this.SaisieFin(true, true, bLigneSuivante ? this.ms_nLigneSuivante : this.ms_nLignePrecedente, oEvent);
	return clWDUtil.bStopPropagation(oEvent);
};

// onchange sur un champ combo
WDCelluleSaisie.prototype.__bOnChange = function __bOnChange(oEvent)
{
	var oElement = clWDUtil.oGetTarget(oEvent);

	// GP 07/12/2012 : TB79556 : Appel du traitement navigateur
	var bAnnulation = this.__bAppelOnChange(oEvent, oElement);

	// GP 07/12/2012 : TB79556 : Rewriting : filtr� ici
	// On a un traitement sp�cifique uniquement sur les combo
	if (clWDUtil.bBaliseEstTag(oElement, "select"))
	{
		var nTouche = oEvent.keyCode;
		if (undefined !== nTouche)
		{
			switch (nTouche)
			{
			case 9:
				// Tab
				// GP 07/12/2012 : TB60939 : Gestion du shift + tab
				this.SaisieFin(true, true, oEvent.shiftKey ? this.ms_nColonnePrecedente : this.ms_nColonneSuivante, oEvent);
				break;
			default:
				// Ne change rien
				return bAnnulation;
			}
		}
		return clWDUtil.bStopPropagation(oEvent);
	}
	else
	{
		return bAnnulation;
	}
};
WDCelluleSaisie.prototype.__bAppelOnChange = function __bAppelOnChange(oEvent, oElement)
{
	return false === this.__bOnXxxPourCodeNav(oEvent, oElement, WDChamp.prototype.ms_nEventNavChange, "change", true);
};

// Gestion des touches gauche et droite
// Retourne vrai si la touche a �t� g�r�
WDCelluleSaisie.prototype.__bOnFlecheGaucheDroite = function __bOnFlecheGaucheDroite(oEvent, oElement, bDroite)
{
	// Par d�faut : non
	var bFlecheGaucheDroite = false;

	// Selon le type du champ
	switch (clWDUtil.sGetTagName(oElement))
	{
	case "input":
		switch (oElement.type.toLowerCase())
		{
		case "checkbox":
			// Les case a cocher : toujours
			bFlecheGaucheDroite = true;
			break;
		case "text":
			// Les champs de saisie : si on est en extr�mit� => trouve la position du curseur
			var nPositionCurseur;
			// Si on est en HTML5
			var nSelectionHTML5 = bDroite ? oElement.selectionEnd : oElement.selectionStart;
			var nValeurLongeur = oElement.value.length;
			if (typeof nSelectionHTML5 == "number")
			{
				nPositionCurseur = nSelectionHTML5;
			}
			else
			{
				// Recupere la selection (qui normalement est dans le champ : oSelection.parentElement() == oElement)
				var oSelection = document.selection.createRange();
				
				if (!bDroite)
				{
					nPositionCurseur = - oSelection.moveStart("character", -nValeurLongeur);
				}
				else
				{
					nPositionCurseur = nValeurLongeur - oSelection.moveEnd("character", nValeurLongeur);
				}
			}
			bFlecheGaucheDroite = nPositionCurseur === (bDroite ? nValeurLongeur : 0);
			break;
//		default:
//			break;
		}
		break;
	case "select":
		// Les combos : toujours (pas comme en WinDev)
		bFlecheGaucheDroite = true;
		break;
//	default:
//		break;
	}

	if (bFlecheGaucheDroite)
	{
		return this.__bOnEnchaineSaisieGD(oEvent, oElement, bDroite);
	}
	else
	{
		return true;
	}
};

WDCelluleSaisie.prototype.__bOnFlecheHautBas = function __bOnFlecheGaucheDroite(oEvent, oElement, bBas)
{
	// Par d�faut : non
	var bFlecheHautBas = false;

	// Selon le type du champ
	switch (clWDUtil.sGetTagName(oElement))
	{
	case "input":
		switch (oElement.type.toLowerCase())
		{
		case "checkbox":
			// Les case a cocher : toujours
			bFlecheHautBas = true;
			break;
		case "text":
			// Les champs de saisie : toujours.
			bFlecheHautBas = true;
			break;
//		default:
//			break;
		}
		break;
	case "select":
		// Les combos : jamais (on pourrais regarder si on est sur la derni�re option, mais il faudrait aussi avoir le cas de la combo pas encore ouverte).
//		bFlecheHautBas = false;
		break;
//	default:
//		break;
	}

	if (bFlecheHautBas)
	{
		return this.__bOnEnchaineSaisieHB(oEvent, oElement, bBas);
	}
	else
	{
		return true;
	}
};

// GP 07/12/2012 : TB79556 : Appel du traitement navigateur : le champ est dans un formulaire qui est dans la cellule avec le code
WDCelluleSaisie.prototype.__bOnXxxPourCodeNav = function __bOnXxxPourCodeNav(oEvent, oElement, eEvent, sEvent, bPourPCodeSortie)
{
	// GP 03/01/2017 : TB106187 : Si on est dans le code de onchange/onblur d'une colonne de table, il faut utiliser la valeur saisie.
	clWDUtil.WDDebug.assert(null == this.m_oEventPCodeSortie, "R\xE9entrance des appels de PCodes de sortie");
	var oEventPCodeSortiePrecedent = this.m_oEventPCodeSortie;
	try
	{
		this.m_oEventPCodeSortie = bPourPCodeSortie ? oEvent : null;

		// GP 07/12/2012 : Et les interrupteur qui sont d�j� la (pour les tables AJAX)
		var pfOnXxx = oElement.parentNode.parentNode["on" + sEvent];
		if (pfOnXxx)
		{
			return pfOnXxx(oEvent);
		}
		// Si on est sur une table navigateur, on peut faire un appel de __oAppelPCodeSurLigne(nLigne, fPCode, oEvent)
		var oColonne = this.m_oChampTable._oGetColonne(this.m_nColonne);
		if (oColonne && this.m_oChampTable.__oAppelPCodeSurLigne)
		{
			this.m_oChampTable.__oAppelPCodeSurLigne(this.m_nLigne, clWDUtil.pfGetTraitement(oColonne.m_sAlias, eEvent), oEvent);
		}
		return true;
	}
	finally
	{
		this.m_oEventPCodeSortie = oEventPCodeSortiePrecedent;
	}
};

// Indique si on doit continuer la saisie
WDCelluleSaisie.prototype.__nContinueSaisie = function __nContinueSaisie(bContinueSaisie, nColonneSuivante)
{
	if (bContinueSaisie)
	{
		// Ignore les valeurs invalides
		switch (nColonneSuivante)
		{
		case this.ms_nColonnePrecedente:
			// On n'a pas de colonne pr�c�dente, remonte d'une ligne si possible
			return (0 < this.m_nLigne) ? this.ms_nContinueSaisieLignePrecedenteFin : this.ms_nContinueSaisieSans;
		case this.ms_nColonneSuivante:
			// On n'a pas de colonne suivante, avance d'une ligne (on ne teste rien, avec la ligne virtuelle on peut avoir une nouvelle ligne)
			return this.ms_nContinueSaisieLigneSuivanteDebut;
		case undefined:
			return this.ms_nContinueSaisieSans;
		default:
			return this.m_oChampTable.bColonneSaisissable(nColonneSuivante) ? this.ms_nContinueSaisieLigneCourante : this.ms_nContinueSaisieSans;
		};
	}
	else
	{
		return this.ms_nContinueSaisieSans;
	}
};

// Si on a un champ mod�le pour la gestion du masque de saisie, copie ses propri�t�es
// Partage de code avec WDPopupSaisie
WDCelluleSaisie.prototype.__SetMasqueModele = WDPopupSaisie.prototype.__SetMasqueModele;
// Valide si on a un mod�le
// Partage de code avec WDPopupSaisie
WDCelluleSaisie.prototype.__bValideMasqueModele = WDPopupSaisie.prototype.__bValideMasqueModele;
// Supprime les trace du mod�le
// Partage de code avec WDPopupSaisie
WDCelluleSaisie.prototype.__ClearMasqueModele = WDPopupSaisie.prototype.__ClearMasqueModele;
// Conversion en sortie du masque
// Partage de code avec WDPopupSaisie
WDCelluleSaisie.prototype.__ConversionMasqueModele = WDPopupSaisie.prototype.__ConversionMasqueModele;

// GP 11/06/2014 : Appel dans du code g�n�r� dans le HTML du champ.
// Pour ne pas casser les pages internes 19 dans une page 20 (ou plus), on garde le m�me symbole et au lieu de WDMenuContextuelExport.prototype.s_Ouvre
// On �tend WDMenuContextuel avec _OuvreExport
// Ouverture d'un menu d'export des tables
WDMenuContextuel.prototype.s_OuvreExport = (function ()
{
	"use strict";

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	WDMenuContextuelExport
	//		Affichage du menu contextuel d'export des tables et zones r�p�t�es
	function WDMenuContextuelExport(oEvent, sAliasChamp)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// M�morise les param�tres sp�cifiques
			this.m_sAliasChamp = sAliasChamp;

			// Appel le constructeur de la classe de base
			// GP 25/02/2015 : TB88160 : Demande l'ouverture dans une direction "intelligente"
			WDMenuContextuel.prototype.constructor.apply(this, [oEvent, ms_tabOptions, this.ms_eOuvreSensAutomatique, TABLE_EXPORT]);
		}
	}

	// Declare l'heritage
	WDMenuContextuelExport.prototype = new WDMenuContextuel();
	// Surcharge le constructeur qui a ete efface
	WDMenuContextuelExport.prototype.constructor = WDMenuContextuelExport;

	// Constantes
	var ms_tabOptions =
		[
			{
				m_sExtension: "xls",
				m_sCommande: "EXPORTXLS",
				m_oLibelle: { m_sTraduction: "EXCEL", sLibelle: "Exporter vers Excel...", sTitre: "Exporter le contenu vers Excel..." }
			},
			{
				m_sExtension: "rtf",
				m_sCommande: "EXPORTRTF",
				m_oLibelle: { m_sTraduction: "WORD", sLibelle: "Exporter vers Word...", sTitre: "xporter le contenu vers Word..." }
			},
			{
				m_sExtension: "xml",
				m_sCommande: "EXPORTXML",
				m_oLibelle: { m_sTraduction: "XML", sLibelle: "Exporter vers XML...", sTitre: "Exporter le contenu vers XML..." }
			},
			{
				m_sExtension: "pdf",
				m_sCommande: "EXPORTPDF",
				m_oLibelle: { m_sTraduction: "PDF", sLibelle: "Imprimer en PDF...", sTitre: "Imprimer vers un fichier PDF..." }
			}
		];

	// M�thodes virtuelles

	// Effectue l'action
	WDMenuContextuelExport.prototype._vAction = function _vAction(oEvent, oOptionSelection)
	{
		// Si on est dans une page AWP : on g�n�re le lien diff�rement car sinon on bug (Ouverture de www.monsite.com/export.xls
		// Si on a _WDR_ c'est que l'on n'est pas dans une page dynamique, comme l'export n'existe que dans les pages dynamiques ou AWP,
		// cela indique si l'on est	ou pas dans une page AWP
		// GP 22/03/2012 : Contournement pour TB72295 : Dans Firefox on ouvre dans un nouveau navigateur (qui sera imm�diatement referm�)
		_JCL(_PU_ + (window["_WDR_"] ? "" : ("/export." + oOptionSelection.m_sExtension)) + "?WD_ACTION_=" + oOptionSelection.m_sCommande + "&" + this.m_sAliasChamp, bFF ? "_blank" : "_self", "", "");
	};

	// Filtre les options
	WDMenuContextuelExport.prototype._vbFiltre = clWDUtil.m_pfVide;

	// M�thodes sp�cifiques

	// GP 11/06/2014 : Appel dans du code g�n�r� dans le HTML du champ.
	// Pour ne pas casser les pages internes 19 dans une page 20 (ou plus), on garde le m�me symbole et au lieu de WDMenuContextuelExport.prototype.s_Ouvre
	// On �tend WDMenuContextuel avec _OuvreExport
	// Ouverture d'un menu d'export des tables
	return function (oEvent, sAliasChamp)
	{
		// Instancie un nouveau menu
		new WDMenuContextuelExport(oEvent, sAliasChamp);
	};
})();

//////////////////////////////////////////////////////////////////////////
// Classes utilitaires (tri, menu, recherche etc)
//	WDSelection
//		Gestion de la selection

function WDSelection (oChampTable, eTypeSelection)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		this.m_oChampTable = oChampTable;
		// M�morise le type de s�lection autoris�
		this.m_eTypeSelection = eTypeSelection;

		// Mode de s�lection courant (on ne peut avoir en m�me temps que une s�lection � la ligne ou � la colonne ou � la cellule
		this.m_nModeSelection = this.ms_nTsLigne;
		// Tableau des �l�ments s�lectionn�
		this.m_tabSelection = [];
	}
};

// Constantes
WDSelection.prototype.ms_nSelectionSans = 0;
WDSelection.prototype.ms_nSelectionSimple = 1;
WDSelection.prototype.ms_nSelectionMultiple = 2;
WDSelection.prototype.ms_nTsLigne = 0;
// La s�lection � la colonne est d�sactiv�e pour le moment
//WDSelection.prototype.ms_nTsColonne = 1;
WDSelection.prototype.ms_nTsCellule = 2;
WDSelection.prototype.ms_nTsLigneCellule = 10;
WDSelection.prototype.ms_nTsColonneCellule = 11;
// Copie pour simplifier la notation
WDSelection.prototype.ms_nLigneInvalide = WDTableZRNavigateur.prototype.ms_nLigneInvalide;

// Initialisation : pour le champ formulaire
WDSelection.prototype.Init = function Init()
{
	// Ecrit la s�lection actuelle (= aucune) dans le champ formulaire
	this._MAJValeurChampFormulaire();
};

// Ecrit la s�lection actuelle dans le champ formulaire
WDSelection.prototype._MAJValeurChampFormulaire = function _MAJValeurChampFormulaire()
{
	this.m_oChampTable.m_oChampFormulaire.value = this.m_oChampTable._nLigneLigneWL(this.nGetSelection());
};

// Fait les MAJs
WDSelection.prototype._OnChangementSelection = function _OnChangementSelection(nLigne, bExecutePCode, oEvent)
{
	// Fait la mise � jour du champ cach� (m�me si le rang modifi� n'est pas le premier, ce qui est �crit dans le champ formulaire est potentiellement complexe)
	this._MAJValeurChampFormulaire();

	// Notifie la table
	this.m_oChampTable.OnChangementSelection(nLigne, bExecutePCode, oEvent);
};

// R�cup�re la s�lection actuelle
WDSelection.prototype.nGetSelection = function nGetSelection()
{
	// Normalement this.m_oChampTable.m_oChampFormulaire.value n'est pas �crit dans notre dos.
	// => Plus besoin de lire this.m_oChampTable.m_oChampFormulaire.value
	if (undefined !== this.m_nForceSelection)
	{
		return this.m_nForceSelection;
	}
	else
	{
		// GP 17/11/2013 : QW238215 : Il est ecrit dans notre DOS par la g�n�ration HTML.

		return this.m_tabSelection.length ? this.m_tabSelection[0].m_nLigne : this.ms_nLigneInvalide;
	}
};

// Retourne la ligne actuellement forc�e
WDSelection.prototype.nGetForceSelection = function nGetForceSelection()
{
	return this.m_nForceSelection;
};

// Force la s�lection
WDSelection.prototype.ForceSelection = function ForceSelection(nLigne)
{
	this.m_nForceSelection = nLigne;
};

// Si c'est la premi�re ligne, r�init la s�lection
WDSelection.prototype.ReinitSelection = function ReinitSelection(nLigne)
{
	// Repasse en s�lection � la ligne
	this.SetModeSelection(this.ms_nTsLigne, true);
	// Si on autorise la s�lection, s�lectionne une ligne (avec ex�cution du PCode)
	if (this.ms_nSelectionSans != this.m_eTypeSelection)
	{
		// GP 01/10/2021 : TB123378 : Si le num�ro de ligne est invalide, c'est que l'on a supprimer la derni�re ligne.
		if (undefined !== nLigne)
		{
			// GP 01/09/2014 : Utilisation de SelectPlusDirect car la ligne est forc�ment non s�lectionn�e apr�s l'appel de this.SetModeSelection(..., true)
			this.SelectPlusDirect(nLigne, true, null);
		}
	}
};

// Reinit la s�lection sauf si la s�lection courante est d�j� exactement la ligne demand�e
WDSelection.prototype.ReinitSelectionSansReselection = function ReinitSelectionSansReselection(nLigne)
{
	// Change la s�lection si :
	// - La s�lection n'est pas par ligne
	// - Il n'y a pas exactement une ligne de s�lectionn�e
//	if ((this.ms_nTsLigne != this.m_nModeSelection) || (1 != this.m_tabSelection.length) || (nLigne != this.m_tabSelection[0].m_nLigne))
	if ((this.ms_nTsLigne != this.m_nModeSelection) || (1 != this.m_tabSelection.length) || (!this.bGetLigneEstSelectionnee(nLigne)))
	{
		this.ReinitSelection(nLigne);
	}
};

// Passe en mode de s�lection diff�ren
// Si on indique de vider toujours  : on d�selection tout m�me si le mode ne change pas
WDSelection.prototype.SetModeSelection = function SetModeSelection(nModeSelection, bVideToujours)
{
	if ((nModeSelection != this.m_nModeSelection) || bVideToujours)
	{
		this.bSelectAucun();
	}
	this.m_nModeSelection = nModeSelection;
};

// Regarde si une ligne est s�lectionn�
WDSelection.prototype.bGetLigneEstSelectionnee = function bGetLigneEstSelectionnee(nLigne)
{
	return clWDUtil.nElementInconnu != this._nGetRangLigneSelection(nLigne);
};
// Si oui retourne son rang dans la s�lection
WDSelection.prototype._nGetRangLigneSelection = function _nGetRangLigneSelection(nLigne)
{
	return clWDUtil.nDansTableauFct(this.m_tabSelection, this.__s_nCompareSelectionLigne, nLigne)
};
WDSelection.prototype.__s_nCompareSelectionLigne = function __s_nCompareSelectionLigne(oSelection, nLigne)
{
	// Si on est en s�lection � la cellule, retourne toutes les cellules de la ligne
	return oSelection.m_nLigne == nLigne;
};

// Indique la s�lection
WDSelection.prototype.xnSelectOccurrence = function xnSelectOccurrence(nModeSelection)
{
	switch (nModeSelection)
	{
	default:
		// Le code serveur retourne une erreur ici
		// Erreur fatale WL :
		// "La valeur de la constante (%1) est invalide avec cette fonction.",
		throw new WDErreur(303, nModeSelection);
	case this.ms_nTsLigne:
//	case this.ms_nTsColonne:
	case this.ms_nTsCellule:
		// Si l'information demand�e correspond au mode courant, on retourne la taille du tableau avec la s�lection
		return (this.m_nModeSelection == nModeSelection) ? this.m_tabSelection.length : 0;
	}
};

// Retourne la ni�me ligne s�lectionnn�e
WDSelection.prototype.xnSelect = function xnSelect(nRangC, nModeSelection)
{
	var nModeSelectionOccurrence;
	switch (nModeSelection)
	{
	default:
		nModeSelectionOccurrence = nModeSelection;
		break;
	case this.ms_nTsLigneCellule:
	case this.ms_nTsColonneCellule:
		nModeSelectionOccurrence = this.ms_nTsCellule;
		break;
	}
	// Si la constante est invalide, SelectOccurrence lance une exception, on a donc pas besoin de la valider plus loin
	var nSelectOccurrence = this.xnSelectOccurrence(nModeSelectionOccurrence);

	// Valide le rang de la s�lection
	// V�rifie aussi que l'information demand�e correspond au mode courant
	if ((nRangC < 0) || (nSelectOccurrence <= nRangC) || (this.m_nModeSelection != nModeSelection))
	{
		// Pas d'erreur WL
		return this.ms_nLigneInvalide;
	}

	// Si la constante est invalide, xnSelectOccurrence lance une exception, on a forc�ment une constante valide ici
	var oSelection = this.m_tabSelection[nRangC];
	switch (nModeSelection)
	{
	default:
//	case this.ms_nTsLigneCellule:
		return oSelection.m_nLigne;
	case this.ms_nTsColonneCellule:
		return oSelection.m_nColonne;
	}
};

// S�lectionne/D�selectionne les lignes (fonction en ...)
// Retourne l'indice de la premi�re (dans l'ordre du tableau) ligne dont la s�lection a �t� chang�e
// Les indices sont en indices C
WDSelection.prototype.xSelectPlusMoins = function xSelectPlusMoins(pfSelectPlusMoins, pfSelectTousAucun, tabArguments)
{
	// Ne fait rien si la s�lection n'est pas sur des lignes
	if (this.ms_nTsLigne == this.m_nModeSelection)
	{
		if (tabArguments.length)
		{
			// On demande la d�s�lection d'une s�rie de lignes
			var nArgument;
			var nLimiteArguments = tabArguments.length;
			for (nArgument = 0; nArgument < nLimiteArguments; nArgument++)
			{
				pfSelectPlusMoins.apply(this, [tabArguments[nArgument]]);
			}

		}
		else
		{
			// On demande la d�s�lection de toutes les lignes
			pfSelectTousAucun.apply(this, [null]);
		}
	}
	else
	{
		// Ne fait rien si la s�lection n'est pas sur des lignes
		// Faire une erreur ?
	}
};

// D�s�lectionne une ligne selon son num�ro de ligne
WDSelection.prototype.bSelectMoins = function bSelectMoins(nLigne)
{
	var bChangementSelection = false;

	// Trouve le rang de s�lection de cette ligne
	// On peut avoir plusieurs s�lection si on est en s�lection � la cellule
	var nRang;
	while (clWDUtil.nElementInconnu != (nRang = this._nGetRangLigneSelection(nLigne)))
	{
		this._SelectMoinsRang(nRang, null);
		// La ligne �tait s�lectionn�e
		bChangementSelection = true;
	}

	return bChangementSelection;
};
// D�s�lectionne une ligne selon son rang dans la s�lection
WDSelection.prototype._SelectMoinsRang = function _SelectMoinsRang(nRang, oEvent)
{
	// R�cup�re l'�l�ment dans le tableau de la s�lection en le supprimant du tableau
	var oSelection = this.m_tabSelection.splice(nRang, 1)[0];

	// Fait les MAJs
	this._OnChangementSelection(oSelection.m_nLigne, false, oEvent);
};

// S�lectionne une ligne
WDSelection.prototype.bSelectPlus = function bSelectPlus(nLigne, bExecutePCode, oEvent)
{
	// Si la ligne n'est pas d�j� s�lectionn�e
	if (!this.bGetLigneEstSelectionnee(nLigne))
	{
		this.SelectPlusDirect(nLigne, bExecutePCode, oEvent);
		// On a changer la s�lection
		return true;
	}
	else
	{
		// Aucun changement de la s�lection
		return false;
	}
};

// S�lectionne une ligne qui n'est pas d�j� s�lectionn�e
WDSelection.prototype.SelectPlusDirect = function SelectPlusDirect(nLigne, bExecutePCode, oEvent)
{
	clWDUtil.WDDebug.assert(!this.bGetLigneEstSelectionnee(nLigne), "Ligne d\xE9j\xE0 s\xE9lectionn\xE9e");

	// Si la liste est mono s�lection, supprime la s�lection
	// Si la liste est sans s�lection, la s�lection simple par programmation est possible
	if (this.ms_nSelectionMultiple != this.m_eTypeSelection)
	{
		this.bSelectAucun(oEvent);
	}

	// Construit l'�l�ment
	var oSelection = { m_nLigne: nLigne };
	// L'ajoute dans le tableau de la s�lection
	this.m_tabSelection.push(oSelection);

	// Fait les MAJs
	this._OnChangementSelection(nLigne, bExecutePCode, oEvent);

	// On a changer la s�lection
	return true;
};

// D�selectionne tout (les lignes/colonnes/cellules)
// Retourne si la s�lection � chang�
WDSelection.prototype.bSelectAucun = function bSelectAucun(oEvent, nLigneConserve)
{
	var bChangementSelection = false;

	// Supprime un par un les �l�ments de la s�lection
	var tabSelection = this.m_tabSelection;
	var nRang = 0;
	while (nRang < tabSelection.length)
	{
		// Si on doit d�selectionner la ligne
		if (nLigneConserve != tabSelection[nRang].m_nLigne)
		{
			this._SelectMoinsRang(nRang, oEvent);
			bChangementSelection = true;
		}
		else
		{
			// La ligne est la ligne exclue.
			// => Il ne faut plus la tester, avance le rang de teste (logiquement la ligne n'est pr�sente que une fois, donc on passe de 0 � 1)
			nRang++;
		}
	}

	return bChangementSelection;
};

// D�selectionne toutes les lignes
// Retourne l'indice de la premi�re (dans l'ordre du tableau) ligne nouvelle s�lectionn�e
WDSelection.prototype.SelectTous = function SelectTous(oEvent)
{
	// Rien si la liste n'est pas multis�lection
	if (this.ms_nSelectionMultiple == this.m_eTypeSelection)
	{
		var nLigne;
		var nLimiteLignes = this.m_oChampTable._nGetNbLignes();
		for (nLigne = 0; nLigne < nLimiteLignes; nLigne++)
		{
			this.bSelectPlus(nLigne, false, oEvent);
		}
	}
};

// Notifie la s�lection de l'insertion de la ligne (d�cale les lignes suivantes)
WDSelection.prototype.OnLigneInsere = function OnLigneInsere(nLigne)
{
	// Si c'est la premi�re ligne ajout�e
	if (1 == this.m_oChampTable._nGetNbLignes())
	{
		// R�init la s�lection
		this.ReinitSelection(0);
	}
	else
	{
		// D�cale la s�lection des lignes s�lectionn�es apr�s la ligne courante
		clWDUtil.bForEach(this.m_tabSelection, function(oSelection)
		{
			if (nLigne <= oSelection.m_nLigne)
			{
				oSelection.m_nLigne++;
			}
			return true;
		});
	}
};

// Notifie la s�lection de la suppression de la ligne (d�cale le reste de la s�lection, et �ventuellement res�lectionne la ligne (visible) suivante)
WDSelection.prototype.OnLigneSupprime = function OnLigneSupprime(nLigne)
{
	// GP 15/11/2013 : QW238708 : Imite l'action serveur : si la s�lection est une s�lection simple et que la ligne est s�lectionn�e, s�lectionne la ligne suivante
	// (qui arrive � la place de la ligne)
	// Supprime la ligne de la s�lection (si la ligne n'est pas s�lectionn�e, ne fait rien)
	var bSelectionnee = this.bSelectMoins(nLigne);

	// D�cale la s�lection des lignes s�lectionn�es apr�s la ligne courante
	clWDUtil.bForEach(this.m_tabSelection, function(oSelection)
	{
		if (nLigne < oSelection.m_nLigne)
		{
			oSelection.m_nLigne--;
		}
		return true;
	});

	// Si la ligne �tait s�lectionn�e et que la s�lection est simple, s�lectionne l'ex ligne suivante
	// En fait on s�lectionne a ligne suivante VISIBLE
	if (bSelectionnee && (this.ms_nSelectionSimple == this.m_eTypeSelection))
	{
		var nLigneASelectionner = this.m_oChampTable.nGetLigneAfficheeAutour(nLigne);
		if (this.ms_nLigneInvalide != nLigneASelectionner)
		{
			this.bSelectPlus(nLigneASelectionner, true);
		}
	}
};

// Corrige la s�lection
// Utilise la valeur de nLigneDestination non modifi�
WDSelection.prototype.OnLigneDeplace = function OnLigneDeplace(nLigneSource, nLigneDestination, bEchange)
{
	if (bEchange)
	{
		// Si on echange : recherche les deux lignes avant d'en modifi�e une car la modification de la s�lection de nLigneSource va la transformer en nLigneDestination
		// que l'on risque de trouver avec la seconde recherche.
		var nRangSource = this._nGetRangLigneSelection(nLigneSource);
		var nRangDestination = this._nGetRangLigneSelection(nLigneDestination);
		if (clWDUtil.nElementInconnu != nRangSource)
		{
			this.m_tabSelection[nRangSource].m_nLigne = nLigneDestination;
		}
		if (clWDUtil.nElementInconnu != nRangDestination)
		{
			this.m_tabSelection[nRangDestination].m_nLigne = nLigneSource;
		}
	}
	else
	{
		var tabSelection = this.m_tabSelection;
		var nSelection;
		var nLimiteSelection = tabSelection.length;
		for (nSelection = 0; nSelection < nLimiteSelection; nSelection++)
		{
			// Si on d�place :
			// - nLigneSource < nLigneDestination :
			//	- Change la ligne de nLigneSource en nLigneDestination
			//	- D�cale de un vers le bas des dans ]nLigneSource, nLigneDestination[
			// (nLigneDestination ne se d�cale pas)
			// - nLigneDestination < nLigneSource
			//	- Change la ligne de nLigneSource en nLigneDestination
			//	- D�cale de un vers le haut des dans [nLigneDestination, nLigneSource[
			var oSelection = tabSelection[nSelection];
			if (oSelection.m_nLigne == nLigneSource)
			{
				oSelection.m_nLigne = nLigneDestination;
			}
			if ((nLigneSource < oSelection.m_nLigne) && (oSelection.m_nLigne < nLigneDestination))
			{
				oSelection.m_nLigne--;
			}
			else if ((nLigneDestination <= oSelection.m_nLigne) && (oSelection.m_nLigne < nLigneSource))
			{
				oSelection.m_nLigne++;
			}
		}
	}
};

// Click sur une ligne
WDSelection.prototype.OnSelectLigne = function OnSelectLigne(nLigne, nColonne, oEvent, bColonneLien)
{
	// Uniquement si :
	// - On autorise la selection
	// - La ligne existe (= ignore le clic dans une des lignes vide en bas quand on gerera la fonctionnalit�e)
	// - On n'est pas en saisie dans la cellule cliqu�e
	if ((this.ms_nSelectionSans != this.m_eTypeSelection) && (undefined !== nLigne) && this.m_oChampTable.m_oCelluleSaisie && !this.m_oChampTable.m_oCelluleSaisie.bSaisieEnCoursDansCellule(nLigne, nColonne))
	{
		var bCtrl = (oEvent && !bColonneLien) ? oEvent.ctrlKey : false;
		var bShift = (oEvent && !bColonneLien) ? oEvent.shiftKey : false;

		var bChangementSelection = false;
		var bSelectionSimple = (this.m_eTypeSelection == WDSelection.prototype.ms_nSelectionSimple) || bColonneLien;

		// Si on est en selection simple ou que ctrl et shift ne sont pas enfonce (Selection multiple): supprime les autres selections
		// Sauf la ligne en cours de selection car elle doit rester selectionnee
		if (bSelectionSimple || (!bCtrl && !bShift))
		{
			bChangementSelection |= this.bSelectAucun(oEvent, nLigne);
		}
		// GP 09/01/2014 : QW241165 : Non car sinon on ne peut pas cliquer dans la colonne voisine + d�j� filtr�e avec bSaisieEnCoursDansCellule
//		// Si on est en saisie et que la selection ne change pas : fin
//		if (!bChangementSelection && this.m_oChampTable.m_oCelluleSaisie.bSaisieEnCours())
//		{
//			return;
//		}

		// Regarde si la ligne est selectionne
		var nRang;
		// Decide si on va deselectionne la ligne si elle est selectionne
		if (clWDUtil.nElementInconnu != (nRang = this._nGetRangLigneSelection(nLigne)))
		{
			// bCtrl est a faux si la colonne est lien donc c'est OK
			if (bCtrl)
			{
				// Deselectionne la ligne
				this._SelectMoinsRang(nRang, oEvent);
				bChangementSelection = true;
			}
			// Et reselection de la la ligne si la colonne est lien
			if (bColonneLien)
			{
				bChangementSelection |= this.bSelectPlus(nLigne, true, oEvent);
			}
		}
		else
		{
			// Dans le cas de la selection multiple on traite les touches shift et Ctrl
			// Ctrl => Rien a faire on ajoute simplement a la selection
			// Shift => On ajoute tout entre la premiere selectionne si elle existe et la nouvelle
			// GP 17/10/2013 : @@@ Ce n'est pas derni�re s�lectionn�e plutot ?
			if (!bSelectionSimple && bShift && this.m_tabSelection.length)
			{
				var nSelection = this.m_tabSelection[0].m_nLigne;
				var nSens = (nSelection < nLigne) ? 1 : -1;
				var tabLignes = this.m_oChampTable.m_tabLignes;
				for (nSelection += nSens; nSelection != nLigne; nSelection += nSens)
				{
					// GP 15/11/2013 : Ne s�lectionne pas les lignes filtr�es
					if (tabLignes[nLigne].bGetVerifieFiltre())
					{
						// Selectionne les lignes si besoin
						bChangementSelection |= this.bSelectPlus(nSelection, true, oEvent);
					}
				}
			}

			// Selectionne la ligne
			// (si on est pass� dans le cas "shift", on n'a pas s�lectionn�e la ligne (test !=) et sinon on n'a pas s�lectionn�e la ligne
			bChangementSelection |= this.bSelectPlus(nLigne, true, oEvent);
		}

		// Gere une eventuelle entree en saisie dans la ligne
		if (this.m_oChampTable.m_oCelluleSaisie)
		{
			this.m_oChampTable.m_oCelluleSaisie.OnClickCellule(nLigne, nColonne, bChangementSelection, oEvent);
		}

		// Pas besoin de faire de redessin, chaque appel de bSelectPlus/_SelectMoinsRang/bSelectAucun a notifier la table du changement de s�lection
	}
};

//////////////////////////////////////////////////////////////////////////
// Classes utilitaires (tri, menu, recherche etc)
//	WDAffichageColonnes
//		Gestion de la largeur (redimensionnement et ancrage) et de l'ordre (d�placement) des colonnes

var WDAffichageColonnes = (function ()
{
	"use strict";

	var WDDnDColonne = (function ()
	{
		//////////////////////////////////////////////////////////////////////////
		// Classes utilitaires (tri, menu, recherche etc)
		//	WDDnDColonne
		//		D�placement des colonnes

		function __WDDnDColonne(oAffichageColonne, oColonne, oElement)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Calcule si la colonne est source : si d�placable
				var nSource = oColonne.bColonneDeplace() ? 1 : 0;
				// Calcule si la colonne est cible : si insertion � droite ou a gauche
				var nCible = oColonne.bColonneInsereGaucheDroite() ? 1 : 0;

				// Appel le constructeur de la classe de base
				WDDnDNatif.prototype.constructor.apply(this, [nSource, nCible, oElement, this.ms_nOperationDeplacement]);

				// M�morise les informations
				this.m_oAffichageColonne = oAffichageColonne;
				this.m_oColonne = oColonne;
			}
		};

		// Declare l'heritage
		__WDDnDColonne.prototype = new WDDnDNatif();
		// Surcharge le constructeur qui a ete efface
		__WDDnDColonne.prototype.constructor = __WDDnDColonne;

		//////////////////////////////////////////////////////////////////////////
		// Classes utilitaires (tri, menu, recherche etc)
		//	WDDnDColonne
		//		Impl�mentation des m�thodes de WDDnDNatif

		// Ecrit la/les valeurs : lit le champs
		__WDDnDColonne.prototype._vSetDonneesDnD = function _vSetDonneesDnD()
		{
			// Appel de la methode de la classe de base
			WDDnDNatif.prototype._vSetDonneesDnD.apply(this, arguments);

			// GP 14/11/2013 : QW238989 : Place des donn�es dans le DnD (sinon on ne part pas en DnD avec Firefox et Safari)
			this._SetEventDataSelonTypeAvecCorrection(this.ms_tabTypes[0], this.m_oColonne.m_sAlias);
//			this._SetEventDataSelonTypeAvecCorrection(this.ms_tabTypes[1], this.m_oColonne.m_sAlias);
		};

		// Operation de mouvement de la sourie
		__WDDnDColonne.prototype._vnGetOperationSurDrop = function _vnGetOperationSurDrop(/*nDnDOperation*/)
		{
			var oDnDSource = this.ms_oDnDSource;
			// Si la source n'est pas une de nos DnD
			// instanceof g�re le cas undefined
			if (!(oDnDSource instanceof __WDDnDColonne) || (this.m_oAffichageColonne !== oDnDSource.m_oAffichageColonne))
			{
				// Refuse le DnD sur autre chose que une colonne de notre table
				return this.ms_nOperationSans;
			}
			else
			{
				// Refuse le DnD si une colonne n'accepte pas l'insertion a droite ou a gauche
				// Si le drop est interdit, on recoit une colonne invalide
				var oColonneCible = this.__oPositionAffichageCible(oDnDSource);
				if (!oColonneCible)
				{
					return this.ms_nOperationSans;
				}
			}

			// Utilise l'operation par defaut definie
			return WDDnDNatif.prototype._vnGetOperationSurDrop.apply(this, arguments);
		};

		// En cas de survol
		// Ici ce qui nous importe est l'entr�e en survol
		__WDDnDColonne.prototype._vnOnDragSurvol = function _vnOnDragSurvol(nDnDOperation, nOperation)
		{
			// Si on arrive ici c'est que _vnGetOperationSurDrop a valider le contenu du drop

			// Appel de la methode de la classe de base
			nOperation = WDDnDNatif.prototype._vnOnDragSurvol.apply(this, arguments);

			if (this.ms_nDnDEntreeChamp == nDnDOperation)
			{
				// Ne fait rien en cas de DnD de la colonne sur elle m�me (= pas de d�placement)
				if (this !== this.ms_oDnDSource)
				{
					// On ne teste pas si on peut placer a gauche ou a droite de la colonne, c'est d�j� fait avant (test� dans _vnGetOperationSurDrop)
					this.__AjouteDivsPosition();
				}
			}

			// Si on arrive ici c'est que _vnGetOperationSurDrop a valider le contenu du drop
			return nOperation;
		};

		// Indique que l'on sort du survol
		__WDDnDColonne.prototype._vOnDragExit = function _vOnDragExit()
		{
			// On sort de la colonne : supprime l'indication graphique de placement
			this.__SupprimeDivsPosition();

			// Appel de la methode de la classe de base
			WDDnDNatif.prototype._vOnDragExit.apply(this, arguments);
		};

		// Lacher sur l'element
		__WDDnDColonne.prototype._vOnDrop = function _vOnDrop()
		{
			// Appel de la methode de la classe de base
			WDDnDNatif.prototype._vOnDrop.apply(this, arguments);

			// Supprime l'indication graphique de placement
			this.__SupprimeDivsPosition();

			var oDnDSource = this.ms_oDnDSource;
			// Ne fait rien en cas de DnD de la colonne sur elle m�me (= pas de d�placement)
			// On ne bloque pas plus t�t pour ne pas perturber l'utilisateur final avec une interdiction en d�but de DnD
			if (this !== oDnDSource)
			{
				var oColonneCible = this.__oPositionAffichageCible(oDnDSource);
				// Demande le d�placement de la source vers nous
				// Le survol a valider que l'on est sur la m�me table
				this.m_oAffichageColonne.DeplaceColonne(oDnDSource.m_oColonne, oColonneCible.m_nPositionAffichage);
			}
		};

		// Emule le DnDNatif avec IE9 : Oui si on est bien en IE9
		// Il faut le test bIE car nIE = 0 pour les navigateurs qui ne sont pas IE
		__WDDnDColonne.prototype._vbEmuleIE9 = function _vbEmuleIE9()
		{
			return bIE && (nIE < 10);
		};

		//////////////////////////////////////////////////////////////////////////
		// Classes utilitaires (tri, menu, recherche etc)
		//	WDDnDColonne
		//		M�thodes internes g�n�rales

		// Refuse le DnD si une colonne n'accepte pas l'insertion a droite ou a gauche{
		__WDDnDColonne.prototype.__oPositionAffichageCible = function __oPositionAffichageCible(oDnDSource)
		{
			// GP 14/11/2013 : QW238805 : Le calcul est compliqu�, trouve la position d'affichage cible pour le drop
			var nPositionAffichageSource = oDnDSource.m_oColonne.m_nPositionAffichage;

			var oColonne = this.m_oColonne;
			var nPositionAffichageCible = oColonne.m_nPositionAffichage;
			if (nPositionAffichageSource < nPositionAffichageCible)
			{
				// D�calage vers la fin : ajoute apr�s (= � droite)
				while (oColonne)
				{
					if (oColonne.bColonneInsereDroite())
					{
						// Ajout a droite possible
						return oColonne;
					}

					// Ajout a droite interdit
					// GP 14/11/2013 : QW238805 : Sauf si une des colonne a droite est invisible et que elle autorise l'insertion : on insere alors a cet endroit.
					// Explication : Si on a des sur ent�tes de colonne
					//	| Col1	| Col2-3		| Col 4	|
					//	| Col1	| Col2	| Col3	| Col 4	|
					// Si on d�place Col1 sur Col2 : l'insertion est impossible car on n'a pas le droit de mettre entre Col2 et Col3
					// Maintenant si Col3 est invisible :
					//	| Col1	| Col2-3| Col 4	|
					//	| Col1	| Col2	| Col 4	|
					// On n'a toujours pas le droit de mettre a droite de Col2 (entre Col2 et Col3) : pour le cas ou l'on r�-affiche Col3.
					// En revanche on peut ajouter a droite de Col3, ce qui dans la situation courante revient au m�me.
					oColonne = this.m_oAffichageColonne.oGetColonneInvisible(++nPositionAffichageCible);
				}
				// Si on arrive ici c'est que ajout a droite est effectivement interdit
			}
			else if (nPositionAffichageCible < nPositionAffichageSource)
			{
				// D�calage vers le d�but : ajoute avant (= � gauche)
				while (oColonne)
				{
					if (oColonne.bColonneInsereGauche())
					{
						// Ajout a droite possible
						return oColonne;
					}

					// Ajout a gauche interdit
					// GP 14/11/2013 : QW238805 : Sauf si une des colonne a gauche est invisible et que elle autorise l'insertion : on insere alors a cet endroit.
					// Explication : Si on a des sur ent�tes de colonne
					//	| Col1	| Col2-3		| Col 4	|
					//	| Col1	| Col2	| Col3	| Col 4	|
					// Si on d�place Col4 sur Col3 : l'insertion est impossible car on n'a pas le droit de mettre entre Col2 et Col3
					// Maintenant si Col3 est invisible :
					//	| Col1	| Col2-3| Col 4	|
					//	| Col1	| Col2	| Col 4	|
					// On n'a toujours pas le droit de mettre a gauche de Col3 (entre Col2 et Col3) : pour le cas ou l'on r�-affiche Col3.
					// En revanche on peut ajouter a gauche de Col2, ce qui dans la situation courante revient au m�me.
					oColonne = this.m_oAffichageColonne.oGetColonneInvisible(--nPositionAffichageCible);
				}
				// Si on arrive ici c'est que ajout a droite est effectivement interdit
			}

			// Ajout interdit
			return null;
		};

		// Ajoute les deux divs de survol
		__WDDnDColonne.prototype.__AjouteDivsPosition = function __AjouteDivsPosition()
		{
			// On peut avoir plusieurs appels en entr�e ou en sortie selon les �l�ments internes survol�s, supprime la pr�c�dente indication
			this.__SupprimeDivsPosition();

			var nPositionAffichageSource = this.ms_oDnDSource.m_oColonne.m_nPositionAffichage;
			var nPositionAffichageDestination = this.m_oColonne.m_nPositionAffichage;

			// Colonne a gauche (affiche le div a droite)
			var nPositionAffichageGauchePourDivDroit;
			// Colonne a droite (affiche le div a gauche)
			var nPositionAffichageDroitePourDivGauche;
			if (nPositionAffichageSource < nPositionAffichageDestination)
			{
				// Si on d�place la colonne vers la droite : affiche dans la colonne et dans la colonne suivante
				nPositionAffichageGauchePourDivDroit = nPositionAffichageDestination;
				nPositionAffichageDroitePourDivGauche = this.m_oAffichageColonne.nGetPositionAffichageValide(nPositionAffichageDestination + 1, 1);
			}
			else
			{
				// Si on d�place la colonne vers la gauche : affiche dans la colonne et dans la colonne pr�c�dente
				nPositionAffichageGauchePourDivDroit = this.m_oAffichageColonne.nGetPositionAffichageValide(nPositionAffichageDestination - 1, -1);
				nPositionAffichageDroitePourDivGauche = nPositionAffichageDestination;
			}

			// Affiche les deux divs
			this.__AjouteUnDivPosition(nPositionAffichageGauchePourDivDroit, true, "m_oDivDroit");
			this.__AjouteUnDivPosition(nPositionAffichageDroitePourDivGauche, false, "m_oDivGauche");
		};
		// Ajoute un div de survol
		__WDDnDColonne.prototype.__AjouteUnDivPosition = function __AjouteUnDivPosition(nPositionAffichage, bDivDroite, sNomMembre)
		{
			// Seulement si on a une position (on n'a pas de position si on est "avant" la premi�re colonne affich�e, ou "apr�s" la derni�re colonne affich�e
			if (undefined !== nPositionAffichage)
			{
				var oElement = this.m_oAffichageColonne.m_oChampTable.oGetIDElement(clWDTableDefs.ID_TITRE, this.m_oAffichageColonne.m_tabPositionAffichage[nPositionAffichage].m_oColonne.m_nRangCreation);
				// GP 25/11/2013 : Parfois clientHeight est 0
				var nHauteurLigne = oElement.clientHeight || oElement.offsetHeight;

				var oImage = document.createElement("img");
				oImage.src = this.m_oAffichageColonne.m_tabFleches[bDivDroite ? 0 : 1];
				var sPadding = (nHauteurLigne - 8) / 2 + "px";
				oImage.style.paddingTop = sPadding;
				oImage.style.paddingBottom = sPadding;

				// On entre au dessus de la colonne : ajoute l'indication graphique de placement
				var oDiv = document.createElement("div");
				oDiv.style.position = "absolute";
				oDiv.style.top = "0";
				if (bDivDroite)
				{
					oDiv.style.right = "0";
					oImage.style.borderRight = "1px solid white";
					oDiv.style.borderRight = "1px solid red";
				}
				else
				{
					oDiv.style.left = "0";
					oImage.style.borderLeft = "1px solid white";
					oDiv.style.borderLeft = "1px solid red";
				}
				oDiv.appendChild(oImage);
				this[sNomMembre] = oElement.appendChild(oDiv);
			}
		};

		// Supprime le div de survol
		__WDDnDColonne.prototype.__SupprimeDivsPosition = function __SupprimeDivsPosition()
		{
			// Div de la premi�re colonne (= a droite de la colonne de gauche)
			clWDUtil.bHTMLVideDepuisVariable(this, "m_oDivDroit");
			// Div de la seconde colonne (= a gauche de la colonne de droite)
			clWDUtil.bHTMLVideDepuisVariable(this, "m_oDivGauche");
		};

		return __WDDnDColonne;
	})();

	function __WDAffichageColonnes(oChampTable, tabFleches, oStyleCacheLargeur)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDDrag.prototype.constructor.apply(this, [0, 50]);

			this.m_oChampTable = oChampTable;
			this.m_tabFleches = tabFleches;
			this.m_oStyleCacheLargeur = oStyleCacheLargeur;
			this.m_sPrefixe = "table .wbcol";

			// Cr�ation du tableau des colonnes (vide pour le moment)
			this.m_tabPositionAffichage = [];
		}
	};

	// Declare l'heritage
	__WDAffichageColonnes.prototype = new WDDrag();
	// Surcharge le constructeur qui a ete efface
	__WDAffichageColonnes.prototype.constructor = __WDAffichageColonnes;

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires (tri, menu, recherche etc)
	//	WDAffichageColonnes
	//		Interface g�n�rale

	// Initialisation : r�cupere la liste des colonnes
	__WDAffichageColonnes.prototype.Init = function Init(tabColonnes)
	{
		var oChampTable = this.m_oChampTable;
		var tabPositionAffichage = this.m_tabPositionAffichage;

		// GP 24/11/2013 : QW239000 : Dans le d�placement des colonnes dans les tables AJAX, on fait InitTitres deux fois lors d'une d�placement
		// Une fois lors du d�placement, une fois lors du retour du serveur
		// => Ajout d'une protection dans .Init
		if (tabPositionAffichage.length)
		{
			this.LibereTitres();
			tabPositionAffichage.length = 0;
		}

		// Construit le tableau d'ordre des colonnes
		// Chaque colonne � sa position d'affichage (qui n'est pas forc�ment sa position de cr�ation)
		tabPositionAffichage.length = tabColonnes.length;

		var oColonne;
		var nColonne;
		var nLimiteColonne = tabColonnes.length;
		for (nColonne = 0; nColonne < nLimiteColonne; nColonne++)
		{
			// Trouve l'objet colonne
			oColonne = tabColonnes[nColonne];
			var oTitreColonne = this.m_oChampTable.oGetIDElement(clWDTableDefs.ID_TITRE, nColonne);
			var pfClick;
			if (oTitreColonne)
			{
				// Active le tri en cas de clic sur le titre de colonne.
				if (oColonne.m_bTri)
				{
					pfClick = (function ()
					{
						var nRangCreation = oColonne.m_nRangCreation;
						return function (oEvent)
						{
							oChampTable.OnTriColonne(nRangCreation, oEvent);
						};
					})();
					oTitreColonne.addEventListener("click", pfClick);
				}
			}
			// Construit l'objet des param�tres
			tabPositionAffichage[oColonne.m_nPositionAffichage] =
				{
					m_oColonne: oColonne,
					m_oTitreColonne: oTitreColonne,
					m_oDeplace: new WDDnDColonne(this, oColonne, oTitreColonne),
					m_pfClick: pfClick
				};
		}
	};

	// On viens de changer l'ordre des colonnes, refait le lien entre le HTML des colonnes et le DnD
	__WDAffichageColonnes.prototype.InitTitres = function InitTitres()
	{
		var oChampTable = this.m_oChampTable;

		// GP 24/11/2013 : QW239000 : Dans le d�placement des colonnes dans les tables AJAX, on fait InitTitres deux fois lors d'une d�placement
		// Une fois lors du d�placement, une fois lors du retour du serveur
		// => Ajout d'une protection dans .Init

		var tabPositionAffichage = this.m_tabPositionAffichage;
		var nPositionAffichage;
		var nLimitePositionAffichage = tabPositionAffichage.length;
		// GP 01/10/2015 : Ce code n'a jamais fonctionn� : le &= fait que l'on ne passe jamais a true
//		var bColonneAvecLargeur = false;
		for (nPositionAffichage = 0; nPositionAffichage < nLimitePositionAffichage; nPositionAffichage++)
		{
			var oPositionAffichage = tabPositionAffichage[nPositionAffichage];
			var oColonne = oPositionAffichage.m_oColonne;
			// Retrouve le titre
			var oTitreColonne = oChampTable.oGetIDElement(clWDTableDefs.ID_TITRE, oColonne.m_nRangCreation);
			oPositionAffichage.m_oTitreColonne = oTitreColonne;

			// GP 13/11/2013 : QW238193 : Seulement si le titre existe
			if (oTitreColonne)
			{
				oPositionAffichage.m_oDeplace._InitElement(oTitreColonne);

				// Active le tri en cas de clic sur le titre de colonne.
				if (oColonne.m_bTri)
				{
					var pfClick = (function ()
					{
						var nRangCreation = oColonne.m_nRangCreation;
						return function (oEvent)
						{
							oChampTable.OnTriColonne(nRangCreation, oEvent);
						};
					})();
					oTitreColonne.addEventListener("click", pfClick);
					oPositionAffichage.m_pfClick = pfClick;
				}
			}

			// GP 01/10/2015 : Ce code n'a jamais fonctionn� : le &= fait que l'on ne passe jamais a true
//			// Gestion du redimensionnement des colonnes : si une colonne a une largeur, on doit figer les colonnes
//			bColonneAvecLargeur &= (undefined !== oColonne.m_nLargeur);
		}

		// GP 01/10/2015 : Ce code n'a jamais fonctionn� : le &= fait que l'on ne passe jamais a true
//		// Si on a une colonne avec une dimension
//		if (bColonneAvecLargeur)
//		{
//			// Fixe les colonnes sans largeur (= calcule toutes les largeurs)
//			this.__FigeColonnes();
//		}
	};

	// On va changer l'ordre des colonnes, il faut lib�rer le lien entre le HTML des colonnes et le DnD
	__WDAffichageColonnes.prototype.LibereTitres = function LibereTitres()
	{
		var tabPositionAffichage = this.m_tabPositionAffichage;
		var nPositionAffichage;
		var nLimitePositionAffichage = tabPositionAffichage.length;
		for (nPositionAffichage = 0; nPositionAffichage < nLimitePositionAffichage; nPositionAffichage++)
		{
			var oPositionAffichage = tabPositionAffichage[nPositionAffichage];
			var oTitreColonne = oPositionAffichage.m_oTitreColonne;
			// GP 13/11/2013 : QW238193 : Seulement si le titre existe
			if (oTitreColonne)
			{
				var pfClick = oPositionAffichage.m_pfClick;
				if (pfClick)
				{
					oTitreColonne.removeEventListener("click", pfClick);
				}
				oPositionAffichage.m_pfClick = undefined;
				oPositionAffichage.m_oDeplace._LibereElement(oTitreColonne);
			}
		}
	};

	// D�place une colonne (change l'ordre d'affichage)
	__WDAffichageColonnes.prototype.DeplaceColonne = function DeplaceColonne(oColonne, nPositionAffichageNew)
	{
		// Si la colonne n'est pas d�placable, on ne fait rien (en code serveur on ne lance pas d'erreur)
		if (!oColonne.bColonneDeplace())
		{
			return;
		}

		// Trouve la position actuelle de la colonne
		var nPositionAffichageOld = oColonne.m_nPositionAffichage;

		// Uniquement si on d�place effectivement la colonne
		if (nPositionAffichageNew != nPositionAffichageOld)
		{
			var tabPositionAffichage = this.m_tabPositionAffichage;
			// D�place les informations sur la colonne dans le tableau ([0] car splice retourne un tableau (de un �l�ment dans le cas pr�sent)).
			// L'objet d�plac� contient aussi les informations de largeur de colonne !!!
			var oColonneInformation = tabPositionAffichage.splice(nPositionAffichageOld, 1)[0];
			tabPositionAffichage.splice(nPositionAffichageNew, 0, oColonneInformation);
			// N'oublie pas d'indiquer � la colonne sa nouvelle position
			oColonneInformation.m_oColonne.m_nPositionAffichage = nPositionAffichageNew;

			// Resynchronise les m_nPositionAffichage
			var nPositionAffichage;
			if (nPositionAffichageOld < nPositionAffichageNew)
			{
				for (nPositionAffichage = nPositionAffichageOld; nPositionAffichage < nPositionAffichageNew; nPositionAffichage++)
				{
					tabPositionAffichage[nPositionAffichage].m_oColonne.m_nPositionAffichage--;
				}
			}
			else
			{
				for (nPositionAffichage = nPositionAffichageNew + 1; nPositionAffichage <= nPositionAffichageOld; nPositionAffichage++)
				{
					tabPositionAffichage[nPositionAffichage].m_oColonne.m_nPositionAffichage++;
				}
			}

			// Redessine la table et indiquant de conserver le scroll et de redessiner les titres de colonnes
			this.m_oChampTable.ChangeOrdreColonne(true, oColonne);
		}
	};

	// Trouve une position d'affichage valide (= trouve la colonne suivante ou pr�cedente (selon le pas) qui est valide et affich�e
	__WDAffichageColonnes.prototype.nGetPositionAffichageValide = function nGetPositionAffichageValide(nPositionAffichage, nPas)
	{
		var tabPositionAffichage = this.m_tabPositionAffichage;
		var nPositionAffichageLimite = tabPositionAffichage.length;
		for (; (0 <= nPositionAffichage) && (nPositionAffichage < nPositionAffichageLimite); nPositionAffichage += nPas)
		{
			// On ne teste pas si on peut placer a gauche ou a droite de la colonne, c'est d�j� fait avant (test� dans _vnGetOperationSurDrop)
			if (tabPositionAffichage[nPositionAffichage].m_oColonne.bGetVisible())
			{
				return nPositionAffichage;
			}
		}

		// Pas d'affichage possible
		return undefined;
	};

	// Retourne la colonne si la colonne � la position d'affichage nPositionAffichage existe et est invisible
	__WDAffichageColonnes.prototype.oGetColonneInvisible = function oGetColonneInvisible(nPositionAffichage)
	{
		var tabPositionAffichage = this.m_tabPositionAffichage;
		var nPositionAffichageLimite = tabPositionAffichage.length;
		if ((0 <= nPositionAffichage) && (nPositionAffichage < nPositionAffichageLimite))
		{
			var oColonne = tabPositionAffichage[nPositionAffichage].m_oColonne;
			if (!oColonne.bGetVisible())
			{
				return oColonne;
			}
		}

		return null;
	};

	// Indique si une colonne est la derni�re colonne visible (par ordre d'affichage)
	// nColonne est le num�ro de la colonne dans l'ordre de cr�ation
	__WDAffichageColonnes.prototype.bDerniereColonneVisible = function bDerniereColonneVisible(nPositionAffichage)
	{
		var tabPositionAffichage = this.m_tabPositionAffichage;

		// Filtre aussi les colonnes ajustables (pour faire comme en code serveur)
		if (tabPositionAffichage[nPositionAffichage].m_oColonne.m_bAjustable)
		{
			return false;
		}

		var nLimitePositionAffichage = tabPositionAffichage.length;
		// Commence � la position courante : si la colonne n'est pas visible, elle n'est pas la derni�re colonne visible
		for (; nPositionAffichage < nLimitePositionAffichage; nPositionAffichage++)
		{
			// GP 21/11/2013 : QW239510
			if (tabPositionAffichage[nPositionAffichage].m_oColonne.bGetVisible())
			{
				return false;
			}
		}
		return true;
	};

	// Restaure les largeurs variables de colonnes
	__WDAffichageColonnes.prototype.ColonnesRestaure = function ColonnesRestaure()
	{
		// On n'a besoin de le faire seulement si un redimensionnement a ete effectue
		if (this.__bRedimEffectue())
		{
			// Initialise les styles
			this.m_oStyleCacheLargeur.CreationAjout();

			// Restaure la largeur des colonnes ancrables
			this.__RestaureLargeurColonnes_StyleEnCreation(this.m_tabColonnesTaille);

			// Applique les styles
			this.m_oStyleCacheLargeur.CreationFin();

			// Restaure la taille de la table
			this.m_oChampTable.m_oHote.style.width = this.m_sTableTaille;
			if (this.m_oChampTable.m_oTitrePosPixel)
			{
				this.m_oChampTable.m_oTitrePosPixel.style.width = this.m_sTableTitreTaille;
			}

			// Supprime les membres
			this.m_tabColonnesTaille = null;
			this.m_sTableTaille = null;
			this.m_sTableTitreTaille = null;
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires (tri, menu, recherche etc)
	//	__WDAffichageColonnes
	//		Impl�mentation des m�thodes de WDDrag

	// Appel lors du debut d'un click pour le redimensionnement
	// Pose les hooks
	__WDAffichageColonnes.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent, nColonne, nLargeurMinimale)
	{
		var oColonne = this.m_oChampTable._oGetColonne(nColonne);

		// Sauve la taille originale
		var nLargeur = this.m_oChampTable.oGetIDCelluleRel(0, nColonne).parentNode.offsetWidth;
		oColonne.m_nLargeur = nLargeur;

		// Appel de la classe de base : sauve la position de la souris et place les hooks
		if (!WDDrag.prototype._vbOnMouseDown.apply(this, [oEvent]))
		{
			return false;
		}

		// Si on est sur le premier redimensionnement des colonnes : memorise la taille des colonnes et fixe les largeurs
		if (!this.__bRedimEffectue())
		{
			// Initialise les styles
			this.m_oStyleCacheLargeur.CreationAjout();

			this.__ColonnesFige_StyleEnCreation();

			// GP 10/04/2018 : TB98596 : Defini la taille de la colonne, car l'appel de __ColonnesFige_StyleEnCreation peut changer la largeur effective.
			// Plus pr�cis�ment, c'est l'appel de oTitrePosPixel.style.width = "".
			this.__SetDimColonne(oColonne, nLargeur);

			// Applique les styles
			this.m_oStyleCacheLargeur.CreationFin();
		}

		// Commence par sauver la colonne
		this.m_oColonne = oColonne;
		// La largeur originale (on calcule la taille par delta)
		// GP 10/04/2018 : TB98596 : R�utilise la largeur lue initialement, car l'appel de __ColonnesFige_StyleEnCreation peut changer la largeur effective
		// Plus pr�cis�ment, c'est l'appel de oTitrePosPixel.style.width = "". En plus c'est plus optimis� (une seule lecture du DOM et evite un reflow).
		this.m_nLargeurOriginale = nLargeur;

		// Sauve la taille minimale
		this.m_nLargeurMinimale = nLargeurMinimale;

		return true;
	};

	// Appel lors du deplacement de la souris
	__WDAffichageColonnes.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
	{
		// Appel de la classe de base
		WDDrag.prototype._vOnMouseMove.apply(this, arguments);

		// Calcule la nouvelle taille des colonnes
		// ATTENTION : Si on est en affichage de droite a gauche il faut inverser le deplacement de la souris car
		// les coordonnees X sont toujours de gauche a droite
		var nNouvelleTaille = this.nGetOffsetPosX(oEvent) + this.m_nLargeurOriginale;
		if (nNouvelleTaille < 8)
		{	// Taille minimum de 8
			nNouvelleTaille = 8;
		}

		// Respecte la taille minimale
		if ((this.m_nLargeurMinimale != -1) && (nNouvelleTaille < this.m_nLargeurMinimale))
		{
			nNouvelleTaille = this.m_nLargeurMinimale;
		}

		// Calcule la nouvelle taille des colonnes
		// On respecte la taille minimale de la colonne (avec une limite inf�rieure de 8)
		// Si on n'a pas de taille minimale, this.m_nLargeurMinimale est -1, ce qui donne 8 au final
		this.m_oColonne.m_nLargeur = nNouvelleTaille;

		// Initialise les styles
		this.m_oStyleCacheLargeur.CreationAjout();

		// Defini la taille de la colonne
		this.__SetDimColonne(this.m_oColonne, nNouvelleTaille);

		// Applique les styles
		this.m_oStyleCacheLargeur.CreationFin();

		// Si on risque de devoir changer le nombre de lignes
		// GP 26/11/2013 : Seul les tables AJAX ont bMAJNbLignesVisibles
		if (this.m_oChampTable.bMAJNbLignesVisibles && this.m_oChampTable.bMAJNbLignesVisibles(true, true))
		{
			// Initialise les styles
			this.m_oStyleCacheLargeur.CreationAjout();

			// Sauve la largeur de toutes les colonnes
			var tabLargeurColonnes = this.__tabSauveLargeurColonnes_StyleEnCreation(false);

			// Applique les styles
			this.m_oStyleCacheLargeur.CreationFin();

			// Rafraichi l'ascenseur et les lignes de la table. Si le nombre de ligne change : il faut reppliquer la gestion de la largeur
			if (this.m_oChampTable.bMAJNbLignesVisibles(true, false))
			{
				// Initialise les styles
				this.m_oStyleCacheLargeur.CreationAjout();

				// Restaure la largeur des colonnes
				this.__RestaureLargeurColonnes_StyleEnCreation(tabLargeurColonnes);

				// Applique les styles
				this.m_oStyleCacheLargeur.CreationFin();
			}
		}

		// Probl�me de reflow en HTML4 avec IE
		if (bIE && !clWDUtil.bHTML5)
		{
			this.m_oChampTable.m_oHote.className += "";
			// GP 27/11/2013 : Et aussi sur le titre
			this.m_oChampTable.m_oTitrePosPixel.className += "";
		}

		// Si la colonne est une colonne image, notifie les champs images du redimensionnement
		if (WDChamp.prototype.ms_nIDObjetImage == this.m_oColonne.m_eTypeIDObjet)
		{
			// Recalcule toutes les images (car la hauteur d'une image dans la colonne modifi�e peut affecter la hauteur d'une ligne ce qui affecte les autres images de la table)
			var tabImages = clWDUtil.tabGetElementsByClass(this.m_oChampTable.m_oHote, this.m_oColonne.ms_sClasseImage);
			if (this.m_oChampTable.m_bHauteurLigneVariable)
			{
				clWDUtil.bForEach(tabImages, WDTableZRNavigateur.prototype.s_bRedimImageDebutRedimCol);
			}
			clWDUtil.bForEach(tabImages, WDTableZRNavigateur.prototype.s_bRedimImageFinRedimCol);
		}
	};

	// Appel lors du relachement de la souris
	__WDAffichageColonnes.prototype._vOnMouseUp = function _vOnMouseUp(/*oEvent*/)
	{
		// Supprime les variables d'�tat
		this.m_nLargeurMinimale = null;
		this.m_nLargeurOriginale = null;
		this.m_oColonne = null;

		// Appel de la classe de base
		WDDrag.prototype._vOnMouseUp.apply(this, arguments);
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires (tri, menu, recherche etc)
	//	WDAffichageColonnes
	//		M�thodes internes g�n�rales

	// GP 25/11/2013 : Replace le code de redimensionnement original
	// Sauve la largeurs des colonnes dans un tableau et renvoie le tableau
	// Si bProportionnel est a vrai ne sauve que les colonnes proportionnelles
	// Il FAUT avoir fait un this.m_oStyleCacheLargeur.CreationAjout() et faire un this.m_oStyleCacheLargeur.CreationFin() en sortie
	__WDAffichageColonnes.prototype.__tabSauveLargeurColonnes_StyleEnCreation = function __tabSauveLargeurColonnes_StyleEnCreation(bProportionnel)
	{
		var tabLargeurColonnes = [];

		var i = 0;
		// Recupere le DIV
		var oCelluleColonne = this.m_oChampTable.oGetIDCelluleRel(0, i);
		var nLimiteI = this.m_oChampTable._nGetNbColonnes();
		while (oCelluleColonne || (i < nLimiteI))
		{
			if (oCelluleColonne)
			{
				// Recherche le TD
				while (!clWDUtil.bBaliseEstTag(oCelluleColonne, "td"))
				{
					oCelluleColonne = oCelluleColonne.parentNode;
				}

				// Si la colonne est invisible : ne sauve pas sa valeur : elle ne sera pas manipuler
				var oStyleCelluleColonne = clWDUtil.oGetCurrentStyle(oCelluleColonne);
				var sVisibility = oStyleCelluleColonne.visibility;
				if (((sVisibility == "visible") || (sVisibility == "inherit")) && (oStyleCelluleColonne.display != "none"))
				{
					// Lit la taille si demande
					if (((clWDUtil.oGetCurrentStyle(oCelluleColonne).width + "").indexOf("%") != -1) || !bProportionnel)
					{
						var nOffsetWidth = oCelluleColonne.offsetWidth;
						// Si on est pas en "quirks mode", il faut tenir compte des bordure du parent
						if (!bIEQuirks)
						{
							nOffsetWidth -= WDChamp.prototype.s_nGetOffsetBorderPourWidth(oStyleCelluleColonne);
						}
						// Stocke la valeur proportionnelle dans le cas proportionnel
						if (bProportionnel)
						{
							tabLargeurColonnes[i] = clWDUtil.oGetCurrentStyle(oCelluleColonne).width;
							this.__SetDimColonne(this.m_oChampTable._oGetColonne(i), nOffsetWidth);
						}
						else
						{	// Sinon stocke la vrai valeur
							tabLargeurColonnes[i] = nOffsetWidth;
						}
					}
				}
			}

			// Passe a la colonne suivante
			i++;
			oCelluleColonne = this.m_oChampTable.oGetIDCelluleRel(0, i);
		}

		// Renvoi le tableau forme
		return tabLargeurColonnes;
	};

	// Restaure la largeurs des colonnes depuis le tableau donne
	// Il FAUT avoir fait un this.m_oStyleCacheLargeur.CreationAjout() et faire un this.m_oStyleCacheLargeur.CreationFin() en sortie
	__WDAffichageColonnes.prototype.__RestaureLargeurColonnes_StyleEnCreation = function __RestaureLargeurColonnes_StyleEnCreation(tabLargeurColonnes)
	{
		// Restaure les colonnes
		var i;
		var nLimiteI = tabLargeurColonnes.length;
		for (i = 0; i < nLimiteI; i++)
		{
			if (tabLargeurColonnes[i] !== undefined)
			{
				// Restaure la taille de la colonne
				this.__SetDimColonne(this.m_oChampTable._oGetColonne(i), tabLargeurColonnes[i]);
			}
		}
	};

	// Indique s'il y a eu un redimensionnement
	__WDAffichageColonnes.prototype.__bRedimEffectue = function __bRedimEffectue()
	{
		return !!this.m_tabColonnesTaille;
	};

	// Si on est sur le premier redimensionnement des colonnes : memorise la taille des colonnes et fixe les largeurs
	// Il FAUT avoir fait un this.m_oStyleCacheLargeur.CreationAjout() et faire un this.m_oStyleCacheLargeur.CreationFin() en sortie
	__WDAffichageColonnes.prototype.__ColonnesFige_StyleEnCreation = function __ColonnesFige_StyleEnCreation()
	{
		var oHote = this.m_oChampTable.m_oHote;
		var oTitrePosPixel = this.m_oChampTable.m_oTitrePosPixel;

		// GP 04/02/2014 : QW242234 : Le style est toujours inline. Et ici oavec Chrome on a la taille calcul�e ce qui bloque ensuite les ancrages.
//		this.m_sTableTaille = clWDUtil.oGetCurrentStyle(oHote).width;
//		this.m_sTableTitreTaille = clWDUtil.oGetCurrentStyle(oTitrePosPixel).width;
		this.m_sTableTaille = oHote.style.width;
		// GP 11/02/2014 : QW242532 : oTitrePosPixel n'esiste pas dans les tables sans limites
		if (oTitrePosPixel)
		{
			this.m_sTableTitreTaille = oTitrePosPixel.style.width;
		}

		// Detecte les colonnes ancrees et memorise leur pourcentage d'ancrage
		this.m_tabColonnesTaille = this.__tabSauveLargeurColonnes_StyleEnCreation(true);

		// Supprime la taille de la table parent
		oHote.style.width = "";
		if (oTitrePosPixel)
		{
			oTitrePosPixel.style.width = "";
		}
		if (!clWDUtil.bHTML5)
		{
			if (oHote.width && ("" !== oHote.width))
			{
				oHote.width = "";
			}
			if (oHote.parentNode.style.width && ("" !== oHote.parentNode.style.width))
			{
				oHote.parentNode.style.width = "";
			}
			if (oTitrePosPixel && oTitrePosPixel.width && ("" !== oTitrePosPixel.width))
			{
				oTitrePosPixel.width = "";
			}
		}
	};

	// Defini la taille de toute une colonne
	__WDAffichageColonnes.prototype.__SetDimColonne = function __SetDimColonne(oColonne, sNouvelleTaille)
	{
		var sSuffixeStyle;
		if (-1 !== (sNouvelleTaille + "").indexOf("%"))
		{
			sSuffixeStyle = "";
		}
		else
		{
			sSuffixeStyle = "px";
		}

		// GP 26/11/2013 : Utilise Ajoute et pas Complete pour remplacer le style existant (sinon on se retrouve avec un style qui contient plein de "width:")
		this.m_oStyleCacheLargeur.Ajoute(this.m_sPrefixe + oColonne.m_sAlias, ["width:" + sNouvelleTaille + sSuffixeStyle, "min-width:auto"]);
	};

	return __WDAffichageColonnes;
})();

//////////////////////////////////////////////////////////////////////////
// Classe commune pour les tables/ZRs classiques/AJAXs mais pas navigateur.
var WDTableZRCommun = (function ()
{
	function __WDTableZRCommun()
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			/*WDChampParametresHote*/WDChamp.prototype.constructor.apply(this, arguments);
		}
	}

	// Declare l'heritage
	__WDTableZRCommun.prototype = new /*WDChampParametresHote*/WDChamp();
	// Surcharge le constructeur qui a ete efface
	__WDTableZRCommun.prototype.constructor = __WDTableZRCommun;

		// Factorisation de code avec WDZRNavigateur.
	__WDTableZRCommun.prototype.s_tabGetStyles = function s_tabGetStyles(tabStylesBruts)
	{
		// Note : ici est une bonne utilisation de Array.map mais pas dispo en HTML4...
		var tabStyles = [];
		clWDUtil.bForEach(tabStylesBruts, function (sUnStyleBrut)
		{
			tabStyles.push(clWDUtil.tabSplitClasses(sUnStyleBrut));
			return true;
		});
		return tabStyles;
	};

	// Factorisation de code avec WDZRNavigateur.
	__WDTableZRCommun.prototype.s_SetStyleSelonSelection = function s_SetStyleSelonSelection(oThis, tabStyles, nLigneAbsolueBase1, bSelection)
	{
		function __ActiveDesactivesClasses(oElement, tabClasses, bActive)
		{
			clWDUtil.bForEach(tabClasses, function (sClasse)
			{
				clWDUtil.ActiveDesactiveClassName(oElement, sClasse, bActive);
				return true;
			});
		}
		function __oGetLigne(nLigneAbsolueBase1)
		{
			var oLigne = oThis.oGetIDElement(nLigneAbsolueBase1);
			// Deux cas :
			// - Nombre de colonnes fixe : on obtient un div et on demande le td parent.
			// - Nombre de colonnes variable : on obtient un table et il faut se placer sur le premier td.
			var oCellule;
			if (clWDUtil.bBaliseEstTag(oLigne, "table"))
			{
				oCellule = oLigne.getElementsByTagName("td")[0];
			}
			else if (clWDUtil.bBaliseEstTag(oLigne, "div"))
			{
				oCellule = oLigne.parentNode;
			}
			if (clWDUtil.bBaliseEstTag(oCellule, "td"))
			{
				return oCellule;
			}
			return null;
		}

		var oLigne = __oGetLigne(nLigneAbsolueBase1);
		if (oLigne)
		{
			if (bSelection)
			{
				__ActiveDesactivesClasses(oLigne, tabStyles[2], true);
			}
			else
			{
				__ActiveDesactivesClasses(oLigne, tabStyles[2], false);
				// Et on r�active les classe de la ligne paire/impare (qui peut avoir une partie commune avec le style de ligne s�lectionn�.
				// Style 0 = impaire, 1 = paire.
				__ActiveDesactivesClasses(oLigne, tabStyles[(nLigneAbsolueBase1 - 1) % 2], true);
			}
		}
	};

	// Pour la fonction WL TableInfoXY
	__WDTableZRCommun.prototype.InfoXY = function InfoXY(eInfo, nX, nY)
	{
		// On a besoin de la racine de la table.
		var oRacine = _JGE(this.m_sAliasChamp, document, true, false);
		if (!oRacine)
		{
			return -1;
		}

		// Document.elementFromPoint attend des coordonn�es selon le viewport.
		var oBoundingClientRect = oRacine.getBoundingClientRect();
		var dXViewport = oBoundingClientRect.x + Number(nX);
		var dYViewport = oBoundingClientRect.y + Number(nY);

		var oDocument = oRacine.ownerDocument;
		var tabElements;
		// On doit traiter le cas de IE :https://developer.mozilla.org/en-US/docs/Web/API/Document/elementsFromPoint
		if (bIE)
		{
			// On doit avoir getElementsFromPoint (normalement disponible depuis IE10) <= v�rifi� � la compilation qui interdit le mode HTML4.
			tabElements = oDocument.msElementsFromPoint(dXViewport, dYViewport);
			// Peut retourner null
			if (null === tabElements)
			{
				return -1;
			}
		}
		else
		{
			tabElements = oDocument.elementsFromPoint(dXViewport, dYViewport);
		}

		// Trouve les informations et calcule le r�sultat.
		var oLigneColonne = this._xvoGetInfoXY(oRacine, tabElements);
		switch (Number(eInfo))
		{
		case 1:
			// tiNumLigne
			return oLigneColonne.nLigne;
		case 2:
			// tiNumColonne
			return oLigneColonne.nColonne;
		default:
			// Erreur fatale WL :
			// "La valeur de la constante (%1) est invalide avec cette fonction.",
			throw new WDErreur(303, eInfo);
		}
	};

	// R�cup�re un parseur pour les ids de ligne.
	__WDTableZRCommun.prototype._pfGetParseurIdLigne = function _pfGetParseurIdLigne(sBaliseAttendue)
	{
		var oRegExp = new RegExp("^" + this.m_sAliasChamp + "_(\\d+)$");
		return function (oElement)
		{
			if (clWDUtil.bBaliseEstTag(oElement, sBaliseAttendue))
			{
				var oRes = oRegExp.exec(oElement.id);
				if ((oRes) && (2 === oRes.length))
				{
					// GP 29/09/2021 : QW444956 : En fait dans le cas des tables AJAX, les indices sont C avec un offset.
					var nLigneIndice = Number(oRes[1]);
					if (!isNaN(nLigneIndice))
					{
						return nLigneIndice;
					}
				}
			}

			return undefined;
		};
	};
	// R�cup�re le parseur pour ruptures.
	__WDTableZRCommun.prototype._pfGetParseurRupture = function _pfGetParseurRupture()
	{
		var oRegExp = new RegExp("^" + this.m_sAliasChamp + "-[HB]-\\d+-(\\d+)$");
		return function (oElement)
		{
			var oRes = oRegExp.exec(oElement.id);
			if ((oRes) && (2 === oRes.length))
			{
				// GP 29/09/2021 : QW444956 : En fait dans le cas des tables AJAX, les indices sont C avec un offset.
				var nLigneIndice = Number(oRes[1]);
				if (!isNaN(nLigneIndice))
				{
					return nLigneIndice;
				}
			}

			return undefined;
		};
	};

	// M�thode � impl�menter dans les classes d�riv�es.
	// R�cup�re les informations pour InfoXY.
	// protected abstract _xvoGetInfoXY (oExterne : Element, tabElements : Element[]) : { nLigne : number, nColonne : number }

	return __WDTableZRCommun;
})();

WDTableZRNavigateur.prototype.InfoXY = WDTableZRCommun.prototype.InfoXY;
WDTableZRNavigateur.prototype._pfGetParseurIdLigne = WDTableZRCommun.prototype._pfGetParseurIdLigne;
WDTableZRNavigateur.prototype._pfGetParseurRupture = WDTableZRCommun.prototype._pfGetParseurRupture;

//////////////////////////////////////////////////////////////////////////
// Classe commune pour les tables/ZRs classiques.
var WDTableZRClassique = (function ()
{
	// La table n'a normalement jamais de table/zr parente
	function __WDTableZRClassique(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDTableZRCommun.prototype.constructor.apply(this, arguments);

			var tabStylesBruts = tabParametresSupplementaires[0];

			// On pr�pare les styles sous forme d'un tableau de cha�nes.
			this.m_tabStyles = this.s_tabGetStyles(tabStylesBruts);

			// Non : car on n'impl�mente pas ce qu'il faut comme table/ZR
//			// Se declare dans la table globale des Tables/ZRs AJAX
//			this.ms_tabTablesZRs.DeclareChamp(this);
		}
	}

	// Declare l'heritage
	__WDTableZRClassique.prototype = new WDTableZRCommun();
	// Surcharge le constructeur qui a ete efface
	__WDTableZRClassique.prototype.constructor = __WDTableZRClassique;

	// Click sur une ligne de zone repetee
	__WDTableZRClassique.prototype.OnSelectLigne = function OnSelectLigne(nSelectionNouvelleAbsolueBase1, nColonne, oEvent)
	{
		// Pas d'appel de la casse de base.

		if (!this.m_oChampFormulaire)
		{
			return;
		}

		// Trouve la s�lection pr�c�dente.
		var nSelectionPrecedenteAbsolueBase1 = parseInt(this.m_oChampFormulaire.value, 10);
		// Si la s�lection ne change pas, ne fait rien.
		if (nSelectionPrecedenteAbsolueBase1 === nSelectionNouvelleAbsolueBase1)
		{
			return;
		}

		// Supprime le style de l'ancienne s�lection.
		this.s_SetStyleSelonSelection(this, this.m_tabStyles, nSelectionPrecedenteAbsolueBase1, false);
		// Applique le style de la nouvelle s�lection.
		this.s_SetStyleSelonSelection(this, this.m_tabStyles, nSelectionNouvelleAbsolueBase1, true);

		// M�morise la nouvelle s�lection.
		this.m_oChampFormulaire.value = nSelectionNouvelleAbsolueBase1;

		// GP 28/04/2021 : QW337223 : Ex�cute le PCode de s�lection (apr�s avoir mis la nouvelle valeur dans le champ formulaire).
		this.RecuperePCode(this.ms_nEventNavSelectLigne)(oEvent);
	};

	return __WDTableZRClassique;
})();

//////////////////////////////////////////////////////////////////////////
// Classe pour les tables classiques.
var WDTableClassique = (function ()
{
	function __WDTableClassique()
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDTableZRClassique.prototype.constructor.apply(this, arguments);
		}
	}

	// Declare l'heritage
	__WDTableClassique.prototype = new WDTableZRClassique();
	// Surcharge le constructeur qui a ete efface
	__WDTableClassique.prototype.constructor = __WDTableClassique;

	// R�cup�re les informations pour InfoXY.
	__WDTableClassique.prototype._xvoGetInfoXY = function _xvoGetInfoXY(oExterne /*: Element*/, tabElements /*: Element[]*/) /*: { nLigne : number, nColonne : number }*/
	{
		var oResultat = { nLigne : -1, nColonne : -1 };

		var pfParseurIdLigne = this._pfGetParseurIdLigne("tr");
		var pfParseurRupture = this._pfGetParseurRupture();
		clWDUtil.bForEach(tabElements, function (oElement)
		{
			// La recherche ne retourne pas les tr, on doit donc partir du td.
			if (clWDUtil.bBaliseEstTag(oElement, "td"))
			{
				// Le num�ro de la ligne est dans l'id du tr parent.
				var oLigne = oElement.parentNode;
				// GP 29/09/2021 : QW444956 : En fait dans le cas des tables AJAX, les indices sont C avec un offset.
				var nLigneIndice = pfParseurIdLigne(oLigne);
				// Donc 0 est possible, il faut tester explictement le cas undefined.
				if (undefined !== nLigneIndice)
				{
					oResultat.nLigne = nLigneIndice;

					// On ne veux pas les nodes, on veux les element : utilise "children"
					var nColonne = 1;
					if (false == clWDUtil.bForEach(oLigne.children, function (oFils)
					{
						if (oFils === oElement)
						{
							oResultat.nColonne = nColonne;
							// Inutile de recherche plus, on a colonne et ligne.
							return false;
						}
						// Ignore les colonnes de s�paration (les tables navigateur partagent le code)
						if (clWDUtil.bBaliseEstTag(oFils, "td") && !clWDUtil.bAvecClasse(oFils, "wbtablesep"))
						{
							nColonne++;
						}
						return true;
					}))
					{
						return false;
					}
				}
			}

			// GP 29/09/2021 : QW444956 : En fait dans le cas des tables AJAX, les indices sont C avec un offset.
			var nLigneIndiceSelonRupture = pfParseurRupture(oElement);
			// Donc 0 est possible, il faut tester explictement le cas undefined.
			if (undefined !== nLigneIndiceSelonRupture)
			{
				oResultat.nLigne = nLigneIndiceSelonRupture;
				oResultat.nColonne = -1;
				return false;
			}

			return true;
		});

		return oResultat;
	};

	return __WDTableClassique;
})();

//////////////////////////////////////////////////////////////////////////
// Classe pour les ZR classiques.
var WDZRClassique = (function ()
{
	function __WDZRClassique()
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDTableZRClassique.prototype.constructor.apply(this, arguments);
		}
	}

	// Declare l'heritage
	__WDZRClassique.prototype = new WDTableZRClassique();
	// Surcharge le constructeur qui a ete efface
	__WDZRClassique.prototype.constructor = __WDZRClassique;

	// Indique que le champ est une ZR 
	__WDZRClassique.prototype.vbZR = function vbZR()
	{
		return true;
	};

	// R�cup�re les informations pour InfoXY.
	__WDZRClassique.prototype._xvoGetInfoXY = function _xvoGetInfoXY(oExterne /*: Element*/, tabElements /*: Element[]*/) /*: { nLigne : number, nColonne : number }*/
	{
		var oResultat = { nLigne : -1, nColonne : -1 };

		var pfParseurIdLigne = this._pfGetParseurIdLigne("div");
		var pfParseurRupture = this._pfGetParseurRupture();
		clWDUtil.bForEach(tabElements, function (oElement)
		{
			// Le num�ro de la ligne est dans l'id d'un div.
			// GP 29/09/2021 : QW444956 : En fait dans le cas des tables AJAX, les indices sont C avec un offset.
			var nLigneIndice = pfParseurIdLigne(oElement);
			// Donc 0 est possible, il faut tester explictement le cas undefined.
			if (undefined !== nLigneIndice)
			{
				oResultat.nLigne = nLigneIndice;
				oResultat.nColonne = -1;
				return false;
			}

			// GP 29/09/2021 : QW444956 : En fait dans le cas des tables AJAX, les indices sont C avec un offset.
			var nLigneIndiceSelonRupture = pfParseurRupture(oElement);
			// Donc 0 est possible, il faut tester explictement le cas undefined.
			if (undefined !== nLigneIndiceSelonRupture)
			{
				oResultat.nLigne = nLigneIndiceSelonRupture;
				oResultat.nColonne = -1;
				return false;
			}

			return true;
		});

		return oResultat;
	};

	return __WDZRClassique;
})();
