// __WDTdb.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - La page
///#GLOBALS _PAGE_
// - StdAction.js
///#GLOBALS _JSL _JGE
// - WDUtil.js
///#GLOBALS bIE bIEQuirks nIE bIEAvec11 bTouch WDStyleCache AppelMethode
// - WDChamp.js
///#GLOBALS WDChamp WDChampParametresHote WDMenuContextuel
// - WDDrag.js
///#GLOBALS WDDrag WDDnDNatif WDDragDnDNatifEmule
// - WD.js
///#GLOBALS NSPCS
// - WWConstanteX.js
///#GLOBALS TDB_MENU
// - Autres
///#GLOBALS $

//////////////////////////////////////////////////////////////////////////
// Manipulation d'un champ tableau de bord
var WDTdb = (function ()
{
	function __WDTdb(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChampParametresHote.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParametres, oDonnees, eAncrageVertical ]

			// Cache du style de la largeur des colonnes
			var oStyleCacheDimension = new WDStyleCache(true);
			oStyleCacheDimension.Creation();
			oStyleCacheDimension.CreationFin();
			this.m_oStyleCacheDimension = oStyleCacheDimension;

			// Pas en mode �dition
			this.m_oTdbModeEdition = null;
			// Pas encore de cache des Widgets
			this.m_tabCacheDivWidget = [];

			// 0 : Pas d'ancrage
			// 1 : Ancrage au navigateur
			// 2 : Ancrage au contenu
			this.m_eAncrageHauteur = tabParametresSupplementaires[2];

			// S'abonne � la notification de changement de tranche (dans le framework V2)
			// => Temporaire : dans le framework v2, les champs recoivent la notification par vOnChangementTranche
			// GP 08/11/2016 : QW279635 : Si la page est RWD, on inclus syst�matiquement le framework V2. Donc plus besoin de tester NSPCS.
			if (clWDUtil.bRWD)
			{
				var oThis = this;
				NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(function ()
				{
					oThis.vOnChangementTranche.apply(oThis, arguments);
				});
			}
		}
	}

	// Declare l'heritage
	__WDTdb.prototype = new WDChampParametresHote();
	// Surcharge le constructeur qui a ete efface
	__WDTdb.prototype.constructor = __WDTdb;

	//////////////////////////////////////////////////////////////////////////
	// Membres statiques
	var ms_sClasseBase = "WDTDB-Base";
	var ms_sClasseWidget = "WDTDB-Widget";
	var ms_sClasseMasque = "WDTDB-Masque";
	var ms_sClasseLigne = "WDTDB-Ligne";
	var ms_sClasseColonne = "WDTDB-Colonne";
	var ms_sClasseLargeur = "WDTDB-Largeur";
	var ms_sClasseHauteur = "WDTDB-Hauteur";

	// Commandes pour les champs tableau de bord
	var ms_sActionAjoute = "TDBAJO";
	var ms_sActionSupprime = "TDBSUP";
	var ms_sActionDeplace = "TDBDEP";
	var ms_sActionRedimensionne = "TDBRED";
	var ms_sActionConfigInitiale = "TDBCI";

	// Option de l'�dition
	var ms_nDeplace = 1;
	var ms_nSupprime = 2;
	var ms_nRedimensionne = 4;

	// La correspondance entre les propri�t�s d'un widget et les propri�t�s par tranche d'un widget
	var ms_tabCorrespondanceProprietesTranches = [
		["m_bVisible", "m_tabVisible"],
		["m_nLigne", "m_tabLigne"],
		["m_nColonne", "m_tabColonne"],
		["m_nLargeur", "m_tabLargeur"],
		["m_nHauteur", "m_tabHauteur"]
	];

	//////////////////////////////////////////////////////////////////////////
	// __WDTdb
	//	M�thodes surcharg�es
	//		WDChamp

	// Initialisation
	__WDTdb.prototype.Init = function Init()
	{
		// Appel de la methode de la classe de base
		WDChampParametresHote.prototype.Init.apply(this, arguments);

		// Appel explicite de _vAppliqueParametres car celui ci n'est en fait fait que en cas de modification (en AJAX) des param�tre et pas a l'init.
		this._vAppliqueParametres();

		// Affichage du champ (filtre sur la visibilit� du champ)
		this.__Affiche(true);
	};

	//// Methode d'initialisation generale de la classe (ne s'execute que lors de l'init de la premi�re instance de ce type)
	//__WDTdb.prototype._vInitInitiale = function _vInitInitiale()
	//{
	//	// Appel de la methode de la classe de base
	//	WDChampParametresHote.prototype._vInitInitiale.apply(this, arguments);
	//
	//...
	//
	//	// S'auto efface pour ne plus etre appele
	//	__WDTdb.prototype._vInitInitiale = clWDUtil.m_pfVide;
	//};

	// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
	__WDTdb.prototype.OnDisplay = function OnDisplay(oElementRacine, bAffiche)
	{
		// Appel de la methode de la classe de base
		WDChampParametresHote.prototype.OnDisplay.apply(this, arguments);

		// GP 27/04/1981 : Demande de GF (vu avec QW#286237) : OPTIM : On ne fait pas les ancrages si on n'est pas fils de l'�l�ment affich�.
		if (bAffiche && this.m_oHote && clWDUtil.bEstFils(this.m_oHote, oElementRacine))
		{
			// GP 10/09/2015 : TB93990 : Si on est ancr� en hauteur, il faut l'�muler lors du premier affichage
			this.__AncrageEnHauteur(true);

			// R�affichage du champ (filtre sur la visibilit� du champ)
			this.__Affiche(true);
		}
	};

	// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
	__WDTdb.prototype._vOnResize = function _vOnResize(/*oEvent*/)
	{
		// Appel de la methode de la classe de base
		WDChampParametresHote.prototype._vOnResize.apply(this, arguments);

		// _vOnResize est filtr� pour les plan non affich�s mais pas si on est display : none.
		// GP 25/04/2018 : TB105846 : Le code d'ancrage ne fonctionne pas tr�s bien avec IE dans le cas display : none (oParent.offsetParent retourne null dans ce cas).
		// Si on est pas affich�, il est inutile de faire quoi que ce soit.
		if (this.m_oHote && clWDUtil.bEstDisplay(this.m_oHote, document, false))
		{
			// GP 30/10/2014 : QW247911 : Si on est ancr� en hauteur : il faut l'�muler
			this.__AncrageEnHauteur(true);

			// R�affichage du champ (filtre sur la visibilit� du champ)
			this.__Affiche(true);
		}
	};

	//// Pour implementer ConstruitParam (accepte des parametres variables)
	//__WDTdb.prototype._vsConstruitParam = function _vsConstruitParam()
	//{
	//	var tabParam = [];
	//
	//	...
	//
	//	return tabParam.join(',');
	//};

	// Trouve les divers elements : liaison avec le HTML
	__WDTdb.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
	{
		// Appel de la methode de la classe de base
		WDChampParametresHote.prototype._vLiaisonHTML.apply(this, arguments);

		// GP 04/09/2014 : Ajout� maintenant par la g�n�ration HTML
//		// Ajoute le positionnement relatif pas ajout� par la g�n�ration HTML
//		if (this.m_oHote)
//		{
//			this.m_oHote.style.position = "relative";
//		}

		// Trouve le bouton s'il existe
		// Si on a m_sBoutonMenuAlias c'est que l'on a un bouton
		if (this.m_oParametres.m_sBoutonMenuAlias)
		{
			this.m_oBoutonMenu = _JGE(this.m_oParametres.m_sBoutonMenuAlias, document, true);
		}

		// R�cup�re les �l�ments pour le mode �dition
		this.m_oModeleModeEdition = this.oGetIDElement("ME");
		this.m_oModeleModeEditionVide = this.oGetIDElement("MEV");
		// Masque les divs utilis�s pour le mode �dition
		clWDUtil.SetDisplay(this.m_oModeleModeEdition, false);
		clWDUtil.SetDisplay(this.m_oModeleModeEditionVide, false);

		// GP 10/09/2015 : TB93990 : Si on est ancr� en hauteur, il faut l'�muler lors du premier affichage
		// => Calcul d�cal� dans __AncrageEnHauteur
		this.__AncrageEnHauteur(false);

		// Construit le cache des Widget s'il n'existe pas encore
		var tabCacheDivWidget = this.m_tabCacheDivWidget;
		if (!tabCacheDivWidget.length)
		{
			var oThis = this;
			clWDUtil.bForEach(this.m_oDonnees.m_tabConfigCourante, function (oWidget, nWidget)
			{
				var oDiv = oThis.oGetIDElement(nWidget + 1);
				tabCacheDivWidget[nWidget] =
					{
						m_oDiv: oDiv,
						m_sClasses: (oDiv ? oDiv.className : "")
					};
				return true;
			});
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// __WDTdb
	//	M�thodes surcharg�es
	//		WDChampParametres

	//// Fusionne les donnes
	//__WDTdb.prototype._voFusionneDonne = function _voFusionneDonne(oDonnees)
	//{
	//	WDChampParametresHote.prototype._voFusionneDonne.apply(this, arguments);
	//
	//	...
	//};

	//////////////////////////////////////////////////////////////////////////
	// __WDTdb
	//	M�thodes surcharg�es
	//		WDChampParametresHote

	// Applique les parametres
	__WDTdb.prototype._vAppliqueParametres = function _vAppliqueParametres(/*oParametreFusion*/)
	{
		// Appel de la methode de la classe de base
		WDChampParametresHote.prototype._vAppliqueParametres.apply(this, arguments);

		// M�thode la configuration courante (et pas la configuration initiale) pour le cas du changement de tranche en responsible
		if (clWDUtil.bRWD)
		{
			this.m_tabConfigCouranteRecue = __s_tabDupliqueConfiguration(this.m_oDonnees.m_tabConfigCourante);
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// __WDTdb
	//		M�thodes internes g�n�rales

	// Donne le nombre de colonnes
	__WDTdb.prototype.__nGetNbColonnes = function __nGetNbColonnes()
	{
		// Trouve la tranche
		// Si on est en response web design on a toujours JQuery et toujours les extensions WB
		var nTrancheIndiceWL = clWDUtil.bRWD ? $.wb.nGetTrancheActiveIndiceWL(true) : 1;
		return this.__nGetNbColonnesSelonTranche(nTrancheIndiceWL);
	};
	__WDTdb.prototype.__nGetNbColonnesSelonTranche = function __nGetNbColonnesSelonTranche(nTrancheDepuisDefautBase1)
	{
		// Si on a les informations par tranche
		var oParametres = this.m_oParametres;
		if (oParametres)
		{
			if (oParametres.m_tabNbColonnes)
			{
				var nNbColonnes = oParametres.m_tabNbColonnes[nTrancheDepuisDefautBase1 - 1];
				if (undefined !== nNbColonnes)
				{
					return nNbColonnes;
				}
			}
			return oParametres.m_nNbColonnes;
		}
		return 1;
	};

	// Changement de tranche
	__WDTdb.prototype.vOnChangementTranche = function vOnChangementTranche(oEvent, nTrancheDepuisDefautBase1)
	{
		// G�re un nombre de colonne dynamique si :
		// - On n'est pas dans le mode avec nombre de colonne variable (tout est alors trait� dans le resize + on ne d�place pas de force des �l�ments)
		// - On a des informations de nombre de colonnes par tranches
		// - On a des informations de nombre de colonnes pour cette tranche
		// - Le nombre de colonne change par rapport au nombre pr�c�dent
		if ((1 != this.m_oParametres.m_eMiseEnPage) && (undefined !== this.m_nNbColonnesEffectif))
		{
			var nNbColonnes = this.__nGetNbColonnesSelonTranche(nTrancheDepuisDefautBase1);
			if (nNbColonnes != this.m_nNbColonnesEffectif)
			{
				// Force une MAJ
				this.__Affiche(true);
			}
		}
	};

	// Applique l'ancrage en hauteur
	__WDTdb.prototype.__AncrageEnHauteur = function __AncrageEnHauteur(bPourResize)
	{
		// 0 : Pas d'ancrage
		// 1 : Ancrage au navigateur
		// 2 : Ancrage au contenu
		if (1 == this.m_eAncrageHauteur)
		{
			// Si on est pour un resize : se masque
			if (bPourResize)
			{
				clWDUtil.SetDisplay(this.m_oHote, false);
			}
			// Calcule la hauteur du parent et se l'applique
			var oParent = this.m_oHote.parentNode;
			var nHauteur = oParent.clientHeight;
			// GP 30/10/2014 : Dans IE notre parent n'a pas forc�ment la taille
			if ((0 == nHauteur) && bIEAvec11 && !bIEQuirks)
			{
				// Le parent est un td
				clWDUtil.WDDebug.assert(clWDUtil.bBaliseEstTag(oParent, "td"), "clWDUtil.bBaliseEstTag(oParent, \"td\")");
				// Qui est dans une table qui a la bordure et autre �ventuelle
				var oParentTable = oParent.offsetParent;
				clWDUtil.WDDebug.assert(clWDUtil.bBaliseEstTag(oParentTable, "table"), "clWDUtil.bBaliseEstTag(oParentTable, \"table\")");
				// Qui est dans un td
				// GP 12/11/2014 : Parfois on a des div entre les deux. Donc le offsetParent ne fonctionne pas
				var oParentTd = oParentTable.offsetParent;
				var oBody = document.body;
				while (oParentTd && (oParentTd != oBody) && !clWDUtil.bBaliseEstTag(oParentTd, "td"))
				{
					oParentTd = oParentTd.parentNode;
				}
				clWDUtil.WDDebug.assert(clWDUtil.bBaliseEstTag(oParentTd, "td"), "clWDUtil.bBaliseEstTag(oParentTd, \"td\")");
				// GP 10/11/2015 : TB95057 : getBoundingClientRect().height/width n'existe pas dans IE8-.
				// Utilisation du calcul par (bottom - top)
				var oDimensions = oParentTable.getBoundingClientRect();
				nHauteur = oParentTd.clientHeight - (oDimensions.bottom - oDimensions.top);
			}
			// GP 16/11/2015 : TB95057 : Ajout d'un second check
			if (0 < nHauteur)
			{
				this.m_oHote.style.height = nHauteur + "px";
			}
			if (bPourResize)
			{
				clWDUtil.SetDisplay(this.m_oHote, true);
			}
		}
	};

	// Affichage/r�affichage g�n�ral du champ (filtre si le champ est visible)
	__WDTdb.prototype.__Affiche = function __Affiche(bReaffiche)
	{
		// Affichage du champ si il est visible
		if (this.m_oHote && clWDUtil.bEstDisplay(this.m_oHote, document, true))
		{
			this.__AfficheInterne(bReaffiche);
		}
	};

	// Affichage/r�affichage g�n�ral du champ
	__WDTdb.prototype.__AfficheInterne = function __AfficheInterne(bReaffiche)
	{
		// Pr�paration/Mise � jour du positionnement : recalcule les dimensions et calcule les classes CSS pour le positionnement
		// R�organise le dessin si les options le demande (nombre de colonnes variable, position invalide, compactage)
		bReaffiche |= this.__bCalculeOrganisation();

		// Affiche le contenu selon l'organisation calcul�e
		if (bReaffiche)
		{
			this.__AfficheContenu();

			// Ici applique les ancrages.
			// Note : on n'est pas int�gr� avec le reste du produit : bug possible (mais c'est mieux que pas de dimension).
			// 0 : Pas d'ancrage
			// 1 : Ancrage au navigateur
			// 2 : Ancrage au contenu
			if (this.m_oHote && (2 == this.m_eAncrageHauteur))
			{
				var nNbLignes = 0;
				clWDUtil.bForEach(this.m_oDonnees.m_tabConfigCourante, function (oPosition)
				{
					if (oPosition.m_bVisible)
					{
						nNbLignes = Math.max(nNbLignes, oPosition.m_nLigne + oPosition.m_nHauteur);
					}

					return true;
				});
				// Hauteur totale :
				// - Marge du haut (demi marge)
				// - Ligne
				// - Marge interm�diaire (marge compl�te)
				// - ...
				// - Marge interm�diaire (marge compl�te)
				// - Ligne
				// - Marge du bas (demi marge)
				// Ce qui donne : (Marge / 2) + nNbLignes * HauteurLigne + (nNbLignes - 1) * Marge + (Marge / 2)
				// Ce qui se simplifie en : nNbLignes * (HauteurLigne + Marge)
				this.m_oHote.style.height = clWDUtil.GetDimensionPxPourStyle(nNbLignes * (this.m_oParametres.m_nTaille1CaseY + this.m_oParametres.m_nMargeY));
			}
		}

		// Elements du mode �dition
		this.__AfficheModeEdition();

		// D�placement du bouton du menu
		this.__AfficheBouton();
	};

	// Pr�pare le positionnement : recalcule les dimensions et calcule les classes CSS pour le positionnement
	__WDTdb.prototype.__PreparePositionnement = function __PreparePositionnement()
	{
		// Rebond sur la m�thode quyui accepte un tableau de positions
		this.PreparePositionnement(this.m_oDonnees.m_tabConfigCourante);
	};

	// Affiche/supprime les �l�ments du mode �dition
	// Le contenu normal DOIT avoir �t� calcul� (= utilise la position des widgets)
	__WDTdb.prototype.__CalculeNbLignesColonnesEffectives = function __CalculeNbLignesColonnesEffectives(tabPositionnement)
	{
		// Mise a jour du positionnement :
		// - Calcul du nombre de colonne (si nombre variable)
		// - De la largeur des colonnes (si colonnes extensibles)
		// - Du nombre de lignes avec des �l�ments affich�es
		// - Du nombre de ligness maximales affichables
//		var nNbColonnesEffectif = this.m_oParametres.m_nNbColonnes;
		var nNbColonnesEffectif = this.__nGetNbColonnes();
		var nTaille1CaseXEffective = this.m_oParametres.m_nTaille1CaseX;
		var nMargeX = this.m_oParametres.m_nMargeX;
		var nLargeurColonneAvecMargeGauche = nTaille1CaseXEffective + nMargeX;
		// GP 16/09/2014 : QW248023 : Il faut ajouter la marge car la division est avec marge mais on a une marge en moins dans la largeur en centrant (n widgets mais n-1 intervalle entre les wdigets)
		var nLargeurDisponible = this.m_oHote.offsetWidth;
		var nLargeurDisponibleAvecMargeDroite = nLargeurDisponible + nMargeX;
		var nOffsetCentrage = nMargeX / 2;

		switch (this.m_oParametres.m_eMiseEnPage)
		{
		case 0:
			// Nombre de colonne fixe
			// GP 03/09/2014 : QW246733 : Ajout de "Math.max(0, x)" pour g�rer le cas du champ trop �troit (qui a donc un ascenseur)
			// GP 17/02/2015 : On ne centre pas dans les modes Largeur variable et nombre de colonne variable (sinon le cot� gauche joue au yoyo)
			nOffsetCentrage = Math.max(0, Math.floor((nLargeurDisponibleAvecMargeDroite - nNbColonnesEffectif * nLargeurColonneAvecMargeGauche) / 2));
			break;
		case 1:
			// Nombre de colonne variable : calcule le nombre de colonnes
			nNbColonnesEffectif = Math.max(nNbColonnesEffectif, Math.floor(nLargeurDisponibleAvecMargeDroite / nLargeurColonneAvecMargeGauche));
			break;
		case 2:
			// Colonne de largeur variable : calcule la largeur d'une colonne
			// Math.floor et pas Math.ceil sinon on a une largeur effective finale trop large
			// GP 18/02/2015 : QW254988 : Il ne faut pas utiliser nLargeurDisponibleAvecMargeDroite mais simplement nLargeurDisponible. Car ici on retire la largeur ensuite.
			nTaille1CaseXEffective = Math.max(nTaille1CaseXEffective, Math.floor(nLargeurDisponible / nNbColonnesEffectif) - nMargeX);
			break;
		}
		this.m_nNbColonnesEffectif = nNbColonnesEffectif;
		this.m_nTaille1CaseXEffective = nTaille1CaseXEffective;
		this.m_nOffsetCentrage = nOffsetCentrage;

		// Par d�faut pas de lignes (si pas d'�l�ments)
		var nNbLignesEffectif = 0;
		clWDUtil.bForEach(tabPositionnement, function (oPosition)
		{
			if (oPosition.m_bVisible)
			{
				// Un widget "simple" sur la ligne 0 donne une hauteur de 1, donc oPosition.m_nLigne + oPosition.m_nHauteur permet d'avoir la ligne)
				nNbLignesEffectif = Math.max(nNbLignesEffectif, oPosition.m_nLigne + oPosition.m_nHauteur);
			}
			return true;
		});

		this.m_nNbLignesEffectif = nNbLignesEffectif;

		// Et calcule selon la taille de l'�cran
		this.m_nNbLignesVisiblesEffectif = Math.max(nNbLignesEffectif, Math.ceil((this.m_oHote.offsetHeight - this.m_oParametres.m_nMargeY) / (this.m_oParametres.m_nTaille1CaseY + this.m_oParametres.m_nMargeY)));

	};

	// Mise a jour des classes de style selon le positionnement
	__WDTdb.prototype.__CalculeClassePositionnement = function __CalculeClassePositionnement()
	{
		var oStyleCacheDimension = this.m_oStyleCacheDimension;
		// Supprime toutes les classes en cr�ant le cache
		oStyleCacheDimension.Creation();

		var sBaseSelecteur = "#" + this.sGetNomElement(this.ms_sSuffixeHote) + " .";
		var nMargeX = this.m_oParametres.m_nMargeX;
		var nMargeY = this.m_oParametres.m_nMargeY;
		var nTaille1CaseX = this.m_nTaille1CaseXEffective;
		var nTaille1CaseY = this.m_oParametres.m_nTaille1CaseY;

		// Invente toutes les positions en X et Y selon le nombre de lignes et de colonnes
		// Invente toutes les dimensions en largeur et hauteur selon le nombre de lignes et de colonnes
		var i;
		var nLimiteI;
		var nOffset;

		nLimiteI = this.m_nNbColonnesEffectif;
		nOffset = nMargeX + nTaille1CaseX;
		// GP 16/09/2014 : QW248023 : Ici il ne faut pas mettre la marge, elle a �t� compt� dans le centrage
		var nMargeXGaucheTotal = this.m_nOffsetCentrage;
		for (i = 0; i < nLimiteI; i++)
		{
			oStyleCacheDimension.Ajoute(sBaseSelecteur + ms_sClasseColonne + i, ["left:" + (nMargeXGaucheTotal + nOffset * i) + "px"]);
			oStyleCacheDimension.Ajoute(sBaseSelecteur + ms_sClasseLargeur + (i + 1), ["width:" + (nTaille1CaseX + nOffset * i) + "px"]);
		}
		nLimiteI = this.m_nNbLignesVisiblesEffectif;
		nOffset = nMargeY + nTaille1CaseY;
		var nOffsetYInitial = Math.floor(nMargeY / 2);
		for (i = 0; i < nLimiteI; i++)
		{
			oStyleCacheDimension.Ajoute(sBaseSelecteur + ms_sClasseLigne + i, ["top:" + (nOffsetYInitial + nOffset * i) + "px"]);
			// On peut se limiter a m_nNbLignesEffectif et pas m_nNbLignesVisiblesEffectif pour la hauteur mais cela complexifie inutilement la boucle
			oStyleCacheDimension.Ajoute(sBaseSelecteur + ms_sClasseHauteur + (i + 1), ["height:" + (nTaille1CaseY + nOffset * i) + "px"]);
		}

		// GP 11/07/2017 : Plus besoin de pr�fixer les divers styles CSS utilis�s (disponible sans pr�fixe depuis 2011/2012)
//		oStyleCacheDimension.Ajoute(sBaseSelecteur + ms_sClasseBase, ["position:absolute;" + clWDUtil.m_sPrefixeCSS + "box-sizing: border-box;overflow:hidden"]);
		oStyleCacheDimension.Ajoute(sBaseSelecteur + ms_sClasseBase, ["position:absolute;box-sizing: border-box;overflow:hidden"]);
		// GP 09/09/2014 : QW247886 : Il faut faire en sorte que le masque soit toujours au dessus des widgets
		oStyleCacheDimension.Ajoute(sBaseSelecteur + ms_sClasseWidget, ["z-index:0"]);
		oStyleCacheDimension.Ajoute(sBaseSelecteur + ms_sClasseMasque, ["z-index:1"]);

		oStyleCacheDimension.CreationFin();
	};

	// Pr�paration/Mise � jour du positionnement : recalcule les dimensions et calcule les classes CSS pour le positionnement
	// R�organise le dessin si les options le demande (nombre de colonnes variable, position invalide, compactage)
	// Retourne vrai si on a modifi� l'affichage.
	__WDTdb.prototype.__bCalculeOrganisation = function __bCalculeOrganisation()
	{
		var bModifie = false;

		// Si on doit r�organiser les �l�ments en cas de changement du nombre de colonne affich�
		if (clWDUtil.bRWD && (1 != this.m_oParametres.m_eMiseEnPage))
		{
			var nTrancheIndiceWL = clWDUtil.bRWD ? $.wb.nGetTrancheActiveIndiceWL(true) : 1;
			var nNbColonnesTrancheCourante = this.__nGetNbColonnesSelonTranche(nTrancheIndiceWL);
			if (this.m_nNbColonnesEffectif != nNbColonnesTrancheCourante)
			{
				// Recommence avec la configuration courante qui a �t� sauv�e
				this.m_oDonnees.m_tabConfigCourante = __s_tabDupliqueConfiguration(this.m_tabConfigCouranteRecue);
				// Place les propri�t�s selon la tranche.
				clWDUtil.bForEachIn(this.m_oDonnees.m_tabConfigCourante, function (nWidget, oWidget)
				{
					clWDUtil.bForEach(ms_tabCorrespondanceProprietesTranches, function (tabCorrespondance)
					{
						var tabParTranches = oWidget[tabCorrespondance[1]];
						if (undefined !== tabParTranches)
						{
							var oPourNouvelleTranche = tabParTranches[nTrancheIndiceWL - 1];
							if (undefined !== oPourNouvelleTranche)
							{
								oWidget[tabCorrespondance[0]] = oPourNouvelleTranche;
							}
						}
						return true;
					});
					return true;
				});

				// D�place les �l�ments de la configuration courante pour tenir compte du nombre de colonnes effectif
				// GP 31/10/2016 : Vu par le TDF, lors du premier appel this.m_nNbColonnesEffectif n'est pas d�fini
				// GP 13/02/2017 : QW282702 : R�duction de la taille de la recherche : passe de 1000 x 1000 � 100 x 250 (soit 40 fois moins)
				// => En effet l'algo de bFaitDeLaPlace est en O(largeur * hauteur * nombre de widget)
	//			this.bFaitDeLaPlace(this.m_oDonnees.m_tabConfigCourante, { m_bVisible: true, m_nLigne: 0, m_nColonne: nNbColonnesTrancheCourante, m_nLargeur: 1000, m_nHauteur: 1000 }, clWDUtil.nElementInconnu, nNbColonnesTrancheCourante);
				this.bFaitDeLaPlace(this.m_oDonnees.m_tabConfigCourante, { m_bVisible: true, m_nLigne: 0, m_nColonne: nNbColonnesTrancheCourante, m_nLargeur: 100, m_nHauteur: 250 }, clWDUtil.nElementInconnu, nNbColonnesTrancheCourante);

				bModifie = true;
			}
		}

		// Pr�paration/Mise � jour du positionnement : recalcule les dimensions et calcule les classes CSS pour le positionnement
		this.__PreparePositionnement();

		// On ne recalcule l'organisation que dans les pages statiques
		// Dans les pages dynamiques, ce que l'on recoit du serveur est recalcul�
		if (clWDUtil.bPageStatique)
		{
			// On recalcule l'organisation si besoin
			// => On ne recalcule pas. On ne corrige pas en ex�cution une organisation incorrecte (comportement de la OBJ)

			// Et on compacte (si autoris�)
			bModifie = this.__bAutoCompacte() || bModifie;
		}

		return bModifie;
	};

	// Effectue le compactage automatique (si autoris�).
	// Retourne vrai si on a modifi� l'affichage.
	__WDTdb.prototype.__bAutoCompacte = function __bAutoCompacte()
	{
		var bModifie = false;

		if (this.m_oParametres.m_bAutoCompacte)
		{
			// Attention algo en nNbCellules * nNbCellules * nNbWidget
			// Pour chaque cellule on regarde si un widget l'occupe. Pour chaque cellule libre on recommence l'algo.
			bModifie = this.__bBoucheTrous();

			if (bModifie)
			{
				// Mise � jour du positionnement : recalcule les dimensions et calcule les classes CSS pour le positionnement
				this.__PreparePositionnement();
			}
		}

		return bModifie;
	};
	// Bouche les trous.
	__WDTdb.prototype.__bBoucheTrous = function __bBoucheTrous()
	{
		var tabConfigCourante = this.m_oDonnees.m_tabConfigCourante;

		var nNbLignes = this.m_nNbLignesEffectif;
		var nNbColonnes = this.m_nNbColonnesEffectif;

		var bModification = false;

		// Construit la liste des cellules utilis�es
		// Acc�s par nLigne * nNbColonnes + nColonne
		var tabCellules = new Array(nNbLignes * nNbColonnes);
		for (var nLigne = 0; nLigne < nNbLignes; nLigne++)
		{
			for (var nColonne = 0; nColonne < nNbColonnes; nColonne++)
			{
				// Si la cellule est d�j� occup� (par un widget plus grand rencontr� pr�c�dement)
				if (tabCellules[nLigne * nNbColonnes + nColonne])
				{
					continue;
				}

				// La cellule n'est pas d�j� occup�e : regarde si on a un widget � ces coordonn�es
				var nWidget = __s_nGetPosition(tabConfigCourante, nLigne, nColonne, clWDUtil.nElementInconnu);
				var oPosition = null;
				// __s_nGetPosition filtre d�j� les widget invisibles
				if (clWDUtil.nElementInconnu != nWidget)
				{
					// On m�morise juste la position pour marquer les cellules et ne pas les retester
					oPosition = tabConfigCourante[nWidget];
				}
				else
				{
					// On ne calcule pas sa taille, on prend tous les �l�ments qui sont plus loin dans le TDB, et on regarde s'il vont dans la place.
					// On choisi celui qui occupe la plus grande surface en privil�giant les �l�ments les plus loin
					var oWidgetChoix = null;
					var nSurface = 0;
					clWDUtil.bForEach(tabConfigCourante, function (oWidget)
					{
						// Seulement ceux :
						// - Qui sont visibles
						// - Qui sont au moins aussi grand
						// - Qui sont apr�s
						var nSurfaceWidget = oWidget.m_nLargeur * oWidget.m_nHauteur;
						if (oWidget.m_bVisible && (nSurface <= nSurfaceWidget) && ((nLigne < oWidget.m_nLigne) || ((nLigne == oWidget.m_nLigne) && (nColonne < oWidget.m_nColonne))))
						{
							var oPositionNew = {
								m_nLigne: nLigne,
								m_nColonne: nColonne,
								m_nLargeur: oWidget.m_nLargeur,
								m_nHauteur: oWidget.m_nHauteur
							};
							// Si le d�placement est possible
							if (__s_bPositionDisponible(tabConfigCourante, oPositionNew, oWidget))
							{
								nSurface = nSurface;
								oWidgetChoix = oWidget;
							}
						}

						return true;
					});

					// Si on a un widget
					if (oWidgetChoix)
					{
						// Le d�place � la position
						oWidgetChoix.m_nColonne = nColonne;
						oWidgetChoix.m_nLigne = nLigne;

						bModification = true;
						oPosition = oWidgetChoix;
					}
				}

				if (oPosition)
				{
					// Marque les cellules comme occup�e (y compris la premi�re cellule (elle ne sera jamais relue mais cela permet de garder l'algo simple))
					var nLigneOccupee;
					var nLigneOccupeeLimite = nLigne + oPosition.m_nHauteur;
					for (nLigneOccupee = nLigne; nLigneOccupee < nLigneOccupeeLimite; nLigneOccupee++)
					{
						var nColonneOccupee;
						var nColonneOccupeeLimite = nColonne + oPosition.m_nLargeur;
						for (nColonneOccupee = nColonne; nColonneOccupee < nColonneOccupeeLimite; nColonneOccupee++)
						{
							tabCellules[nLigneOccupee * nNbColonnes + nColonneOccupee] = true;
						}
					}
				}
			}
		}

		if (bModification)
		{
			// Mise a jour du positionnement :
			// - Calcul du nombre de colonne (si nombre variable)
			// - De la largeur des colonnes (si colonnes extensibles)
			// - Du nombre de lignes avec des �l�ments affich�es
			// - Du nombre de ligness maximales affichables
			this.__CalculeNbLignesColonnesEffectives(tabConfigCourante);
		}

		return bModification;
	};

	// Indique si une position est possible
	function __s_bPositionDisponible(tabPosition, oPositionRecherche, oExclusion)
	{
		// Si on trouve un position qui intersecte, on sort de la boucle donc on recoit false. Qui est ce que l'on veux puisque alors la position n'est pas disponible.
		return clWDUtil.bForEach(tabPosition, function (oPosition/*, nPosition*/)
		{
			// Si on a une position visible � cette position, c'est que ce n'est pas disponible.
			// => On veux sortir de la boucle => On ajoute un !
			return !((oPosition !== oExclusion) && oPosition.m_bVisible && __s_bIntersectionPositions(oPosition, oPositionRecherche));
		});
	}

	// Indique si deux positions sont en intersection
	function __s_bIntersectionPositions(oPosition1, oPosition2)
	{
		return (oPosition1.m_nColonne < oPosition2.m_nColonne + oPosition2.m_nLargeur)
			&& (oPosition2.m_nColonne < oPosition1.m_nColonne + oPosition1.m_nLargeur)
			&& (oPosition1.m_nLigne < oPosition2.m_nLigne + oPosition2.m_nHauteur)
			&& (oPosition2.m_nLigne < oPosition1.m_nLigne + oPosition1.m_nHauteur);
	}

	// Indique si deux positions sont �gales
	function __s_bEgalePositions(oPosition1, oPosition2)
	{
		return (oPosition1.m_nColonne == oPosition2.m_nColonne)
			&& (oPosition1.m_nLigne == oPosition2.m_nLigne)
			&& (oPosition1.m_nHauteur == oPosition2.m_nHauteur)
			&& (oPosition1.m_nLargeur == oPosition2.m_nLargeur);
	}

	// Affiche le contenu selon l'organisation calcul�e
	__WDTdb.prototype.__AfficheContenu = function __AfficheContenu()
	{
		clWDUtil.bForEachThis(this.m_oDonnees.m_tabConfigCourante, this, this.bAfficheUnWidget);
	};

	// Dessine/supprime les �l�ments du mode �dition
	__WDTdb.prototype.__AfficheModeEdition = function __AfficheModeEdition()
	{
		// On commence par supprimer les �l�ments d'�dition pr�c�dents :
		// - Si on n'est pas en �dition, permet de g�rer le cas ou l'on viens de sortir du mode �dition
		// - Si on est en �dition, permet de redessiner selon le positionnement courant
		if (this.m_oTdbModeEdition)
		{
			this.m_oTdbModeEdition.Fin();
			this.m_oTdbModeEdition = null;
		}

		if (this.m_oDonnees.m_bEnModeEdition)
		{
			// Commence le mode �dition
			this.m_oTdbModeEdition = new __WDTdbModeEdition(this, this.m_oDonnees.m_bDeplace, this.m_oDonnees.m_bRedimensionne);
		}
	};

	// D�placement du bouton du menu
	__WDTdb.prototype.__AfficheBouton = function __AfficheBouton()
	{
		var oBoutonMenu = this.m_oBoutonMenu;
		if (oBoutonMenu)
		{
			var bDroite = false;
			var bBas = false;
			// La largeur du champ
			switch (this.m_oParametres.m_eBoutonMenuPosition)
			{
			default:
			case 0:
				// BOUTONPOSITION_LIBRE
				// => On ne doit pas �tre ici (filtr� sur le serveur qui ne retourne pas de bouton
				return;
			case 1:
				// BOUTONPOSITION_HAUTGAUCHE
				// => On ne change rien
				break;
			case 2:
				// BOUTONPOSITION_HAUTDROITE
				bDroite = true;
				break;
			case 3:
				// BOUTONPOSITION_BASGAUCHE
				bBas = true;
				break;
			case 4:
				// BOUTONPOSITION_BASDROITE
				bDroite = true;
				bBas = true;
				break;
			}

			var oHote = this.m_oHote;
			var oHoteParent = oHote.parentNode;
			// 6 : cas par d�faut (gauche ou haut)
			var nLeft = 6;
			if (bDroite)
			{
				// GP 02/09/2014 : QW247568 : Comme tout est superposable, la dimension est de 0, on prend la dimension du parent
				var nOffsetWidth = oHote.offsetWidth;
				if (0 == nOffsetWidth)
				{
					nOffsetWidth = oHoteParent.offsetWidth;
				}
				nLeft = nOffsetWidth - 6 - oBoutonMenu.offsetWidth;
			}
			var nTop = 6;
			if (bBas)
			{
				// GP 02/09/2014 : QW247568 : Comme tout est superposable, la dimension est de 0, on prend la dimension du parent
				var nOffsetHeight = oHote.offsetHeight;
				if (0 == nOffsetHeight)
				{
					nOffsetHeight = oHoteParent.offsetHeight;
				}
				nTop = nOffsetHeight - 6 - oBoutonMenu.offsetHeight;
			}

			// Le d�place
			oBoutonMenu.style.left = (clWDUtil.nGetBoundingClientRectLeft(oHote, false, false) + nLeft - clWDUtil.nGetBoundingClientRectLeft(oBoutonMenu.offsetParent, false, false)) + "px";
			oBoutonMenu.style.top = (clWDUtil.nGetBoundingClientRectTop(oHote, false, false) + nTop - clWDUtil.nGetBoundingClientRectTop(oBoutonMenu.offsetParent, false, false)) + "px";
			// GP 17/02/2015 : QW254976 : Supprime lel right et le bottom
			oBoutonMenu.style.right = "";
			oBoutonMenu.style.bottom = "";
		}
	};

	// Appel d'un PCode navigateur avec transmission (optionnelle) d'un rendezvous
	// GP 02/07/2014 : Pas d'appel de _SetActionMoteurSpecifique dans WDJS : pas de sActionServeur
	//__WDTdb.prototype.__AppelPCode = function __AppelPCode(ePCodeNav, oEvent, sActionServeur, nWidget)
	__WDTdb.prototype.__AppelPCode = function __AppelPCode(ePCodeNav, oEvent, nWidget)
	{
		// Si on a un rendezvous, construit le type avance correspondant et le transmet au PCode
//		this.RecuperePCode(ePCodeNav)(oEvent, sActionServeur, this.m_oDonnees.m_tabConfigCourante[nWidget].m_sNomFI);
		this.RecuperePCode(ePCodeNav)(oEvent, this.m_oDonnees.m_tabConfigCourante[nWidget].m_sNomFI);
	};

	// Notifie le serveur
	__WDTdb.prototype.__ActionServeur = function __ActionServeur(sActionServeur, nWidget)
	{
		// Construit le JSON du serveur
		this.m_oChampFormulaire.value = nWidget + "," + (this.m_oDonnees.m_bEnModeEdition ? "1" : "0") + "," + this.sSauveConfiguration();

		try
		{
			// GP 24/02/2015 : TB91049
//			var sActionSvg = _PAGE_.action;
			var sActionSvg = clWDUtil.sGetPageAction();
			_PAGE_.action = sActionSvg + "#" + this.m_oHote.id;

			_JSL(_PAGE_, this.m_sAliasChamp, "_self", undefined, undefined, sActionServeur);
		}
		finally
		{
			_PAGE_.action += sActionSvg;
		}
	};

	// Notifie les champs d'un widget de l'affichage/masquage du widget
	__WDTdb.prototype.__OnDisplayWidget = function __OnDisplayWidget(nWidget, bAffiche)
	{
		// Appel du OnDisplay sur le Widget (pour ses champs)
		var oDiv = this.m_tabCacheDivWidget[nWidget].m_oDiv;
		if (oDiv)
		{
			AppelMethode(WDChamp.prototype.ms_sOnDisplay, [oDiv, bAffiche]);
		}
	};

	// Regarde si l'objet est un tableau de bord, si oui, v�rifie si le champ est dans le tableau et bord, et si oui appel la m�thode sur le tableau de bord
	// En fait le this ici est un objet qui n'est pas forc�ment un __WDTdb
	__WDTdb.prototype.__s_AppelChangeTailleDeplace = function __s_AppelChangeTailleDeplace(oChamp, fCallback, tabParametres)
	{
		if ((this instanceof __WDTdb) && clWDUtil.bEstFils(oChamp, this.m_oHote))
		{
			var tabCacheDivWidget = this.m_tabCacheDivWidget;
			if (tabCacheDivWidget.length)
			{
				// Trouve le widget parent
				var nWidgetParentC;
				if (!clWDUtil.bForEach(tabCacheDivWidget, function (oCacheDivWidget, nWidgetC)
				{
					if (clWDUtil.bEstFils(oChamp, oCacheDivWidget.m_oDiv))
					{
						nWidgetParentC = nWidgetC;
						return false;
					}
					return true;
				}))
				{
					tabParametres.unshift(nWidgetParentC);
					fCallback.apply(this, tabParametres);
				}
			}
		}
	};

	__WDTdb.prototype.__WLAfficheUnWidget = function __WLAfficheUnWidget(oEvent, oWidget, nWidget)
	{
		if (oWidget.m_bVisible)
		{
			// R�cup�re l'alias de la page interne et ex�cute la fonction si elle existe
			// Ex�cute le traitement de rafraichissement navigateur du widget
			clWDUtil.pfGetTraitement(oWidget.m_sAlias, this.ms_nEventNavTdbWidgetRefresh)(oEvent);

			// Cas sur un seul �l�ment
			this.OnAfficheWidget(oEvent, oWidget, nWidget);
		}
	};

	// Duplique une configuration
	function __s_tabDupliqueConfiguration(tabConfigurationOriginale)
	{
		// Copie de la configuration originale dans la configuration courante
		var tabConfigurationCopie = [];
		clWDUtil.bForEachIn(tabConfigurationOriginale, function (nWidgetInitial, oWidgetInitial)
		{
			var oWidgetNew = {};
			clWDUtil.bForEachIn(oWidgetInitial, function (sMembre, oMembre)
			{
				oWidgetNew[sMembre] = oMembre;
				return true;
			});
			tabConfigurationCopie.push(oWidgetNew);
			return true;
		});
		return tabConfigurationCopie;
	};

	//////////////////////////////////////////////////////////////////////////
	// __WDTdb
	//	Interface des tableaux de bord
	//		Appel depuis le HTML

	// GP 28/08/2015 : QW260577 : Si le champ est marqu� comme clonable, c'est que son champ TDB associ� peut changer (s'il est clon� avec le TDB)
	// - L'alias du TDB (qui ne change pas forc�ment selon le contexte de clone du bouton)
	// - L'alias du bouton (qui change selon le contexte de clone du bouton)
	// Le code recherche alors le champ TDB associ� � ce bouton, s'il le trouve il est utilis� (c'est le champ associ� a ce bouton). S'il ne le trouve pas,
	// c'est que c'est un bouton qui ouvre un menu de TDB en placement libre et il n'est pas clon� avec le TDB.
	__WDTdb.prototype.s_OnOuvreMenu = (function ()
	{
		//////////////////////////////////////////////////////////////////////////
		// Classes utilitaires
		//	__WDMenuContextuelTdb
		//		Affichage du menu contextuel du champ Tdb
		function __WDMenuContextuelTdb(oEvent, oTdb)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				var oDonnees = oTdb.m_oDonnees;
				var bEnModeEdition = oDonnees.m_bEnModeEdition;

				// Construit le menu
				var tabOptions = [];

				// Ajoute les options selon le besoin
				// GP 01/12/2014 : On affiche l'option pour passer en mode �dition SI la FAA est active. Si elle est active on aura peut-�tre un menu avec rien et ne pourra rien faire.
				if (oDonnees.m_bFAAEdition)
				{
					// Ajoute un objet imm�diat (et pas une globale constante de la classe) pour pouvoir la modifier (ajout de m_bSeparateur)
					var oOption = {
						m_oLibelle: { m_sTraduction: "EDITION", sLibelle: "Mode \xE9dition" },
						m_pfAction: function (oEvent) { oTdb.OnModeEdition(oEvent); }
					};
					if (bEnModeEdition)
					{
						oOption.m_sImage = "CocheActif.png";
					}
					tabOptions.push(oOption);
				}
				if (oDonnees.m_bFAARestaureConfigInitiale)
				{
					tabOptions.push({
						m_oLibelle: { m_sTraduction: "CONFINIT", sLibelle: "Restaurer la configuration initiale" },
						m_pfAction: function (oEvent) { oTdb.OnConfigurationInitiale(oEvent); }
					});
				}

				// GP 18/09/2014 : QW248301 : Uniquement si on ne d�sactive pas la suppression
				var tabConfigCourante = oDonnees.m_tabConfigCourante;
				if (oDonnees.m_bSupprime && oDonnees.m_bFAAAjouteSupprime && (0 < tabConfigCourante.length))
				{
					// Si on a d�j� au moins une des deux options : ajoute le s�parateur
					if (tabOptions.length)
					{
						tabOptions[tabOptions.length - 1].m_bSeparateur = true;
					}
					clWDUtil.bForEach(tabConfigCourante, function (oWidget, nWidget)
					{
						var oOption = { m_oLibelle: { sLibelle: oWidget.m_sLibelle } };
						if (oWidget.m_bVisible)
						{
							oOption.m_pfAction = function (oEvent) { oTdb.OnMasqueWidget(oEvent, oWidget, nWidget); };
							oOption.m_sImage = "CocheActif.png";
						}
						else
						{
							oOption.m_pfAction = function (oEvent) { oTdb.OnAfficheWidget(oEvent, oWidget, nWidget); };
						}
						tabOptions.push(oOption);

						return true;
					});
				}

				// M�morise les param�tres sp�cifiques
				var eSensOuverture = this.ms_eOuvreBasDroite;
				switch (oTdb.m_oParametres.m_eBoutonMenuPosition)
				{
				case 0:
					// BOUTONPOSITION_LIBRE
					break;
				case 1:
					// BOUTONPOSITION_HAUTGAUCHE
					break;
				case 2:
					// BOUTONPOSITION_HAUTDROITE
					eSensOuverture = this.ms_eOuvreBasGauche;
					break;
				case 3:
					// BOUTONPOSITION_BASGAUCHE
					eSensOuverture = this.ms_eOuvreHautDroite;
					break;
				case 4:
					// BOUTONPOSITION_BASDROITE
					eSensOuverture = this.ms_eOuvreHautGauche;
					break;
				}

				// Appel le constructeur de la classe de base
				WDMenuContextuel.prototype.constructor.apply(this, [oEvent, tabOptions, eSensOuverture, TDB_MENU]);
			}
		}

		// Declare l'heritage
		__WDMenuContextuelTdb.prototype = new WDMenuContextuel();
		// Surcharge le constructeur qui a ete efface
		__WDMenuContextuelTdb.prototype.constructor = __WDMenuContextuelTdb;

		// M�thodes virtuelles

		// Effectue l'action
		__WDMenuContextuelTdb.prototype._vAction = function _vAction(oEvent, oOptionSelection)
		{
			oOptionSelection.m_pfAction(oEvent);
		};

		// Ouverture du menu
		return function (oEvent, sAliasTDB, sAliasBouton)
		{
			var oTDB = oGetObjetChamp(sAliasTDB);

			// Recherche un TDB avec ce bouton
			clWDUtil.bForEachIn(clWDUtil.m_oChamps, function (sAliasChamp, oObjetChamp)
			{
				if ((oObjetChamp instanceof __WDTdb) && (oObjetChamp.m_oParametres.m_sBoutonMenuAlias == sAliasBouton))
				{
					oTDB = oObjetChamp;
					return false;
				}
				return true;
			});

			// Instancie un nouveau menu
			new __WDMenuContextuelTdb(oEvent, oTDB);
		};
	})();

	//////////////////////////////////////////////////////////////////////////
	// __WDTdb
	//	Interface des tableaux de bord
	//		Appel depuis __WDMenuContextuelTdb

	// Commence/Termine le mode �dition
	__WDTdb.prototype.OnModeEdition = function OnModeEdition(/*oEvent*/)
	{
		// Inverse le mode d'�dition
		this.m_oDonnees.m_bEnModeEdition = !this.m_oDonnees.m_bEnModeEdition;

		// GP 14/11/2014 : QW251754 : L'entr�e et la sortie du mode �dition "oublie" les options forc� sur le serveur (qui en fait ne servent que quand on force le passage en �dition dans un mode donn�)
		this.m_oDonnees.m_bRedimensionne = true;
		this.m_oDonnees.m_bDeplace = true;
		this.m_oDonnees.m_bAjoute = true;
		this.m_oDonnees.m_bSupprime = true;

		// Et redessine le mode �diton
		this.__AfficheModeEdition();
	};

	// R�affiche le tableau de bord avec la configuration initiale
	__WDTdb.prototype.OnConfigurationInitiale = function OnConfigurationInitiale(/*oEvent*/)
	{
		// Copie de la configuration originale dans la configuration courante
		this.m_oDonnees.m_tabConfigCourante = __s_tabDupliqueConfiguration(this.m_oParametres.m_tabConfigInitiale);

		// Si on est en RWD : force un recalcul car la config re�ue correspond � la premi�re tranche
		this.m_nNbColonnesEffectif = undefined;

		// Effectue un affichage (forc� dans les pages statiques)
		// Une partie est probablement inutile : les d�placements on �t� fait par le mode �dition
		this.__AfficheInterne(clWDUtil.bPageStatique);

		// Si on est dans une page dynamique : notifie le serveur qui :
		if (!clWDUtil.bPageStatique)
		{
			// - Restaure la configuration
			// - Provoque le rafraichissement de la page
			this.__ActionServeur(ms_sActionConfigInitiale, -1);
		}
	};

	// Affiche un widget
	__WDTdb.prototype.OnAfficheWidget = function OnAfficheWidget(oEvent, oWidget, nWidget)
	{
		// On ne trouve l'emplacement du widget dans le cas page dynamique car on ne connait m�me pas la taille du widget
		var tabConfigCourante = this.m_oDonnees.m_tabConfigCourante;

		// Si on est dans une page statique :
		if (clWDUtil.bPageStatique)
		{
			// - Trouve un emplacement pour le widget. On privil�gie la position actuelle
			// Comme le widget est invisible, il n'interfere pas dans le test de __s_bPositionDisponible
			if (!__s_bPositionDisponible(tabConfigCourante, oWidget))
			{
				// La position actuelle ne convient pas : trouve une autre position et d�place le widget a cet endroit
				__s_CopiePosition(oWidget, this.__oGetNouvellePosition(oWidget, tabConfigCourante));
			}
		}

		// Marque le widget comme affich�
		oWidget.m_bVisible = true;

		// Effectue un affichage (forc� dans les pages statiques)
		this.__AfficheInterne(clWDUtil.bPageStatique);

		// Si on est dans une page statique :
		if (clWDUtil.bPageStatique)
		{
			// Appel du OnDisplay sur le Widget (pour ses champs)
			this.__OnDisplayWidget(nWidget, true);
		}

		// Appel le traitement navigateur d'ajout d'un Widget
		// (Actuellement on ignore le r�sultat du traitement)
//		this.__AppelPCode(this.ms_nEventNavTdbAjoute, oEvent, ms_sActionAjoute, nWidget);
		this.__AppelPCode(this.ms_nEventNavTdbAjoute, oEvent, nWidget);

		// Si on est dans une page dynamique : notifie le serveur qui :
		if (!clWDUtil.bPageStatique)
		{
			// - Charge le Widget
			// - Appel le traitement serveur
			// - Provoque le rafraichissement de la page
			this.__ActionServeur(ms_sActionAjoute, nWidget);
		}
	};

	// Masque un widget
	__WDTdb.prototype.OnMasqueWidget = function OnMasqueWidget(oEvent, oWidget, nWidget)
	{
		// Marque le widget comme masqu�
		oWidget.m_bVisible = false;

		// Effectue un affichage (forc� dans les pages statiques)
		this.__AfficheInterne(clWDUtil.bPageStatique);

		// Si on est dans une page statique :
		if (clWDUtil.bPageStatique)
		{
			// Appel du OnDisplay sur le Widget (pour ses champs)
			this.__OnDisplayWidget(nWidget, false);
		}

		// Appel le traitement navigateur de suppression d'un Widget
		// (Actuellement on ignore le r�sultat du traitement)
//		this.__AppelPCode(this.ms_nEventNavTdbSupprime, oEvent, ms_sActionSupprime, nWidget);
		this.__AppelPCode(this.ms_nEventNavTdbSupprime, oEvent, nWidget);

		// Si on est dans une page dynamique : notifie le serveur qui :
		if (!clWDUtil.bPageStatique)
		{
			// - Masque le Widget
			// - Appel le traitement serveur
			// - Provoque le rafraichissement de la page
			this.__ActionServeur(ms_sActionSupprime, nWidget);
		}
	};

	// Notifie le champ de la nouvelle configuration :
	// - Copie la configuration temporaire dans la configuration g�n�rale
	// - Ex�cution des PCodes serveur et navigateur
	__WDTdb.prototype.OnChangementConfiguration = function OnChangementConfiguration(oEvent, tabPosition, nWidget, bRedimensionnement)
	{
		var tabConfigCourante = this.m_oDonnees.m_tabConfigCourante;

		// Si la position du widget est identique (= non modifi�e) : ne fait rien
		if (__s_bEgalePositions(tabConfigCourante[nWidget], tabPosition[nWidget]))
		{
			return true;
		}

		// Copie la configuration temporaire dans la configuration g�n�rale
		clWDUtil.bForEach(tabConfigCourante, function (oWidget, nWidgetIteration)
		{
			__s_CopiePosition(oWidget, tabPosition[nWidgetIteration]);
			return true;
		});

		// On ne fait pas de r�affichage, on est en mode �dition, c'est le mode �dition qui g�re le dessin
//		// Effectue un affichage (forc� dans les pages statiques)
//		// Une partie est probablement inutile : les d�placements on �t� fait par le mode �dition
//		this.__AfficheInterne(clWDUtil.bPageStatique);

		// Pr�paration/Mise � jour du positionnement : recalcule les dimensions et calcule les classes CSS pour le positionnement
		// Effectue une r�organisation si besoin
		this.__bCalculeOrganisation();

		// Appel le traitement navigateur de d�placement ou de redimensionnement d'un Widget
		// (Actuellement on ignore le r�sultat du traitement)
		var sActionServeur = bRedimensionnement ? ms_sActionRedimensionne : ms_sActionDeplace;
//		this.__AppelPCode(bRedimensionnement ? this.ms_nEventNavTdbRedimensionnement : this.ms_nEventNavTdbDeplacement, oEvent, sActionServeur, nWidget);
		this.__AppelPCode(bRedimensionnement ? this.ms_nEventNavTdbRedimensionnement : this.ms_nEventNavTdbDeplacement, oEvent, nWidget);

		// Si on est dans une page dynamique : notifie le serveur qui :
		if (!clWDUtil.bPageStatique)
		{
			// - D�place/redimensionne le widget
			// - Appel le traitement serveur
			// - Provoque le rafraichissement de la page
			this.__ActionServeur(sActionServeur, nWidget);
		}
	};

	// Affiche un widget a une position donn�e
	__WDTdb.prototype.bAfficheUnWidget = function bAfficheUnWidget(oPosition, nWidget)
	{
		// Positionne chaque �l�ment : +1 car indice WL
		// GP 27/11/2014 : QW252503 : Erreur JS avec cette pile : => Le widget n'est peut-�tre pas pr�sent et il est impossible de l'afficher
		// bAfficheUnWidget [Ligne�: 925, col�: 3], __WDTdb.js
		// __Affiche [Ligne�: 1933, col�: 5], __WDTdb.js
		// WDTdbModeEdition [Ligne�: 1699, col�: 3], __WDTdb.js
		// __AfficheModeEdition [Ligne�: 586, col�: 3], __WDTdb.js
		// __AfficheInterne [Ligne�: 271, col�: 2], __WDTdb.js
		// OnConfigurationInitiale [Ligne�: 783, col�: 2], __WDTdb.js
		// ...
		if (oPosition.m_bVisible)
		{
			var tabCacheDivWidget = this.m_tabCacheDivWidget;
			if (nWidget < tabCacheDivWidget.length)
			{
				var oCacheDivWidget = tabCacheDivWidget[nWidget];
				var oDiv = oCacheDivWidget.m_oDiv;
				if (oDiv)
				{
					oDiv.style.left = "";
					oDiv.style.top = "";
					oDiv.style.width = "";
					oDiv.style.height = "";
					// Force l'affichage :
					// - En mode statique les �l�ments masqu�s sont en display : none
					// - En mode �dition on masque certains �l�ments pendant le DnD
					clWDUtil.SetDisplay(oDiv, true);
					oDiv.className = oCacheDivWidget.m_sClasses + " " + __s_sGetClassesPositionnement(true, oPosition.m_nLigne, oPosition.m_nColonne, oPosition.m_nLargeur, oPosition.m_nHauteur);
				}
			}
		}

		return true;
	};

	// Masque un widget
	__WDTdb.prototype.bMasqueUnWidget = function bMasqueUnWidget(nWidget)
	{
		// GP 27/11/2014 : QW252503 : Erreur JS avec cette pile : => Le widget n'est peut-�tre pas pr�sent et il est impossible de l'afficher
		// bMasqueUnWidget [Ligne�: 946, col�: 2], __WDTdb.js
		// Anonymous function [Ligne�: 1887, col�: 4], __WDTdb.js
		// bForEach [Ligne�: 1254, col�: 3], WDUtil.js
		// __Affiche [Ligne�: 1883, col�: 3], __WDTdb.js
		// WDTdbModeEdition [Ligne�: 1684, col�: 3], __WDTdb.js
		// __AfficheModeEdition [Ligne�: 586, col�: 3], __WDTdb.js
		// __AfficheInterne [Ligne�: 271, col�: 2], __WDTdb.js
		// OnConfigurationInitiale [Ligne�: 783, col�: 2], __WDTdb.js
		// ...
		var tabCacheDivWidget = this.m_tabCacheDivWidget;
		if (nWidget < tabCacheDivWidget.length)
		{
			var oDiv = tabCacheDivWidget[nWidget].m_oDiv;
			if (oDiv)
			{
				// Force l'affichage :
				// - En mode statique les �l�ments masqu�s sont en display : none
				// - En mode �dition on masque certains �l�ments pendant le DnD
				clWDUtil.SetDisplay(oDiv, false);
			}
		}
	};

	// Pr�pare le positionnement : recalcule les dimensions et calcule les classes CSS pour le positionnement
	__WDTdb.prototype.PreparePositionnement = function PreparePositionnement(tabPositionnement)
	{
		// Mise a jour du positionnement :
		// - Calcul du nombre de colonne (si nombre variable)
		// - De la largeur des colonnes (si colonnes extensibles)
		// - Du nombre de lignes avec des �l�ments affich�es
		// - Du nombre de ligness maximales affichables
		this.__CalculeNbLignesColonnesEffectives(tabPositionnement);

		// Mise a jour des classes de style selon le positionnement
		this.__CalculeClassePositionnement();
	};

	// Calcule la classe d'un objet
	function __s_sGetClassesPositionnement(bWidget, nLigne, nColonne, nLargeur, nHauteur)
	{
		var tabClasses = [ms_sClasseBase];
		if (bWidget)
		{
			tabClasses.push(ms_sClasseWidget);
		}
		else
		{
			tabClasses.push(ms_sClasseMasque);
		}
		tabClasses.push(ms_sClasseLigne + nLigne);
		tabClasses.push(ms_sClasseColonne + nColonne);
		tabClasses.push(ms_sClasseLargeur + nLargeur);
		tabClasses.push(ms_sClasseHauteur + nHauteur);
		return tabClasses.join(" ");
	};

	// Modifie une position pour prendre la premi�re position disponible
	// oPosition est une position (objet position, objet de DnD ou objet widget)
	// tabPosition est un tableau de positions (objet position, objet de DnD ou objet widget)
	// oPositionInterdite est une �ventuelle position interdite
	__WDTdb.prototype.__oGetNouvellePosition = function __oGetNouvellePosition(oPosition, tabPosition, oPositionInterdite, nNbColonnesEffectifOuUndefined)
	{
		if (undefined == nNbColonnesEffectifOuUndefined)
		{
			nNbColonnesEffectifOuUndefined = this.m_nNbColonnesEffectif;
		}

		// GP 21/08/2018 : TB109492 : Bug de l'algo (= force un d�placement inutile) si :
		// - Un �l�ment est trop large pour le nombre de colonne
		// - L'�l�ment est sur la colonne 0.
		// => On force la limitation de sa largeur, donc (sauf position interdite) sa position initiale devient acceptable.
		var bInterditPositionInitiale = true;
		// Limite les dimensions a ce qui est affichable (�vite de partir en boucle)
		var bVisible = oPosition.m_bVisible;
		var nLargeur = oPosition.m_nLargeur;
		if (nNbColonnesEffectifOuUndefined < nLargeur)
		{
			nLargeur = nNbColonnesEffectifOuUndefined;
			if (0 == oPosition.m_nColonne)
			{
				bInterditPositionInitiale = false;
			}
		}
		var nHauteur = oPosition.m_nHauteur;

		var nLigne;
		var nColonne;
		// On ne cherche pas sur les derni�re colonnes si on est sur de l'�chec (pas assez de place en largeur)
		var nLimiteColonne = nNbColonnesEffectifOuUndefined - nLargeur + 1;

		// Attention algo en nNbCellules * nNbWidgets

		// Recherche les positions libres
		// nLigne < 1024 : Pour �tre sur de ne pas partir en boucle
		for (nLigne = 0; nLigne < 1024; nLigne++)
		{
			for (nColonne = 0; nColonne < nLimiteColonne; nColonne++)
			{
				// Construit la position possible
				var oPositionPossible = {
					m_bVisible: bVisible,
					m_nLigne: nLigne,
					m_nColonne: nColonne,
					m_nLargeur: nLargeur,
					m_nHauteur: nHauteur
				};

				// GP 28/10/2014 : Change l'algo :
				// - Interdit la position originale, mais on a le droit d'�tre en intersection avec la position originale (= d�placement qui recouvre partiellement)
				// - Interdit la position exclue
				// - Interdit les positions non disponible SAUF la position originale (si on recouvre partiellement, le recouvrement total a d�j� �t� test�)
				if ((bInterditPositionInitiale
					&& (nLigne == oPosition.m_nLigne)
					&& (nColonne == oPosition.m_nColonne))
//						__s_bIntersectionPositions(oPositionPossible, oPosition)
					|| (oPositionInterdite && __s_bIntersectionPositions(oPositionPossible, oPositionInterdite))
					|| !__s_bPositionDisponible(tabPosition, oPositionPossible, oPosition))
				{
					continue;
				}

				// On a une position possible
				return oPositionPossible;
			}
		}

		// Erreur : aucune position trouv�e : retourne la position originale
		return oPosition;
	};

	// Indique si une colonne est valide pour positionner un widget
	__WDTdb.prototype.bColonneValidePourLargeur = function bColonneValidePourLargeur(nColonne, nLargeur)
	{
		// Il faut avoir assez de place par rapport au nombre de colonne effectif
		return (nColonne + nLargeur) <= this.m_nNbColonnesEffectif;
	};

	// Copie une position dans une autre position (chaque position peut �tre un position, un widget, etc...)
	function __s_CopiePosition(oPositionCible, oPositionSource)
	{
		var nTrancheIndiceC = clWDUtil.bRWD ? ($.wb.nGetTrancheActiveIndiceWL(true) - 1) : 0;
		clWDUtil.bForEach(ms_tabCorrespondanceProprietesTranches, function (tabCorrespondance)
		{
			var sNomClassique = tabCorrespondance[0];
			// Copie la position "classique"
			var oNouvelleValeur = oPositionSource[sNomClassique];
			oPositionCible[sNomClassique] = oNouvelleValeur;

			// Copie la position "RWD"
			if (clWDUtil.bRWD)
			{
				var sNomTableauRWD = tabCorrespondance[1];
				var tabTableauValeurRWD = oPositionCible[sNomTableauRWD];
				// Uniquement si la cible est un widget (une position simple n'a pas les membres).
				if (tabTableauValeurRWD)
				{
					tabTableauValeurRWD[nTrancheIndiceC] = oNouvelleValeur;
				}
			}
			return true;
		});
	}
	function __s_oDupliquePosition(oPositionSource)
	{
		var oPositionCible = {};
		__s_CopiePosition(oPositionCible, oPositionSource);
		return oPositionCible;
	}

	// Indique quelle position est dans une case donn�e
	function __s_nGetPosition(tabPositions, nLigne, nColonne, nPositionIgnore)
	{
		// GP 13/02/2017 : QW282702 : L'utilisation d'un fonction priv�e est lente : le r�f�rencement des variables externes prend du temps (et doit bloquer l'optimiseur).
		// => Passage par une boucle � la main
		var nLimitePosition = tabPositions.length;
		for (var nPosition = 0; nPosition < nLimitePosition; nPosition++)
		{
			var oPosition = tabPositions[nPosition];
			if ((oPosition.m_nLigne <= nLigne)
				&& (nLigne < (oPosition.m_nLigne + oPosition.m_nHauteur))
				&& (oPosition.m_nColonne <= nColonne)
				&& (nColonne < (oPosition.m_nColonne + oPosition.m_nLargeur))
				&& oPosition.m_bVisible
				&& (nPositionIgnore != nPosition))
			{
				return nPosition;
			}
		}

		return clWDUtil.nElementInconnu;
	}

	// Fait de la place pour une position donn�e
	// nWidgetIgnore : si la position est celle d'un Widget : ignore ce widget (on ne d�place pas l'�l�ment pour lequel on fait de la place)
	// Retourne si on a d�placer un �l�ment
	__WDTdb.prototype.bFaitDeLaPlace = function bFaitDeLaPlace(tabPositions, oPositionCible, nWidgetIgnore, nNbColonnesEffectifOuUndefined)
	{
		var bDeplacement = false;

		// D�place les �l�ments adjacent pour faire de la place (�ventuellement la position lib�r�e par l'�l�ment source)
		var nLigne = oPositionCible.m_nLigne;
		var nLimiteLigne = nLigne + oPositionCible.m_nHauteur;
		for (; nLigne < nLimiteLigne; nLigne++)
		{
			var nColonne = oPositionCible.m_nColonne;
			var nLimiteColonne = nColonne + oPositionCible.m_nLargeur;
			for (; nColonne < nLimiteColonne; nColonne++)
			{
				// Trouve un �l�ment qui commence � cette position
				// GP 26/04/2018: TB103901 : Transmission de nWidgetIgnore (pour l'ignorer) : si l'on veux faire de la place pour nWidgetIgnore, et que celui-ci est d�j�
				// superpos� avec d'autres widget (cas possible pour un appel de TDBChangeTailleWidget) on peut trouve le widget a ignorer et pas l'autre widget.
				var nWidget = __s_nGetPosition(tabPositions, nLigne, nColonne, nWidgetIgnore);
				// __s_nGetPosition filtre d�j� les widget invisibles
				// GP 26/04/2018: TB103901 : Donc ici on ne peut plus avoir nWidgetIgnore puisque __s_nGetPosition l'a filtr�.
//				if ((clWDUtil.nElementInconnu != nWidget) && (nWidgetIgnore != nWidget))
				if (clWDUtil.nElementInconnu != nWidget)
				{
					tabPositions[nWidget] = this.__oGetNouvellePosition(tabPositions[nWidget], tabPositions, oPositionCible, nNbColonnesEffectifOuUndefined);
					bDeplacement = true;
				}
			}
		}

		return bDeplacement;
	};


	//////////////////////////////////////////////////////////////////////////
	// __WDTdb
	//	Acc�s pour le WL

	// TDBAffiche
	__WDTdb.prototype.Affiche = function Affiche(oFenetreInterneOuIndice)
	{
		var oWidgetExterne;
		var nWidgetExterne;
		var tabConfigCourante = this.m_oDonnees.m_tabConfigCourante;

		switch (typeof oFenetreInterneOuIndice)
		{
		case "string":
			if (clWDUtil.bForEach(tabConfigCourante, function (oWidget, nWidget)
			{
				if (oWidget.m_sNomFI == oFenetreInterneOuIndice)
				{
					oWidgetExterne = oWidget;
					nWidgetExterne = nWidget;
					return false;
				}
				return true;
			}))
			{
				// Non trouv�
				return;
			}
			break;
		case "number":
			oWidgetExterne = tabConfigCourante[oFenetreInterneOuIndice];
			nWidgetExterne = oFenetreInterneOuIndice;
			break;
		default:
			// Inclus le cas "undefined"
			clWDUtil.bForEachThis(tabConfigCourante, this, function (oWidget, nWidget)
			{
				this.__WLAfficheUnWidget(null, oWidget, nWidget);
				return true;
			});
			return;
		}

		// Cas sur un seul �l�ment
		this.__WLAfficheUnWidget(null, oWidgetExterne, nWidgetExterne);
	};

	// TDBChargeConfiguration
	__WDTdb.prototype.bChargeConfiguration = function bChargeConfiguration(sConfiguration)
	{
		// sConfiguration est une s�rialisation de this.m_oDonnees.m_tabConfigCourante
		var tabConfigNew = JSON.parse(sConfiguration);
		var tabConfigCourante = this.m_oDonnees.m_tabConfigCourante;
		var tabCouranteVersNew = new Array(tabConfigCourante.length);

		// Supprime les �l�ments invalide de tabConfigNew :
		// - Si invalide : pas de chargement
		// - Si widget qui n'existe plus : ne le charge pas
		if (!clWDUtil.bForEach(tabConfigNew, function (oWidgetNew, nWidgetNew)
		{
			// Si invalide : pas de chargement
			if (!oWidgetNew)
			{
				return false;
			}
			// Recherche dans la configuration courante
			if (clWDUtil.bForEach(tabConfigCourante, function (oWidgetOld, nWidgetOld)
			{
				// Ignore les widget d�j� compt� pour un autre
				if (undefined !== tabCouranteVersNew[nWidgetOld])
				{
					return true;
				}
				if (oWidgetOld.m_sNomFI != nWidgetOld.m_sNomFI)
				{
					// Trouve une correspondance : ne plus l'utiliser pour une nouvelle correspondance et sortir de la boucle sans ignorer le widget
					tabCouranteVersNew[nWidgetOld] = nWidgetNew;
					return false;
				}
				return true;
			}))
			{
				// Non trouv� : l'ignore
				tabConfigNew[nWidgetNew] = null;
			}

			return true;
		}))
		{
			// En cas d'�chec, ne fait rien
			return false;
		}

		// Maintenant tabConfigNew ne contient que des widget qui existent dans la configuration et qui on un widget correspondant
		// On place tout les widget correspondant en invisible
		clWDUtil.bForEach(tabConfigCourante, function (oWidgetOld, nWidgetOld)
		{
			if (undefined !== tabCouranteVersNew[nWidgetOld])
			{
				oWidgetOld.m_bVisible = false;
			}
			return true;
		});

		// Maintenant copie les coordonn�es des widgets qui ont de la place
		clWDUtil.bForEach(tabConfigCourante, function (oWidgetOld, nWidgetOld)
		{
			if (undefined !== tabCouranteVersNew[nWidgetOld])
			{
				var oWidgetNew = tabConfigNew[tabCouranteVersNew[nWidgetOld]];

				var bPlacementPossible = true;

				// Copie la position si on a de la place et que l'on demande la visibilit�
				if (oWidgetNew.m_bVisible)
				{
					var nLigne = oWidgetNew.m_nLigne;
					var nLimiteLigne = nLigne + oWidgetNew.m_nHauteur;
					for (; (nLigne < nLimiteLigne) && bPlacementPossible; nLigne++)
					{
						var nColonne = oWidgetNew.m_nColonne;
						var nLimiteColonne = nColonne + oWidgetNew.m_nLargeur;
						for (; (nColonne < nLimiteColonne) && bPlacementPossible; nColonne++)
						{
							// Trouve un �l�ment qui commence � cette position
							var nWidget = __s_nGetPosition(tabConfigCourante, nLigne, nColonne, clWDUtil.nElementInconnu);
							// __s_nGetPosition filtre d�j� les widget invisibles
							bPlacementPossible &= (clWDUtil.nElementInconnu != nWidget);
						}
					}
				}

				if (bPlacementPossible)
				{
					__s_CopiePosition(oWidgetOld, oWidgetNew);
					// Ne traitera plus le widget dans la derni�re passe
					tabCouranteVersNew[nWidgetOld] = undefined;
				}
			}
			return true;
		});

		// Ne fait rien pour les autres : ils restent a leurs place

		// Demande le redessin (y compris du mode �dition)
		// Effectue un affichage (forc� dans les pages statiques)
		// Une partie est probablement inutile : les d�placements on �t� fait par le mode �dition
		this.__AfficheInterne(clWDUtil.bPageStatique);
	};

	// TDBConfigurationInitiale
	// nX, nY, nLargeur, nHauteur : optionnel
	__WDTdb.prototype.ConfigurationInitiale = function ConfigurationInitiale(oFenetreInterneOuIndice, nX, nY, nLargeur, nHauteur)
	{
		var oWidgetExterne;
		var nWidgetExterne;
		var tabConfigCourante = this.m_oDonnees.m_tabConfigCourante;

		switch (typeof oFenetreInterneOuIndice)
		{
		case "string":
		default:
			if (clWDUtil.bForEach(tabConfigCourante, function (oWidget, nWidget)
			{
				if (oWidget.m_sNomFI == oFenetreInterneOuIndice)
				{
					oWidgetExterne = oWidget;
					nWidgetExterne = nWidget;
					return false;
				}
				return true;
			}))
			{
				// Non trouv�
				return;
			}
			break;
		case "number":
			oWidgetExterne = tabConfigCourante[oFenetreInterneOuIndice];
			nWidgetExterne = oFenetreInterneOuIndice;
			break;
		}

		if (undefined !== nX)
		{
			oWidgetExterne.m_nColonne = Math.max(Math.min(nX - 1, this.m_nNbColonnesEffectif - 1), 0);
		}
		if (undefined !== nY)
		{
			oWidgetExterne.m_nLigne = Math.max(nY - 1, 0);
		}
		if (undefined !== nLargeur)
		{
			oWidgetExterne.m_nLargeur = Math.max(Math.min(nLargeur, this.m_nNbColonnesEffectif), 1);
		}
		if (undefined !== nHauteur)
		{
			oWidgetExterne.m_nHauteur = Math.max(nHauteur, 1);
		}

		// Effectue un affichage (forc� dans les pages statiques)
		this.__AfficheInterne(clWDUtil.bPageStatique);
	};

	// TDBInfoXY
	__WDTdb.prototype.nInfoXY = function nInfoXY(nX, nY)
	{
		var nMargeX = this.m_oParametres.m_nMargeX;
		var nMargeY = this.m_oParametres.m_nMargeY;
		var nTaille1CaseXEffective = this.m_nTaille1CaseXEffective;
		var nTaille1CaseY = this.m_oParametres.m_nTaille1CaseY;
		var nTaille1CaseXAvecMarge = nMargeX + nTaille1CaseXEffective;
		var nTaille1CaseYAvecMarge = nMargeX + nTaille1CaseY;
		var nMargeXGaucheTotal = this.m_nOffsetCentrage + nMargeX;

		// Pour tous les widgets fectue un test si les coordonn�es sont dedans
		// On peut passer par le calcul du DOM mais alors on est � la merci des bugs (scroll et autre)
		var nWidgetResultat = 0;
		clWDUtil.bForEach(this.m_oDonnees.m_tabConfigCourante, function (oWidget, nWidget)
		{
			if (oWidget.m_bVisible)
			{
				// Conversion des coordonn�es du widget en pixels
				var nXWidgetDebut = (oWidget.m_nColonne - 1) * nTaille1CaseXAvecMarge + nMargeXGaucheTotal;
				var nYWidgetDebut = (oWidget.m_nLigne - 1) * nTaille1CaseYAvecMarge + nMargeY;
				var nXWidgetFin = nXWidgetDebut + (oWidget.m_nLargeur - 1) * nTaille1CaseXAvecMarge + nTaille1CaseXEffective;
				var nYWidgetFin = nYWidgetDebut + (oWidget.m_nHauteur - 1) * nTaille1CaseYAvecMarge + nTaille1CaseY;
				if ((nXWidgetDebut <= nX) && (nX <= nXWidgetFin) && (nYWidgetDebut <= nY) && (nY <= nYWidgetFin))
				{
					nWidgetResultat = nWidget;
					return false;
				}
			}
			return true;
		});

		return nWidgetResultat;
	};

	// TDBMode
	__WDTdb.prototype.SetMode = function SetMode(nMode)
	{
		var oDonnees = this.m_oDonnees;
		if (0 == nMode)
		{
			oDonnees.m_bEnModeEdition = false;
		}
		else
		{
			oDonnees.m_bRedimensionne = (0 != (nMode & ms_nRedimensionne));
			oDonnees.m_bDeplace = (0 != (nMode & ms_nDeplace));
			// Pas de constante WL pour le mode AJOUT
//			oDonnees.m_bAjoute = ...;
			oDonnees.m_bSupprime = (0 != (nMode & ms_nRedimensionne));
			oDonnees.m_bEnModeEdition = oDonnees.m_bRedimensionne || oDonnees.m_bDeplace;
		}

		// Affiche le mode �dition
		this.__AfficheModeEdition();
	};
	__WDTdb.prototype.nGetMode = function nGetMode()
	{
		var oDonnees = this.m_oDonnees;
		return (oDonnees.m_bRedimensionne ? ms_nRedimensionne : 0)
			+ (oDonnees.m_bDeplace ? ms_nDeplace : 0)
			// Pas de constante WL pour le mode AJOUT
//			+ (oDonnees.m_bAjoute ? this.ms_nAjoute : 0)
			+ (oDonnees.m_bSupprime ? ms_nSupprime : 0);
	};

	// TDBOccurrence
	__WDTdb.prototype.nOccurrence = function nOccurrence(nOptions)
	{
		switch (nOptions)
		{
		case 1:
			// toTotal
			return this.m_oDonnees.m_tabConfigCourante.length;
		case 4:
			// toAffich�e
			var nCompte = 0;
			clWDUtil.bForEach(this.m_oDonnees.m_tabConfigCourante, function (oWidget)
			{
				if (oWidget.m_bVisible)
				{
					nCompte++;
				}
				return true;
			});
			return nCompte;
		default:
			return 0;
		}
	};

	// TDBSauveConfiguration
	__WDTdb.prototype.sSauveConfiguration = function sSauveConfiguration()
	{
		// Conversion de la configuration courante en tableau avec uniquement
		return JSON.stringify(this.m_oDonnees.m_tabConfigCourante);
	};

	// TDBChangeTailleWidget
	// nOptions : optionnel
	__WDTdb.prototype.s_ChangeTailleWidget = function s_ChangeTailleWidget(oChamp, nLargeur, nHauteur, nOptions)
	{
		// Trouve le champ Tdb qui inclus le champ
		// GP 28/08/2017 : TB104843 : __s_AppelChangeTailleDeplace transmet un indice C : appel direct de la m�thode interne
		WDChamp.prototype._AppelMethodePtr(__WDTdb.prototype.__s_AppelChangeTailleDeplace, [oChamp, __WDTdb.prototype.__ChangeTailleWidget, [nLargeur, nHauteur, nOptions]]);
	};
	__WDTdb.prototype.ChangeTailleWidget = function ChangeTailleWidget(nWidgetWL, nLargeur, nHauteur, nOptions)
	{
		// GP 28/08/2017 : TB104843 : Il faut passer des indices WL au indices C
		this.__ChangeTailleWidget(nWidgetWL - 1, nLargeur, nHauteur, nOptions);
	};
	__WDTdb.prototype.__ChangeTailleWidget = function __ChangeTailleWidget(nWidgetC, nLargeur, nHauteur, nOptions)
	{
		var tabConfigCourante = this.m_oDonnees.m_tabConfigCourante;

		var nLargeurCases;
		var nHauteurCases;

		// Si la taille est en pixel : d�code
		if (0 != (nOptions & 0x1))
		{
			nLargeurCases = 1;
			nHauteurCases = 1;
			// Si on a moins d'une case ne fait rien
			var nTaille1CaseXEffective = this.m_nTaille1CaseXEffective;
			if (nTaille1CaseXEffective < nLargeur)
			{
				nLargeurCases += Math.round((nLargeur - nTaille1CaseXEffective) / (nTaille1CaseXEffective + this.m_oParametres.m_nMargeX));
			}
			var nTaille1CaseY = this.m_oParametres.m_nTaille1CaseY;
			if (nTaille1CaseY < nHauteur)
			{
				nHauteurCases += Math.round((nHauteur - nTaille1CaseY) / (nTaille1CaseY + this.m_oParametres.m_nMargeY));
			}
		}
		else
		{
			nLargeurCases = nLargeur;
			nHauteurCases = nHauteur;
		}

		// Change la taille du widget
		var oWidget = tabConfigCourante[nWidgetC];
		// GP 26/04/2018 : Vu avec TB103901 : Ici il faut prendre le max du nombre de colonne qui restent.
		oWidget.m_nLargeur = Math.max(Math.min(nLargeurCases, this.m_nNbColonnesEffectif - oWidget.m_nColonne), 1);
		oWidget.m_nHauteur = Math.max(nHauteurCases, 1);

		// Si on demande la r�organisation : fait de la place
		var bReaffiche = clWDUtil.bPageStatique;
		if (0 == (nOptions & 0x2))
		{
			bReaffiche = this.bFaitDeLaPlace(tabConfigCourante, oWidget, nWidgetC) || bReaffiche;
		}

		// Demande le redessin (y compris du mode �dition)
		// Effectue un affichage (forc� dans les pages statiques)
		// Une partie est probablement inutile : les d�placements on �t� fait par le mode �dition
		this.__AfficheInterne(bReaffiche);
	};

	// TDBDeplaceWidget
	// nOptions : optionnel
	__WDTdb.prototype.s_DeplaceWidget = function s_DeplaceWidget(oChamp, nX, nY, nOptions)
	{
		// Trouve le champ Tdb qui inclus le champ
		// GP 28/08/2017 : TB104843 : __s_AppelChangeTailleDeplace transmet un indice C : appel direct de la m�thode interne
		WDChamp.prototype._AppelMethodePtr(__WDTdb.prototype.__s_AppelChangeTailleDeplace, [oChamp, __WDTdb.prototype.__DeplaceWidget, [nX, nY, nOptions]]);
	};
	__WDTdb.prototype.DeplaceWidget = function DeplaceWidget(nWidgetWL, nX, nY, nOptions)
	{
		// GP 28/08/2017 : TB104843 : Il faut passer des indices WL au indices C
		this.__DeplaceWidget(nWidgetWL - 1, nX, nY, nOptions);
	};
	__WDTdb.prototype.__DeplaceWidget = function __DeplaceWidget(nWidgetC, nX, nY, nOptions)
	{
		var tabConfigCourante = this.m_oDonnees.m_tabConfigCourante;

		var nXCases;
		var nYCases;

		// Si la taille est en pixel : d�code
		if (0 != (nOptions & 0x1))
		{
			// Commence par retirer le centrage
			nX -= this.m_nOffsetCentrage;
			// Et la premi�re marge
			nX -= this.m_oParametres.m_nMargeX;
			nY -= this.m_oParametres.m_nMargeY;

			nXCases = Math.round(nX / (this.m_nTaille1CaseXEffective + this.m_oParametres.m_nMargeX));
			nYCases = Math.round(nY / (this.m_oParametres.m_nTaille1CaseY + this.m_oParametres.m_nMargeY));
		}
		else
		{
			nXCases = nX - 1;
			nYCases = nY - 1;
		}

		// Change la taille du widget
		var oWidget = tabConfigCourante[nWidgetC];
		oWidget.m_nColonne = Math.max(Math.min(nXCases, this.m_nNbColonnesEffectif - 1), 0);
		oWidget.m_nLigne = Math.max(nYCases, 0);

		// Si on demande la r�organisation : fait de la place
		var bReaffiche = clWDUtil.bPageStatique;
		if (0 == (nOptions & 0x2))
		{
			bReaffiche = this.bFaitDeLaPlace(tabConfigCourante, oWidget, nWidgetC) || bReaffiche;
		}

		// Demande le redessin (y compris du mode �dition)
		// Effectue un affichage (forc� dans les pages statiques)
		// Une partie est probablement inutile : les d�placements on �t� fait par le mode �dition
		this.__AfficheInterne(bReaffiche);
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	WDTdbModeEdition
	//		Gestion du mode �dition du tdb

	function __WDTdbModeEdition(oTdb, bDeplace, bRedimensionne)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDDrag.prototype.constructor.apply(this, [0, 50]);

			this.m_oTdb = oTdb;
			this.m_bAnnuleOnDragExit = false;

			// Cr�ation du tableau des �l�ments pour les widget visible (mais sans les placer)
			var oThis = this;
			var tabElements = [];
			clWDUtil.bForEach(oTdb.m_oDonnees.m_tabConfigCourante, function (oWidget, nWidget)
			{
				tabElements.push(new __WDDnDElementModeEditionWidget(oThis, nWidget, bDeplace, bRedimensionne));
				return true;
			});
			this.m_tabElements = tabElements;
			this.m_tabElementsVides = [];
			this.m_oRedimensionnement = null;

			// GP 18/09/2014 : QW248286 : Place ou pas la classe qui affiche le curseur de redimensionnement
			clWDUtil.ActiveDesactiveClassName(oTdb.m_oHote, "wbTdbRedim", bRedimensionne);

			// Effectue le premier dessin en utilisant la configuration courante comme base
			// Avec cr�ation de la configuration depuis la configuration g�n�rale
			this.m_tabAffichageCourant = [];
			this.__Affiche(true);
		}
	}

	// Declare l'heritage
	__WDTdbModeEdition.prototype = new WDDrag();
	// Surcharge le constructeur qui a ete efface
	__WDTdbModeEdition.prototype.constructor = __WDTdbModeEdition;

//	var ms_eAutoriseNon = 0;
//	var ms_eAutorisePlus = 1;
//	var ms_eAutoriseMoins = 2;
//	var ms_eAutorisePlusMoins = 3;

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	WDTdbModeEdition
	//		Impl�mentation des m�thodes de WDDrag

	// Appel lors du debut d'un clic pour le deplacement
	// Pose les hooks
	__WDTdbModeEdition.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent, nWidget, oVariationX, oVariationY, sCurseur)
	{
		// Appel de la classe de base : sauve la position de la souris et place les hooks
		if (!WDDrag.prototype._vbOnMouseDown.apply(this, arguments))
		{
			return false;
		}

		// Normalement on n'a pas d'informations d'un pr�c�dent redimensionnement. Lib�re au cas ou.
		if (this.m_oRedimensionnement)
		{
			this.__LibereRedimensionnement();
		}

		// Allocation d'un nouveau redimensionnement
		this.m_oRedimensionnement =
			{
				m_sCurseurBody: document.body.style.cursor,
				m_nWidget: nWidget,
				m_oVariationX: oVariationX,
				m_oVariationY: oVariationY,
				m_nOffsetGrilleXDernier: 0,
				m_nOffsetGrilleYDernier: 0
			};
		// Change le curseur de souris du body
		document.body.style.cursor = sCurseur + " !important";
	};

	// Si on active le filtrage du mousemove sans boutons
	__WDTdbModeEdition.prototype._vbFiltrePremierMouseMove = clWDUtil.m_pfVide;

	// Appel lors du deplacement de la souris
	__WDTdbModeEdition.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
	{
		// Appel de la classe de base
		WDDrag.prototype._vOnMouseMove.apply(this, arguments);

		var oRedimensionnement = this.m_oRedimensionnement;
		var oVariationX = oRedimensionnement.m_oVariationX;
		var oVariationY = oRedimensionnement.m_oVariationY;

		var oTdb = this.m_oTdb;
		var oParametres = oTdb.m_oParametres;

		// Calcule la variation sur chaque axe et la place entre les bornes
		// Calcule le redimensionnement de l'�l�ment : arrondi de la valeur de dimension selon le pas (taille des cellules)
		// => On agrandi/r�tr�ci a la moitie de la distance parcourue
		var nOffsetGrilleX = 0;
		var nOffsetGrilleY = 0;
		if (oVariationX)
		{
			var nOffsetX = Math.max(Math.min(this.nGetOffsetPosX(oEvent), oVariationX.m_nMax), oVariationX.m_nMin);
			var nPasX = oParametres.m_nMargeX + oTdb.m_nTaille1CaseXEffective;
			nOffsetGrilleX = Math.round(nOffsetX / nPasX);
		}
		if (oVariationY)
		{
			var nOffsetY = Math.max(Math.min(this.nGetOffsetPosY(oEvent), oVariationY.m_nMax), oVariationY.m_nMin);
			var nPasY = oParametres.m_nMargeY + oParametres.m_nTaille1CaseY;
			nOffsetGrilleY = Math.round(nOffsetY / nPasY);
		}

		// Fait une MAJ graphique si on a un changement
		if ((nOffsetGrilleX != oRedimensionnement.m_nOffsetGrilleXDernier) || (nOffsetGrilleY != oRedimensionnement.m_nOffsetGrilleYDernier))
		{
			// Repart de la configuration initiale
			this.__RAZAffichageCourant();

			// On travaille avec une position temporaire sinon la recherche dans les widget risque de nous trouver
			var oPosition = __s_oDupliquePosition(this.m_tabAffichageCourant[oRedimensionnement.m_nWidget]);

			// D�place l'�l�ment
			if (oVariationX)
			{
				if (oVariationX.m_bBasOuDroite)
				{
					oPosition.m_nLargeur += nOffsetGrilleX;
				}
				else
				{
					oPosition.m_nLargeur -= nOffsetGrilleX;
					oPosition.m_nColonne += nOffsetGrilleX;
				}
				oRedimensionnement.m_nOffsetGrilleXDernier = nOffsetGrilleX;
			}
			if (oVariationY)
			{
				if (oVariationY.m_bBasOuDroite)
				{
					oPosition.m_nHauteur += nOffsetGrilleY;
				}
				else
				{
					oPosition.m_nHauteur -= nOffsetGrilleY;
					oPosition.m_nLigne += nOffsetGrilleY;
				}
				oRedimensionnement.m_nOffsetGrilleYDernier = nOffsetGrilleY;
			}

			// D�place les �l�ments adjacent pour faire de la place (�ventuellement la position lib�r�e par l'�l�ment source)
			oTdb.bFaitDeLaPlace(this.m_tabAffichageCourant, oPosition, oRedimensionnement.m_nWidget);

			// Et finalement d�place l'�l�ment
			__s_CopiePosition(this.m_tabAffichageCourant[oRedimensionnement.m_nWidget], oPosition);

			// Fait une MAJ graphique si besoin
			this.__Affiche(false, true);
		}
	};

	// Appel lors du relachement de la souris
	__WDTdbModeEdition.prototype._vOnMouseUp = function _vOnMouseUp(oEvent)
	{
		// La configuration courante est valide (modifi�e sur le survol).

		// Notifie le champ de la nouvelle configuration :
		// - Copie la configuration temporaire dans la configuration g�n�rale
		// - Ex�cution des PCodes serveur et navigateur
		this.m_oTdb.OnChangementConfiguration(oEvent, this.m_tabAffichageCourant, this.m_oRedimensionnement.m_nWidget, true);

		// Replace le curseur de souris original du body et supprime les options de redimensionnement
		this.__LibereRedimensionnement();

		// Force un redessin : va recr�er un �l�ment vide que la suite du DnD va permettre d'identifier la cellule
		this.__Affiche(true);

		// Appel de la classe de base
		WDDrag.prototype._vOnMouseUp.apply(this, arguments);
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	WDTdbModeEdition
	//		M�thodes internes g�n�rales

	// Reset de la configuration
	__WDTdbModeEdition.prototype.__RAZAffichageCourant = function __RAZAffichageCourant()
	{
		var tabAffichageCourant = this.m_tabAffichageCourant;

		clWDUtil.VideTableau(tabAffichageCourant);
		clWDUtil.bForEach(this.m_oTdb.m_oDonnees.m_tabConfigCourante, function (oWidget/*, nWidget*/)
		{
			tabAffichageCourant.push(__s_oDupliquePosition(oWidget));
			return true;
		});
	};

	// Dessin en utilisant la configuration courante comme base
	__WDTdbModeEdition.prototype.__Affiche = function __Affiche(bRAZ, bDansRedimensionnement)
	{
		if (bRAZ)
		{
			this.__RAZAffichageCourant();
		}

		var oTdb = this.m_oTdb;
		var tabAffichageCourant = this.m_tabAffichageCourant;

		// Pr�pare le positionnement : recalcule les dimensions et calcule les classes CSS pour le positionnement
		// (Pour le cas ou le nombre de ligne �ffectivement affich� a chang�)
		oTdb.PreparePositionnement(tabAffichageCourant);

		// Pour que le dessin ne clignote pas : on ne d�place pas les �l�ments vides si possible
		// On construit donc un second tableau des �l�ments vide et l'on d�place les �l�ments si possible
		var tabElementsVidesPrecedent = this.m_tabElementsVides;
		this.m_tabElementsVides = [];
		var tabElementsVides = this.m_tabElementsVides;

		// Normalement this.m_tabElements est d�j� initialis�;
		var tabElements = this.m_tabElements;

		// Construit la liste des �l�ments (un par widget) pour connaitre en sortie ceux qui doivent �tre masqu�s
		// => Non on masque tout : sauf si on est dans un redimensionnement, on l'on ne veux pas perdre le lien OnXxx sur les objets JS
		if (!bDansRedimensionnement)
		{
			clWDUtil.bForEach(tabElements, function (oElement/*, nWidget*/)
			{
				oElement.vMasque();
				// Normalement nWidget == oElement.m_nWidget car les deux tableaux sont indic� pareil.
				oTdb.bMasqueUnWidget(oElement.m_nWidget);
				return true;
			});
		}

		var nNbLignes = oTdb.m_nNbLignesVisiblesEffectif;
		var nNbColonnes = oTdb.m_nNbColonnesEffectif;

		// Construit la liste des cellules utilis�es
		// Acc�s par nLigne * nNbColonnes + nColonne
		var tabCellules = new Array(nNbLignes * nNbColonnes);
		var nLigne;
		for (nLigne = 0; nLigne < nNbLignes; nLigne++)
		{
			var nColonne;
			for (nColonne = 0; nColonne < nNbColonnes; nColonne++)
			{
				// Si la cellule est d�j� occup� (par un widget plus grand rencontr� pr�c�dement)
				if (tabCellules[nLigne * nNbColonnes + nColonne])
				{
					continue;
				}

				// La cellule n'est pas d�j� occup�e : regarde si on a un widget � ces coordonn�es
				var nWidget = __s_nGetPosition(this.m_tabAffichageCourant, nLigne, nColonne, clWDUtil.nElementInconnu);
				// nGetPosition filtre d�j� les widget invisibles
				if (clWDUtil.nElementInconnu != nWidget)
				{
					var oPosition = tabAffichageCourant[nWidget];
					// D�place le masque � cette position
					tabElements[nWidget].vAffiche(oPosition.m_nLigne, oPosition.m_nColonne, oPosition.m_nLargeur, oPosition.m_nHauteur, bDansRedimensionnement);
					oTdb.bAfficheUnWidget(oPosition, nWidget);

					// Marque les cellules comme occup�e (y compris la premi�re cellule (elle ne sera jamais relue mais cela permet de garder l'algo simple))
					var nLigneOccupee;
					var nLigneOccupeeLimite = nLigne + oPosition.m_nHauteur;
					for (nLigneOccupee = nLigne; nLigneOccupee < nLigneOccupeeLimite; nLigneOccupee++)
					{
						var nColonneOccupee;
						var nColonneOccupeeLimite = nColonne + oPosition.m_nLargeur;
						for (nColonneOccupee = nColonne; nColonneOccupee < nColonneOccupeeLimite; nColonneOccupee++)
						{
							tabCellules[nLigneOccupee * nNbColonnes + nColonneOccupee] = true;
						}
					}
				}
				else
				{
					// Il n'y a pas de widget : recherche un �l�ment vide d�j� construit
					var nPositionVide = __s_nGetPosition(tabElementsVidesPrecedent, nLigne, nColonne, clWDUtil.nElementInconnu);
					if (clWDUtil.nElementInconnu != nPositionVide)
					{
						// Supprime l'�l�ment du tableau tabElementsVidesPrecedent pour ne pas le lib�rer � la fin
						// Et le place dans le nouveau tableau
						// [0] car splice retourne un tableau des �l�ments supprim�s (ici 1 seul)
						tabElementsVides.push(tabElementsVidesPrecedent.splice(nPositionVide, 1)[0]);
					}
					else
					{
						// Il n'y a pas de widget : construit une cellule vide
						var oDnDElementModeEdition = new __WDDnDElementModeEditionVide(this, tabElementsVides.length);
						oDnDElementModeEdition.vAffiche(nLigne, nColonne, 1, 1, bDansRedimensionnement);
						tabElementsVides.push(oDnDElementModeEdition);
					}
				}
			}
		}

		// Lib�re les �l�ments vide qui n'ont pas �t� utilis� (arrive si on d�place un �l�ment)
		__s_LibereElements(tabElementsVidesPrecedent);
	};

	// Lib�re une s�rie d'�l�ments
	function __s_LibereElements(tabElements)
	{
		// Vide le tableau qui est une r�f�rence et supprime du DOM au passage
		while (0 < tabElements.length)
		{
			tabElements.pop().vLibereElement();
		}
	}

	// Fin d'un redimensionnement
	__WDTdbModeEdition.prototype.__LibereRedimensionnement = function __LibereRedimensionnement()
	{
		// Replace le curseur de souris original du body
		document.body.style.cursor = this.m_oRedimensionnement.m_sCurseurBody;

		// Supprime les options de redimensionnement
		this.m_oRedimensionnement = null;
	};

	// Survol d'un widget
	__WDTdbModeEdition.prototype.__bOnDragSurvolWidget = function __bOnDragSurvolWidget(oDnDSource, oPositionCibleReelle)
	{
		var nWidgetSource = oDnDSource.m_nWidget;
		var nWidgetCible = oPositionCibleReelle.m_nWidget;
		var oPositionSource = this.m_tabAffichageCourant[nWidgetSource];
		// Construit la position possible
		var oPositionCible = {
			m_bVisible: true,
			m_nLigne: oPositionCibleReelle.m_nLigne,
			m_nColonne: oPositionCibleReelle.m_nColonne,
			m_nLargeur: oPositionSource.m_nLargeur,
			m_nHauteur: oPositionSource.m_nHauteur
		};

		// Si on n'est plus au dessus de l'�l�ment source, le rend invisible, cela permettra de d�placer d'autres �l�ments � sa place actuelle
		var bRes = true;
		if (nWidgetSource != nWidgetCible)
		{
			// Masque l'�l�ment source (rend invisible)
			oPositionSource.m_bVisible = false;
		}
		else
		{
			// Ne traite plus les autres �l�ments
			bRes = false;
		}

		// D�place les �l�ments adjacent pour faire de la place (�ventuellement la position lib�r�e par l'�l�ment source)
		this.m_oTdb.bFaitDeLaPlace(this.m_tabAffichageCourant, oPositionCible, nWidgetSource);

		// Force un redessin : va recr�er un �l�ment vide que la suite du DnD va permettre d'identifier la cellule
		this.__Affiche(false);

		this.m_bAnnuleOnDragExit = true;

		return bRes;
	};

	// Survol d'un �l�ment vide
	__WDTdbModeEdition.prototype.__bOnDragSurvolVide = function __bOnDragSurvolVide(oDnDSource, oPositionCibleReelle)
	{
		// Ne fait un redessin que si on change quelque chose
		var bRedessin = false;

		// Masque l'�l�ment source (rend invisible)
		var nWidgetSource = oDnDSource.m_nWidget;
		var oPositionSource = this.m_tabAffichageCourant[nWidgetSource];
		if (oPositionSource.m_bVisible)
		{
			oPositionSource.m_bVisible = false;
			bRedessin = true;
		}

		// Interdit la position de la cible
		var oPositionCible = {
			m_nLigne: oPositionCibleReelle.m_nLigne,
			m_nColonne: oPositionCibleReelle.m_nColonne,
			m_nLargeur: oPositionSource.m_nLargeur,
			m_nHauteur: oPositionSource.m_nHauteur
		};

		// D�place les �l�ments adjacent pour faire de la place (�ventuellement la position lib�r�e par l'�l�ment source)
		// Logiquement nWidgetSource est inutile (il a �t� rendu invisible)
		if (this.m_oTdb.bFaitDeLaPlace(this.m_tabAffichageCourant, oPositionCible, nWidgetSource))
		{
			bRedessin = true;
		}

//		// Reaffiche l'�l�ment source (il est en DnD, il est forc�ment visible)
//		oPositionSource.m_bVisible = true;

		if (bRedessin)
		{
			// Force un redessin : va recr�er un �l�ment vide que la suite du DnD va permettre d'identifier la cellule
			this.__Affiche(false);
		}

		return true;
	};

	// Factorisation des OnXxx
	__WDTdbModeEdition.prototype.__OnDnDAnnule = function __OnDnDAnnule(/*oDnDSource*//*, tabPositionsCibleReelle*/)
	{
		this.m_bAnnuleOnDragExit = false;

		// Reaffiche la configuration courante du TDB
		this.__Affiche(true);
	};

	// Calcule l'objet cible du drop en fonction des offsets relatif (diff�rence des offset dans la source et dans la cible)
	// Retourne une position avec en plus un m_nWidget qui indique si on cible un widget ou une cellule vide
	// Les autres �l�ments affect� par le drop sont apr�s dans le tableau
	__WDTdbModeEdition.prototype.__tabGetPositionsCibleReelle = function __tabGetPositionsCibleReelle(oDnDSource, oDnDCible)
	{
		// Si on est sur nous m�me, on n'a pas de dest tant que ce n'est pas valide
		if (undefined === oDnDCible.m_oOffsetDernierDnDDest)
		{
			return [];
		}

		var oTdb = this.m_oTdb;
		var oOffsetDernierDnDSrc = oDnDSource.m_oOffsetDernierDnDSrc;
		var oOffsetDernierDnDDest = oDnDCible.m_oOffsetDernierDnDDest;

		// Calcule la diff�rence des offsets
		clWDUtil.WDDebug.assert(oDnDSource, "oDnDSource");
		clWDUtil.WDDebug.assert(oDnDCible, "oDnDCible");
		clWDUtil.WDDebug.assert(undefined !== oOffsetDernierDnDSrc.m_nCelluleX, "undefined !== oOffsetDernierDnDSrc.m_nCelluleX");
		clWDUtil.WDDebug.assert(undefined !== oOffsetDernierDnDSrc.m_nCelluleY, "undefined !== oOffsetDernierDnDSrc.m_nCelluleY");
		clWDUtil.WDDebug.assert(undefined !== oOffsetDernierDnDDest.m_nCelluleX, "undefined !== oOffsetDernierDnDDest.m_nCelluleX");
		clWDUtil.WDDebug.assert(undefined !== oOffsetDernierDnDDest.m_nCelluleY, "undefined !== oOffsetDernierDnDDest.m_nCelluleY");

		// Conversion en offset de nombre de colonnes et de lignes
		// Le probl�me est que les offsets sont centr�es : l'offset 0 est au milieu d'une cellule : on d�cale d'une demi cellule
		// => Mais pas besoin, le Math.round fait exactement cela
		var nOffsetColonnes = oOffsetDernierDnDDest.m_nCelluleX - oOffsetDernierDnDSrc.m_nCelluleX;
		var nOffsetLignes = oOffsetDernierDnDDest.m_nCelluleY - oOffsetDernierDnDSrc.m_nCelluleY;
		// On ne va pas trop a gauche, a droite ou en haut
		var nColonneInitiale = Math.min(Math.max(0, oDnDCible.m_nColonne + nOffsetColonnes), oTdb.m_nNbColonnesEffectif - 1);
		var nLigneInitiale = Math.max(0, oDnDCible.m_nLigne + nOffsetLignes);

		var nLimiteColonne = nColonneInitiale + oDnDSource.m_nLargeur;
		var nLimiteLigne = nLigneInitiale + oDnDSource.m_nHauteur;

		var tabPositionsCibleReelle = [];
		var tabWidgets = [];
		for (var nLigne = nLigneInitiale; nLigne < nLimiteLigne; nLigne++)
		{
			for (var nColonne = nColonneInitiale; nColonne < nLimiteColonne; nColonne++)
			{
				// Construit un pseudo �l�ment (position + m_nWidget)
				var oPositionCibleReelle = {
					m_nLigne: nLigne,
					m_nColonne: nColonne,
					m_nLargeur: 1,
					m_nHauteur: 1
				};

				// Trouve l'�l�ment � cet endroit.
				var nWidget = __s_nGetPosition(this.m_tabAffichageCourant, nLigne, nColonne, clWDUtil.nElementInconnu);
				// nGetPosition filtre d�j� les widget invisibles
				// Evite de faire deux positions avec le m�me num�ro de widget.
				if ((clWDUtil.nElementInconnu != nWidget) && !clWDUtil.bDansTableau(tabWidgets, nWidget))
				{
					oPositionCibleReelle.m_nWidget = nWidget;
					tabWidgets.push(nWidget);
				}
				tabPositionsCibleReelle.push(oPositionCibleReelle);
			}
		}

		// Et le retourne
		return tabPositionsCibleReelle;
	};

	//////////////////////////////////////////////////////////////////////////
	// WDTdbModeEdition
	//	Interface des tableaux de bord
	//		Appel depuis __WDTdb

	// Fin du mode �dition
	__WDTdbModeEdition.prototype.Fin = function Fin()
	{
		__s_LibereElements(this.m_tabElements);
		__s_LibereElements(this.m_tabElementsVides);
	};

	//////////////////////////////////////////////////////////////////////////
	// WDTdbModeEdition
	//	Interface des tableaux de bord
	//		Appel depuis __WDDnDElementModeEdition

	// Attache le DnD sur un �l�ment d'un widget
	// Retourne la m�thode qui a �t� associ� � mousedown (pour la lib�ration)
	__WDTdbModeEdition.prototype.fAttacheUnRedimensionnement = function fAttacheUnRedimensionnement(oElement, nWidget, oVariationX, oVariationY, sCurseur)
	{
		// Construit la m�thode
		var oThis = this;
		var fOnMouseDown = (function (oEvent) { return oThis.bOnMouseDown(oEvent || event, nWidget, oVariationX, oVariationY, sCurseur) ? oThis._bStopPropagation(oEvent) : true; });
		this._AttacheDetacheMouseDown(true, oElement, fOnMouseDown);
		return fOnMouseDown;
	};

	// D�tache le DnD sur un �l�ment d'un widget
	__WDTdbModeEdition.prototype.DetacheUnRedimensionnement = function DetacheUnRedimensionnement(oElement, fOnMouseDown)
	{
		this._AttacheDetacheMouseDown(false, oElement, fOnMouseDown);
	};

	// Notifie de l'op�ration de drop interdite
	__WDTdbModeEdition.prototype.OnOperationSurDropSans = function OnOperationSurDropSans(oDnDSource, oDnDCible)
	{
		// Calcule l'objet cible du drop en fonction des offsets relatif (diff�rence des offset dans la source et dans la cible)
		var tabPositionsCibleReelle = this.__tabGetPositionsCibleReelle(oDnDSource, oDnDCible);

		this.__OnDnDAnnule(oDnDSource, tabPositionsCibleReelle);
	};

	// GP 09/09/2014 : QW247840 : Ajoute le test que l'on est pas trop a droite
	__WDTdbModeEdition.prototype.bColonneValidePourLargeur = function bColonneValidePourLargeur(oDnDSource, oDnDCible)
	{
		// Calcule l'objet cible du drop en fonction des offsets relatif (diff�rence des offset dans la source et dans la cible)
		var tabPositionsCibleReelle = this.__tabGetPositionsCibleReelle(oDnDSource, oDnDCible);
		var oPositionCibleReelle = tabPositionsCibleReelle[0];

		var oPositionSource = this.m_tabAffichageCourant[oDnDSource.m_nWidget];

		// V�rifie que la colonne de drop est valide (que le drop ne va pas mettre le widget trop a droite ce qui va le faire d�border
		// On ne fait le d�placement que si la position cible est valide.
		// La position cible est valide si on a assez de colonnes pour afficher le widget
		return this.m_oTdb.bColonneValidePourLargeur(oPositionCibleReelle.m_nColonne, oPositionSource.m_nLargeur);
	};

	// Survol : a cause du changement de cible (calcul de la cible r�elle en fonction des divers offsets) on ne connait pas le type a priori
	__WDTdbModeEdition.prototype.OnDragSurvol = function OnDragSurvol(oDnDSource, oDnDCible)
	{
		// Calcule l'objet cible du drop en fonction des offsets relatif (diff�rence des offset dans la source et dans la cible)
		var tabPositionsCibleReelle = this.__tabGetPositionsCibleReelle(oDnDSource, oDnDCible);

		clWDUtil.bForEachThis(tabPositionsCibleReelle, this, function (oPositionCibleReelle, nPosition)
		{
			if (undefined !== oPositionCibleReelle.m_nWidget)
			{
				return this.__bOnDragSurvolWidget(oDnDSource, oPositionCibleReelle);
			}
			// Seulement sur le premier vide, on peut ignorer les autres
			else if (0 == nPosition)
			{
				return this.__bOnDragSurvolVide(oDnDSource, oPositionCibleReelle);
			}
		});
	};

	// On sort du sorvol d'un �l�ment
	__WDTdbModeEdition.prototype.OnDragExit = function OnDragExit(oDnDSource, oDnDCible)
	{
		// Calcule l'objet cible du drop en fonction des offsets relatif (diff�rence des offset dans la source et dans la cible)
		var tabPositionsCibleReelle = this.__tabGetPositionsCibleReelle(oDnDSource, oDnDCible);

		// Dans __bOnDragSurvolWidget, on remplace le widget d�plac� par un widget vide, cela d�clenche un OnDragExit, qui force le r�affichage de la configuration de base
		// Or on ne veux pas (clignotement + c'est faux)
		// => On fait le dessin dans un timeout que l'on annule dans __bOnDragSurvolVide et (par s�curit�) dans __bOnDragSurvolWidget

		if (!this.m_bAnnuleOnDragExit)
		{
			this.__OnDnDAnnule(oDnDSource, tabPositionsCibleReelle);
		}
		else
		{
			this.m_bAnnuleOnDragExit = false;
		}
	};

	// Lach� sur un �l�ment valide
	__WDTdbModeEdition.prototype.OnDrop = function OnDrop(oDnDSource, oDnDCible)
	{
		var oEvent = oDnDCible.m_oEvent;

		// Calcule l'objet cible du drop en fonction des offsets relatif (diff�rence des offset dans la source et dans la cible)
		var tabPositionsCibleReelle = this.__tabGetPositionsCibleReelle(oDnDSource, oDnDCible);
		if (tabPositionsCibleReelle && tabPositionsCibleReelle.length)
		{
			var oPositionCibleReelle = tabPositionsCibleReelle[0];
			var oPositionSource = this.m_tabAffichageCourant[oDnDSource.m_nWidget];

			// Ne fait rien en cas de DnD de la colonne sur elle m�me (= pas de d�placement)
			// On ne bloque pas plus t�t pour ne pas perturber l'utilisateur final avec une interdiction en d�but de DnD
			var bChangement;
			if (oDnDCible !== oDnDSource)
			{
				// La configuration courante est valide (modifi�e sur le survol).
				bChangement = true;
			}
			else
			{
				bChangement = (oPositionSource.m_nColonne != oPositionCibleReelle.m_nColonne) || (oPositionSource.m_nLigne != oPositionCibleReelle.m_nLigne);
			}

			if (false != bChangement)
			{
				// Il faut quand m�me r�afficher le widget (masqu� pendant le DnD) et le d�placer
				oPositionSource.m_bVisible = true;
				oPositionSource.m_nColonne = oPositionCibleReelle.m_nColonne;
				oPositionSource.m_nLigne = oPositionCibleReelle.m_nLigne;

				// Notifie le champ de la nouvelle configuration :
				// - Copie la configuration temporaire dans la configuration g�n�rale
				// - Ex�cution des PCodes serveur et navigateur
				this.m_oTdb.OnChangementConfiguration(oEvent, this.m_tabAffichageCourant, oDnDSource.m_nWidget, false);
			}
		}

		// Fin du DnD : Affiche la configuration courante du TDB (pour au moins avoir un retour visuel)
		this.__OnDnDAnnule(oDnDSource, tabPositionsCibleReelle);
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEdition
	//		Gestion d'un �l�ments en mode �dition

	function __WDDnDElementModeEdition(oTdbModeEdition, oModele, nSource, nIndice)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			if (bTouch)
			{
				new WDDragDnDNatifEmule(this);
			}

			// Construit l'�l�ment selon le mod�le
			var oElement = oModele.cloneNode(true);
			oElement.id = oModele.id + "_" + nIndice;
			// Ne positionne ni n'affiche l'�l�ment (il est display:none par d�faut)
			// Ajoute l'�l�ment
			oElement = oTdbModeEdition.m_oTdb.m_oHote.appendChild(oElement);

			// Par d�faut l'�l�ment d�placable est l'�lement
			// Sauf si on demande un sous �l�ment particulier (cas des widget)
			var oElementDnD = clWDUtil.tabGetElementsByClass(oElement, "wbTdbME")[0] || oElement;

			// nSource : 1 si source (widget), 0 sinon (vide)
			// nCible : 1 si cible (toujours
			// Appel le constructeur de la classe de base
			WDDnDNatif.prototype.constructor.apply(this, [nSource, 1, oElementDnD, this.ms_nOperationDeplacement]);

			// M�morise les informations
			this.m_oTdbModeEdition = oTdbModeEdition;
			this.m_sModeleClasses = oModele.className;
			this.m_oElement = oElement;
			this.m_oElementDnD = oElementDnD;
		}
	}

	// Declare l'heritage
	__WDDnDElementModeEdition.prototype = new WDDnDNatif();
	// Surcharge le constructeur qui a ete efface
	__WDDnDElementModeEdition.prototype.constructor = __WDDnDElementModeEdition;

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEdition
	//		Impl�mentation des m�thodes de WDDnDNatif

	// Operation de mouvement de la sourie
	__WDDnDElementModeEdition.prototype._vnGetOperationSurDrop = function _vnGetOperationSurDrop(nDnDOperation)
	{
		var oDnDSource = this.ms_oDnDSource;
		// Si la source n'est pas une de nos DnD
		// instanceof g�re le cas undefined
		// On ne bloque maintenant le DnD sur nous m�me pour ne pas perturber l'utilisateur final avec une interdiction en d�but de DnD
		if (!(oDnDSource instanceof __WDDnDElementModeEdition) || (this.m_oTdbModeEdition !== oDnDSource.m_oTdbModeEdition))
		{
			// Notifie la classe de gestion
			this.m_oTdbModeEdition.OnOperationSurDropSans(oDnDSource, this);

			// Refuse le DnD sur autre chose
			return this.ms_nOperationSans;
		}

		// GP 09/09/2014 : QW247930 : On calcule l'offset de colonnes et de lignes : comme cela si on part en DnD en ne cliquant pas sur la cellule en haut � gauche, on peut faire des calculs corrects
		var oOffsetDernierDnDDest = this._voGetOffsetAction();

		// Si on a un drop possible
		if (this._bDropPossible(nDnDOperation, oOffsetDernierDnDDest))
		{
			this.m_oOffsetDernierDnDDest = oOffsetDernierDnDDest;

			// GP 09/09/2014 : QW247840 : Ajoute le test que l'on est pas trop a droite
			if (!this.m_oTdbModeEdition.bColonneValidePourLargeur(oDnDSource, this))
			{
				// Notifie la classe de gestion
				this.m_oTdbModeEdition.OnOperationSurDropSans(oDnDSource, this);

				// Refuse le DnD sur autre chose
				return this.ms_nOperationSans;
			}
		}

		// Utilise l'operation par defaut definie
		return WDDnDNatif.prototype._vnGetOperationSurDrop.apply(this, arguments);
	};

	// Indique que l'on sort du survol
	__WDDnDElementModeEdition.prototype._vOnDragExit = function _vOnDragExit()
	{

		// Notifie la classe de gestion
		this.m_oTdbModeEdition.OnDragExit(this.ms_oDnDSource, this);

		// Seule la partie destination est effac�e. La partie source est effac�e dans _vOnDragEnd
		delete this.m_oOffsetDernierDnDDest;

		// Appel de la methode de la classe de base
		WDDnDNatif.prototype._vOnDragExit.apply(this, arguments);
	};

	// Lacher sur l'element
	__WDDnDElementModeEdition.prototype._vOnDrop = function _vOnDrop()
	{
		// Appel de la methode de la classe de base
		WDDnDNatif.prototype._vOnDrop.apply(this, arguments);

		this.m_oTdbModeEdition.OnDrop(this.ms_oDnDSource, this);
	};

	// Emule le DnDNatif avec IE9 : Oui si on est bien en IE9
	// Il faut le test bIE car nIE = 0 pour les navigateurs qui ne sont pas IE
	__WDDnDElementModeEdition.prototype._vbEmuleIE9 = function _vbEmuleIE9()
	{
		return bIE && (nIE < 10);
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEdition
	//		M�thodes g�n�rales

	// Affiche l'�l�ment � une position donn�e
	__WDDnDElementModeEdition.prototype.vAffiche = function vAffiche(nLigne, nColonne, nLargeur, nHauteur/*, bDansRedimensionnement*/)
	{
		// Positionne l'�l�ment
		this.m_oElement.className = this.m_sModeleClasses + " " + __s_sGetClassesPositionnement(false, nLigne, nColonne, nLargeur, nHauteur);
		// Affiche l'�l�ment (le mod�le est en display : none)
		clWDUtil.SetDisplay(this.m_oElement, true);

		// M�morise la position (se donne une interface de position)
		this.m_bVisible = true;
		this.m_nLigne = nLigne;
		this.m_nColonne = nColonne;
		this.m_nLargeur = nLargeur;
		this.m_nHauteur = nHauteur;
	};

	// Masque l'�l�ment
	__WDDnDElementModeEdition.prototype.vMasque = function vMasque()
	{
		// Masque l'�l�ment
		clWDUtil.SetDisplay(this.m_oElement, false);
	};

	// Liberation
	__WDDnDElementModeEdition.prototype.vLibereElement = function vLibereElement()
	{
		// D�tache les �v�nements
		this._LibereElement(this.m_oElementDnD);
		// Supprime du DOM
		clWDUtil.oSupprimeElement(this.m_oElement);
		// Et de notre classe
		delete this.m_oElementDnD;
		delete this.m_oElement;
	};

	//_voGetOffsetAction

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEdition
	//		M�thodes internes g�n�rales

	// Indique s'il y a un d�placement. Autorise :
	// - Les actions entre deux �l�ments
	// - Les actions sur le m�me �l�ment si on a un d�placement de plus de une case.
	__WDDnDElementModeEdition.prototype._bDropPossible = function _bDropPossible(nDnDOperation, oOffsetDernierDnDDest)
	{
		var oDnDSource = this.ms_oDnDSource;

		if (this !== oDnDSource)
		{
			// - Les actions entre deux �l�ments (= si on n'est pas sur nous-m�me)
			return true;
		}
		else
		{
			// Si on a �t� rendu invisible, c'est que l'on est dans le cas de la sortie
//			if ((this.ms_nDnDSortieChamp == nDnDOperation) && !this.m_oTdbModeEdition.m_tabAffichageCourant[this.m_nWidget].m_bVisible)
			if (this.ms_nDnDSortieChamp == nDnDOperation)
			{
				return true;
			}

			// Les actions sur le m�me �l�ment si on a un d�placement de plus de une case.
			var oOffsetDernierDnDSrc = oDnDSource.m_oOffsetDernierDnDSrc;

			// Calcule la cellule du d�placement source.
			var nCelluleSrcX = oOffsetDernierDnDSrc.m_nCelluleX;
			var nCelluleSrcY = oOffsetDernierDnDSrc.m_nCelluleY;
			// Calcule la cellule du d�placement cible
			var nCelluleDestX = oOffsetDernierDnDDest.m_nCelluleX;
			var nCelluleDestY = oOffsetDernierDnDDest.m_nCelluleY;

			// Si la cellule cible existe (on n'est pas entre deux cases) et si elle n'est pas la m�me que la cellule source : autorise
			if ((-1 != nCelluleDestX) && (-1 != nCelluleDestY) && ((nCelluleSrcX != nCelluleDestX) || (nCelluleSrcY != nCelluleDestY)))
			{
				return true;
			}
		}

		return false;
	};

	// M�morise les coordonn�es de la derni�re action
	__WDDnDElementModeEdition.prototype._oGetOffsetAction = function _oGetOffsetAction(nLargeur, nHauteur)
	{
		// GP 09/09/2014 : QW247930 : On calcule l'offset de colonnes et de lignes : comme cela si on part en DnD en ne cliquant pas sur la cellule en haut � gauche, on peut faire des calculs corrects
		var oEvent = this._oGetEvent();
		var oElement = this.m_oElement;
		var oTdb = this.m_oTdbModeEdition.m_oTdb;
		var oParametres = oTdb.m_oParametres;

		// On calcule la cellule dans l'�l�ment actuel
		var nCelluleX = __s_nGetCellule(this.oGetOffsetElementSiAutre(oEvent, oElement, false), nLargeur, oTdb.m_nTaille1CaseXEffective, oParametres.m_nMargeX);
		var nCelluleY = __s_nGetCellule(this.oGetOffsetElementSiAutre(oEvent, oElement, true), nHauteur, oParametres.m_nTaille1CaseY, oParametres.m_nMargeY);

//		clWDUtil.WDDebug.info(nCelluleX + ", " + nCelluleY);

		return {
			m_nCelluleX: nCelluleX,
			m_nCelluleY: nCelluleY
		};
	};
	function __s_nGetCellule(nOffset, nDimensionCase, nTaille1Case, nMarge)
	{
		var nTaille1CaseAvecMarge = nTaille1Case + nMarge;
		// GP 28/10/2014 : Remplacement par Math.floor
		var nCellule = Math.floor(nOffset / nTaille1CaseAvecMarge);
		if (nCellule < nDimensionCase)
		{
			// Si on n'est pas sur la derniere cellule
			return nCellule;
		}
		else if ((nOffset - nCellule * nTaille1CaseAvecMarge) < nTaille1Case)
		{
			// Si on est sur la derni�re cellule
			return nCellule;
		}
		else
		{
			// Impossible maintenant on est toujours dans une case
			clWDUtil.WDDebug.assert(false, "Impossible maintenant on est toujours dans une case");
			return -1;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEditionWidget
	//		Gestion d'un �l�ments en mode �dition

	function __WDDnDElementModeEditionWidget(oTdbModeEdition, nWidget, bDeplace, bRedimensionne)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// On est source de DnD que si le d�placement est autoris�
			var nSource = bDeplace ? 1 : 0;

			// Appel le constructeur de la classe de base
			__WDDnDElementModeEdition.prototype.constructor.apply(this, [oTdbModeEdition, oTdbModeEdition.m_oTdb.m_oModeleModeEdition, nSource, nWidget]);

			this.m_nWidget = nWidget;
			this.m_bRedimensionne = bRedimensionne;

			// Calcule les possibilit� de redimensionnment du widget et pose les hooks pour le redimensionnement
			// Tableau des fonctions associ� : pas de fonction = DnD interdit dans ce sens
			// Ordre : HG, H, HD, D, BD, B, BG, G
			//	HG		H		HD
			//		1	2	3
			//	G	8		4	G
			//		7	6	5
			//	BG		B		BD
			var tabRedimensionnement = [];
			var oElement = this.m_oElement;
			clWDUtil.bForEach(ms_tabRedimensionnmentClasse, function (sClasse)
			{
				tabRedimensionnement.push({
					m_fMouseDown: null,
					m_oDiv: clWDUtil.tabGetElementsByClass(oElement, sClasse)[0]
				});
				return true;
			});
			this.m_tabRedimensionnement = tabRedimensionnement;
		}
	}

	// Declare l'heritage
	__WDDnDElementModeEditionWidget.prototype = new __WDDnDElementModeEdition();
	// Surcharge le constructeur qui a ete efface
	__WDDnDElementModeEditionWidget.prototype.constructor = __WDDnDElementModeEditionWidget;

	var ms_tabRedimensionnmentClasse = ["wbTdbHG", "wbTdbH", "wbTdbHD", "wbTdbD", "wbTdbBD", "wbTdbB", "wbTdbBG", "wbTdbG"];
	var ms_tabRedimensionnmentCurseur = ["SE-resize", "N-resize", "NE-resize", "E-resize", "SE-resize", "N-resize", "NE-resize", "E-resize"];

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEditionWidget
	//		Impl�mentation des m�thodes de WDDnDNatif

	// Ecrit la/les valeurs : lit le champs
	// (Seulement sur les widget car se sont les seuls sources)
	__WDDnDElementModeEditionWidget.prototype._vSetDonneesDnD = function _vSetDonneesDnD()
	{
		// Appel de la methode de la classe de base
		__WDDnDElementModeEdition.prototype._vSetDonneesDnD.apply(this, arguments);

		// GP 14/11/2013 : QW238989 : Place des donn�es dans le DnD (sinon on ne part pas en DnD avec Firefox et Safari)
		this._SetEventDataSelonTypeAvecCorrection(this.ms_tabTypes[0], this.m_nWidget + "");

		// _vSetDonneesDnD est en fait _vOnDragStart
		// GP 09/09/2014 : QW247930 : On calcule l'offset de colonnes et de lignes : comme cela si on part en DnD en ne cliquant pas sur la cellule en haut � gauche, on peut faire des calculs corrects
		this.m_oOffsetDernierDnDSrc = this._voGetOffsetAction();
	};

	// Fin du DnD (pour l'appelant) : traite le cas deplacement
	__WDDnDElementModeEditionWidget.prototype._vOnDragEnd = function _vOnDragEnd()
	{
		// Appel de la methode de la classe de base
		__WDDnDElementModeEdition.prototype._vOnDragEnd.apply(this, arguments);

		// Seule la partie source est effac�e. La partie destination est effac�e dans _vOnDragExit
		// Sauf que comme on est sur de finir le DnD on peut supprimer le dest aussi (blindage suppl�mentaire)
		delete this.m_oOffsetDernierDnDSrc;
		delete this.m_oOffsetDernierDnDDest;
	};

	// En cas de survol
	// Ici ce qui nous importe est l'entr�e en survol
	__WDDnDElementModeEditionWidget.prototype._vnOnDragSurvol = function _vnOnDragSurvol(nDnDOperation, nOperation)
	{
		// Si on arrive ici c'est que _vnGetOperationSurDrop a valider le contenu du drop

		// Appel de la methode de la classe de base
		nOperation = __WDDnDElementModeEdition.prototype._vnOnDragSurvol.apply(this, arguments);

		// GP 09/09/2014 : QW247930 : On calcule l'offset de colonnes et de lignes : comme cela si on part en DnD en ne cliquant pas sur la cellule en haut � gauche, on peut faire des calculs corrects
		if (this._bDropPossible(nDnDOperation, this._voGetOffsetAction()))
		{
			// Notifie la classe de gestion
			this.m_oTdbModeEdition.OnDragSurvol(this.ms_oDnDSource, this);
		}

		// Si on arrive ici c'est que _vnGetOperationSurDrop a valider le contenu du drop
		return nOperation;
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEditionWidget
	//		Impl�mentation des m�thodes de __WDDnDElementModeEdition

	// Affiche l'�l�ment � une position donn�e
	__WDDnDElementModeEditionWidget.prototype.vAffiche = function vAffiche(nLigne, nColonne, nLargeur, nHauteur, bDansRedimensionnement)
	{
		// Appel de la methode de la classe de base
		__WDDnDElementModeEdition.prototype.vAffiche.apply(this, arguments);

		// Normalement on n'est pas attach� (il y a toujours un appel de vMasque avant l'affichage et vMasque fait le d�tachement)
		// Sauf dans un redimensionnement : selon le cas les regl�s peuvent changer.
		// Et si on interdit le redimensionnement
		if (!bDansRedimensionnement && this.m_bRedimensionne)
		{
			// Calcule l'extension maximale d'un �l�ment
			// @@@ Actuellement on ne limite pas l'extension en largeur ou en hauteur d'un �l�ment

			var oTdb = this.m_oTdbModeEdition.m_oTdb;
			var oParametres = oTdb.m_oParametres;
			var nPasX = oParametres.m_nMargeX + oTdb.m_nTaille1CaseXEffective;
			var nPasY = oParametres.m_nMargeY + oParametres.m_nTaille1CaseY;

			// Calcule les variations possibles
			var oVariationGauche = __s_oConstruitVariation(-nColonne, nLargeur - 1, false, nPasX, nPasY);
			var oVariationHaut = __s_oConstruitVariation(-nLigne, nHauteur - 1, false, nPasX, nPasY);
			var oVariationDroite = __s_oConstruitVariation(1 - nLargeur, oTdb.m_nNbColonnesEffectif - nColonne - nLargeur, true, nPasX, nPasY);
			// Pas de limite vers le bas : limite arbitraire
			var oVariationBas = __s_oConstruitVariation(1 - nHauteur, 1024, true, nPasX, nPasY);

			// Attache le redimensionnment selon la position actuelle
			this.__AttacheUnRedimensionnement(0, oVariationGauche, oVariationHaut);
			this.__AttacheUnRedimensionnement(1, null, oVariationHaut);
			this.__AttacheUnRedimensionnement(2, oVariationDroite, oVariationHaut);
			this.__AttacheUnRedimensionnement(3, oVariationDroite, null);
			this.__AttacheUnRedimensionnement(4, oVariationDroite, oVariationBas);
			this.__AttacheUnRedimensionnement(5, null, oVariationBas);
			this.__AttacheUnRedimensionnement(6, oVariationGauche, oVariationBas);
			this.__AttacheUnRedimensionnement(7, oVariationGauche, null);
		}
	};

	// Masque l'�l�ment
	__WDDnDElementModeEditionWidget.prototype.vMasque = function vMasque()
	{
		// Detache le redimensionnment
		this.__DetacheRedimensionnement();

		// Appel de la methode de la classe de base
		__WDDnDElementModeEdition.prototype.vMasque.apply(this, arguments);
	};

	// Liberation
	__WDDnDElementModeEditionWidget.prototype.vLibereElement = function vLibereElement()
	{
		// Detache le redimensionnment
		this.__DetacheRedimensionnement();

		// Appel de la methode de la classe de base
		__WDDnDElementModeEdition.prototype.vLibereElement.apply(this, arguments);
	};

	__WDDnDElementModeEditionWidget.prototype._voGetOffsetAction = function _voGetOffsetAction()
	{
		// GP 09/09/2014 : QW247930 : On calcule l'offset de colonnes et de lignes : comme cela si on part en DnD en ne cliquant pas sur la cellule en haut � gauche, on peut faire des calculs corrects
		var oPosition = this.m_oTdbModeEdition.m_tabAffichageCourant[this.m_nWidget];
		return this._oGetOffsetAction(oPosition.m_nLargeur, oPosition.m_nHauteur);
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEdition
	//		M�thodes g�n�rales

	// Construit une variation
	function __s_oConstruitVariation(nMin, nMax, bBasOuDroite, nPasX, nPasY)
	{
		// Il faut que les deux soit valides et que la plage ne soit pas vide :
		if ((nMin <= 0) && (0 <= nMax) && (nMin < nMax))
		{
			return {
				m_nMin: nMin * nPasX,
				m_nMax: nMax * nPasY,
				m_bBasOuDroite: bBasOuDroite
			};
		}
		else
		{
			return null;
		}
	}

	// Attache un redimensionnement
	// nCurseurSiVariationXY : c'est nRedimensionnement
	__WDDnDElementModeEditionWidget.prototype.__AttacheUnRedimensionnement = function __AttacheUnRedimensionnement(nRedimensionnement, oVariationX, oVariationY)
	{
		var oRedimensionnement = this.m_tabRedimensionnement[nRedimensionnement];

		// Uniquement si on a bien le div et que l'on n'est pas d�j� attach� (il est possible de demander le r�attachement dans __Affiche
		if (oRedimensionnement.m_oDiv && !oRedimensionnement.m_fMouseDown)
		{
			// Regarde si on autorise les variations en X et/ou Y
			// Si la variation n'est pas possible on recoit null
			var bVariationX = !!oVariationX;
			var bVariationY = !!oVariationY;

			var nCurseur;
			// Si on a X et Y
			if (bVariationX && bVariationY)
			{
				nCurseur = nRedimensionnement;
			}
			else if (bVariationX)
			{
				// "E-resize";
				nCurseur = 3;
			}
			else if (bVariationY)
			{
				// "N-resize"
				nCurseur = 1;
			}
			else
			{
				// Pas de variation possible : masque le curseur et fin.
				oRedimensionnement.m_oDiv.style.cursor = "auto";
				return;
			}

			var sCurseur = ms_tabRedimensionnmentCurseur[nCurseur];
			oRedimensionnement.m_oDiv.style.cursor = sCurseur;
			oRedimensionnement.m_fMouseDown = this.m_oTdbModeEdition.fAttacheUnRedimensionnement(oRedimensionnement.m_oDiv, this.m_nWidget, oVariationX, oVariationY, sCurseur);
		}
	};

	// Detache le redimensionnment
	__WDDnDElementModeEditionWidget.prototype.__DetacheRedimensionnement = function __DetacheRedimensionnement()
	{
		var oTdbModeEdition = this.m_oTdbModeEdition;

		// Pour chaque �l�ment du tableau :
		clWDUtil.bForEach(this.m_tabRedimensionnement, function (oRedimensionnement)
		{
			// Si la fonction existe : c'est que l'on est attach�
			if (oRedimensionnement.m_fMouseDown)
			{
				oTdbModeEdition.DetacheUnRedimensionnement(oRedimensionnement.m_oDiv, oRedimensionnement.m_fMouseDown);
				oRedimensionnement.m_fMouseDown = null;
			}
			// Si la fonction n'existe pas : c'est que l'on n'est pas attach�.
			// Teste si c'est parce que l'on ne devait pas, ou parce que l'on avait pas l'objet (n'arrive normalement pas)
			else if (oRedimensionnement.m_oDiv)
			{
				// Supprime le style ajout� �ventuellement sur l'ojet (pas de curseur souris)
				oRedimensionnement.m_oDiv.style.cursor = "";
			}

			return true;
		});
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEditionVide
	//		Gestion d'un �l�ments en mode �dition

	function __WDDnDElementModeEditionVide(oTdbModeEdition, nIndice)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			__WDDnDElementModeEdition.prototype.constructor.apply(this, [oTdbModeEdition, oTdbModeEdition.m_oTdb.m_oModeleModeEditionVide, 0, nIndice]);
		}
	}

	// Declare l'heritage
	__WDDnDElementModeEditionVide.prototype = new __WDDnDElementModeEdition();
	// Surcharge le constructeur qui a ete efface
	__WDDnDElementModeEditionVide.prototype.constructor = __WDDnDElementModeEditionVide;

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEditionVide
	//		Impl�mentation des m�thodes de WDDnDNatif

	// En cas de survol
	// Ici ce qui nous importe est l'entr�e en survol
	__WDDnDElementModeEditionVide.prototype._vnOnDragSurvol = function _vnOnDragSurvol(nDnDOperation, nOperation)
	{
		// Si on arrive ici c'est que _vnGetOperationSurDrop a valider le contenu du drop

		// Appel de la methode de la classe de base
		nOperation = __WDDnDElementModeEdition.prototype._vnOnDragSurvol.apply(this, arguments);

		// Pas de filtre sur nous m�me (on ne peut pas �tre source)
		if (this.ms_nDnDEntreeChamp == nDnDOperation)
		{
			// Notifie la classe de gestion
			this.m_oTdbModeEdition.OnDragSurvol(this.ms_oDnDSource, this);
		}

		// Si on arrive ici c'est que _vnGetOperationSurDrop a valider le contenu du drop
		return nOperation;
	};

	//////////////////////////////////////////////////////////////////////////
	// Classes utilitaires
	//	__WDDnDElementModeEditionVide
	//		Impl�mentation des m�thodes de __WDDnDElementModeEdition

	__WDDnDElementModeEditionVide.prototype._voGetOffsetAction = function _voGetOffsetAction()
	{
		// GP 09/09/2014 : QW247930 : On calcule l'offset de colonnes et de lignes : comme cela si on part en DnD en ne cliquant pas sur la cellule en haut � gauche, on peut faire des calculs corrects
		return this._oGetOffsetAction(1, 1);
	};

	return __WDTdb;
})();
