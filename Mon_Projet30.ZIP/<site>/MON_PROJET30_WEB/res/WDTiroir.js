// WDTiroir.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS bIEQuirks AppelMethode
// - WDChamp.js
///#GLOBALS WDChamp
// - WDAnim.js
///#GLOBALS WDAnim

//////////////////////////////////////////////////////////////////////////
// Manipulation des champs tiroir

var WDTiroir = (function ()
{
	"use strict";

	function s_bEstVertical(oPartieBasse)
	{
		var eSens = (oPartieBasse.dataset && oPartieBasse.dataset.wbtiroirsens !== undefined) ? parseInt(oPartieBasse.dataset.wbtiroirsens) : 0;
		return eSens === 0 || eSens === 2;
	}

	var WDAnimTiroir = (function ()
	{
		// Animation de l'ouverture ou de la fermeture du champ tiroir
		// GP 18/12/2012 : nType, nCourbe et nDuree n'ont jamais �t� transmis
//		function __WDAnimTiroir(oPartieBasse, sAliasChamp, bOuverture, nHauteurBas, nType, nCourbe, nDuree)
		function __WDAnimTiroir(oPartieBasse, sAliasChamp, bOuverture, nHauteurBas)
		{
			if (arguments.length)
			{
				// enum SENS
				// {
				// 	SENS_MIN_DEFAUT = 0
				// ,	ePoigneeHaut = SENS_MIN_DEFAUT
				// ,	ePoigneeGauche
				// ,	ePoigneeBas
				// ,	ePoigneeDroite
				// ,	SENS_MAX_INVALIDE
				// //,	ePoigneeDAmour = SENS_MAX_INVALIDE
				// };		
				var bVertical = s_bEstVertical(oPartieBasse);
				var oPartieHaute = oPartieBasse.previousElementSibling || oPartieBasse.nextElementSibling;
				// Memorise les parametres (pour les appels de fonctions 'virtuelles' dans le constructeur de WDAnim)
				var oTiroir = document.getElementById("con-" + sAliasChamp);
				this.m_oPartieBasse = oPartieBasse;
				this.m_bOuverture = bOuverture;
				var oPartieAnim = bVertical ? oPartieBasse : oTiroir;

				// Sauve la propriete de debordement et la fixe a sa valeur demandee
				var oStyleBas = clWDUtil.oGetCurrentStyle(oPartieBasse);
				var sSavOverflowY = oStyleBas.overflowY;
				oPartieAnim.style.overflowX = oPartieAnim.style.overflowY = "hidden";

				// Calcule les tailles
				// La taille min est de 1 en 1 sinon toute le champ s'affiche en mode de compatibilite
				var nMin = (bIEQuirks || !bVertical) ? 1 : 0;
				var nDebut = this.m_bOuverture ? nMin : nHauteurBas;
				var nFin = this.m_bOuverture ? nHauteurBas : nMin;

				//initialise la taille
				var sTaillePourRestaurer = "auto";
				if (!bVertical)
				{
					// GP 24/11/2020 : QW332808 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte(les tabulations)
					// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
					// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
					var oPartieHauteFirstElementChild = oPartieHaute.children[0];
					var nLargeurPartieHaute = parseFloat(clWDUtil.oGetCurrentStyle(oPartieHauteFirstElementChild).width);
					nDebut += nLargeurPartieHaute;
					nFin += nLargeurPartieHaute;
					//var nTailleActuelle = parseFloat(clWDUtil.oGetCurrentStyle(oTiroir).width);

					sTaillePourRestaurer = clWDUtil.GetDimensionPxPourStyle(nFin - (this.m_bOuverture ? 0 : 1));

					//la taille vient de la table
					oPartieHaute.parentNode.style.width = "auto";
					oPartieBasse.style.display = "table-cell";
					oPartieBasse.style.overflowX = oPartieBasse.style.overflowY = "hidden";
				}

				//callabck d'�tape d'anim
				var pfSetPropDimension = bVertical 
				? function (nVal) 
				{ 
					oPartieAnim.style.height = nVal + "px"; 
				}
				: function (nVal) 
				{ 
					oPartieAnim.style.width = nVal + "px"; 

					oPartieBasse.style.maxWidth = (nVal-nLargeurPartieHaute) + "px"; 					
				};

				//fixe la largeur de la table dans le div bas du tiroir
				// GP 24/11/2020 : QW332808 : A cause de la mise en forme du HTML, la premi�re balise fille est parfoirs du texte(les tabulations)
				// => Il faut les ignorer et prend la "vraie" premi�re balise : utilise firstElementChild et pas firstChild.
				// Sauf que firstElementChild n'est pas disponible, avec IE8- : utilise children[0].
				var oPartieBasseFirstElementChild = oPartieBasse.children[0];
				var nLargeurInit = oPartieBasseFirstElementChild.style.width;
				if (!bVertical)
				{
					oPartieBasseFirstElementChild.style.width = nHauteurBas + "px";
				}

				pfSetPropDimension(nDebut);


				// Si on est en ouveture, il faut afficher le volet maintenant
				if (this.m_bOuverture || !bVertical)
				{
					//clWDUtil.SetDisplay(oPartieBasse, true);
					oPartieAnim.style.display = "block";
				}

				this.m_pfRestaureProp = bVertical ? function ()
					{
						oPartieAnim.style.height = "auto";
						oPartieAnim.style.overflowX = oPartieAnim.style.overflowY = sSavOverflowY;
					}
					: function ()
					{
						oPartieAnim.style.width = sTaillePourRestaurer;
						oPartieAnim.style.overflowX = oPartieAnim.style.overflowY = sSavOverflowY;
						oPartieBasse.style.overflowX = oPartieBasse.style.overflowY = "visible";
						oPartieBasse.style.maxWidth = "none";
						oPartieBasseFirstElementChild.style.width = nLargeurInit;
						//en cas d'ancrage, retire le display block qui nuit � la propoagation du height 100%
						if (oPartieAnim.style.height.indexOf("%"))
						{
							oPartieAnim.style.display = "";
						}
					};

				// Appel de la classe de base (lance l'animation)
				// GP 18/12/2012 : nType, nCourbe et nDuree n'ont jamais �t� transmis
//				WDAnim.prototype.constructor.apply(this, [pfSetPropDimension, nDebut, nFin, nType, nCourbe, nDuree, sAliasChamp]);
				WDAnim.prototype.constructor.apply(this, [pfSetPropDimension, nDebut, nFin, 0, this.ms_nCourbeLineaire, 25, sAliasChamp]);
			}
		}

		// Declare l'heritage
		__WDAnimTiroir.prototype = new WDAnim();
		// Surcharge le constructeur qui a ete efface
		__WDAnimTiroir.prototype.constructor = __WDAnimTiroir;

		// Annule l'animation
		// Ne met PAS dans l'etat final
//		WDAnim.prototype.vAnnule = function vAnnule()

		// Marque la fin de l'animation
		__WDAnimTiroir.prototype.vFin = function vFin()
		{
			// Masque le volet si on est en fermeture (en ouverture le veolet a deja ete affiche)
			if (!this.m_bOuverture)
			{
				clWDUtil.SetDisplay(this.m_oPartieBasse, false);
			}

			// Restaure les proprietes
			this.m_pfRestaureProp();

			// Appel de la classe de base (memorise que l'animation est finie)
			WDAnim.prototype.vFin.apply(this, arguments);

			clWDUtil.__OnScrollResize(undefined, false);
		};

		return __WDAnimTiroir;
	})();

	// Manipulation d'un tiroir
	function __WDTiroir(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChamp.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : tabStyle, nHauteurBas
			var tabStyle = tabParametresSupplementaires[0];
			var nHauteurBas = tabParametresSupplementaires[1];

			this.m_tabStyle = tabStyle;
			// Parametres pour l'animation
			this.m_nHauteurBasDefaut = nHauteurBas;
			// GP 18/12/2012 : nType, nCourbe et nDuree n'ont jamais �t� transmis
//			this.m_nType = nType ? nType : 0;
//			this.m_nCourbe = nCourbe ? nCourbe : 0;
//			this.m_nDuree = nDuree ? nDuree : 25;

			// GP 10/12/2012 : TB68877 : Si on est dans une ZR on peut avoir plusieurs animations
			// Indic� sur l'ID de la partie basse
			this.m_tabAnimations = [];
			this.m_tabHauteurBas = [];
		}
	}

	// Declare l'heritage
	__WDTiroir.prototype = new WDChamp();
	// Surcharge le constructeur qui a ete efface
	__WDTiroir.prototype.constructor = __WDTiroir;

	// Constantes de style
	var ms_nStyleFerme = 0;
	var ms_nStyleOuvert = 1;

	// Initialisation
	__WDTiroir.prototype.Init = function Init()
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype.Init.apply(this, arguments);

		// MAJ du champ
		this.__InitInterne();
	};

	// MAJ du champ
	__WDTiroir.prototype.__InitInterne = function __InitInterne()
	{
		// GP 10/12/2012 : Pour la gestion dans une ZR : on ne fait plus de pr�calculs
//		// Recupere la partie haute et la partie basse
//		this.m_oPartieHaute = document.getElementById('H-' + this.m_sAliasChamp);
//		this.m_oPartieAnim = document.getElementById('B-' + this.m_sAliasChamp);

		// Recupere les clics sur la zone haute
		if (!this.bGestionTableZR())
		{
			this.__InitOnClick();
		}
		else if (this.oGetTableZRParent())
		{
			// Pour les lignes affich�es
			this.PourToutesLignesTableZR(this.__InitOnClick);
		}
		// Rien pour les ZR AJAX (appel sur l'affichage des lignes)
	};

	// Prend le clic sur un el�ment
	__WDTiroir.prototype.__InitOnClick = function __InitOnClick(nLigneAbsolueBase1)
	{
		var oThis = this;
		var tabParties = this.__tabGetPartiesSelonIndice(nLigneAbsolueBase1);
		if (tabParties[0])
		{
			tabParties[0].onclick = function (oEvent) { oThis.OnClick(oEvent || event, nLigneAbsolueBase1); };
		}
	};

	// - Tous les champs : notifie que une table ou ZRs a �t� MAJ en AJAX (= table/ZR non AJAX mais avec les ZR horizontales)
	__WDTiroir.prototype._vOnTableZRAfficheAJAXInterne = function _vOnTableZRAfficheAJAXInterne()
	{
		// Appel de la methode de la classe de base (qui normalement ne fait rien)
		WDChamp.prototype._vOnTableZRAfficheAJAXInterne.apply(this, arguments);

		// MAJ du champ
		this.__InitInterne();
	};

	// Methode appele directement
	// - Champ dans une table/ZR : notifie le champ de l'affichage/suppression de la ligne
	__WDTiroir.prototype._vOnLigneTableZRAffiche = function _vOnLigneTableZRAffiche(nLigneAbsolueBase1/*, bSelectionne*/)
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype._vOnLigneTableZRAffiche.apply(this, arguments);

		this.__InitOnClick(nLigneAbsolueBase1);
	};
	__WDTiroir.prototype._vOnLigneTableZRMasque = function _vOnLigneTableZRMasque(nLigneAbsolueBase1/*, bSelectionne*//*, oEvent*/)
	{
		var tabParties = this.__tabGetPartiesSelonIndice(nLigneAbsolueBase1);
		// GP 01/04/2014 : TB68877 : tabParties[0] n'existe pas forc�ment (si la ligne n'�tait pas visible)
		if (tabParties[0])
		{
			tabParties[0].onclick = null;
		}

		// Appel de la methode de la classe de base
		WDChamp.prototype._vOnLigneTableZRMasque.apply(this, arguments);
	};

	// Trouve les parties haute et basse associ�es � un champ
	__WDTiroir.prototype.__tabGetParties = function __tabGetParties(oChamp)
	{
		var nIndiceZR;

		// Calcule l'indice de la ZR si on est dans une ZR
		if (this.bGestionTableZR())
		{
			nIndiceZR = parseInt(oChamp.name.split("_")[1], 10);
		}

		return this.__tabGetPartiesSelonIndice(nIndiceZR);
	};
	// Trouve les parties haute et basse associ�es � un champ
	__WDTiroir.prototype.__tabGetPartiesSelonIndice = function __tabGetPartiesSelonIndice(nIndiceZR)
	{
		var sAlias;

		// Si on n'est pas dans une ZR
		if (!this.bGestionTableZR())
		{
			// L'alias est l'alias du champ
			sAlias = this.m_sAliasChamp;
		}
		else
		{
			sAlias = this.sGetNomElementAttributIndice(nIndiceZR, "");
		}

		return [document.getElementById('H-' + sAlias), document.getElementById('B-' + sAlias)];
	};

	// GP 16/11/2012 : QW225804 : M�thode de calcul de la hauteur de la partie basse
	__WDTiroir.prototype.__nGetHauteurBas = function __nGetHauteurBas(oChamp)
	{
		var tabParties = this.__tabGetParties(oChamp);
		return this.__nGetHauteurBasValeur(this.__bGetOuvert(), tabParties);
	};

	// GP 16/11/2012 : QW225804 : M�thode de calcul de la hauteur de la partie basse
	__WDTiroir.prototype.__nGetHauteurBasValeur = function __nGetHauteurBasValeur(bOuvert, tabParties)
	{
		var oPartieBasse = tabParties[1];
		var bVertical = s_bEstVertical(oPartieBasse);

		// Si on est dans une animation : prend la valeur stock�e
		// Donc recalcul uniquement dans les autres cas
		if (!this.m_tabAnimations[oPartieBasse.id])
		{
			var sPosition;
			var sVisibility;
			var sDisplay;
			var sWidthAvant;
			var oTiroir;
			if (!bOuvert)
			{
				// On est ferm� : calcule la hauteur
				// Positionne oPartieBasse de telle mani�re que cela ne g�ne pas
				// Un seul inconv�nient : si le conteneur est trop petit et qu'on a un paint il va y avoir un mouvement
				sPosition = oPartieBasse.style.position;
				oPartieBasse.style.position = bVertical ? "absolute" : "static";
				sVisibility = oPartieBasse.style.visibility;
				oPartieBasse.style.visibility = "hidden";
				sDisplay = oPartieBasse.style.display;
				//clWDUtil.SetDisplay(oPartieBasse, true);
				oPartieBasse.style.display = bVertical ? "block" : "table-cell";
				//retire la largeur du tiroir pour que le table cell trouve tout seul sa bonen largeur
				if (bVertical)
				{
					// GP 16/11/2018 : QW306593 : Si on ne place pas le width:100% (= prend l'ancrage du parent), les �l�ments internes (particulier une ZR en mode nombre de colonne variable)
					// ne prennent pas toute la largeur mais uniquement la largeur d'�dition.
					sWidthAvant = oPartieBasse.style.width;
					oPartieBasse.style.width = "100%";
				}
				else
				{
					oTiroir = document.getElementById("con-" + this.m_sAliasChamp);
					sWidthAvant = oTiroir.style.width;
					oTiroir.style.width = "auto";
					oTiroir.style.display = "table";
				}
			}

			// Prend simplement la hauteur (on est dans un �tat avec la hauteur)
			this.m_tabHauteurBas[oPartieBasse.id] = bVertical ? oPartieBasse.offsetHeight : oPartieBasse.offsetWidth;

			if (!bOuvert)
			{
				// Replace les propri�t�s
				oPartieBasse.style.display = sDisplay;
				oPartieBasse.style.visibility = sVisibility;
				oPartieBasse.style.position = sPosition;

				//restaure
				if (bVertical)
				{
					oPartieBasse.style.width = sWidthAvant;
				}
				else
				{
					oTiroir.style.width = sWidthAvant;
					oTiroir.style.display = "block";	
				}
			}
		}
		else
		{
			// La valeur que l'on a re�u de l'�dition : non compatible avec les ancrages
			// Ou la valeur derni�rement calcule
		}
		return this.__nGetHauteurBasFinal(tabParties);
	};
	__WDTiroir.prototype.__nGetHauteurBasFinal = function __nGetHauteurBasFinal(tabParties)
	{
		var nHauteurBas = this.m_tabHauteurBas[tabParties[1].id];
		return (undefined !== nHauteurBas) ? nHauteurBas : this.m_nHauteurBasDefaut;
	};

	// Trouve la valeur
	__WDTiroir.prototype.__bGetOuvert = function __bGetOuvert()
	{
		if (this.bGestionTableZR())
		{
			this._vLiaisonHTML();
		}

		return this.bConversionValeur(this._vsGetValeurChampFormulaire());
	};

	// Manipule le tiroir sur une action de l'utilisateur
	__WDTiroir.prototype.OnClick = function OnClick(oEvent, nLigneAbsolueBase1)
	{
		// On est sur la ligne de la ZR
		if (this.bGestionTableZR())
		{
			this.SetTableZRValeur(oEvent, nLigneAbsolueBase1, false);
		}

		// Uniquement sur les champs est actif
		// Et si on clic sur le fond
		if ((this.eGetEtat() == this.ms_eEtatActif) && clWDUtil.bClickDansFond(oEvent, this.__tabGetPartiesSelonIndice(nLigneAbsolueBase1)[0]))
		{
			// Change le mode interne interne
			this.SetValeur(oEvent, !this.__bGetOuvert(), this.oGetElementByNameZR(document, ""));

			// Appel le PCode navigateur de modification
			this.RecuperePCode(this.ms_nEventNavModifSimple)(oEvent);
		}
	};

	// Changement de l'etat
	__WDTiroir.prototype.SetValeur = function SetValeur(oEvent, sValeur, oChamp)
	{
		// Conversion de la valeur en booleen
		var bOuverture = this.bConversionValeur(sValeur);

		// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
		WDChamp.prototype.SetValeur.apply(this, [oEvent, bOuverture, oChamp]);

		// Affecte la valeur dans le champ formulaire
		sValeur = bOuverture ? "1" : "0";
		this._vSetValeurChampFormulaire(sValeur);

		// Affiche/masque la partie basse
		this.AfficheTiroir(bOuverture, oChamp);

		return sValeur;
	};

	// Recupere la valeur
	__WDTiroir.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp)
	{
		// Conversion de la valeur en booleen
		var bOuverture = this.bConversionValeur(sValeur);

		// Appel de la methode de la classe de base et retour de son resultat
		return WDChamp.prototype.GetValeur.apply(this, [oEvent, bOuverture, oChamp]);
	};

	// Lit les proprietes
	__WDTiroir.prototype.GetProp = function GetProp(eProp, oEvent, oValeur, oChamp)
	{
		var tabParties = this.__tabGetParties(oChamp);

		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_HAUTEUR:
			// GP 10/12/2012 : Pas de ..Hauteur en code navigateur dans une ZR : on ne g�re pas encore le cas
			// Traite le cas de ..Hauteur : lit la hauteur du bas en tenant compte de la hauteur du haut
			return tabParties[0].offsetHeight + this.__nGetHauteurBas();
		case this.XML_CHAMP_PROP_NUM_LARGEUR:
			// Traite le cas de ..Largeur : lit la largeur du haut (le bas n'est pas forcement visible)
			return tabParties[0].offsetWidth;
		case this.XML_CHAMP_PROP_NUM_ENROULE:
			// Rebond sur ..Valeur avec l'inverse
			return !this.GetValeur(oEvent, oValeur, oChamp);
		default:
			// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
			return WDChamp.prototype.GetProp.apply(this, arguments);
		}
	};

	// Ecrit les proprietes
	__WDTiroir.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp/*, oXMLAction*/)
	{
		// Implementation de la classe de base
		oValeur = WDChamp.prototype.SetProp.apply(this, arguments);

		var tabParties = this.__tabGetParties(oChamp);

		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_HAUTEUR:
			// Traite le cas de ..Hauteur : modifie la hauteur du bas en tenant compte de la hauteur du haut
			this.m_tabHauteurBas[tabParties[1].id] = oValeur - tabParties[0].offsetHeight;
//			tabParties[1].getElementsByTagName("td")[0].height = this.__nGetHauteurBas();
			var nHauteurBas = this.__nGetHauteurBasFinal(tabParties);
			tabParties[1].getElementsByTagName("td")[0].height = nHauteurBas;
			return nHauteurBas;
		case this.XML_CHAMP_PROP_NUM_LARGEUR:
			// Traite le cas de ..Largeur : modifie la hauteur du haut et du bas
			tabParties[0].getElementsByTagName("td")[0].style.width = oValeur + "px";
			tabParties[1].getElementsByTagName("td")[0].style.width = oValeur + "px";
			tabParties[0].parentNode.style.width = oValeur + "px";
			return oValeur;
		case this.XML_CHAMP_PROP_NUM_ENROULE:
			// Rebond sur ..Valeur avec l'inverse
			return this.SetValeur(oEvent, !oValeur, oChamp);
		default:
			return oValeur;
		}
	};

	// Affiche/masque la partie basse
	__WDTiroir.prototype.AfficheTiroir = function AfficheTiroir(bOuverture, oChamp)
	{
		var tabParties = this.__tabGetParties(oChamp);
		var sIDPartieBasse = tabParties[1].id;

		// Donne les bonne propriete a la partie basse
		// On gere le cas d'une animation deja en cours
		if (this.m_tabAnimations[sIDPartieBasse])
		{
			// Annule l'animation (restaure automatiquement les proprietees du champ)
			this.m_tabAnimations[sIDPartieBasse].vAnnule();
		}

		// Lance l'animation de la partie basse
		// GP 18/12/2012 : nType, nCourbe et nDuree n'ont jamais �t� transmis
//		this.m_tabAnimations[sIDPartieBasse] = new WDAnimTiroir(tabParties[1], this.m_sAliasChamp, bOuverture, this.__nGetHauteurBasValeur(!bOuverture, tabParties), this.m_nType, this.m_nCourbe, this.m_nDuree);
		this.m_tabAnimations[sIDPartieBasse] = new WDAnimTiroir(tabParties[1], this.m_sAliasChamp, bOuverture, this.__nGetHauteurBasValeur(!bOuverture, tabParties));

		// Change le style de la partie haute
		tabParties[0].className = this.m_tabStyle[bOuverture ? ms_nStyleOuvert : ms_nStyleFerme] || "";
	};

	// Notifie le tiroir que l'animation est finie
	__WDTiroir.prototype._vAnimationFin = function _vAnimationFin(oAnimation)
	{
		WDChamp.prototype._vAnimationFin.apply(this, arguments);

		var oPartieBasse = oAnimation.m_oPartieBasse;
		delete this.m_tabAnimations[oPartieBasse.id];

		// Force la MAJ des champs dans l'onglet (on n'exclus aucun champ)
		AppelMethode(WDChamp.prototype.ms_sOnDisplay, [oPartieBasse, this.__bGetOuvert()]);

		// IE redessine mal les tables/ZRs AJAX dans les tiroirs (probleme de reflow)
		// => On force un redessin (uniquement en ouverture car sinon rien n'est visible de toutes facons)
		if (bIEQuirks && (parseInt(this._vsGetValeurChampFormulaire(), 10) === 1))
		{
			oPartieBasse.className = oPartieBasse.className;
		}
	};

	return __WDTiroir;
})();