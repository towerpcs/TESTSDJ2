// WDUpload.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// Définition des globales définies dans :
// - La page
///#GLOBALS _PAGE_
// - StdAction.js
///#GLOBALS _JGE
// - WDUtil.js
///#GLOBALS bIE bIEQuirks bIEAvec11 bFF bCrm bSfr bWK
// - WDChamp.js
///#GLOBALS WDChamp
// - WDAJAX.js
///#GLOBALS WDAJAXRequete clWDAJAXMain
// - WDDrag.js
///#GLOBALS WDDnDNatif
// - WWConstanteX.js
///#GLOBALS STD_ERREUR_MESSAGE_UPLOAD


//////////////////////////////////////////////////////////////////////////
// Manipulation des champs Upload

var WDUploadBase = (function()
{
	"use strict";

	// Gestion du drag+drop HTML 5 (+ drag+drop natif) de fichiers
	// Ne fait pas de gestion de sources/cibles multiples
	var WDDnDFichiers = (function()
	{
		// Inutile ? La fonction parente est déjà en mode strict
//		"use strict";

		// piDnDFichierCallback : objet qui implémente une interface (qui n'existe pas vraiment) IDnDFichierCallback : avec les méthodes virtuelles "vbGetMultiFichiers" et "vOnDropFichiers"
		function __WDDnDFichiers(piDnDFichierCallback, oElement)
		{
			// Si on est pas dans l'init d'un protoype
			if (arguments.length)
			{
				// Appel le constructeur de la classe de base
				// Uniquement cible
				// Et par defaut on fait un lien
				// GP 29/03/2013 : Ajout de this.ms_nOperationCopie pour le DnD depuis une application WinDev (la OBJ ne place pas le flag "link")
				// En revanche on me place pas le flag "move" pour ne pas prendre le risque de supprimer le fichier source.
				WDDnDNatif.prototype.constructor.apply(this, [false, true, oElement, this.ms_nOperationLien + this.ms_nOperationCopie]);

				this.m_piDnDFichierCallback = piDnDFichierCallback;
			}
		}

		// Declare l'heritage
		__WDDnDFichiers.prototype = new WDDnDNatif();
		// Surcharge le constructeur qui a ete efface
		__WDDnDFichiers.prototype.constructor = __WDDnDFichiers;

		// Acces aux fichiers de l'evenement courant
		__WDDnDFichiers.prototype._oGetEventDataFiles = function _oGetEventDataFiles()
		{
			return this._oGetEventData().files;
		};

		// Indique les operations sur le drop
		__WDDnDFichiers.prototype._vnGetOperationSurDrop = function _vnGetOperationSurDrop(nDnDOperation)
		{
			// GP 24/05/2013 : TB80175 : Les versions de Safari avant la version 6 ne supportent pas FileReader, donc on ne peut pas manipuler les fichiers reçus par DnD
			if (bSfr)
			{
				var oRes = (new RegExp("Version/\\s*(\\d+)\\.*(\\d+)")).exec(navigator.userAgent);
				if (oRes && oRes[1] && (parseInt(oRes[1], 10) < 6))
				{
					// Safari < 6 : incompatible
					return this.ms_nOperationSans;
				}
			}
			// GP 24/05/2013 : TB80180 : Ne fonctionne que avec IE10 en norme respect des normes
			if (bIEQuirks || (document.documentMode < 10))
			{
				return this.ms_nOperationSans;
			}
			
			// Interdit si le champ est grisé
			if (this.m_piDnDFichierCallback.vbGrise())
			{
				return this.ms_nOperationSans;
			}

			// Valide que le ce sont des fichiers et leur nombre
			if (nDnDOperation === this.ms_nDnDLacher)
			{
				var oFiles = this._oGetEventDataFiles();
				if (oFiles && ((1 === oFiles.length) || ((1 < oFiles.length) && this.m_piDnDFichierCallback.vbGetMultiFichiers())))
				{
					// Utilise l'operation par defaut definie
					return WDDnDNatif.prototype._vnGetOperationSurDrop.apply(this, arguments);
				}
			}
			else if (this._bVerifieEventDataType("Files"))
			{
				// Si on n'a pas encore les donnees (dispo uniquement sur le drop)
				// Utilise l'operation par defaut definie
				return WDDnDNatif.prototype._vnGetOperationSurDrop.apply(this, arguments);
			}

			// Navigateur incompatible ou nombre de fichiers incompatibles
			return this.ms_nOperationSans;
		};

		// Lacher sur l'element
		__WDDnDFichiers.prototype._vOnDrop = function _vOnDrop()
		{
			// Appel de la methode de la classe de base
			WDDnDNatif.prototype._vOnDrop.apply(this, arguments);
			// Si on arrive ici c'est que _vnGetOperationSurDrop a valider le contenu du drop
			this.m_piDnDFichierCallback.vOnDropFichiers(this._oGetEventDataFiles());
		};

		return __WDDnDFichiers;
	})();

	// Upload d'un fichier : lance directement l'upload
	var WDUploadFile = (function()
	{
		// Inutile ? La fonction parente est déjà en mode strict
//		"use strict";

		var WDUploadFileBase = (function()
		{
			// Inutile ? La fonction parente est déjà en mode strict
//			"use strict";
		
			// piUploadFileCallback : objet qui implémente une interface (qui n'existe pas vraiment) IUploadFileCallback : avec les méthodes virtuelles "vUploadFileAvancement" et "vUploadFileFin"
			function __WDUploadFileBase(piUploadFileCallback, oFichier, sURL, sURLMorceau)
			{
				// Si on est pas dans l'init d'un protoype
				if (arguments.length)
				{
					this.m_piUploadFileCallback = piUploadFileCallback;
					this.m_oFichier = oFichier;
					this.m_sURL = sURL;
					this.m_sURLMorceau = sURLMorceau;

					var oThis = this;
					this.m_fOnProgress = function(oEvent) { oThis.__OnProgress(oEvent); };
					this.m_fOnReadyStateChange = function(oEvent) { oThis.__OnReadyStateChange(oEvent); };

					this.m_nTailleEnvoyeePrecedentsMorceaux = 0;
					// OPTIM (???) : Mémorise la taille du fichier
					this.m_nTailleEnvoyee = 0;
					this.m_nTailleFichier = this.m_oFichier.size;
					this.m_nTailleMorceau = this.m_nTailleFichier;
				}
			}
			// URL selon le morceau courant
			__WDUploadFileBase.prototype._sGetUrl = function _sGetUrl()
			{
				if (this.vContinueEnvoiParMorceau && this.m_nTailleEnvoyeePrecedentsMorceaux+WDUploadFile.TAILLE_MAX_MORCEAU < this.m_nTailleFichier)
				{
					return this.m_sURLMorceau;
				}
				return this.m_sURL;
			};
			// Envoi upload par XMLHttpRequest
			__WDUploadFileBase.prototype._Upload = function _Upload(oContenu, tabHeadersSupplementaires)
			{
				// On ne passe pas par WDAjax qui ne fait pas pareil
				var oRequeteUpload = new XMLHttpRequest();
				oRequeteUpload.open("POST", this._sGetUrl(), true);
				clWDUtil.bForEach(tabHeadersSupplementaires, function(oHeader)
				{
					oRequeteUpload.setRequestHeader(oHeader.sNom, oHeader.sValeur);
					return true;
				});
				oRequeteUpload.onreadystatechange = this.m_fOnReadyStateChange;
				if (oRequeteUpload.upload)
				{
					clWDUtil.AttacheDetacheEvent(true, oRequeteUpload.upload, "progress", this.m_fOnProgress);
				}
				oRequeteUpload.send(oContenu);
			};

			// Avancement dans l'upload d'un fichier par XMLHttpRequest
			__WDUploadFileBase.prototype.__OnProgress = function __OnProgress(oEvent)
			{
				if (oEvent.lengthComputable)
				{
					// MAJ de this.m_nTailleEnvoyee
					// Note : comme on ne connait pas toujours la taille qui inclus les entêtes et les séparateur du format : on ignore juste ces octets
					this.m_nTailleEnvoyee = Math.min(oEvent.loaded, this.m_nTailleFichier);
					// Et notification de l'avancement
					this.m_piUploadFileCallback.vUploadFileAvancement(oEvent, this.m_nTailleEnvoyeePrecedentsMorceaux + this.m_nTailleEnvoyee, this.m_nTailleFichier);
				}
			};

			// Avancement de l'upload d'un fichier par XMLHttpRequest
			__WDUploadFileBase.prototype.__OnReadyStateChange = function __OnReadyStateChange(oEvent)
			{
				// MAJ de l'affichage et utilisant la dernière valeur mémorisée de this.m_nTailleEnvoyee
				this.m_piUploadFileCallback.vUploadFileAvancement(oEvent, this.m_nTailleEnvoyeePrecedentsMorceaux + this.m_nTailleEnvoyee, this.m_nTailleFichier);

				var oRequeteUpload = oEvent.target;
				if (oRequeteUpload.readyState === WDAJAXRequete.prototype.readyStateComplete)
				{
					if (oRequeteUpload.upload)
					{
						clWDUtil.AttacheDetacheEvent(false, oRequeteUpload.upload, "progress", this.m_fOnProgress);
					}
					oRequeteUpload.onreadystatechange = clWDUtil.m_pfVide;
					var nStatus = oRequeteUpload.status;
					var sReponse = oRequeteUpload.responseText;
					if (200 === nStatus)
					{
						if (!clWDAJAXMain.bValideEtTraiteErreur(null, sReponse, undefined))
						{
							return;
						}
						
						// continue jusqu'au prochain morceau à uploader ou à l'appel de fin
					}
					else if ((400 <= nStatus) && (nStatus< 600))
					{
						// GP 11/04/2018 : TB102632 : Gestion des erreurs dans l'upload HTML5.
						this.m_piUploadFileCallback.vUploadFileErreur(sReponse, nStatus, oRequeteUpload.statusText);
						return;
					}
					else
					{
						sReponse = undefined; 
					}

					// rajoute la taille envoyée au cumul des tailles envoyées par les morceaux
					this.m_nTailleEnvoyeePrecedentsMorceaux += this.m_nTailleMorceau;

					// Envoi terminé ?
					if (!this.vContinueEnvoiParMorceau || this.m_nTailleEnvoyeePrecedentsMorceaux >= this.m_nTailleFichier)
					{
						// fin
						this.m_piUploadFileCallback.vUploadFileFin(sReponse, this.m_nTailleFichier);								
					}
					else
					{
						// il faut passer au morceau suivant
						this.vContinueEnvoiParMorceau();
					} 							
				}
			};

			return __WDUploadFileBase;
		})();

		if (window.FormData)
		{
			return (function()
			{
				// Inutile ? La fonction parente est déjà en mode strict
//				"use strict";

				function __WDUploadFileFormData(/*oUpload, oFichier, sURL*/)
				{
					// Si on est pas dans l'init d'un protoype
					if (arguments.length)
					{
						// Appel le constructeur de la classe de base
						WDUploadFileBase.prototype.constructor.apply(this, arguments);

						// Autorise l'upload par morceaux
						this.vContinueEnvoiParMorceau();
					}
				}

				// Declare l'heritage
				__WDUploadFileFormData.prototype = new WDUploadFileBase();
				// Surcharge le constructeur qui a ete efface
				__WDUploadFileFormData.prototype.constructor = __WDUploadFileFormData;

				// passe au morceau suivant pour le fichier à uploader
				__WDUploadFileFormData.prototype.vContinueEnvoiParMorceau = function vContinueEnvoiParMorceau()
				{
					// Construit le formulaire : simule le même formulaire que le formulaire Flasg
					var oFormData = new FormData();

					var nTailleMorceau = WDUploadFile.TAILLE_MAX_MORCEAU;
					var nPositionFinMorceau = this.m_nTailleEnvoyeePrecedentsMorceaux + nTailleMorceau;
					var bDernierMorceau = this.m_oFichier.size <= nPositionFinMorceau;
					if (bDernierMorceau)
					{
						nPositionFinMorceau = this.m_oFichier.size;
						nTailleMorceau = nPositionFinMorceau - this.m_nTailleEnvoyeePrecedentsMorceaux;
					}
					this.m_nTailleMorceau = nTailleMorceau;

					oFormData.append("Filename", this.m_oFichier.name);
					oFormData.append("FilePartBegin", (this.m_nTailleEnvoyeePrecedentsMorceaux === 0) ? "1" : "0");
					oFormData.append("FilePartEnd", bDernierMorceau ? "1" : "0");
					oFormData.append("Filedata",  
						this.m_oFichier.size < WDUploadFile.TAILLE_MAX_MORCEAU 
						? this.m_oFichier 
							: this.m_oFichier.slice(this.m_nTailleEnvoyeePrecedentsMorceaux, nPositionFinMorceau)
					, this.m_oFichier.name);
					oFormData.append("Upload", "Submit Query");

					// Lance l'upload
					this._Upload(oFormData, []);
				};

				return __WDUploadFileFormData;
			})();
		}
		else
		{
			return (function()
			{
				// Inutile ? La fonction parente est déjà en mode strict
//				"use strict";

				function __WDUploadFileFileReader(/*oUpload, oFichier, sURL*/)
				{
					// Si on est pas dans l'init d'un protoype
					if (arguments.length)
					{
						// Appel le constructeur de la classe de base
						WDUploadFileBase.prototype.constructor.apply(this, arguments);

						var oThis = this;
						this.m_fOnLoadFile = function(oEvent) { oThis.__OnLoadFile(oEvent); };

						var oFileReader = new FileReader();
						oFileReader.onload = this.m_fOnLoadFile;
						oFileReader.readAsArrayBuffer(this.m_oFichier);
					}
				}

				// Declare l'heritage
				__WDUploadFileFileReader.prototype = new WDUploadFileBase();
				// Surcharge le constructeur qui a ete efface
				__WDUploadFileFileReader.prototype.constructor = __WDUploadFileFileReader;

				// Limite pour l'upload de fichiers : par compatibilité, garde le même séparateur
				__WDUploadFileFileReader.prototype.ms_sBoundary = "WDUpload";


				// Chargement du fichier sur le disque
				__WDUploadFileFileReader.prototype.__OnLoadFile = function __OnLoadFile(oEvent)
				{
					var sBoundary = this.ms_sBoundary + (new Date()).getTime();

					// Comme la requete du champ flash
					var sRequeteDebut = (function(sBoundary, oFichier)
					{
						// Parametre 1 : nom du fichier
						var tabRequeteDebut = [];
						tabRequeteDebut.push("--");
						tabRequeteDebut.push(sBoundary);
						tabRequeteDebut.push("\r\n");
						tabRequeteDebut.push("Content-Disposition: form-data; name=\"Filename\"");
						tabRequeteDebut.push("\r\n\r\n");
						tabRequeteDebut.push(unescape(encodeURIComponent(oFichier.name)));
						tabRequeteDebut.push("\r\n");
						// Parametre 2 : fichier
						tabRequeteDebut.push("--");
						tabRequeteDebut.push(sBoundary);
						tabRequeteDebut.push("\r\n");
						tabRequeteDebut.push("Content-Disposition: form-data; name=\"Filedata\"; filename=\"");
						tabRequeteDebut.push(unescape(encodeURIComponent(oFichier.name)));
						tabRequeteDebut.push("\"");
						tabRequeteDebut.push("\r\n");
						tabRequeteDebut.push("Content-Type: application/octet-stream");
						tabRequeteDebut.push("\r\n\r\n");
						return tabRequeteDebut.join("");
					})(sBoundary, this.m_oFichier);

					// Fin de la requète
					var sRequeteFin = (function(sBoundary)
					{
						var tabRequeteFin = [];
						tabRequeteFin.push("\r\n");
						// Parametre 3
						tabRequeteFin.push("--");
						tabRequeteFin.push(sBoundary);
						tabRequeteFin.push("\r\n");
						tabRequeteFin.push("Content-Disposition: form-data; name=\"Upload\"");
						tabRequeteFin.push("\r\n\r\n");
						tabRequeteFin.push("Submit Query");
						tabRequeteFin.push("\r\n");
						// Marque de fin
						tabRequeteFin.push("--");
						tabRequeteFin.push(sBoundary);
						tabRequeteFin.push("--");
						return tabRequeteFin.join("");
					})(sBoundary);

					// Construit le tableau
					var oUint8ArrayFichier = new Uint8Array(oEvent.target.result);
					var sLongueur1 = sRequeteDebut.length;
					var sLongueur2 = sLongueur1 + oUint8ArrayFichier.length;
					var sLongueur3 = sLongueur2 + sRequeteFin.length;
					var oUint8Array = new Uint8Array(sLongueur3);

					this.__AjouteChaineDansUint8Array(oUint8Array, 0, sRequeteDebut);
					this.__AjouteUint8Array(oUint8Array, sLongueur1, oUint8ArrayFichier);
					this.__AjouteChaineDansUint8Array(oUint8Array, sLongueur2, sRequeteFin);

					var tabHeadersSupplementaires = [{ sNom: "Content-Type", sValeur: "multipart/form-data, boundary=" + sBoundary}];
					if (!bCrm)
					{
						tabHeadersSupplementaires.push({ sNom: "Content-Length", sValeur: sLongueur3 });
					}
					this._Upload(oUint8Array.buffer, tabHeadersSupplementaires);
				};

				// Ajoute sendAsBinary sur XMLHttpRequest
				__WDUploadFileFileReader.prototype.__AjouteChaineDansUint8Array = function __AjouteChaineDansUint8Array(oUint8Array, nPosition, sChaine)
				{
					this.__AjouteUint8Array(oUint8Array, nPosition, new Uint8Array(Array.prototype.map.call(sChaine, function(x) { return x.charCodeAt(0) & 0xff; })));
				};
				// Ajoute sendAsBinary sur XMLHttpRequest
				__WDUploadFileFileReader.prototype.__AjouteUint8Array = function __AjouteUint8Array(oUint8ArrayDestination, nPosition, oUint8ArraySource)
				{
					oUint8ArrayDestination.set(oUint8ArraySource, nPosition);
				};

				return __WDUploadFileFileReader;
			})();
		}
	})();


	// Taille max d'un morceau de fichier uploadé (5Mo)
	WDUploadFile.TAILLE_MAX_MORCEAU = 5 * 1024 *1024;


	// Manipulation d'un Upload
	function __WDUploadBase(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChamp.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ sFiltre, sAliasChampDragDrop ]
			var sFiltre = tabParametresSupplementaires[0];
			var sAliasChampDragDrop = tabParametresSupplementaires[1];

			this.m_sFiltre = sFiltre;
			this.m_sAliasChampDragDrop = sAliasChampDragDrop;
			// Tableau des fichiers recus par DnD et par le champ input HTML5
			this.m_tabFiles = [];
			this.m_oStatusUpload = null;
			this.m_oStatusAvancement = null;
		}
	}

	// Declare l'heritage
	__WDUploadBase.prototype = new WDChamp();
	// Surcharge le constructeur qui a ete efface
	__WDUploadBase.prototype.constructor = __WDUploadBase;

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de WDChamp

	// Initialisation
	__WDUploadBase.prototype.Init = function Init()
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype.Init.apply(this, arguments);

		// Initialise le drag-drop sur le champ lie si besoin
		if (this.m_sAliasChampDragDrop)
		{
			// this : implémente une interface (qui n'existe pas vraiment) IDnDFichierCallback : avec les méthodes virtuelles "vbGetMultiFichiers", "vOnDropFichiers" et "vbGrise"
			this.m_oDnDFichiers = new WDDnDFichiers(this, _JGE(this.m_sAliasChampDragDrop, document, true, false));
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de IDnDFichierCallback

	// vbGetMultiFichiers : dans les classes dérivées

	// Changement du contenu de la liste des fichiers par DragDraop
	__WDUploadBase.prototype.vOnDropFichiers = function vOnDropFichiers(tabFichiers)
	{
		// Si on n'est pas en mode multifichiers : vide la liste courante
		if (!this.vbGetMultiFichiers())
		{
			this.SupprimeTout();
		}

		// Ajoute a la liste des fichiers
		var i;
		var nLimiteI = tabFichiers.length;
		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabFiles.push(tabFichiers[i]);
		}

		// Changement du contenu de la liste des fichiers
		this.OnChange();
	};
	
	// vbGrise : dans les classes dérivées

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de IUploadFileCallback

	// Maj de l'avancement depuis l'upload de fichiers
	__WDUploadBase.prototype.vUploadFileAvancement = function vUploadFileAvancement(oEvent, nTailleFichierEnvoyee, nTailleFichier)
	{
		var oStatusUpload = this.m_oStatusUpload;
	
		// Onupload toujours les fichiers dans un objet JS File avant les fichiers du champ Flash
		var nEnvoyee = oStatusUpload.m_nEnvoyeeFiles + nTailleFichierEnvoyee;

		// MAJ de l'affichage
		this.__OnAvancement(nEnvoyee, oStatusUpload.m_nTailleFiles + oStatusUpload.m_nTailleFlash, nTailleFichierEnvoyee, nTailleFichier, oStatusUpload.m_nFichier);
	};

	// Fin de l'upload d'un fichier (DnD ou input file HTML5)
	__WDUploadBase.prototype.vUploadFileFin = function vUploadFileFin(sData, nTailleFichier)
	{
		if (sData)
		{
			// Fichier suivant
			this.m_oStatusUpload.m_nEnvoyeeFiles += nTailleFichier;
			this.m_oStatusUpload.m_nFichier++;
			this.__UploadFiles(sData);
		}
	};
	
	// Erreur en de l'upload d'un fichier (DnD ou input file HTML5) (déclenche la fin de l'upload)
	__WDUploadBase.prototype.vUploadFileErreur = function vUploadFileErreur(sReponse, nStatus, sStatusText)
	{
		// Affiche le message d'erreur
		alert(STD_ERREUR_MESSAGE_UPLOAD + "\n" + (sReponse || (nStatus + " " + sStatusText)));
		// Fin de l'upload
		this.OnFin("");
	};

	// Interface AVEC le WL

	// ..Valeur
	__WDUploadBase.prototype.GetValeur = function GetValeur(oEvent, nOccurrence, oChamp)
	{
		// Rappel de la classe de base avec la bonne valeur
		return WDChamp.prototype.GetValeur.apply(this, [oEvent, this._vsGetFichiers(false, true, true), oChamp]);
	};

	// Lit les proprietes dont l'occurrence et []
	__WDUploadBase.prototype.GetProp = function GetProp(eProp, oEvent, oValeur/*, oChamp*/)
	{
		switch (eProp)
		{
		case this.XML_CHAMP_PROP_NUM_SOUSELEMENT:
			// Nom d'un sous element (= nom d'un fichier)
			return this.__tabGetFichier(oValeur - 1)[0];
		case this.XML_CHAMP_PROP_NUM_OCCURRENCE:
			// Traite le cas de ..Occurrence
			return this._vnGetOccurrence();
		default:
			// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
			return WDChamp.prototype.GetProp.apply(this, arguments);
		}
	};

	// Ecrit les proprietes dont l'occurrence : pas en ecriture
//	__WDUploadBase.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp, oXMLAction)

	// Submit de la page
	__WDUploadBase.prototype.OnSubmit = function OnSubmit()
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype.OnSubmit.apply(this, arguments);

		// Pas d'upload dans le submit pour le moment
	};

	// Fonction WL UploadLance
	// !!! Fonction en ellipse !!!
//	WDUploadBase.prototype.Lance = function Lance (sFonction)
	__WDUploadBase.prototype.Lance = function Lance()
	{
		// Appele la fonction interne commune avec OnSubmit
		// Prepare au passage les parametres
		this.__Lance(clWDUtil.sConstuitProcedureParams(0, arguments));
	};

	// Fonction principale de l'upload
	__WDUploadBase.prototype.__Lance = function __Lance(sParams)
	{
		// Si on a des fichier a uploader et que l'on n'est pas deja en cours d'upload
		if ((0 === this._vnGetOccurrence()) || this.__bGetUploadEnCours())
		{
			return;
		}

		// true : ajoute la marque de session
		var sAction = clWDUtil.sGetPageAction(null, false, true, true);
		sAction = sAction + ((sAction.indexOf("?") !== -1) ? "&" : "?");

		// - Prepare le parametre de session AWP
		var sParamAWP = "";
		// - Prepare le nom du champ
		var sNomChamp = "&WD_BUTTON_CLICK_=" + this.m_sAliasChamp;

		// La requete pour les fichiers normaux
		var sURL = sAction + "WD_ACTION_=UPLOADFICHIER" + sParamAWP + sNomChamp;
		// La requete pour le dernier fichier
		var sURLFinale;
		if (sParams !== undefined)
		{
			// Cas de UploadLance : avec procedure et parametre
			sURLFinale = sAction + "WD_ACTION_=UPLOADFICHIERFIN" + sParamAWP + sNomChamp + sParams;
		}
		else
		{
			// Cas du submit : upload normal
			// sURL contient deja sAction
			sURLFinale = sURL;
		}

		// Memorise le moment du lancement de l'upload pour avoir une reference pour les reveils periodiques du serveur
		this.m_nReveilDernier = (new Date()).getTime();
		// Avec l'action serveur
		this.m_sReveilURL = sAction + "WD_ACTION_=UPLOADREVEIL" + sParamAWP + sNomChamp;

		// Construit un objet upload de drag-drop
		this.m_oStatusUpload =
		{
			m_sURL: sURL,
			m_sURLFinale: sURLFinale,
			m_nFichier: 0,
			// Calcule la taille des fichiers de l'upload et du flash
			m_nTailleFiles: this.__nGetTailleTotale(this._vsGetFichiers(true, true, false)),
			m_nTailleFlash: this.__nGetTailleTotale(this._vsGetFichiers(true, false, true)),
			m_nEnvoyeeFiles: 0
		};

		// Lance l'upload en commencant par les fichiers en drag-drop
		// (s'il n'y en a pas cela continura automatiquement sur l'upload flash)
		this.__UploadFiles();
	};
	__WDUploadBase.prototype.__UploadFiles = function __UploadFiles(sDataFichierPrecedent)
	{
		var bUpload = this._vbUploadFiles();
		// Si on n'a plus de fichier
		if (!bUpload)
		{
			// Fin de l'upload
			this.OnFin(sDataFichierPrecedent);
		}
	};
	__WDUploadBase.prototype._vbUploadFiles = function _vbUploadFiles()
	{
		var oStatusUpload = this.m_oStatusUpload;
		var nFichier = this.m_oStatusUpload.m_nFichier;
		var tabFiles = this.m_tabFiles;
		if (nFichier < tabFiles.length)
		{
			// Lance l'upload
			var sURL;
			var nNbFiles = tabFiles.length;
			if ((nFichier === (nNbFiles - 1)) && (nNbFiles === this._vnGetOccurrence()))
			{
				// Dernier fichier
				sURL = oStatusUpload.m_sURLFinale;
			}
			else
			{
				sURL = oStatusUpload.m_sURL;
			}
			new WDUploadFile(this, tabFiles[nFichier], sURL, oStatusUpload.m_sURL);
			// On a lancé l'upload 'un fichier
			return true;
		}
		else
		{
			// On n'a plus de fichier
			return false;
		}
	};

	// Calcule la taille totale depuis liste des fichiers avec les tailles
	__WDUploadBase.prototype.__nGetTailleTotale = function __nGetTailleTotale(sFichiersAvecTaille)
	{
		var nTailleTotale = 0;
		if (0 < sFichiersAvecTaille.length)
		{
			// Transforme la chaine en tableau
			var tabFichiersAvecTaille = sFichiersAvecTaille.split("\r\n");
			var i;
			var nLimiteI = tabFichiersAvecTaille.length;
			for (i = 0; i < nLimiteI; i++)
			{
				var tabFichier = tabFichiersAvecTaille[i].split("\t");
				nTailleTotale += parseInt(tabFichier[1], 10);
			}
		}
		return nTailleTotale;
	};

	// Recupere les informations sur un fichier (nFichier est en indice C)
	__WDUploadBase.prototype.__tabGetFichier = function __tabGetFichier(nFichier)
	{
		// Recupere la liste des fichiers;
		var sValeur = this._vsGetFichiers(true, true, true);
		// Transforme la chaine en tableau
		var tabValeur = sValeur.split("\r\n");

		// Recupere la valeur si l'indice est valide
		if ((nFichier >= 0) && (nFichier < tabValeur.length))
		{
			var tabFichier = tabValeur[nFichier].split("\t");
			tabFichier[1] = parseInt(tabFichier[1], 10);
			return tabFichier;
		}
		return ["", 0];
	};
	__WDUploadBase.prototype._vsGetFichiers = function _vsGetFichiers(bAvecTaille, bFiles/*, bFlash*/)
	{
		if (bFiles)
		{
			var tabFichiers = [];
			clWDUtil.bForEach(this.m_tabFiles, function(oFichier)
			{
				tabFichiers.push(oFichier.name + (bAvecTaille ? ("\t" + oFichier.size) : ""));
				return true;
			});
			return tabFichiers.join("\r\n");
		}
		else
		{
			return "";
		}
	};

	__WDUploadBase.prototype._vnGetOccurrence = function _vnGetOccurrence()
	{
		return this.m_tabFiles.length;
	};

	__WDUploadBase.prototype.__bGetUploadEnCours = function __bGetUploadEnCours()
	{
		return !!this.m_oStatusUpload;
	};

	// Fonctions WL UploadTailleXXX
	__WDUploadBase.prototype.nGetProgressData = function nGetProgressData(eInformation)
	{
		// Si on est dans un upload : this.m_oProgressData est indexe sur les ms_eProgressDataXXX
		// Si on est pas dans un upload : this.m_oProgressData est vidé
		// Enumeration eUPLOADPROGRESSDATA
		var oStatusAvancement = this.m_oStatusAvancement;
		if (oStatusAvancement)
		{
			switch (eInformation)
			{
			case 0:
				return oStatusAvancement.m_nEnvoyee;
			case 1:
				return oStatusAvancement.m_nTailleTotale;
			case 2:
				return oStatusAvancement.m_nTailleFichierEnvoyee;
			case 3:
				return oStatusAvancement.m_nFichierTaille;
			case 4:
				return oStatusAvancement.m_nFichier;
			}
		}
		// Hors upload ou constante invalide
		return 0;
	};

	// Fonction WL UploadSupprime
	__WDUploadBase.prototype.Supprime = function Supprime(nPositionWL)
	{
		this._vnSupprimeFichier(nPositionWL);
	};
	// Supprime un fichier : retourne -1 si on a supprimer un fichier, sinon retourne l'indice décalé des éléments ignorés
	__WDUploadBase.prototype._vnSupprimeFichier = function _vnSupprimeFichier(nPositionWL)
	{
		var tabFiles = this.m_tabFiles;
		var nPositionC = nPositionWL - 1;
		if (nPositionC < tabFiles.length)
		{
			tabFiles[nPositionC] = null;
			tabFiles.splice(nPositionC, 1);
			// GP 29/08/2016 : QW275868 : On a supprimer un fichier : notifie de la modification et retourne -1
			this.OnChange();
			return -1;
		}

		// Retourne l'indice décalé des éléments ignorés
		return nPositionWL - tabFiles.length;
	};

	// Fonction WL UploadSupprimeTout
	__WDUploadBase.prototype.SupprimeTout = function SupprimeTout()
	{
		// GP 29/08/2016 : QW275868 : Retourne true si la liste a été modifiée et qu'il faut faire un appel de OnChange
		if (this._vbSupprimeTousFichiers())
		{
			this.OnChange();
		}
	};
	// Retourne true si la liste a étét modifiée et qu'il faut faire un appel de OnChange
	__WDUploadBase.prototype._vbSupprimeTousFichiers = function _vbSupprimeTousFichiers()
	{
		var bModifie = false;

		var tabFiles = this.m_tabFiles;
		var i;
		var nLimiteI = tabFiles.length;
		for (i = 0; i < nLimiteI; i++)
		{
			tabFiles[i] = null;
			bModifie = true;
		}
		tabFiles.length = 0;
		
		return bModifie;
	};

	// Fonction WL UploadTailleFichier
	__WDUploadBase.prototype.nGetUploadTailleFichier = function nGetUploadTailleFichier(nIndiceFichierWL)
	{
		if (!nIndiceFichierWL)
		{
			nIndiceFichierWL = 1;
		}
		// Passe en indice C
		return this.__tabGetFichier(nIndiceFichierWL - 1)[1];
	};

	// Interface pour le flash

	// Progression de l'upload version interne
	__WDUploadBase.prototype.__OnAvancement = function __OnAvancement(nEnvoyee, nTailleTotale, nTailleFichierEnvoyee, nFichierTaille, nFichier)
	{
		// Effectue un reveil periodique de la session pour que un upload long ne la fasse pas tomber en timeout
		var nMaintenant = (new Date()).getTime();
		// Si le dernier reveil est trop ancien, en effectue un autre
		// Toutes les 3 minutes
		if (this.m_nReveilDernier && ((nMaintenant - this.m_nReveilDernier) > 180000))
		{
			// Requete AJAX vers le serveur (la valeur de retourne n'est pas vraiment une image)
			clWDUtil.PrechargeImage(this.m_sReveilURL + "&RAND=" + Math.random());
			this.m_nReveilDernier = nMaintenant;
		}
		
		var oStatusUpload = this.m_oStatusUpload;

		// MAJ du de l'état
		var oStatusAvancement = {
			m_nEnvoyee: nEnvoyee,
			m_nTailleTotale: nTailleTotale,
			m_nTailleFichierEnvoyee: nTailleFichierEnvoyee,
			m_nFichierTaille: nFichierTaille,
			// Passe nFichier de l'indice C en indice WL
			m_nFichier: nFichier + 1
		};
		this.m_oStatusAvancement = oStatusAvancement;

		// Appele le PCode
		// Pas d'event
		this.RecuperePCode(this.ms_nEventNavUploadAvancement)();
		
		this.m_oStatusAvancement = null;
	};

	// Changement du contenu de la liste des fichiers
	__WDUploadBase.prototype.OnChange = function OnChange()
	{
		// Appele le PCode
		// Pas d'event
		this.RecuperePCode(this.ms_nEventNavUploadSelection)();
	};

	// Fin de l'upload
	// Appel depuis le flash possible
	__WDUploadBase.prototype.OnFin = function OnFin(sData)
	{
		// Supprime les fichiers recus par drag-drop (et les fichiers de flash mais ils sont déjà supprimés)
		this.SupprimeTout();

		this.m_oStatusUpload = null;

		// Si on a des donnees : appel le traitement en AJAX
		clWDAJAXMain.eReponseGeneriqueDepuisTexte(sData, _PAGE_, []);

		// Appele le PCode
		// Pas d'event
		this.RecuperePCode(this.ms_nEventNavUploadFin)();
	};

	return __WDUploadBase;
})();

// Manipulation d'un champ upload utilisant Flash
var WDUploadFlash = (function()
{
	"use strict";

	function __WDUploadFlash(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDUploadBase.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ sFiltre, sAliasChampDragDrop ]

			this.m_oFlash = null;
		}
	}

	// Declare l'heritage
	__WDUploadFlash.prototype = new WDUploadBase();
	// Surcharge le constructeur qui a ete efface
	__WDUploadFlash.prototype.constructor = __WDUploadFlash;

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de WDChamp

	// Initialisation
	__WDUploadFlash.prototype.Init = function Init()
	{
		// Appel de la methode de la classe de base
		WDUploadBase.prototype.Init.apply(this, arguments);

		// Lien avec le champ flash
		this._InitFlash();
	};

	// Trouve les divers elements : liaison avec le HTML
	__WDUploadFlash.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
	{
		// Appel de la classe de base
		WDUploadBase.prototype._vLiaisonHTML.apply(this, arguments);

		// Recupere le champ input ou le champ flash
		this.m_oFlash = this.oGetObjectEmbed(this.m_sAliasChamp, bIE);
	};

	// Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
	__WDUploadFlash.prototype.OnDisplay = function OnDisplay(oElementRacine, bAffiche)
	{
		// Appel de la methode de la classe de base
		WDUploadBase.prototype.OnDisplay.apply(this, arguments);

		// Reinit les membres du flash (requis dans le cas d'un pageaffiche dialogue)
		if (bAffiche && this.m_oFlash && clWDUtil.bEstFils(this.m_oFlash, oElementRacine))
		{
			// Reinit les membres du flash (requis dans le cas d'un pageaffiche dialogue)
			// => Replace la liaison avec le HTML
			this._vLiaisonHTML();

			// Si le flash est deplace dans le DOM, il faut refixer sa valeur sinon le lien avec les fonctions interne est perdu
			// GP 04/03/2013 : TB81288 : Quand le champ est masqué, flash supprime l'export des fonctions. Il faut le forcer à le remettre
			// Pour Firefox qui a le bug
			if (bFF)
			{
				this.m_oFlash.data = this.m_oFlash.data;
			}
			// GP 21/02/2018 : TB100003 : Il faut refaire le lien à tous les affichages avec toutes les versions de IE : remplace bIE par bIEAvec11.
			else if (bIEAvec11)
			{
				if (undefined !== this.m_oFlash.src)
				{
					// GP 06/07/2012 : TB77857 : Aussi dans IE
					this.m_oFlash.src = this.m_oFlash.src;
				}
//				else if (this.m_oFlash.object && this.m_oFlash.object.Movie)
//				{
//					this.m_oFlash.object.Movie = "";
//					this.m_oFlash.object.Movie = this.m_oFlash.object.Movie;
//				}
				else
				{
					this.m_oFlash.outerHTML = this.m_oFlash.outerHTML;
					// Recupere le champ flash
					this.m_oFlash = this.oGetObjectEmbed(this.m_sAliasChamp, bIE);
				}
			}

			this._InitFlash();
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de WDUploadBase

	__WDUploadFlash.prototype._vsGetFichiers = function _vsGetFichiers(bAvecTaille, bFiles, bFlash)
	{
		// Appel de la methode de la classe de base
		var sFichiers = WDUploadBase.prototype._vsGetFichiers.apply(this, arguments);

		// GP 24/05/2013 : TB79102 : Filtre le cas de flash invisible
		if (bFlash && this.m_oFlash && clWDUtil.bEstDisplay(this.m_oFlash, document, true))
		{
			var sFichiersFlash = this.m_oFlash.sGetFichiers(bAvecTaille);
			if (0 < sFichiersFlash.length)
			{
				if (0 < sFichiers.length)
				{
					sFichiers += "\r\n";
				}
				sFichiers += sFichiersFlash;
			}
		}
		return sFichiers;
	};

	__WDUploadFlash.prototype._vnGetOccurrence = function _vnGetOccurrence()
	{
		// Appel de la methode de la classe de base
		return WDUploadBase.prototype._vnGetOccurrence.apply(this, arguments) + this.__nGetOccurrenceFlash();
	};

	// Fonction principale de l'upload
	__WDUploadFlash.prototype._vbUploadFiles = function _vbUploadFiles()
	{
		// Appel de la methode de la classe de base
		var bUpload = WDUploadBase.prototype._vbUploadFiles.apply(this, arguments);
		// L'upload d'un fichier en DnD a été lancé
		if (bUpload)
		{
			return true;
		}

		// Il n'y a plus de fichiers à uploader depuis le DnD ou le champ input HTML5
		try
		{
			// Lancement de l'upload du champ (input+file ou Flash) si il contient des fichiers
			if (0 < this.__nGetOccurrenceFlash())
			{
				var oStatusUpload = this.m_oStatusUpload;
				// Notifie le flash
				this.m_oFlash.SetURLs(oStatusUpload.m_sURL, oStatusUpload.m_sURLFinale);

				// Lance l'upload
				this.m_oFlash.ActionUpload();
				return true;
			}
		}
		catch (e)
		{
			// Ne fait rien : déclenche le return false qui déclenche l'appel du OnFin qui termine l'upload
		}

		// Plus de fichiers
		return false;
	};

//	__WDUploadFlash.prototype._vbGetUploadEnCoursFlash = function _vbGetUploadEnCoursFlash()
//	{
//		// GP 24/05/2013 : TB79102 : Filtre le cas de flash invisible
//		if (this.m_oFlash && clWDUtil.bEstDisplay(this.m_oFlash, document, true))
//		{
//			return (true == this.m_oFlash.bGetUploadEnCours());
//		}
//
//		// Pas de champ ou champ flash invisible
//		return false;
//	};

	// Supprime un fichier : retourne -1 si on a supprimer un fichier, sinon retourne l'indice décalé des éléments ignorés
	__WDUploadFlash.prototype._vnSupprimeFichier = function _vnSupprimeFichier(nPositionWL)
	{
		// Appel de la methode de la classe de base
		nPositionWL = WDUploadBase.prototype._vnSupprimeFichier.apply(this, arguments);

		// Si le fichier n'a pas été supprimé
		if ((-1 !== nPositionWL) && this.m_oFlash)
		{
			// Le code flash attend un indice WL sous forme de chaine
			this.m_oFlash.ActionSupprime(nPositionWL + "");
		}
	};

	__WDUploadFlash.prototype._vbSupprimeTousFichiers = function _vbSupprimeTousFichiers()
	{
		// Appel de la methode de la classe de base
		var bModifie = WDUploadBase.prototype._vbSupprimeTousFichiers.apply(this, arguments);
	
		if (this.m_oFlash)
		{
			this.m_oFlash.ActionSupprimeTout();
			// En interne flash déclenche l'appel de OnChange
			bModifie = false;
		}
		
		return bModifie;
	};

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de IDnDFichierCallback

	__WDUploadFlash.prototype.vbGetMultiFichiers = function vbGetMultiFichiers()
	{
		if (this.m_oFlash && clWDUtil.bEstDisplay(this.m_oFlash, document, true))
		{
			return !!this.m_oFlash.bGetMultiFichiers();
		}

		return false;
	};

	__WDUploadFlash.prototype.vbGrise = function vbGrise()
	{
		// Ne gère pas le grisé (= comme avant)
		return false;
	};

	//////////////////////////////////////////////////////////////////////////
	// Méthodes spécifiques

	// Init interne (aussi appele lors de l'affichage)
	__WDUploadFlash.prototype._InitFlash = function _InitFlash()
	{
		// Donne au flash le nom du champ
		this.nSetTimeout(this.__InitFlash, 500);

		// Hack pour chrome/safari qui ne met pas le champ flash dans le formulaire
		if (bWK)
		{
			_PAGE_[this.m_sAliasChamp] = this.m_oFlash;
		}
	};

	// Initialise le flahs en lui donnant ses parametres
	__WDUploadFlash.prototype.__InitFlash = function __InitFlash()
	{
		// Si le champ n'est pas visible (display:none), certains navigateurs n'affichent pas le champ
		// Ce n'est pas grave de ne pas faire l'init car en cas d'affichage, on recoit un OnDisplay
		// GP 04/03/2013 : TB81288 : On ne fait rien sans this.m_oFlash, on ne fait rien s'il n'est pas visible
		if (this.m_oFlash && clWDUtil.bEstDisplay(this.m_oFlash, document, true))
		{
			try
			{
				// Donne le nom du champ (normalement deja fait)
				this.m_oFlash.SetAlias(this.m_sAliasChamp);
				// Et le filtre
				this.m_oFlash.SetFiltre(this.m_sFiltre);
			}
			catch (e)
			{
				// Donne au flash le nom du champ
				this.nSetTimeout(this.__InitFlash, 500);
			}
		}
	};

	__WDUploadFlash.prototype.__nGetOccurrenceFlash = function __nGetOccurrenceFlash()
	{
		// GP 24/05/2013 : TB79102 : Filtre le cas de flash invisible
		if (this.m_oFlash && clWDUtil.bEstDisplay(this.m_oFlash, document, true))
		{
			// GP 24/05/2013 : TB79102 : Filtre le cas de flash invisible
			return parseInt(this.m_oFlash.nGetOccurrence(), 10);
		}

		// Pas de champ ou champ flash invisible
		return 0;
	};
	
	// Appel d'une methode depuis le flash
	// => Il faut utiliser AppelMethodeChamp

	// Progression de l'upload (version flash non renomme car appele du flash)
	__WDUploadFlash.prototype.OnAvancement = function OnAvancement(nEnvoyee, nTotal_Inutile, nTailleFichierEnvoyee, nFichierTaille, nFichier)
	{
		if (isNaN(nEnvoyee))
		{
			// Affiche le message d'erreur
			alert(STD_ERREUR_MESSAGE_UPLOAD);
			// Et force une MAJ de l'affichage
			nEnvoyee = 1;
		}

		// Calcule qui a deja ete envoie par l'upload AJAX des fichiers drag-drop
		var oStatusUpload = this.m_oStatusUpload;
		oStatusUpload.m_nFichier = this.m_tabFiles.length + nFichier;

		// Normalement la progression du DnD est fini donc tout a été envoyé
		nEnvoyee += oStatusUpload.m_nTailleFiles;

		// Pour eviter les messages de flash sur le script qui s'execute trop longtemp, on repouse l'appel
		// Si un appel est deja en attente : pas d'empilage
		// En revanche les dernieres donnees sont utilisees (voir la ligne au dessus)
		this.nSetTimeoutUnique("__OnAvancement", clWDUtil.ms_oTimeoutImmediat, nEnvoyee, oStatusUpload.m_nTailleFiles + oStatusUpload.m_nTailleFlash, nTailleFichierEnvoyee, nFichierTaille, oStatusUpload.m_nFichier);
	};

	return __WDUploadFlash;
})();
// GP 10/03/2016 : Par compatibilité on conserve le nom WDUpload pour l'upload flash
var WDUpload = WDUploadFlash;

// Manipulation d'un champ upload utilisant HTML5
var WDUploadHTML5 = (function()
{
	"use strict";

	function __WDUploadHTML5(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDUploadBase.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ sFiltre, sAliasChampDragDrop ]

			this.m_oButton = null;
			this.m_oInput = null;
			var oThis = this;
			this.m_pfOnChange = function (oEvent) { return oThis.__OnChange(oEvent || event); };
		}
	}

	// Declare l'heritage
	__WDUploadHTML5.prototype = new WDUploadBase();
	// Surcharge le constructeur qui a ete efface
	__WDUploadHTML5.prototype.constructor = __WDUploadHTML5;

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de WDChamp

//	// Initialisation
//	__WDUploadHTML5.prototype.Init = function Init()
//	{
//		// Appel de la methode de la classe de base
//		WDUploadBase.prototype.Init.apply(this, arguments);
//
//		// Aucune autre initialisation spécifique
//	};

	// Trouve les divers elements : liaison avec le HTML
	__WDUploadHTML5.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
	{
		// Appel de la classe de base
		WDUploadBase.prototype._vLiaisonHTML.apply(this, arguments);

		// Recupere le champ input qui est en fait juste derrière le bouton.
		this.m_oButton = this.oGetElementById(document, "");
		this.m_oInput = this.m_oButton.nextElementSibling;
		
		// Se branche sur le onchange du champ
		if (this.m_oInput)
		{
			// Détache pour le cas d'un attachement précédent
			clWDUtil.AttacheDetacheEvent(false, this.m_oInput, "change", this.m_pfOnChange, false);
			clWDUtil.AttacheDetacheEvent(true, this.m_oInput, "change", this.m_pfOnChange, false);

			// GP 27/02/2017 : TB101794 : Il faut transmettre le filtre s'il existe
			if (this.m_sFiltre)
			{
				var sFiltreFinal;
				// Si la chaine contient des / (des types MIME), l'utilise directement
				if (-1 < this.m_sFiltre.indexOf("/"))
				{
					sFiltreFinal = this.m_sFiltre;
				}
				else
				{
					var tabFiltreHTML = [];
					// Le format "serveur" est "<Libelle 1><TAB>*.<Extension 1 1>;...;*.<Extension 1 n><RC>...<RC><Libelle m>+<TAB>+*.<Extension m 1>;...;*.<Extension m n>"
					clWDUtil.bForEach(this.m_sFiltre.split("\r\n"), function (sLigneFiltre)
					{
						if (sLigneFiltre)
						{
							var sExtensions = sLigneFiltre.split("\t")[1];
							if (sExtensions)
							{
								clWDUtil.bForEach(sExtensions.split(";"), function (sExtension)
								{
									if (sExtension)
									{
										sExtension = clWDUtil.sSupprimeEspacesDebutFin(sExtension);
										if ("*" == sExtension.charAt(0))
										{
											sExtension = sExtension.substr(1);
										}
										tabFiltreHTML.push(sExtension);
									}
									return true;
								});
							}
						}
						return true;
					});
					sFiltreFinal = tabFiltreHTML.join(",");
				}
				if (sFiltreFinal)
				{
					this.m_oInput.accept = sFiltreFinal;
				}
			}
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de WDUploadBase

	//////////////////////////////////////////////////////////////////////////
	// Implémentation des méthodes de IDnDFichierCallback

	__WDUploadHTML5.prototype.vbGetMultiFichiers = function vbGetMultiFichiers()
	{
		if (this.m_oInput)
		{
			return this.m_oInput.multiple;
		}

		return false;
	};
	
	__WDUploadHTML5.prototype.vbGrise = function vbGrise()
	{
		// Ne gère pas le grisé (= comme avant)
		return this._bEstGrise(this.m_oButton);
	};

	//////////////////////////////////////////////////////////////////////////
	// Méthodes spécifiques

	// Sélection de fichier via le bouton associé au champ upload HTML5
	__WDUploadHTML5.prototype.OnClick = function OnClic(/*oEvent*/)
	{
		if (this.m_oInput)
		{
			this.m_oInput.click();
		}
	};
	
	// GP 29/08/2016 : QW275868 : Le traitement de l'appel en programmation du click est asynchrone dans Firefox et Chrome
	__WDUploadHTML5.prototype.__OnChange = function __OnChange(oEvent)
	{
		// Il n'est pas possible de changer la liste des fichiers (accès en lecture seule uniquement)
		// L'idée générale est :
		// - Mémoriser la position du champ formulaire
		// - Création d'un formulaire temporaire (le formulaire est en fin de document pour ne pas avoir de formulaires imbriqués)
		// - De déplacer le champ dedans
		// - RAZ du formulaire
		// - Replacer le champ à sa place
		// - Supprimer le formulaire temporaire
		var oInput = this.m_oInput;

	
		// Récupère la liste des fichiers
		this.vOnDropFichiers(oInput.files);

		// - Mémoriser la position du champ formulaire
		var oInputNextSibling = this.m_oInput.nextElementSibling;
		var oInputParent = this.m_oInput.parentNode;

		// - Création d'un formulaire temporaire (le formulaire est en fin de document pour ne pas avoir de formulaires imbriqués)
		var oFormulaire = document.body.appendChild(document.createElement("form"));

		// - De déplacer le champ dedans
		oInput = oFormulaire.appendChild(oInputParent.removeChild(oInput));

		// - RAZ du formulaire
		oFormulaire.reset();

		// - Replacer le champ à sa place
		this.m_oInput = oInputParent.insertBefore(oInput, oInputNextSibling);

		// - Supprimer le formulaire temporaire
		oFormulaire.parentNode.removeChild(oFormulaire);

		return clWDUtil.bStopPropagationCond(oEvent, true);
	};

	return __WDUploadHTML5;
})();
