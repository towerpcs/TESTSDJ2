// WDVideo.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS bIE nIE bIEQuirks bIEAvec11 bCrm bWK
// - WDChamp.js
///#GLOBALS WDChamp
// - WWConstanteX.js
///#GLOBALS STD_ERREUR_MESSAGE_VIDEO
// - Autres
///#GLOBALS YT

//////////////////////////////////////////////////////////////////////////
// Manipulation des champs video

// Manipulation d'un champ video
var WDVideo = (function ()
{
	// Constantes
	var ms_eEtatArret = 1;
	var ms_eEtatPause = 2;
	var ms_eEtatJoue = 3;

	var ms_eControlesSans = 0;
	var ms_eControlesSimple = 1;
	var ms_eControlesComplet = 2;

	var ms_ePlayerDefaut = 0;
	var ms_ePlayerWindowsMedia = 1;
//	var ms_ePlayerFlashRecent = 2;
//	var ms_ePlayerFlashAncien = 3;
	var ms_ePlayerQuickTime = 4;
	var ms_ePlayerHTML5Video = 5;
	var ms_ePlayerObjectSimple = 6;
	var ms_ePlayerHTML5Audio = 7;
	var ms_ePlayerYouTube = 8;
	var ms_eVideoWindowsMedia = 0;
//	var ms_eVideoFlash = 1;
	var ms_eVideoMP4 = 2;
	var ms_eVideoMPG = 3;
	var ms_eVideoQuickTime = 4;
	var ms_eVideoOGG = 5;
	var ms_eVideoMKV = 6;
	var ms_eVideoAutres = 7;
	var ms_eVideoAucune = 8;
	var ms_eVideoWEBM = 9;
	var ms_eVideoYouTube = 10;

	// Classe de base de la manipulation des differents players
	var WDVideoPlayer = (function ()
	{
		function __WDVideoPlayer(oChampVideo, oParamVideo)
		{
			// Recuperes les parametres
			if (oParamVideo)
			{
				this.m_oChampVideo = oChampVideo;
				// Ignore eType, ePlayerDefaut et bDemarrageAuto
				// Construit le tableau des fichiers
				this.m_tabFichiers = __s_tabConstruitFichiers(oParamVideo);
				// Construit le tableau des sous-titres (en fait r�cup�re directement le tableau des param�tres
				this.m_tabSousTitres = oParamVideo.m_tabSousTitres;
				this.m_sImage = oParamVideo.sImage;
				this.m_sLibelle = oParamVideo.sLibelle;
				this.m_bPleinEcran = oParamVideo.bPleinEcran;
				this.m_bBoucle = oParamVideo.bBoucle;
				this.m_eControles = oParamVideo.eControles;
				this.m_sHTMLDefaut = oParamVideo.sHTMLDefaut;
				this.m_bDemarrageAuto = oParamVideo.bDemarrageAuto;
			}
		}

		// Methodes par defaut (retourne la valeur d'erreur)
		// Lance la lecture
		__WDVideoPlayer.prototype.vbJoue = function vbJoue() { return false; };
		__WDVideoPlayer.prototype.vbPause = function vbPause() { return false; };
		__WDVideoPlayer.prototype.vbArret = function vbArret() { return false; };
		__WDVideoPlayer.prototype.vnGetEtat = function vnGetEtat() { return ms_eEtatArret; };
		__WDVideoPlayer.prototype.vbVaDebut = function vbVaDebut() { return this.vbSetPosition(0); };
		__WDVideoPlayer.prototype.vbVaFin = function vbVaFin() { return this.vbSetPosition(this.vnGetDuree()); };
		__WDVideoPlayer.prototype.vnGetPosition = function vnGetPosition() { return 0; };
		__WDVideoPlayer.prototype.vbSetPosition = function vbSetPosition(/*nPosition*/) { return false; };
		__WDVideoPlayer.prototype.vnGetDuree = function vnGetDuree() { return 0; };
		__WDVideoPlayer.prototype.vnGetHauteur = function vnGetHauteur() { return 0; };
		__WDVideoPlayer.prototype.vnGetLargeur = function vnGetLargeur() { return 0; };
		__WDVideoPlayer.prototype.vnGetVolume = function vnGetVolume() { return 100; };
		__WDVideoPlayer.prototype.vbSetVolume = function vbSetVolume(/*nVolume*/) { return false; };
		// Ces m�thodes sont uniquement pour les d�riv�es de WDVideoPlayerHTML.
//		__WDVideoPlayer.prototype._vsGetAttributsObject = function _vsGetAttributsObject() { return ""; };
//		__WDVideoPlayer.prototype._vsGetParamsObject = function _vsGetParamsObject() { return ""; };
//		__WDVideoPlayer.prototype._vsGetAttributsEmbed = function _vsGetAttributsEmbed() { return ""; };
//		__WDVideoPlayer.prototype._vsGetParamsEmbed = function _vsGetParamsEmbed() { return ""; };

		// Pour l'init
		function __s_tabConstruitFichiers(oParamVideo)
		{
			var tabVideos;
			// Si on n'a que un fichier (ancien format)
			if (undefined !== oParamVideo.sFichier)
			{
				tabVideos = [oParamVideo];
			}
			else if (undefined !== oParamVideo.m_tabVideos)
			{
				tabVideos = oParamVideo.m_tabVideos;
			}
			else
			{
				tabVideos = [];
			}

			var tabFichiers = [];
			clWDUtil.bForEach(tabVideos, function (oFichier)
			{
				tabFichiers.push({ m_sFichier: oFichier.sFichier, m_sTypeMIME: oFichier.m_sTypeMIME });
				return true;
			});
			return tabFichiers;
		}

		// Construit le champ : a impl�menter
//		__WDVideoPlayer.prototype.vConstruitPlayer = function vConstruitPlayer(oConteneur, bAccepteObject)

		// Recup�re un fichier video
		__WDVideoPlayer.prototype._sGetFichier = function _sGetFichier(nFichier)
		{
			return this.m_tabFichiers[nFichier].m_sFichier;
		};

		return __WDVideoPlayer;
	})();

	// Classe de base de la manipulation des differents players
	var WDVideoPlayerHTML = (function ()
	{
		function __WDVideoPlayerHTML(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoPlayer.prototype.constructor.apply(this, arguments);

				// Init specifique
				this.m_oObjet = null;
			}
		}
		__WDVideoPlayerHTML.prototype = new WDVideoPlayer();
		__WDVideoPlayerHTML.prototype.constructor = __WDVideoPlayerHTML;

		// Construit le champ
		__WDVideoPlayerHTML.prototype.vConstruitPlayer = function vConstruitPlayer(oConteneur, bAccepteObject)
		{
			oConteneur.innerHTML = this._vsGetPlayerHTML(oConteneur);

			// Recupere le champ
			// GP 03/12/2015 : TB90136 : Ajout de bAccepteEmbebPremier pour faire un cas particulier et ne pas prendre de risque avec le reste du code
			this.m_oObjet = this.m_oChampVideo.oGetObjectEmbed(this.m_oChampVideo.m_sAliasChamp, bAccepteObject, true);
		};

		// Helper pour la construction
		function __s_sGetAttributsMin(sAliasChamp)
		{
			return "name=\"" + sAliasChamp + "\" width=\"100%\" height=\"100%\" ";
		}
		__WDVideoPlayerHTML.prototype._sGetEmbed = function _sGetEmbed()
		{
			return "<embed " + __s_sGetAttributsMin(this.m_oChampVideo.m_sAliasChamp) + this._vsGetAttributsEmbed() + " " + this._vsGetParamsEmbed() + "></embed>";
		};

		// Construit le html du champ
		__WDVideoPlayerHTML.prototype._vsGetPlayerHTML = function _vsGetPlayerHTML(/*oConteneur*/)
		{
			// Balise OBJECT + EMBED
			var sAliasChamp = this.m_oChampVideo.m_sAliasChamp;

			return	"<object id=\"" + sAliasChamp + "\" " + __s_sGetAttributsMin(sAliasChamp) + this._vsGetAttributsObject() + ">" +
					this._vsGetParamsObject() +
					this._sGetEmbed() +
					"</object>";
		};

		// Methodes par defaut (retourne la valeur d'erreur)
		__WDVideoPlayerHTML.prototype._vsGetAttributsObject = function _vsGetAttributsObject() { return ""; };
		__WDVideoPlayerHTML.prototype._vsGetParamsObject = function _vsGetParamsObject() { return ""; };
		__WDVideoPlayerHTML.prototype._vsGetAttributsEmbed = function _vsGetAttributsEmbed() { return ""; };
		__WDVideoPlayerHTML.prototype._vsGetParamsEmbed = function _vsGetParamsEmbed() { return ""; };

		// Recup�re un fichier video
		__WDVideoPlayerHTML.prototype._sGetFichier = function _sGetFichier(nFichier)
		{
			return this.m_tabFichiers[nFichier].m_sFichier;
		};

		return __WDVideoPlayerHTML;
	})();

	// Manipulation de media player
	var WDVideoMediaPlayer = (function ()
	{
		function __WDVideoMediaPlayer(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoPlayerHTML.prototype.constructor.apply(this, arguments);

				// Init specifique
			}
		}
		__WDVideoMediaPlayer.prototype = new WDVideoPlayerHTML();
		__WDVideoMediaPlayer.prototype.constructor = __WDVideoMediaPlayer;

		__WDVideoMediaPlayer.prototype.vbJoue = function vbJoue() { this.m_oObjet.controls.play(); return true; };
		__WDVideoMediaPlayer.prototype.vbPause = function vbPause() { this.m_oObjet.controls.pause(); return true; };
		__WDVideoMediaPlayer.prototype.vbArret = function vbArret() { this.m_oObjet.controls.stop(); return true; };
		// Les etats generaux (stop pause play correspondent au constantes WL)
		__WDVideoMediaPlayer.prototype.vnGetEtat = function vnGetEtat() { return this.m_oObjet.playState; };
		__WDVideoMediaPlayer.prototype.vnGetPosition = function vnGetPosition() { return Math.floor(this.m_oObjet.controls.currentPosition * 1000); };
		__WDVideoMediaPlayer.prototype.vbSetPosition = function vbSetPosition(nPosition) { this.m_oObjet.controls.currentPosition = nPosition / 1000; return true; };
		__WDVideoMediaPlayer.prototype.vnGetDuree = function vnGetDuree() { return this.m_oObjet.controls.currentItem.duration * 1000; };
		__WDVideoMediaPlayer.prototype.vnGetHauteur = function vnGetHauteur() { return this.m_oObjet.controls.currentItem.imageSourceHeight; };
		__WDVideoMediaPlayer.prototype.vnGetLargeur = function vnGetLargeur() { return this.m_oObjet.controls.currentItem.imageSourceWidth; };
		// GP 31/03/2014 : TB76611 : Le membre est "settings" avec un "s" minuscule. On n'a pas le probl�me avec IE car il est insensible � la casse dans ce genre de cas.
		__WDVideoMediaPlayer.prototype.vnGetVolume = function vnGetVolume() { return this.m_oObjet.settings.volume; };
		__WDVideoMediaPlayer.prototype.vbSetVolume = function vbSetVolume(nVolume) { this.m_oObjet.settings.volume = nVolume; return true; };

		// Recupere le mode d'interface
		__WDVideoMediaPlayer.prototype._sGetUiMode = function _sGetUiMode()
		{
			switch (this.m_eControles)
			{
			case ms_eControlesSans:
				return "none";
			default:
			case ms_eControlesSimple:
				return "mini";
			case ms_eControlesComplet:
				return "full";
			}
		};

		return __WDVideoMediaPlayer;
	})();

	// Manipulation de l'ActiveX media player
	var WDVideoMediaPlayerIE = (function ()
	{
		function __WDVideoMediaPlayerIE(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoMediaPlayer.prototype.constructor.apply(this, arguments);

				// Init specifique
			}
		}
		__WDVideoMediaPlayerIE.prototype = new WDVideoMediaPlayer();
		__WDVideoMediaPlayerIE.prototype.constructor = __WDVideoMediaPlayerIE;

		__WDVideoMediaPlayerIE.prototype._vsGetAttributsObject = function _vsGetAttributsObject()
		{
			return "CLASSID=\"CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6\" type=\"application/x-oleobject\" ";
		};
		__WDVideoMediaPlayerIE.prototype._vsGetParamsObject = function _vsGetParamsObject()
		{
			return	"<param name=\"url\" value=\"" + this._sGetFichier(0) + "\">" +
					"<param name=\"AutoStart\" value=\"false\">" +
					"<param name=\"uiMode\" value=\"" + this._sGetUiMode() + "\">" +
					(this.m_bBoucle ? "<param name=\"playCount\" value=\"1000\">" : "");
		};
		__WDVideoMediaPlayerIE.prototype._vsGetAttributsEmbed = function _vsGetAttributsEmbed()
		{
			return "type=\"application/x-mplayer2\" pluginspage=\"http://microsoft.com/windows/mediaplayer/en/download/\" ";
		};
		__WDVideoMediaPlayerIE.prototype._vsGetParamsEmbed = function _vsGetParamsEmbed()
		{
			return	"uiMode=\"" + this._sGetUiMode() + "\" src=\"" + this._sGetFichier(0) + "\" autostart=\"false\" " + (this.m_bBoucle ? "playCount=\"1000\" " : "");
		};

		return __WDVideoMediaPlayerIE;
	})();

	// Manipulation du plugin MediaPlayer sous WebKit
	var WDVideoMediaPlayerWK = (function ()
	{
		function __WDVideoMediaPlayerWK(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoMediaPlayerIE.prototype.constructor.apply(this, arguments);

				// Init specifique
			}
		}
		__WDVideoMediaPlayerWK.prototype = new WDVideoMediaPlayerIE();
		__WDVideoMediaPlayerWK.prototype.constructor = __WDVideoMediaPlayerWK;

		// GP 01/07/2013 : TB73177 : Il semble qu'il faille tapper dans le embed en fait...
//		// Construit le champ
//		__WDVideoMediaPlayerWK.prototype.vConstruitPlayer = function vConstruitPlayer(oConteneur/*, bAccepteObject*/)
//		{
//			// Appel le constructeur de la classe de base
//			// Et indique que l'on demande le object (et pas le embed)
//			WDVideoMediaPlayerIE.prototype.vConstruitPlayer.apply(this, [oConteneur, true]);
//		};

		// GP 31/03/2014 : TB76611 : Ce code est devenu inutile, on manipule toujours "settings" avec un "s" minuscule.
//		// Dans les player a base de webkit, les interfaces de l'objet son presentes avec la premiere lettre en minuscule....
//		__WDVideoMediaPlayerWK.prototype.vnGetVolume = function vnGetVolume() { return this.m_oObjet.settings.volume; };
//		__WDVideoMediaPlayerWK.prototype.vbSetVolume = function vbSetVolume(nVolume) { this.m_oObjet.settings.volume = nVolume; return true; };

		return __WDVideoMediaPlayerWK;
	})();

	// Manipulation du plugin MediaPlayer
	var WDVideoMediaPlayerFF = (function ()
	{
		function __WDVideoMediaPlayerFF(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoMediaPlayer.prototype.constructor.apply(this, arguments);

				// Init specifique
			}
		}
		__WDVideoMediaPlayerFF.prototype = new WDVideoMediaPlayer();
		__WDVideoMediaPlayerFF.prototype.constructor = __WDVideoMediaPlayerFF;

		// Construit le champ
		__WDVideoMediaPlayerFF.prototype.vConstruitPlayer = function vConstruitPlayer(oConteneur/*, bAccepteObject*/)
		{
			// Appel le constructeur de la classe de base
			return WDVideoMediaPlayer.prototype.vConstruitPlayer.apply(this, [oConteneur, true]);
		};

		// Construit le html du champ
		__WDVideoMediaPlayerFF.prototype._vsGetPlayerHTML = function _vsGetPlayerHTML(/*oConteneur*/)
		{
			return this.m_sHTMLDefaut;
		};

		return __WDVideoMediaPlayerFF;
	})();

//	// Manipulation de du player flash
//	var WDVideoFlash = (function ()
//	{
//		function __WDVideoFlash(oChampVideo/*, oParamVideo*/)
//		{
//			// Si on est pas dans l'init d'un protoype
//			if (oChampVideo)
//			{
//				// Appel le constructeur de la classe de base
//				WDVideoPlayerHTML.prototype.constructor.apply(this, arguments);
//
//				// Init specifique (valeur lue par le Flash)
//				this.m_sMsgErreur = STD_ERREUR_MESSAGE_VIDEO.replace(/\%1/g, this._sGetFichier(0));
//
//				// Pour le player flash qui va lire directement la variable
//				this.m_sFichier = this._sGetFichier(0);
//
//				this.m_sCheminSWF = clWDUtil.sCheminImageRes(undefined, "WDVideo.swf", true);
//			}
//		}
//		__WDVideoFlash.prototype = new WDVideoPlayerHTML();
//		__WDVideoFlash.prototype.constructor = __WDVideoFlash;
//
//		__WDVideoFlash.prototype.vbJoue = function vbJoue() { return this.m_oObjet.bJoue(); };
//		__WDVideoFlash.prototype.vbPause = function vbPause() { return this.m_oObjet.bPause(); };
//		__WDVideoFlash.prototype.vbArret = function vbArret() { return this.m_oObjet.bArret(); };
//		__WDVideoFlash.prototype.vnGetEtat = function vnGetEtat() { return this.m_oObjet.nGetEtat(); };
//		__WDVideoFlash.prototype.vnGetPosition = function vnGetPosition() { return this.m_oObjet.nGetPosition(); };
//		__WDVideoFlash.prototype.vbSetPosition = function vbSetPosition(nPosition) { return this.m_oObjet.bSetPosition(nPosition); };
//		__WDVideoFlash.prototype.vnGetDuree = function vnGetDuree() { return this.m_oObjet.nGetDuree(); };
//		__WDVideoFlash.prototype.vnGetHauteur = function vnGetHauteur() { return this.m_oObjet.nGetHauteur(); };
//		__WDVideoFlash.prototype.vnGetLargeur = function vnGetLargeur() { return this.m_oObjet.nGetLargeur(); };
//		__WDVideoFlash.prototype.vnGetVolume = function vnGetVolume() { return this.m_oObjet.nGetVolume(); };
//		__WDVideoFlash.prototype.vbSetVolume = function vbSetVolume(nVolume) { return this.m_oObjet.bSetVolume(nVolume); };
//
//		// GP 31/03/2014 : TB70303 : Uniquement embed dans le cas de Webkit et d�riv� (ou ancien d�riv�)
//		// Construit le html du champ
//		__WDVideoFlash.prototype._vsGetPlayerHTML = function _vsGetPlayerHTML(/*oConteneur*/)
//		{
//			if (bWK || bCrm)
//			{
//				return this._sGetEmbed();
//			}
//			else
//			{
//				return WDVideoPlayerHTML.prototype._vsGetPlayerHTML.apply(this, arguments);
//			}
//		};
//	
//		__WDVideoFlash.prototype._vsGetAttributsObject = function _vsGetAttributsObject()
//		{
//			return "classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" type=\"application/x-shockwave-flash\" ";
//		};
//		__WDVideoFlash.prototype._vsGetParamsObject = function _vsGetParamsObject()
//		{
//			return	"<param name=\"Movie\" value=\"" + this.m_sCheminSWF + "\">" +
//					"<param name=\"src\" value=\"" + this.m_sCheminSWF + "\">" +
//					"<param name=\"FlashVars\" VALUE=\"sAlias=" + this.m_oChampVideo.m_sAliasChamp + "\">" +
//					"<param name=\"WMode\" value=\"Window\">" +
//					"<param name=\"Play\" value=\"0\">" +
//					"<param name=\"Loop\" value=\"-1\">" +
//					"<param name=\"Quality\" value=\"high\">" +
//					"<param name=\"AllowScriptAccess\" value=\"sameDomain\">" +
//					"<param name=\"AllowFullScreen\" value=\"" + (this.m_bPleinEcran ? "true" : "false") + "\">";
//		};
//		__WDVideoFlash.prototype._vsGetAttributsEmbed = function _vsGetAttributsEmbed()
//		{
//			return "type=\"application/x-shockwave-flash\" pluginspage=\"http://www.adobe.com/go/getflashplayer\" ";
//		};
//		__WDVideoFlash.prototype._vsGetParamsEmbed = function _vsGetParamsEmbed()
//		{
//			return	"src=\"" + this.m_sCheminSWF + "\" " +
//					"flashVars=\"sAlias=" + this.m_oChampVideo.m_sAliasChamp + "\" " +
//					"play=\"true\" " +
//					"loop=\"false\" " +
//					"quality=\"high\" " +
//					"allowScriptAccess=\"sameDomain\" " +
//					"allowFullScreen=\"" + (this.m_bPleinEcran ? "true" : "false") + "\" ";
//		};
//
//		return __WDVideoFlash;
//	})();

	// Manipulation de quicktime
	var WDVideoQuickTime = (function ()
	{
		function __WDVideoQuickTime(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoPlayerHTML.prototype.constructor.apply(this, arguments);

				// Init specifique
				this.m_nEtat = ms_eEtatArret;
			}
		}
		__WDVideoQuickTime.prototype = new WDVideoPlayerHTML();
		__WDVideoQuickTime.prototype.constructor = __WDVideoQuickTime;

		__WDVideoQuickTime.prototype.vbJoue = function vbJoue() { this.m_oObjet.Play(); this.m_nEtat = ms_eEtatJoue; return true; };
		__WDVideoQuickTime.prototype.vbPause = function vbPause() { this.m_oObjet.Stop(); this.m_nEtat = ms_eEtatPause; return true; };
		__WDVideoQuickTime.prototype.vbArret = function vbArret() { this.m_oObjet.Stop(); this.m_oObjet.Rewind(); this.m_nEtat = ms_eEtatArret; return true; };
		// Les etats generaux (stop pause play correspondent au constantes WL)
		__WDVideoQuickTime.prototype.vnGetEtat = function vnGetEtat() { return this.m_nEtat; };
		__WDVideoQuickTime.prototype.vnGetPosition = function vnGetPosition() { return this.__nUnitToMs(this.m_oObjet.GetTime()); };
		__WDVideoQuickTime.prototype.vbSetPosition = function vbSetPosition(nPosition) { this.m_oObjet.SetTime(this.__nMsToUnit(nPosition)); return true; };
		__WDVideoQuickTime.prototype.vnGetDuree = function vnGetDuree() { return this.__nUnitToMs(this.m_oObjet.GetDuration()); };
		__WDVideoQuickTime.prototype.vnGetHauteur = function vnGetHauteur() { return this.__nGetDimension(true); };
		__WDVideoQuickTime.prototype.vnGetLargeur = function vnGetLargeur() { return this.__nGetDimension(false); };
		__WDVideoQuickTime.prototype.vnGetVolume = function vnGetVolume() { return parseInt(this.m_oObjet.GetVolume() * 100 / 255, 10); };
		__WDVideoQuickTime.prototype.vbSetVolume = function vbSetVolume(nVolume) { this.m_oObjet.SetVolume(nVolume * 255 / 100); return true; };

		// Conversions de ms en unite de la video (framerate)
		__WDVideoQuickTime.prototype.__nMsToUnit = function __nMsToUnit(nMs) { return nMs / 1000 * this.m_oObjet.GetTimeScale(); };
		__WDVideoQuickTime.prototype.__nUnitToMs = function __nUnitToMs(nUnit) { return nUnit * 1000 / this.m_oObjet.GetTimeScale(); };
		// Conversion des dimensions
		__WDVideoQuickTime.prototype.__nGetDimension = function __nGetDimension(bHauteur)
		{
			// sRectangle contient une chaine de la forme x1, y1, x2, y2
			// donc on calcule x2 - x1 et y2 - y1
			var sRectangle = this.m_oObjet.GetRectangle();
			var tabCoords = sRectangle.split(",");
			return parseInt(tabCoords[bHauteur ? 3 : 2], 10) - parseInt(tabCoords[bHauteur ? 1 : 0], 10);
		};

		// Construit le html du champ
		__WDVideoQuickTime.prototype._vsGetPlayerHTML = function _vsGetPlayerHTML(/*oConteneur*/)
		{
			return this.m_sHTMLDefaut;
		};

		return __WDVideoQuickTime;
	})();

	// Manipulation d'une balise video
	var WDVideoBaliseVideo = (function ()
	{
		function __WDVideoBaliseVideo(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoPlayerHTML.prototype.constructor.apply(this, arguments);

				// Init specifique
			}
		}
		__WDVideoBaliseVideo.prototype = new WDVideoPlayerHTML();
		__WDVideoBaliseVideo.prototype.constructor = __WDVideoBaliseVideo;

		__WDVideoBaliseVideo.prototype.vbJoue = function vbJoue() { this.m_oObjet.play(); return true; };
		__WDVideoBaliseVideo.prototype.vbPause = function vbPause() { this.m_oObjet.pause(); return true; };
		__WDVideoBaliseVideo.prototype.vbArret = function vbArret() { this.vbPause(); this.m_oObjet.currentTime = 0; this.vbPause(); return true; };
		// Les etats generaux (stop pause play correspondent au constantes WL)
		__WDVideoBaliseVideo.prototype.vnGetEtat = function vnGetEtat() { return this.m_oObjet.paused ? ms_eEtatPause : ms_eEtatJoue; };
		__WDVideoBaliseVideo.prototype.vnGetPosition = function vnGetPosition() { return Math.round(this.m_oObjet.currentTime * 1000); };
		__WDVideoBaliseVideo.prototype.vbSetPosition = function vbSetPosition(nPosition) { this.m_oObjet.currentTime = nPosition / 1000; return true; };
		__WDVideoBaliseVideo.prototype.vnGetDuree = function vnGetDuree()
		{
			var nDuree = this.m_oObjet.duration;
			if (isNaN(nDuree) || !isFinite(nDuree))
			{
				return 0;
			}
			return Math.round(nDuree * 1000);
		};
		__WDVideoBaliseVideo.prototype.vnGetHauteur = function vnGetHauteur() { return this.m_oObjet.videoHeight; };
		__WDVideoBaliseVideo.prototype.vnGetLargeur = function vnGetLargeur() { return this.m_oObjet.videoWidth; };
		__WDVideoBaliseVideo.prototype.vnGetVolume = function vnGetVolume() { return Math.round(this.m_oObjet.volume * 100); };
		// GP 24/11/2015 : TB93356 : Il ne faut pas arrondir la valeur en �criture (car sinon on 0 ou 1 au lieu d'une valeur entre 0 et 1)
		__WDVideoBaliseVideo.prototype.vbSetVolume = function vbSetVolume(nVolume) { this.m_oObjet.volume = nVolume / 100; };

		// La balise a utiliser
		__WDVideoBaliseVideo.prototype._vsGetBalise = function _vsGetBalise()
		{
			return "video";
		};

		// Construit le html du champ
		__WDVideoBaliseVideo.prototype._vsGetPlayerHTML = function _vsGetPlayerHTML(oConteneur)
		{
			var sBalise = this._vsGetBalise();

			var sHTML = "<" + sBalise + " preload=\"metadata\" ";
			// Balise video
			// GP 04/12/2015 : TB94181 : Astuce trouv�e sur le net pour avoir le player vid�o qui s'affiche correctement sans pourrir l'aspect de la vid�o
			// On fait 3 code selon les navigateurs
			if (bIEAvec11)
			{
				sHTML += "style=\"width:100%;";
			}
			else if (bWK)
			{
				sHTML += "style=\"width:100%;height:100%;top:50%;left:50%;transform:translate(-50%, -50%);position: absolute;";
				oConteneur.style.position = "relative";
			}
			else
			{
				sHTML += "width=\"100%\" height=\"100%";
			}
			sHTML += "\" id=\"" + this.m_oChampVideo.m_sAliasChamp;
			if (this.m_bDemarrageAuto)
			{
				sHTML += "\" autoplay=\"autoplay";
			}
			if (this.m_bBoucle)
			{
				sHTML += "\" loop=\"loop";
			}
			if (this.m_eControles !== ms_eControlesSans)
			{
				sHTML += "\" controls=\"controls";
			}
			// GP 08/01/2014 : Plus de src : utilise des balises source
//			sHTML += "\" src=\"";
//			sHTML += this._sGetFichier(0);
			sHTML += "\">";

			// Le contenu du champ
			clWDUtil.bForEach(this.m_tabFichiers, function (oFichier)
			{
				sHTML += "<source src=\"" + oFichier.m_sFichier + "\" type=\"" + oFichier.m_sTypeMIME + "\" />";
				return true;
			});

			// Les pistes de sous titres (apr�s le contenu selon la norme)
			// GP 30/01/2014 : Vu av QW242118 : Accepte le tableau absent c'est ce que fait PHP
			if (this.m_tabSousTitres)
			{
				clWDUtil.bForEach(this.m_tabSousTitres, function (oSousTitre)
				{
					sHTML += "<track kind=\"" + oSousTitre.m_sKind +
							"\" src=\"" + oSousTitre.m_sSrc +
							((undefined !== oSousTitre.m_sSrclang) ? ("\" srclang=\"" + oSousTitre.m_sSrclang) : "") +
							((undefined !== oSousTitre.m_sLabel) ? ("\" label=\"" + oSousTitre.m_sLabel) : "") +
							(oSousTitre.m_bDefaut ? "\" default=\"default" : "") +
							"\" />";
					return true;
				});
			}

			sHTML += "</" + sBalise + ">";

			return sHTML;
		};

		// Appel de play mais retourne la Promise.
		__WDVideoBaliseVideo.prototype.oJoue = function oJoue() { return this.m_oObjet.play(); };
		__WDVideoBaliseVideo.prototype.SetMuet = function SetMuet() { return this.m_oObjet.muted = true; };

		return __WDVideoBaliseVideo;
	})();

	// Manipulation d'une balise audio
	var WDVideoBaliseAudio = (function ()
	{
		function __WDVideoBaliseAudio(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoBaliseVideo.prototype.constructor.apply(this, arguments);

				// Init specifique
			}
		}
		__WDVideoBaliseAudio.prototype = new WDVideoBaliseVideo();
		__WDVideoBaliseAudio.prototype.constructor = __WDVideoBaliseAudio;

		// La balise a utiliser
		__WDVideoBaliseAudio.prototype._vsGetBalise = function _vsGetBalise()
		{
			return "audio";
		};

		return __WDVideoBaliseAudio;
	})();

	// Manipulation d'une vid�o YouTube
	var WDVideoYouTube = (function ()
	{
		// Les noms on �t� obtenu par une trace avec des vid�os qui ont ces modes.
		// Les dimensions ont �t� obtenus par https://support.google.com/youtube/answer/6375112
		// Sauf 144p et 4320p qui ne sont pas list�es.
		var ms_oDimensions = {
			"tiny": [256, 144],
			"small": [426, 240],
			"medium": [640, 360],
			"large": [854, 480],
			"hd720": [1280, 720],
			"hd1080": [1920, 1080],
			"hd1440": [2560, 1440],
			"hd2160": [3840, 2160],
			"highres": [7680, 4320]
		};
		function __s_oGetDimensionYouTube(oPlayer, bLargeur)
		{
			var tabDimension = ms_oDimensions[oPlayer.getPlaybackQuality()];
			if (tabDimension)
			{
				return tabDimension[bLargeur ? 0 : 1];
			}
			else
			{
				return 0;
			}
		}

		function __WDVideoYouTube(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoPlayer.prototype.constructor.apply(this, arguments);

				// Init specifique
				this.m_oPlayer = null;
			}
		}
		__WDVideoYouTube.prototype = new WDVideoPlayer();
		__WDVideoYouTube.prototype.constructor = __WDVideoYouTube;

		__WDVideoYouTube.prototype.vbJoue = function vbJoue() { this.m_oPlayer.playVideo(); return true; };
		__WDVideoYouTube.prototype.vbPause = function vbPause() { this.m_oPlayer.pauseVideo(); return true; };
		__WDVideoYouTube.prototype.vbArret = function vbArret() { this.m_oPlayer.stopVideo(); return true; };
		__WDVideoYouTube.prototype.vnGetEtat = function vnGetEtat()
		{
			switch (this.m_oPlayer.getPlayerState())
			{
			case -1:	// unstarted
			case YT.PlayerState.ENDED:
			case YT.PlayerState.CUED: 		// Consid�re que la vid�o est arr�t�e.
			default:
				return ms_eEtatArret;
			case YT.PlayerState.PLAYING:
			case YT.PlayerState.BUFFERING:	// Consid�re que la vid�o est en cours de lecture.
				return ms_eEtatJoue;
			case YT.PlayerState.PAUSED:
				return ms_eEtatPause;
			}
		};
		__WDVideoYouTube.prototype.vnGetPosition = function vnGetPosition() { return this.m_oPlayer.getCurrentTime() * 1000; };
		// allowSeekAhead : dans le doute utilise true. Car avec le syst�me, il n'y aura jamais d'appel avec true si l'appel ici est avec true.
		__WDVideoYouTube.prototype.vbSetPosition = function vbSetPosition(nPosition) { this.m_oPlayer.seekTo(nPosition / 1000, true); return true; };
		__WDVideoYouTube.prototype.vnGetDuree = function vnGetDuree() { return this.m_oPlayer.getDuration() * 1000; };
		// Taille non disponible : YouTube s�lectionne la taille comme il veux et ne donne que une indication.
		__WDVideoYouTube.prototype.vnGetHauteur = function vnGetHauteur() { return __s_oGetDimensionYouTube(this.m_oPlayer, false); };
		__WDVideoYouTube.prototype.vnGetLargeur = function vnGetLargeur() { return __s_oGetDimensionYouTube(this.m_oPlayer, true); };
		__WDVideoYouTube.prototype.vnGetVolume = function vnGetVolume() { return this.m_oPlayer.getVolume(); };
		__WDVideoYouTube.prototype.vbSetVolume = function vbSetVolume(nVolume) { this.m_oPlayer.setVolume(nVolume); return true; };

		__WDVideoYouTube.prototype.vConstruitPlayer = function vConstruitPlayer(oConteneur/*, bAccepteObject*/)
		{
			// DOC : https://developers.google.com/youtube/iframe_api_reference

			// D�clare la vid�o comme en attente de chargement.
			// Fait avant la tentative de chargement de YouTube. Ainsi si YouTube est d�j� disponible, c'est le chargement des vid�os en attente qui fait le travail.
			__s_ChargementVideoAsynchrone(this, oConteneur);

			// Charge le code de YouTube de mani�re asynchrone (fait uniquement sur le premier appel).
			__s_ChargementYouTubeAPI();
		};

		// Rappel pour le chargement de la vid�o quand l'API YouTube est disponible.
		__WDVideoYouTube.prototype.ChargementVideo = function ChargementVideo(/*oConteneur*/)
		{
			// Ignore le conteneur : le serveur a normalement g�n�r� une balise IFrame. Et cette IFrame a transmis les options au player.
			this.m_oPlayer = new YT.Player(this.m_oChampVideo.m_sAliasChamp + "_YT", {
//				height: "390",
//				width: "640",
//				videoId: 'M7lc1UVf-VE',
//				playerVars: {
//				},
//				events: {
//					'onReady': onPlayerReady,
//					'onStateChange': onPlayerStateChange
//				}
			});
		};

		// Chargement du code de YouTube de mani�re asynchrone.
		var ms_bOnYouTubeIframeAPIReady = false;
		var __s_ChargementYouTubeAPI = function ()
		{
			// Prepare la callback d'initialisation. On m�morise la pr�c�dente callback au cas ou un autre script la d�clare
			var pfAncienOnYouTubeIframeAPIReady = null;
			function __s_OnYouTubeIframeAPIReady()
			{
				// Normalement un seul appel
				clWDUtil.WDDebug.assert(false === ms_bOnYouTubeIframeAPIReady, "Normalement un seul appel de __s_OnYouTubeIframeAPIReady");
				ms_bOnYouTubeIframeAPIReady = true;

				// Charge les vid�os en attente
				clWDUtil.bForEach(ms_tabVideoEnAttente, function (oVideoEnAttente)
				{
					__s_ChargementVideo(oVideoEnAttente.m_oVideoYouTube, oVideoEnAttente.m_oConteneur);
					return true;
				});
				ms_tabVideoEnAttente = [];

				// Execute la pr�c�dente callback si elle existe. On l'ex�cute apr�s notre code : si elle plante, cela ne bloque pas l'affichage du champ.
				if (pfAncienOnYouTubeIframeAPIReady)
				{
					pfAncienOnYouTubeIframeAPIReady();
				}
			}

			// Pas de second chargement
			__s_ChargementYouTubeAPI = clWDUtil.m_pfVide;

			// V�rifie si YouTube n'est pas d�j� disponible
			if (window.YT && window.YT.Player)
			{
				// D�j� disponible (charg� par un script tier). Notifie imm�diatement le chargement.
				__s_OnYouTubeIframeAPIReady();
			}
			else
			{
				// Non disponible

				// Prepare la callback d'initialisation. On m�morise la pr�c�dente callback au cas ou un autre script la d�clare
				pfAncienOnYouTubeIframeAPIReady = window.onYouTubeIframeAPIReady;
				window.onYouTubeIframeAPIReady = __s_OnYouTubeIframeAPIReady;

				// Charge le code de YouTube de mani�re asynchrone.
				var oScript = document.createElement("script");
				oScript.src = "https://www.youtube.com/iframe_api";
				var oPremierScriptPage = document.getElementsByTagName("script")[0];
				oPremierScriptPage.parentNode.insertBefore(oScript, oPremierScriptPage);
			}
		};

		// Charge une vid�o (si YouTube est d�j� disponible), sinon ajoute une vid�o dans la liste des vid�o en attente.
		var ms_tabVideoEnAttente = [];
		function __s_ChargementVideoAsynchrone(oVideoYouTube, oConteneur)
		{
			if (ms_bOnYouTubeIframeAPIReady)
			{
				__s_ChargementVideo(oVideoYouTube, oConteneur);
			}
			else
			{
				ms_tabVideoEnAttente.push({
					m_oVideoYouTube: oVideoYouTube,
					m_oConteneur: oConteneur
				});
			}
		}
		function __s_ChargementVideo (oVideoYouTube, oConteneur)
		{
			oVideoYouTube.ChargementVideo(oConteneur);
		}

		return __WDVideoYouTube;
	})();

	// Manipulation d'une balise object
	var WDVideoBaliseObject = (function ()
	{
		function __WDVideoBaliseObject(oChampVideo/*, oParamVideo*/)
		{
			// Si on est pas dans l'init d'un protoype
			if (oChampVideo)
			{
				// Appel le constructeur de la classe de base
				WDVideoPlayerHTML.prototype.constructor.apply(this, arguments);

				// Init specifique
			}
		}
		__WDVideoBaliseObject.prototype = new WDVideoPlayerHTML();
		__WDVideoBaliseObject.prototype.constructor = __WDVideoBaliseObject;

		// Construit le champ
//		__WDVideoBaliseObject.prototype.vConstruitPlayer = function vConstruitPlayer(oConteneur, bAccepteObject)
//		{
//			// Garde le player par defaut
//			WDVideoPlayerHTML.prototype.vConstruitPlayer.apply(this, arguments);
//		};

		// Construit le html du champ
		__WDVideoBaliseObject.prototype._vsGetPlayerHTML = function _vsGetPlayerHTML(/*oConteneur*/)
		{
			return this.m_sHTMLDefaut;
		};

		return __WDVideoBaliseObject;
	})();

	function __WDVideo(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
	{
		// Si on est pas dans l'init d'un protoype
		if (arguments.length)
		{
			// Appel le constructeur de la classe de base
			WDChamp.prototype.constructor.apply(this, arguments);

			// Format de tabParametresSupplementaires : [ oParamVideoInitial ]
			var oParamVideoInitial = tabParametresSupplementaires[0];

			this.m_oParamVideoInitial = oParamVideoInitial;

			// On a toujours un objet player valide
			this.m_oPlayer = new WDVideoPlayerHTML(this);
		}
	}

	// Declare l'heritage
	__WDVideo.prototype = new WDChamp();
	// Surcharge le constructeur qui a ete efface
	__WDVideo.prototype.constructor = __WDVideo;

	// Initialisation
	__WDVideo.prototype.Init = function Init()
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype.Init.apply(this, arguments);

		// Trouve le conteneur HTML
		this.m_oConteneur = document.getElementById("tz" + this.m_sAliasChamp);

		// Analyse les parametres (sParamVideo est objet JS en JSON)
		this.__InitPlayer(this.m_oParamVideoInitial);
	};

	// GP 01/07/2013 : Ce code ne marche pas bien en g�n�ral, le champ est r�affich� apr�s la fin du PCode (donc apr�s l'envoi des commandes)
	// => Il n'est peut-�tre requis que dans le cas du player flash
	// GP 01/07/2013 : En l'absence de bugs prouv�s, on n'active pas le code
//	// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
//	__WDVideo.prototype.OnDisplay = function OnDisplay(oElementRacine, bAffiche)
//	{
//		// Appel de la methode de la classe de base
//		WDChamp.prototype.OnDisplay.apply(this, arguments);
//
//		// Uniquement sur le champ flash.
//		if (bAffiche && this.m_oConteneur && clWDUtil.bEstFils(this.m_oConteneur, oElementRacine))
//		{
//			// Reinit les membres du flash (requis dans le cas d'un pageaffiche dialogue)
//			this.__InitPlayerInterne();
//		}
//	};

	__WDVideo.prototype.sGetVariable = function sGetVariable(sVariable)
	{
		return this.m_oPlayer[sVariable];
	};
	__WDVideo.prototype.bGetVariable = function bGetVariable(sVariable)
	{
		return this.m_oPlayer[sVariable];
	};
	__WDVideo.prototype.nGetVariable = function nGetVariable(sVariable)
	{
		return this.m_oPlayer[sVariable];
	};

	// Fonctions pour les fonctions MultimediaXxx du WL

	// Lance la lecture
	__WDVideo.prototype.bJoue = function bJoue()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vbJoue(arguments);
		}
		catch (e)
		{
			return false;
		}
	};

	// Mise en pause
	__WDVideo.prototype.bPause = function bPause()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vbPause();
		}
		catch (e)
		{
			return false;
		}
	};

	// Arret (= pause generalement)
	__WDVideo.prototype.bArret = function bArret()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vbArret();
		}
		catch (e)
		{
			return false;
		}
	};

	// Etat
	__WDVideo.prototype.nGetEtat = function nGetEtat()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vnGetEtat();
		}
		catch (e)
		{
			return ms_eEtatArret;
		}
	};

	// Va au debut de la video
	__WDVideo.prototype.bDebut = function bDebut()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vbVaDebut();
		}
		catch (e)
		{
			return false;
		}
	};

	// Va a la fin de la video
	__WDVideo.prototype.bFin = function bFin()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vbVaFin();
		}
		catch (e)
		{
			return false;
		}
	};

	// Lecture de la position (en ms)
	__WDVideo.prototype.nGetPosition = function nGetPosition()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vnGetPosition();
		}
		catch (e)
		{
			return 0;
		}
	};

	// Fixe la position (en ms)
	__WDVideo.prototype.bSetPosition = function bSetPosition(nPosition)
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vbSetPosition(nPosition);
		}
		catch (e)
		{
			return false;
		}
	};

	// Recupere la duree totale (en ms)
	__WDVideo.prototype.nGetDuree = function nGetDuree()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vnGetDuree();
		}
		catch (e)
		{
			return 0;
		}
	};

	// Hauteur
	__WDVideo.prototype.nGetHauteur = function nGetHauteur()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vnGetHauteur();
		}
		catch (e)
		{
			return 0;
		}
	};

	// Largeur
	__WDVideo.prototype.nGetLargeur = function nGetLargeur()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vnGetLargeur();
		}
		catch (e)
		{
			return 0;
		}
	};

	// Lecture du volume (entre 0 et 100)
	__WDVideo.prototype.nGetVolume = function nGetVolume()
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vnGetVolume();
		}
		catch (e)
		{
			return 100;
		}
	};

	// Fixe du volume (entre 0 et 100)
	__WDVideo.prototype.bSetVolume = function bSetVolume(nVolume)
	{
		// Rebond sur la classe de manipulation du player
		try
		{
			return this.m_oPlayer.vbSetVolume(nVolume);
		}
		catch (e)
		{
			return false;
		}
	};

	// Creation du player (sParamVideo est objet JS en JSON)
	__WDVideo.prototype._vDeduitParam = function _vDeduitParam(oParametres)
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype._vDeduitParam.apply(this, arguments);

		// Ici il n'y a pas quelque chose a faire dans le cas YouTube ?
//		@@@;

		// Initialise la classe de manipulation du player
		this.__InitPlayer(oParametres);
	};

	// Initialise la classe de manipulation du player
	__WDVideo.prototype.__InitPlayer = function __InitPlayer(oParamVideo)
	{
		// Initialise le bon player en fonction des parametres et du type de la video
		var ePlayer = __s_eGetPlayer(oParamVideo);
		// GP 06/01/2016 : Corrige le player pour le cas du player audio
		if ((ms_ePlayerHTML5Video === ePlayer) && (ms_ePlayerHTML5Audio === oParamVideo.ePlayerDefaut))
		{
			ePlayer = ms_ePlayerHTML5Audio;
		}
		this.m_oPlayer = __s_oGetPlayer(this, ePlayer, oParamVideo);

		// Toujours car sinon on ne peut pas jouer
		// Si le champ n'est pas visible (display:none), certains navigateurs n'affichent pas le champ
		// Ce n'est pas grave de ne pas faire l'init car en cas d'affichage, on recoit un OnDisplay
		if (this.m_oConteneur && clWDUtil.bEstDisplay(this.m_oConteneur, document, false))
		{
			this.__InitPlayerInterne();
		}
	};

	// Initialise le HTML du player : version commune avec OnDisplay
	__WDVideo.prototype.__InitPlayerInterne = function __InitPlayerInterne()
	{
		// Construit le champ
		// GP 03/12/2015 : TB90136 : Remplacement de bIE par bIEAvec11
		this.m_oPlayer.vConstruitPlayer(this.m_oConteneur, bIEAvec11);

		// Si il y a un lancement automatique, lance la video
		if (this.m_oPlayer.m_bDemarrageAuto)
		{
			// Mais pas immediatement (attend le chargement du player)
			this.nSetTimeoutUnique("__JoueDemarrageAuto", 500);
		}
	};
	// Lancement du player en cas d'autoplay
	__WDVideo.prototype.__JoueDemarrageAuto = function __JoueDemarrageAuto()
	{
		try
		{
			var oPlayer = this.m_oPlayer;

			// GP 19/12/2019 : TB110751/QW321544 : Les navigateurs interdisent la lecture sans interactions des vid�os HTML5. En cas d'�chec, tente un second lancement en mode silencieux.
			if (oPlayer instanceof WDVideoBaliseVideo)
			{
				var oPromise = oPlayer.oJoue();
				// Les anciens navigateurs ne retournent rien.
				if (oPromise instanceof Promise)
				{
					oPromise.catch(function ()
					{
						// Tente de mettre en muted
						oPlayer.SetMuet();
						oPlayer.oJoue();
					});
				}
			}
			else
			{
				// Lecture simple
				oPlayer.vbJoue();
			}
		}
		catch (e)
		{
		}
	};

	// Trouve le bon player en fonction du type de la video
	function __s_eGetPlayer(oParamVideo)
	{
		// Exception : le player youtube ne se m�langue pas avec les autres vid�os.
		if (ms_ePlayerYouTube === oParamVideo.ePlayerDefaut)
		{
			return ms_ePlayerYouTube;
		}

		// Si on a plusieurs fichiers : player HTML5
		if ((undefined !== oParamVideo.m_tabVideos) || ((undefined !== oParamVideo.m_tabSousTitres) && (0 < oParamVideo.m_tabSousTitres.length)))
		{
			return ms_ePlayerHTML5Video;
		}
		switch (oParamVideo.eType)
		{
		case ms_eVideoMPG:
			// Les sons/vid�os mp4/mpg sont g�r�es correctements par Chrome/Firefox dans les versions r�centes
			// GP 13/01/2014 : Et tous les navigateurs HTML5
			if (__s_bHTML5Video_MPG_MP4(oParamVideo))
			{
				return ms_ePlayerHTML5Video;
			}
			// Pas de break;
		case ms_eVideoWindowsMedia:
			if (__s_bWindowsMedia())
			{
				// Si le plugin WindowsMedia est installe
				return ms_ePlayerWindowsMedia;
			}
			else
			{
				oParamVideo.ePlayerDefaut;
			}
			break;
//		case ms_eVideoFlash:
//			// Si Flash est installe
//			var ePlayer = __s_eGetFlash();
//			return (ePlayer !== ms_ePlayerDefaut) ? ePlayer : oParamVideo.ePlayerDefaut;
		case ms_eVideoMP4:
//			// GP 03/12/2015 : Si on est dans IE en mode quirks : on affiche les vid�o MP4 avec le player flash
//			if (bIEQuirks && (__s_eGetFlash() === ms_ePlayerFlashRecent))
//			{
//				return ms_ePlayerFlashRecent;
//			}
			// Si on demande la balise video HTML5 ou si player sait gerer la video
			if (__s_bHTML5Video_MPG_MP4(oParamVideo))
			{
				return ms_ePlayerHTML5Video;
			}
			// Pas de break;
		case ms_eVideoQuickTime:
			// Si Flash ou QuickTime est installe
			if (__s_bQuickTime())
			{
				return ms_ePlayerQuickTime;
			}
			return oParamVideo.ePlayerDefaut;
		case ms_eVideoOGG:
			// Si on demande la balise video HTML5 ou si player sait gerer la video
			return __s_bHTML5Video_OGG(oParamVideo) ? ms_ePlayerHTML5Video : oParamVideo.ePlayerDefaut;
		case ms_eVideoMKV:
		case ms_eVideoAutres:
		case ms_eVideoAucune:
		default:
			// Retourne le player trouve par le calcul serveur
			return oParamVideo.ePlayerDefaut;
		case ms_eVideoWEBM:
			return ms_ePlayerHTML5Video;
		case ms_eVideoYouTube:
			return ms_ePlayerYouTube;
		}
	}

	// Recupere l'objet player
	function __s_oGetPlayer(oChampVideo, ePlayer, oParamVideo)
	{
		switch (ePlayer)
		{
		case ms_ePlayerWindowsMedia:
			// Sous IE
			// GP 03/12/2015 : TB90132 : Remplacement de bIE par bIEAvec11
			if (bIEAvec11)
			{
				return new WDVideoMediaPlayerIE(oChampVideo, oParamVideo);
			}
			else if (bWK)
			{
				return new WDVideoMediaPlayerWK(oChampVideo, oParamVideo);
			}
			else
			{
				return new WDVideoMediaPlayerFF(oChampVideo, oParamVideo);
			}
//		case ms_ePlayerFlashRecent:
//		case ms_ePlayerFlashAncien:
//			return new WDVideoFlash(oChampVideo, oParamVideo);
		case ms_ePlayerQuickTime:
			return new WDVideoQuickTime(oChampVideo, oParamVideo);
		case ms_ePlayerHTML5Video:
			return new WDVideoBaliseVideo(oChampVideo, oParamVideo);
		default:
		case ms_ePlayerDefaut:
		case ms_ePlayerObjectSimple:
			return new WDVideoBaliseObject(oChampVideo, oParamVideo);
		case ms_ePlayerHTML5Audio:
			return new WDVideoBaliseAudio(oChampVideo, oParamVideo);
		case ms_ePlayerYouTube:
			return new WDVideoYouTube(oChampVideo, oParamVideo);
		}
	}

	// Indique si un plugin avec le nom demande existe
	function __s_bAvecPlugins (sNom)
	{
		// Parcours les plugins
		// Si la recherche va � la fin (= �chec) on recoit true, donc on inverse le r�sultat de la recherche
		return !clWDUtil.bForEach(navigator.plugins || [], function (oPlugin)
		{
			if (0 <= oPlugin.name.indexOf(sNom))
			{
				// Trouv� : fin de la recherche
				return false;
			}
			return true;
		});
	}

	// Si on est sous IE, utilise Windows Media
	// Si on est sous firefox, regarde si le plugin est installe
	function __s_bWindowsMedia()
	{
		// Si on est sous IE, utilise Windows Media
		// Si on est sous firefox, regarde si le plugin est installe
		// GP 03/12/2015 : TB90132 : Remplacement de bIE par bIEAvec11
		return bIEAvec11 || __s_bAvecPlugins("Windows Media");
	}

//	// Version de flash ?
//	function __s_eGetFlash()
//	{
//		// Test via plugins (firefox etc...)
//		var eVersionFlash = __s_eGetFlashPlugins();
//		if (eVersionFlash !== ms_ePlayerDefaut)
//		{
//			return eVersionFlash;
//		}
//		// Test via un ActiveX (IE)
//		eVersionFlash = __s_eGetFlashActiveX();
//		if (eVersionFlash !== ms_ePlayerDefaut)
//		{
//			return eVersionFlash;
//		}
//		return ms_ePlayerDefaut;
//	}
//
//	// Version de flash ? Test via plugins (firefox etc...)
//	function __s_eGetFlashPlugins()
//	{
//		if (navigator.plugins)
//		{
//			// Parcours les plugins
//			var i;
//			var nLimiteI = navigator.plugins.length;
//			for (i = 0; i < nLimiteI; i++)
//			{
//				var sDescription = navigator.plugins[i].description;
//				if (sDescription)
//				{
//					var tabDescription = sDescription.split(" ");
//					if ((tabDescription.length >= 3) && (tabDescription[0].toLowerCase() === "shockwave") && (tabDescription[1].toLowerCase() === "flash"))
//					{
//						var nVersion = parseInt(tabDescription[2], 10);
//						if (nVersion > 9)
//						{
//							return ms_ePlayerFlashRecent;
//						}
//						else if (nVersion === 8)
//						{
//							return ms_ePlayerFlashAncien;
//						}
//					}
//				}
//			}
//		}
//		return ms_ePlayerDefaut;
//	}
//
//	// Version de flash ? Test via un ActiveX (IE)
//	function __s_eGetFlashActiveX()
//	{
//		var oTest;
//		try
//		{
//			// Version 9 et +
//			oTest = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.9");
//			if (oTest)
//			{
//				return ms_ePlayerFlashRecent;
//			}
//			// Normalement on ne passe pas ici...
//		}
//		catch (e)
//		{
//		}
//		try
//		{
//			// Version 8
//			oTest = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.8");
//			if (oTest)
//			{
//				return ms_ePlayerFlashAncien;
//			}
//			// Normalement on ne passe pas ici...
//		}
//		catch (e)
//		{
//		}
//		return ms_ePlayerDefaut;
//	}

	// QuickTime installe
	function __s_bQuickTime()
	{
		// Test via plugins (firefox etc...) ou un ActiveX (IE)
		return __s_bAvecPlugins("QuickTime") || __s_bQuickTimeActiveX();
	};
	function __s_bQuickTimeActiveX()
	{
		try
		{
			var oTest = new ActiveXObject("QuickTimeCheckObject.QuickTimeCheck.1");
			if (oTest && oTest.IsQuickTimeAvailable(0))
			{
				return true;
			}
			// Normalement on ne passe pas ici...
		}
		catch (e)
		{
		}
		return false;
	}

	// Si on demande la balise video HTML5 ou si player sait gerer la video
	function __s_bHTML5Video_MPG_MP4(oParamVideo)
	{
		// GP 09/01/2014 : Autorise maintenant toujours dans tous les navigateurs sauf IE9- et IE quirks
		return (oParamVideo.ePlayerDefaut === ms_ePlayerHTML5Video) || !bIE || ((10 <= nIE) && !bIEQuirks);
	}

	// Si on demande la balise video HTML5 ou si player sait gerer la video
	function __s_bHTML5Video_OGG(oParamVideo)
	{
		// GP 09/01/2014 : Autorise maintenant toujours dans tous les navigateurs sauf IE- et IE quirks
		return (oParamVideo.ePlayerDefaut === ms_ePlayerHTML5Video) || !bIE;
	}

	return __WDVideo;
})();