// WDXML.js
/*! 26.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */
// Attention a ne pas mettre d'accent dans le code, chaines incluses
///#DEBUG=clWDUtil.WDDebug
///#GLOBALS XPathResult
var TEXT_NODE = 3;
var CDATA_NODE = 4;
var PROCESSING_INSTRUCTION_NODE = 7;
var COMMENT_NODE = 8;
var XMLErreur = -1;
var xHTML = 1;
var XMLBalise = 1;
var XMLAttribut = 2;
var XMLElement = XMLBalise + XMLAttribut;
var XMLValeur = 4;
var XMLSousElement = 16;
var XMLNiveauCourant = 32;
var XMLContinue = 64;
var XMLExact = 1;
var XMLCommencePar = 2;
var XMLContient = 4;
var XMLIgnoreLaCasse = 16;
var XMLAvecNamespace = 32;
var XMLEncodageAucun = 1;
var XMLEncodageUTF8 = 2;
var XMLEncodageUTF16 = 3;
var XMLEncodageIso8859_1 = 6;
var XMLEncodageIso8859_2 = 7;
var XMLEncodageIso8859_3 = 8;
var XMLEncodageIso8859_4 = 9;
var XMLEncodageIso8859_5 = 10;
var XMLEncodageIso8859_6 = 11;
var XMLEncodageIso8859_7 = 12;
var XMLEncodageIso8859_8 = 13;
var XMLEncodageIso8859_9 = 14;
var XMLDocumentDefaut = 0;
var XMLPositionCourante = 1;
var XMLSansEntete = 2;
var XMLDebutNS = "xmlns";
var XMLDebutComment = "#";
var gTabDocXML = new Array();
var gTabConvTexteXML = new Array();
gTabConvTexteXML[gTabConvTexteXML.length] = new XMLConversionTexteXML("&", "amp");
gTabConvTexteXML[gTabConvTexteXML.length] = new XMLConversionTexteXML("'", "apos");
gTabConvTexteXML[gTabConvTexteXML.length] = new XMLConversionTexteXML(">", "gt");
gTabConvTexteXML[gTabConvTexteXML.length] = new XMLConversionTexteXML("<", "lt");
gTabConvTexteXML[gTabConvTexteXML.length] = new XMLConversionTexteXML("\"", "quot");
// constantes pour les fonctions XMLInsèrexxx
var snXMLAvant = 0x00000001; // insertion avant le noeud courant
var snXMLApres = 0x00000002; // insertion après le noeud courant
var snXMLSousElement = 0x00000010; // ajout un fils au noeud courant
function XMLConversionTexteXML(t, x) {
    this.t = t;
    this.x = x;
}
function XMLInitRechDoc(pDoc) {
    pDoc.Rech = false;
    pDoc.DebRech = null;
    pDoc.AttRech = XMLErreur;
    pDoc.ValRech = null;
    pDoc.OptRechNiv = XMLElement + XMLSousElement + XMLNiveauCourant;
    pDoc.OptRech = XMLExact;
    pDoc.Dehors = false;
    // pour les recheches avec XPath
    pDoc.XPathRes = null; // le XPathResult en cours
    pDoc.nIndiceSnapshot = 0; // indice du snapshot en cours pour le parcours
    pDoc.XPathValeur = null; // valeur
}
function XMLInitDoc(pDoc, Nom, Doc, Vide) {
    pDoc.Nom = Nom; // nom du document
    pDoc.Doc = Doc; // XML DOM
    pDoc.Pos = Vide ? null : Doc.documentElement; // noeud en cours (Init sur la racine)
    pDoc.Att = XMLErreur;
    pDoc.Ent = null; // entête du XML
    pDoc.TabPosition = {}; // tableau des positions pour les XMLSauvePosition/XMLRetourPosition
    pDoc.nIndicePosition = 0; // indice de la dernière position créée
    XMLInitRechDoc(pDoc);
}
function clDocumentXML(Nom, Doc, Vide) {
    XMLInitDoc(this, Nom, Doc, Vide);
}
function pclDocXML(Nom, Doc, Vide) {
    var bVide = true;
    if (typeof Vide === "boolean") {
        bVide = Vide;
    }
    for (var i = 0; i < gTabDocXML.length; i++) {
        if (gTabDocXML[i].Nom == Nom) {
            if (!Doc) {
                return gTabDocXML[i];
            }
            if ((gTabDocXML[i].Doc != null) && ((bVide) || (gTabDocXML[i].Pos != null))) {
                return gTabDocXML[i];
            }
            return null;
        }
    }
    return null;
}
function XMLAjoutDoc(Nom, Doc, Vide) {
    var p = pclDocXML(Nom);
    if (p != null) {
        XMLInitDoc(p, Nom, Doc, Vide);
    }
    else {
        gTabDocXML[gTabDocXML.length] = new clDocumentXML(Nom, Doc, Vide);
    }
}
function bXMLChaineVide(s) {
    return (s == null) || (s == "");
}
function XMLDocument(Nom, Code, Option, Elem) {
    var d = null;
    var c = !bXMLChaineVide(Code);
    if (c && window.DOMParser) {
        var p = new DOMParser();
        if (p == null) {
            return false;
        }
        d = p.parseFromString(Code, "text/" + ((Option == xHTML) ? "html" : "xml"));
    }
    else if ((!c) && (document != null) && (document.implementation != null) && (document.implementation.createDocument != null)) {
        d = document.implementation.createDocument(null, (Elem != null) ? Elem : null, null);
    }
    else if (window.ActiveXObject != null) {
        d = new ActiveXObject("Microsoft.XMLDOM");
        if (d == null) {
            return false;
        }
        if (c) {
            d.loadXML(Code);
            if ((d.parseError != null) && (d.parseError.errorCode != 0)) {
                return false;
            }
        }
    }
    if (d == null) {
        return false;
    }
    XMLAjoutDoc(Nom, d, !c);
    if (c) {
        var e = Code.indexOf("<?");
        if (e == XMLErreur) {
            return true;
        }
        var s = "?>";
        var f = Code.indexOf(s, e);
        if (f == XMLErreur) {
            return true;
        }
        var pDoc = pclDocXML(Nom);
        if (pDoc == null) {
            return false;
        }
        pDoc.Ent = Code.substring(e, f + s.length);
    }
    return true;
}
function sTexteXMLRemplace(s, c, r) {
    var i = 0;
    while ((i < s.length) && ((i = s.indexOf(c, i)) != XMLErreur)) {
        s = ((i > 0) ? s.substring(0, i) : "") + r + (((i + c.length) < s.length) ? s.substring(i + c.length, s.length) : "");
        i += r.length;
    }
    return s;
}
function sXMLEntite(s) {
    return "&" + s + ";";
}
function TexteVersXML(s) {
    for (var i = 0; i < gTabConvTexteXML.length; i++) {
        s = sTexteXMLRemplace(s, gTabConvTexteXML[i].t, sXMLEntite(gTabConvTexteXML[i].x));
    }
    return s;
}
function XMLVersTexte(s) {
    for (var i = 0; i < gTabConvTexteXML.length; i++) {
        s = sTexteXMLRemplace(s, sXMLEntite(gTabConvTexteXML[i].x), gTabConvTexteXML[i].t);
    }
    return s;
}
function bXMLChaineCompare(sChaine1, sChaine2, nOption) {
    if (!sChaine2) {
        return true;
    }
    if (nOption & XMLIgnoreLaCasse) {
        sChaine1 = sChaine1.toUpperCase();
        sChaine2 = sChaine2.toUpperCase();
    }
    if (nOption & XMLCommencePar) {
        sChaine1 = sChaine1.substring(0, sChaine2.length);
    }
    return (nOption & XMLContient) ? (sChaine1.indexOf(sChaine2) != XMLErreur) : (sChaine1 == sChaine2);
}
function bXMLAttributNS(a) {
    return bXMLChaineCompare(a.name, XMLDebutNS, XMLIgnoreLaCasse + XMLCommencePar);
}
function nXMLAttribut(p, r, m) {
    for (var i = 0; i < p.attributes.length; i++) {
        if ((!bXMLAttributNS(p.attributes[i])) && bXMLChaineCompare(p.attributes[i].name, r, m)) {
            return i;
        }
    }
    return XMLErreur;
}
function XMLAjouteAttribut(Nom, Att, Val, Pos) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    p.Pos.setAttribute(Att, TexteVersXML(Val));
    if (Pos) {
        var i = nXMLAttribut(p.Pos, Att);
        if (i != XMLErreur) {
            p.Att = i;
        }
    }
    return true;
}
function XMLAjouteFils(Nom, Elem, Val, Pos) {
    var p = pclDocXML(Nom, true, true);
    if (p == null) {
        return false;
    }
    var e = p.Doc.createElement(Elem);
    if (e == null) {
        return false;
    }
    var t = null;
    if ((!bXMLChaineVide(Val)) && (((t = p.Doc.createTextNode(TexteVersXML(XMLVersTexte(Val)))) == null) || (e.appendChild(t) == null))) {
        return false;
    }
    if (p.Pos == null) {
        if (p.Doc.documentElement == null) {
            if (p.Doc.appendChild(e) == null) {
                return false;
            }
        }
        else {
            if (!XMLDocument(Nom, null, null, Elem)) {
                return false;
            }
            if ((t != null) && ((e = p.Doc.documentElement).appendChild(t) == null)) {
                return false;
            }
        }
    }
    else if (p.Pos.appendChild(e) == null) {
        return false;
    }
    if (Pos || (p.Pos == null)) {
        p.Pos = e;
        p.Att = XMLErreur;
    }
    return true;
}
function XMLAnnuleRecherche(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return;
    }
    XMLInitRechDoc(p);
}
//Indique si un noeud est de type texte
//Entrée :	oNoeud	Noeud dont on veut savoir si c'est un noeud texte
//Sortie :	true si le noeud est de type texte, false sinon
function bNoeudTexte(oNoeud) {
    //Indique si le noeud est de type texte
    return (oNoeud != null) ? (oNoeud.nodeType == TEXT_NODE) : false;
}
function sXMLElemVersTxt(e, n) {
    if (bNoeudTexte(e)) {
        return e.nodeValue;
    }
    if (e.nodeType == CDATA_NODE) {
        return e.xml;
    }
    var p = "";
    if (n > 0) {
        //		p += "\n";
        //		for (var i = 0; i < n; i++) p += "\t";
    }
    var s = p + "<" + e.nodeName;
    var i = 0;
    for (i = 0; i < e.attributes.length; i++) {
        s += " " + e.attributes[i].nodeName + "=\"" + e.attributes[i].nodeValue + "\"";
    }
    var b = e.childNodes.length > 0;
    if (!b) {
        s += "/";
    }
    s += ">";
    if (b) {
        var f = false;
        for (i = 0; i < e.childNodes.length; i++) {
            s += sXMLElemVersTxt(e.childNodes[i], n + 1);
            f = f || (!bNoeudTexte(e.childNodes[i]));
        }
        //		if (f) s += (p == "") ? "\n" : p;
        s += "</" + e.nodeName + ">";
    }
    return s;
}
function XMLConstruitChaine(Nom, Option /*,Encod*/) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return "";
    }
    return ((Option & XMLSansEntete) ? "" : (((p.Ent != null) ? p.Ent : "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>") + "\n")) + sXMLElemVersTxt((Option & XMLPositionCourante) ? p.Pos : p.Doc.documentElement, 0) + "\n";
}
function nXMLDernier(t) {
    return ((t != null) ? t.length : 0) - 1;
}
function pXMLDernier(t) {
    return ((t != null) && (t.length > 0)) ? t[nXMLDernier(t)] : null;
}
function XMLPositionneElement(p, e) {
    p.Pos = e;
    p.Att = XMLErreur;
}
function pXMLParent(p) {
    return (p.Att == XMLErreur) ? (((p.Pos.parentNode != null) && (p.Pos.parentNode.nodeType == XMLBalise)) ? p.Pos.parentNode : null) : p.Pos;
}
function nXMLIndiceAttribut(e, d, s) {
    if (e.attributes == null) {
        return XMLErreur;
    }
    for (var i = d; s ? (i < e.attributes.length) : (i >= 0); s ? i++ : i--) {
        if (!bXMLAttributNS(e.attributes[i])) {
            return i;
        }
    }
    return XMLErreur;
}
function nXMLDernierAttribut(e) {
    return (e != null) ? nXMLIndiceAttribut(e, nXMLDernier(e.attributes), false) : XMLErreur;
}
function bXMLDernierFils(p, e) {
    var f = (e != null) ? pXMLDernier(e.childNodes) : null;
    while (f != null) {
        if (bNoeudTexte(f)) {
            f = f.previousSibling;
            continue;
        }
        else {
            XMLPositionneElement(p, f);
            return true;
        }
    }
    return (p.Att = nXMLDernierAttribut(e)) >= 0;
}
function XMLDernier(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    // si on est dans un XPath
    if (p.XPathRes != null) {
        return __bXMLDernierXPath(p);
    }
    bXMLDernierFils(p, pXMLParent(p));
    XMLInitRechDoc(p);
    return true;
}
function pXMLCourant(p, a, m) {
    if (p.Att != XMLErreur) {
        return (a == null) ? p.Pos.attributes[p.Att] : null;
    }
    if (a == null) {
        return p.Pos;
    }
    var i = nXMLAttribut(p.Pos, a, m);
    return (i != XMLErreur) ? p.Pos.attributes[i] : null;
}
function XMLDonnee(Nom, Att, Mod) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return "";
    }
    var e = pXMLCourant(p, Att, Mod);
    var a = (p.Att != XMLErreur) || (Att != null);
    //Noeud contenant les données
    var oNoeud = ((e != null) && (a || bNoeudTexte(e.firstChild))) ? (a ? e : e.firstChild) : null;
    //Initialisation résultat
    var sRes = "";
    //Récupération données (FireFox découpe les chaînes de plus de 4096 caractères en liste de noeuds texte)
    while (oNoeud != null) {
        //Récupération valeur
        if (oNoeud.nodeValue != null) {
            sRes += oNoeud.nodeValue;
        }
        //On est sur un attribut ? oui => on arrête le parcours; non => on va sur le noeud suivant
        oNoeud = a ? null : oNoeud.nextSibling;
    }
    //Résultat
    return sRes;
}
function XMLEnDehors(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return true;
    }
    return p.Dehors;
}
function bXMLPosElemFils(p, e) {
    if (e == null) {
        return false;
    }
    var b = false;
    for (var i = 0; (!b) && (i < e.childNodes.length); i++) {
        if ((b = (!bNoeudTexte(e.childNodes[i]))) == true) {
            XMLPositionneElement(p, e.childNodes[i]);
        }
    }
    return b;
}
function nXMLPremierAttribut(e) {
    return (e != null) ? nXMLIndiceAttribut(e, 0, true) : XMLErreur;
}
function bXMLFils(p) {
    var b = false;
    if (p.Att == XMLErreur) {
        var n = nXMLPremierAttribut(p.Pos);
        if (n != XMLErreur) {
            p.Att = n;
            b = true;
        }
        else {
            b = bXMLPosElemFils(p, p.Pos);
        }
    }
    return b;
}
function XMLFils(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    var b = bXMLFils(p);
    XMLInitRechDoc(p);
    return b;
}
function XMLNomElement(Nom) {
    var sNom = String(Nom);
    // récupération du document
    var p = pclDocXML(sNom, true);
    if (p == null) {
        return "";
    }
    // on prend le noeud courant
    var c = pXMLCourant(p);
    // si on est sur un commentaire
    // il fut exclure le # du début
    if (c.nodeType == COMMENT_NODE && bXMLChaineCompare(c.nodeName, XMLDebutComment, XMLIgnoreLaCasse + XMLCommencePar)) {
        return c.nodeName.substring(XMLDebutComment.length, c.nodeName.length);
    }
    // sinon, on prend toute la chaine
    return c.nodeName;
}
function XMLNomParent(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return "";
    }
    var e = pXMLParent(p);
    return (e != null) ? e.nodeName : "";
}
function XMLParent(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    var e = pXMLParent(p);
    if (e != null) {
        XMLPositionneElement(p, e);
    }
    XMLInitRechDoc(p);
    return (e != null);
}
function oXMLElemPrec(p) {
    while ((p = p.previousSibling) && (bNoeudTexte(p) || (p.nodeType == PROCESSING_INSTRUCTION_NODE))) {
    }
    return p;
}
function bXMLDansFilsRech(p, b) {
    var e = b ? p.Pos : p.Pos.parentNode;
    while ((e != null) && (e.parentNode != p.DebRech)) {
        e = e.parentNode;
    }
    return e != null;
}
function bXMLRechercheOK(p) {
    if (p.ValRech == null) {
        return true;
    }
    var b = false;
    if (p.Att != XMLErreur) {
        if (p.OptRechNiv & XMLAttribut) {
            b = bXMLChaineCompare(p.Pos.attributes[p.Att].nodeName, p.ValRech, p.OptRech);
        }
        if ((!b) && (p.OptRechNiv & XMLValeur)) {
            b = bXMLChaineCompare(p.Pos.attributes[p.Att].nodeValue, p.ValRech, p.OptRech);
        }
    }
    else {
        if (p.OptRechNiv & XMLBalise) {
            b = bXMLChaineCompare(p.Pos.nodeName, p.ValRech, p.OptRech);
        }
        if ((!b) && (p.OptRechNiv & XMLValeur) && bNoeudTexte(p.Pos.firstChild)) {
            b = bXMLChaineCompare(p.Pos.firstChild.nodeValue, p.ValRech, p.OptRech);
        }
    }
    return b;
}
function bXMLRetourSiEchec(p, b, e, a) {
    if (!b) {
        p.Pos = e;
        p.Att = a;
        p.Dehors = true;
    }
    return b;
}
function XMLPrecedent(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    // si on est dans un XPath
    if (p.XPathRes != null) {
        return __bXMLPrecedentXPath(p);
    }
    p.Dehors = false;
    var e = p.Pos;
    var a = p.Att;
    var b = false;
    while (!b) {
        if (p.Rech && (p.OptRechNiv & XMLSousElement) && (p.Att == XMLErreur)) {
            b = bXMLDernierFils(p, p.Pos);
        }
        if ((!b) && ((!p.Rech) || ((p.OptRechNiv & XMLNiveauCourant) || (pXMLParent(p) != p.DebRech.parentNode)))) {
            if ((p.Att != XMLErreur) && ((!p.Rech) || (p.OptRechNiv & (XMLAttribut | XMLValeur)))) {
                var n = nXMLIndiceAttribut(p.Pos, p.Att - 1, false);
                if (n != XMLErreur) {
                    p.Att = n;
                    b = true;
                }
            }
            else {
                var oPrecedent = oXMLElemPrec(p.Pos);
                if (!oPrecedent) {
                    var nAtt = nXMLDernierAttribut(p.Pos.parentNode);
                    if ((p.Pos.parentNode != null) && (nAtt != XMLErreur)) {
                        p.Pos = p.Pos.parentNode;
                        p.Att = nAtt;
                        b = true;
                    }
                }
                else {
                    XMLPositionneElement(p, oPrecedent);
                    b = true;
                }
            }
        }
        if ((!b) && p.Rech) {
            var q = null;
            while ((!b) && ((q = pXMLParent(p)) != null) && ((p.OptRechNiv & XMLContinue) || ((((p.Att == XMLErreur) ? q : q.parentNode) == p.DebRech) && (p.OptRechNiv & XMLNiveauCourant)) || bXMLDansFilsRech(p, !!oXMLElemPrec(q)))) {
                XMLPositionneElement(p, oXMLElemPrec(q) || q);
            }
        }
        if (!b) {
            break;
        }
        b = bXMLRechercheOK(p);
    }
    return bXMLRetourSiEchec(p, b, e, a);
}
function XMLPremier(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    // si on est dans un XPath
    if (p.XPathRes != null) {
        return __bXMLPremierXPath(p);
    }
    var e = pXMLParent(p);
    var n = nXMLPremierAttribut(e);
    if ((e != null) && (n != XMLErreur)) {
        p.Pos = e;
        p.Att = n;
    }
    else {
        bXMLPosElemFils(p, e);
    }
    XMLInitRechDoc(p);
    return true;
}
function XMLRacine(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    XMLPositionneElement(p, p.Doc.documentElement);
    XMLInitRechDoc(p);
    return true;
}
function XMLRecherche(Nom, Valeur, Parcours, Option) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    p.Rech = true;
    p.DebRech = p.Pos;
    p.AttRech = p.Att;
    p.ValRech = Valeur;
    p.OptRechNiv = ((Parcours != null) ? Parcours : 0) + ((!(Parcours & (XMLElement + XMLValeur))) ? XMLElement : 0) + ((!(Parcours & (XMLNiveauCourant + XMLSousElement + XMLContinue))) ? (XMLNiveauCourant + XMLSousElement) : 0);
    p.OptRech = (Option != null) ? Option : XMLExact;
    p.Dehors = false;
    p.XPathRes = null;
    p.nIndiceSnapshot = 0;
    p.XPathValeur = null;
    return XMLSuivant(Nom);
}
function XMLSuivant(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return false;
    }
    // si on est dans un XPath
    if (p.XPathRes != null) {
        return __bXMLSuivantXPath(p);
    }
    p.Dehors = false;
    var e = p.Pos;
    var a = p.Att;
    var b = false;
    while (!b) {
        if (p.Rech && (p.OptRechNiv & XMLSousElement) && (p.Att == XMLErreur)) {
            b = (p.OptRechNiv & XMLAttribut) ? bXMLFils(p) : bXMLPosElemFils(p, p.Pos);
        }
        if ((!b) && ((!p.Rech) || ((p.OptRechNiv & XMLNiveauCourant) || (pXMLParent(p) != p.DebRech.parentNode)))) {
            //On est sur un attribut et on n'est ps en cours de recherche ou on recherche juste au niveau des attributs et valeurs ?
            if ((p.Att != XMLErreur) && ((!p.Rech) || (p.OptRechNiv & (XMLAttribut | XMLValeur)))) {
                //Oui => on passe sur l'attribut suivant
                var n = nXMLIndiceAttribut(p.Pos, p.Att + 1, true);
                if (n == XMLErreur) {
                    b = bXMLPosElemFils(p, p.Pos);
                }
                else {
                    p.Att = n;
                    b = true;
                }
            }
            else {
                //Non => on se met sur le noeud suivant
                var oNoeud = p.Pos.nextSibling;
                //Tant qu'on est sur un noeud texte (cas d'un document créé à partir d'un texte avec des retours chariot entre les balise => des frères neuds texte RC sont créés entre les balises)
                while (bNoeudTexte(oNoeud)) {
                    //On passe au neud suivant
                    oNoeud = oNoeud.nextSibling;
                }
                //On a trouvé un noeud frère non texte ?
                if (oNoeud != null) {
                    //Oui => on se positionne sur ce noeud
                    XMLPositionneElement(p, oNoeud);
                    b = true;
                }
            }
        }
        if ((!b) && p.Rech) {
            var q = null;
            while ((!b) && ((q = pXMLParent(p)) != null) && ((p.OptRechNiv & XMLContinue) || ((((p.Att == XMLErreur) ? q : q.parentNode) == p.DebRech) && (p.OptRechNiv & XMLNiveauCourant)) || bXMLDansFilsRech(p, q.nextSibling != null))) {
                XMLPositionneElement(p, (b = (q.nextSibling != null)) ? q.nextSibling : q);
            }
        }
        if (!b) {
            break;
        }
        b = bXMLRechercheOK(p);
    }
    return bXMLRetourSiEchec(p, b, e, a);
}
function XMLTermine(Nom) {
    var p = pclDocXML(Nom, true, true);
    if (p == null) {
        return false;
    }
    p.Doc = p.Pos = p.DebRech = null;
    return true;
}
function XMLTrouve(Nom) {
    return !XMLEnDehors(Nom);
}
function XMLTypeElement(Nom) {
    var p = pclDocXML(Nom, true);
    if (p == null) {
        return XMLErreur;
    }
    return (p.Att != XMLErreur) ? XMLAttribut : XMLBalise;
}
// Fonction WL XMLExtraitDocument()
function bXMLExtraitDocument(Source, Destination) {
    // formatage des paramètres
    var sSource = String(Source);
    var sDestination = String(Destination);
    // récupération du document source
    var pSource = pclDocXML(sSource, true);
    if (pSource == null) {
        return false;
    }
    // création du document destination
    XMLAjoutDoc(sDestination, pSource, false);
    var pDestination = pclDocXML(sDestination, true);
    if (pDestination == null) {
        return false;
    }
    // changement du nom
    if (pSource.Pos != null) {
        pDestination.Doc = pSource.Pos;
    }
    pDestination.Pos = pDestination.Doc;
    pDestination.Doc.Nom = sDestination;
    // repositionnement sur la racine
    XMLRacine(pDestination);
    return true;
}
// Fonction WL XMLFilsExiste()
function bXMLFilsExiste(Doc, Type) {
    var snXMLBalise = 0x00000001;
    var snXMLAttribut = 0x00000002;
    var snXMLElement = 0x00000003;
    // formatage des paramètres
    var sDoc = String(Doc);
    var nType = snXMLElement;
    if (typeof Type == "number") {
        nType = Type;
    }
    // récupération du document source
    var p = pclDocXML(sDoc, true);
    if (p == null) {
        return false;
    }
    // le type doit avoir une valeur valide
    if ((nType & snXMLElement) === 0) {
        return false;
    }
    // récupération du noeud courant
    var pNoeudCourant = pXMLCourant(p);
    if (pNoeudCourant == null) {
        return false;
    }
    var bRes = false;
    // si le noeud a un attribut
    if ((nType & snXMLAttribut) && pNoeudCourant.nodeType !== XMLAttribut && p.Pos.attributes !== undefined && p.Pos.attributes.length > 0) {
        bRes = true;
    }
    // si le noeud est une balise
    if ((nType & snXMLBalise) && pNoeudCourant.nodeType === XMLBalise) {
        bRes = true;
    }
    return bRes;
}
// Fonction WL XMLModifie()
function bXMLModifie(Doc, Valeur) {
    // formatage des paramètres
    var sDoc = String(Doc);
    var sValeur = String(Valeur);
    // récupération du document source
    var p = pclDocXML(sDoc, true);
    if (p == null) {
        return false;
    }
    // récupération du noeud courant
    var pNoeudCourant = pXMLCourant(p);
    if (pNoeudCourant == null) {
        return false;
    }
    // si on a un attribut
    var bAttribut = (p.Att != XMLErreur);
    var oNoeud = null;
    // si le noeud courant existe et contient soit un attribut, soit une texte
    if (((pNoeudCourant != null) && (bAttribut || bNoeudTexte(pNoeudCourant.firstChild)))) {
        // si c'est un attribut
        if (bAttribut) {
            oNoeud = pNoeudCourant;
        }
        // si c'est une balise, on prend son premier fils
        else {
            oNoeud = pNoeudCourant.firstChild;
        }
    }
    // pas de modification possible
    if (oNoeud == null) {
        return false;
    }
    // modification de la valeur
    oNoeud.nodeValue = sValeur;
    oNoeud.nextSibling = null;
    return true;
}
function __XMLExecuteXPath(p, Path, Type) {
    // il faut doubler les slash
    var sPath = String(Path).split("//").join("##");
    sPath = sPath.split("/").join("//");
    sPath = sPath.split("##").join("//");
    var nType = parseInt(String(Type), 10);
    // évaluation du path
    var nsResolver = p.Doc.createNSResolver(p.Doc.ownerDocument == null ? p.Doc.documentElement : p.Doc.ownerDocument.documentElement);
    var XPathRes = p.Doc.evaluate(sPath, p.Doc, nsResolver, nType, null);
    return XPathRes;
}
// Fonction WL XMLLit()
function XMLLit(Nom, Path, NonTrouve) {
    // valeur par défaut
    var sNonTrouve = "";
    if (typeof NonTrouve === "string") {
        sNonTrouve = NonTrouve;
    }
    // récupération du document
    var p = pclDocXML(String(Nom), true);
    if (p == null) {
        return sNonTrouve;
    }
    // recheche du noeud
    var XPathRes = __XMLExecuteXPath(p, Path, XPathResult.FIRST_ORDERED_NODE_TYPE);
    // vérifie le type du résulat
    if (XPathRes.resultType === XPathResult.FIRST_ORDERED_NODE_TYPE && XPathRes.singleNodeValue != null) {
        // pour un attribut
        if (XPathRes.singleNodeValue.childNodes[0] === undefined) {
            return String(XPathRes.singleNodeValue.value);
        }
        // pour une valeur
        return String(XPathRes.singleNodeValue.childNodes[0].nodeValue);
    }
    // non trouvé
    return sNonTrouve;
}
// Fonction WL XMLEcrit()
function bXMLEcrit(Nom, Path, Valeur) {
    // récupération du document
    var p = pclDocXML(String(Nom), true);
    if (p == null) {
        return false;
    }
    // valeur
    var sValeur = "";
    if (typeof Valeur === "string") {
        sValeur = Valeur;
    }
    // recheche du noeud
    var XPathRes = __XMLExecuteXPath(p, Path, XPathResult.FIRST_ORDERED_NODE_TYPE);
    // vérifie le type du résulat
    if (XPathRes.resultType === XPathResult.FIRST_ORDERED_NODE_TYPE && XPathRes.singleNodeValue != null) {
        // pour un attribut
        if (XPathRes.singleNodeValue.childNodes[0] === undefined) {
            XPathRes.singleNodeValue.value = sValeur;
        }
        // pour une valeur
        XPathRes.singleNodeValue.childNodes[0].nodeValue = sValeur;
        return true;
    }
    return false;
}
// retourne le noeud courant du doc
function __oGetNoeudCourant(Doc) {
    // formatage des paramètres
    var sDoc = String(Doc);
    // récupération du document source
    var p = pclDocXML(sDoc, true);
    if (p == null) {
        return null;
    }
    // récupération du noeud courant
    var pNoeudCourant = pXMLCourant(p);
    if (pNoeudCourant == null) {
        return null;
    }
    return pNoeudCourant;
}
// Fonction Wl XMLRenomme()
function bXMLRenomme(Doc, Valeur) {
    // récupération du noeud courant
    var pNoeudCourant = __oGetNoeudCourant(Doc);
    if (pNoeudCourant == null) {
        return false;
    }
    // formatage des paramètres
    var sValeur = String(Valeur);
    // si on est sur un commentaire
    if (pNoeudCourant.nodeType == COMMENT_NODE && bXMLChaineCompare(pNoeudCourant.nodeName, XMLDebutComment, XMLIgnoreLaCasse + XMLCommencePar)) {
        pNoeudCourant.nodeName = XMLDebutComment + sValeur;
    }
    // sinon, on prend toute la chaine
    pNoeudCourant.nodeName = sValeur;
    return true;
}
// Fonction WL XMLNameSpace()
function sXMLNamespace(Doc) {
    // récupération du noeud courant
    var pNoeudCourant = __oGetNoeudCourant(Doc);
    // si pas de noeud courant ou si le noeud n'est pas une balise
    if (pNoeudCourant == null || pNoeudCourant.nodeType !== XMLBalise) {
        return "";
    }
    var sNodeName = "";
    // si il y a un fils
    if (pNoeudCourant.firstElementChild != null) {
        sNodeName = pNoeudCourant.firstElementChild.nodeName;
    }
    else {
        sNodeName = pNoeudCourant.nodeName;
    }
    // extraction du namespace si il y en a un
    var nPos = sNodeName.indexOf(":");
    if (nPos != -1) {
        return sNodeName.substring(0, nPos);
        ;
    }
    return "";
}
// Fonction WL NameSpaceURI()
function sXMLNamespaceURI(Doc) {
    // récupération du noeud courant
    var pNoeudCourant = __oGetNoeudCourant(Doc);
    // si pas de noeud courant ou si le noeud n'est pas une balise
    if (pNoeudCourant == null || pNoeudCourant.nodeType !== XMLBalise) {
        return "";
    }
    var sNameSpaceURI = "";
    // si il y a un fils
    if (pNoeudCourant.firstElementChild != null) {
        sNameSpaceURI = pNoeudCourant.firstElementChild.namespaceURI;
    }
    else {
        sNameSpaceURI = pNoeudCourant.namespaceURI;
    }
    return sNameSpaceURI === null ? "" : sNameSpaceURI;
}
// Fonction WL XMLExecuteXPath()
function bXMLExecuteXPath(Nom, Path) {
    // récupération du document
    var p = pclDocXML(String(Nom), true);
    if (p == null) {
        return false;
    }
    // annule la recherche précédente
    XMLInitRechDoc(p);
    var sPath = String(Path);
    // si le path est un chemin
    if (sPath.charAt(0) == "/") {
        // recherche du noeud
        var XPathRes = __XMLExecuteXPath(p, sPath, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE);
        // vérifie le type du résulat
        if (XPathRes.resultType === XPathResult.ORDERED_NODE_SNAPSHOT_TYPE && XPathRes.snapshotLength > 0) {
            // modifie la position courante
            p.Pos = XPathRes.snapshotItem(0);
            p.Att = XMLErreur;
            p.Dehors = false;
            p.XPathRes = XPathRes;
            return true;
        }
    }
    // pour une requête
    else {
        // on se place en dehors
        p.Dehors = true;
        // recherche du noeud
        var XPathRes = __XMLExecuteXPath(p, sPath, XPathResult.ANY_TYPE);
        // selon le type de résulat
        switch (XPathRes.resultType) {
            case XPathResult.BOOLEAN_TYPE:
                p.XPathValeur = new Boolean(XPathRes.booleanValue);
                return true;
            case XPathResult.NUMBER_TYPE:
                p.XPathValeur = new Number(XPathRes.numberValue);
                return true;
            case XPathResult.STRING_TYPE:
                p.XPathValeur = new String(XPathRes.stringValue);
                return true;
        }
    }
    // pas trouvé
    return false;
}
// Positionnement sur le snapshot courant
function __bXMLPositionneXPathSnapshot(p) {
    // vérification des bornes
    if (p.nIndiceSnapshot < 0 || p.nIndiceSnapshot >= p.XPathRes.snapshotLength) {
        p.Dehors = true;
        return false;
    }
    // on se positionne
    p.Pos = p.XPathRes.snapshotItem(p.nIndiceSnapshot);
    p.Dehors = false;
    return true;
}
// positionnement sur le snapshot suivant
function __bXMLSuivantXPath(p) {
    // si pas de doc ou si pas de XPathResult
    if (p == null || p.XPathRes == null) {
        return false;
    }
    // snapshot suivant
    p.nIndiceSnapshot++;
    return __bXMLPositionneXPathSnapshot(p);
}
// positionnement sur le snapshot précédent
function __bXMLPrecedentXPath(p) {
    p.nIndiceSnapshot--;
    return __bXMLPositionneXPathSnapshot(p);
}
// positionnement sur le premier snapshot
function __bXMLPremierXPath(p) {
    p.nIndiceSnapshot = 0;
    return __bXMLPositionneXPathSnapshot(p);
}
// positionnement sur le dernier snapshot
function __bXMLDernierXPath(p) {
    p.nIndiceSnapshot = p.XPathRes.snapshotLength - 1;
    return __bXMLPositionneXPathSnapshot(p);
}
// Fonction WL XMLRésultat()
function XMLResultat(Doc) {
    // récupération du document
    var p = pclDocXML(String(Doc), true);
    if (p == null) {
        return "";
    }
    if (p.XPathValeur == null) {
        return "";
    }
    return p.XPathValeur;
}
// Fonction WL XMLSauvePosition
function nXMLSauvePosition(Nom) {
    // récupération du document
    var p = pclDocXML(String(Nom), true);
    if (p == null) {
        return XMLErreur;
    }
    // sauvegarde du contexte en cours
    var oPosition = {};
    oPosition.Pos = p.Pos;
    oPosition.Rech = p.Rech;
    oPosition.DebRech = p.DebRech;
    oPosition.AttRech = p.AttRech;
    oPosition.ValRech = p.ValRech;
    oPosition.OptRechNiv = p.OptRechNiv;
    oPosition.OptRech = p.OptRech;
    oPosition.Dehors = p.Dehors;
    oPosition.Att = p.Att;
    oPosition.Ent = p.Ent;
    oPosition.XPathRes = p.XPathRes;
    oPosition.nIndiceSnapshot = p.nIndiceSnapshot;
    oPosition.XPathValeur = p.XPathValeur;
    // incrémente l'indice
    p.nIndicePosition++;
    // création d'une nouvelle position
    p.TabPosition[p.nIndicePosition] = oPosition;
    // retourne la position créée
    return p.nIndicePosition;
}
;
// Fonction WL XMLRetourPosion
function bXMLRetourPosition(Nom, Position, Options) {
    // constantes pour la fonction XMLRetourPosition
    var snXMLRPConserve = 0x00000002; // La position n'est pas libérée (d'autres appels à la fonction XMLRetourPosition pourront être réalisés sur cette position).
    var snXMLRPDefaut = 0x00000004; // La position est libérée. La position sauvegardée est restaurée.
    var snXMLRPFiltre = 0x00000008; // Restaure le filtre posé au moment du XMLSauvePosition.
    // récupération du document
    var p = pclDocXML(String(Nom), true);
    if (p == null) {
        return false;
    }
    // formatage des paramètres
    var nIndicePosition = parseInt(String(Position), 10);
    var nOptions = parseInt(String(Options), 10);
    // la position demandée n'existe pas
    if (p.TabPosition[nIndicePosition] === undefined || p.TabPosition[nIndicePosition] == null) {
        return false;
    }
    var oPosition = p.TabPosition[nIndicePosition];
    // initialise la recheche
    XMLInitRechDoc(p);
    // restauration du contexte
    p.Pos = oPosition.Pos;
    p.Att = oPosition.Att;
    p.Ent = oPosition.Ent;
    // si il faut restaurer aussi la recherche en cours
    if (nOptions & snXMLRPFiltre) {
        p.Rech = oPosition.Rech;
        p.DebRech = oPosition.DebRech;
        p.AttRech = oPosition.AttRech;
        p.ValRech = oPosition.ValRech;
        p.OptRechNiv = oPosition.OptRechNiv;
        p.OptRech = oPosition.OptRech;
        p.Dehors = oPosition.Dehors;
        p.XPathRes = oPosition.XPathRes;
        p.nIndiceSnapshot = oPosition.nIndiceSnapshot;
        p.XPathValeur = oPosition.XPathValeur;
    }
    // si l faut supprimer la position
    if ((nOptions & snXMLRPConserve) === 0 && (nOptions & snXMLRPDefaut)) {
        // supprime la position
        p.TabPosition[nIndicePosition] = null;
    }
    return true;
}
;
// Création d'un XPath à partir d'un noeud
function __getXPathForElement(pNoeudCourant, pNoeudRacine) {
    var sXPath = "";
    // parcours des noeud en remontant jusqu'à la racine
    while (pNoeudCourant !== pNoeudRacine) {
        // pour un attribut
        if (pNoeudCourant.nodeType === XMLAttribut) {
            sXPath = "/@" + pNoeudCourant.nodeName;
        }
        // pour une balise
        else {
            // si pas d'attribut
            if (pNoeudCourant.attributes.length === 0) {
                sXPath = pNoeudCourant.nodeName + '/' + sXPath;
            }
            // si il y a des attributs,il faut l'indice
            else {
                // recherche de l'indice du noeud
                var nIndice = 0;
                var pNoeud = pNoeudCourant;
                while (pNoeud) {
                    // si le noeud a le même nom, il faut incrémenter l'indice
                    if (pNoeud.nodeType === 1 && pNoeud.nodeName === pNoeudCourant.nodeName) {
                        nIndice += 1;
                    }
                    pNoeud = pNoeud.previousSibling;
                }
                // construit le path avec l'indice
                if (nIndice > 1) {
                    sXPath = pNoeudCourant.nodeName + "[" + nIndice + "]" + '/' + sXPath;
                }
                else {
                    sXPath = pNoeudCourant.nodeName + '/' + sXPath;
                }
            }
        }
        // remonte sur le parent
        pNoeudCourant = pNoeudCourant.parentNode;
    }
    // finalisation : le path doit commencer par / qui représente la racine
    sXPath = "/" + sXPath;
    sXPath = sXPath.replace(/\/$/, '');
    return sXPath;
}
// Fonction WL XMLPosition()
function sXMLPosition(Nom) {
    // formatage des paramètres
    var sDoc = String(Nom);
    // récupération du document source
    var p = pclDocXML(sDoc, true);
    if (p == null) {
        return "";
    }
    // récupération du noeud courant
    var pNoeudCourant = pXMLCourant(p);
    if (pNoeudCourant == null) {
        return "";
    }
    return __getXPathForElement(pNoeudCourant, p.Doc);
}
// Insertion d'un document avant le noeud courant
function __bInsereNoeudAvant(oNoeudReferecence, oNoeudAInserer) {
    // le noeud à insérer ne peut pas être à deux endroits différents
    // il faut donc en faire une copie
    var oNouveauNoeud = oNoeudAInserer.cloneNode();
    // récupération dunoeud parent
    var oParent = oNoeudReferecence.parentNode;
    if (oParent == null) {
        return false;
    }
    // insertion
    oParent.insertBefore(oNoeudAInserer, oNouveauNoeud);
    return true;
}
// Insertion d'un noeud avant le noeud courant
function __bInsereNoeudAvant(oNoeudReferecence, oNoeudAInserer) {
    // récupération du noeud parent
    var oParent = oNoeudReferecence.parentNode;
    if (oParent == null) {
        return false;
    }
    // insertion avant
    oParent.insertBefore(oNoeudAInserer, oNoeudAInserer);
    return true;
}
// Insertion d'un noeud après le noeud courant
function __bInsereNoeudApres(oNoeudReferecence, oNoeudAInserer) {
    // récupération du noeud parent
    var oParent = oNoeudReferecence.parentNode;
    if (oParent == null) {
        return false;
    }
    // insertion après
    // si oNoeudAInserer.nextSibling == null l'insertion se fait quand même en dernier fils du parent
    oParent.insertBefore(oNoeudAInserer, oNoeudAInserer.nextSibling);
    return true;
}
// Insertion d'un noeud fils
function __bInsereNoeudFils(oNoeudReferecence, oNoeudAInserer) {
    oNoeudReferecence.appendChild(oNoeudAInserer);
    return true;
}
// Insertion d'un noeud
function __bInsereNoeud(oNoeudReferecence, oNoeudAInserer, nPosition) {
    // on ne peut pas insérer la racine d'un document #document
    // dans ce cas, on prend le premier fils
    if (oNoeudAInserer.nodeType === Node.DOCUMENT_NODE) {
        oNoeudAInserer = oNoeudAInserer.firstChild;
    }
    // selon la position d'insertion
    switch (nPosition) {
        case snXMLSousElement:
            return __bInsereNoeudFils(oNoeudReferecence, oNoeudAInserer);
        case snXMLAvant:
            return __bInsereNoeudAvant(oNoeudReferecence, oNoeudAInserer);
        case snXMLApres:
            return __bInsereNoeudApres(oNoeudReferecence, oNoeudAInserer);
    }
    return false;
}
// Fonction Wl XMLInsereDocument()
function bXMLInsereDocument(DocDestination, DocSource, Position) {
    // le doc source à insérer
    var pSource = pclDocXML(String(DocSource), true);
    if (pSource == null) {
        return false;
    }
    // récupération du document
    var p = pclDocXML(String(DocDestination), true);
    if (p == null) {
        return false;
    }
    // vérification du noeud courant
    if (p.Pos == null) {
        return false;
    }
    // position d'insertion du document
    var nPosition = snXMLApres;
    if (typeof Position === "number") {
        nPosition = Position;
    }
    // le noeud à insérer ne peut pas être à deux endroits différents
    // il faut donc en faire une copie
    var oNouveauNoeud = pSource.Doc.cloneNode(true);
    // on fait l'insertion au bon endroit
    return __bInsereNoeud(p.Pos, oNouveauNoeud, nPosition);
}
// Fonction WL XMLInsereElement()
function bXMLInsereElement(Doc, NomElement, Valeur, Position, ChangementPosition) {
    // préparatin des paramètres
    var sNomElement = String(NomElement);
    var sValeur = "";
    if (typeof Valeur === "string") {
        sValeur = TexteVersXML(XMLVersTexte(Valeur));
    }
    var nPosition = snXMLSousElement;
    if (typeof Position === "number") {
        nPosition = Position;
    }
    var bChangementPosition = false;
    if (typeof ChangementPosition === "boolean") {
        bChangementPosition = ChangementPosition;
    }
    // récupération du document
    var p = pclDocXML(String(Doc), true);
    if (p == null) {
        return false;
    }
    // vérification du noeud courant
    if (p.Pos == null) {
        return false;
    }
    // si le noeud courant est un attribut
    if (p.Pos.nodeType === XMLAttribut) {
        p.Pos.setAttribute(sNomElement, sValeur);
        // positionnement sur l'attribut
        if (bChangementPosition) {
            var pos = p.Pos.getAttributeNode(sNomElement);
            if (pos != null) {
                p.Pos = pos;
            }
        }
    }
    else {
        // création de l'élément
        var oElement = p.Doc.createElement(sNomElement);
        if (oElement == null) {
            return false;
        }
        // création du noeud contenant la valeur
        if (!bXMLChaineVide(sValeur)) {
            var oNouveauNoeud = p.Doc.createTextNode(sValeur);
            if (oNouveauNoeud !== null) {
                oElement.appendChild(oNouveauNoeud);
            }
        }
        // on fait l'insertion au bon endroit
        if (!__bInsereNoeud(p.Pos, oElement, nPosition)) {
            return false;
        }
        // positionnement sur le noeud
        if (bChangementPosition) {
            p.Pos = oElement;
            p.Att = XMLErreur;
        }
    }
    return true;
}
// Fonction WL XMLSupprime()
function bXMLSupprime(Doc) {
    // récupération du document
    var p = pclDocXML(String(Doc), true);
    if (p == null) {
        return false;
    }
    // vérifie la position courante
    if (p.Pos == null) {
        return false;
    }
    // init de la recherche
    XMLInitRechDoc(p);
    // noeud à supprimer
    var oNoeud = p.Pos;
    // récupération du parent
    var oParent = oNoeud.parentNode;
    // modifie la position courante
    if (oParent != null && oParent === p.Doc) {
        XMLPositionneElement(p, null);
    }
    else {
        XMLPositionneElement(p, oParent);
    }
    // si le noeud à supprimer est un attribut
    if (p.Att != XMLErreur) {
        p.Pos.removeAttributeNode(p.Pos.attributes[p.Att]);
    }
    // pour une balise
    else {
        oNoeud.remove();
    }
    return true;
}
