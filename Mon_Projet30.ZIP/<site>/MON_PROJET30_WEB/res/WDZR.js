// WDZR.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS bIE bIEQuirks
// - WDAjax.js
///#GLOBALS clWDAJAXMain
// - WDTableZRCommun.js
///#GLOBALS WDSelection WDZRClassique
// - WDTable.js
///#GLOBALS WDTableCacheLigne WDTable

// Ligne dans une ZR
function WDZRCacheLigne (oXMLLigne, oObjetZR, nLigne)
{
	if (oXMLLigne)
	{
		// Appel le constructeur de la classe de base
		WDTableCacheLigne.prototype.constructor.apply(this, arguments);

		// Recupere la ligne et la colonne effective
		this.m_nLignePosVisibleEff = clWDAJAXMain.nXMLGetAttributSafe(oXMLLigne, this.XML_LIGNE_EFFECTIVE, parseInt(nLigne / oObjetZR.vnGetNbLignesLogiquesParLignePhysique(), 10));
		this.m_nColonneEff = clWDAJAXMain.nXMLGetAttributSafe(oXMLLigne, this.XML_COLONNE_EFFECTIVE, nLigne % oObjetZR.vnGetNbLignesLogiquesParLignePhysique());
	}
};

// Declare l'heritage
WDZRCacheLigne.prototype = new WDTableCacheLigne();
// Surcharge le constructeur qui a ete efface
WDZRCacheLigne.prototype.constructor = WDZRCacheLigne;

WDZRCacheLigne.prototype.XML_LIGNE_EFFECTIVE = "LIGNEEFF";
WDZRCacheLigne.prototype.XML_COLONNE_EFFECTIVE = "COLONNEEFF";

// Place le contenu du XML dans une cellule
WDZRCacheLigne.prototype._vPlaceXMLDansCellule = function _vPlaceXMLDansCellule(oXMLCellule, oCellule/*, nColonne*//*, oChampTable*/)
{
	var oXMLCelluleChildNodes = oXMLCellule.childNodes;

	// Si on est dans le cas d'une ZR on lit la balise millieu
	if ((oXMLCelluleChildNodes.length == 3) && (oXMLCelluleChildNodes[1].nodeName == clWDAJAXMain.XML_CHAMP_LIGNES_LIGNE_CORPS))
	{
		oCellule.m_sValeur = clWDAJAXMain.sXMLGetValeur(oXMLCelluleChildNodes[1]);
	}
};

// Recupere la ligne dans le HTML
WDZRCacheLigne.prototype.vnGetLigneHTML = function vnGetLigneHTML(/*nLigneAbsolue*/)
{
	// Se place par rapport a la premiere ligne affichee
	return this.m_nLignePosVisibleEff;
};

// Recupere la colonne dans le HTML
WDZRCacheLigne.prototype.vnGetColonneHTML = function vnGetColonneHTML()
{
	return this.m_nColonneEff;
};

// GP 16/10/2014 : QW249545 : Fusionn�e avec WDZRCacheLigne.prototype.vnGetNbReplieesOuEnroulees
//// Si la ligne est repliee (ligne est invisible mais ses ruptures oui)
//// Utilis� pour supprimer les lignes ensuites
//// Retourne le nombre de ligne a ignorer ensuite (attention en serveur le nombre de lignes repli�es inclus la ligne courante, ici ce n'est pas le cas)
//// En revanche, c'est identique pour le nombre de lignes enroul�es qui n'inclus jamais la ligne courante
//WDZRCacheLigne.prototype.vnGetNbReplieesOuEnroulees = function vnGetNbReplieesOuEnroulees()
//{
//	// Se place par rapport a la premiere ligne affichee
//	// GP 20/07/2012 : On fait donc -1
//	return this.m_nNbRepliee - 1;
//};

// Classe manipulant une ZR
function WDZR(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		// Format de tabParametresSupplementaires attendu par WDTable : [ sXMLLignes, eCacheLimite, nHauteurLigne, nPagesMargeMin, nPagesMargeMax, eTypeSelection, tabStyle, tabImagesTriRechercheFiltre, bHauteurLigneVariable ]
		WDTable.prototype.constructor.apply(this, [sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, [tabParametresSupplementaires[0], tabParametresSupplementaires[1], tabParametresSupplementaires[2], tabParametresSupplementaires[3], tabParametresSupplementaires[4], WDSelection.prototype.ms_nSelectionSimple, tabParametresSupplementaires[5], undefined, true]]);

		// Format de tabParametresSupplementaires : [ sXMLLignes, eCacheLimite, nHauteurLigne, nPagesMargeMin, nPagesMargeMax, tabStyle, nNbLignesLogiquesParLignePhysique ]
		var nNbLignesLogiquesParLignePhysique = tabParametresSupplementaires[6];

		this.m_nNbLignesLogiquesParLignePhysique = nNbLignesLogiquesParLignePhysique;

		// Ne rien mettre ici qui doit etre remit a zero dans l'init
	}
};

// Declare l'heritage
WDZR.prototype = new WDTable();
// Surcharge le constructeur qui a ete efface
WDZR.prototype.constructor = WDZR;

// Classe de cache
WDZR.prototype.vCacheLigne = WDZRCacheLigne;

//// Initialisation
//WDZR.prototype.Init = function Init()
//{
//	// Appel de la methode de la classe de base
//	WDTable.prototype.Init.apply(this, arguments);
//};

//////////////////////////////////////////////////////////////////////////
// M�thodes de l'interface des ZRs

// Indique que le champ est une ZR
WDZR.prototype.vbZR = function vbZR()
{
	return true;
};

//////////////////////////////////////////////////////////////////////////
// M�thodes surcharg�es

// Recupere l'ID de la cellule depuis son numero de le ligne et de son information de colonne dans le cas des tables
WDTable.prototype._vsGetIDCellule = function _vsGetIDCellule(oLigneCache, nLigneAbsolue/*, nColonneSiTable*/)
{
	return this._sGetIDCellule(oLigneCache, nLigneAbsolue, oLigneCache.vnGetColonneHTML());
};

// Recupere le HTML d'une ligne dans la table
WDZR.prototype._vInitHTMLLigne = function _vInitHTMLLigne()
{
	// Recupere la balise table.
	// Code JSON pour les tables, code HTML pour les ZRs
	(this.m_sHTMLLigne = clWDUtil.sGetHTMLDansCommentaire(this.m_oHote));
};

// Genere le nombre de ligne HTML qui va bien pour afficher le tableau
WDZR.prototype._vtabGenereLignesHTML = function _vtabGenereLignesHTML(/*bAvecEntetes*/)
{
	// Recupere le HTML des lignes
	var sHTMLLigne = this._sCorrigeHTMLLigne(this.m_sHTMLLigne);

	// Le tableau du HTML des lignes
	var nLimiteI = this.m_nNbLignesHTML;
	var tabHTMLLigne = new Array(nLimiteI);
	var i;
	for (i = 0; i < nLimiteI; i++)
	{
		// Construit le HTML de la nouvelle ligne
		// Remplacer les balises indiquant le numero de ligne
		tabHTMLLigne[i] = sHTMLLigne.replace(/\[%_INDICE_%\]/g, i);
		// Pas de remplacement des commentaires (deja fait au chargement du HTML)
	}

	return tabHTMLLigne;
};

// Gestion sepcifique de l'evenement roulette SI il y a deplacement
WDZR.prototype._vForceDefilement = function(/*oEvent*/)
{
	// Si on est en saisie dans une zone repetee valide la modification de la ligne par une selection d'une autre partie du DOM
	// Dans certaines tables, ce code declenche une execution de DeplaceTable mais avec un deplacement vide.
	var oHote = this.m_oHote;

	// Il ne faut pas donner le focus a l'ascenseur car cela provoque un defilement irregulier (ou pas de defilment du tout) dans IE
	var sTabIndex;
	try
	{
		if (!bIEQuirks)
		{
			// Pour recevoir le focus un element doit avoir un TABINDEX
			sTabIndex = oHote.tabIndex;
			oHote.tabIndex = "1000";
		}

		oHote.focus();
	}
	finally
	{
		if (!bIEQuirks)
		{
			oHote.tabIndex = sTabIndex;
		}
	}

	// Appel de la methode de la classe de base
	WDTable.prototype._vForceDefilement.apply(this, arguments);
};

// Pas de bordure dans les ZRs
WDZR.prototype._vnGetOffset = function _vnGetOffset(/*oLignePhysique*//*, bExact*/)
{
	return 0;
};

// Recepere le style CSS a utiliser pour la hauteur des lignes :
// - table : "height"
// - ZR : "height" pour le mode quirks, "min-height" pour le reste
WDZR.prototype._vsGetCSSLigneHeight = function _vsGetCSSLigneHeight()
{
	return (bIEQuirks ? "height" : "min-height");
};

// Indique si on a une couleur de fond pour la s�lection de la ligne
// => C'est selon dans les ZRs. On devrait �tre plus pr�cis mais il faudrait avoir les couleurs de fond des styles.
WDZR.prototype.__bAvecSelection = function ()
{
	return WDSelection.prototype.ms_nSelectionSans !== this.veGetModeSelection() && "" !== this.m_tabStyle[2];
};
WDZR.prototype._vbAvecCouleurDeFondSelection = WDZR.prototype.__bAvecSelection;

// Indique si une ligne est selectionnee + retourne faux dans le cas des ZRs
WDZR.prototype.vbLigneEstSelectionneeSansZR = function vbLigneEstSelectionneeSansZR(/*nLigneAbsolue*/)
{
	return this.__bAvecSelection() && WDTable.prototype.vbLigneEstSelectionneeSansZR.apply(this, arguments);
};

// Vide une cellule de ZR
WDZR.prototype.vVideCellule = function vVideCellule(oEtatLigne, nColonne)
{
	this.__VideCellule(oEtatLigne.oGetCelluleHTML(this, nColonne));
};
WDZR.prototype.__VideCellule = function __VideCellule(oCellule)
{
	// Pas d'appel de la methode de la classe de base

	// La suppression des ruptures est fait par l'appel parent

	// Supprime les elements JavaScript pour les reference circulaires entre le DOM et le JS
	// Vide la cellule
	clWDUtil.SupprimeFilsEtOnFocus(oCellule, true);
};

// Remplit une cellule de la ZR
WDZR.prototype.vRemplitCellule = function vRemplitCellule(oCellule, sValeur, sBulleCellule, nLigneAbsolue, nColonne, oLigneCache/*, bSelection, tabRedimensionnementDesImages*/)
{
	// Pas d'appel de la methode de la classe de base

	// L'ajout des ruptures est fait par l'appel parent

	// Vide la cellule
	this.__VideCellule(oCellule);

	// Affiche ou masque la cellule selon son repliement
	// On modifie la racine de la ligne pour ne pas avoir de blanc
	var oCelluleParent = oCellule.parentNode;
	if (1 == this.vnGetNbLignesLogiquesParLignePhysique())
	{
		oCelluleParent = oCelluleParent.parentNode;
	}
	var bSansRepliees = (0 == oLigneCache.vnGetNbReplieesInclusSelf());
	clWDUtil.SetDisplay(oCelluleParent, bSansRepliees);

	if (bSansRepliees)
	{
		// Et place le contenu dans la cellule
		oCellule.innerHTML = String(sValeur);

		this._SetOnXxxSurChampsCellule(oCellule, nLigneAbsolue, nColonne);
	}
};

// Invalide la valeur actuelle du d�bordement en largeur
WDZR.prototype._vInvalideDebordeLargeur = function _vInvalideDebordeLargeur()
{
	// Jamais de d�bordement en largeur dans une ZR. Donc inutile de faire la moindre invalidation
	// Pas d'appel de la classe de base
};
// Lecture du d�bordement en largeur
WDZR.prototype._vbGetDebordeLargeur = function _vbGetDebordeLargeur()
{
	// Jamais de d�bordement en largeur dans une ZR
	return false;
};

// Recupere le nombre de colonne de presentation
WDZR.prototype.vnGetNbLignesLogiquesParLignePhysique = function()
{
	return this.m_nNbLignesLogiquesParLignePhysique;
};

// Click sur une ligne de zone repetee
WDZR.prototype.OnSelectLigne = function OnSelectLigne(nLigneRelative, nColonne, oEvent)
{
	// Pas d'appel de la casse de base

	// Si on a une requete en cours : la modification de la selection va etre ecrase donc on l'interdit
	if (this.m_oCache.m_tabRequetes.length > 0)
	{
		return;
	}

	// GP 05/11/2014 : QW251178 : Il semble que l'appel correct est nRelative2Visible2Absolue
	var nLigneAbsolue = this.nRelative2Visible2Absolue(nLigneRelative);

	// Regarde si la ligne est selectionne et ne fait rien si c'est deja le cas
	if (this.bLigneEstSelectionnee(nLigneAbsolue, NaN))
	{
		return;
	}

	// Supprime les autres selections (Normalement une seule ligne)
	this.bLigneDeselectionneTous(-1, NaN, oEvent);

	// Selectionne la ligne
	this.__bLigneSelectionnePosVisible(nLigneAbsolue, NaN, true, oEvent);

//	// Envoie une requete au serveur demandant le refraichissement de la ligne donnee
//	this.RequeteSelection(-1);
};

WDZR.prototype._vPostMAJLignes = function _vPostMAJLignes()
{
	// Appel de la classe de base
	WDTable.prototype._vPostMAJLignes.apply(this, arguments);

	// GP 29/11/2013 : TB84899/TB84009 : Reflow en HTML4 avec IE
	if (bIE && !clWDUtil.bHTML5)
	{
		this.m_oHote.className += "";
		// Pas sur le titre (on n'a pas de titre)
	}
};

WDZR.prototype._xvoGetInfoXY = WDZRClassique.prototype._xvoGetInfoXY;
