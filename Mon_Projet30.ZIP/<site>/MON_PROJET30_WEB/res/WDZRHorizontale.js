// WDZRHorizontale.js
/*! 27.0.1.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDUtil.js
///#GLOBALS bIE bTouch
// - WDChamp.js
///#GLOBALS WDChamp
// - WDDrag.js
///#GLOBALS WDDrag WDDragTouch

//////////////////////////////////////////////////////////////////////////
// Manipulation des champs zone repetee galerie

// Manipulation d'une zone repetee galerie
function WDZRHorizontale(/*sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires*/)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		WDChamp.prototype.constructor.apply(this, arguments);

		// Se declare dans la table globale des Tables/ZRs AJAX
		this.ms_tabTablesZRs.DeclareChamp(this);

		this.m_bDansOnSelectLigneExterne = false;

		// Ne rien mettre ici qui doit etre remit a zero dans l'init
	}
};

// Declare l'heritage
WDZRHorizontale.prototype = new WDChamp();
// Surcharge le constructeur qui a ete efface
WDZRHorizontale.prototype.constructor = WDZRHorizontale;

// Initialisation
WDZRHorizontale.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChamp.prototype.Init.apply(this, arguments);

	// Initialisation du defilement
	this._InitDefilement();

	// Hook le resizing pour deplacer les elements en cas de changement de geometrie
	// => Pas de hook on est deja automatiquement appele sur la methode _vOnResize

	// GP 23/06/2014 : TB87956 : Indique que les lignes sont affichees aux champs fils
	var nLigneAbsolue;
	var nLimiteLigneAbsolue = parseInt(this.m_oChampOcc.value, 10);
	for (nLigneAbsolue = 0; nLigneAbsolue < nLimiteLigneAbsolue; nLigneAbsolue++)
	{
		this.m_tabChampsFils._AppelMethodePtr(WDChamp.prototype.OnLigneTableZRAffiche, [nLigneAbsolue + 1, false]);
	}

	// Positionne le champ
	this._InitDeplace();
};

//////////////////////////////////////////////////////////////////////////
// M�thodes de l'interface des ZRs

// Indique que le champ est une ZR
WDZRHorizontale.prototype.vbZR = function vbZR()
{
	return true;
};

// Click sur une ligne de zone repetee
WDZRHorizontale.prototype.vTableZROnSelectLigne = function vTableZROnSelectLigne(nLigneAbsolueBase1/*, oEvent*/)
{
	try
	{
		// GP 30/04/2018 : TB103858 : Les actions externes ne doivent pas d�clencher l'entr�e en saisie
		var bDansOnSelectLigneExterneOld = this.m_bDansOnSelectLigneExterne;
		this.m_bDansOnSelectLigneExterne = true;

		this._vSetValeurChampFormulaire(nLigneAbsolueBase1);
	}
	finally
	{
		this.m_bDansOnSelectLigneExterne = bDansOnSelectLigneExterneOld;
	}
};

// Valide la ligne selectionnee et envoie la modification au serveur
WDZRHorizontale.prototype.vTableZROnValideLigne = clWDUtil.m_pfVide;

// Click sur une ligne
// GP 27/04/2021 : TB121794
WDZRHorizontale.prototype.OnSelectLigne = function OnSelectLigne(nLigneWL, nColonne, oEvent)
{
	this.vTableZROnSelectLigne(nLigneWL, oEvent);
};

//////////////////////////////////////////////////////////////////////////
// M�thodes surcharg�es

// Trouve les divers elements : liaison avec le HTML
WDZRHorizontale.prototype._vLiaisonHTML = function _vLiaisonHTML(/*sSuffixeFormulaire*//*, sSuffixeHote*/)
{
	// Appel de la methode de la classe de base
	WDChamp.prototype._vLiaisonHTML.apply(this, arguments);

	// Recupere les differents champs caches
	// Jamais utilis�
//	this.m_oChampDeb = this.oGetElementByName(document, "_DEB");
	this.m_oChampOcc = this.oGetElementByName(document, "_OCC");
	this.m_oChampPos = this.oGetElementByName(document, "_POSV");

	// Recupere la partie defilante de la ZR
	this.m_oDivPos = this.oGetIDElement("POS");
	this.m_oDivPosTable = this.m_oDivPos.getElementsByTagName("table")[0];
	this.m_oDivPosParent = this.m_oDivPos.parentNode;
	this.m_oDivScrollBar = this.oGetIDElement("SB");
};

// Initialisation du defilement
WDZRHorizontale.prototype._InitDefilement = function _InitDefilement()
{
	// Le gestionnaire de glissement du curseur de la barre de defilement
	this.m_oDragScrollBarCurseur = new WDDragScrollBarCurseur(this);
	// Le gestionnaire de glissement du curseur par le fond
	this.m_oDragScrollBarFond = new WDDragScrollBarFond(this);

	// Le gestionnaire de glissement du curseur par les boutons gauche et droite
	this.m_oDragScrollBarBtnGauche = new WDDragScrollBarBouton(this, "BG", false);
	this.m_oDragScrollBarBtnDroite = new WDDragScrollBarBouton(this, "BD", true);

	if (bTouch)
	{
		var oThis = this;
		new WDDragTouch(function(nOffsetX/*, nOffsetY, oEvent*/)
		{
			// "+" car nOffsetX a d�j� �t� "invers�"
			oThis.OnDeplace(oThis.m_nPosition + nOffsetX);
		}, this.m_oDivPos);
	}
};

// Positionne le champ en fonction de la valeur initiale du positionnement
WDZRHorizontale.prototype._InitDeplace = function _InitDeplace()
{
	// Recupere la valeur initiale
	var nPosition = parseInt(this.m_oChampPos.value, 10);
	// Filtre les valeurs invalides
	if (isNaN(nPosition) || (nPosition < 0))
	{
		nPosition = 0;
	}

	// Positionne le champ
	// Appele la methode interne commune qui reecrit dans m_oChampPos car on peut avoir modifie la valeur
	this._Deplace(nPosition);
};

// Positionne le champ en fonction d'une position et la memorise
WDZRHorizontale.prototype._Deplace = function _Deplace(nPosition)
{
	// Uniquement si la position change
	if (this.m_nPosition != nPosition)
	{
		// Memorise la nouvelle position
		this.m_nPosition = nPosition;
		this.m_oChampPos.value = nPosition;

		// Deplace les elements graphiques
		this._DeplaceElements();
	}
};

// Appel pour le d�filement
WDZRHorizontale.prototype.OnDeplace = function OnDeplace(nNouvellePosition)
{
	// Pas trop au debut
	if (nNouvellePosition < 0)
	{
		nNouvellePosition = 0;
	}

	var nLargeurTotale = this.nGetLargeurTotale();
	var nLargeurCliente = this.nGetLargeurCliente();

	// Pas trop a la fin
	// Si on a trop de place
	if (nLargeurTotale <= nLargeurCliente)
	{
		nNouvellePosition = 0;
	}
	else if (nNouvellePosition + nLargeurCliente > nLargeurTotale)
	{
		// Si on est trop loin
		nNouvellePosition = nLargeurTotale - nLargeurCliente;
	}

	// Fixe la nouvelle position
	this._Deplace(nNouvellePosition);
};

// - Tous les champs : notifie que une table ou ZRs a �t� MAJ en AJAX (= table/ZR non AJAX mais avec les ZR horizontales)
// Attention ne surcharge pas _vOnTableZRAfficheAJAXInterne mais _vOnTableZRAfficheAJAX pour etre avant le test de this.m_sAliasTableZRParent == sAliasTableZR
WDZRHorizontale.prototype._vOnTableZRAfficheAJAX = function _vOnTableZRAfficheAJAX(sAliasTableZR)
{
	// Appel de la methode de la classe de base (qui normalement ne fait rien)
	WDChamp.prototype._vOnTableZRAfficheAJAX.apply(this, arguments);

	// Si c'est nous meme
	if (this.m_sAliasChamp == sAliasTableZR)
	{
		// Reinit de la liaison HTML
		this._vLiaisonHTML();
		// Deplace les elements graphiques
		this._DeplaceElements();
	}
};

// Recupere les differentes largeurs
WDZRHorizontale.prototype.nGetLargeurTotale = function nGetLargeurTotale()
{
//	return this.m_oDivPos.offsetWidth;
//	return this.m_oDivPos.scrollWidth;
	return this.m_oDivPosTable.offsetWidth;
};
WDZRHorizontale.prototype.nGetLargeurCliente = function nGetLargeurCliente()
{
	return this.m_oDivPosParent.clientWidth;
};
WDZRHorizontale.prototype.nGetLargeurClienteSB = function nGetLargeurClienteSB()
{
	return this.m_oDivScrollBar.parentNode.clientWidth;
};

// Positionne les elements graphique du champ en fonction de la position courante
WDZRHorizontale.prototype._DeplaceElements = function _DeplaceElements()
{
	// Recupere la taille totale de la zone a defiler
	var nLargeurTotale = this.nGetLargeurTotale();
	var nLargeurCliente = this.nGetLargeurCliente();
	var nLargeurClienteSB = this.nGetLargeurClienteSB();

	// Valeur qui seront calculees
	// - Deplacement horizontal de la zone au pixel
	// - Position de l'ascenseur
	// - Largeur de l'ascenseur
	var nScrollLeft = this.m_nPosition;
	var nLeft = 0;
	var nWidth = 0;

	// Si on a trop de place
	if (nLargeurTotale <= nLargeurCliente)
	{
		// Positionne la zone au pixel au centre avec une valeur negative
		nScrollLeft = parseInt(-(nLargeurCliente - nLargeurTotale) / 2, 10);

		// Positionne la barre de defilement pour prendre toute la place
		nLeft = 0;
		nWidth = nLargeurClienteSB;
	}
	else
	{
		// Il y a un defilement

		// Positionne la zone au pixel mais pas trop loin
		// En revanche on ne corrige pas la position
		if ((nLargeurTotale - nScrollLeft) < nLargeurCliente)
		{
			nScrollLeft = nLargeurTotale - nLargeurCliente;
		}

		// Positionne la barre de defilement
		nWidth = parseInt(nLargeurCliente * nLargeurClienteSB / nLargeurTotale, 10);
		// Si on arrive a un ascenseur trop petit (34 = 2 * 17)
		if (nWidth < 34)
		{
			nLargeurClienteSB -= (34 - nWidth);
		}
		nLeft = parseInt(nScrollLeft * nLargeurClienteSB / nLargeurTotale, 10);
	}

	this.m_oDivPosParent.scrollLeft = nScrollLeft;
	this.m_oDivScrollBar.style.left = nLeft + "px";
	this.m_oDivScrollBar.style.width = nWidth + "px";

	// GP 25/01/2016 : QW267391 : Notifie que l'on a peut-�tre des images a chargement diff�r� qui sont maintenant affich�es.
	clWDUtil.m_oNotificationsImagesVisibles.LanceNotifications(this, this.m_oDivPosParent);
};

// Fonction appele en cas de redimensionnement de la fenetre
// Evenement sur le rechargement du champ
WDZRHorizontale.prototype._vOnResize = function _vOnResize(/*oEvent*/)
{
	// Appel de la classe de base
	WDChamp.prototype._vOnResize.apply(this, arguments);

	// Force le redessin de la barre
	this._DeplaceElements();
};

// Effectue un deplacement du contenu d'une quantite fixe
WDZRHorizontale.prototype.OnDefilement = function OnDefilement(bDroite, nPas)
{
	// Effectue le defilement
	var nPosition;
	if (bDroite)
	{
		nPosition = this.m_nPosition + nPas;
	}
	else
	{
		nPosition = this.m_nPosition - nPas;
	}

	// Limite le deplacement
	nPosition = Math.min(nPosition, this.nGetLargeurTotale() - this.nGetLargeurCliente());
	nPosition = Math.max(nPosition, 0);

	this._Deplace(nPosition);
};

// Le gestionnaire de glissement de la barre de defilement
function WDDragScrollBarBase (oObjetZRHorizontale, oElement)
{
	// Si on est pas dans l'init d'un protoype
	if (oObjetZRHorizontale)
	{
		// Appel le constructeur de la classe de base
		WDDrag.prototype.constructor.apply(this, [0, 50]);

		// Sauve l'objet attache
		this.m_oObjetZRHorizontale = oObjetZRHorizontale;

		// Intercepte le click sur la barre
		this._AttacheDetacheMouseDown(true, oElement, this.m_fMouseDown);
	}
};

// Declare l'heritage
WDDragScrollBarBase.prototype = new WDDrag();
// Surcharge le constructeur qui a ete efface
WDDragScrollBarBase.prototype.constructor = WDDragScrollBarBase;

// Appel lors du debut d'un click pour le deplacement
WDDragScrollBarBase.prototype._vbOnMouseDown = function _vbOnMouseDown(/*oEvent*/)
{
	// Appel de la classe de base : sauve la position de la souris et place les hooks
	if (!WDDrag.prototype._vbOnMouseDown.apply(this, arguments))
	{
		return false;
	}

	// Sauve la position originale
	this.m_nPosition = this.m_oObjetZRHorizontale.m_nPosition;

	return true;
};

// Appel lors du relachement de la souris
WDDragScrollBarBase.prototype._vOnMouseUp = function _vOnMouseUp(/*oEvent*/)
{
	// Vire la position originale
	this.m_nPosition = 0;

	// Appel de la classe de base
	WDDrag.prototype._vOnMouseUp.apply(this, arguments);
};

// Le gestionnaire de glissement du curseur de la barre de defilement
function WDDragScrollBarCurseur (oObjetZRHorizontale)
{
	// Si on est pas dans l'init d'un protoype
	if (oObjetZRHorizontale)
	{
		// Appel le constructeur de la classe de base
		WDDragScrollBarBase.prototype.constructor.apply(this, [oObjetZRHorizontale, oObjetZRHorizontale.m_oDivScrollBar]);
	}
};

// Declare l'heritage
WDDragScrollBarCurseur.prototype = new WDDragScrollBarBase();
// Surcharge le constructeur qui a ete efface
WDDragScrollBarCurseur.prototype.constructor = WDDragScrollBarCurseur;

// Appel lors du deplacement de la souris
WDDragScrollBarCurseur.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
{
	// Appel de la classe de base
	WDDragScrollBarBase.prototype._vOnMouseMove.apply(this, arguments);

	// Recupere la taille totale de la zone a defiler
	var nLargeurTotale = this.m_oObjetZRHorizontale.nGetLargeurTotale();
	var nLargeurClienteSB = this.m_oObjetZRHorizontale.nGetLargeurClienteSB();

	// Calcule la nouvelle position
	// ATTENTION : Si on est en affichage de droite a gauche il faut inverser le deplacement de la souris car
	// les coordonnees X sont toujours de gauche a droite
	var nOffset = this.nGetOffsetPosX(oEvent);
	// Modifie en fonction de la largueur relative de la zone de defilement
	nOffset = parseInt(nOffset * nLargeurTotale / nLargeurClienteSB, 10);

	// Fixe la nouvelle position
	this.m_oObjetZRHorizontale.OnDeplace(nOffset + this.m_nPosition);
};

// Le gestionnaire de glissement du curseur par le fond
function WDDragScrollBarFond (oObjetZRHorizontale)
{
	// Si on est pas dans l'init d'un protoype
	if (oObjetZRHorizontale)
	{
		// Appel le constructeur de la classe de base
		WDDragScrollBarBase.prototype.constructor.apply(this, [oObjetZRHorizontale, oObjetZRHorizontale.m_oDivScrollBar.parentNode]);

		this.m_oDivScrollBar = oObjetZRHorizontale.m_oDivScrollBar;
	}
};

// Declare l'heritage
WDDragScrollBarFond.prototype = new WDDragScrollBarBase();
// Surcharge le constructeur qui a ete efface
WDDragScrollBarFond.prototype.constructor = WDDragScrollBarFond;

// Appel lors du debut d'un click pour le deplacement
WDDragScrollBarFond.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent)
{
	// Appel de la classe de base : sauve la position de la souris et place les hooks
	if (!WDDragScrollBarBase.prototype._vbOnMouseDown.apply(this, arguments))
	{
		return false;
	}

	// Normalement il n'y a plus de timer mais on le supprime au besoin
	this._AnnuleTimer(oEvent);

	// Effectue un premier deplacement
	// En memorisant la position de clic car on n'aura pas l'evenement dans le timer
	this.m_nClientX = this._nGetPosXEvent(oEvent);
	this.__OnDefilement();

	// Lance le timer du deplacement, la repetition est 'lente' (300-500ms)
	// Normalement le comportement est : une repetition 'lente' puis des repetitions 'rapides' (50-100ms)
	var oThis = this;
	this.m_oObjetZRHorizontale.SetInterval("OnDefilementFondSB", function() { oThis.__OnDefilement(); }, 300);

	return true;
};

// Appel lors du deplacement de la souris
WDDragScrollBarFond.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
{
	// Appel de la classe de base
	WDDragScrollBarBase.prototype._vOnMouseMove.apply(this, arguments);

	this.m_nClientX = this._nGetPosXEvent(oEvent);
};

// Appel lors du relachement de la souris
WDDragScrollBarFond.prototype._vOnMouseUp = function _vOnMouseUp(oEvent)
{
	// Annule le timer
	this._AnnuleTimer(oEvent);

	// Appel de la classe de base
	WDDragScrollBarBase.prototype._vOnMouseUp.apply(this, arguments);
};

// Annule le timer
WDDragScrollBarFond.prototype._AnnuleTimer = function _AnnuleTimer(/*oEvent*/)
{
	// Normalement il y a un timer mais on le supprime uniquement s'il existe
	this.m_oObjetZRHorizontale.AnnuleTimeXXX("OnDefilementFondSB", true);
};

// Effectue un deplacement du contenu par appuis continu sur le fond de l'ascenseur
WDDragScrollBarFond.prototype.__OnDefilement = function __OnDefilement()
{
	// Verifie que le clic n'est pas sur l'ascenseur et en profite pour calculer si on est a droite ou a gauche
	var bDroite;
	// GP 16/07/2012 : Utilisation de getBoundingClientRect() : plus rapide et fonctionne correctement en HTML5
	var nClientXLocal = this.m_nClientX - this.m_oDivScrollBar.getBoundingClientRect().left;
	if (nClientXLocal < 0)
	{
		bDroite = false;
	}
	else if (nClientXLocal > this.m_oDivScrollBar.offsetWidth)
	{
		bDroite = true;
	}
	else
	{
		return;
	}

	// Calcule le pas : 90% de l'ecran
	var nPas = Math.ceil(this.m_oObjetZRHorizontale.nGetLargeurCliente() * 0.9);

	// Effectue le defilement avec le pas courant
	this.m_oObjetZRHorizontale.OnDefilement(bDroite, nPas);
};

// Le gestionnaire de glissement du curseur par les boutons gauche et droite
function WDDragScrollBarBouton(oObjetZRHorizontale, sSuffixe, bDroite)
{
	// Si on est pas dans l'init d'un protoype
	if (oObjetZRHorizontale)
	{
		// Appel le constructeur de la classe de base
		WDDragScrollBarBase.prototype.constructor.apply(this, [oObjetZRHorizontale, oObjetZRHorizontale.oGetIDElement(sSuffixe)]);

		this.m_bDroite = bDroite;
	}
};

// Declare l'heritage
WDDragScrollBarBouton.prototype = new WDDragScrollBarBase();
// Surcharge le constructeur qui a ete efface
WDDragScrollBarBouton.prototype.constructor = WDDragScrollBarBouton;

// Pas de l'augmentation de la vitesse de defilement
WDDragScrollBarBouton.prototype.ms_nPasDefilement = 8;


// Appel lors du debut d'un click pour le deplacement
WDDragScrollBarBouton.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent)
{
	// Appel de la classe de base : sauve la position de la souris et place les hooks
	if (!WDDragScrollBarBase.prototype._vbOnMouseDown.apply(this, arguments))
	{
		return false;
	}

	// Normalement il n'y a plus de timer mais on le supprime au besoin
	this._AnnuleTimer(oEvent, false);

	// Effectue un premier deplacement
	this.m_nDefilementV = this.ms_nPasDefilement;
	this.__OnDefilement();

	// Lance le timer du deplacement
	var oThis = this;
	this.m_oObjetZRHorizontale.SetInterval("OnDefilementBouton", function() { oThis.__OnDefilement(); }, 50);

	return true;
};

// Appel lors du relachement de la souris
WDDragScrollBarBouton.prototype._vOnMouseUp = function _vOnMouseUp(oEvent)
{
	// Annule le timer
	this._AnnuleTimer(oEvent, true);

	// Appel de la classe de base
	WDDragScrollBarBase.prototype._vOnMouseUp.apply(this, arguments);
};

// Annule le timer
WDDragScrollBarBouton.prototype._AnnuleTimer = function _AnnuleTimer(oEvent, bDepuisUp)
{
	// Probleme avec IE, sur une serie de clic rapide on recoit Down, Up, Up et pas Down, Up, Down, Up
	// Donc si on recoit un Up seul, on force un defilement
	if (bIE && bDepuisUp && !this.m_oObjetZRHorizontale.bGetTimeXXXExiste("OnDefilementBouton"))
	{
		// Effectue un premier deplacement
		this.m_nDefilementV = this.ms_nPasDefilement;
		this.__OnDefilement();
	}
	// Normalement il y a un timer mais on le supprime uniquement s'il existe
	this.m_oObjetZRHorizontale.AnnuleTimeXXX("OnDefilementBouton", true);
};

// Effectue un deplacement du contenu par appuis continu sur le bouton
WDDragScrollBarBouton.prototype.__OnDefilement = function __OnDefilement()
{
	// Effectue le defilement avec le pas courant
	this.m_oObjetZRHorizontale.OnDefilement(this.m_bDroite, this.m_nDefilementV);

	// Augmente la vitesse de defilement
	if (this.m_nDefilementV <= this.ms_nPasDefilement * 10)
	{
		this.m_nDefilementV += this.ms_nPasDefilement;
	}
};
