// WDZRNavigateur.js
/*! 27.0.3.0 */
/*! VersionVI: yyyyyyyyyyyy */

// Attention a ne pas mettre d'accent dans le code, chaines incluses

///#DEBUG=clWDUtil.WDDebug

// D�finition des globales d�finies dans :
// - WDTableZRCommun.js
///#GLOBALS WDAttribut WDLigne WDRupture WDSelection WDTableZRNavigateur WDZRClassique

// Code sp�cifique aux zones r�p�t�es navigateur

//////////////////////////////////////////////////////////////////////////
// WDZRRupture
// => Rupture de zone r�p�t�e navigateur
// H�rite de WDRupture
// => Rien de sp�cifique par rapport � WDRupture
var WDZRRupture = WDRupture;

//////////////////////////////////////////////////////////////////////////
// WDZRAttribut
// => Attribut de zone r�p�t�e navigateur
// H�rite de WDAttribut
var WDZRAttribut = WDAttribut;

//////////////////////////////////////////////////////////////////////////
// WDZRLigne
// => Ligne de zone r�p�t�e navigateur
// H�rite de WDLigne
// => Rien de sp�cifique par rapport � WDLigne
var WDZRLigne = WDLigne;

//////////////////////////////////////////////////////////////////////////
// WDZRNavigateur
// => Zone r�p�t�e
// H�rite de WDTableZRNavigateur

// Manipulation d'une zone repetee galerie
// La table n'a normalement jamais de table/zr parente
function WDZRNavigateur(sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, tabParametresSupplementaires)
{
	// Si on est pas dans l'init d'un protoype
	if (arguments.length)
	{
		// Appel le constructeur de la classe de base
		// Format de tabParametresSupplementaires attendu par WDTableZRNavigateur : [ eTypeSelection ]
		WDTableZRNavigateur.prototype.constructor.apply(this, [sAliasChamp, sAliasTableZRParent, sAliasAttribut, pfConstructeursSupplementaires, [tabParametresSupplementaires[0], tabParametresSupplementaires[1], WDSelection.prototype.ms_nSelectionSimple]]);

		// Format de tabParametresSupplementaires : [ oParametres, oDonnees, tabCouleurFond, nNbLignesLogiquesParLignePhysique ]
		var tabCouleurFond = tabParametresSupplementaires[2];
		var nNbLignesLogiquesParLignePhysique = tabParametresSupplementaires[3];
		var tabStylesBruts = tabParametresSupplementaires[4];

		// Couleurs de fond des lignes altern�e
		this.m_tabCouleurFond = tabCouleurFond;
		// Nombre de colonnes de la ZR
		this.m_nNbLignesLogiquesParLignePhysique = nNbLignesLogiquesParLignePhysique;
		// On pr�pare les styles sous forme d'un tableau de cha�nes.
		this.m_tabStyles = WDZRClassique.prototype.s_tabGetStyles(tabStylesBruts);
	}
};

// Declare l'heritage
WDZRNavigateur.prototype = new WDTableZRNavigateur();
// Surcharge le constructeur qui a ete efface
WDZRNavigateur.prototype.constructor = WDZRNavigateur;

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		M�thodes surcharg�es : WDChamp

//// Initialisation :
//WDZRNavigateur.prototype.Init = function Init()
//{
//	// Appel de la methode de la classe de base
//	WDTableZRNavigateur.prototype.Init.apply(this, arguments);
//};

// Indique que le champ est une ZR
WDZRNavigateur.prototype.vbZR = function vbZR()
{
	return true;
};

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		M�thodes surcharg�es : WDTableZRNavigateur

// Cr�� un nouvel objet colonne/attribut (qui d�rive donc de WDColonne)
WDZRNavigateur.prototype._vNewColonne = WDZRAttribut;
// Cr�� un nouvel objet attribut automatique (qui d�rive donc de WDAttribut)
WDZRNavigateur.prototype._vNewAttributAutomatique = WDZRAttribut;
// Cr�� un nouvel objet colonne/attribut (qui d�rive donc de WDRupture)
WDZRNavigateur.prototype._vNewRupture = WDZRRupture;
// Cr�e un nouvel objet ligne
WDZRNavigateur.prototype._vLigne = WDZRLigne;

// G�n�re une ligne du HTML
WDZRNavigateur.prototype._vHTMLGenereLigne = function _vHTMLGenereLigne(nLigne, nLigneAffiche, oLigne, tabHTML)
{
	// G�n�re directement this.m_oElementsHTML (qui est un tableau du HTML de chaque ligne dans le cas d'une ZR navigateur)
	this.__HTMLGenere(nLigne, nLigneAffiche, oLigne, this.m_oElementsHTML, tabHTML);
};

WDZRNavigateur.prototype._vOnChangementSelectionSansRedessin = function _vOnChangementSelectionSansRedessin(nLigneBase0)
{
	WDZRClassique.prototype.s_SetStyleSelonSelection(this, this.m_tabStyles, nLigneBase0 + 1, this.m_oSelection.bGetLigneEstSelectionnee(nLigneBase0));
};

// Appel un PCode en forcant la ligne courante de l'�l�ment
WDZRNavigateur.prototype._voAppelPCodeSurLigne = function _voAppelPCodeSurLigne(nLigne, fPCode, oEvent)
{
	try
	{
		// Fait comme si on etait dans une ZR (on est une ZR)
		this.m_sAliasTableZRParent = this.m_sAliasChamp;
		// Appel la methode sur la ligne
		return this.oAppelSurLigneTableZR(this._nLigneLigneWL(nLigne), fPCode, [oEvent]);
	}
	finally
	{
		this.m_sAliasTableZRParent = null;
	}
};

// Retourne une propri�t� (pour le parsing du HTML)
WDZRNavigateur.prototype._vsLitPropriete = function _vsLitPropriete(nLigne, nLigneAffiche, oLigne, ePropriete, oParametre, bPourCondition)
{
	switch (ePropriete)
	{
	case this.XML_CHAMP_PROP_NUM_COULEURFOND:
		// GP 04/10/2013 : Aussi trait� dans la classe de base mais diff�rement
		// Si la ligne a une couleur de fond (non disponible en WL navigateur actuellement)
		if (oLigne.m_sCouleurFond !== undefined)
		{
			return oLigne.m_sCouleurFond;
		}
		var sCouleur;
		if (this.m_tabCouleurFond && this.m_tabCouleurFond.length)
		{
			// GP 17/10/2013 : On compte en ligne affich�e : nLigneAffiche
			// Notre premier indice est zero, mais c'est la premiere ligne qui ets impaire et le tableau est [impair, pair]
			// Donc +1 -1 => 0
			sCouleur = this.m_tabCouleurFond[nLigneAffiche % this.m_tabCouleurFond.length];
		}
		if ((sCouleur === undefined) && !bPourCondition)
		{
			sCouleur = "transparent";
		}
		return sCouleur;
	default:
		// Appel de la methode de la classe de base
		return WDTableZRNavigateur.prototype._vsLitPropriete.apply(this, arguments);
	}
};

// Parse le HTML re�u de la g�n�ration HTML
WDZRNavigateur.prototype._voHTMLParse = WDTableZRNavigateur.prototype.__tabHTMLParse;

// Indique si on a une couleur de fond pour la s�lection de la ligne
// => C'est selon dans les ZRs. On devrait �tre plus pr�cis mais il faudrait avoir les couleurs de fond des styles.
WDZRNavigateur.prototype.__bAvecSelection = function ()
{
	var oStyleLigneSelectionne = this.m_oStyleLigneSelectionne;
	return oStyleLigneSelectionne && 0 < Object.keys(oStyleLigneSelectionne).length;
};
WDZRNavigateur.prototype._vbAvecCouleurDeFondSelection = WDZRNavigateur.prototype.__bAvecSelection;

//////////////////////////////////////////////////////////////////////////
// Classes de base des tables/zone r�p�t�es navigateur
//	WDTableZRNavigateur
//		Calculs pour l'affichage

// CodeHTML32 : Colspan a utiliser pour la cellule des ruptures dans une table
WDZRNavigateur.prototype._vnGetColSpanRupture = function _vnGetColSpanRupture()
{
	// GP 17/11/2014 : QW251791 : Plutot que de faire supprimer la valeur dynamique dans la g�n�ration HTML, on g�re le cas en JS. Cela servira peut-�tre un jour
	return this.m_nNbLignesLogiquesParLignePhysique;
};

WDZRNavigateur.prototype._xvoGetInfoXY = WDZRClassique.prototype._xvoGetInfoXY;
