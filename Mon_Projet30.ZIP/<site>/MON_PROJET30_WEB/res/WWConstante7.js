// WWConstante7.js
/*! 26.0.2.0 */
/*! VersionVI: yyyyyyyyyyyy */
// Le seul support technique disponible pour cette librairie est accessible a travers le service "Assistance Directe".
STD_LUNDI = "Lunes";
STD_MARDI = "Martes";
STD_MERCREDI = "Mi\u00e9rcoles";
STD_JEUDI = "Jueves";
STD_VENDREDI = "Viernes";
STD_SAMEDI = "S\u00e1bado";
STD_DIMANCHE = "Domingo";
STD_JANVIER = "Enero";
STD_FEVRIER = "Febrero";
STD_MARS = "Marzo";
STD_AVRIL = "Abril";
STD_MAI = "Mayo";
STD_JUIN = "Junio";
STD_JUILLET = "Julio";
STD_AOUT = "Agosto";
STD_SEPTEMBRE = "Septiembre";
STD_OCTOBRE = "Octubre";
STD_NOVEMBRE = "Noviembre";
STD_DECEMBRE = "Diciembre";
TABLE_EXPORT = {
	"EXCEL":
	{
		"sLibelle":"Exportar a Excel...",
		"sTitre":"Exportar el contenido a Excel..."
	},
	"WORD":
	{
		"sLibelle":"Exportar a Word...",
		"sTitre":"Exportar el contenido a Word..."
	},
	"XML":
	{
		"sLibelle":"Exportar a XML...",
		"sTitre":"Exportar el contenido a XML..."
	},
	"PDF":
	{
		"sLibelle":"Imprimir en PDF...",
		"sTitre":"Imprimir en un archivo PDF..."
	}
};
TABLE_FILTRE = {
	"RECHERCHE":
	{
		"sLibelle":"Buscar"
	},
	"FILTRE":
	{
		"sLibelle":"Filtros:"
	},
	"FILTRE_EGAL":
	{
		"sLibelle":"Es igual a"
	},
	"FILTRE_COMMENCE":
	{
		"sLibelle":"Comienza por"
	},
	"FILTRE_CONTIENT":
	{
		"sLibelle":"Contiene"
	},
	"FILTRE_TERMINE":
	{
		"sLibelle":"Termina por"
	},
	"FILTRE_DIFFERENT":
	{
		"sLibelle":"Es diferente de"
	},
	"FILTRE_COMMENCE_PAS":
	{
		"sLibelle":"No comienza por"
	},
	"FILTRE_CONTIENT_PAS":
	{
		"sLibelle":"No contiene"
	},
	"FILTRE_TERMINE_PAS":
	{
		"sLibelle":"No termina por"
	},
	"FILTRE_SUPERIEUR":
	{
		"sLibelle":"Mayor que"
	},
	"FILTRE_SUPERIEUR_EGAL":
	{
		"sLibelle":"Mayor que o igual a"
	},
	"FILTRE_INFERIEUR":
	{
		"sLibelle":"Menor que"
	},
	"FILTRE_INFERIEUR_EGAL":
	{
		"sLibelle":"Menor que o igual a"
	},
	"FILTRE_SUPPRIME":
	{
		"sLibelle":"Eliminar filtro"
	}
};
TDB_MENU = {
	"EDITION":
	{
		"sLibelle":"Edici\u00f3n"
	},
	"CONFINIT":
	{
		"sLibelle":"Restaurar configuraci\u00f3n inicial"
	}
};
STD_TITRE_TRACE = "Traza de c\u00f3digos navegador de WEBDEV";
STD_INFO_TRACE = "Utilizar Ctrl+P para imprimir la ventana de traza";
STD_ERREUR_MESSAGE_UPLOAD = "Error al cargar.\nSe produjo un error inesperado al subir uno de los archivos.\nAseg\u00farese de que los archivos que desea subir no sean demasiado grandes.";
CHART_TOOLBAR = {
	"ALTTEXT":
	{
		"PIE":"Gr\u00e1ficos circulares...",
		"COL":"Gr\u00e1ficos de barras...",
		"CUR":"Gr\u00e1ficos de l\u00edneas...",
		"STO":"Gr\u00e1ficos de cotizaciones...",
		"SAV":"Guardar como...",
		"PRI":"Imprimir...",
		"LEG":"Leyenda",
		"GDH":"L\u00edneas de cuadr\u00edcula horizontales ",
		"GDV":"L\u00edneas de cuadr\u00edcula verticales",
		"SMO":"Suavizar",
		"GRA":"Degradado",
		"RAI":"Relieve",
		"ANT":"Antialiasing",
		"TRA":"Transparencia",
		"MIR":"Mira",
		"ANI":"Animaci\u00f3n",
		"INT":"Interactividad",
		"ZOH":"Zoom horizontal",
		"ZOV":"Zoom vertical",
		"FUS":"Pantalla completa"
	},
	"LEG":
	{
		"0":"Ninguna",
		"1":"Derecha",
		"2":"Izquierda",
		"3":"Arriba",
		"4":"Abajo"
	},
	"PIE":
	{
		"0":"Circular",
		"1":"Semic\u00edrculo",
		"2":"Anillo",
		"3":"Embudo",
		"4":"Proyecci\u00f3n solar"
	},
	"COL":
	{
		"0":"Gr\u00e1fico de barras agrupadas",
		"1":"Gr\u00e1fico de barras apiladas",
		"2":"Gr\u00e1fico de barras agrupadas horizontales",
		"3":"Gr\u00e1fico de barras apiladas verticales",
		"4":"Cascada"
	},
	"CUR":
	{
		"0":"L\u00ednea",
		"1":"Dispersi\u00f3n",
		"2":"\u00c1rea",
		"3":"Radial",
		"4":"Burbujas",
		"5":"Mapa de calor"
	},
	"STO":
	{
		"0":"Velas japonesas",
		"1":"BarCharts",
		"2":"M\u00ednimo M\u00e1ximo"
	},
	"MIR":
	{
		"0":"Mira m\u00faltiple",
		"1":"Mira",
		"2":"Tooltip"
	},
	"PARAMS":"Par\u00e1metros"
};
HTML_TOOLBAR = {
	"DLG":
	{
		"IMG":"Introducir direcci\u00f3n de la imagen",
		"IMGURL":"\u00bfDesea insertar una imagen desde la URL?\nCancelar para abrir el editor de im\u00e1genes.",
		"LNK":"Introducir direcci\u00f3n del enlace",
		"MRG":"Introducir valor del margen",
		"ALT":"Introducir texto alternativo de la imagen",
		"CPY":"Se integrar\u00e1 una copia de la imagen al texto para aplicar esta acci\u00f3n",
		"ERR":"No se puede realizar esta acci\u00f3n.\nEl servidor que aloja la imagen no permite copias locales (CORS)",
		"DBL":"Haga doble clic para introducir el valor del margen"
	},
	"ALTTEXT":
	{
		"GRA":"Negrita",
		"ITA":"Cursiva",
		"SOU":"Subrayado",
		"BAR":"Tachado",
		"AGA":"Alinear a la izquierda",
		"ACE":"Centrar",
		"ADR":"Alinear a la derecha",
		"AJU":"Justificar",
		"LNU":"Numeraci\u00f3n",
		"LPU":"Vi\u00f1etas",
		"RMO":"Disminuir sangr\u00eda",
		"RPL":"Aumentar sangr\u00eda",
		"EXP":"Super\u00edndice",
		"IND":"\u00cdndice",
		"COL":"Color",
		"LNK":"Insertar un enlace",
		"IMG":"Insertar una imagen",
		"FNA":"Fuente",
		"FSI":"Tama\u00f1o fuente",
		"EMO":"Emotic\u00f3n",
		"UND":"Cancelar",
		"RED":"Rehacer"
	},
	"COSP":
	{
		"0":"Inicial"
	},
	"COFP":
	{
		"0":"General",
		"1":"T\u00edtulo",
		"2":"Subt\u00edtulo",
		"3":"Nota \/ Advertencia"
	},
	"COLP":
	{
		"0":"General",
		"1":"T\u00edtulo",
		"2":"Subt\u00edtulo",
		"3":"Enlace (1)",
		"4":"Enlace (2)",
		"5":"Nota \/ Advertencia"
	},
	"FHE":
	{
		"0":"Cuerpo de texto",
		"1":"T\u00edtulo 1",
		"2":"T\u00edtulo 2",
		"3":"T\u00edtulo 3",
		"4":"T\u00edtulo 4",
		"5":"T\u00edtulo 5",
		"6":"T\u00edtulo 6",
		"7":"Preformateado",
		"8":"Resaltado"
	},
	"FSI":
	{
		"0":"Peque\u00f1o",
		"1":"Normal",
		"2":"Ligeramente grande",
		"3":"Grande",
		"4":"M\u00e1s grande",
		"5":"Muy grande",
		"6":"Enorme"
	},
	"HAB":
	{
		"0":"En l\u00ednea con el texto",
		"1":"A la izquierda",
		"2":"A la derecha",
		"3":"P\u00e1rrafo centrado",
		"4":"P\u00e1rrafo expandido",
		"5":"Modificar imagen",
		"6":"Recortar (integra una copia de la imagen al texto)",
		"7":"Girar a la derecha (integra una copia de la imagen al texto)",
		"8":"Texto alternativo"
	},
	"LNK":
	{
		"0":"Abrir en una nueva pesta\u00f1a",
		"1":"Modificar enlace",
		"2":"Eliminar enlace"
	},
	"EMO":
	{
		"0":"Frecuentes",
		"1":"Personas",
		"2":"Naturaleza",
		"3":"Objetos",
		"4":"Lugares",
		"5":"S\u00edmbolos"
	},
	"TABLE":
	{
		"ROW":
		{
			"BEFORE":"Insertar fila encima",
			"AFTER":"Insertar fila debajo",
			"DELETE":"Eliminar fila"
		},
		"COLUMN":
		{
			"BEFORE":"Insertar columna a la izquierda",
			"AFTER":"Insertar columna a la derecha",
			"DELETE":"Eliminar columna"
		},
		"CELL":
		{
			"PROP":"Propiedades de la celda"
		},
		"PROP":"Propiedades de la tabla"
	}
};
tabWDErrors = {
	"0":"Error desconocido.",
	"1":"Error en el c\u00f3digo navegador:\n",
	"200":"\u00cdndice de valor incorrecto: se intenta acceder al \u00edndice %1, pero solo hay %2 valor(es).",
	"201":"No se encontr\u00f3 el elemento en el array asociativo.",
	"202":"Esta clave hace referencia a %1 elemento(s) en el array asociativo y se intent\u00f3 acceder al elemento %2.",
	"203":"La lectura de un elemento de un array asociativo con duplicados no est\u00e1 permitida con esta sintaxis: puede que una misma clave haga referencia a varios elementos.",
	"204":"Formato no v\u00e1lido.",
	"205":"Las funciones ArrayToString() y ArrayToCSV() solo se pueden utilizar en un array unidimensional o bidimensional.",
	"206":"Las funciones ArrayToString() y ArrayToCSV() no se pueden utilizar en un array de estructuras, si la estructura misma contiene un array o una estructura.",
	"207":"Una adici\u00f3n ordenada solo se puede hacer en un array previamente ordenado por una llamada al m\u00e9todo Sort() o al m\u00e9todo ArraySort().",
	"208":"El array tiene %1 dimensi\u00f3n(es) y ha intentado acceder a \u00e9l con %2 dimensi\u00f3n(es).",
	"209":"Las dimensiones de un array deben ser positivas.",
	"210":"Dimensi\u00f3n de no permite modificar el n\u00famero de dimensiones del array.",
	"211":"La funci\u00f3n %1()\/%2() solo puede utilizarse en un array unidimensional.",
	"212":"La funci\u00f3n %1()\/%2() solo puede utilizarse en un array unidimensional o bidimensional.",
	"213":"La funci\u00f3n %1()\/%2() solo puede utilizarse en un array bidimensional.",
	"214":"El orden no est\u00e1 disponible con objetos nativos Javascript transmitidos a un procedimiento WLanguage.",
	"215":"No se ha creado el array din\u00e1mico.",
	"216":"Divisi\u00f3n por 0",
	"217":"Indique el tipo de b\u00fasqueda (constantes asBinary, asLinear, etc.).",
	"218":"Factorial de un n\u00famero negativo.",
	"219":"El mes debe ser un valor comprendido entre 1 y 12.",
	"220":"No se ha iniciado el cron\u00f3metro %1.",
	"300":"\u00cdndice %1 no v\u00e1lido. El control est\u00e1 vac\u00edo.",
	"301":"\u00cdndice %1 no v\u00e1lido. Los valores deben estar entre %2 y %3.",
	"302":"Columna <%1> desconocida.",
	"303":"El valor de la constante (%1) no es v\u00e1lido con esta funci\u00f3n.",
	"400":"La solicitud <%1> no existe.",
	"401":"No hay conexiones.",
	"500":"Error al enviar la solicitud:\n%1",
	"600":"A una estructura solo se puede asignar otra estructura de la misma definici\u00f3n.",
	"601":"Tipo incompatible.",
	"602":"Operador '%1' no permitido.",
	"603":"La propiedad no existe.",
	"604":"El par\u00e1metro n\u00b0%1 no tiene un valor predeterminado y no ha recibido ning\u00fan valor.",
	"605":"El elemento '%1' no existe.",
	"606":"No hay ning\u00fan elemento.",
	"607":"Formato JSON no v\u00e1lido.",
	"608":"La serializaci\u00f3n JSON solo se puede hacer a una variable de tipo cadena.",
	"609":"La deserializaci\u00f3n JSON solo se puede hacer a una variable compleja.",
	"610":"No se puede manipular el control (alias: '%1')  porque no se encuentra en el HTML de la p\u00e1gina.\nEste control se encuentra (directa o indirectamente) en un plano con carga diferida que a\u00fan no se muestra (y no se ha cargado).",
	"611":"No se puede manipular el control (alias: '%1') porque no se encuentra en el HTML de la p\u00e1gina.\nEste control (o uno de sus padres) es invisible y la opci\u00f3n 'Generar c\u00f3digo HTML del control, incluso si es invisible' no ha sido activada.",
	"612":"\u00cdndice de par\u00e1metro incorrecto: se intent\u00f3 acceder al par\u00e1metro %1, pero solo hay %2 par\u00e1metros.",
	"613":"Los par\u00e1metros de llamada son incorrectos: se esperaban %1 par\u00e1metros solo se pasaron %2.",
	"614":"Los par\u00e1metros de llamada son incorrectos: se esperaban entre %1 y %2 par\u00e1metros, pero solo se pasaron %3.",
	"615":"A\u00fan no se ha creado el objeto din\u00e1mico.",
	"616":"El elemento '%1' no existe.\nSolo se puede utilizar una sintaxis objeto (por ejemplo, \"ControlList.Add\") en un control manipulado por su nombre, en un par\u00e1metro tipado o en una variable.",
	"617":"Control '%1' requerido",
	"618":"No se puede asignar un objeto de la clase '%1' a un objeto de la clase '%2'.",
	"619":"El variant no es un objeto.",
	"700":"Los l\u00edmites est\u00e1n invertidos: el l\u00edmite superior (%2) es inferior al l\u00edmite inferior (%1).",
	"800":"Los sockets no est\u00e1n disponibles.",
	"801":"Ha llamado a la funci\u00f3n SocketConnect solicitando que el nombre del socket sea %1.\nSin embargo, ya existe un socket con este nombre.",
	"802":"Ha llamado a la funci\u00f3n SocketWrite.\nNo existe ning\u00fan socket con el nombre %1.",
	"803":"Ha llamado a la funci\u00f3n SocketClose.\nNo existe ning\u00fan socket con el nombre %1.",
	"804":"Ha llamado a la funci\u00f3n SocketWrite.\nEl socket %1 a\u00fan no est\u00e1 conectado.",
	"805":"Ha llamado a la funci\u00f3n SocketWrite.\nEl socket %1 est\u00e1 cerrado.",
	"900":"Se produjo un error al pasar el par\u00e1metro %1.\nCuando se pasa un par\u00e1metro por direcci\u00f3n, un elemento de tipo '%2' no puede convertirse al tipo '%3'. Utilice un par\u00e1metro local en el procedimiento llamado o pase un par\u00e1metro de tipo '%3'.",
	"901":"El nombre\/valor '%1' no existe en la enumeraci\u00f3n\/combinaci\u00f3n o ha sido eliminado o renombrado.",
	"902":"El valor '%1' de la enumeraci\u00f3n no tiene valor asociado.",
	"903":"Un elemento de tipo '%2' no puede convertirse en un elemento de tipo '%1'.",
	"1000":"El valor de la propiedad ..TokenCurrentInput no debe contener separadores token.",
	"1001":"No hay ninguna entrada en curso en el control (alias:'%1').",
	"1100":"El variant ya contiene un miembro '%1'.",
	"1101":"La funci\u00f3n hash requerida no est\u00e1 disponible en este navegador.",
	"1200":"Matriz no v\u00e1lida",
	"1201":"\u00cdndice <%1!d!> no v\u00e1lido: Los \u00edndices de filas y columnas comienzan en 1.",
	"1202":"Las unidades <%1!s!> y <%2!s!> no son del mismo tipo.\nNo se puede realizar la conversi\u00f3n.",
	"1203":"Error interno: no se encontraron uno o m\u00e1s coeficientes de conversi\u00f3n necesarios para convertir <%1!s!> a <%2!s!>.",
	"1204":"Unidad desconocida: <%1>.",
	"1205":"Se ha intentado acceder a una posici\u00f3n fuera de la matriz",
	"1206":"Las dimensiones de las matrices no son compatibles",
	"1207":"Los \u00edndices pasados como par\u00e1metros no son v\u00e1lidos.",
	"1208":"Matriz singular: no se puede realizar el c\u00e1lculo.",
	"1209":"Determinante nulo: no se puede calcular la inversa de la matriz.",
	"1210":"La cadena de formato es incorrecta",
	"1300":"Se produjo un error al obtener la zona geogr\u00e1fica."
};
GRF = {
	"BULLE":
	{
		"BOURSIER":"[%CATEGORIE%]\nM\u00edn=[%MIN%]\nM\u00e1x=[%MAX%]\nInicio=[%DEBUT%]\nFin=[%FIN%]"
	}
};
WDSTD_CONST = {
	"FORMAT_TAILLE_OCTET":"byte",
	"FORMAT_TAILLE_KO":"KB",
	"FORMAT_TAILLE_MO":"MB",
	"FORMAT_TAILLE_GO":"GB",
	"FORMAT_TAILLE_TO":"TB",
	"CONTINENT":
	{
		"AFRIQUE":"\u00c1frica",
		"AMERIQUE_DU_NORD":"Norteam\u00e9rica",
		"AMERIQUE_DU_SUD":"Sudam\u00e9rica",
		"ANTARCTIQUE":"Ant\u00e1rtida",
		"ASIE":"Asia",
		"EUROPE":"Europa",
		"OCEANIE":"Ocean\u00eda"
	},
	"PAYS":
	{
		"AFGHANISTAN":"Afganist\u00e1n",
		"AFRIQUE_DU_SUD":"Sud\u00e1frica",
		"ALAND_ILES":"Aland (Islas)",
		"ALBANIE":"Albania",
		"ALGERIE":"Argelia",
		"ALLEMAGNE":"Alemania",
		"ANDORRE":"Andorra",
		"ANGOLA":"Angola",
		"ANGUILLA":"Anguila",
		"ANTARCTIQUE":"Ant\u00e1rtida",
		"ANTIGUA_ET_BARBUDA":"Antigua y Barbuda",
		"ARABIE_SAOUDITE":"Arabia Saudita",
		"ARGENTINE":"Argentina",
		"ARMENIE":"Armenia",
		"ARUBA":"Aruba",
		"AUSTRALIE":"Australia",
		"AUTRICHE":"Austria",
		"AZERBAIDJAN":"Azerbaiy\u00e1n",
		"BAHAMAS":"Bahamas",
		"BAHREIN":"Bahr\u00e9in",
		"BANGLADESH":"Bangladesh",
		"BARBADE":"Barbados",
		"BELARUS":"Bielorrusia",
		"BELGIQUE":"B\u00e9lgica",
		"BELIZE":"Belice",
		"BENIN":"Ben\u00edn",
		"BERMUDES":"Bermudas",
		"BHOUTAN":"But\u00e1n",
		"BOLIVIE_L_ETAT_PLURINATIONAL_DE":"Bolivia (Estado Plurinacional de)",
		"BONAIRE_SAINT_EUSTACHE_ET_SABA":"Bonaire, San Eustaquio y Saba",
		"BOSNIE_HERZEGOVINE":"Bosnia-Herzegovina",
		"BOTSWANA":"Botsuana",
		"BOUVET_ILE":"Bouvet (Isla)",
		"BRESIL":"Brasil",
		"BRUNEI_DARUSSALAM":"Brun\u00e9i Darussalam",
		"BULGARIE":"Bulgaria",
		"BURKINA_FASO":"Burkina-Faso",
		"BURUNDI":"Burundi",
		"CAIMANES_ILES":"Caim\u00e1n (Islas)",
		"CAMBODGE":"Camboya",
		"CAMEROUN":"Camer\u00fan",
		"CANADA":"Canad\u00e1",
		"CAP_VERT":"Cabo Verde",
		"CENTRAFRICAINE_REPUBLIQUE":"Rep\u00fablica Centroafricana",
		"CHILI":"Chile",
		"CHINE":"China",
		"CHYPRE":"Chipre",
		"COCOS_KEELING_ILES":"Cocos (Islas) \/ Keeling (Islas)",
		"COLOMBIE":"Colombia",
		"COMORES":"Comoras",
		"CONGO":"Congo",
		"CONGO_RD":"Congo (Rep\u00fablica Democr\u00e1tica)",
		"COREE_DU_NORD":"Corea (Rep\u00fablica Popular Democr\u00e1tica)",
		"COREE_REPUBLIQUE_DE":"Corea (Rep\u00fablica)",
		"COSTA_RICA":"Costa Rica",
		"COTE_D_IVOIRE":"Costa de Marfil",
		"CROATIE":"Croacia",
		"CUBA":"Cuba",
		"CURACAO":"Curazao",
		"DANEMARK":"Dinamarca",
		"DJIBOUTI":"Yibuti",
		"DOMINICAINE_REPUBLIQUE":"Dominicana (Rep\u00fablica)",
		"DOMINIQUE":"Dominica",
		"EGYPTE":"Egipto",
		"EL_SALVADOR":"El Salvador",
		"EMIRATS_ARABES_UNIS":"Emiratos \u00c1rabes Unidos",
		"EQUATEUR":"Ecuador",
		"ERYTHREE":"Eritrea",
		"ESPAGNE":"Espa\u00f1a",
		"ESTONIE":"Estonia",
		"ETATS_FEDERES_DE_MICRONESIE":"Micronesia (Estados Federados)",
		"ETATS_UNIS":"Estados Unidos de Am\u00e9rica",
		"ETHIOPIE":"Etiop\u00eda",
		"FALKLAND_ILES_MALVINAS":"Falkland (Islas)",
		"FEROE_ILES":"Feroe (Islas)",
		"FIDJI":"Fiyi (Islas)",
		"FINLANDE":"Finlandia",
		"FRANCE":"Francia",
		"GABON":"Gab\u00f3n",
		"GAMBIE":"Gambia",
		"GEORGIE":"Georgia",
		"GEORGIE_DU_SUD_ET_LES_ILES_SANDWICH_DU_SU":"Islas Georgia del Sur y S\u00e1ndwich del Sur",
		"GHANA":"Ghana",
		"GIBRALTAR":"Gibraltar",
		"GRECE":"Grecia",
		"GRENADE":"Granada",
		"GROENLAND":"Groenlandia",
		"GUADELOUPE":"Guadalupe",
		"GUAM":"Guam",
		"GUATEMALA":"Guatemala",
		"GUERNESEY":"Guernesey",
		"GUINEE":"Guinea",
		"GUINEE_EQUATORIALE":"Guinea Ecuatorial",
		"GUINEE_BISSAU":"Guinea-Bissau",
		"GUYANA":"Guayana",
		"GUYANE_FRANCAISE":"Guayana Francesa",
		"HAITI":"Hait\u00ed",
		"HEARD_ILE_ET_MCDONALD_ILES":"Heard y McDonald (Islas)",
		"HONDURAS":"Honduras",
		"HONG_KONG":"Hong Kong",
		"HONGRIE":"Hungr\u00eda",
		"ILE_CHRISTMAS":"Navidad (Isla)",
		"ILE_DE_MAN":"Isla de Man",
		"ILE_NORFOLK":"Norfolk (Isla)",
		"ILES_COOK":"Cook (Islas)",
		"ILES_MARIANNES_DU_NORD":"Marianas del Norte (Islas)",
		"ILES_MINEURES_ELOIGNEES_DES_ETATS_UNIS":"Islas Ultramarinas Menores de Estados Unidos",
		"ILES_TURKS_ET_CAIQUES":"Turcas y Caicos (Islas)",
		"ILES_VIERGES_BRITANNIQUES":"Islas V\u00edrgenes Brit\u00e1nicas",
		"ILES_VIERGES_DES_ETATS_UNIS":"Islas V\u00edrgenes de los Estados Unidos",
		"INDE":"India",
		"INDONESIE":"Indonesia",
		"IRAN_REPUBLIQUE_ISLAMIQUE_D_":"Ir\u00e1n (Rep\u00fablica Isl\u00e1mica)",
		"IRAQ":"Irak",
		"IRLANDE":"Irlanda",
		"ISLANDE":"Islandia",
		"ISRAEL":"Israel",
		"ITALIE":"Italia",
		"JAMAIQUE":"Jamaica",
		"JAPON":"Jap\u00f3n",
		"JERSEY":"Jersey",
		"JORDANIE":"Jordania",
		"KAZAKHSTAN":"Kazajst\u00e1n",
		"KENYA":"Kenia",
		"KIRGHIZISTAN":"Kirguist\u00e1n",
		"KIRIBATI":"Kiribati",
		"KOWEIT":"Kuwait",
		"LAO_REPUBLIQUE_DEMOCRATIQUE_POPULAIRE":"Lao (Rep\u00fablica Democr\u00e1tica Popular)",
		"LESOTHO":"Lesoto",
		"LETTONIE":"Letonia",
		"LIBAN":"L\u00edbano",
		"LIBERIA":"Liberia",
		"LIBYENNE_JAMAHIRIYA_ARABE":"Libia",
		"LIECHTENSTEIN":"Liechtenstein",
		"LITUANIE":"Lituania",
		"LUXEMBOURG":"Luxemburgo",
		"MACAO":"Macao",
		"MACEDOINE":"Macedonia (Antigua Rep\u00fablica Yugoslava)",
		"MADAGASCAR":"Madagascar",
		"MALAISIE":"Malasia",
		"MALAWI":"Malaui",
		"MALDIVES":"Maldivas",
		"MALI":"Mal\u00ed",
		"MALTE":"Malta",
		"MAROC":"Marruecos",
		"MARSHALL_ILES":"Marshall (Islas)",
		"MARTINIQUE":"Martinica",
		"MAURICE":"Mauricio",
		"MAURITANIE":"Mauritania",
		"MAYOTTE":"Mayotte",
		"MEXIQUE":"M\u00e9xico",
		"MOLDOVA":"Moldavia (Rep\u00fablica)",
		"MONGOLIE":"Mongolia",
		"MONTENEGRO":"Montenegro",
		"MONTSERRAT":"Montserrat",
		"MOZAMBIQUE":"Mozambique",
		"MYANMAR":"Myanmar",
		"NAMIBIE":"Namibia",
		"NAURU":"Nauru",
		"NEPAL":"Nepal",
		"NICARAGUA":"Nicaragua",
		"NIGER":"N\u00edger",
		"NIGERIA":"Nigeria",
		"NIUE":"Niue",
		"NORVEGE":"Noruega",
		"NOUVELLE_CALEDONIE":"Nueva Caledonia",
		"NOUVELLE_ZELANDE":"Nueva Zelanda",
		"OMAN":"Om\u00e1n",
		"OUGANDA":"Uganda",
		"OUZBEKISTAN":"Uzbekist\u00e1n",
		"PAKISTAN":"Pakist\u00e1n",
		"PALAOS":"Palaos",
		"PALESTINE_GAZA":"Palestina (Estado)",
		"PANAMA":"Panam\u00e1",
		"PAPOUASIE_NOUVELLE_GUINEE":"Pap\u00faa Nueva Guinea",
		"PARAGUAY":"Paraguay",
		"PAYS_BAS":"Pa\u00edses Bajos",
		"PEROU":"Per\u00fa",
		"PHILIPPINES":"Filipinas",
		"PITCAIRN":"Pitcairn",
		"POLOGNE":"Polonia",
		"POLYNESIE_FRANCAISE":"Polinesia Francesa",
		"PORTO_RICO":"Puerto Rico",
		"PORTUGAL":"Portugal",
		"PRINCIPAUTE_DE_MONACO":"M\u00f3naco",
		"QATAR":"Catar",
		"REUNION":"Reuni\u00f3n",
		"ROUMANIE":"Rumania",
		"ROYAUME_UNI":"Reino Unido de Gran Breta\u00f1a e Irlanda del Norte",
		"RUSSIE_FEDERATION_DE":"Rusia (Federaci\u00f3n)",
		"RWANDA":"Ruanda",
		"SAHARA_OCCIDENTAL":"S\u00e1hara occidental",
		"SAINT_BARTHELEMY":"San Bartolom\u00e9",
		"SAINTE_HELENE_ASCENSION_ET_TRISTAN_DA_CUN":"Santa Elena, Ascensi\u00f3n y Trist\u00e1n Da Cunha",
		"SAINTE_LUCIE":"Santa Luc\u00eda",
		"SAINT_KITTS_ET_NEVIS":"San Crist\u00f3bal y Nieves",
		"SAINT_MAARTIN":"Sint Maarten (Holanda)",
		"SAINT_MARIN":"San Marino",
		"SAINT_MARTIN":"San Mart\u00edn (Francia)",
		"SAINT_PIERRE_ET_MIQUELON":"San Pedro y Miquel\u00f3n",
		"SAINT_SIEGE_ETAT_DE_LA_CITE_DU_VATICAN":"Santa Sede",
		"SAINT_VINCENT_ET_LES_GRENADINES":"San Vicente y las Granadinas",
		"SALOMON_ILES":"Salom\u00f3n (Islas)",
		"SAMOA":"Samoa",
		"SAMOA_AMERICAINES":"Samoa Americana",
		"SAO_TOME_ET_PRINCIPE":"Santo Tom\u00e9 y Pr\u00edncipe",
		"SENEGAL":"Senegal",
		"SERBIE":"Serbia",
		"SEYCHELLES":"Seychelles",
		"SIERRA_LEONE":"Sierra Leona",
		"SINGAPOUR":"Singapur",
		"SLOVAQUIE":"Eslovaquia",
		"SLOVENIE":"Eslovenia",
		"SOMALIE":"Somalia",
		"SOUDAN":"Sud\u00e1n",
		"SOUDAN_SUD":"Sud\u00e1n del Sur",
		"SRI_LANKA":"Sri Lanka",
		"SUEDE":"Suecia",
		"SUISSE":"Suiza",
		"SURINAME":"Surinam",
		"SVALBARD_ET_ILE_JAN_MAYEN":"Svalbard y Jan Mayen",
		"SWAZILAND":"Suazilandia",
		"SYRIENNE_REPUBLIQUE_ARABE":"Rep\u00fablica \u00c1rabe Siria",
		"TADJIKISTAN":"Tayikist\u00e1n",
		"TAIWAN_PROVINCE_DE_CHINE":"Taiw\u00e1n (Provincia de China)",
		"TANZANIE_REPUBLIQUE_UNIE_DE":"Tanzania (Rep\u00fablica Unida)",
		"TCHAD":"Chad",
		"TCHEQUE_REPUBLIQUE":"Chequia (Rep\u00fablica Checa)",
		"TERRES_AUSTRALES_FRANCAISES":"Tierras Australes Francesas",
		"TERRITOIRE_BRITANNIQUE_DE_L_OCEAN_INDIEN":"\u00cdndico (Territorio Brit\u00e1nico del Oc\u00e9ano)",
		"THAILANDE":"Tailandia",
		"TIMOR_ORIENTAL":"Timor-Leste",
		"TOGO":"Togo",
		"TOKELAU":"Tokelau",
		"TONGA":"Tonga",
		"TRINITE_ET_TOBAGO":"Trinidad y Tobago",
		"TUNISIE":"T\u00fanez",
		"TURKMENISTAN":"Turkmenist\u00e1n",
		"TURQUIE":"Turqu\u00eda",
		"TUVALU":"Tuvalu",
		"UKRAINE":"Ucrania",
		"URUGUAY":"Uruguay",
		"VANUATU":"Vanuatu",
		"VENEZUELA_REPUBLIQUE_BOLIVARIENNE_DU":"Venezuela (Rep\u00fablica Bolivariana)",
		"VIET_NAM":"Vietnam",
		"WALLIS_ET_FUTUNA":"Wallis y Futuna",
		"YEMEN":"Yemen",
		"ZAMBIE":"Zambia",
		"ZIMBABWE":"Zimbabue"
	},
	"UNITES":
	{
		"MILLIERS":
		[
			"mil",
			"mill\u00f3n",
			"mil millones",
			"bill\u00f3n",
			"mil billones",
			"trill\u00f3n",
			"mil trillones"
		],
		"CHIFFRES":
		[
			"un",
			"dos",
			"tres",
			"cuatro",
			"cinco",
			"seis",
			"siete",
			"ocho",
			"nueve",
			"diez",
			"once",
			"doce",
			"trece",
			"catorce",
			"quince",
			"diecis\u00e9is",
			"diecisiete",
			"dieciocho",
			"diecinueve"
		],
		"DIZAINES":
		[
			"veinte",
			"treinta",
			"cuarenta",
			"cincuenta",
			"sesenta",
			"setenta",
			"ochenta",
			"noventa"
		],
		"CENT":"cien",
		"ZERO":"cero",
		"MOINS":"menos",
		"VIRGULE":"coma"
	}
};