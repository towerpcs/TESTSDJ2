/*! VersionVI: yyyyyyyyyyyy */
// 26.0.1.0 jquery-ancrage-ie.js
///#DEBUG=clWDUtil.WDDebug
var _bOpr = (window.bOpr!==undefined && window.bOpr); 
  $().ready(function(){ var fDeclencheAncrage = undefined;
if (_bOpr || ((document.documentMode!==undefined) && (document.compatMode!="BackCompat"))){//si Opera ou IE
///#DEBUG
	var Chrono = new Date().getTime();
///#ENDDEBUG
	//hauteur du contenu avant toute manipulation d'ancrage => TODO � mettre � jour � chaque appel AJAX
	//var nHauteurContenu = $(document).height();
	$("html,body").css("height","auto");
	var nHauteurContenu = $("body").height();
	$("html,body").css("height","100%");	
	//identifiant du timer => pour pouvoir d�caler l'appel h100_set � plus tard si l'utilisateur continue de resizer
	var gbH100 = null;
	//indique si on est en train d'ex�cuter h100_set => permet d'ignorer les �v�nements de resize pendant h100_set
	var gbH100_set = false;
	clWDUtil.WDDebug.log("19 : " + (new Date().getTime() - Chrono));
	function nGetDocumentHauteur()
	{
		var body = document.body,
			html = document.documentElement;
		return Math.max( body.scrollHeight, body.offsetHeight, 
							html.clientHeight, html.scrollHeight, html.offsetHeight );	
	}
	
	//Tente de faire les ancrages navigateurs via flexbox
	//pour IE11 uniquement(car pas support� avant)
	//et uniquement pour du debug pour le moment
	//TODO OPTIM stabiliser les ancrages via flexbox pour TB#94629
	//bugs connus : le text-align center sur le td d'un libell� ancr� n'est pas appliqu� + on perd les valign
	var bViaFlex = 0 && bIEAvec11 && !bIE;
	
	//d�finit l'affichage entre le d�but du redimensionnement du navigateur et le d�but de l'application des ancrages
 	function h100_raz(oEvent,domParent)
	{
		if (!bViaFlex)
		{
			//masque l'ascenseur vertical le temps du redimensionnement ou force son affichage s'il �tait d�j� affich� pour �viter qu'il ne clignote pendant le redimensionnement
			//force l'ascenseur sous Op�ra car on ne sait pas d�terminer s'il faut l'afficher ou pas
			if (!domParent || domParent==document.body)
				$("body").css("overflow-y",(_bOpr || ($(document).height()>document.documentElement.offsetHeight)) ? "scroll" : "hidden");
		}
	}
	
	//applique les ancrages
	function h100_set(oEvent,domParent)
	{
		if(!domParent) domParent = document.body;

		$(window).trigger("trigger.wb.ancrage.ie.debut");

		if (!bViaFlex)
		{

		//pour op�ra on fait varier la taille du html,body du coup on la raz avant d'appliquer les ancrages
		if (_bOpr) $("html,body").css("height","100%");	
		
		//Applique l'ancrage en 2 passes afin que les champs soient tous en absolu avant de les remettre un � un un static
		//1  - Passe les champs en absolu pour qu'ils ne poussent plus leurs conteneurs
		var bContenuTropGrand = (domParent == document.body) ? (nHauteurContenu>document.documentElement.offsetHeight) : false;	

		clWDUtil.WDDebug.log("53 : " + (new Date().getTime() - Chrono));
		
		var tabChamps = $(domParent).find('.h100,.hauto').filter(function(){
			return $(this).css("display") != "none";
		});
		
		tabChamps.each(function()
		{
			var jqChamp = $(this);
			//Si le contenu est d�j� trop grand pour �tre affich� en entier
			if (bContenuTropGrand)
			{
				//alors on restaure les positions initiales des champs
				jqChamp.css("position",jqChamp.attr("data-position"));
			}
			else
			{
				//sinon les champs sont forc�s en absolute pour qu'ils ne poussent pas
				jqChamp.parent().css("position","relative");
				jqChamp.css("position","absolute");	
			}
			//RAZ la hauteur �ventuellement d�j� pr�cis�e lors d'un pr�c�dent calcul d'ancrage
			var sTagName = this.tagName.toLowerCase();
			if ((sTagName == 'img' || sTagName == 'svg') && bLargeur100p100(jqChamp))
			{
				//une hauteur auto sur une image en largeur � 100% forcerait son rendu homoth�tique, ce qui peut pousser le conteneur
				jqChamp.css("height",1);		
			}
			else			
			{
				jqChamp.css("height","auto");
			}
		});	
			
		//2 - Remplace un � un les champs en static pour leur calculer les dimensions pour l'ancrage vis � vis du navigateur
		tabChamps.each(function()
		{
			var jqChamp = $(this);
			//prend sa  taille naturelle
			if (!bContenuTropGrand) 
			{
			jqChamp.parent().css("position","");
			}
			// on restaure les positions initiales des champs
			jqChamp.css("position",jqChamp.attr("data-position"));
			
			if (jqChamp.hasClass('hauto') || bContenuTropGrand) return;
			
			var nNouvelleHauteur = jqChamp.parent().innerHeight();

			//d�j� � la bonne hauteur
			if (jqChamp.outerHeight()>nNouvelleHauteur)//pas le cas =, car peut �tre du � un auto qui est toujours calcul� � l'ancienne hauteur
			{	
				return;
			}			
			//ancrage artificiel
			jqChamp.css({height : nNouvelleHauteur});		
		});

		//3 -  applique les ancrages navigateur vis � vis d'un conteneur agrandi par le contenu 
		tabChamps.each(function(){MajTailleDepuisContenu($(this));});		
		
		function MajTailleDepuisContenu(jqThis)
		{
			//prend sa  taille naturelle
			var nNouvelleHauteur = jqThis.parent().parent().innerHeight();//parent td, parent parent tr
			nNouvelleHauteur = Math.max(nNouvelleHauteur,jqThis.children().first().outerHeight());

			//d�j� � la bonne hauteur
			if (jqThis.outerHeight()>=nNouvelleHauteur)
			{	
				return;
			}			
			//ancrage artificiel
			if (jqThis.parent().hasClass("WDOC"))
			{
				nNouvelleHauteur-=2;//2px de bordures en dur pour les s�parateurs de volets et qui sont collapse
			}
			jqThis.css({height : nNouvelleHauteur});					
		}		
		
		//5- pour Op�ra : si le navigateur est trop petit, on force une taille pour <html> et <body> sinon ils s'arr�tent � la hauteur du navigateur et non du contenu
		if (_bOpr)
		{
			//force une taille de html;body
			$("html,body").css("height",nGetDocumentHauteur() + "px");				
			//6 -  applique les ancrages navigateur vis � vis d'un conteneur agrandi par le contenu 
			$('.hauto,.h100').each(function(){MajTailleDepuisContenu($(this));});
		}

		if (domParent == document.body)
		{
			//4 -  r�tablit les ascenseurs (inverse de h100_raz)
			$("body").css("overflow-y","auto");
			clWDUtil.WDDebug.log("145 : " + (new Date().getTime() - Chrono));
			//5 -	notifie la JS
			if (window.clWDUtil)
			{
				clWDUtil.__OnScrollResize(event, false);
			}
		}

		}//!flex

		clWDUtil.WDDebug.log("151 : " + (new Date().getTime() - Chrono));
		//Evite de voir les �tapes interm�diaire du 1er dessin
		var jqStyleMasque = $(".wbAndrageIEChargement1erAffichage");
		if (bContenuTropGrand || !jqStyleMasque.length || jqStyleMasque.data("wbPremierCalculFait")===true)
		{	//en cas de contenu trop grand il n'y aura qu'un appel
			if (jqStyleMasque.length)
			{	
				jqStyleMasque.remove();
			}
			$(window).trigger("trigger.wb.ancrage.ie.1erAffichageApresAncrage");
		}
		else 
		{
			jqStyleMasque.data("wbPremierCalculFait",true);
		}	clWDUtil.WDDebug.log("165 : " + (new Date().getTime() - Chrono));	
	

		$(window).trigger("trigger.wb.ancrage.ie.fin");
	}
	
	//vrai si l'�l�ment est  � 100% en hauteur
	function bHauteur100p100(jqElement,bTestTable)
	{
	return  (jqElement.length==1 )
			&&
			(		(jqElement[0].currentStyle && jqElement[0].currentStyle.height=="100%")
				||	((jqElement.attr("style")+"").indexOf("height: 100%")>=0)
				||	(_bOpr && (jqElement.attr("style")+"").indexOf("height:100%")>=0)
				||	(_bOpr && (jqElement.attr("style")+"").indexOf("height:100.00%")>=0)
				||	(bTestTable!==false && ((jqElement[0].tagName.toLowerCase()=='tr') && bHauteur100p100(jqElement.closest('table'))))
			)
	;
	}
	function bLargeur100p100(jqElement)
	{
	return  (jqElement.length==1 )
			&&
			(		(jqElement[0].currentStyle && jqElement[0].currentStyle.width=="100%")
				||	((jqElement.attr("style")+"").indexOf("width: 100%")>=0)
				||	(_bOpr && (jqElement.attr("style")+"").indexOf("width:100%")>=0)
				||	(_bOpr && (jqElement.attr("style")+"").indexOf("width:100.00%")>=0)
				||	((jqElement[0].tagName.toLowerCase()=='tr') && bLargeur100p100(jqElement.closest('table')))
			)
	;
	}	
	clWDUtil.WDDebug.log("193 : " + (new Date().getTime() - Chrono));
	//Initialisation :
	//1 - rep�re les lignes d'ancrage
	$('tr>td>*').each(function()
	{
		var jqTrTdFils = $(this);
		//S�lectionne les balises ancr�es en hauteur selon les crit�res   :
		// - avoir height:100%
		// - �tre le cadre de la page
		// - �tre ni absolute ni fixed
		if (	
		//cadre de la page ou ligne de 100%
			((jqTrTdFils.attr("id")=="page") || (bHauteur100p100(jqTrTdFils)&&bHauteur100p100(jqTrTdFils.parent().parent())))
		//�vite les divs de superposition
		&&	(jqTrTdFils.css("position")!="absolute")
		&&	(jqTrTdFils.css("position")!="fixed")
		//�vite le champ table
		&&	((jqTrTdFils.attr("id")||"").indexOf("ctz")!=0)
		)
		{
			//la balise sera affect�e par le redimensionnement
			jqTrTdFils.addClass("h100");
			if (jqTrTdFils.css("position") == "relative")
				jqTrTdFils.attr("data-position","relative");
			else 
				jqTrTdFils.attr("data-position","");
		}
		else
		{
			//flag la balise comme ne transmettant pas d'ancrages
			jqTrTdFils.addClass("h100non");
		}
	});
	clWDUtil.WDDebug.log("226 : " + (new Date().getTime() - Chrono));
	//1 - suite : annule les ancrages sur la table
	$('table[id^=ctz]').addClass("h100non");
	
	//2 - retrouve les balises h100 filles de balises ne transmettant pas l'ancrage  : optim pour �viter d'appliquer un 100% sur un fils dont le parent ne s'agrandit pas
	$('.h100non .h100').each(function()
	{
		$(this).removeClass("h100");
		//hauto : indique ces chamsp sont ancr�s en hauteur mais dans un conteneur (direct ou indirect) qui n'est pas ancr� en hauteur
		$(this).addClass("hauto");
	});	
	//note : les class="h100non" ne sont pas retir�es. Elles sont pour le moment inutiles une fois l'init faites. On pourrait les retirer mais cela ralonge le temps d'ex�cution et n'apporte rien.
	clWDUtil.WDDebug.log("238 : " + (new Date().getTime() - Chrono));
	//2 - suite : pas d'ancrage, m�me auto dans les tables
	$('table[id^=ctz] .hauto').removeClass("hauto");
	
	//Eventements concern�s :	
	//TODO bind ancrage ie sur tous les �l�ments? pas que window? -> http://benalman.com/code/projects/jquery-resize/examples/resize/
	//- le resize du navigateur
	$(window).on("resize",function(event,domParent){fDeclencheAncrage(event,true,domParent);});
	$(window).on("trigger.wb.ancrage.ie.declenche trigger.wb.postUpdateLayoutSuperposableEpingle.ancrage",function(event,domParent){fDeclencheAncrage(event,-1,domParent);});
	//- le changement de volet d'onglet
	$(".WDVC,.WDVG,.WDVD").add($(".WDOT").parent().children()).click(function(event){fDeclencheAncrage(event,false);});

	//permet d'�tre notifi� en cas de resize d'un champ alors que le navigateur n'a pas �t� resize (cas d'un changement de plan)
    clWDUtil.AttacheOnScrollResize(function(oEvent, bOnScroll)
    {
        if (bOnScroll)
        {
            return;
        }
        fDeclencheAncrage(oEvent,true,document.body);
    }); 
	
	//Fonction de d�clanchement => directement appel�e par les �v�nements concern�s
	fDeclencheAncrage = function DeclencheAncrage(event,bAvecDelai,domParent)	
	{	
		if (!domParent) domParent = document.body;
		//�vite les appels � resize � cause des modifications temporaires de h100_set
		if (domParent.gbH100_set)
		{
			return;
		}
		//aucun timer en attente?
		if (domParent.gbH100==null) 
		{	//oui=> on fait l'unique raz avant tout set
			h100_raz(event,domParent);
		}
		else
		{	//non=> il faut donc annuler le pr�c�dent timer
			clearTimeout(domParent.gbH100);
		}
		//le set est d�cal� pour qu'il ne soit ex�cut� qu'une fois m�me si l'utilisateur met plusieurs secondes � redimensionner le navigateur
		if (bAvecDelai==true) 
		{
			//applique l'ancrage pour IE avec le d�lai, et d�clenche l'�v�nement de resize afin d'�tre s�r d'�tre le premier �v�nements de resize
			domParent.gbH100 = setTimeout(function()
			{
				try
				{
					domParent.gbH100_set = true;
					h100_set(event,domParent);					
					$(window).trigger('resize',domParent);//ne doit pas faire un 2�me fDeclencheAncrage									
				}
				catch(e)
				{
					clWDUtil.WDDebug.log(e);
				}
				finally
				{
					domParent.gbH100_set = false;
					domParent.gbH100 = null;
				}
			},50);
		}
		else 
		{
			//Appeler directement la m�thode est trop rapide, on doit faire un l�ger d�lai sinon ce n'est pas efficace
			if (bAvecDelai==-1) 
			{
				try
				{
					domParent.gbH100_set = true;
					h100_set(event,domParent);										
				}
				catch(e)
				{
					clWDUtil.WDDebug.log(e);
				}
				finally
				{
					domParent.gbH100_set = false;
				}
			}
			else 
			{
				setTimeout(function(){
				try
				{
					domParent.gbH100_set = true;
					h100_set(event,domParent);					
				}
				catch(e)
				{
					clWDUtil.WDDebug.log(e);
				}
				finally
				{
					domParent.gbH100_set = false;
					domParent.gbH100 = null;
				}
				},10);
			}
		}
	}
	//un premier appel pour effectuer les ancrage, mais l�g�rement d�cal� pour que cela se produise apr�s le premier paint d'IE
	setTimeout(function()
	{	

		clWDUtil.WDDebug.log("300 : " + (new Date().getTime() - Chrono));

		if (bViaFlex)
		{
			window.tabChamps = $('.h100,.hauto').filter(function(){
				return $(this).css("display") != "none";
			});


			//lecture des �l�ments
			window.tabChamps.each(function(){
				this.rect = this.getBoundingClientRect();

				var jqTrParent = $(this).closest("tr").first();
				jqTrParent[0].rect = jqTrParent[0].getBoundingClientRect();
			});
			
			//�criture des �l�ments
			window.tabChamps.each(function(){
				var cssTailleMin = {minHeight : this.rect.height, height : "100%", flexGrow : 1  };
				$(this).css(cssTailleMin);
			});

			//devrait �tre corrig� dans la g�n�ration
			$(".h100>table,table.h100").each(function(){
				var jqTr = $(this.querySelector("tr"));
				var jqTr2 = jqTr.next();
				if (jqTr2.length==0)
				{
					jqTr.css("height","100%");
				}
				//cas de la liste ancr�e en hauteur avec libell� au dessus
				else if ((jqTr.attr("style")||"").indexOf("height")==-1 && (jqTr2.attr("style")||"").indexOf("height")==-1)
				{
					jqTr.next().css("height","100%");
				}				
			});

			window.tabChamps.each(function(){
				var jqTrParent = $(this).closest("tr").first();
				if (!bHauteur100p100(jqTrParent,false))
				{
					$(this.querySelectorAll(".h100")).removeClass("h100").addClass("hauto");

					jqTrParent.css({minHeight : jqTrParent[0].rect.height,maxHeight : jqTrParent[0].rect.height });
				}
			});


			//passage en flex
			var jqStyleFlex = $("<style>"
			+"table{    display: flex;    flex-direction: row;    height:100%;width:100%;}"
			+"tbody{    display: flex;    flex-direction: column;    height:100%;width:100%;}"
			+"tr{    display: flex;    flex-direction: row;    width:100%;  }"
			+"td {        display: flex;    flex-direction: column;    height:100%;  }"
			+".hauto table,table .hauto{    display: table;       }"
			+".hauto tbody{    display: table;       }"
			+".hauto tr{    display: table-row;      }"
			+".hauto td {        display: table-cell;}"			
			+"</style>");			

			$("head").append(jqStyleFlex);
			$("head #wbStyleAncrageIE11").remove();
				
		}

		//force la hauteur � 100% sur la page
		if (bIEAvec11)
		{
			//�tire la page ou la page interne � 100%
			//permet d'optimiser le 1er affichage avec un height qui est d'abord en height:auto
			//avant de repasser ici en height:100%. Comme �a les offsetHeight/offsetWidth qui sont appel�s entre temps sont rapides
			//car ne relancent pas un dessin
			$("#page,[id|=page]").first().css("height","100%");
		}	
		
		//1er appel d'ancrage
		h100_set(event);
		clWDUtil.WDDebug.log("321 : " + (new Date().getTime() - Chrono));
		//retire les r�gles CSS de premier affichage sous IE11
		//Note : ces r�gles permettent de ne pas avoir trop de height:100% lors du 1er affichage afin de le fluidifier
		//mais une fois que h100_set est appel�, les height:100% sont transform�s en height:px donc ces r�gles ne sont plus utiles
		//Astuce:  il est possible de garder ces r�gles car elles vises les *[style*='height: 100%'] hors les height sont d�sormais en pixels
		//donc ne sont plus vis�s. Mais mieux vaut retirer ce r�sidu utile que pour le 1er affichage
		if (bIEAvec11)
		{
			$("head #wbStyleAncrageIE11").remove();
		}

		//QW#255339 force un 2�me recalcule		
		if (!(nHauteurContenu>document.documentElement.offsetHeight)) $(window).trigger("trigger.wb.ancrage.ie.declenche");
		clWDUtil.WDDebug.log("324 : " + (new Date().getTime() - Chrono));	

		//en cas de mise � jour de html par ajax
		if (fDeclencheAncrage && window["clWDUtil"]!==undefined) 
		{
			if (clWDUtil.m_oNotificationsAjoutHTML)
			{
				clWDUtil.m_oNotificationsAjoutHTML.AddNotification(function()
				{
					var nNouvelleHauteurAjoutHTML = $(document.body).height();
					if (this.m_nHauteurPrecedenteAjoutHTML != nNouvelleHauteurAjoutHTML)
					{
						fDeclencheAncrage();					
					}
					this.m_nHauteurPrecedenteAjoutHTML = nNouvelleHauteurAjoutHTML;
				});
			}
			if (clWDUtil.m_oNotificationsFinAJAX)
			{
				clWDUtil.m_oNotificationsFinAJAX.AddNotification(fDeclencheAncrage);
			}
		}
	},10);

}
//�vite de laisser trainer un style de hack
else	
{
	var jqStyleMasque = $(".wbAndrageIEChargement1erAffichage");
	if (jqStyleMasque.length)
	{
		jqStyleMasque.remove();
	}
	//indique que le 1er affichage apr�s ancrage a lieu, 
	//m�me si aucune action n'a eu lieu vu qu'on est sur un navigateur qui n'a pas besoin des ancrages calcul�s par js
	$(window).trigger("trigger.wb.ancrage.ie.1erAffichageApresAncrage",false);
}		

//TODO VERIF : astuce si on retire le td de trou et qu'on laisse le colspan tel quel pour le td de contenu dans le tr suivant (donc � N+1) le comportement semble ok
//Onglet 
$(function(){

function MajHauteurTrouVolet(jqTrou)
{
	//hauteur adapt�e des trous d'onglet
	//en appliquant la hauteur de la table parente sur la table des libell�s de volets

	var jqTableParent = jqTrou.parents("table").first();
	jqTableParent.css("height", "100%");

	var jqTableGrandParent = jqTableParent.parents("table").first();
	jqTableParent.css("height", jqTableGrandParent.height());
}
//largeur adapt�e des onglets
function MajLargeurTrouVolet(b1erePhase,bForceSynchrone,fCallbackFinPhase)
{
	//chaque trou de libell� de volet se recalcule
	var jqListeTrous = $(".WDOT");


	if (jqListeTrous.length === 0)
	{
		//pas d'action 
		return false;
	}

	//traite uniquement si visible
	var jqTousLesTrousEnProfondeurDabord = $(jqListeTrous.get().reverse()).filter(function(){
		return clWDUtil.bEstDisplay(this,document);
	});

	//Tout 1er init ?
	jqTousLesTrousEnProfondeurDabord.each(function(){
		//d�j� fait
		if (this.bBindResize!==undefined)
		{
			return;
		}
		//calcule la largeur adapt�e des libell�s
		var jqTrou = $(this);
		//les fr�res pr�c�dents
		var jqFreresLibelle = this.jqFreresLibelle = jqTrou.parent().children().slice(0,-1);
		this.bVertical = false;
		//volet vertical
		if(jqFreresLibelle.length==0)
		{		
			this.bVertical=true;
			//prend les td des autres tr
			jqFreresLibelle = jqTrou.parent().parent().children().slice(0,-1).children("td");
		}
		//- le changement de volet d'onglet recalcule le trou
		this.jqChampOnglet = jqTrou.closest("table");
		this.jqChampOnglet.find(".WDVC,.WDVG,.WDVD").add(jqFreresLibelle).click(function(event){$(window).trigger("resize");/*MajLargeurTrouVolet() inusffisant en csa d'ancrage IE */});		
		var sStyle = (this.jqChampOnglet.attr("style")||'').replace(/ /g,"");	//ou width=100% pour HTML4
		this.bCalculRequis = true;//this.bVertical || jqFreresLibelle.find(".wbDynLibelle").length;
		this.bBindResize =  this.bCalculRequis && (	( this.bVertical ? ( (sStyle.indexOf("height:100%")>-1) || (sStyle.indexOf("HEIGHT:100%")>-1) || this.jqChampOnglet.attr("height")=="100%") : ( (sStyle.indexOf("width:100%")>-1) || (sStyle.indexOf("WIDTH:100%")>-1)  || this.jqChampOnglet.attr("width")=="100%")) );	

		var bAvecFlex = clWDUtil.bHTML5 && !this.bVertical && !bIEAvec11 && !bIE;
		if (bAvecFlex)
		{
			jqFreresLibelle.parent().addClass("wbVoletFlex").next().addClass("wbVoletFlex").css("height","100%").parent().css({
				display:"flex",flexDirection:"column",width:"100%",height:"100%"//tbody
			}).parent().css({
				display:"flex",flexDirection:"column",width:"100%",height:"100%"//table
			});
		}
	});

	//traite uniquement ceux qui ont besoin d'un calcul (soit ancr�, soit pas 1er affichage pas encore calcul� )
	var jqTousLesTrousEnProfondeurDabordPourCalcul = jqTousLesTrousEnProfondeurDabord.filter(function() { return this.bCalculRequis && (!this.b1erCalculDejaiFait || this.bBindResize); });

	if (jqTousLesTrousEnProfondeurDabordPourCalcul.length === 0)
	{
		//pas d'action 
		return false;
	}

	if (b1erePhase)
	{
		//retire l'ascenseur horizontal pendant le resize
		$(document.body).addClass("wbOverflowHiddenX");
	}

	var jqListeTrousHorizontaux = jqTousLesTrousEnProfondeurDabordPourCalcul.filter(function() { return !this.bVertical; });

	var jqListeTrousVerticaux = jqTousLesTrousEnProfondeurDabordPourCalcul.not(jqListeTrousHorizontaux);

	if (!b1erePhase)
	{			
		jqListeTrousVerticaux.each(function(){
			var jqTrou = $(this);
			MajHauteurTrouVolet(jqTrou);
			this.b1erCalculDejaiFait=true;
		});
	}

	//calcul en 3 passes asynchrones
	var bMasquerEntrePhases = false && !bForceSynchrone;//d�sactive le maquage par opacit� car le clignottement est g�nant
	var bAsynchrone = window.requestAnimationFrame && !bForceSynchrone;// && !b1erePhase; l'asynchrone ici n'apporte rien et fait un clignottement
	var fRaf = (bAsynchrone) ? requestAnimationFrame : function(f){f();return undefined/*et non true vu qu'il n'y a pas de blocage*/;};

	fRaf(function(){
	//phase de raz des largeurs
	if (b1erePhase)
	{
		jqListeTrousHorizontaux.each(function()
		{
			//calcule la largeur adapt�e des libell�s
			var jqTrou = $(this);
			jqTrou.children().first().css("width","auto");		
			jqTrou.css("width","100%");	//raz la dimension pour permettre le redimensionnement plus petit
			//les fr�res pr�c�dents
			this.jqFreresLibelle = this.jqFreresLibelle || jqTrou.parent().children().slice(0,-1);
			this.jqFreresLibelleVisible = this.jqFreresLibelle.filter(function(){return this.style.display!="none";}).addClass("t-0");
			//calcule la largeur totale		
			if (bMasquerEntrePhases)
			{
				this.jqFreresLibelleVisible.css({opacity:0});
			}
			//�vite de voir le dessin interm�diaire
			this.jqFreresLibelleVisible
			.each(function(){	
				var jqTdLibelle = $(this);					
				this.jqLibelle = jqTdLibelle.find(".WDVC").children().first();
				//sans le 3 images
				jqTrou[0].bMode3Images = this.jqLibelle.length;
				if (!jqTrou[0].bMode3Images)
				{
					this.jqLibelle = jqTdLibelle.children().first();
				}
				if (jqTdLibelle.hasClass("wbLargeurAdapteeVoletLibelle"))
				{
					this.jqLibelle.css("width", "auto").css("white-space", "pre").parent().css("width", "auto");
				}
			});		
		});
		//pas plus pour la 1ere phase => le reste est fait apr�s (permet aux tables de se calculer)
		!fCallbackFinPhase || fCallbackFinPhase();
		return;
	}

	fRaf(function(){

	//phase de calcul des largeurs
	jqListeTrousHorizontaux.each(function()
	{
		var jqTrou = $(this);
		jqTrou[0].nBordure = 0;
		this.jqChampOnglet = this.jqChampOnglet || jqTrou.closest("table");
		this.nLargeurChampOnglet = Math.max( this.jqChampOnglet.width(),	this.jqChampOnglet.find(".WDOC").children(":visible").width()+2/*bordure obligatoire*/	);

		this.nLargeurTotaleLibelle = 0;
		//calcule la largeur totale
		this.jqFreresLibelleVisible.each(function(){	
			var jqTdLibelle = $(this);
			this.nLargeurInit = this.jqLibelle.width();
			//lecture de la largeur dans la table contenu dans le TD de libell� de volet afin d'avoir la taille requise pour le contenu
			//alors que le TD aurait la taille �ventuellement r�partie � cause d'un trou pass� � 100% et donc �ventuellement � plat.
			this.nLargeurInitTD = jqTdLibelle.children().first().width();
			jqTrou[0].nBordure += jqTdLibelle.outerWidth() - jqTdLibelle.width();
			//m�morise la largeur adapt�e
			this.nLargeurAdaptee = this.nLargeurInit;
			if (jqTdLibelle.hasClass("wbLargeurAdapteeVoletLibelle"))
			{
				this.nLargeurAdaptee = Math.max(this.nLargeurAdaptee, this.jqLibelle.width());
			}			
			//incr�mente le total avec la largeur total du td apr�s modif
			jqTrou[0].nLargeurTotaleLibelle+=(this.nLargeurInitTD-this.nLargeurInit+this.nLargeurAdaptee);
			jqTrou[0].nLargeurChampOnglet = Math.max(jqTrou[0].nLargeurChampOnglet , jqTrou[0].nLargeurTotaleLibelle);
		});
	})
	;
	fRaf(function(){
	//phase d'application des largeurs calcul�es
	jqListeTrousHorizontaux.each(function()
	{
		var jqTrou = $(this);
		
		//calcule la largeur totale
		this.jqFreresLibelleVisible.each(function(){	
			var jqTdLibelle = $(this);

			if (jqTdLibelle.hasClass("wbLargeurAdapteeVoletLibelle"))
			{
				//r�tablit le dom initial
				this.jqLibelle.css("width", this.nLargeurInit).css("white-space", "normal")
				//attention � la bordure sur le td parent
				this.jqLibelle.parent().css("width", this.nLargeurInit + (this.jqLibelle.parent().outerWidth() - this.jqLibelle.width()));
			}
			this.jqLibelle.data("width-adaptee", this.nLargeurAdaptee);			
		});
		
		//si la largeur totale d�passe le champ, on r�partie la largeur
		//note : la largeur du trou exclue la bordure

		var nLargeurTrou = this.nLargeurChampOnglet-jqTrou[0].nLargeurTotaleLibelle-jqTrou[0].nBordure-1;//-1 pour des probl�mes de pr�cisions
		var nLargeurChacun = -1;//-1 indiquant qu'il faut r�cup�rer data("width-adaptee")
		if (nLargeurTrou<0)
		{
			//r�partition de la largeur (moins 1 pour laisser 1px pour le td de trou)
			nLargeurChacun = parseInt((this.nLargeurChampOnglet-1)/this.jqFreresLibelleVisible.length) - (jqTrou[0].bMode3Images ? 16*2 : 0);// moins la gauche et droite du 3 images
			//et le trou � 0
			nLargeurTrou=0;
		}
		
		//attribut la largeur calcul�e
		this.jqFreresLibelleVisible.each(function()
		{ 
			var jqTdLibelle=$(this); 
			jqTdLibelle			
			var nLargeurAppliquer = nLargeurChacun>0 ? nLargeurChacun : this.jqLibelle.data("width-adaptee");
			//jqTdLibelle.css("width",nLargeurAppliquer); 
			this.jqLibelle.css("width",nLargeurAppliquer);
		})
		;
		
		//�vite de voir le dessin interm�diaire
		this.jqFreresLibelleVisible.css({opacity:1});
		
		if (!b1erePhase)
		{
			this.jqFreresLibelleVisible.removeClass("t-0");
		}

		//et trou au reste
		jqTrou.css("width",nLargeurTrou).children().css("width",nLargeurTrou);
		
		//Ancrage en hauteur du trou 		
		if (this.jqChampOnglet.attr("id") === undefined)//cas de table interne
		{
			var jqTrParent = jqTrou.parent();
			var nHauteurManquant = this.jqChampOnglet.parent().height() - this.jqChampOnglet.height();
			if (nHauteurManquant>2)//si l'ancrage actuel n'est pas appliqu� par le navigateur (car sous IE Quirks le height 100% ici fonctionne)
				jqTrParent.css("height",nHauteurManquant);
		}	

		this.b1erCalculDejaiFait = true;

		!fCallbackFinPhase || fCallbackFinPhase(this.jqChampOnglet);
	})
	;
	!fCallbackFinPhase || fCallbackFinPhase();
	$(document.body).removeClass("wbOverflowHiddenX");	
	});
	});
});
}

function onRelanceMajLarjeurTrouVolet(event,bForceSynchrone)
{
    //applique l'ancrage pour IE avec le d�lai, et d�clenche l'�v�nement de resize afin d'�tre s�r d'�tre le premier �v�nements de resize
    var fRaf = (bForceSynchrone || (event && event.type && event.isTrigger)) ? function(f){f();return undefined/*et non true vu qu'il n'y a pas de blocage*/;} : setTimeout;
	var f2ndePhase = function(msTime)
    {
        /*window["MajLargeurTrouVoletTimer"] =*/ 
        window["MajLargeurTrouVoletEnCours2ndePhaseTimer"] = fRaf(function()
        {					
            MajLargeurTrouVolet(false,bForceSynchrone,function(jqChampOnglet){ 
            	if (!jqChampOnglet) window["MajLargeurTrouVoletEnCours"]=undefined; 
            	else $(window).trigger("trigger.wb.updateLayoutSuperposableEpingle",[jqChampOnglet,true]);
        	});            
        },msTime||100);			   
	};

	if (window["MajLargeurTrouVoletEnCours"]===true)
	{
		//en train d'attendre la 2nde phase ?
		if (window["MajLargeurTrouVoletEnCours2ndePhaseTimer"])
		{
			//on prolonge l'attente
			clearTimeout(window["MajLargeurTrouVoletEnCours2ndePhaseTimer"]);
			f2ndePhase(150);//plus long apr�s

		}
		return;
	}

    window["MajLargeurTrouVoletEnCours"]=true;
	
	//SUGG : passe tout en absolute pendant le resize plut�t ? ou dans un div overflow:hidden qui permet le resize petit comme grand ?

	//1�re phase imm�diate
	bForceSynchrone = bForceSynchrone || (event && event.type == "wbOngletVisible");
    MajLargeurTrouVolet(true,bForceSynchrone,f2ndePhase);		
}

//en cas de mise � jour de html par ajax
if (window["clWDUtil"]!==undefined) 
{
	if (clWDUtil.m_oNotificationsAjoutHTML)
	{
		clWDUtil.m_oNotificationsAjoutHTML.AddNotification(function(){ onRelanceMajLarjeurTrouVolet(undefined,true); } );
	}
	if (clWDUtil.m_oNotificationsFinAJAX)
	{
		clWDUtil.m_oNotificationsFinAJAX.AddNotification(function(){ onRelanceMajLarjeurTrouVolet(undefined,true); });
	}
}

//en cas de resize 
$(window).bind("wbOngletVisible resize.wb.onglet.onRelanceMajLarjeurTrouVolet",function(event){

	//ignore le resize lanc� par trigger, il faut passer par wbOngletVisible pour �a
	if (event && event.type == "resize" && event.isTrigger)
	{
		return;
	}

	onRelanceMajLarjeurTrouVolet(event, event && event.type == "wbOngletVisible"  );

});

// //apr�s un affichage de popup
// $(window).bind("trigger.wb.postUpdateLayoutSuperposableEpingle.apparition",function(event,domParent)
// {
// 	$(".WDOT").each(function()
// 	{
// 		//si je suis fils de domParent alors 
// 		if (clWDUtil.bEstFils(this ,domParent))
// 		{
// 			onRelanceMajLarjeurTrouVolet(null, true);
// 		}
// 	});	
// });

//1er appel
onRelanceMajLarjeurTrouVolet();

});

});