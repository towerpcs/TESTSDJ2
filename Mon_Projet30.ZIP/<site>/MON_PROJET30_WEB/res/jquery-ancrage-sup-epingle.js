/*! VersionVI: yyyyyyyyyyyy */
// 26.0.1.0 jquery-ancrage-sup-epingle.js

///#DEBUG=clWDUtil.WDDebug

//OPTIM remplacer les attr("data par data( pour clarifier le DOM
//TODO debug du cas de plans avec que des superposables, du coup on perd la valeur du plan courant
//RWD sugg : texte proportionnel : window.addEventListener('resize', function(){ document.documentElement.style.fontSize = (16*$("#page").width()/$("#page").data("width")) + 'px'; }, false);

ANCRAGE_SUPEPINGLE_SYNC_DEFAUT = bEdge || bIEAvec11; 
function tween(dAvant,dApres,dNow)
{
	//return dAvant + (dApres-dAvant) * dNow;
	//comme en java
	var retour = dApres * dNow + (1-dNow) * dAvant;
	if (Math.abs(retour)<0.1)//évite de tomber dans l'écritue scientifique Xe-Y
		return Math.round(retour*10000000000)/10000000000;
	return retour;
}

//M�morise la position du scroll
$(function() {
	//uniquement en responsive
	var bPageResponsive = clWDUtil.bRWD;
	if (!bPageResponsive) return;

	var _bIEAvec11OuEdge = (
	(		(-1 == navigator.userAgent.toLowerCase().indexOf("opera"))
		&& 	(-1 != navigator.appName.indexOf("Microsoft"))
	)
	||	(-1 != navigator.userAgent.indexOf("Trident/"))
	||  (-1 != navigator.userAgent.toLowerCase().indexOf("edge/"))
	);
	if (_bIEAvec11OuEdge)
	{
		//retire l'overflow sur le html car cela empêche de trigger le scroll sur window
		$("html").css("overflow-x","visible");
	}

    var jqChamp1erVisible;
    var nOffset = 0;
    var nWidthOri = 0;

    function memPos()
    {
    	//variables de sortie pour le 1er champ visible
        jqChamp1erVisible=undefined;
        nOffset = 0;

        //le bord haut (scrolltop) ne change pas pendant l'exécution de memPos
        var nBordHautNavigateur = window.nBordHautNavigateur!==undefined ? window.nBordHautNavigateur : $(document).scrollTop();

        //$("[class^='clearfix pos']:not(.wbEpingle *)").each(function()//optim � faire ?
        function testEnProfondeur(jqChamp)
        {
        	//ignore la branche à partir d'un épinglé
        	if (jqChamp.css("position")=="fixed")
    		{
    			//ignore le champ et ses fils
    			return -1;
    		}
    		var nBordHautChamp = jqChamp.offset().top;
    		//début au dessus du navigateur
        	if (nBordHautChamp<=nBordHautNavigateur)
    		{
    			//donc pas le premier visible
    			//mais peut être un de ses fils

	    		var nHauteurChamp = jqChamp.is(":visible") ? jqChamp.height() : 0;
	    		//fin au dessus du navigateur
	        	if (nBordHautChamp+nHauteurChamp<=nBordHautNavigateur)
	    		{
	    			//ignore le champ et ses fils
	    			return -1;
	    		}

	    		//un de ses fils est peut être le premier visible
	    		var domSuivant = jqChamp[0].querySelector(".clearfix");
	        	return domSuivant ? parcoursFreres.apply(domSuivant) : false;
    		}
    		//son début est dans la partie visible, c'est le premier visible
            jqChamp1erVisible = jqChamp;
            nWidthOri = $(window).width();
            nOffset = (nBordHautChamp-nBordHautNavigateur);
    		return true;
        }

        function parcoursFreres()
        {
        	var jqChamp = $(this);
        	var nRes = (testEnProfondeur(jqChamp));
        	if (nRes===true)
    		{
    			//trouvé
    			return true;
    		}
    		if (nRes===-1)
			{
				//ignore le champ et ses fils
				return false;
			}
        	//parcourt les frères
        	var bRetour = false;
        	jqChamp.nextAll(".clearfix").each(function(){
        		bRetour = parcoursFreres.apply(this);
        		//si trouvé, arrête le parcours
        		if(bRetour)
    			{
    				return false;
    			}
        	});
        	return bRetour;
        }

        //commence à partir de la page
        testEnProfondeur($(document.getElementById("page")));
    }
    //1�re m�morisation de position
    memPos();
    function keepPos()
    {
        if (jqChamp1erVisible && nWidthOri != $(window).width())
    	{
    		var f = function(){$(document).scrollTop(jqChamp1erVisible.offset().top-nOffset);        };
    		window.requestAnimationFrame ? requestAnimationFrame(f) : setTimeout(f,1);
    	}
        //memPos(); inutile car le scrollTop d�clenchera l'�v�nement de scroll qui appelera memPos apr�s d�lai
    }

    var nTimerScroll = undefined;
    $(window)
    .scroll(function()
    {
        if (nTimerScroll)
        {
            clearTimeout(nTimerScroll);
        }
        nTimerScroll = setTimeout(memPos,1000);
    })
    .on("trigger.wb.rwd.tranche.changement",keepPos);

});

//Gestion WB des tranches
$.wb = {
	//pile des medias en cours
	stackMedia : []
	//tableau de slisteners de chaque champ ayant un data-media
,	tabListeners : { }
	//tableau des @media
,	tabAllMediaOrdreDeDeclaration : []
	//indice de la tranche active la plus spécifique
,	nGetTrancheActiveIndiceWL : function(bSensDepuisDefautEgal1)
	{
			$(window).trigger("trigger.wb.rwd.media.charge");
			return (bSensDepuisDefautEgal1!==false
						? 		this.stackMedia.length
						:  		this.tabAllMediaOrdreDeDeclaration.length-this.stackMedia.length) + 1
			;
	}
};

//uniquement en rwd
var fRwdInit = (!clWDUtil.bRWD || !window.matchMedia) ? undefined : function(oEvent,bPremierChargement,bOnResize)//SUGG OPTIM déplacer le load à DOMContentLoaded via DOMContentLoaded.rwd.media ?
{
	//r?cup?re ls balises avec data-media et cr?? les listener pour chacune de leur query
	var mq = window.matchMedia;

	$("[data-media]").each(function()
	{
		var jqBalise = $(this);
		if (!jqBalise.attr("data-media")) return;
		var tabMedia = jqBalise.wbJsonParseAttr("data-media");
		if (!tabMedia || tabMedia.length==0)
		{
			return;
		}

		jqBalise.data('media',tabMedia);

		jqBalise.removeAttr('data-media');

		for(var iMedia=0; iMedia<tabMedia.length; ++iMedia)
		{
			var oMedia = tabMedia[iMedia];
			if (
				//pas de media query ?
				!oMedia.query
			||	//ni data ni attr ?
				(!oMedia.attr || oMedia.attr.length==0)// || !Modernizr.mq(oMedia.query.replace("@media ","")))
			){
				continue;
			}
			var sQuery = oMedia.query.replace("@media ","");//retire le @media qui bloque window.matchMedia

			if (!$.wb.tabListeners[sQuery])
			{
				$.wb.tabListeners[sQuery] = [];
				$.wb.tabAllMediaOrdreDeDeclaration.push(sQuery);
			}

			$.wb.tabListeners[sQuery].push(
			{
				 attr : oMedia.attr
				,iMedia : iMedia
				,balise : jqBalise
				,callback : function(bMatches)
				{
					//sauve la valeur init
					this.fSauveOri();
					//attr
					for(sData in this.attr)
					{
						if (!this.attr.hasOwnProperty(sData))
						{
							continue;
						}
						var bRetourOri = false;
						var sNouvelleValeur = undefined;
						if (bMatches)
						{
							var sPrefixe = "";
							//concat avec l'ori ?
							if (this.balise.attr(sData + "Concat")==="true" || this.balise.attr("data-" + sData + "Concat")==="true")
							{
								sNouvelleValeur = this.balise.data("attr-" + sData+ "-ori");
								var sRemove;
								if (sRemove=(this.balise.attr(sData + "Remove") || this.balise.attr("data-" + sData + "Remove")))
								{
									sNouvelleValeur = sNouvelleValeur.replace(new RegExp("("+ sRemove + ")","g"),"");
								}
								sNouvelleValeur +=  " " + this.attr[sData];
								sNouvelleValeur = sNouvelleValeur.replace(/  /g,' ').trim();
							}
							else
							{
								//note : this.attr[sData] peut être un objet
								sNouvelleValeur = this.attr[sData];
							}
						}
						else
						{
							//restaure la valeur init
							if (this.balise.data("attr-"+sData+ "-ori")!==undefined)
							{
								sNouvelleValeur = this.balise.data("attr-"+sData+ "-ori");
								bRetourOri=true;
							}
						}
						var fCallback = this.balise.data("wbMediaAttrCallback");
						if (fCallback!==undefined)
						{
							sNouvelleValeur = fCallback(this,bMatches,sData,sNouvelleValeur);
						}
						if (sNouvelleValeur!==undefined)
						{
							if (sData=="style" && (this.balise.hasClass("fixedcoulisse")))
							{
								//blindage : coulissot non dispo en RWD
								continue;
							}

							//pour le style
							//il faut penser à reporter les modifications faites en code navigateur ou ajax d'une tranche à l'autre
							if (sData=="style")
							{
								try
								{
									//peu de propriétés sont visées, on les traite donc au cas par cas
									var sStyleInitial;
									//comparaison avec le style qui devrait être appliqué
									if (this.balise[0].iDerninierMedia===undefined)
									{
										//initial pour la tranche par défaut
										sStyleInitial = this.balise.data("attr-"+sData+ "-ori");
									}
									else
									{
										//initial pour cette tranche
										sStyleInitial = this.balise.data("media")[ this.balise[0].iDerninierMedia ].attr[sData];
									}
									//maj l'indice du dernier media appliqué sur le style
									this.balise[0].iDerninierMedia=(bMatches ? this.iMedia : undefined);

									//style, initialement dans cette tranche, en édition
									sStyleInitial = sStyleInitial.replace(/"/g,"'").replace(/;/g,'","').replace(/:/g,'":"');
									var oStyleInitial = sStyleInitial=="" ? {} : JSON.parse('{"' + sStyleInitial.substr(0,sStyleInitial.length-2) + '}');

									//style, finalement dans cette tranche, en exécution
									var sStyleActuel = this.balise.attr(sData).replace(/: /g,':').replace(/, /g,',').replace(/; /g,';');
									sStyleActuel = sStyleActuel.replace(/"/g,"'").replace(/;/g,'","').replace(/:/g,'":"');
									var oStyleActuel = sStyleActuel=="" ? {} : JSON.parse('{"' + sStyleActuel.substr(0,sStyleActuel.length-2) + '}');

									//force width 100% si le width est recalculé par js
									if (oStyleActuel.width && this.balise.hasClass("ancragefixedl")||this.balise.hasClass("ancragesupl"))
									{
										oStyleActuel.width = "100%";
									}
									if (oStyleActuel.height && this.balise.hasClass("ancragefixedh")||this.balise.hasClass("ancragesuph"))
									{
										oStyleActuel.height = "100%";
									}

									//set la nouvelle valeur
									this.balise.attr(sData,sNouvelleValeur);

									//style, à appliquer pour la prochaine tranche
									sNouvelleValeur = sNouvelleValeur.replace(/"/g,"'").replace(/;/g,'","').replace(/:/g,'":"');
									var oStyleNouveau = sNouvelleValeur=="" ? {} : JSON.parse('{"' + sNouvelleValeur.substr(0,sNouvelleValeur.length-2) + '}');

									//fait le diff uniquement si les modifs proviennent d'ailleurs
									//Donc pas de diff si les modifs provienent d'une sortie de tranche récupérant le data-style-ori
									//if (!this.balise.data('media').bRetourOriStyle)//VRAIMENT??
									{
										//diff
										var oBalise = this.balise;
										//a été modifié en code navigateur dans la tranche ?
										clWDUtil.bForEachIn(oStyleActuel, function(sProp/*, oValeur*/)
										{
											if (oStyleActuel.hasOwnProperty(sProp))
											{
												if  (oStyleNouveau[sProp]==oStyleInitial[sProp] && oStyleInitial[sProp]!=oStyleActuel[sProp] && !(oStyleInitial[sProp]=="0" && oStyleActuel[sProp]==="0px"))
												{
													//obj des modifications par wl
													if (!oBalise.data('media').oStyleModifViaProg)
													{
														oBalise.data('media').oStyleModifViaProg = {};
													}
													oBalise.data('media').oStyleModifViaProg[sProp] = oStyleActuel[sProp];
												}
											}
											return true;
										});
										//retiré par code navigateur
										clWDUtil.bForEachIn(oStyleInitial, function(sProp/*, oValeur*/)
										{
											if (oStyleInitial.hasOwnProperty(sProp) && !oStyleActuel.hasOwnProperty(sProp))
											{
												//obj des modifications par wl
												if (!oBalise.data('media').oStyleModifViaProg)
												{
													oBalise.data('media').oStyleModifViaProg = {};
												}
												//oStyleNouveau[sProp] = oStyleActuel[sProp];
												oBalise.data('media').oStyleModifViaProg[sProp] = "";
											}
											return true;
										});

										//obj des modifications par wl
										if (this.balise.data('media').oStyleModifViaProg)
										{
											//retiré par code navigateur après avoir été ajouté par le code navigateur
											clWDUtil.bForEachIn(this.balise.data('media').oStyleModifViaProg, function(sProp/*, oValeur*/)
											{
												if (oBalise.data('media').oStyleModifViaProg.hasOwnProperty(sProp) 												
													// la propriété n'est plus modifiée par programmation si on revient à sa valeur initiale
													// pas si elle est supprimée, car un display:none qui disparaît sous entend display:block 
													//&& !oStyleActuel.hasOwnProperty(sProp)
													&& oStyleInitial[sProp] == oStyleActuel[sProp]
												)
												{
													//oStyleNouveau[sProp] = oStyleActuel[sProp];
													oBalise.data('media').oStyleModifViaProg[sProp] = undefined;
												}
												return true;
											});

											//applique les modifications faites par prog WL
											this.balise.css(this.balise.data('media').oStyleModifViaProg);
										}
									}


									this.balise.data('media').bRetourOriStyle = bRetourOri;
									continue;
								}
								catch(e)
								{
									//console.log(e);
									clWDUtil.WDDebug.assert(false,e);
								}
							}

							//idée : Passer par .css() ?
							// if (sData=="style")
							// {
							// 	var tabStyles = sNouvelleValeur.split(";");
							// 	for(var iStyle=0; iStyle<tabStyles.length; ++iStyle)
							// 	{
							// 		var tabPropValeur = tabStyles[iStyle].split(":");
							// 		this.balise.css(tabPropValeur[0],tabPropValeur[1]);
							// 	}
							// }
							// else
							//
							if (sData.indexOf("data-")===0 || (sData in this.balise[0]) || sData=="class")//blinde un usage de src= sur un <td> + cas de class qui existe en tant que classList
							{
								this.balise.attr(sData,  (clWDUtil.isObject(sNouvelleValeur) ? JSON.stringify(sNouvelleValeur) : sNouvelleValeur));
							}
						}
					}
				}
				,fSauveOri : function()
				{
					//attr
					for(sData in this.attr)
					{
						if (!this.attr.hasOwnProperty(sData))
						{
							continue;
						}
						//cas du non renseign�
						if (this.balise.attr(sData)===undefined)
						{
							this.balise.data("attr-" + sData+ "-ori", "");
						}
						//sauve la valeur init
						else if (this.balise.attr(sData)!==undefined && this.balise.data("attr-" + sData + "-ori")===undefined)
						{

							this.balise.data("attr-" + sData+ "-ori", this.balise.attr(sData));
						}
					}
				}
			});
		}

		if (jqBalise.data('wbOnRemoveDataMedia'))
		{
			jqBalise.data('wbOnRemoveDataMedia')();
			jqBalise.data('wbOnRemoveDataMedia',undefined);
		}

	});
	//cas de post traitement apr�s remise des data pour ce @media
	function postWatchMedia(sQuery,bOnResize)
	{
		//les champs �pingl�s et superposables vont se mettre � jour par le resize,
		//mais au cas o� on peut le forcer ici
		//FORCE SYNCHRONE POUR EVITER LE CLIGNOTTEMENT
		// => sugg revoir pourquoi ce clignottement
		// (et voir si  __OnScrollResize ne devrait pas être sur l'écoute de postUpdateLayoutSuperposableEpingle)
		UpdateLayoutSuperposableEpingle(undefined,true);

		//diffère afin de traiter tous les changements de media avant de notifier __OnScrollResize
		if (window["trigger.wb.rwd.media.postWatchMedia.timer"])
		{
			cancelAnimationFrame(window["trigger.wb.rwd.media.postWatchMedia.timer"]);
		}

		//évite la réentrance, car on vient déjà depuis cet appel
		if (!bOnResize)
		{
			//onscroll resize semble permettre le cas de champs superposables ancrés
			//contenant des champs comme le champ Table qui ont besoin de __OnScrollResize
			//pour réorganiserleur contenu
			window["trigger.wb.rwd.media.postWatchMedia.timer"]=requestAnimationFrame(function(){clWDUtil.__OnScrollResize(undefined, false);});
		}
	}
	function callListeners(sMedia,bMatches)
	{
		var sMediaCorrige = sMedia.replace(/ /g,'');
		//on quitte ce media mais il y en a un autre, il faut donc l'appeler pour remettre ses valeurs
		for(sQuery in $.wb.tabListeners)
		{
			if (!$.wb.tabListeners.hasOwnProperty(sQuery))
			{
				continue;
			}
			if (sQuery.replace(/ /g,'') == sMediaCorrige)//car MQ.media n'est pas exactement le media mais sa version comput�e
			{
				for(var i=0; i<$.wb.tabListeners[sQuery].length; ++i)
				{
					//inutile de d�sactiver un media qui n'�tait pas actif
					if (!bMatches && $.wb.stackMedia.indexOf(sMediaCorrige)===-1)
					{
						$.wb.tabListeners[sQuery][i].fSauveOri.apply($.wb.tabListeners[sQuery][i]);
					}
					else
					{
						$.wb.tabListeners[sQuery][i].callback.apply($.wb.tabListeners[sQuery][i],[bMatches]);
					}
				}
				break;
			}
		}
		return sQuery;
	}
	var fAppelTrancheInitiale = undefined;
	var sMediaCallInit = undefined;
	for(var i=0; i<$.wb.tabAllMediaOrdreDeDeclaration.length; ++i)
	//for(sQuery in $.wb.tabListeners)
	{
		var sQuery = $.wb.tabAllMediaOrdreDeDeclaration[i];
		var mql = mq(sQuery);
		var bDernierMedia = i+1==$.wb.tabAllMediaOrdreDeDeclaration.length;
		var tmpFonc = function(oMediaQueryList,bAppelForcePour1erAffichage)
		{
			if (!oMediaQueryList)
			{
				return;
			}
			var bMatches = oMediaQueryList.matches;
			var sMediaCourant = oMediaQueryList.media.replace(/ /g,'');
			//applique ou d�sappliqe les valeurs du media
			var sMediaCall = callListeners(sMediaCourant,bMatches);
			if (bMatches)
			{
				//évite de stacker 2 fois le même media
				if ($.wb.stackMedia.indexOf(sMediaCourant)===-1)
				{
					$.wb.stackMedia.push(sMediaCourant);
				}
			}
			else if ($.wb.stackMedia.length)
			{
				var bEstDernierDuStack = sMediaCourant == $.wb.stackMedia[$.wb.stackMedia.length-1];
				var stackMediaRestant = [];
				//cas o� on a plusieurs fois le m�me empil� (empirique : bug du navigateur a priori)
				for(var i=0; i<$.wb.stackMedia.length; ++i)
				{
					if (sMediaCourant == $.wb.stackMedia[i])
					{
						//ce media n'est plus valide
					}
					else
					{
						stackMediaRestant.push($.wb.stackMedia[i]);
					}
				}
				//on quitte ce media mais il y en a un autre, il faut donc l'appeler pour remettre ses valeurs
				//si $.wb.stackMedia est vide, alors le callListeners appel� plus haut suffit
				//et si on est sur le dernier du stack car sinon on a aucune certitude que ce media match
				//puis si l'avant dernier qu'on vient de callListeners ne match plus alors il sera appelé par le navigateur en !bMatch juste après
				if (stackMediaRestant.length && bEstDernierDuStack)
				{
					sMediaCall = callListeners(stackMediaRestant[stackMediaRestant.length-1],true);
				}

				$.wb.stackMedia = stackMediaRestant;

			}

			//appel les traitements d'après watch
			//en cas de changement réell de tranche
			//ou
			//en cas d'init du 1er affichage pour la dernière tranche qui n'est toujours pas active
			if (!bAppelForcePour1erAffichage || (!bMatches && bDernierMedia && !fAppelTrancheInitiale))
			{
				//traitement apr�s watchMedia
				postWatchMedia(sMediaCall,bOnResize);
			}
///#DEBUG
			console.log($.wb.stackMedia);
///#ENDDEBUG

			//cas de changement de tranche par redimensionnement (que l'on rentre ou sorte de la tranche)
			//ou
			//cas d'appel du 1er affichage et cette tranche est active (on rentre dans cette tranche)
			if (!bAppelForcePour1erAffichage || bMatches)
			{
				//déclenchera la notif
				var fAppelTranche = function()
				{
					if (window.NSPCS)//blindage
					{
						// Notifie aussi de la modification du HTML de la page
						NSPCS.NSUtil.ms_oNotificationsChangementTranche.LanceNotifications(oMediaQueryList, $.wb.nGetTrancheActiveIndiceWL());
					}
					$(window).trigger("trigger.wb.rwd.tranche.changement",oMediaQueryList);
				};
				//cas d'appel du 1er affichage et cette tranche est active
				if (bAppelForcePour1erAffichage)
				{
					sMediaCallInit = sMediaCall;
					//la notif se fera pour la tranche active la plus spécifique
					fAppelTrancheInitiale = function() { postWatchMedia(sMediaCallInit);	 fAppelTranche(); }
				}
				//cas de changement de tranche par redimensionnement
				else
				{
					//décale la notif pour un appel async
					//permet d'éviter trop d'appels lors du franchissement de plusieurs points de rupture de tranche
					if (requestAnimationFrame && cancelAnimationFrame)
					{
						if (window["trigger.wb.rwd.tranche.changement"])
						{
							cancelAnimationFrame(window["trigger.wb.rwd.tranche.changement"]);
						}
						window["trigger.wb.rwd.tranche.changement"]=requestAnimationFrame(fAppelTranche);
					}
					//appel direct de la notif
					else
					{
						fAppelTranche();
					}
				}
			}
		};
		if (bPremierChargement)
		{
			mql.addListener(tmpFonc);
		}
		//SUGG Option : ne pas appeler si �a ne matche pas ?
		tmpFonc(mql,true);
	}
	return fAppelTrancheInitiale;
};
if (fRwdInit)
$(window)
	.on("trigger.wb.rwd.media.reinit",function(){

		if (window["trigger.wb.rwd.media.reinit.timer"])
		{
			cancelAnimationFrame(window["trigger.wb.rwd.media.reinit.timer"]);
		}
		window["trigger.wb.rwd.media.reinit.timer"]=requestAnimationFrame(function(){fRwdInit(undefined,false,true);});
	})
	.oneOfThem("load.rwd.media trigger.wb.rwd.media.charge",function()
	{
		//Reinit le RWD qui peut venir dans le plan différé
		function fOnModifHTML () { $(window).trigger("trigger.wb.rwd.media.reinit"); }
		//cas de ZRAjoute en AJAX
		if (window.NSPCS)
		{
			// Notifie aussi de la modification du HTML de la page
			NSPCS.NSUtil.ms_oNotificationsAjoutHTML.AddNotification(fOnModifHTML);
		}
		if (clWDUtil.m_oNotificationsAjoutHTML)
		{
			clWDUtil.m_oNotificationsAjoutHTML.AddNotification(fOnModifHTML);
		}

		var fAppelTrancheInitiale = fRwdInit(undefined,true);

		//appel de la tranche active la plus spécifique
		if (fAppelTrancheInitiale)
		{
			fAppelTrancheInitiale();
		}
		//remet l'overflow visible
		$(".wbRwd").css("overflow","visible");
		//pas 1 match au 1er affichage ?
		if ($.wb.stackMedia.length==0 && window.NSPCS)
		{
			// Notifie aussi de la modification du HTML de la page
			NSPCS.NSUtil.ms_oNotificationsChangementTranche.LanceNotifications(undefined, $.wb.nGetTrancheActiveIndiceWL());
		}
	})
;
//POSITION des champs superpos�s ou �pingl�s dans une page RWD
//le data style contient le style tel qu'il est g�n�r� pour le point de rupture
//il faut le convertir dans style= proportionnellement
//ex: style="left:100px;" alors que le conteneur de r�f�rence a un data-width=500 => implique un left:20%
//TODO OPTIM éviter les layout intermédiaire en faisant en 2 passes (1 lecture, 1 écriture)
function UpdatePositionRWD(jqChamp,jqConteneur,bSynchrone)
{
	if (bSynchrone===undefined) bSynchrone = ANCRAGE_SUPEPINGLE_SYNC_DEFAUT;
	var fRaf = bSynchrone ? function(f){f();return undefined/*et non true vu qu'il n'y a pas de blocage*/;} : requestAnimationFrame;
	if (jqChamp[0].rafUpdatePositionRWD) return;//évite double appel
	
	if (!jqChamp.is(":visible")) return;//évite sur les champs invisibles (optim utile pour les champs dans les plans inactifs)

	if (jqChamp[0].wbancrageattachex===undefined) jqChamp[0].wbancrageattachex=jqChamp.hasClass("wbancrageattachex");
	if (jqChamp[0].ancragesupl===undefined) jqChamp[0].ancragesupl=jqChamp.hasClass("ancragesupl");

	var oData = jqChamp.data("style");
	var oAttr = jqChamp.attr("style");
	//déjà traitée ?
	if (oData!==undefined && oData==oAttr)
	{
		return;
	}

	var tabProprietesValeurs = oAttr.split(";");
	var nIndiceTranche = $.wb.nGetTrancheActiveIndiceWL();
	var oValeursCSSActuelles = {};
	//raz le style pour �viter qu'un media d�finisse une propri�t� tandis que l'autre compte sur la valeur par d�faut
	if (!jqChamp[0].oValeursCSSQuandStyleVide) jqChamp[0].oValeursCSSQuandStyleVide = jqChamp[0].oValeursCSSQuandStyleVide = [];
	if (!jqChamp[0].oValeursCSSQuandStyleVide[nIndiceTranche]) 
	{
		// raz à l'exception de visibility afin d'éviter de clignotter 
		var bMasqueParDefaut = tabProprietesValeurs.indexOf('visibility:hidden')>-1;
		jqChamp.attr("style", bMasqueParDefaut ? 'visibility:hidden;' : '');
		if (bMasqueParDefaut) 
		{
			oValeursCSSActuelles['position'] = jqChamp[0].style.position; // TODO dans quel cas la visibilité par défaut avec style= vide serait autre?
			oValeursCSSActuelles['visibility'] = 'visible'; // TODO dans quel cas la visibilité par défaut avec style= vide serait autre?
			jqChamp.attr("style", 'position:absolute;visibility:hidden;');
		}
		else 
			jqChamp.attr("style", '');
	}

	//console.log("avant " + jqChamp[0].rafUpdatePositionRWD);
	if (jqChamp[0].rafUpdatePositionRWD!==undefined)
	{
		cancelAnimationFrame(jqChamp[0].rafUpdatePositionRWD);
	}
	jqChamp[0].rafUpdatePositionRWD = fRaf(function(){

	if (!jqChamp[0].oValeursCSSQuandStyleVide[nIndiceTranche])
	{
		jqChamp[0].oValeursCSSQuandStyleVide[nIndiceTranche] = oValeursCSSActuelles; // pre init
		for(var iProp=0; iProp<tabProprietesValeurs.length; ++iProp)
		{
			var tabUnePropVal = tabProprietesValeurs[iProp].split(':');
			//cas du ; final
			if (tabUnePropVal.length<2)
			{
				continue;
			}
			var sProp = tabUnePropVal[0].trim().toLowerCase();
			jqChamp[0].oValeursCSSQuandStyleVide[nIndiceTranche][sProp] = jqChamp.css(sProp);
		}
	}
	oValeursCSSActuelles = jqChamp[0].oValeursCSSQuandStyleVide[nIndiceTranche];

	//requestAnimationFrame(function(){
	var oNouvellesInfosCSS = "";

	var bCentre = false;
	//1ère passe pour savoir le champ est centré
	for(var iProp=0; iProp<tabProprietesValeurs.length; ++iProp)
	{
		var tabUnePropVal = tabProprietesValeurs[iProp].split(':');
		//cas du ; final
		if (tabUnePropVal.length<2)
		{
			continue;
		}
		var sProp = tabUnePropVal[0].trim().toLowerCase();
		if (sProp == "left")
		{
			var sValeur = tabUnePropVal[1].trim();
			bCentre = sValeur=="50%";
			break;
		}
	}

	for(var iProp=0; iProp<tabProprietesValeurs.length; ++iProp)
	{
		var tabUnePropVal = tabProprietesValeurs[iProp].split(':');
		//cas du ; final
		if (tabUnePropVal.length<2)
		{
			continue;
		}
		var sProp = tabUnePropVal[0].trim().toLowerCase();
		//cas des propri�t�s trait�es : margin-left, margin-right, left et right (attention, le raccourci margin n'est pas trait�)
		var bTraiteesAvecProportion = !jqChamp[0].wbancrageattachex && (sProp.indexOf('left')>-1 ||  sProp.indexOf('right')>-1);
		//cas particulier de la marge qui décale de la moitié de la largeur du champ
		//Pas de proportion si la marge est fixe et la largeur du champ est fixe
		if (bTraiteesAvecProportion && sProp == "margin-left")
		{
			bTraiteesAvecProportion	= (jqChamp[0].ancragesupl || !bCentre);
		}
		//les autres propri�t�s sont � copier/coller. Celles de dimesions pourront �tre �cras�es ensuite par l'ancrage
		/*
		var bTraiteesSansProportion = !bTraiteesAvecProportion && (sProp.indexOf('top')>-1 ||  sProp.indexOf('bottom')>-1 ||  sProp.indexOf('width')>-1 ||  sProp.indexOf('height')>-1);
		if (!bTraiteesAvecProportion && !bTraiteesSansProportion)
		{
			jqChamp.css(sProp,sValeur);
			continue;
		}
		*/
		var sValeur = tabUnePropVal[1].trim();
		//var sValeurCourante = jqChamp.css(sProp);
		var sValeurCourante = oValeursCSSActuelles[sProp];
		//applique la valeur telle quelle
		if (!bTraiteesAvecProportion || sValeur=="auto")
		{
			//jqChamp.css(sProp,sValeur);
			oNouvellesInfosCSS += sProp+":"+sValeur+";";
			continue;
		}

		var bPourcentage = sValeur.indexOf("%")>0;
		var bPourcentageCourant = sValeurCourante.indexOf("%")>0;
		//d�j� la valeur relative
		if (bPourcentageCourant && bPourcentage && sValeurCourante == sValeur)
		{
			continue;
		}
		if (bPourcentage)
		{
			sValeur = jqConteneur.attr('data-width') * parseFloat(sValeur)/100;
		}
		sValeur = (100*(parseFloat(sValeur) / parseInt(jqConteneur.attr('data-width'),10))) + "%";
		//si c'est un pourcentage alors on peut le laisser tel quel
		if (bPourcentage && sValeurCourante==sValeur)
		{
			continue;
		}
		//sinon il faut appliquer le ratio
		//jqChamp.css(sProp,sValeur);
		oNouvellesInfosCSS+= sProp+":"+sValeur+";"
	}

	fRaf(function(){

	jqChamp.attr("style",oNouvellesInfosCSS);
	//maj le data-style pour ne plus refaire cette conversion (jusqu'au prochain changement de media qui remettra le style
	jqChamp.data("style",oNouvellesInfosCSS);

	//console.log("fin " + jqChamp[0].rafUpdatePositionRWD);
	jqChamp[0].rafUpdatePositionRWD=undefined;
	});
	//});
	});
	//console.log("apres " + jqChamp[0].rafUpdatePositionRWD);
}
//TODO OPTIM en 2 passe, une lecture et une écriture plutôt que les 2 faites champ par champ
function UpdateLayoutSuperposableEpingle(jqListe,bSynchrone)
{
	if (bSynchrone===undefined) bSynchrone = ANCRAGE_SUPEPINGLE_SYNC_DEFAUT;
	var bPageResponsive = clWDUtil.bRWD;
	var fRaf = bSynchrone ? function(f){f();} : requestAnimationFrame;

	//la liste est soit le champ parent soit les éléments eux mêmes
	if (jqListe)
	{
		jqListe = jqListe.find('.ancragesuph, .ancragesupl, .ancragesuprwd, .ancragefixedh, .ancragefixedl, .ancragefixedrwd').add(jqListe);
	}

	//ancrages sur champs superposables
	(jqListe || $('.ancragesuph, .ancragesupl, .ancragesuprwd')).each(function()
	{
	//filtre les champs issus de galerie car c'est la galerie qui les envoie directement
	var jqChamp	= $(this);
	if (!jqListe && this.bUpdateLayoutSuperposableEpingleFiltre!==false)
	{
		if (this.bUpdateLayoutSuperposableEpingleFiltre===undefined)
		{
			this.bUpdateLayoutSuperposableEpingleFiltre = jqChamp.closest(".wbGalerie").length>0;
		}

		if (this.bUpdateLayoutSuperposableEpingleFiltre===true)
		{
			return;
		}
	}
	//le champ lui meme
	if (((this.cssPosition || (this.cssPosition = jqChamp.css("position"))) =="static") || jqChamp.attr("data-wbParallaxeChamp") || (jqChamp[0].oParallaxe&&(jqChamp[0].oParallaxe.dTauxHauteur||jqChamp[0].oParallaxe.dTauxY))) return;//blindage
	//le conteneur de reference d'agrandissement pour les champs superposable est le premier parent flagge avec la classe ancragesup ou en dernier lieu la page elle meme
	//var jqConteneur = jqChamp.parent().children('table').find('.ancragesupref').first();//ne trouve pas le ancragesupref sur le td d'un champ image derrirèe un <div débordement><table<tr><td ancragesupref>
	//TODO OPTIM conserver jqConteneur dans this
	var bEstPopup = jqChamp.hasClass("wbchamppopup");
	var jqConteneur = bEstPopup ? [] : jqChamp.siblings('.ancragesupref').add(jqChamp.siblings().not("[id^=dww]").find('#page,.ancragesupref')).first();//siblings pour ne pas chercher à l'intérieur de soi ou des autres superposables
	var sTag = jqConteneur.length ? jqConteneur[0].tagName.toLowerCase() : undefined;
	//ce n'est pas un champ lie a une reference ?
	var bSelonChampReference = jqConteneur.length===1;
	if (!bSelonChampReference)//=> alors on prend le conteneur (voire la page) comme reference
	{
		jqConteneur = bEstPopup ? $(document.getElementById("page")) : jqChamp.parents('.ancragesup,#page').first();
	}
	//cas du conteneur <table> car les data- sont peut etre sur le td
	if (!jqConteneur.attr("data-width") && !jqConteneur.attr("data-height"))
	{
		if (jqConteneur.length && jqConteneur.get(0).tagName.toLowerCase() == "table")
		{
			//trouve entre le champ est son conteneur .ancragesup la 1ère balise ayant les data
			//cela peut être le td du table.ancragesup
			//ou le 1er div de répétition d'une ZR ajax
			jqConteneur = jqChamp.parentsUntil(jqConteneur).filter("[data-width]").first();
		}
		//cas de l'input en ancragesupref mais dont le td possède les data-*
		else if (jqConteneur.parent().attr("data-width")!==undefined)//blindage
		{
			jqConteneur = jqConteneur.parent();
		}
		//blindage en utilisant la page
		if (!jqConteneur)
		{
			jqConteneur = jqChamp.parents('#page').first();
		}
	}
	//les champs superposables en RWD sont proporitionnels en positions
	//(sauf la popup car elle est positionnée par PopupAffiche => bEstPopup est un blindage car la popup ne doit jamais avoir ancragesuprwd)
	if (bPageResponsive && !bEstPopup && jqChamp.hasClass("ancragesuprwd"))
	{
		UpdatePositionRWD(jqChamp,jqConteneur,bSynchrone);
	}
	//ancrage en largeur sur champ superposable
	if (jqChamp.hasClass("ancragesupl"))
	{

		var nAgrandissement = 0;
		if (bSelonChampReference)
		{
			nAgrandissement = ( (sTag=='tr' || sTag=='td') ? jqConteneur.parents('table') : jqConteneur ).outerWidth()-parseInt(jqConteneur.attr('data-width'));
		}
		else
		{
			nAgrandissement = bEstPopup ? (parseInt(window.nLargeurNavigateur)-parseInt(jqChamp.attr('data-width'))) : jqConteneur.outerWidth()-parseInt(jqConteneur.attr('data-width'));
			if (bEstPopup)
			{
				//moins les marges gauche+droite
				nAgrandissement -= parseInt(jqChamp[0].style.marginLeft) + parseInt(jqChamp[0].style.marginRight);
			}			
		}

		fRaf(function(){
		var dProportion = 1;

		//l'ancrage ne doit pas �tre de 100% mais proportionnelle � l'�dition
		var dProportionEdition = parseInt(jqChamp.attr('data-width')) / parseInt(jqConteneur.attr(bEstPopup ? 'data-window-width' : 'data-width'));
		if (bPageResponsive)// && jqChamp.hasClass("ancragesuprwd")) => NON car seule la position doit être est modifiée par ancragesuprwd
		{
			dProportion = dProportionEdition;
		}

		//modifie la largeur en prenant
		fRaf(function(){
		jqChamp.css('width', dProportionEdition===1 ? '100%' :
		Math.round(Math.max(//round car les arrondis ne sont pas top...
		//soit la largeur min d'�dition
		 parseInt(jqChamp.attr('data-min-width')||0)
		 //soit la largeur d'�dition + l'agrnadissement du conteneur
		,parseInt(jqChamp.attr('data-width')) + (dProportion * nAgrandissement)
		)) + 'px'
		);
		});
		});
	}
	//ancrage en hauteur sur champ superposable
	if (jqChamp.hasClass("ancragesuph"))
	{
		fRaf(function(){
		var nAgrandissement = 0;
		if (bSelonChampReference)
		{
			nAgrandissement = ( (sTag=='tr' || sTag=='td') ? jqConteneur.parents('table') : jqConteneur ).outerHeight()-parseInt(jqConteneur.attr('data-height'));
		}
		else
		{
			nAgrandissement = bEstPopup ? (parseInt(window.nHauteurNavigateur)-parseInt(jqChamp.attr('data-height'))) : jqConteneur.outerHeight()-parseInt(jqConteneur.attr('data-height'));
			if (bEstPopup)
			{
				//moins les marges haut+bas 	
				nAgrandissement -= parseInt(jqChamp[0].style.marginTop) + parseInt(jqChamp[0].style.marginBottom);
			}
		}
		//modifie la hauteur en prenant le max entre
		fRaf(function(){
		jqChamp.css('height',
		Math.max(
		//la hauteur min d'�dition
		 parseInt(jqChamp.attr('data-min-height')||0)
		 //la hauteur d'�dition + l'agrnadissement du conteneur
		,parseInt(jqChamp.attr('data-height')) + nAgrandissement
		//en pixels
		) + 'px'
		);
		});
		});
	}
	});

	//ancrages sur champs �pingl�s
	(jqListe || $('.ancragefixedh, .ancragefixedl, .ancragefixedrwd')).each(function()
	{
	//le champ lui m�me
	var jqChamp	= $(this);
	if ( ((this.cssPosition || (this.cssPosition = jqChamp.css("position"))) =="static") || jqChamp.attr("data-wbParallaxeChamp") || (jqChamp[0].oParallaxe&&(jqChamp[0].oParallaxe.dTauxHauteur||jqChamp[0].oParallaxe.dTauxY)))
	{
		return;//blindage
	}
	//conteneur dont on prend la taille comme r�f�rence
	var jqConteneur = $('#page');
	if (bPageResponsive && jqChamp.hasClass("ancragefixedrwd"))
	{
		UpdatePositionRWD(jqChamp,jqConteneur,bSynchrone);
	}
	//ancrage en largeur sur champ �pingl�
	if (jqChamp.hasClass("ancragefixedl"))
	{
		//le conteneur de r�f�rence d'agrandissement pour les champs �pingl�s est la page ou le navigateur, selon que le champ est positionn� dans la page ou au bord du navigateur
		var nAgrandissement = 0;
		var dProportionEdition = parseInt(jqChamp.attr('data-width')) / parseInt(jqConteneur.attr('data-width'));
		var dProportion = 1;

		//optim cas 100% ? //QW#291700 en taille mobile devrait dire que c'est faux mais je ne vois pas pourquoi...
		if (dProportionEdition===1)
		{
			jqChamp.css('width', '100%');
		}
		else
		{
			fRaf(function(){
			if ((("x"+jqChamp.css("left")).substr(-1) == "x")||(("x"+jqChamp.css("right")).substr(-1) == "x"))
			{
				nAgrandissement = document.body.clientWidth/*$(window).width()*/ - parseInt(jqConteneur.attr('data-window-width'));
			}
			else
			{
				nAgrandissement = jqConteneur.outerWidth() - parseInt(jqConteneur.attr('data-width'));
			}
			//l'ancrage ne doit pas �tre de 100% mais proportionnelle � l'�dition
			if (bPageResponsive)// && jqChamp.hasClass("ancragesuprwd")) => NON car seule la position doit être est modifiée par ancragesuprwd
			{
				dProportion = dProportionEdition;
			}
			fRaf(function(){
			//modifie la largeur en prenant le max entre
			jqChamp.css('width',
			Math.max(
			//la largeur min d'�dition
			 parseInt(jqChamp.attr('data-min-width')||0)
			 //la largeur d'�dition + l'agrnadissement du conteneur
			,parseInt(jqChamp.attr('data-width')) + (dProportion * nAgrandissement)
			) + 'px'
			);
			});
			});
		}
	}
	//ancrage en hauteur sur champ �pingl�
	if (jqChamp.hasClass("ancragefixedh"))
	{
		fRaf(function(){
		//le conteneur de r�f�rence d'agrandissement pour les champs �pingl�s est la page ou le navigateur, selon que le champ est positionn� dans la page ou au bord du navigateur
		var nAgrandissement = 0;
		if ((("x"+jqChamp.css("top")).substr(-1) == "x")||(("x"+jqChamp.css("bottom")).substr(-1) == "x"))
		{
			nAgrandissement = $(window).height() - parseInt(jqConteneur.attr('data-window-height'));
		}
		else
		{
			nAgrandissement = jqConteneur.outerHeight() - parseInt(jqConteneur.attr('data-height'));
		}
		fRaf(function(){
		//modifie la hauteur en prenant
		jqChamp.css('height',
		Math.max(
		//soit la hauteur min d'�dition
		 parseInt(jqChamp.attr('data-min-height')||0)
		//soit la hauteur d'�dition + l'agrnadissement du conteneur
		,parseInt(jqChamp.attr('data-height')) + nAgrandissement
		//en pixels
		) + 'px'
		);
		});
		});
	}
	});
	$(window).trigger("trigger.wb.postUpdateLayoutSuperposableEpingle");
}

// Evite d'appeler le redimensionnement des champs superposables en RWD car ce sera fait par le changement de tranche
$(window).on(  ((window["clWDUtil"] && clWDUtil.bRWD) ? "" : "resize ") + "trigger.wb.updateLayoutSuperposableEpingle",function(jqEvent,jqBalise,bSynchrone){ UpdateLayoutSuperposableEpingle(jqBalise,bSynchrone) });
//un premier appel pour effectuer les ancrage, mais l�g�rement d�cal� pour que cela se produise apr�s le premier paint d'IE
//et envoie la notification
//sauf en rwd car la tranche fera l'appel
if (!(window["clWDUtil"] && clWDUtil.bRWD)) $().ready(function() { setTimeout(function()
{
	UpdateLayoutSuperposableEpingle();
	if (window["clWDUtil"])
	{
		clWDUtil.__OnScrollResize(undefined, false);
	}
},10);
});

var fNotifRecalculLayoutSuperposable = function(oWDObjet, domBalise)
{
	UpdateLayoutSuperposableEpingle(
		$(domBalise).find(".ancragesuph, .ancragesupl, .ancragesuprwd, .ancragefixedh, .ancragefixedl, .ancragefixedrwd")
	);
};
//cas de ZRAjoute en AJAX => du nouveau HTML donc des nouveaux ancrages à calculer
if (window.NSPCS)
{	
	// Notifie aussi de la modification du HTML de la page
	NSPCS.NSUtil.ms_oNotificationsAjoutHTML.AddNotification(fNotifRecalculLayoutSuperposable);
	//NSPCS.NSUtil.ms_oNotificationsFinAJAX.AddNotification(fNotifRecalculLayoutSuperposable);
	//changement de tranche => ré init les globales de tailles min
	//NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(fNotifRecalculLayoutSuperposable);
}
//en cas de mise à jour de html par ajax
if (window["clWDUtil"]!==undefined)
{
	if (clWDUtil.m_oNotificationsAjoutHTML)
	{
		clWDUtil.m_oNotificationsAjoutHTML.AddNotification(fNotifRecalculLayoutSuperposable);
	}
	// if (clWDUtil.m_oNotificationsFinAJAX)
	// {
	// 	clWDUtil.m_oNotificationsFinAJAX.AddNotification(fNotifRecalculLayoutSuperposable);
	// }
}

/////////////////////////////////////////////////////////////////////
///////////////////////////// PLAN //////////////////////////////////
/////////////////////////////////////////////////////////////////////
// oOption {
//   bSensCorrectionIncrement: undefined
//  ,bBoucle : undefined
//  ,fCallback : undefined
// }
$.fn.wbPlanSet = function(sNumero,oOption) {

	if (!oOption) oOption = {};
	var bSensCorrectionIncrement = oOption.bSensCorrectionIncrement;
	var bBoucle = oOption.bBoucle;
	var fCallback = oOption.fCallback;
	var sContenuHTML = oOption.sContenuHTML;//dans le cas d'une modification de ..Plan en AJAX le contenu est fourni
	if (!bBoucle) bBoucle=false;

	var jqChamp = this.wbPlanGetInstance();
	if (!jqChamp)
	{	//non trouvé
		return;
	}
	//travaille avec un numéro entier
	var nNumero = parseInt(sNumero,10);

	//en cas d'enchaînement rapide de plan pendant l'animation
	if (jqChamp.queue().length>0)
	{
		jqChamp[0].wbPlanSuivant = sNumero;
		jqChamp[0].wbPlanSuivantOption = oOption;
		jqChamp.stop(true,true);
		return;
	}

	if (nNumero<1 && !bBoucle)
	{
		return;//blindage
	}

	//récupère les plans à animer
	var jqTdParentDirectDesPlans = jqChamp.find(".wbPlanSimple").first().parent();
	var nNbPlans = jqTdParentDirectDesPlans.children(".wbPlanSimple").length;
	var jqPlanActif = jqTdParentDirectDesPlans.children(".wbPlanSimple.wbActif");
	var jqNouveauPlanActif = jqTdParentDirectDesPlans.children(".wbPlanNumero" + nNumero);

	//le plan existe mais est à ..Visible=faux
	if (jqNouveauPlanActif.hasClass("wbPlanMasque"))
	{
		//tout
		if (jqTdParentDirectDesPlans.children(".wbPlanSimple:not(.wbPlanMasque)").length==0)
		{
			//même le plan courant
			if (jqPlanActif.hasClass("wbPlanMasque"))
			{
				//set un état indéfini
				jqChamp[0].wbPlanSuivant = -1;
				jqPlanActif.removeClass("wbActif");
				jqChamp.trigger("trigger.wb.plan.action.set.debut");
				jqChamp.trigger("trigger.wb.plan.action.set.fin");
				return;
			}
			//mais pas le plan courant
			else
			{
				//on ne bouge pas
				return;
			}
		}
		if (bSensCorrectionIncrement!==undefined)
		{
			//passe au prochain
			jqChamp.wbPlanSet((bSensCorrectionIncrement) ? (nNumero+1) : (nNumero-1),oOption);
		}
		//quitte en ignorant la nouvelle valeur
		return;
	}

	var jqChampNouveauPlan = jqNouveauPlanActif;
	var jqChampAncienPlan = jqPlanActif;
	var jqChampMultiPlanAvecApparition = $();

	//et les multi plan
	//sachant que le conteneur est de la forme 		wbPlanDeALIAS
	//et ses plans et champ multi plans de la forme wbPlanDansALIAS
	var sSelectionPlanDans = ".wbPlanMultiple.wbPlanDans";
	sSelectionPlanDans +=  jqChamp.wbGetClassCommencePar("wbPlanDe",false);
	//parcours les multi plan pour savoir s'il sont dans le nouveau plan
	$(sSelectionPlanDans).each(function(){
		//ignore les multi plans avec effet d'apparition, sinon il y a double effet
		var jqMultiPlan = $(this) ;
		if (this.wbEffetApparitionDisparition)
		{
			jqChampMultiPlanAvecApparition=jqChampMultiPlanAvecApparition.add(jqMultiPlan);
			return;
		}
		var sListePlan = jqMultiPlan.attr("data-wbPlan");
		if (!sListePlan)
		{
			//cas où la classe est écrite sur une balise intermédiaire, comme le td d'une ZTR
			jqMultiPlan.removeClass("wbPlan").removeClass("wbPlanMultiple");
			return;
		}
		//présent aussi dans ce plan ?
		if (sListePlan.split(",").indexOf(nNumero+"")>-1)
		{
			if (!jqMultiPlan.hasClass("wbActif"))
			{
				jqChampNouveauPlan=jqChampNouveauPlan.add(jqMultiPlan);
			}
		}
		else
		{
			if (jqMultiPlan.hasClass("wbActif"))
			{
				jqChampAncienPlan=jqChampAncienPlan.add(jqMultiPlan);
			}
		}
	});


	if (jqNouveauPlanActif.length==0)
	{
		//le nouveau plan n'existe pas

		if (bBoucle)
		{
			//si on avance
			if (jqPlanActif.wbPlanGetIndice() <= nNumero-1)
			{
				var nIndiceDernier = jqTdParentDirectDesPlans.find(".wbPlanSimple").last().wbPlanGetIndice();
				//si on va après le dernier
				if (nIndiceDernier == nNumero-1)
				{
					//boucle au premier
					oOption.bSensCorrectionIncrement=true;
					jqChamp.wbPlanSet(1,oOption);
				}
				else
				{
					//butée sur le dernier
					oOption.bSensCorrectionIncrement=false;
					jqChamp.wbPlanSet(nNbPlans,oOption);
				}
			}
			//si on recule
			else if	(jqPlanActif.wbPlanGetIndice() >= nNumero+1)
			{
				var nIndicePremier = jqTdParentDirectDesPlans.find(".wbPlanSimple").first().wbPlanGetIndice();
				//si on va avant le premier
				if (nIndicePremier == nNumero+1)
				{
					//boucle au dernier
					oOption.bSensCorrectionIncrement=false;
					jqChamp.wbPlanSet(jqTdParentDirectDesPlans.children(".wbPlanSimple").length,oOption);
				}
				else
				{
					//butée sur le premier
					oOption.bSensCorrectionIncrement=true;
					jqChamp.wbPlanSet(1,oOption);
				}
			}
		}


		//plan inexistant
		if (!jqChamp.hasClass("wbPlanDefilementUtilisateur"))
		{
			//le changement a été fait par programmation
			//alors on masque le plan actif et n'affiche rien
			jqChampAncienPlan.removeClass("wbActif");

			//création du nouveau plan vide
			jqNouveauPlanActif = $('<div class="lh0 wbPlan wbPlanDans' + jqChamp.wbGetClassCommencePar("wbPlanDe",false) + ' wbPlanSimple wbPlanNumero' + nNumero + '"></div>');
			jqChampNouveauPlan = jqChampNouveauPlan.add( jqNouveauPlanActif );
			jqChampAncienPlan.parent().append(jqNouveauPlanActif);
		}
	}
	var oEffet = {};
	var jqChampOuPremierTd = jqChamp;
	if (jqChamp.get(0).tagName.toLowerCase() == "table")
	{
		jqChampOuPremierTd = jqChamp.add(jqChamp.children("tbody").first()).last().children("tr").children().first();
		clWDUtil.WDDebug.assert(jqChampOuPremierTd.get(0) == jqChamp.find("td").first().get(0));
	}
	//jqNouveauPlanActif possède t il le contenu ou faut il le charger
	if (jqNouveauPlanActif.hasClass("wbPlanDiffere"))
	{
		//note que le plan est demandé
		jqChamp[0].wbPlanSuivant = sNumero;
		//si ce plan n'est pas déjà en train d'être chargé
		if (!sContenuHTML && jqNouveauPlanActif.hasClass("wbPlanDiffereChargementEnCours"))
		{
			//quitte car l'affichage n'est pas prêt
			return;
		}
		//seulement si vide (cas du 1er affichage de plan différé, son contenu est déjà là)
		if (jqNouveauPlanActif.children().length>0)
		{
			//force déjà actif pour éviter que le plan clignotte à l'écran
			//normalement le plan est déjà .wbActif car on traite le cas de l'affichage du plan initial
			jqNouveauPlanActif.removeClass("wbPlanDiffere");
			if (jqChampAncienPlan.get(0) == jqNouveauPlanActif.get(0))
				jqChampAncienPlan = $();//évite de considérer l'ancien et le nouveau plan pour le même plan
		}
		else
		{
			jqChamp.addClass("wbPlanConteneurDiffereChargementEnCours");
			//TODO debug sous Edge il faut forcer un repaint ici car la jauge par défaut ne s'affiche pas, alors que si on redimensionne Edge elle s'affiche
			//bloque les prochains chargement et lance le chargement
			jqNouveauPlanActif.addClass("wbPlanDiffereChargementEnCours").wbPlanCharge(jqChamp,sContenuHTML,function()
			{
				var jqChampNouveauPlan = jqNouveauPlanActif;
				var sSelectionPlanDans = ".wbPlanMultiple.wbPlanDans";
				sSelectionPlanDans +=  jqChamp.wbGetClassCommencePar("wbPlanDe",false);
				//parcours les multi plan pour savoir s'il sont dans le nouveau plan
				$(sSelectionPlanDans).each(function(){
					var jqMultiPlan = $(this) ;
					var sListePlan = jqMultiPlan.attr("data-wbPlan");
					if (!sListePlan)
					{
						//cas où la classe est écrite sur une balise intermédiaire, comme le td d'une ZTR
						jqMultiPlan.removeClass("wbPlan").removeClass("wbPlanMultiple");
						return;
					}
					//présent aussi dans ce plan ?
					if (sListePlan.split(",").indexOf(jqChamp[0].wbPlanSuivant+"")>-1)
					{
						jqChampNouveauPlan=jqChampNouveauPlan.add(jqMultiPlan);
					}
				});

				//en fin de chargement on retire les flags de réentrance (pour le plan simple et les multi plans)
				jqChampNouveauPlan
					.removeClass("wbPlanDiffere")
					.removeClass("wbPlanDiffereChargementEnCours")
				;
				//retire la jauge dès qu'il y a un retour de contenu
				//sinon le cas d'un ..Plan=2 navigateur qui appelle le serveur qui fait un ..Plan=3 fait qu'on va avoir
				//le <i plan2 toujours en attente de son contenu qui ne viendra jamais
				//if (jqTdParentDirectDesPlans.children(".wbPlanSimple.wbPlanDiffereChargementEnCours").length==0)
				{
					jqChamp.removeClass("wbPlanConteneurDiffereChargementEnCours");
				}
				//si c'est toujours ce plan qui est demandé (pas eu d'autre ..Plan= entre temps)
				if (jqChamp[0].wbPlanSuivant===sNumero)
				{
					//alors on l'affiche enfin
					//note: le pcode de fin de chargement différé de plan (une fois le nouveau plan actif) sera appelé par
					//wbPlanCharge lors de NSPCS.NSAjax.ExecuteEvenementAsynchrone(_PAGE_, sAlias, jqPlan.wbPlanGetIndice(), 14 /*EContenuRequeteEvenement.PlanDiffere*/, 78 ...
					jqChamp.wbPlanSet(sNumero,oOption);
				}
			});
			//quitte car le plan différé n'est pas encore arrivé, on vient tout juste de le demander
			return;
		}
	}
	else
	{
		if (jqNouveauPlanActif.hasClass("wbActif"))
		{
			//le nouveau plan est déjà le plan courant
			return;
		}

		//cas du jqChamp sur table mais les effets sont sur le td?
		//seul le bandeau défilant a tout sur la table, les autres ont les data du le td
		var jqChampData = jqChamp;

		//le premier td a les data ?
		if (jqChamp.get(0).tagName.toLowerCase() == "table")
		{
			if (
					jqChamp.hasClass("wbPlanDefilementUtilisateur") || jqChamp.parent().hasClass("wbchamppopup")
				|| 	jqChampData.attr("data-wbPlanEffet1erAffichage") || jqChampData.attr("data-wbPlanEffetDecremente") || jqChampData.attr("data-wbPlanEffet")
				|| 	jqChampData.data("wbPlanEffet1erAffichage") || jqChampData.data("wbPlanEffetDecremente") || jqChampData.data("wbPlanEffet")
			)
			{
				//conserve jqChamp comme l'élément ayant les data dans jqChampData
			}
			else
			{
				//l'élément ayant les data est le premier td
				jqChampData = jqChampOuPremierTd;
			}
		}

		//cas décrémente
		var oEffetDecremente = undefined;
		var oEffet1erAffichage = undefined;

		if (jqPlanActif.length==0)
		{
			if (jqChampData.attr("data-wbPlanEffet1erAffichage"))
			{
				oEffet1erAffichage = jqChampData.wbJsonParseAttr("data-wbPlanEffet1erAffichage");
				jqChampData.removeAttr("data-wbPlanEffet1erAffichage");
				jqChampData.data("wbPlanEffet1erAffichage",oEffet1erAffichage);
			}
			else
			{
				oEffet1erAffichage =  jqChampData.data("wbPlanEffet1erAffichage");
			}
		}
		else if (bSensCorrectionIncrement===false || (nNumero < jqPlanActif.wbPlanGetIndice() && !(nNumero==1 && bSensCorrectionIncrement)))
		{
			if (jqChampData.attr("data-wbPlanEffetDecremente"))
			{
				oEffetDecremente = jqChampData.wbJsonParseAttr("data-wbPlanEffetDecremente");
				jqChampData.removeAttr("data-wbPlanEffetDecremente");
				jqChampData.data("wbPlanEffetDecremente",oEffetDecremente);
			}
			else
			{
				oEffetDecremente =  jqChampData.data("wbPlanEffetDecremente");
			}
		}
		//détermine l'effet à appliquer
		//SUGG : utiliser un tableau d'animation pour oAnimationAncienPlan et oAnimationNouveauPlan
		oEffet = oEffet1erAffichage || oEffetDecremente;
		if (!oEffet)
		{
			if (jqChampData.attr("data-wbPlanEffet"))
			{
				oEffet = jqChampData.wbJsonParseAttr("data-wbPlanEffet");
				jqChampData.removeAttr("data-wbPlanEffet");
				jqChampData.data("wbPlanEffet",oEffet);
			}
			else
			{
				oEffet =  jqChampData.data("wbPlanEffet") || {};
			}
		}
	}
	//blindage
	if (!oEffet.oMouvement)
	{
		oEffet.oMouvement = {sNom:'',dDelai:0,dDuree:0};
	}
	if (!oEffet.oAnimationAncienPlan)
	{
		oEffet.oAnimationAncienPlan = {dDuree:0};
	}
	if (!oEffet.oAnimationNouveauPlan)
	{
		oEffet.oAnimationNouveauPlan = {dDuree:0};
	}
	if (!oEffet.oParallax)
	{
		oEffet.oParallax = {dDuree:0};
	}

	//sNom est du format %1 pour X, %2 pour Y et + ou - pour le signe à faire basculer
	var bEffetAvecBascule = (oEffet.oMouvement.sNom && (oEffet.oMouvement.sNom.indexOf("+")>-1 || oEffet.oMouvement.sNom.indexOf("-")>-1));

	var fFinAnimationSupp = undefined;
	var jqParallaxFils = undefined;
	var sChampBackupStyle = jqChamp.attr("style");
	if (sChampBackupStyle)
	{
		sChampBackupStyle=sChampBackupStyle.replace('min-width','width').replace('min-height','height').replace('width','min-width').replace('height','min-height');
		//force le td à suivre l'ancrage en hauteur de sa table
		if (sChampBackupStyle.indexOf("height")>-1 && jqChampOuPremierTd[0].tagName.toLowerCase()==="td")
		{
			jqChampOuPremierTd.css("height","100%");
		}
	}

	function transformationConstruit(sNom,jqChamp,bInverse)
	{
		var w = jqChampNouveauPlan.width();
		var h = jqChampNouveauPlan.height();
		return sNom
			.replace("-%1","%3%1")
			.replace("-%2","%3%2")
			.replace("%1",w)
			.replace("%2",h)
			.replace("-",(bInverse ? "" : "-"))
			.replace("+",(bInverse ? "-" : ""))
			.replace("%3","-")
		;
	}

	//traite l'affichage du plan
	//et notif l'affichage
	fFinAnimationSupp = function(){
		jqChampAncienPlan.each(function(){
			$(this).removeClass("wbActif");
			window["WDChamp"] && AppelMethode(WDChamp.prototype.ms_sOnDisplay, [this, false]);
		});
		clWDUtil.__OnScrollResize(undefined, false);
	};

	//annonce le début de changement de plan
	jqChamp.trigger("trigger.wb.plan.action.set.debut",nNumero);//indique la valeur du futur plan

	//pcode de changement de plan
	!fCallback || fCallback(undefined,nNumero);//undefined<event>, puis numero, paramètre non utilisé mais transmis au cas où

	//déclenche les effets d'apparition disparition dans les fils de plan
	jqChampAncienPlan.find(".wbEffetApparitionDisparition").trigger("trigger.wb.effet.apparition.masque",oEffet);

	//wbEffetEnCours masque les plans hors du conteneur pendant l'animation (force display block sinon l'overflow est ignoré sur firefox)
	//effet
	jqChamp.each(function(){
		//récupère les infos de taille avant d'appliquer wbEffetEnCours qui fait un height:100% et overflow:hidden

		//débordement invisible sur le conteneur de plan pendant l'animation
		//afin de ne pas laisser apparaître les champs qui dépassent
		//et applique les dimensions actuelles
		this.nLargeurAvant = jqChamp.width()  + parseInt(jqChamp.css("paddingLeft")) + parseInt(jqChamp.css("paddingRight"));
		this.nHauteurAvant = jqChamp.height() + parseInt(jqChamp.css("paddingTop")) + parseInt(jqChamp.css("paddingBottom"));
	}).addClass("wbEffetEnCours").delay(oEffet.oMouvement.dDelai||0).animate({content:1},
	{
		duration : oEffet.oMouvement.dDuree||0,
		easing : "linear",
		start : function()
		{
			//pas d'animation sur l'ancien plan ?
			if (!oEffet.oAnimationAncienPlan.dDuree)
			{
				//alors on affiche directement le nouveau plan
				fFinAnimationSupp();
			}
			else
			//niveau de calque pour avoir le nouveau plan toujours au-dessus
			//sauf si c'est le seul plan présent car wbPlanEffet provoque un position absolute et donc le conteneur de plan ferait une hauteur de 0
			jqChampNouveauPlan.addClass("wbPlanEffet");

			//affiche le nouveau plan
			jqChampNouveauPlan.each(function(){
				$(this).addClass("wbActif");
				window["WDChamp"] && AppelMethode(WDChamp.prototype.ms_sOnDisplay, [this, true]);
			});

			//vérifie sa prochaine taille maintenant que les 2 plans sont display (avant le nouveau était display none)
			this.nLargeurApres = Math.max(jqNouveauPlanActif.width(),this.bLargeurAuto ? 0 : jqPlanActif.width())	 + parseInt(jqChamp.css("paddingLeft")) + parseInt(jqChamp.css("paddingRight"));
			this.nHauteurApres = Math.max(jqNouveauPlanActif.height(),this.bHauteurAuto ? 0 : jqPlanActif.height())	 + parseInt(jqChamp.css("paddingTop")) + parseInt(jqChamp.css("paddingBottom"));

			//sous FF l'ancrage en hauteur n'est pas propagé, donc si le plan est ancré en hauteur alors on prend le max
			//entre la hauteur du contenu du plan
			//et la hauteur du conteneur de plan
			if (bFF && jqNouveauPlanActif.length && jqNouveauPlanActif[0].style.height == "100%")
			{
				this.nHauteurApres =  Math.max(this.nHauteurApres, jqNouveauPlanActif.parent().height());
			}

			//avec animation sur l'ancien plan
			if (oEffet.oAnimationAncienPlan.sNom)
			{
				jqChampAncienPlan.css("animation-duration",(oEffet.oMouvement.dDuree*oEffet.oAnimationAncienPlan.dDuree)+"ms").css("animation-name",oEffet.oAnimationAncienPlan.sNom.replace(" ",",")).addClass("animated");
				//avec délai
				if (oEffet.oAnimationAncienPlan.dDelai)
				{
					jqChampAncienPlan.css("animation-delay",(oEffet.oMouvement.dDuree*oEffet.oAnimationAncienPlan.dDelai)+"ms")
				}
				//fonction forcée en dur
				jqChampAncienPlan.css("animation-timing-function","ease-out");
			}
			//avec animation sur le nouveau plan
			if (oEffet.oAnimationNouveauPlan.sNom)
			{
				jqChampNouveauPlan.css("animation-duration",(oEffet.oMouvement.dDuree*oEffet.oAnimationNouveauPlan.dDuree)+"ms").css("animation-name",oEffet.oAnimationNouveauPlan.sNom.replace(" ",",")).addClass("animated");
				//avec délai
				if (oEffet.oAnimationNouveauPlan.dDelai)
				{
					jqChampNouveauPlan.css("animation-delay",(oEffet.oMouvement.dDuree*oEffet.oAnimationNouveauPlan.dDelai)+"ms")
				}
				//fonction forcée en dur
				jqChampNouveauPlan.css("animation-timing-function","ease-out");
			}

			if (oEffet.oParallax.dDuree)
			{
				//OPTIM trouver comment identifier les champs sans multiplier l'effet du parallax
				jqNouveauPlanActif
				.find("div[class^=pos]>:not(div[class^=pos])")//sugg : viser webdevclass-riche
				.addClass("wbPlanParallax")
				.each(function()
				{
					var jqThis = $(this);
					if (this.wbEffetApparitionDisparition || jqThis.find(".wbPlanParallax").length>0)
						return;
					jqThis
						.css("transform",(oEffet.oParallax.sNom || "translateY(100px)"))
						.delay(oEffet.oMouvement.dDuree*(oEffet.oParallax.dDelai))
						.animate(
							{content : 1}
						,
							{
								duration: (oEffet.oMouvement.dDuree*oEffet.oParallax.dDuree)
							,	easing:"linear"
							,	step : function(now,jqTween)
								{
									if (!jqTween.b1erStepFait)
									{jqTween.b1erStepFait=true;
										$(this).css("transition",(oEffet.oMouvement.dDuree*oEffet.oParallax.dDuree) + "ms transform").css("transform","");
										this.bPremierAffichage=true;
									}
									this.bPremierAffichage=false;
								}
							,	always : function()
								{
									$(this).css("transition","");
								}
							}
						)
					;
				})
				.removeClass("wbPlanParallax");
			}

			if (oEffet.sPerspective)
			{
				(
					(jqChamp[0].tagName.toLowerCase() == "table")
					? jqChamp.find("td").first()
					: jqChamp
				)
				.css("perspective",oEffet.sPerspective);
			}

			//déclenche les effets d'apparition disparition dans les fils de plan
			jqNouveauPlanActif.find(".wbEffetApparitionDisparition").add(jqChampMultiPlanAvecApparition).trigger("trigger.wb.effet.apparition.affiche");
		}
		,
		step : function(now,jqTween)
		{
			//redimensionne progressivement le conteneur de plan
			if (!this.bLargeurNavigateur && (this.nLargeurAvant!=this.nLargeurApres || this.bLargeurAuto))//optim
			{
				if (this.style.setProperty)
					this.style.setProperty( 'width', tween(this.nLargeurAvant,this.nLargeurApres,now)+'px', 'important' );
				else
					this.style.cssText += 'width:' + tween(this.nLargeurAvant,this.nLargeurApres,now)+'px !important;';
			}
			if (!this.bHauteurNavigateur && (this.nHauteurAvant!=this.nHauteurApres || this.bHauteurAuto))//optim
			{
				if (this.style.setProperty)
					this.style.setProperty( 'height', tween(this.nHauteurAvant,this.nHauteurApres,now)+'px', 'important' );
				else
					this.style.cssText += 'height:' + tween(this.nHauteurAvant,this.nHauteurApres,now)+'px !important;';
			}

			if (!jqTween.b1erStepFait)
			{   jqTween.b1erStepFait=true;
				if (bEffetAvecBascule)
				{
					jqChampNouveauPlan
						.css("transform",transformationConstruit(oEffet.oMouvement.sNom,jqChampNouveauPlan,true))
					;
				}
				else if (oEffet.oMouvement.sNom)
				{
					jqChampNouveauPlan.css("transform",oEffet.oMouvement.sNom);
				}
				this.bPremierAffichage=true;
			}
			else if (this.bPremierAffichage)
			{
				this.bPremierAffichage = false;
				if (bEffetAvecBascule)
				{
					jqChampAncienPlan
						.css("transition-timing-function","linear")
						.css("transition-duration",(oEffet.oMouvement.dDuree/2)+"ms")
						.css("transform",transformationConstruit(oEffet.oMouvement.sNom,jqChampAncienPlan))
					;
					//modification de la transition pour le nouveau plan
					jqChampNouveauPlan
						.css("transition-timing-function","ease")
						.css("transition-duration",(oEffet.oMouvement.dDuree/2)+"ms")
						.css("transition-delay",(oEffet.oMouvement.dDuree/2)+"ms")
						.css("transform","")
					;
					//on évite de retomber la définition générale de la transition pour le nouveau plan
				}
				else if (oEffet.oMouvement.sNom)
				{
					jqChampNouveauPlan.css("transition-duration",oEffet.oMouvement.dDuree+"ms").css("transform","");
				}
			}
		}
		,
		always : function()
		{
			//raz info du conteneur de plan, utile ?
			this.nLargeurAvant = this.nLargeurApres = this.nHauteurAvant = this.nHauteurApres = undefined;

			//raz chaque plan
			jqChampNouveauPlan.add(jqChampAncienPlan)
				.css("animation-duration","")
				.css("animation-timing-function","")
				.css("animation-delay","")
				.css("animation-name","")
				.css("transition-timing-function","")
				.css("transition-duration","")
				.css("transition-delay","")
				.css("transform","")
				.removeClass("animated")
			;

			//suite dans un timeout car sinon les transitions sur les transformations des champs dans le plan ne sont pas visibles sosu chrome (ok ff)
			// if (jqChamp[0].nTimerContournement)
			// {
			// 	clearTimeout(jqChamp[0].nTimerContournement);
			// }
			// jqChamp[0].nTimerContournement=0;
			// jqChamp[0].nTimerContournement = setTimeout(function()
			// {
				//retire le flag de "pendant l'effet"
				jqChampNouveauPlan.removeClass("wbPlanEffet");

				//raz le conteneur de plan
				jqChamp
					// .css("width","")
					// .css("height","")
					.css("transition","")
					.attr("style",sChampBackupStyle)
					.removeClass("wbEffetEnCours")
				;
				//retire la taille min d'un champ ancré en hauteur sous IE
				//car la hauteur était calculé à chaque resize et ne doit donc pas devenir une hauteur min
				if (bIEAvec11 && jqChamp.hasClass("h100"))
				{
					jqChamp.css("min-height","");
				}
				//cas de FF qui n'applique pas le min height 100% idem pour Chrome
				else if (!bIEAvec11 && jqChamp[0].style.minHeight==="100%")
				{
					jqChamp.css("height","100%").css("min-height","");
				}

				(
					(jqChamp[0].tagName.toLowerCase() == "table")
					? jqChamp.find("td").first()
					: jqChamp
				)
				.css("perspective","")

				//termine l'animation en changeant le flag de plan actif
				fFinAnimationSupp();

				//évite le cas du -1 pour indéfini lros du masquage du dernier plan
				if (jqChamp[0].wbPlanSuivant===-1)
				{
					jqChamp[0].wbPlanSuivant = undefined;
				}

				jqChamp.trigger("trigger.wb.plan.action.set.fin");

				//en cas d'enchaînement rapide de plan pendant l'animation
				if (jqChamp[0].wbPlanSuivant)
				{
					var nSuivant=jqChamp[0].wbPlanSuivant;
					var nSuivantOption=jqChamp[0].wbPlanSuivantOption;
					jqChamp[0].wbPlanSuivant = undefined;
					jqChamp[0].wbPlanSuivantOption = undefined;
					if (nSuivant!=nNumero)
					{
						jqChamp.wbPlanSet(nSuivant, nSuivantOption );
					}
				}

				// if (jqChamp[0].nTimerContournement)
				// {
				// 	clearTimeout(jqChamp[0].nTimerContournement);
				// }
				// jqChamp[0].nTimerContournement=0;
			// },100);
		}
	});
	return nNumero;
};
//passe au suivant/précédent
$.fn.wbPlanAvanceRecule = function(nAvance,bBoucle,fCallback) {
	if (!nAvance) nAvance=-1;
	if (!bBoucle) bBoucle=false;
	var nPlanActif = this.wbPlanGet();
	this.wbPlanSet(nPlanActif+nAvance,{ bSensCorrectionIncrement : nAvance>0, bBoucle : bBoucle, fCallback : fCallback});
};
$.fn.wbPlanGetInstance = function () {

	$(window).trigger("trigger.wb.plan.chargement");//accès à un conteneur de plan? force le chargement des conteneurs de plan (cas d'appel à ..Plan dans onload par le wl)
	var jqChamp = this;
	if (jqChamp.hasClass("wbPlanConteneur"))
	{
		return jqChamp;
	}
	//cas de jqChamp td id=ALIAS d'un cadre arrondi avec dedans une table tzALIAS puis dedans une table wbPlanDeALIAS
	var sAlias = jqChamp.attr("id");
	if (sAlias)
	{
		var jqChampDepuisAlias = jqChamp.find(".wbPlanDe" + sAlias);
		if (jqChampDepuisAlias && jqChampDepuisAlias.length)
		{
			return jqChampDepuisAlias;
		}
	}
	if (jqChamp.hasClass("wbChampSupportDest"))
	{
		return jqChamp.find(".wbChampSupportSource").first();
	}
	jqChamp = jqChamp.closest(".wbPlanConteneur");
	return jqChamp.hasClass("wbPlanConteneur") ? jqChamp : undefined;

};

//renvoie le plan auquel appartient le champ
$.fn.wbPlanGet = function() {

	var jqChamp = this.wbPlanGetInstance();
	if (!jqChamp)
	{
		return 1;//SUGG Exception pas conteneur de plan
	}

	//La WDJS utilise directement l'input hidden pour le bandeau défilant
	//Dans le cas de l'exécution du pcode navigateur de changement de plan c'est pratique car le plan actif n'est pas encore le prochain
	//Note : cela pourrait se corriger en settant jqChamp[0].wbPlanSuivant "au bon moment"

	//renvoie le plan à afficher ou actif
	return jqChamp[0].wbPlanSuivant || jqChamp.find(".wbPlanSimple.wbActif").wbPlanGetIndice();
};
$.fn.wbPlanGetIndice = function() {
	//renvoie l'indice du plan
	var jqPlan = this;
	if (!jqPlan.hasClass("wbPlan"))
	{
		return 1;//SUGG Exception pas un plan
	}
	var nNumeroNaturel = jqPlan.index()+1;
	//optim s'il n'y a pas de trou
	if (jqPlan.hasClass("wbPlanNumero" + nNumeroNaturel))
	{
		return nNumeroNaturel;
	}
	//trouve la classe de son numéro
	nNumeroNaturel = parseInt(jqPlan.wbGetClassCommencePar("wbPlanNumero",false),10);
	if(isNaN(nNumeroNaturel))
	{
		return 1;//SUGG Exception jqChamp.closest(".wbPlan").index();
	}
	return nNumeroNaturel;
};

$.fn.wbPlanEnAttenteAffichage = function() {

	var jqChamp = this.wbPlanGetInstance();
	if (!jqChamp)
		return;

	//SUGG un contenu en attendant d'être affiché ?

};

//init pour le chargement différé
//init effet de 1er affichage de plan
//init pour le set de l'input caché de la valeur du champ
$(window).oneOfThem("load.wb.plan.multiplans load.wb.plan.effet.1erAffichage trigger.wb.plan.chargement",function()
{
	//pas 2 fois (blindage car il y a 2 load dans le on)
	if (this.jqListePlanConteneur)
	{
		return;
	}

	//aucun plan dans la page?
	this.jqListePlanConteneur = $(".wbPlanConteneur");
	if (this.jqListePlanConteneur.length==0)
	{
		return;
	}

	//liste es plans conteneur avec 1er effet d'affichage
	this.jqListePlanLazy = $();

	//init des conteneurs de plans
	this.jqListePlanConteneur.each(function()
	{
		var jqPlanConteneur = $(this);

		var sSelectionPlanDans = ".wbPlanMultiple.wbPlanDans";
		sSelectionPlanDans +=  jqPlanConteneur.wbGetClassCommencePar("wbPlanDe",false);
		//parcours les multi plan pour savoir s'il sont dans le nouveau plan
		$(sSelectionPlanDans).each(function(){

			var domMultiPlan = this;
			var jqMultiPlan = $(this);

			//permet de synchro les wbActif des champs multi plans
			jqPlanConteneur
				.on("trigger.wb.plan.action.set.fin",function(){
					var sListePlan = jqMultiPlan.attr("data-wbPlan");
					if (!sListePlan)
					{
						//cas où la classe est écrite sur une balise intermédiaire, comme le td d'une ZTR
						jqMultiPlan.removeClass("wbPlan").removeClass("wbPlanMultiple");
						return;
					}
					var nNumero = jqPlanConteneur.wbPlanGet();
					//présent aussi dans ce plan ?
					if (sListePlan.split(",").indexOf(nNumero+"")>-1)
					{
						if (!jqMultiPlan.hasClass("wbActif"))
						{
							jqMultiPlan.addClass("wbActif");
						}
					}
					else
					{
						if (jqMultiPlan.hasClass("wbActif"))
						{
							jqMultiPlan.removeClass("wbActif");
						}
					}
					//stopPropagation
					return false;
				})
				.on("trigger.wb.plan.multiplan.initdata trigger.wb.plan.action.set.debut",function(jqEvent,nNumero)
				{
					//action en début ?
					domMultiPlan.oPlanMultiple = domMultiPlan.oPlanMultiple===undefined ? (jqMultiPlan.wbJsonParseAttr("data-wbPlanMultiple",true)||false) : domMultiPlan.oPlanMultiple;
					if (!domMultiPlan.oPlanMultiple)
					{
						return;
					}
					nNumero = nNumero || jqPlanConteneur.wbPlanGet();
					if (!domMultiPlan.oPlanMultiple[nNumero])
					{
						return;
					}
					clWDUtil.bForEachIn(domMultiPlan.oPlanMultiple[nNumero], function(sProp, oValeur)
					{
						if (domMultiPlan.oPlanMultiple[nNumero].hasOwnProperty(sProp))
						{
							jqMultiPlan.attr(sProp, oValeur);
						}
						return true;
					});
				})
			;
		});
		//1er affichage
		jqPlanConteneur.trigger("trigger.wb.plan.multiplan.initdata");

		//input hidden à côté pour le bandeau défilant
		jqPlanConteneur.filter(".wbPlanDefilementUtilisateur").on("trigger.wb.plan.action.set.fin trigger.wb.plan.action.set.debut",function(jqEvent,nNumero){
			//set de l'input caché de la valeur du champ
			jqPlanConteneur.prev().filter("input").attr("value",nNumero || jqPlanConteneur.wbPlanGet());
		});

		//lazy avec l'effet ? ou différé ? il faudra faire un wbPlanAffiche
		if (jqPlanConteneur.attr("data-wbPlanEffet1erAffichage") || jqPlanConteneur.hasClass("wbPlanDiffere"))
		{
			window.jqListePlanLazy = window.jqListePlanLazy.add(jqPlanConteneur);
		}

		//info d'ancrage du conteneur de plans
		this.bLargeurAuto = (this.style.width==="auto");
		if (!this.style.width)
		{
			//sans width, un block est à 100%
			this.bLargeurAuto = (jqPlanConteneur.css("display") !== "block");
		}
		this.bLargeurNavigateur = (this.style.width==="100%" || (this.children[0] && this.children[0].style.width==="100%"));
		this.bHauteurAuto = (this.style.height==="auto");
		if (!this.style.height)
		{
			//si la hauteur n'est pas la même que le parent, alors on est adapté au contenu (note pour la page le form vaudrait 0 en hauteur)
			this.bHauteurAuto = (this.offsetHeight !== this.parentElement.offsetHeight);
		}
		this.bHauteurNavigateur = (this.style.height==="100%" || (this.children[0] && this.children[0].style.height==="100%"));

	});
	//Callback de 1erAffichage
	if (this.jqListePlanLazy.length>0)
	{
		$(window).on("scroll.wb.plan.effet.1erAffichage resize.wb.plan.effet.1erAffichage trigger.wb.plan.effet.1erAffichage",function(){
			this.jqListePlanLazy.filter(function(){ return !$.belowthefold(this,{
		        threshold       : 0,
		        failure_limit   : 0,
		        event           : "scroll",
		        container       : window,
		        skip_invisible  : true,
		        appear          : null
		    }) && $(this).is(":visible"); }).each(function()
			{
				//affiche le plan courant avec l'anim
				$(this).wbPlanAffiche();
				window.jqListePlanLazy = window.jqListePlanLazy.not($(this));
				if (window.jqListePlanLazy.length==0)
				{
					$(window).off("scroll.wb.plan.effet.1erAffichage resize.wb.plan.effet.1erAffichage trigger.wb.plan.effet.1erAffichage");
				}
			});
		});
		//déclenche pour les conteneurs déjà visibles à l'écran
		$(window).trigger("trigger.wb.plan.effet.1erAffichage");
	}
});

$.fn.wbDefilementSet = function(bVal)
{
	var domBalise = this[0];
	//blindage
	if (!domBalise.oDefilement)
	{
		return;
	}
	domBalise.oDefilement.bActif = !!bVal;
	if (domBalise.oDefilement.bActif)
	{
		//relance
		domBalise.fDefilementReprendre.apply(domBalise);
	}
	else
	{
		//stop tout de suite
		domBalise.fDefilementMettreEnPause.apply(domBalise);
	}
};

$.fn.wbPlanOccurrenceGet = function()
{
	var jqChamp = this.wbPlanGetInstance();
	if (!jqChamp)
		return;
	//récupère les plans à animer
	var jqTdParentDirectDesPlans = jqChamp.find(".wbPlanSimple").first().parent();
	//retourne le nombre de plans affichés
	return jqTdParentDirectDesPlans.children(".wbPlanSimple").length;
};

//défilement automatique
$(window).oneOfThem("load.wb.plan.effet.defilement trigger.wb.plan.chargement",function(event)
{
	$(".wbPlanConteneur.wbPlanDefilementAuto").each(function(){
//$(".wbPlanConteneur").each(function(){
		var jqChamp = $(this);
		this.oDefilement = jqChamp.wbJsonParseAttr("data-wbPlanDefilementAuto",true);

		//blindage
		if (!this.oDefilement)
		{
			return;
		}
		jqChamp.removeAttr("data-wbPlanDefilementAuto");
		//blindage
		if (!this.oDefilement.nDuree)
		{
			return;
		}
//this.oDefilement = { nDuree : 5000, oJauge : {top : 0, bottom : "auto"}};

		//ajoute la jauge
		if (this.oDefilement.oJauge)
		{
			var i = $(document.createElement('i'));
			i
				.addClass("wbPlanJauge")
				.css($.extend( {}, {animationDuration: this.oDefilement.nDuree+"ms"}, this.oDefilement.oJauge ))
				.insertAfter($(this))
			;
			jqChamp.find(".wbPlanSimple").first().parent().append(i);
		}

		//animation
		this.fDefilement = function()
		{
			//évite de faire défiler le champ invisible
			if (!jqChamp.attr("data-wbPlanEffet1erAffichage") && $.inviewport(jqChamp[0],
			{
	        threshold       : 100,
	        failure_limit   : 0,
	        event           : "scroll",
	        container       : window,
	        skip_invisible  : true,
	        appear          : null
	    	}) && jqChamp.is(":visible"))
			{
				jqChamp.wbPlanAvanceRecule(true,true,
	        		//+ pcode de changement de plan une fois le nouveau plan actif
	            	(!window.NSPCS ? undefined : NSPCS.NSChamps.oGetChamp(jqChamp.attr("id"))._RecuperePCode(75))
				);
			}
		};

		this.fDefilementMettreEnPause = function(event)
		{
			//Demande TDF, lors d'un changement de plan par clic sur les puces il ne faut pas reprendre le défilement auto
			if (!this.bMiseEnPauseForcee && (event && event.type == "mouseenter"))
			{
				this.bMiseEnPauseForcee = true;
			}
			//souris au dessus => stop et reprend depuis le début
			if (this.nDefilementInterval)
			{
				clearTimeout(this.nDefilementInterval);
				delete this.nDefilementInterval;
			}
		};
		this.fDefilementReprendre = function(event)
		{
			if (this.nDefilementInterval)
			{
				clearTimeout(this.nDefilementInterval);
				delete this.nDefilementInterval;
			}
			//Demande TDF, lors d'un changement de plan par clic sur les puces il ne faut pas reprendre le défilement auto
			if (this.bMiseEnPauseForcee && (event && event.type == "mouseleave"))
			{
				this.bMiseEnPauseForcee = false;
			}
			if (this.oDefilement.bActif && !this.bMiseEnPauseForcee)
			{
				this.nDefilementInterval = setTimeout(this.fDefilement,this.oDefilement.nDuree);
			}
		};

		//est rappelé en cas de changement de plan autrement que par le défilement auto
		jqChamp
			.on("trigger.wb.plan.action.set.debut",this.fDefilementMettreEnPause)
			.on("trigger.wb.plan.action.set.fin",this.fDefilementReprendre)
		;

		//pause du défilement au survol
		if (jqChamp.hasClass("wbPlanDefilementPauseSurvol"))
		{
			jqChamp.hover(this.fDefilementMettreEnPause,this.fDefilementReprendre);
		}

		if (this.oDefilement.bActif)
		{
			//1er appel
			this.fDefilementReprendre.apply(this);
		}

	});
});

//pour effet de premier affichage
$.fn.wbPlanAffiche = function() {

	var jqChamp = this.wbPlanGetInstance();
	if (!jqChamp)
		return;

	//récupère les plans à animer
	var jqTdParentDirectDesPlans = jqChamp.find(".wbPlanSimple").first().parent();
	var jqPlanActif = jqTdParentDirectDesPlans.children(".wbPlanSimple.wbActif");

	//retire le plan actif
	var nNumero = jqChamp.wbPlanGet();

	//retire l'attribut pour le passer en data afin de ne plus apliquer l'opacité
	//reset le plan actif
	if (jqTdParentDirectDesPlans.attr("data-wbPlanEffet1erAffichage"))
	{
		jqPlanActif.removeClass("wbActif");
		jqTdParentDirectDesPlans
			.data("wbPlanEffet1erAffichage",jqTdParentDirectDesPlans.wbJsonParseAttr("data-wbPlanEffet1erAffichage"))
			.removeAttr("data-wbPlanEffet1erAffichage")
		;
	}
	//else si pas d'anim de 1er affichage alors on fait aucune anim et on laisse le plan actif
	//ça permet juste d'exécuter les pcodes pour le différé

	//change le plan
	jqChamp.wbPlanSet(nNumero);

};
//charge le contenu du plan
$.fn.wbPlanCharge = function(jqChamp,sContenuHTML,fCallbackPasseAuNouveauPlan) {
	var jqPlan = this;
	if (!jqPlan.hasClass("wbPlanSimple") || !jqChamp.hasClass("wbPlanConteneur"))
	{
		return;//SUGG Exception pas un plan
	}

	//appelé en fin d'ajax
	function fApresChargementContenuHTML(sContenuHTML)
	{
		//masquer l'image de chargement

		var jqPlanAvecContenu = $(sContenuHTML);
		//TODO retirer le flag wbActif du plan différé reçu du serveur afin que ce flag ne soit mis qu'après l'animation
		if (fCallbackPasseAuNouveauPlan)
		{
			jqPlanAvecContenu.removeClass("wbActif");
		}
		//retire le flag différé puisque justement il s'agit du contenu réel
		jqPlanAvecContenu.removeClass("wbPlanDiffere");
		//TODO remplacer le noeud du plan vide temporaire par le code HTML reçu qui contient <div class=wbPlanSimple wbPlan2>...</div>
		jqPlan.replaceWith(jqPlanAvecContenu);

		//TODO appeler les inits des champs
		//

		// Notifie aussi de la modification du HTML de la page
		clWDUtil.m_oNotificationsAjoutHTML.LanceNotifications(jqPlan.wbPlanGetInstance(), jqPlan.get(0));

		//notifier de rajout de contenu par ajax ? ou c'est fait lors de l'appel du pcode navigateur ?

		!fCallbackPasseAuNouveauPlan || fCallbackPasseAuNouveauPlan();
	}

	if (sContenuHTML)
	{
		//dans le cas d'une modification de ..Plan en AJAX le contenu est fourni
		fApresChargementContenuHTML(sContenuHTML);
		return;
	}
	//sinon c'est un ..Plan modifié en code navigateur

	var sAlias = jqChamp.hasClass("wbPlanDeMaPage") ? _PAGE_.name : jqChamp.attr("id");

	NSPCS.NSAjax.ExecuteEvenementAsynchrone(_PAGE_, sAlias, jqPlan.wbPlanGetIndice(), 14 /*EContenuRequeteEvenement.PlanDiffere*/, 78 /*ETraitementNavigateur.ChargementDifferePlan*/);

	// // on prepare la requete
	// var tabRequete = [];
	// var sValeur = "";

	// NSPCS.NSChamps.ms_oProprietesSecurises.OnSubmit();
	// // Action AJAX
	// tabRequete.push(clWDAJAXMain.sCommandeAjax_Page);
	// // Champ
	// tabRequete.push("PLANDIFFERE=" + sAlias);
	// // Indice
	// tabRequete.push("WD_PLAN_AFFICHE_=" + jqPlan.wbPlanGetIndice());
	// // Liste des plans déjà affichés pour ce conteneur de plan
	// tabRequete.push("WD_PLAN_DEJA_AFFICHES_=" + jqPlan.wbPlanGetInstance().wbPlanListeDejaPresent());

	// // Valeur du champ
	// sValeur = clWDAJAXMain.sConstruitValeurChampNom(_PAGE_, NSPCS.NSChamps.ms_oProprietesSecurises.m_oChamp.name)

	// // Si on a une valeur : l'ajoute
	// if ((sValeur !== undefined) && (sValeur.length > 0))
	// {
	// 	tabRequete.push(sValeur);
	// }

	// // Renvoie la requete
	// var sRequete = tabRequete.join("&");

	// // on prepare l'URL
	// var sURL = clWDAJAXMain.sConstruitURL(clWDUtil.sGetPageAction());

	// //TODO Plan différé : faire le chargement du contenu en async
	// //TODO Demande au serveur le contenu du nouveau plan, le serveur exécutera alors le pcode de chargement différé
	// clWDAJAXMain.sRequeteAsynchroneTexte(true, sRequete, sURL);
};

//retourne une liste des indices des plans déjà présents côté navigateur séparé par ";"
$.fn.wbPlanListeDejaPresent = function() {

	var jqChamp = this.wbPlanGetInstance();
	if (!jqChamp)
		return;

	var sListePlanDejaPresents = "";
	jqChamp.find(".wbPlanSimple").first().parent().children(".wbPlanSimple:not(.wbPlanDiffere)").each(function(){
		if (sListePlanDejaPresents!="")
			sListePlanDejaPresents+=";";
		sListePlanDejaPresents+=$(this).wbPlanGetIndice();
	});
	return sListePlanDejaPresents;
};

//clic dans le fond de plan par l'utilisateur
$(window).oneOfThem("load.wb.plan.fondcliquable trigger.wb.plan.chargement",function(event)
{
	this.jqListePlanFondCliquable = $(".wbPlanConteneur.wbPlanFondCliquable");
	if (this.jqListePlanFondCliquable.length==0)
	{
		return;
	}
	jqListePlanFondCliquable.on("click.wb.plan.fondcliquable",function(oEvent)
	{
		// Uniquement sur les champs est actif
		// Et si on clic sur le fond
		if (!$(this).hasClass("wbEffetEnCours") && clWDUtil.bClickDansFond(oEvent, this))
		{
			// Appel le PCode navigateur de clic dans le fond de plan
			if (window.NSPCS)
			{
				//clWDUtil.pfGetTraitement($(this).attr("id"), this.ms_nEventNavClick);
				NSPCS.NSChamps.oGetChamp($(this).attr("id"))._RecuperePCode(0)(oEvent);
			}

		}
	});
});

//visibilité de plan
$.fn.wbPlanVisibleSet = function(nIndiceWL,bValeur) {
	var jqChamp = this.wbPlanGetInstance();
	if (!jqChamp)
		return;

	var jqPlan = jqChamp.find(".wbPlanNumero" + nIndiceWL);
	if (bValeur)
	{
		jqPlan.removeClass("wbPlanMasque").css("visibility","");//retire l'éventuelle propriété visibility écrite par la HTML
		//non défini ?
		if (jqChamp.wbPlanGet()==-1)
		{
			jqChamp.wbPlanSet(nIndiceWL);
		}
	}
	else
	{
		jqPlan.addClass("wbPlanMasque");
		//masque le plan actif ?
		if (jqPlan.hasClass("wbActif"))
		{
			jqChamp.wbPlanAvanceRecule(true,true);
		}
	}
	jqChamp.trigger("trigger.wb.plan.visible",[nIndiceWL,bValeur]);
};
$.fn.wbPlanVisibleGet = function(nIndiceWL) {
	var jqChamp = this.wbPlanGetInstance();
	if (!jqChamp)
		return;

	return !jqChamp.find(".wbPlanNumero" + nIndiceWL).hasClass("wbPlanMasque");
};

//défilement de plan par l'utilisateur
$(window).oneOfThem("load.wb.plan.defilement trigger.wb.plan.chargement",function(event)
{
	//pas de swipe sur IE, les plans semblent se superposer au lieu d'être côte à côte
	this.jqListePlanDefilementUtilisateurTouch = (bIEAvec11 ? $() : $(".wbPlanConteneur.wbPlanDefilementUtilisateurDrag,.wbPlanConteneur.wbPlanDefilementUtilisateurSwipe"));
	this.jqListePlanDefilementUtilisateurClavier = $(".wbPlanConteneur.wbPlanDefilementUtilisateurClavier");

	if (this.jqListePlanDefilementUtilisateurTouch.length+this.jqListePlanDefilementUtilisateurClavier.length==0)
	{
		return;
	}
	var DUREE_TRANSITION_DRAG = 250;
	function nTestGestureSwipeOuDrag(distance,duree)
	{
		//si la durée est > 150 c'est un drag
		if (duree > 150)
		{
			return false;
		}
		var nVelocityX = distance/duree;
		//la vitesse doit être > 1.5
		if (nVelocityX>1.5)
		{
			return true;
		}
		//si la distance est < 100 ça ne peut pas être un swipe
		if (distance>100)
		{
			return false;
		}
		//la vitesse doit être < 0.5
		if (nVelocityX<0.5)
		{
			return false;
		}

		return undefined;
	}
	this.jqListePlanDefilementUtilisateurTouch.each(function()
	{
		var nGesture = undefined;
		var jqPlanConteneur = $(this);
		var dateStart = undefined;
		var jqPrecedent = undefined;
		var jqSuivant = undefined;
		var jqPlansVisibles = undefined;
		var IMG_WIDTH = undefined;
		var bDragAutorise = jqPlanConteneur.hasClass("wbPlanDefilementUtilisateurDrag");
		var bSwipeAutorise = jqPlanConteneur.hasClass("wbPlanDefilementUtilisateurSwipe");
		jqPlanConteneur
		//force l'arrêt du swipe en sortie du champ
		.on("mouseleave.wb.plan.defilement.swipe",function(){ $(this).trigger("mouseup")})
		//au swipe
		.swipe({
			fingers:1
	    ,   triggerOnTouchEnd: true
	    ,   excludedElements: "label, button, input, select, textarea, .noSwipe" //retire le a des exclusions afin d'autoriser le swipe d'images cliquables
	    ,   swipeStatus:
	        /**
	         * Catch each phase of the swipe.
	         * move : we drag the div
	         * cancel : we animate back to where we were
	         * end : we animate to the next image
	         */
	        function swipeStatus(event, phase, direction, distance) {

	        	//console.log(phase + ":" + event);
	        	//blindage si animation déjà en cours
	        	if (!bDragAutorise || jqPlanConteneur.queue().length)
	        	{
	        		return;
	        	}
		        /**
		         * Manually update the position of the jqPlansVisibles on drag
		         */
		        function scrollImages(distance, duration) {
		            jqPlansVisibles.css("transition-duration", (duration / 1000).toFixed(1) + "s");

		            //inverse the number we set in the css
		            var value = (distance < 0 ? "" : "-") + Math.abs(distance).toString();
		            jqPlansVisibles.css("transform", "translateX(" + value + "px)");
		        }
		        function scrollCancel()
		        {
	                jqPlanConteneur.animate({content:1},{
	                	duration : DUREE_TRANSITION_DRAG
	                ,	start : function()
	                {
						scrollImages(0, DUREE_TRANSITION_DRAG);
	                }
	                ,	always : function()
	                {
	                	scrollRaz();
	                	jqPlanConteneur.removeClass("wbEffetEnCours").css("content",0);
	                }
	                , queue : "swipeStatus"
	                }).dequeue("swipeStatus");
		        }
		        function scrollRaz()
		        {
	            	jqPlanConteneur
	            		.find(".wbPlanSuivant,.wbPlanPrecedent,.wbPlanSimple.wbActif")
		            		.removeClass("wbPlanPrecedent")
		            		.removeClass("wbPlanSuivant")
		            		.css("transform","")
		            		.css("transition","")
		            		.css("left","")
		            		.css("right","")
	            	;
	            	jqPlanConteneur
	            		.removeClass("wbEffetEnCours")
	            		.removeClass("wbGlisserEnCours")
	            		.trigger("trigger.wb.plan.action.set.fin")
	            	;
	            	jqPlansVisibles = undefined;
		        }
		        if (phase == 'start')
	            {
	            	//raz la gesture en cours
	            	nGesture = undefined;
					IMG_WIDTH = jqPlanConteneur.width();

			        jqPlanConteneur.trigger("trigger.wb.plan.action.set.debut");

			        //permet de différencier le swipe continu ou par à-coup
			        dateStart = new Date();

			        var jqPlanActif = jqPlanConteneur.find(".wbPlanSimple.wbActif").first();

			        jqPrecedent = jqPlanActif.prevAll(".wbPlanSimple:not(.wbPlanMasque)");
			        for(var iPrec=jqPrecedent.length-1; iPrec>=0; --iPrec)
			        {
			        	$(jqPrecedent.get(iPrec)).css("left","-"+(iPrec+1) +"00%");//right marche moins bien que left ici...
			        }

			        jqSuivant = jqPlanActif.nextAll(".wbPlanSimple:not(.wbPlanMasque)");
			        for(var iSuiv=0; iSuiv<jqSuivant.length; ++iSuiv)
			        {
			        	$(jqSuivant.get(iSuiv)).css("left",(iSuiv+1) +"00%");
			        }

	            	jqPlansVisibles = jqPlanActif.add(
	            		jqPrecedent.addClass("wbPlanPrecedent")
	            		.add(
	            			jqSuivant.addClass("wbPlanSuivant")
	            		)
	            	);
	            }
	            else if (jqPlansVisibles)
	            {
	            	//ignore pendant la durée d'un swipe
	            	if (nGesture===undefined)
	            	{
	            		nGesture= (bSwipeAutorise ? nTestGestureSwipeOuDrag(distance,new Date() - dateStart) : false);
	            	}
	            	//la gestion n'est pas un drag ?
	            	if (nGesture!==false)
	            	{
	            		//en fin on raz
	            		if (phase == "end" || phase == "cancel")
	            		{
	            			scrollRaz();
	            		}
	            		//sinon on ignore (immobile)
	            		return;
	            	}
		            //If we are moving before swipe, and we are going L or R in X mode, or U or D in Y mode then drag.
		            if (phase == "move" && distance>0)
		            {
	            		jqPlanConteneur.addClass("wbEffetEnCours").addClass("wbGlisserEnCours");
		            	//délai de suivi
		                var duration = 0;
		                if (direction == "left")
		                {
		                	if (!jqSuivant || jqSuivant.length==0)
		                	{
		                		distance /= 3;
		                	}
		                    scrollImages(distance, duration);
		                }
		                else if (direction == "right")
		                {
		                	if (!jqPrecedent || jqPrecedent.length==0)
		                	{
		                		distance /= 3;
		                	}
		                    scrollImages(-distance, duration);
		                }
		            }
		            else if (phase == "cancel")
		            {
		            	//annule
		                scrollCancel();
		            }
		            else if (phase == "end")
		            {
		                if (direction == "right" || direction == "left")
		                {
		                	//retire le curseur de drag dès le mouse up
		                	jqPlanConteneur.removeClass("wbGlisserEnCours");
		                    var jqNouveau = undefined;
							var jqAncien = jqPlansVisibles.filter(".wbActif");
							if (jqAncien.length!=1)
							{
								scrollRaz();
								return;
							}

							//on avance ou on recule, de combien ?
							var nIncrement = Math.max(0,parseInt((Math.abs(distance) / IMG_WIDTH)+0.66,10));
							if (nIncrement>0)
							{
								if (direction == "left")
								{
									jqNouveau = $(jqAncien.nextAll(".wbPlanSuivant").get(nIncrement-1));
								}
								else //if (direction == "right")
								{
									jqNouveau = $(jqAncien.prevAll(".wbPlanPrecedent").get(nIncrement-1));
								}
							}

							//reste sur le même plan
		                    if (!jqNouveau || jqNouveau.length==0)
		                    {
								scrollCancel();
		                    	return;
		                    }

		                    //décale les plans
		                    //var nDecalage = parseInt(jqNouveau.css("left"),10); non car sous iPad avec zoom cela ne correspond pas
		                    var nDecalage = jqPlanConteneur.width()  * Math.round(  (distance / jqPlanConteneur.width())+0.5 ) * (direction == "right" ? -1 : 1);
		                    jqPlansVisibles.css("transition",DUREE_TRANSITION_DRAG+"ms transform").css("transform", "translateX(" + (-nDecalage) + "px)");

							jqPlanConteneur.trigger("trigger.wb.plan.action.set.debut",jqNouveau.wbPlanGetIndice());

							//déclenche les effets d'apparition disparition dans les fils de plan
							jqAncien.find(".wbEffetApparitionDisparition").trigger("trigger.wb.effet.apparition.masque",{swipe:1});

		                    //anime vers le nouveau plan
		                    jqPlanConteneur.animate({content:1},{
		                    	duration : DUREE_TRANSITION_DRAG
		                    ,	start : function()
		                    {
								//déclenche les effets d'apparition disparition dans les fils de plan
								jqNouveau.find(".wbEffetApparitionDisparition").trigger("trigger.wb.effet.apparition.affiche");

								//notif l'affichage
								window["WDChamp"] && AppelMethode(WDChamp.prototype.ms_sOnDisplay, [jqNouveau[0], true]);
		                    }
		                    ,	always : function()
		                    {
		                    	scrollRaz();
			                    //passe le flag actif
			                    jqNouveau.addClass("wbActif");
			                    jqAncien.removeClass("wbActif");
		                    	jqPlanConteneur.css("content",0);
		                    	jqPlanConteneur.trigger("trigger.wb.plan.action.set.fin");

		                    	//notif le masquage
		                    	window["WDChamp"] && AppelMethode(WDChamp.prototype.ms_sOnDisplay, [jqAncien[0], false]);
			                    //pcode de changement de plan une fois le nouveau plan actif
			                    if(window.NSPCS)
			                    {
			                    	NSPCS.NSChamps.oGetChamp(jqPlanConteneur.attr("id"))._RecuperePCode(75)(event);
			                    }
		                    }
		                    });
		                }
		                else
		                {
		                	//annule si la direction de fin n'est pas gauche ou droite
		                	scrollCancel();
		                }
		            }
	        	}
	        }
	    ,   allowPageScroll: "vertical"
	    ,   threshold: 75
		, 	swipe:function(event, direction, distance, duration, fingerCount, fingerData)
			{
				//cas d'un drag (donc pas un swipe) ou cas d'un swipe pas horizontal
				if (!bSwipeAutorise || (bDragAutorise && !nGesture) || !(direction == 'left' || direction == 'right'))
				{
					return;
				}
				var jqChamp = $(this);
				if (direction == 'left')
				{
					jqChamp.wbPlanAvanceRecule(true,false,
		        		//+ pcode de changement de plan une fois le nouveau plan actif
		            	(!window.NSPCS ? undefined : NSPCS.NSChamps.oGetChamp(jqChamp.attr("id"))._RecuperePCode(75))
					);
				}
				else if (direction == 'right')
				{
					jqChamp.wbPlanAvanceRecule(false,false,
		        		//+ pcode de changement de plan une fois le nouveau plan actif
		            	(!window.NSPCS ? undefined : NSPCS.NSChamps.oGetChamp(jqChamp.attr("id"))._RecuperePCode(75))
					);
				}
		    }
		});
	});
	//au clavier
	$(window).on("keyup.wb.plan.defilement",function(event)
	{
		if ((event.key == "ArrowRight")||(event.key == "Right"))//IE Right
		{
			var bAvance = true;
		}
		else if ((event.key == "ArrowLeft")||(event.key == "Left"))//IE Left
		{
			var bAvance = false;
		}
		else
		{
			return;
		}

		//évite de prendre les touches alors que le focus est sur un champ de saisie
		if ( $( document.activeElement ).filter("input,textarea,[contenteditable]").length )
		{
			return;
		}

		window.jqListePlanDefilementUtilisateurClavier.filter(function(){ return $.inviewport(this,{
	        threshold       : 0,
	        failure_limit   : 0,
	        event           : "scroll",
	        container       : window,
	        skip_invisible  : true,
	        appear          : null
	    }) && $(this).is(":visible"); }).each(function()
		{
			var jqChamp = $(this);
			jqChamp.wbPlanAvanceRecule(bAvance,true,
        		//+ pcode de changement de plan une fois le nouveau plan actif
            	(!window.NSPCS ? undefined : NSPCS.NSChamps.oGetChamp(jqChamp.attr("id"))._RecuperePCode(75))
			);
		});
	});
});

//options de plan : présence de flèche, puces etc.
$(window).oneOfThem("load.wb.plan.options trigger.wb.plan.chargement",function(event)
{
	this.jqListePlanOptions = $("[data-wbPlanOptions]");//<td data-wbPlanOptions={}/>

	if (this.jqListePlanOptions.length==0)
	{
		return;
	}

	//enum ePARTIEBANDEAU
	// 	ePARTIEBANDEAU_MIN	= 0,
		var eChamp=0;//			= ePARTIEBANDEAU_MIN,
		var ePuces=1;//,
		var eFlechePrecedent=2;//,
		var eFlecheSuivant=3;//,
	// 	//autre
	// 	ePARTIEBANDEAU_MAX_INVALIDE

	this.jqListePlanOptions.each(function()
	{
		//le conteneur est la <table>
		var jqTdData = $(this);
		var jqChamp = jqTdData.wbPlanGetInstance();
		if (!jqChamp || !jqChamp.length)//blindage
		{
			//cas de génération du data-wbPlanOptions sur le div dww de superposition et sur la table du champ
			return;
		}

		//charge les options
		var wbPlanConteneurOptions = jqTdData.wbJsonParseAttr("data-wbPlanOptions");
		jqTdData.removeAttr("data-wbPlanOptions");

		//lecture des options
		if (!wbPlanConteneurOptions)
		{
			return;
		}

		var jqTdParentDirectDesPlans = jqChamp.find(".wbPlanSimple").first().parent();
		var jqNouveauxElements = $();

		if (wbPlanConteneurOptions[eChamp])
		{
			//wbPlanConteneurOptions[eChamp].style
			//wbPlanConteneurOptions[eChamp].surcharge

			//utile ?
		}
		if (wbPlanConteneurOptions[ePuces])
		{
			//wbPlanConteneurOptions[ePuces].style
			//wbPlanConteneurOptions[ePuces].surcharge
			//
			//création
			// 		<ol class="wbPlanPuces">
			// 		<li class="wbPlanNumero1 wbPlanMasque">
			// 		<label>
			// 			<input type="radio" name="A1_PUCES" value="1" class="wbCoche wbCoche6Anim" checked/>
			// 			<i class="padding A1-styXXX A1-suchargeXXX"></i>
			// 		</label>
			// 		</li>
			// 		</ol>
			var jqListePuces = $(document.createElement('ol')).addClass("wbPlanPuces wbPlanMasque");

			var jqListePlans = jqTdParentDirectDesPlans.children(".wbPlanSimple");
			var nNbPlans = jqListePlans.length;
			var sNomPuces = jqChamp.attr("id") +'_PUCES';

			for(var iPlan=0; iPlan<nNbPlans; ++iPlan)
			{
				var jqPlan = $(jqListePlans[iPlan])
				var nIndice = jqPlan.wbPlanGetIndice();
				var jqPuce = $(document.createElement('li'))
					.addClass("wbPlanNumero"+ nIndice + (jqPlan.hasClass("wbPlanMasque") ? ' wbPlanMasque' : ''))
					.append(
						$(document.createElement('label')).append(

							$(document.createElement('input'))
								.attr({
									type 	: 	"radio"
								,	name 	: 	sNomPuces
								,	value 	: 	nIndice
								,	'class' 	: 	"wbCoche wbCoche6Anim"
								})
								.add(
									$(document.createElement('i'))
										.attr({
											'class' 	: 	"padding "+ (wbPlanConteneurOptions[ePuces].style||"") + " " +   (wbPlanConteneurOptions[ePuces].surcharge||"")
										})
								)
						)
					)
				;
				//associe la puce à l'affectation de plan
				jqPuce.find("input").on("change.wb.plan.options.puces",function(oEvent,bSansAppelerPlanSet){
					jqListePuces.find("input+i.wbActif").removeClass("wbActif");
					bSansAppelerPlanSet || jqChamp.wbPlanSet($(this).attr("value"),
						{fCallback :
			        		//+ pcode de changement de plan une fois le nouveau plan actif
			            	(!window.NSPCS ? undefined : NSPCS.NSChamps.oGetChamp(jqChamp.attr("id"))._RecuperePCode(75))
						}
					);
					$(this).next().addClass("wbActif");//i.wbActif
				});

				//ajoute la puce à la liste de puces
				jqListePuces.append(jqPuce);
			}
			//coche le plan actif courant
			jqChamp
				.on("trigger.wb.plan.options.puces.maj trigger.wb.plan.action.set.debut",function(oEvent,nNumeroProchain){
					if (oEvent.namespace == "action.debut.plan.set.wb" && nNumeroProchain===undefined)
					{
						//blindage
						return;
					}
					if (nNumeroProchain===undefined)
					{
						nNumeroProchain	= jqChamp.wbPlanGet();
					}
					jqListePuces.find(".wbPlanNumero" + nNumeroProchain).find("input").prop("checked",true).trigger("change.wb.plan.options.puces",true);
				})
				//init
				.trigger("trigger.wb.plan.options.puces.maj")
			;

			//ajoutes aux nouveaux éléments qui seront insérés d'un coup dans la page
			jqNouveauxElements=jqNouveauxElements.add(jqListePuces);

			//cas d'un seul plan visible
			var fAfficheMasqueListePucesSelonNbPlansVisibles = function()
			{
				if (jqListePuces.children().filter(":not(.wbPlanMasque)").length<2)
				{
					jqListePuces.addClass("wbPlanMasque");
				}
				else
				{
					jqListePuces.removeClass("wbPlanMasque");
				}
			};
			//1er appel
			window.requestAnimationFrame ? requestAnimationFrame(fAfficheMasqueListePucesSelonNbPlansVisibles) : fAfficheMasqueListePucesSelonNbPlansVisibles();

			//synchronise la visibilité des puces et des plans
			jqChamp
				.on("trigger.wb.plan.visible",function(jEvent,nIndice,bValeur)
				{
					var jqPuce = jqListePuces.find(".wbPlanNumero" + nIndice);
					if (bValeur)
					{
						jqPuce.removeClass("wbPlanMasque");
					}
					else
					{
						jqPuce.addClass("wbPlanMasque");
					}
					fAfficheMasqueListePucesSelonNbPlansVisibles();
				})
			;
		}
		var jqFleches = $();
		if (wbPlanConteneurOptions[eFlechePrecedent])
		{
			//wbPlanConteneurOptions[eFlechePrecedent].style
			//wbPlanConteneurOptions[eFlechePrecedent].surcharge
			//wbPlanConteneurOptions[eFlechePrecedent].planche
			//
			//<button type="button"  class="wbPlanBoutonPrecedent"
			//    onclick="{_JSL(_PAGE_,'A4','_self','','');} "
			//    id="A4" class="BTN-Image wbp2etatsNS wbplanche wblien padding webdevclass-riche"
			//    style="
			//			display:block;
			//			width:Wpx;
			//			height:Hpx;
			//			margin-top:-H/2px;
			//			position:absolute;top:50%;left:0;
			//			background-image:url(/WB21_WEB/res/btn_b6d82c881b344a7a1a916c1058117582268462de.png);
			//			-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
			//    &lt;
			//    </button>
			if (wbPlanConteneurOptions[eFlechePrecedent].planche)
			{
				wbPlanConteneurOptions[eFlechePrecedent].planche += " wbplanche";
			}
			var jqFlechePrecedent = $(document.createElement('a'))
				.addClass("wbPlanBoutonPrecedent padding wbPlanMasque"
					+ ' ' + (wbPlanConteneurOptions[eFlechePrecedent].style||"")
					+ ' ' + (wbPlanConteneurOptions[eFlechePrecedent].surcharge||"")
					+ ' ' + (wbPlanConteneurOptions[eFlechePrecedent].planche||"")
				)
				.html("&lt;")
			;
			//associe la flèche à l'affectation de plan
			jqFlechePrecedent.on("click.wb.plan.options.fleche.precedent",function(){
				jqChamp.wbPlanAvanceRecule(false,true,
            		//+ pcode de changement de plan une fois le nouveau plan actif
                	(!window.NSPCS ? undefined : NSPCS.NSChamps.oGetChamp(jqChamp.attr("id"))._RecuperePCode(75))
				);
			});
			//ajoutes aux nouveaux éléments qui seront insérés d'un coup dans la page
			jqFleches=jqFleches.add(jqFlechePrecedent);
		}
		if (wbPlanConteneurOptions[eFlecheSuivant])
		{
			//wbPlanConteneurOptions[eFlecheSuivant].style
			//wbPlanConteneurOptions[eFlecheSuivant].surcharge
			//wbPlanConteneurOptions[eFlecheSuivant].planche
			if (wbPlanConteneurOptions[eFlecheSuivant].planche)
			{
				wbPlanConteneurOptions[eFlecheSuivant].planche += " wbplanche";
			}
			var jqFlecheSuivant = $(document.createElement('a'))
				.addClass("wbPlanBoutonSuivant padding wbPlanMasque"
				+ ' ' + (wbPlanConteneurOptions[eFlecheSuivant].style||"")
				+ ' ' + (wbPlanConteneurOptions[eFlecheSuivant].surcharge||"")
				+ ' ' + (wbPlanConteneurOptions[eFlecheSuivant].planche||"")
				)
				.html("&gt;")
			;
			//associe la flèche à l'affectation de plan
			jqFlecheSuivant.on("click.wb.plan.options.fleche.suivant",function(){
				jqChamp.wbPlanAvanceRecule(true,true,
            		//+ pcode de changement de plan une fois le nouveau plan actif
                	(!window.NSPCS ? undefined : NSPCS.NSChamps.oGetChamp(jqChamp.attr("id"))._RecuperePCode(75))
				);
			});
			//ajoutes aux nouveaux éléments qui seront insérés d'un coup dans la page
			jqFleches=jqFleches.add(jqFlecheSuivant);
		}

		//code commun aux flèches
		if (jqFleches.length>0)
		{
			jqNouveauxElements=jqNouveauxElements.add(jqFleches);
			jqChamp.on("trigger.wb.plan.action.set.fin trigger.wb.plan.option.fleches.load trigger.wb.plan.visible",function(){
				//set de l'input caché de la valeur du champ
				if (jqChamp.wbPlanGet() === -1)
				{
					jqFleches.addClass("wbPlanMasque");
				}
				//état valide
				else
				{
					var jqTdParentDirectDesPlans = jqChamp.find(".wbPlanSimple").first().parent();
					var nNbPlansAffiches = jqTdParentDirectDesPlans.children(".wbPlanSimple:not(.wbPlanMasque)").length;
					if (nNbPlansAffiches>1)
					{
						jqFleches.removeClass("wbPlanMasque");
					}
					//il ne reste plus que le plan actif comme plan visible
					else
					{
						jqFleches.addClass("wbPlanMasque");
					}
				}
			});
		}

		if (!jqNouveauxElements.length)
		{
			return;
		}

		//ajoute tous les nouveaux éléments d'un coup dans la page dans un tfooter
		var jqFooterTd = $(document.createElement('tr')).append($(document.createElement('td')))
		jqFooterTd.append(jqNouveauxElements);
		var jqFooter = $(document.createElement('tfoot')).append(jqFooterTd);

		jqTdParentDirectDesPlans.css("width","100%").addClass("pr")/*relativise la position des plans mais pas des flèches*/.closest("table").append(jqFooter);

		jqChamp.trigger("trigger.wb.plan.option.load");//=> trigger.wb.plan.option.??????.load comme trigger.wb.plan.option.fleches.load
	});
});

/////////////////////////////////////////////////////////////////////
////////////////////////// PARALLAXE ////////////////////////////////
/////////////////////////////////////////////////////////////////////

$.fn.wbParallaxeOptions = {
	dTauxFond 		: 0
,	dTauxY 			: 0
,	dTauxHauteur 	: 0
};

//parallaxe sur l'image de fond
$.fn.wbParallaxeUpdateFond = function()
{
	this.each(function()
	{
		//pas de parallaxe de fond ou ratio pas encore calculé (image en cours de chargement) ?
		if (this.oParallaxe.dTauxFond==0 || !this.dRatioImageFond)
		{
			return;
		}
		//infos navigateur
		var nBordHautNavigateur = window.nBordHautNavigateur;
		var nLargeurNavigateur = window.nLargeurNavigateur;
		var nHauteurNavigateur = window.nHauteurNavigateur;
		var nHauteurPage = window.nHauteurPage;

		var bMemePosition = this.nBordHautNavigateurPrecedent!==undefined && nBordHautNavigateur == this.nBordHautNavigateurPrecedent;
		var bMemeHauteur = this.nHauteurNavigateurPrecedent!==undefined && nHauteurNavigateur == this.nHauteurNavigateurPrecedent;
		var bMemeLargeur = this.nLargeurNavigateurPrecedent!==undefined && nLargeurNavigateur == this.nLargeurNavigateurPrecedent;
		this.nLargeurNavigateurPrecedent = nLargeurNavigateur;
		this.nHauteurNavigateurPrecedent = nHauteurNavigateur;
		this.nBordHautNavigateurPrecedent = nBordHautNavigateur;
		if (bMemePosition && bMemeHauteur && bMemeLargeur)
		{
			//quitte car déjà calculé pour ce fond
			return;
		}

		//infos champ
		var nPositionY = this.nPositionY;
		var nPositionX = this.nPositionX;
		var nHauteurChamp = this.nHauteurChamp;
		var nLargeurChamp = this.nLargeurChamp;
		var dRatioImageFond = this.dRatioImageFond;

		//image dépassée
		if (nPositionY+nHauteurChamp<nBordHautNavigateur)
		{
			return;
		}

		//image non affichée ?
		if (dRatioImageFond<=0 || nPositionY>nBordHautNavigateur+nHauteurNavigateur)
		{
			this.jqBaliseCibleFond.css("backgroundPositionY",  0 );
			return;
		}

		var dRatioChamp = nHauteurChamp/nLargeurChamp;

		var nHauteurImageFond = nHauteurNavigateur;
		var nLargeurImageFond = nHauteurImageFond/dRatioImageFond;

		//cale pour être haute comme le navigateur
		//nHauteurImageFond = nHauteurNavigateur + (nHauteurPage*(this.oParallaxe.dTauxFond));
		nHauteurImageFond = nHauteurNavigateur + (nHauteurNavigateur*(1-this.oParallaxe.dTauxFond));
		nLargeurImageFond = nHauteurImageFond / dRatioImageFond;

		//pas assez large
		if (nLargeurImageFond < nLargeurChamp)
		{
			nLargeurImageFond = nLargeurChamp;
			nHauteurImageFond = nLargeurImageFond * dRatioImageFond;
		}

		//définit la taille
		var sBgSize = nLargeurImageFond+"px "+nHauteurImageFond+"px";
		if (this.sBgSize != sBgSize)
		{
			//change la taille
			this.jqBaliseCibleFond.css({backgroundSize : sBgSize});
			this.sBgSize = sBgSize;
		}

		var nMilieuChamp = nPositionY + (nHauteurChamp/2);
		var nMilieuNavigateur = nBordHautNavigateur + (nHauteurNavigateur/2);
		var nMilieuImage = nHauteurImageFond/2;

		//aligne le milieu de l'image et le milieu du champ
		nPositionY = (nPositionY-nBordHautNavigateur) - nMilieuImage + (nHauteurChamp/2);
		//et déplace
		nPositionY += (nMilieuNavigateur-nMilieuChamp) * (this.oParallaxe.dTauxFond);

		var sPositionX = (nPositionX-(nLargeurImageFond/2)+(nLargeurChamp/2)) + "px";
		//pas de fixed en mobile donc la position est relative au champ
		if (clWDUtil.bGetNavigateurMobile())
		{
			nPositionY -=  (this.nPositionY-nBordHautNavigateur);
			sPositionX = "center";
		}
		//+ bg-size pour faire zoom ? bof car le top serait de faire opacité aussi mais ce n'est pas possible avec ce mécanisme

		//note : éviter backgroundPositionY non supporté en firefox
		this.jqBaliseCibleFond.css({backgroundPosition:  sPositionX + " "+nPositionY+"px" });

		//+optim arrêter une fois la hauteur du navigateur dépassé car le champ n'est pas encore visible
	});
};

$.fn.wbBgLoadAsync = function(jqBalise,f)
{
	var img = new Image();
	var s = this.css("background-image");
	if (s=="none")
	{
		f.apply({balise : jqBalise});
		return;
	}
	img.src = s.replace(/url\(|\)$|"/ig, '');
	img.balise = jqBalise;
	img.onload = f;
};

$.fn.s_wbParallaxeUpdateFond = function()
{
	window.jqListeChampParallaxeFond.wbParallaxeUpdateFond();
	//note que le dessin a été fait
	$.fn.s_wbParallaxeUpdateFond.appelDemande=false;
};

$.fn.wbParallaxeUpdateChamp = function()
{
	this.each(function()
	{
		//pas de parallaxe de champ ?
		if (this.oParallaxe.dTauxY==0 && this.oParallaxe.dTauxHauteur==0)
		{
			return;
		}

		//hauteur qui vient d'être scollée
		var nAugmentation = (this.nBordHautNavigateur||0) - window.nBordHautNavigateur;
		if (this.nBordHautNavigateur!==undefined && Math.abs(nAugmentation)<3 && window.nBordHautNavigateur+window.nHauteurNavigateur+3>=window.nHauteurPage)//<3 pour éviter le tremblement en fin de page sur un scroll maintenu
		{
			//quitte car déjà calculé pour ce champ
			return;
		}

		//interdit car une animation d'apparition est en cours
		var jqChamp = $(this);
		if (jqChamp.queue("wbEffetApparitionDisparition").length)
		{
			//blindage car l'édition devrait interdire ce cumul d'effet
			return;
		}

		//mémorise la dernière position calculée
		this.nBordHautNavigateur = window.nBordHautNavigateur;

		//Modification CSS à faire
		var oModifCSS = {};

		//calcule le décalage à appliquer sur le champ par rapport au décalage fait sur le scroll
		var nOffsetY = this.oParallaxe.dTauxY * -nAugmentation;
		//ajoute à ce décalage, le décalage fait jusqu'ici
		nOffsetY += this.nOffsetTransformationPrecedente||0;
		//note que son bord a changé
		this.nPositionY += nOffsetY - (this.nOffsetTransformationPrecedente||0);
		//mémorise le nouveau décalage fait jusqu'ici
		this.nOffsetTransformationPrecedente = nOffsetY;
		//applique ce décalage sur la balise
		oModifCSS.transform = (nOffsetY==0 ? "" : ("translateY(" +nOffsetY+ "px)"));


		//parallaxe hauteur ?
		if (this.oParallaxe.dTauxHauteur>0)
		{
			//calcule la hauteur à modifier sur le champ par rapport au décalage fait sur le scroll
			oModifCSS.height = this.nHauteurChampCourante + (this.oParallaxe.dTauxHauteur*nAugmentation);
			//mémorise la nouvelle hauteur courante
			this.nHauteurChampCourante = oModifCSS.height;

			//avec homothétie
			if (this.bHomothetieSelonHauteur)
			{
				oModifCSS.width = "auto";
				oModifCSS.margin = "0 auto";
				--oModifCSS.height;//-1 car avec l'homothétie l'arrondi peut provoquer une largeur trop grande
			}

			//note que sa hauteur a changé
			this.nHauteurChamp = oModifCSS.height;
		}

		if (!this.bPositionEpingle)
		{
			//optim si le champ n'est pas encore visible (à faire après calcul car la translation peut le rendre visible)
			if (this.nPositionY > window.nBordHautNavigateur+ window.nHauteurNavigateur)
			{
				return;
			}

			//optim si le champ n'est plus visible
			if (this.nPositionY+Math.max(this.nHauteurChampMin,this.nHauteurChamp) < window.nBordHautNavigateur)
			{
				return;
			}
		}

		//applique les modifs css sans la transform (pour ne pas double translater)
		this.jqBaliseCible.css($.extend({}, oModifCSS , {transform : ""}));
		//applique les modifs css
		this.jqBaliseCibleTransform.css(oModifCSS);
	});
};

//à chaque resize scroll
$(window).on("scroll.wb.parallax resize.wb.parallax load.wb.parallax trigger.wb.postUpdateLayoutSuperposableEpingle.parallax trigger.wb.parallax.load",function(event)
{
	var $window = $(this);

	//évite les triggers sans dessins intermédiaires
	if ($.fn.s_wbParallaxeUpdateFond.appelDemande)
	{
		return;
	}

	if (!this.jqListeChampParallaxe)
	{
		//utile pour les parallaxes de fond uniquement en cas d'ancrage
		if ((event.type+(event.namespace||"")).toLowerCase().indexOf("load")<0)
		{
			//init au load uniquement
			return;
		}

		//pas 2 fois
		$(window).off("trigger.wb.parallax.load");

		this.jqListeChampParallaxeChamp = $("[data-wbParallaxeChamp]");
		this.jqListeChampParallaxeFond = $("[data-wbParallaxeFond]");
		this.jqListeChampParallaxe = this.jqListeChampParallaxeChamp.add(this.jqListeChampParallaxeFond);

		//pas de champ avec parallaxe ? ni de fond ?
		if (jqListeChampParallaxe.length==0)
		{
			//désactive le parallaxe
			$window.off("scroll.wb.parallax resize.wb.parallax load.wb.parallax trigger.wb.postUpdateLayoutSuperposableEpingle.parallax");
			return;
		}

		//init les calculs de parallaxe
		this.jqListeChampParallaxe.each(function()
		{
			//note : pas d'overflow automatique, pour le faire le client doit mettre le débordement sur le conteneur du champ
			var jqChamp = $(this);

			//lecture initiale de la vitesse (la 1ère fois elle est dans le DOM, puis elle peut changer par programmation)
			this.oParallaxe = $.extend( {}, $.fn.wbParallaxeOptions, jqChamp.wbJsonParseAttr("data-wbParallaxeChamp",true)||{}, jqChamp.wbJsonParseAttr("data-wbParallaxeFond",true)||{} );
			//nettoyage
			jqChamp.removeAttr("data-wbParallaxeChamp").removeAttr("data-wbParallaxeFond");

			//init le calcul pour la position Y et Fond
			var oOffset = jqChamp.offset();
			this.nPositionY = oOffset.top;
			this.nPositionX = oOffset.left;

			//jqBaliseCibleConteneur est la balise la plus externe, jqBaliseCible la plus interne
			this.jqBaliseCibleConteneur = this.jqBaliseCible = jqChamp;

			//doit appliquer les transform sur la table car les styles sont sur la table au moins pour la couleur de fond
			var jqTable = this.jqBaliseCible.closest("table");
			if (this.jqBaliseCible[0].tagName.toLowerCase() == "td")
			{
				this.jqBaliseCibleConteneur = jqTable;
			}

			//découvre le czALIAS à partir du tzALIAS
			var sAlias = (this.jqBaliseCible.attr("id")||' ').substr(1);
			var jqTableConteneur = !sAlias ? undefined : this.jqBaliseCible.parents("#c" + sAlias);
			if (jqTableConteneur && jqTableConteneur.length)
			{
				this.jqBaliseCibleConteneur = jqTableConteneur;
			}
		});

		//init supplémentaire pour les parallaxes de champ
		this.jqListeChampParallaxeChamp.each(function()
		{
			//une seule balise cible les transformations pour ne pas les appliquer en double table+td
			this.jqBaliseCibleTransform = this.jqBaliseCibleConteneur;

			//blindage du cas superposable ou épinglé avec ancrage
			//retire l'ancrage en hauteur
			this.jqBaliseCible.removeClass("ancragesuph").removeClass("ancragefixedh");

			var sPosition = this.jqBaliseCible/*.parent() le data sera sur le div de superposition*/.css("position");
			this.bPositionEpingle = sPosition == "fixed" || sPosition == "absolute" || this.jqBaliseCible.hasClass("fixedcoulisse");

			//force l'homothétie sur les img
			this.bHomothetieSelonHauteur = (this.jqBaliseCible[0].tagName.toLowerCase() == "img" );//&& this.jqBaliseCible.css("height")=="auto" ) ?

			//retire toute transition sur transform
			var sTransitionCourante = this.jqBaliseCibleTransform.css("transition");
			if (sTransitionCourante && sTransitionCourante!='' && sTransitionCourante!='none')
			{
				this.jqBaliseCibleTransform.css("transition",sTransitionCourante.replace('transform','content').replace('all','content'));
			}
			// //sauf pour IE où on la force afin que le décalage en Y ne soit pas trop saccadé à chaque coup de molette
			// if (bIEAvec11)
			// {
			// 	sTransitionCourante = this.jqBaliseCibleTransform.css("transition");
			// 	this.jqBaliseCibleTransform.css("transition",
			// 		(
			// 			(sTransitionCourante && sTransitionCourante!='' && sTransitionCourante!='none')
			// 			? (sTransitionCourante+" ")
			// 			: ""
			// 		)
			// 		+ "transform 300ms"
			// 	);
			// }
			//balises de positionnement zoning
			var jqTable = undefined;
			var jqTr = undefined;
			var bBaliseTd = this.jqBaliseCible.is("td");
			if (!this.bPositionEpingle)
			{
				//retire la contrainte de hauteur des parents de positionnement
				jqTable = this.jqBaliseCible.closest("table")
				if (!bBaliseTd)
				{
					jqTable.css("height","auto");
				}
				if (jqTable)
				{
					//mémorise la ligne
					jqTr = jqTable.closest("tr");

					//Note : impossible de trouver une technique fonctionnelle sur IE et Edge (celle ci est ok sur Chrome et FF)
					// //place le premier frère suivant au dessus
					// jqTable.parents().each(function(){
					// 	//si pas de frère, remonte
					// 	if (!$(this).next().length)
					// 	{
					// 		return;
					// 	}
					// 	$(this).next().css("transform","translateZ(0px)");
					// 	//return false;//s'arrête
					// });
				}
			}

			//if (this.oParallaxe.dTauxHauteur) à faire toujours car ..dTauxParallaxeHauteur peut être appelé ensuite
			{
				//hauteur initiale pour calculer le ratio
				this.nHauteurChampCourante = this.nHauteurChamp = this.nHauteurChampInitiale =  parseInt(this.jqBaliseCible.attr("data-height"),10) || this.jqBaliseCible.height();
				//applique la hauteur min pour éviter que le parallaxe de hauteur n'aille en dessous
				this.nHauteurChampMin = parseInt(this.jqBaliseCible.attr("data-min-height"),10) ||  1;
				this.jqBaliseCible.css("min-height",this.nHauteurChampMin+"px").css("height",this.nHauteurChampInitiale+"px");

				if (!this.bPositionEpingle)
				{
					//retire la contrainte de hauteur des parents de positionnement
					if (jqTr && jqTr.children().length==1)
					{
						jqTr.css("height","auto");
					}
				}

				var jqTd =  bBaliseTd ? this.jqBaliseCible : this.jqBaliseCible.find("td").first();
				var jqPremierFilsDeContenu = jqTd.children().first();
				if (jqPremierFilsDeContenu.is("div[class*=pos]"))
				{
					jqPremierFilsDeContenu.css("height","auto").css("min-height",0);
				}

				//pour IE on évite le calcul d'ancrage
				if (bIEAvec11)
				{
					this.jqBaliseCible.add(jqTable||$()).removeClass("h100").addClass("h100non");
				}
			}

			//force au dessus des autres s'il y a du taux Y
			if (this.oParallaxe.dTauxY)
			{
				var jqParent = this.jqBaliseCibleTransform;

				while( (jqParent=jqParent.parent()).length )
				{
					if (jqParent.next().length)
					{
						if (jqParent.css("position") == "static")
							jqParent.css("position","relative");
						var zIndex = parseInt(jqParent.css("zIndex"));
						if (isNaN(zIndex) || !zIndex)
							jqParent.css("zIndex",1);
						break;
					}
				}

			}

			//retire la hauteur sur la table après avoir déterminer sa hauteur initiale
			if (!this.bPositionEpingle && jqTable && jqTable.length)
			{
				jqTable.css("height","auto");
			}


		});

		//init supp pour les parallaxes de fond
		this.jqListeChampParallaxeFond.each(function()
		{
			if (!this.oParallaxe.dTauxFond)
			{
				return;
			}
			this.jqBaliseCibleFond = this.jqBaliseCibleConteneur;
			//descend éventuellement au td
			if (this.jqBaliseCibleFond.css("background-image")=="none" && this.jqBaliseCibleFond[0].tagName.toLowerCase() == "table")
			{
				//déplace la classe sur le td si c'est lui qui a le fond
				this.jqBaliseCibleFond.removeClass("wbParallaxFond");//utile?
				this.jqBaliseCibleFond = this.jqBaliseCibleFond.find("td").first();
			}
			//masque le champ le temps que le 1er calcul soit fait
			this.jqBaliseCibleFond.css("opacity",0);
			var jqBaliseCibleFond = this.jqBaliseCibleFond;
			requestAnimationFrame(function(){
				//1er chargement du fond
				jqBaliseCibleFond.wbBgLoadAsync(jqBaliseCibleFond,function()
				{
					//blinde le cas où il n'y a pas d'image de fond
					//arrive pour le champ superposé car son div superposable et le td ont le data-wbParallaxeFond
					//mais seul le td a l'image de fond => le mieux serait d'éviter de doubler certains data-
					if (this.height && this.width)
					{
						this.balise.addClass("wbParallaxFond");
						this.balise[0].dRatioImageFond = this.height/this.width;
						//OPTIM : il risque d'y avoir plusieurs trigger initiaux
						$(window).trigger("trigger.wb.cache.window").trigger("scroll.wb.parallax");
					}
					//+rend visible le champ une fois le fond re travaillé
					this.balise./*css("opacity","");*/animate({opacity : 1});
				});
			});
			//pas de fixed en mobile
			if (clWDUtil.bGetNavigateurMobile())
			{
				this.jqBaliseCibleFond.attr("style", "background-attachment:scroll !important;" + (this.jqBaliseCibleFond.attr("style") ||"") );
			}
		});

		$(window)
			.on("trigger.wb.rwd.tranche.changement resize.wb.parallax trigger.wb.parallax.fond.maj.dimensions",function(){
				//utile pour les parallaxes de fond uniquement en cas d'ancrage
				this.jqListeChampParallaxeFond.each(function()
				{
					var jqChamp = $(this);
					this.nHauteurChamp =  jqChamp.height();
					this.nLargeurChamp =  jqChamp.width();
					this.nPositionX =  jqChamp.offset().left;	//à cause du centrage dans la page
				});
			})
			.trigger("trigger.wb.cache.window")
			.trigger("trigger.wb.parallax.fond.maj.dimensions")
		;
	}

	//évite les triggers sans dessins intermédiaires
	$.fn.s_wbParallaxeUpdateFond.appelDemande = true;

	//update les champs avant le RAF
	//lance wbParallaxeUpdateChamp pour qu'il soit fait avant calcul du fond
	window.jqListeChampParallaxeChamp.wbParallaxeUpdateChamp();

	//update les fonds après le RAF
	requestAnimationFrame($.fn.s_wbParallaxeUpdateFond);
	//et relance wbParallaxeUpdateChamp pour qu'il soit refait pour le dessin
	requestAnimationFrame(function(){ window.jqListeChampParallaxeChamp.wbParallaxeUpdateChamp() });

	// pour que les modifications de hauteur via parallaxe applique les ancrages en hauteur dans le champ
	if (!this.bRebondScrollResizeParallaxeIE && bIEAvec11)
	{
		$(window).scroll(function()
		{
			$(window).trigger("resize");
		})
		//.on("trigger.wb.ancrage.ie.fin",function(){ } ) ?
		;
		//à faire une seule fois
		this.bRebondScrollResizeParallaxeIE=true;
	}
});

//Permet de travailler depuis la table ou le td du champ
$.fn.wbTauxParallaxeInstance = function()
{
	var domBalise = this[0];
	if (!domBalise.oParallaxe)
	{
		var sBalise = this[0].tagName.toLowerCase();
		if (sBalise == "table")
		{
			domBalise = this.find("td").first().get(0);
		}
		else if ( (sBalise == "td") || (sBalise == "tr") )
		{
			domBalise = this.closest("table").first().get(0);
		}
		else
		{
			domBalise = this.parent().get(0);
		}
	}
	//non trouvé ?
	if (!domBalise.oParallaxe)
	{
		//n'est pas encore initialisé ?
		$(window).trigger("trigger.wb.parallax.load");
		return (domBalise.oParallaxe) ? domBalise : this[0];
	}
	return domBalise;
};

//..TauxParallaxeHauteur
$.fn.wbTauxParallaxeHauteurGet = function() {
	return this.wbTauxParallaxeInstance().oParallaxe.dTauxHauteur * 1000;
};
$.fn.wbTauxParallaxeHauteurSet = function(dCoeff) {
	this.wbTauxParallaxeInstance().oParallaxe.dTauxHauteur = dCoeff / 1000;
	if (this[0].parentElement.oParallaxe && this[0].parentElement.id === "dww" + this[0].id)
		this[0].parentElement.oParallaxe.dTauxHauteur = dCoeff / 1000;
};

//..TauxParallaxeY
$.fn.wbTauxParallaxeYGet = function() {
	return this.wbTauxParallaxeInstance().oParallaxe.dTauxY * 1000;
};
$.fn.wbTauxParallaxeYSet = function(dCoeff) {
	this.wbTauxParallaxeInstance().oParallaxe.dTauxY = dCoeff / 1000;
	if (this[0].parentElement.oParallaxe && this[0].parentElement.id === "dww" + this[0].id)
		this[0].parentElement.oParallaxe.dTauxY = dCoeff / 1000;
};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Effet d'apparition

// .wbEffetApparition
// {
//     animation-name: deplace, fondu;
//     animation-delay: 0s, 0s;
//     animation-direction: normal,normal;
//     animation-duration: 0.5s,1s;
//     animation-fill-mode: forwards,forwards;
//     animation-iteration-count: 1,1;
//     animation-play-state: running,running;
//     animation-timing-function: ease,ease;
// }
//
// .wbEffetApparitionDisparitionAnimationJoue
// {
//
// }
var bApparitionSelonProprieteVisible = 0 && !!window.MutationObserver;

$.fn.wbDelencheAffichageSiVisible = function(bSiInvisible,domBalise,bForceDisparition) {
    var counter = 0;
    var settings = {
        threshold       : 0, //-(window.nHauteurNavigateur/4), //TODO à peaufiner selon la hauteur du navigateur
        failure_limit   : 0,
        event           : "scroll",
        container       : window,
        skip_invisible  : true,
        appear          : null
    };

    //pour chaque champ
    this.each(function() {

        var $this = $(this);
        var bAffiche = undefined;
        this.wbEffetApparitionDisparitionSettings = this.wbEffetApparitionDisparitionSettings || $.extend({},settings,{ threshold: (this.nHauteurChamp||(this.nHauteurChamp=$(this).height())) });
    	this.wbEffetApparitionDisparitionParents = this.wbEffetApparitionDisparitionParents || $this.parents(".dzSpan,.dzSpanRiche").filter(function(){
			return 'hidden' != $(this).css("overflow"); //ignore les conteneur qui ne font que tronquer car ils ne scrollent pas
    	}).add(window);

    	//pour chaque conteneur à débordement de ce champ
    	this.wbEffetApparitionDisparitionParents.each(function(){

	    	var wbEffetApparitionDisparitionSettings = $.extend({},$this[0].wbEffetApparitionDisparitionSettings,{ container : this});

	        if (wbEffetApparitionDisparitionSettings.skip_invisible && (!$this.is(":visible") || (bApparitionSelonProprieteVisible && $this.css("visibility")=="hidden")) ) {
	            return;
	        }
	        //TODO OPTIM en conservant les valeurs de taille/position de champ et window en cas de scroll uniquement
	    	if (!bForceDisparition && !$.belowthefold($this[0],wbEffetApparitionDisparitionSettings))
	    	{
	    	   //QUID de plusieurs niveaux de conteneurs à débordement et certains rendent le champ masqué ?
	           bAffiche=true;
	    	   return false;
	    	}
	    	else if (bSiInvisible && $.belowthefold($this[0],wbEffetApparitionDisparitionSettings))
	    	{
	    		//QUID de plusieurs niveaux de conteneurs à débordement et certains rendent le champ masqué ?
	    		bAffiche=false;
	    		return false;
	    	}

    	});

    	if (bAffiche===true)
    	{
           $this.trigger("trigger.wb.effet.apparition.affiche");
    	}
    	else if (bAffiche===false)
    	{
    		$this.trigger("trigger.wb.effet.apparition.masque");
    	}

    });


};

//à chaque resize scroll
$(window).on("scroll.wb.effet.apparition resize.wb.effet.apparition load.wb.effet.apparition trigger.wb.postUpdateLayoutSuperposableEpingle.apparition.effet.apparition trigger.wb.postUpdateLayoutSuperposableEpingle.disparition.effet.disparition",function(jqEvent,domBalise)
{
	var $window = $(this);
	var domWindow = this;

	//init
	if (!domWindow.jqListeChampApparuEtEnAttenteDeDisparition)
	{
		//init uniquement au load, pas avant
		if (jqEvent.type.toLowerCase()!="load")
		{
			return;
		}
		var jqListeChampApparition = $("[data-wbEffetApparition]");
		var jqListeChampDisparition = $("[data-wbEffetDisparition]");
		//pas de champ ?
		if (jqListeChampApparition.length+jqListeChampDisparition.length==0)
		{
			//désactive
			$window.off("scroll.wb.effet.apparition resize.wb.effet.apparition load.wb.effet.apparition trigger.wb.postUpdateLayoutSuperposableEpingle.apparition.effet.apparition trigger.wb.postUpdateLayoutSuperposableEpingle.disparition.effet.disparition");
			return;
		}
		domWindow.jqListeChampApparuEtEnAttenteDeDisparition = $();
		domWindow.jqListeChampEnAttenteDeApparition = $();
		//init
		jqListeChampApparition.not(jqListeChampDisparition).add(jqListeChampDisparition).each(function()
		{
			//charge les effets
			var wbEffetApparitionDisparition = {};
			var jqThis = $(this);//contient les data
			var jqChamp = jqThis;
			var bVisiblePrecedent = jqChamp.css("visibility")=="visible";
			var optionsObserver = { attributes: true };
			if (jqThis.attr("data-wbEffetApparition"))
			{
				//écoute les mutations de ..visible
				if (bApparitionSelonProprieteVisible)
				{
					//observe les modifications d'attribut du champ
					jqChamp[0].observerApparition = new MutationObserver(function(mutations) {

						var bVisible = jqChamp.css("visibility")!="hidden";
						if (bVisible && !bVisiblePrecedent)
						{

							//déconnecte le temps de l'animation
							!jqChamp[0].observerApparition || jqChamp[0].observerApparition.disconnect();
							!jqChamp[0].observerDispparition || jqChamp[0].observerDispparition.disconnect();

							jqChamp.css("visibility","visible");//force visible pour faire jouer l'animation, sera masqué en fin
							jqChamp.trigger("trigger.wb.effet.apparition.affiche",[undefined,function(){
								bVisiblePrecedent=true;
								//rebind la disparition
								!jqChamp[0].observerDispparition || jqChamp[0].observerDispparition.observe(jqChamp[0],optionsObserver);
							}]);
						}
					});
					if (!bVisiblePrecedent)
						jqChamp[0].observerApparition.observe(jqChamp[0],optionsObserver);
				}
				wbEffetApparitionDisparition.oApparition = jqThis.wbJsonParseAttr("data-wbEffetApparition");
				jqChamp.removeAttr("data-wbEffetApparition");
				//replace le champ sur la balise la plus externe
				if (wbEffetApparitionDisparition.oApparition)
				{
					//ajoute par recherche d'id => add va créer une liste triée dans l'ordre du DOM
					jqChamp = jqChamp.add( jqChamp.parents(wbEffetApparitionDisparition.oApparition.sId) );
				}
			}
			if (jqThis.attr("data-wbEffetDisparition"))
			{
				//écoute les mutations de ..visible
				if (bApparitionSelonProprieteVisible)
				{
					//observe les modifications d'attribut du champ
					jqChamp[0].observerDispparition = new MutationObserver(function(mutations) {

						var bVisible = jqChamp.css("visibility")!="hidden";
						if (!bVisible && bVisiblePrecedent)
						{

							//déconnecte le temps de l'animation
							!jqChamp[0].observerApparition || jqChamp[0].observerApparition.disconnect();
							!jqChamp[0].observerDispparition || jqChamp[0].observerDispparition.disconnect();

							jqChamp.css("visibility","visible");//force visible pour faire jouer l'animation, sera masqué en fin
							jqChamp.trigger("trigger.wb.effet.apparition.masque",[undefined,function(){
								bVisiblePrecedent=false;
								//rebind l'apparition
								jqChamp.css("visibility","hidden");
								!jqChamp[0].observerApparition || jqChamp[0].observerApparition.observe(jqChamp[0],optionsObserver);
							}]);
						}

					});
					if (bVisiblePrecedent)
						jqChamp[0].observerDispparition.observe(jqChamp[0],optionsObserver);
				}
				wbEffetApparitionDisparition.oDisparition = jqThis.wbJsonParseAttr("data-wbEffetDisparition");
				jqChamp.removeAttr("data-wbEffetDisparition");
				//replace le champ sur la balise la plus externe
				if (wbEffetApparitionDisparition.oDisparition)
				{
					//ajoute par recherche d'id => add va créer une liste triée dans l'ordre du DOM
					jqChamp = jqChamp.add( jqChamp.parents(wbEffetApparitionDisparition.oDisparition.sId) );
				}
			}

			//comme .add a créé une liste triée dans l'ordre du DOM
			//jqChamp[0] est le plus externe
			jqChamp = jqChamp.first();

			//stocke les données dans le champ externe
			jqChamp[0].wbEffetApparitionDisparition = wbEffetApparitionDisparition;

			//facilite la recherche des balises via DOM
			jqChamp
				.addClass("wbEffetApparitionDisparition")
				//en attente d'apparition donc masqué
				.css("opacity",0)
			;

			//ajoute le champ dans la liste des champs en attente d'apparition
			domWindow.jqListeChampEnAttenteDeApparition = domWindow.jqListeChampEnAttenteDeApparition.add(jqChamp);
		});

		var fDesappliqueEffet = function(jqChamp,bMasque)
		{
			jqChamp
				//.removeClass("wbEffetApparitionDisparitionAnimationJoue")
				.css("animation","")
				.css("transition","")
				.css("transform","")
			;

			//TODO scroll horizontal pendant anim à désactiver ?
			// //évite les débordements avec ascenseurs causés par les transform sur les éléments absolute
			// //cf. http://stackoverflow.com/questions/21248111/overflow-behavior-after-using-css3-transform
			// if (--$window.wbCompteurEffetApparitionDisparition==0)
			// {
			// 	$("html,body").css("overflow-x","");
			// }

			fAlwaysDesappliqueEffet(jqChamp,bMasque);
		};
		var fAlwaysDesappliqueEffet = function(jqChamp,bMasque)
		{
			//applique un overflow hidden pour ne pas voir les champs au delà du conteneur de l'animation
			var jqPlanConteneur = jqChamp.closest(".wbPlanConteneur,#page");
			if (jqPlanConteneur.length && jqPlanConteneur.queue().length==0)
			{
				jqPlanConteneur.removeClass("wbEffetEnCours");
			}
		};

		var fAffiche = function(jqEvent,oEffetPlan,fCallbackFin)
		{
			var jqChamp = $(this);

			//déclenchement ?
			if (this.wbEffetApparitionDisparition.oApparition)
			{

				//TODO scroll horizontal pendant anim à désactiver ?
				// //évite les débordements avec ascenseurs causés par les transform sur les éléments absolute
				// //cf. http://stackoverflow.com/questions/21248111/overflow-behavior-after-using-css3-transform
				// $("html,body").css("overflow-x","hidden");
				// $window.wbCompteurEffetApparitionDisparition = ($window.wbCompteurEffetApparitionDisparition||0)+1;

				//via transformation ?
				//conflit avec le parralaxe de champ
				//blindage car l'édition devrait interdire ce cumul d'effet
				if (!this.nOffsetTransformationPrecedente)
				{
					jqChamp.css("transform",(this.wbEffetApparitionDisparition.oApparition.transform||""));
				}
				//via opacité ?
				jqChamp.css("opacity",(this.wbEffetApparitionDisparition.oApparition.opacity||""));

				//note tech : il est plus rapide de passer par un setTimeout mais l'application de la transformation+transition n'a pas toujours le résultat voulu
				//- plus rapide : car on évite le isHidden propre à animate qui demande un reflow
				//- résultat différent : car la transformation initiale n'a pas le temps d'être prise en compte que déjà elle est raz (pour faire transition)
				jqChamp.stop("wbEffetApparitionDisparition",true,false).animate({content:1},
				{
					queue:"wbEffetApparitionDisparition"
				,	oEffet : this.wbEffetApparitionDisparition.oApparition
				,	start : function(pAnimation)
						{
						//applique un overflow hidden pour ne pas voir les champs au delà du conteneur de l'animation
						jqChamp.closest(".wbPlanConteneur,#page").addClass("wbEffetEnCours");
						//jqChamp.addClass("wbEffetApparitionDisparitionAnimationJoue");
						jqChamp
							.css("animation",(pAnimation.tweens[0].options.oEffet.animation||""))
							.css("opacity","")
							.css(
								"transition"
							,	(pAnimation.tweens[0].options.oEffet.transition||"")
								.replace
								(
									"transform"
									//blindage car l'édition devrait interdire ce cumul d'effet
								,	(!this.nOffsetTransformationPrecedente ? "transform" : "content")
								)
							)
						;
						//conflit avec le parralaxe de champ
						//blindage car l'édition devrait interdire ce cumul d'effet
						if (!this.nOffsetTransformationPrecedente)
						{
							jqChamp
								.css("transform","")
							;
						}
					}
				, 	duration : this.wbEffetApparitionDisparition.oApparition.nDuree
				, 	done : function()//et pas alaways afin de gérer le cas de scroll en yoyo qui doit reprendre la transition
					{
						fDesappliqueEffet(jqChamp);
						//callback d'après affichage
						if (oEffetPlan && oEffetPlan.fCallback)
						{
							oEffetPlan.fCallback();
						}
					}
				, 	always : function()
					{
						fAlwaysDesappliqueEffet(jqChamp);
						!fCallbackFin || fCallbackFin();
					}
				})
				.dequeue("wbEffetApparitionDisparition");
				//une seule fois ? et que le champ ne vas plus disparaître
				if (!this.wbEffetApparitionDisparition.oDisparition && this.wbEffetApparitionDisparition.oApparition.bToujours===false)
				{
					delete this.wbEffetApparitionDisparition.oApparition;
				}
			}

			//retire le champ de la liste des champs à afficher
			domWindow.jqListeChampEnAttenteDeApparition = jqListeChampEnAttenteDeApparition.not(jqChamp);
			//passe le champ dans la liste des champs à masquer
			domWindow.jqListeChampApparuEtEnAttenteDeDisparition = domWindow.jqListeChampApparuEtEnAttenteDeDisparition.add(jqChamp);

			//masque dès que invisible
			var fMasque = function(jqEvent,oEffetPlan,fCallbackFin)
			{
				//déclenchement de l'effet
				var bRetourMasquageViaEffet = false;
				if (this.wbEffetApparitionDisparition.oDisparition)
				{
					bRetourMasquageViaEffet=true;
					//TODO scroll horizontal pendant anim à désactiver ?
					// //évite les débordements avec ascenseurs causés par les transform sur les éléments absolute
					// //cf. http://stackoverflow.com/questions/21248111/overflow-behavior-after-using-css3-transform
					// $("html,body").css("overflow-x","hidden");
					// $window.wbCompteurEffetApparitionDisparition = ($window.wbCompteurEffetApparitionDisparition||0)+1;

					//applique l'effet sans la transformation
					jqChamp
						.css("transition",(this.wbEffetApparitionDisparition.oDisparition.transition||"")
						//blindage car l'édition devrait interdire ce cumul d'effet
						.replace("transform",(!this.nOffsetTransformationPrecedente ? "transform" : "content") ))
					;

					//appliquer une classe et la retirer en fin d'animation pour appliquer une classe opacity:0;
					//car le champ est masqué mais doit être à sa place pour le détecter re visible
					jqChamp.stop("wbEffetApparitionDisparition",true,false).animate({content:1},
					{
						queue:"wbEffetApparitionDisparition"
					,	oEffet : this.wbEffetApparitionDisparition.oDisparition
					,	start : function(pAnimation)
						{
						//applique un overflow hidden pour ne pas voir les champs au delà du conteneur de l'animation
						jqChamp.closest(".wbPlanConteneur,#page").addClass("wbEffetEnCours");
						jqChamp
							.css("animation",(pAnimation.tweens[0].options.oEffet.animation||""))
							.css("opacity",(pAnimation.tweens[0].options.oEffet.opacity||""))
						;
						//conflit avec le parralaxe de champ
						//blindage car l'édition devrait interdire ce cumul d'effet
						if (!this.nOffsetTransformationPrecedente)
						{
							jqChamp
								.css("transform",(pAnimation.tweens[0].options.oEffet.transform||""))
							;
						}
					}
					, 	duration : this.wbEffetApparitionDisparition.oDisparition.nDuree
					, 	done : function()//et pas alaways afin de gérer le cas de scroll en yoyo qui doit reprendre la transition
					{
						//callback d'après masquage
						if (oEffetPlan && oEffetPlan.fCallback)
						{
							oEffetPlan.fCallback();
						}
						fDesappliqueEffet(jqChamp,true);
						jqChamp
							//force transparent car masqué
							.css("opacity",0)
						;
					}
					,	always : function()
						{
							fAlwaysDesappliqueEffet(jqChamp,true);
							!fCallbackFin || fCallbackFin();
						}
					})
					.dequeue("wbEffetApparitionDisparition");
					//une seule fois ?
					if (this.wbEffetApparitionDisparition.oDisparition.bToujours===false)
					{
						delete this.wbEffetApparitionDisparition.oDisparition;
					}
				}
				//force transparent car masqué jusqu'à la prochaine apparition
				else if (this.wbEffetApparitionDisparition.oApparition)
				{
					if (!oEffetPlan)
					{
						jqChamp.css("opacity",0);
					}
				}
				else//<=> if (!this.wbEffetApparitionDisparition.oApparition && !this.wbEffetApparitionDisparition.oDisparition)
				{
					//aucun autre affichage/masquage à faire
					delete this.wbEffetApparitionDisparition;
					//évite le re bind l'affichage
					return;
				}
				//re bind l'affichage
				jqChamp.one("trigger.wb.effet.apparition.affiche",fAffiche);
				return bRetourMasquageViaEffet;
			};
			//bind le masquage qui suit l'affichage
			jqChamp.one("trigger.wb.effet.apparition.masque",fMasque);
			return true;
		};
		//bind le 1er affichage
		domWindow.jqListeChampEnAttenteDeApparition.one("trigger.wb.effet.apparition.affiche",fAffiche);

		var fMajEcouteScroll = function()
		{
			$(document.getElementsByClassName("dzSpan")).add($(document.getElementsByClassName("dzSpanRiche"))).each(function(){
				if (this.wbEffetApparitionDisparitionLocalDeja) return;
				this.wbEffetApparitionDisparitionLocalDeja = true;
				var jqBalise = $(this);
				jqBalise.on("scroll.wb.effet.apparition",function(){
					$(window).trigger("trigger.wb.postUpdateLayoutSuperposableEpingle.apparition"); 
				});
			});
		};
		fMajEcouteScroll();

		//cas de ZRAjoute en AJAX, changement de tranche...
		var fNotifMaj = function()
		{ 
			fMajEcouteScroll(); // au cas où on reçoit un nouvel élément à débordement il faut l'écouter
			$(window).trigger("trigger.wb.postUpdateLayoutSuperposableEpingle.apparition"); 
		};
		if (window.NSPCS)
		{
			// Notifie aussi de la modification du HTML de la page
			NSPCS.NSUtil.ms_oNotificationsAjoutHTML.AddNotification(fNotifMaj);
			NSPCS.NSUtil.ms_oNotificationsFinAJAX.AddNotification(fNotifMaj);
			//changement de tranche => ré init les globales de tailles min
			NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(fNotifMaj);
		}
		//en cas de mise à jour de html par ajax
		if (window["clWDUtil"]!==undefined)
		{
			if (clWDUtil.m_oNotificationsAjoutHTML)
			{
				clWDUtil.m_oNotificationsAjoutHTML.AddNotification(fNotifMaj);
			}
			if (clWDUtil.m_oNotificationsFinAJAX)
			{
				clWDUtil.m_oNotificationsFinAJAX.AddNotification(fNotifMaj);
			}
		}

	}

	//délenche l'affichage des champs désormais visibles
    domWindow.jqListeChampEnAttenteDeApparition.wbDelencheAffichageSiVisible(false,domBalise);
    //ou le masquage des champs qui ne le sont plus
    domWindow.jqListeChampApparuEtEnAttenteDeDisparition.wbDelencheAffichageSiVisible(true,domBalise,jqEvent.namespace && jqEvent.namespace.indexOf("disparition")===0);

});

$(window).on("load.wb.focus.viajs",function(){
	//les pages php et statiques ont le le tabindex géré côté navigateur, tandis que les pages awp et moteur le font côté serveur
	var href = document.location.href.toLowerCase();
	function bPageDeType(sExt,href) { return (href.lastIndexOf("." + sExt) + 1 + sExt.length) == href.length; }
	if (bPageDeType('html',href) || bPageDeType('htm',href) || bPageDeType('php',href))
	$(document).on('keydown', '[tabindex]', function(oEvent)
	{
		//effectue le changement de focus
		function _bChangeFocusParProg(e,jqChamp,bSuivant)
		{
			//champ table pour ce champ
			var jqChampTable = jqChamp.closest("[id^=con-]");
			//ligne du champ
			var jqLigne = jqChamp.closest(".wbImpaire,.wbPaire");
			//est dans un conteneur répété ?
			if (!jqLigne || !jqLigne.length)
			{
				//non, laisse faire le navigateur
				return;
			}
			var nTabIndexProchain = parseInt(jqChamp.attr("tabindex")) + (bSuivant ? 1 : -1);
			//recherche ce tabindex dans la ligne
			var jqChampProchain = jqLigne.find("[tabindex=" + nTabIndexProchain + "]");
			//pas dans la ligne?
			if (!jqChampProchain || !jqChampProchain.length)
			{
				//lignes de toute la table
				var jqLignes = jqChampTable.find(".wbImpaire,.wbPaire");
				var nIndiceLigne = jqLignes.index(jqLigne);
				//avance ou recule d'une ligne pour trouver le prochain
				if (bSuivant)
				{
					++nIndiceLigne;
				}
				else
				{
					--nIndiceLigne;
				}
				//la ligne existe pas
				if (nIndiceLigne<0 || nIndiceLigne>=jqLignes.length || !(jqLigne = jqLignes.eq(nIndiceLigne)).length)
				{
					//on laisse le navigateur faire pour sortir dela ZR
					return;
				}
				//trouve le premier / dernier champ avec focus
				nTabIndexProchain = -1;
				jqLigne.find("[tabindex]").each(function()
				{
					var nTabIndex = parseInt($(this).attr("tabindex"));
					if (nTabIndexProchain==-1 ||(bSuivant ? nTabIndexProchain>nTabIndex : nTabIndexProchain<nTabIndex))
					{
						nTabIndexProchain=nTabIndex;
						jqChampProchain = $(this);
					}
				});
				if (!jqChampProchain || !jqChampProchain.length)
				{
					//pas de champ avec focus...étrange car dans cette ligne il y en a et pas dans l'autre
					return;
				}
			}
			//donne le focus
			jqChampProchain.focus();
			return true;
		}

	///#DEBUG
		console.log(oEvent);
	///#ENDDEBUG
		if ((oEvent.keyCode || oEvent.which) != 9)
		{
			return;
		}
	///#DEBUG
		var dateDebut = window.performance ? performance.now() : new Date();
	///#ENDDEBUG
		if (_bChangeFocusParProg(oEvent,$(this),!oEvent.shiftKey))
		{
			//annule le TAB défaut du navigateur
			oEvent.preventDefault();
		}
	///#DEBUG
		var dateFin = window.performance ? performance.now() : new Date();
		console.log(dateFin- dateDebut);
	///#ENDDEBUG

	});

});

// Point d'entrée pour être rappelé après l'exécution du pcode navigateur d'après ajax
function wbTableZrInfiniSuiteAuPcodeApresAjax(sAliasChamp, ValeurRetourServeur)
{
	return $("#con-" + sAliasChamp + ",#ctz" + sAliasChamp).wbTableZrInfiniSuiteAuPcodeApresAjax(ValeurRetourServeur);
}

// Point d'entrée pour la fonction composante TableAjoutEnCours ZoneRépétéeAjoutEnCours
function wbTableZoneRepeteeAjoutEnCours(sAliasChamp, bValeur)
{
	return $("#con-" + sAliasChamp + ",#ctz" + sAliasChamp).wbTableZoneRepeteeAjoutEnCours(bValeur);
}

//ZoneRepeteeAjoutEnCours
$.fn.wbTableZoneRepeteeAjoutEnCours = function (bValeur) 
{
	var domBalise = this[0];

	if (bValeur === undefined) return false !== domBalise.wbConteneurInfiniAjoutEnCours;
	domBalise.wbConteneurInfiniAjoutEnCours = !!bValeur;
	if (domBalise.wbConteneurInfiniAjoutEnCours)
	{
		//ré autorise
		domBalise.wbConteneurInfiniAjoutInterdit = false;
		//passe en manuel 
		domBalise.wbConteneurInfiniModeManuel = true;
		// Affiche la page interne
		domBalise.fAffichePageInterne();
	}
	else 
	{
		//passe en mode automatique
		domBalise.wbConteneurInfiniModeManuel = false;
		// Masque la page interne (conditionnelement ?? et si on est en bas ?)
		domBalise.fMasquePageInterne();
	}
};
//- Après le "Après AJAX"
$.fn.wbTableZrInfiniSuiteAuPcodeApresAjax = function(sRetourPcodeServeur) 
{
	var domBalise = this[0];

	// traiter le retour faux 
	if (sRetourPcodeServeur==="0")
	{
		//interdit de charger à nouveau
		domBalise.wbConteneurInfiniAjoutInterdit=true;
	}

	// fin de l'ajout
	var sConteneurInfiniAjoutEnCoursPrecedent = domBalise.wbConteneurInfiniAjoutEnCours;
	domBalise.wbConteneurInfiniAjoutEnCours=false;

	// masque la jauge en s'assurant qu'elle est restée affichée au moins 500ms
	if (!domBalise.wbConteneurInfiniModeManuel)
	{
		var nDureeAffiche = new Date() - domBalise.wbConteneurInfiniAjoutEnCoursTimestamp;
		domBalise.wbConteneurInfiniAjoutEnCoursTimer = setTimeout(function()
		{
			domBalise.fMasquePageInterne();
			domBalise.wbConteneurInfiniAjoutEnCoursTimer = undefined;
		}
		,Math.max(1,500-nDureeAffiche));
	}

	// boucle si besoin
	// traiter le contenu identique
	// si c'est pareil alors on évite de boucler sur le test 
	if (domBalise.innerHTML != sConteneurInfiniAjoutEnCoursPrecedent)
	{
		domBalise.fChargeInfiniSiBesoin();
	}	
};

// ZR infinie
if (document.getElementsByClassName) $(window).on("scroll.wb.zrinfinie resize.wb.zrinfinie load.wb.zrinfinie trigger.wb.zrinfinie.test",function(jqEvent,domBalise)
{
	//identifie les ZR infinies 	
	$(document.getElementsByClassName("wbConteneurInfini")).each(function()
	{
		// le client ne veut plus que sa ZR ait du chargement infini
		if (this.wbConteneurInfiniAjoutInterdit===true) return;
		// si l'ajout est déjà en cours on attend
		if (this.wbConteneurInfiniAjoutEnCours!==undefined && this.wbConteneurInfiniAjoutEnCours!==false) return;//vaut undefined false "html"

		var jqTableZrInfini = $(this);

		if (!this.wbZrInfinieInitFait)
		{
			this.sAliasTableOuZr = jqTableZrInfini.hasClass("wbTableInfinie") ? this.id.substr(3)/*ctz*/ : this.id.substr(4)/*con-*/;
			this.wbConteneurInfiniAjoutEnCours=false;
			//TODO repérer le conteneur de la ZR, il peut s'agir d'un autre élément que window 
			var jqDebordement = $(window);
			// page interne de chargement 
			this.wbConteneurInfiniPageInterne = jqTableZrInfini.next().filter(".wbConteneurInfiniJauge");
			// non trouvé ou vide
			if (!this.wbConteneurInfiniPageInterne.length || this.wbConteneurInfiniPageInterne.get(0).innerHTML=="")
			{
				this.wbConteneurInfiniPageInterne.remove();
				//fabrique une jauge par défaut 
				this.wbConteneurInfiniPageInterne = $('<div class="wbConteneurInfiniJauge wbConteneurInfiniJauge' + this.sAliasTableOuZr + '"></div>');
				// contenu par défaut de jauge infinie
				this.wbConteneurInfiniPageInterne.append($('<div class="wbConteneurInfiniJaugeLoader"><svg class="wbConteneurInfiniJaugeCircular" viewBox="25 25 50 50"><circle class="wbConteneurInfiniJaugePath" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/></svg></div>'));
				//place dans la page
				this.wbConteneurInfiniPageInterne.insertAfter(jqTableZrInfini);
			}

			//Vérifie si besoin de charger des données
			this.fChargeInfiniSiBesoin = function()
			{
				//si la table/zr a son bas qui est dans la partie visible 
				if (jqTableZrInfini.offset().top + jqTableZrInfini.height() > jqDebordement.scrollTop() && jqTableZrInfini.offset().top + jqTableZrInfini.height() < jqDebordement.scrollTop() + jqDebordement.height())
				{
					this.wbConteneurInfiniAjoutEnCours = this.innerHTML;
					this.fAffichePageInterne();
					this.wbConteneurInfiniAjoutEnCoursTimestamp = new Date();
		    		//appel du pcode (on sera rappelé via wbTableZrInfiniSuiteAuPcodeApresAjax)
		        	if(false===clWDUtil.pfGetTraitement(this.sAliasTableOuZr, 87, undefined)(event))
	        		{
	        			//cas du pcode navigateur avec RENVOYER Faux
	        			jqTableZrInfini.wbTableZrInfiniSuiteAuPcodeApresAjax("0");
	        		}
		    	}
			}.bind(this);
			// Affiche la page interne
			this.fAffichePageInterne = function ()
			{
				//cas où la jauge est encore affichée (pendant ses 500ms) et qu'il faut encore prendre des nouveaux enregs
				if (this.wbConteneurInfiniAjoutEnCoursTimer !== undefined)
				{
					clearTimeout(this.wbConteneurInfiniAjoutEnCoursTimer);
					this.wbConteneurInfiniAjoutEnCoursTimer = undefined;
				}
				//rendre visible et positionner la page interne 
				this.wbConteneurInfiniPageInterne.css({
					display: "block"
					, opacity: 0
					, width: jqTableZrInfini.width()
				});
				//TODO appliquer les ancrages superposables dans la PI insérée
				jqTableZrInfini.css({
					marginBottom: this.wbConteneurInfiniPageInterne.height()
				});
				this.wbConteneurInfiniPageInterne.css({
					marginTop: -this.wbConteneurInfiniPageInterne.height()
					, opacity: 1
				});
			}.bind(this);
			// Masque la page interne
			this.fMasquePageInterne = function ()
			{
				this.wbConteneurInfiniPageInterne.hide();
			}.bind(this);

			this.wbZrInfinieInitFait = true;
		}

		this.fChargeInfiniSiBesoin();

	});
});