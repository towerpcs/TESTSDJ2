/*!
Grab Bag - Assorted Detritus
  (c) 2008 Jason Frame (jason@onehackoranother.com)
  Released under The MIT License.
 */
jQuery().ready(function(){

	/*
	* Auto-growing textareas; technique ripped from Facebook
	*/
    $.fn.autogrow = function(options) {
        
        this.filter('textarea').each(function() {
            
            var $this       = $(this),
                minHeight   = $this.data("min-height") || $this.data("height") || $this.height();
            var nPaddingLateral = parseInt($this.css('paddingLeft')) - parseInt($this.css('paddingRight'));
            

            var shadow = $(document.createElement('div')).css({
                position:   'absolute',
                wordWrap:   'break-word', //GF ajoute le wrapping pour ne avoir de scroll sur des phrases sans espaces              
                top:        -10000,
                left:       -10000,
                fontSize:   $this.css('fontSize'),
                fontFamily: $this.css('fontFamily'),
                lineHeight: $this.css('lineHeight'),
                resize:     'none',
                pointerEvents:     'none',
                visibility:     'hidden'
            }).appendTo(document.body);
            
            //SUGG avec transition ?
            // var sTransCourant = $this.css("transition")||"none";
            // if (sTransCourant) 
            // {
            //     sTransCourant += ",";
            // }
            // else if (sTransCourant==="none")
            // {
            //     sTransCourant = "";
            // }

            var update = function(oEvent,bSansAnim) {
    
                //SUGG avec transition ?
                // if (bSansAnim)
                // {
                //     $this.css("transition", sTransCourant+"height 0ms ease,width 0ms" );
                // }
                // else 
                // {
                //     $this.css("transition", sTransCourant+"height 300ms ease,width 0ms" );
                // }

                var times = function(string, number) {
                    for (var i = 0, r = ''; i < number; i ++) r += string;
                    return r;
                };
                
                var val = $this[0].value.replace(/</g, '&lt;')
                                    .replace(/>/g, '&gt;')
                                    .replace(/&/g, '&amp;')
                                    .replace(/\n$/, '<br/>&nbsp;')
                                    .replace(/\n/g, '<br/>')
                                    .replace(/ {2,}/g, function(space) { return times('&nbsp;', space.length -1) + ' '; });
                
                //maj la largeur en cas d'ancrage
                shadow.css("width",$this.width() - nPaddingLateral).html(val);
				//GF offset double pour eiter un a/retour haut bas
                var nHeight = Math.max(shadow.height() + 40, minHeight);
                $this.css({'height': nHeight}).css('overflow' 	, 'hidden');//GF pas de scroll                
            };
            //bind
            $this.change(update).keyup(update).keydown(update);
            clWDUtil.AttacheOnScrollResize(function(oEvent, bOnScroll)
            {
                if (bOnScroll)
                {
                    return;
                }
                if (clWDUtil.bEstDisplay($this[0],document,false))
                {
                    update.apply($this[0],[oEvent,false]);
                }
                else 
                {
                    //appel après le traitement courant car le plan parant n'est peut etre pas encore actif
                    //il faut donc le laisser etre actif avant de tester .width()
                    //sans anim car initialement non visible
                    setTimeout(function(){update.apply($this[0],[oEvent,true]);},1);
                }
            });            
            
            //1er appel sans anim
            update.apply(this,[undefined,true]);            
        });        
        return this;        
    };
    
    //1ere init
    wbAutogrowInit();

    //les prochaines init seront lors d'ajout ajax
    if (window.clWDUtil!==undefined) 
    {
        if (clWDUtil.m_oNotificationsAjoutHTML)
        {
            clWDUtil.m_oNotificationsAjoutHTML.AddNotification(wbAutogrowInit);
        }
        if (clWDUtil.m_oNotificationsFinAJAX)
        {
            clWDUtil.m_oNotificationsFinAJAX.AddNotification(wbAutogrowInit);
        }
    }
});

//parsede le chargement 
//mais ne sera exeutequ'apre le ready par la page geee cf. CECPHSaisie::vEcritAvantBodyFerme
function wbAutogrowInit()
{
    //s'applique aux textarea avec la class autoresize
    //+ resize:none : Pour deactiver le grip pour retailler les textareas sous webkit
    //cela empehe jQuery d'agrandir les champs correctement quand il y en a plusieurs
    //source http://www.electrictoolbox.com/disable-textarea-resizing-safari-chrome/    
    $("textarea.autoresize")
        .filter(function()
        {
            //eite de le faire 2 fois sur les mes instances
            if ($(this).data("wbAutogrowInit"))
            {
                return false;
            }   
            return true;
        })
        .data('wbAutogrowInit',true)
        .css('resize','none')
        .autogrow()
    ;    
}