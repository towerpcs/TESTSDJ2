/*! VersionVI: yyyyyyyyyyyy */
// 19.0.1.0 jquery-effet.js

///#DEBUG=clWDUtil.WDDebug

//var imgVide = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";

//source : https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/String/trim
//compat IE8
if (!String.prototype.trim) {
  String.prototype.trim = function () {
    return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
  };
}
//compat quirks
if (!window.Object)
{
	window.Object= {};
}

//polyfill source: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Objets_globaux/Array/fill
if (!Array.prototype.fill) {
  Array.prototype.fill = function fill(value) {
    

      // Steps 1-2.
      if (this == null) {
        throw new TypeError('this is null or not defined');
      }

      var O = Object(this);

      // Steps 3-5.
      var len = O.length >>> 0;

      // Steps 6-7.
      var start = arguments[1];
      var relativeStart = start >> 0;

      // Step 8.
      var k = relativeStart < 0 ?
        Math.max(len + relativeStart, 0) :
        Math.min(relativeStart, len);

      // Steps 9-10.
      var end = arguments[2];
      var relativeEnd = end === undefined ?
        len : end >> 0;

      // Step 11.
      var final = relativeEnd < 0 ?
        Math.max(len + relativeEnd, 0) :
        Math.min(relativeEnd, len);

      // Step 12.
      while (k < final) {
        O[k] = value;
        k++;
      }

      // Step 13.
      return O;
    
  };
}


//utilise requestAnimationFrame
/*
 * jquery.requestAnimationFrame
 * https://github.com/gnarf37/jquery-requestAnimationFrame
 * Requires jQuery 1.8+
 *
 * Copyright (c) 2012 Corey Frang
 * Licensed under the MIT license.
 */

//(function( jQuery ) {

if ( !window.requestAnimationFrame )
{
	// polyfill
	window.requestAnimationFrame = function( callback, element ) {
		var currTime = new Date().getTime(),
			timeToCall = Math.max( 0, 16 - ( currTime - lastTime ) ),
			id = window.setTimeout( function() {
				callback( currTime + timeToCall );
			}, timeToCall );
		lastTime = currTime + timeToCall;
		return id;
	};

	window.cancelAnimationFrame = function(id) {
		clearTimeout(id);
	};
}


//polyfill pour requestIdleCallback
if (!window.requestIdleCallback)
{
	window.requestIdleCallback = requestAnimationFrame;
	window.cancelIdleCallback = cancelAnimationFrame;
}	

// requestAnimationFrame polyfill adapted from Erik Möller
// fixes from Paul Irish and Tino Zijdel
// http://paulirish.com/2011/requestanimationframe-for-smart-animating/
// http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating
if (jQuery.fn && parseFloat(jQuery.fn.jquery)>=3)
{	
	//en version 3, jQuery utilise déjà rAF
}
else 
{

	var animating,
		lastTime = 0,
		vendors = ['webkit', 'moz'],
		requestAnimationFrame = window.requestAnimationFrame,
		cancelAnimationFrame = window.cancelAnimationFrame;

	for(; lastTime < vendors.length && !requestAnimationFrame; lastTime++) {
		requestAnimationFrame = window[ vendors[lastTime] + "RequestAnimationFrame" ];
		cancelAnimationFrame = cancelAnimationFrame ||
			window[ vendors[lastTime] + "CancelAnimationFrame" ] || 
			window[ vendors[lastTime] + "CancelRequestAnimationFrame" ];
	}

	function raf() {
		if ( animating ) {
			requestAnimationFrame( raf );
			jQuery.fx.tick();
		}
	}

	// use rAF
	window.requestAnimationFrame = requestAnimationFrame;
	window.cancelAnimationFrame = cancelAnimationFrame;
	jQuery.fx.timer = function( timer ) {
		if ( timer() && jQuery.timers.push( timer ) && !animating ) {
			animating = true;
			raf();
		}
	};

	jQuery.fx.stop = function() {
		animating = false;
	};
}
//}( jQuery ));

function extendEvent(domEvent,oAutre)
{
    if (!oAutre)//blindage
    {
        oAutre = {};
    }

    var oriEvent = domEvent.originalEvent ? domEvent.originalEvent : domEvent;

    //JSON.parse(JSON.stringify(domEvent)); => non car exception circulaire
    //return $.extend({},domEvent,oAutre); => coûteux
    //optim par copie des membres utilisés uniquement
    return $.extend({
        pageX            : nGetPageX(oAutre) || nGetPageX(domEvent)
    ,   pageY            : nGetPageY(oAutre) || nGetPageY(domEvent)
    ,   target           : oriEvent.target
    ,   type             : oriEvent.type
    ,   button           : oriEvent.button
    ,   stopPropagation  : oriEvent.stopPropagation
    ,   grfX             : domEvent.grfX
    ,   grfY             : domEvent.grfY
    ,   keyCode          : oriEvent.keyCode
    ,   offsetX          : oriEvent.offsetX
    ,   offsetY          : oriEvent.offsetY
    ,   originalEvent    : oriEvent.originalEvent
    ,   touches          : oriEvent.touches
    ,   key              : oriEvent.key
    ,   code             : oriEvent.code
    ,   changedTouches   : oriEvent.changedTouches
    ,   deltaY           : oriEvent.deltaY  

    //pour le preventDefault 
    , domEvent : domEvent

    //complète avec plus
    },oAutre);
}
function _getPageX(event)
{
    if (!event)
    {
        return undefined;
    }
    if (event.grfX)
    {
        return event.grfX;
    }
    return (event.touches && event.touches.length && event.touches[0].pageX!==undefined) ? event.touches[0].pageX : event.pageX;
}
function _getPageY(event)
{
    if (!event)
    {
        return undefined;
    }
    if (event.grfY)
    {
        return event.grfY;
    }   
    return (event.touches && event.touches.length && event.touches[0].pageY!==undefined) ? event.touches[0].pageY : event.pageY;
}
function nGetPageX(event,defaut)
{
    if (!event)
    {
        return defaut;
    }       
    return _getPageX(event.originalEvent) || _getPageX(event) || defaut;
}
function nGetPageY(event,defaut)
{
    if (!event)
    {
        return defaut;
    }       
    return _getPageY(event.originalEvent) || _getPageY(event) || defaut;
}
function nGetDeltaY(event,defaut)
{
    if (!event)
    {
        return defaut;
    }   
    //http://www.javascriptkit.com/javatutors/onmousewheel.shtml
    return event.deltaY || event.originalEvent.deltaY || (event.detail || event.originalEvent.detail || 0)*40 || defaut;
}

/**
 * https://github.com/joelpurra/emulatetab/blob/master/LICENSE
 
EmulateTab javascript library.
A jQuery plugin to emulate tabbing between elements on a page.
Developed for PTS by Joel Purra <http://joelpurra.se/>

Copyright (c) 2011, 2012, 2013, 2014, The Swedish Post and Telecom Authority (PTS)

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted
provided that the following conditions are met:

 - Redistributions of source code must retain the above copyright notice, this list of
   conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this list
   of conditions and the following disclaimer in the documentation and/or other materials
   provided with the distribution.
 - Neither the name of the copyright holder nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific prior written
   permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
(function(document, $, pluginName) {
    "use strict";

    var eventNamespace = "." + pluginName,

        // TODO: get code for :focusable, :tabbable from jQuery UI?
        focusable = ":input, a[href]",

        // Keep a reference to the last focused element, use as a last resort.
        lastFocusedElement = null,

        // Private methods
        internal = {
            escapeSelectorName: function(str) {
                // Based on http://api.jquery.com/category/selectors/
                // Still untested
                return str.replace(/(!"#$%&'\(\)\*\+,\.\/:;<=>\?@\[\]^`\{\|\}~)/g, "\\\\$1");
            },

            findNextFocusable: function($from, offset) {
                var $focusable = $(focusable)
                    .not(":disabled")
                    .not(":hidden")
                    .not(".wbSaisieJetonsInput")
                    .not("[tabindex=-1]")
                    .not("a[href]:empty");

                if ($from[0].tagName === "INPUT" && $from[0].type === "radio" && $from[0].name !== "") {
                    var name = internal.escapeSelectorName($from[0].name);

                    $focusable = $focusable
                        .not("input[type=radio][name=" + name + "]")
                        .add($from);
                }

                var currentIndex = $focusable.index($from);

                var nextIndex = (currentIndex + offset) % $focusable.length;

                if (nextIndex <= -1) {
                    nextIndex = $focusable.length + nextIndex;
                }

                var $next = $focusable.eq(nextIndex);

                return $next;
            },

            focusInElement: function(event) {
                lastFocusedElement = event.target;
            },

            tryGetElementAsNonEmptyJQueryObject: function(selector) {
                try {
                    var $element = $(selector);

                    if ( !! $element && $element.size() !== 0) {
                        return $element;
                    }
                } catch (e) {
                    // Could not use element. Do nothing.
                }

                return null;
            },

            // Fix for EmulateTab Issue #2
            // https://github.com/joelpurra/emulatetab/issues/2
            // Combined function to get the focused element, trying as long as possible.
            // Extra work done trying to avoid problems with security features around
            // <input type="file" /> in Firefox (tested using 10.0.1).
            // http://stackoverflow.com/questions/9301310/focus-returns-no-element-for-input-type-file-in-firefox
            // Problem: http://jsfiddle.net/joelpurra/bzsv7/
            // Fixed:   http://jsfiddle.net/joelpurra/bzsv7/2/

            getFocusedElement: function() {
                // 1. Try the well-known, recommended method first.
                //
                // 2. Fall back to a fast method that might fail.
                // Known to fail for Firefox (tested using 10.0.1) with
                // Permission denied to access property "nodeType".
                //
                // 3. As a last resort, use the last known focused element.
                // Has not been tested enough to be sure it works as expected
                // in all browsers and scenarios.
                //
                // 4. Empty fallback
                var $focused = internal.tryGetElementAsNonEmptyJQueryObject(":focus") || internal.tryGetElementAsNonEmptyJQueryObject(document.activeElement) || internal.tryGetElementAsNonEmptyJQueryObject(lastFocusedElement) || $();

                return $focused;
            },

            emulateTabbing: function($from, offset) {
                var $next = internal.findNextFocusable($from, offset);

                $next.focus();
            },

            initializeAtLoad: function() {
                // Start listener that keep track of the last focused element.
                $(document)
                    .on("focusin" + eventNamespace, internal.focusInElement);
            }
        },

        plugin = {
            tab: function($from, offset) {
                // Tab from focused element with offset, .tab(-1)
                if ($.isNumeric($from)) {
                    offset = $from;
                    $from = undefined;
                }

                $from = $from || plugin.getFocused();

                offset = offset || +1;

                internal.emulateTabbing($from, offset);
            },

            forwardTab: function($from) {
                return plugin.tab($from, +1);
            },

            reverseTab: function($from) {
                return plugin.tab($from, -1);
            },

            getFocused: function() {
                return internal.getFocusedElement();
            }
        },

        installJQueryExtensions = function() {
            $.extend({
                emulateTab: function($from, offset) {
                    return plugin.tab($from, offset);
                }
            });

            $.fn.extend({
                emulateTab: function(offset) {
                    return plugin.tab(this, offset);
                }
            });
        },

        init = function() {
         

            installJQueryExtensions();

            // EmulateTab initializes listener(s) when jQuery is ready
            $(internal.initializeAtLoad);
        };

    init();
}(document, jQuery, "EmulateTab"));

/*!
 * jQuery UI Touch Punch 0.2.3
 *
 * Copyright 2011–2014, Dave Furfero
 * Dual licensed under the MIT or GPL Version 2 licenses.
 *
 * Depends:
 *  jquery.ui.widget.js
 *  jquery.ui.mouse.js
 */ (function($) {

    // Detect touch support
    $.support.touch = 'ontouchend' in document;

    // Ignore browsers without touch support
    if (!$.ui || !$.support.touch) {
        return;
    }

    var mouseProto = $.ui.mouse.prototype,
        _mouseInit = mouseProto._mouseInit,
        _mouseDestroy = mouseProto._mouseDestroy,
        touchHandled;

    /**
     * Simulate a mouse event based on a corresponding touch event
     * @param {Object} event A touch event
     * @param {String} simulatedType The corresponding mouse event
     */
    function simulateMouseEvent(event, simulatedType) {

        // Ignore multi-touch events
        if (event.originalEvent.touches.length > 1) {
            return;
        }

        event.preventDefault();

        var touch = event.originalEvent.changedTouches[0],
            simulatedEvent = document.createEvent('MouseEvents');

        // Initialize the simulated mouse event using the touch event's coordinates
        simulatedEvent.initMouseEvent(
        simulatedType, // type
        true, // bubbles                    
        true, // cancelable                 
        window, // view                       
        1, // detail                     
        touch.screenX, // screenX                    
        touch.screenY, // screenY                    
        touch.clientX, // clientX                    
        touch.clientY, // clientY                    
        false, // ctrlKey                    
        false, // altKey                     
        false, // shiftKey                   
        false, // metaKey                    
        0, // button                     
        null // relatedTarget              
        );

        // Dispatch the simulated event to the target element
        event.target.dispatchEvent(simulatedEvent);
    }

    /**
     * Handle the jQuery UI widget's touchstart events
     * @param {Object} event The widget element's touchstart event
     */
    mouseProto._touchStart = function(event) {

        var self = this;

        // Ignore the event if another widget is already being handled
        if (touchHandled || !self._mouseCapture(event.originalEvent.changedTouches[0])) {
            return;
        }

        // Set the flag to prevent other widgets from inheriting the touch event
        touchHandled = true;

        // Track movement to determine if interaction was a click
        self._touchMoved = false;

        // Simulate the mouseover event
        simulateMouseEvent(event, 'mouseover');

        // Simulate the mousemove event
        simulateMouseEvent(event, 'mousemove');

        // Simulate the mousedown event
        simulateMouseEvent(event, 'mousedown');
    };

    /**
     * Handle the jQuery UI widget's touchmove events
     * @param {Object} event The document's touchmove event
     */
    mouseProto._touchMove = function(event) {

        // Ignore event if not handled
        if (!touchHandled) {
            return;
        }

        // Interaction was not a click
        this._touchMoved = true;

        // Simulate the mousemove event
        simulateMouseEvent(event, 'mousemove');
    };

    /**
     * Handle the jQuery UI widget's touchend events
     * @param {Object} event The document's touchend event
     */
    mouseProto._touchEnd = function(event) {

        // Ignore event if not handled
        if (!touchHandled) {
            return;
        }

        // Simulate the mouseup event
        simulateMouseEvent(event, 'mouseup');

        // Simulate the mouseout event
        simulateMouseEvent(event, 'mouseout');

        // If the touch interaction did not move, it should trigger a click
        if (!this._touchMoved) {

            // Simulate the click event
            simulateMouseEvent(event, 'click');
        }

        // Unset the flag to allow other widgets to inherit the touch event
        touchHandled = false;
    };

    /**
     * A duck punch of the $.ui.mouse _mouseInit method to support touch events.
     * This method extends the widget with bound touch event handlers that
     * translate touch events to mouse events and pass them to the widget's
     * original mouse event handling methods.
     */
    mouseProto._mouseInit = function() {

        var self = this;

        // Delegate the touch handlers to the widget's element
        self.element.bind({
            touchstart: $.proxy(self, '_touchStart'),
            touchmove: $.proxy(self, '_touchMove'),
            touchend: $.proxy(self, '_touchEnd')
        });

        // Call the original $.ui.mouse init method
        _mouseInit.call(self);
    };

    /**
     * Remove the touch event handlers
     */
    mouseProto._mouseDestroy = function() {

        var self = this;

        // Delegate the touch handlers to the widget's element
        self.element.unbind({
            touchstart: $.proxy(self, '_touchStart'),
            touchmove: $.proxy(self, '_touchMove'),
            touchend: $.proxy(self, '_touchEnd')
        });

        // Call the original $.ui.mouse destroy method
        _mouseDestroy.call(self);
    };

})(jQuery);

$.fn.oneOfThem = function(sNom,fCallback)
{
	return this.each( function() {
		var jqThis = $(this);
		jqThis.one(sNom,function(jqEvent)
		{ 
			if (!fCallback.oneOfThem)
			{
				fCallback.oneOfThem=true;
				fCallback.apply(this);
				//off automatique par l'appel en one
			}
			else 
			{
				//off l'autre event qui est associé à la même callback
				jqThis.off(jqEvent);			
			}
		});		
	} );
};

$.fn.wbJsonParseAttr = function(sNom,bNullSiAbsent) {
	try 
	{
		if (bNullSiAbsent && !this.attr(sNom))
		{
			return undefined;
		}

        //essaye sans nettoyage
        try 
        {
            return JSON.parse(this.attr(sNom));
        }
        catch (e)
        {
           //
        }
        //avec nettoyage des ' (pour les attributs écrits par la HTML?)
        return JSON.parse(this.attr(sNom).replace(/'/g,'"'));
	}
	catch (e)
	{
		if (window["clWDUtil"] && clWDUtil.WDDebug) 
		{
			clWDUtil.WDDebug.assert(false, "JSON incorrect dans " + sNom);
		}
		return undefined;
	}
};
$.fn.wbGetClassCommencePar = function(sDebut,bRetourAvecDebut) {
	//trouve la classe de son numéro 
	var tabClasses = this.attr("class").split(' ');	
	for (var iClasse=0; iClasse<tabClasses.length; ++iClasse)
	{
		var sClasse = tabClasses[iClasse];
		if (sClasse.indexOf(sDebut) === 0)
		{
			return sClasse.substr(bRetourAvecDebut ? 0 : sDebut.length);
		}
	}
	return undefined;
};

//TODO Sugg gérer soi même l'ordre des appels au chargement ainsi et retirer les on("load") de partout et faire l'appel 
//$(window).trigger("trigger.wb.load"); dans le onload= de body afin d'être appelé avant le code utilisateur

// //ordre des appels au chargement
// $(window).one("trigger.wb.load",function()
// {
// 	$(this)
// 		.trigger("trigger.wb.cache.windowinit")
// 		.trigger("trigger.wb.rwd.media.charge")
// 		.trigger("trigger.wb.plan.chargement")
// 	;
// });

(function(){

var oDescAgencements = undefined;  

function nTrouveAgencementSelonLargeurMin(nLargeurTest)
{
    var nIndiceAgencementTrouve;
    for(var i=0; i<oDescAgencements.tabLargeurMin.length; ++i)
    {
        if (oDescAgencements.tabLargeurMin[i] < nLargeurTest)
        {
            if ((nIndiceAgencementTrouve===undefined) || (oDescAgencements.tabLargeurMin[nIndiceAgencementTrouve]<oDescAgencements.tabLargeurMin[i]))
            {
                  nIndiceAgencementTrouve=i;  
            }
        }
    }
    return nIndiceAgencementTrouve;
}

$(window).on("DOMContentLoaded.wb.cache.window load.wb.cache.window trigger.wb.cache.windowinit",function()
{
	//TODO refaire le cache à chaque notif d'ajout html
	var $body = $(document.body);
    oDescAgencements = $body.wbJsonParseAttr('data-wbAgencements',true);
    if (oDescAgencements)
    {
        //fait croire que l'agencement courant est celui qui aurait du être alors que c'est forcé par prog
        //afin que le resize au sein du même agencement programmé ne provoque pas de changement
        if (oDescAgencements.indiceForce>-1)
        {
            oDescAgencements.courant = nTrouveAgencementSelonLargeurMin(document.documentElement.clientWidth);
        }
    }
	$(this).trigger("trigger.wb.cache.window");
	window.nHauteurPage = $body.height();
	window.nLargeurPage = $body.width();

});


// impression de page (hors l'iframe elle même)
if (window.addEventListener && window === window.parent)
{    
    (function()
    {
        // iframe de l'impression
        var iframePrint = null;

        // avant l'impression
        var avantImpression = function(e) 
        {            
            // pas 2 fois
            if (iframePrint) return;

            // ignore en l'absence d'agencement d'impression
            if (!oDescAgencements || !oDescAgencements.bAvecPrint) return;

            // création de l'iframe d'impression
            iframePrint = document.createElement('iframe');
            iframePrint.setAttribute("id","print");
            iframePrint.setAttribute("style","display:none;");
            document.body.append(iframePrint);        
            
            // appel aJAX synchrone pour bloquer l'aperçu le temps que la page revienne
            var xhr = new XMLHttpRequest();
            xhr.open("POST", clWDUtil.sGetPageAction(), false);            
            xhr.onload = function (e) 
            {
                // si requete pas ok on quitte en nettoyant
                if (false === ((xhr.readyState === 4) && (xhr.status === 200))) 
                { 
                    apresImpression();  
                    return; 
                }

                // ajoute le contenu
                iframePrint.contentWindow.document.write(xhr.responseText);
                
                var oAttributsHTML = iframePrint.contentWindow.document.documentElement.attributes;

                
                iframePrint.contentWindow.document.documentElement.remove();
                var div = iframePrint.contentWindow.document.createElement('html');
                div.innerHTML = xhr.responseText.trim();
                iframePrint.contentWindow.document.insertBefore(div,undefined);
                
                for(oAttribute in oAttributsHTML)
                {
                    if ( oAttributsHTML.hasOwnProperty(oAttribute) && isNaN(oAttribute) )
                        iframePrint.contentWindow.document.documentElement.setAttribute(oAttribute.name,oAttribute.value);
                }

                // transforme le contenu en balise => ainsi les scripts sont exécutés, les css téléchargées etc.
                var tab = iframePrint.contentWindow.document.body.querySelectorAll("*");
                for(var i =tab.length-1; i>-1; i--){
                    var elem = tab[i];
                    var balise = $(elem).clone(true,true);
                    // attention si on fait àa pour 2 balises scripts sync alors elles sotn exécutées à l'envers non?
                    elem.parentNode.insertBefore(balise[0],elem);    
                    elem.remove();                    
                }

                var tabJS = iframePrint.contentWindow.document.documentElement.querySelectorAll("script");                
                for(var i =0; i<tabJS.length; ++i){
                    var elem = tabJS[i];
                    var newScript = document.createElement("script");
                    var sScript;
                    if (elem.src)
                    {
                        var xhrJS = new iframePrint.contentWindow.XMLHttpRequest();
                        xhrJS.open("GET", elem.src, false);
                        xhrJS.onload = function (e) 
                        {
                            // si requete pas ok on quitte en nettoyant
                            if (false === ((xhrJS.readyState === 4) && (xhrJS.status === 200))) 
                            { 
                                return; 
                            }            
                            sScript  = xhrJS.responseText;                                 
                        };
                        try {                            
                        xhrJS.send(null);  
                        }
                        catch(e){
                            //e
                        }
                    }
                    else 
                    {
                        sScript = elem.innerText;
                    }
                    var inlineScript = iframePrint.contentWindow.document.createTextNode(sScript);
                    newScript.appendChild(inlineScript); 
                    // attention si on fait àa pour 2 balises scripts sync alors elles sotn exécutées à l'envers non?
                    elem.parentNode.insertBefore(newScript,elem);    
                    elem.remove();                    
                }


                var tabCSS = iframePrint.contentWindow.document.documentElement.querySelectorAll("link");                
                for(var i =0; i<tabCSS.length; ++i){
                    var elem = tabCSS[i];
                    var newScript = document.createElement("style");
                    var sScript;
                    if (elem.href)
                    {
                        var xhrJS = new iframePrint.contentWindow.XMLHttpRequest();
                        xhrJS.open("GET", elem.href, false);
                        xhrJS.onload = function (e) 
                        {
                            // si requete pas ok on quitte en nettoyant
                            if (false === ((xhrJS.readyState === 4) && (xhrJS.status === 200))) 
                            { 
                                return; 
                            }            
                            sScript  = xhrJS.responseText;                                 
                        };
                        try {                            
                        xhrJS.send(null);  
                        }
                        catch(e){
                            //e
                        }  
                    }
                    else 
                    {
                       continue;
                    }
                    var inlineScript = iframePrint.contentWindow.document.createTextNode(sScript);
                    newScript.appendChild(inlineScript); 
                    // attention si on fait àa pour 2 balises scripts sync alors elles sotn exécutées à l'envers non?
                    elem.parentNode.insertBefore(newScript,elem);    
                    elem.remove();                    
                }                

                // hack pour charger les images dans la page directement en datauri
                // note : rien est fait pour les image de fond... il faudrait alors parcourir tout le DOM avec le GetComputedStyle et remplacer le background par son datauri
                iframePrint.contentWindow.document.body.querySelectorAll("img").forEach( 
                function(elem)
                {
                    if (elem.src)
                    {
                        var xhrImg = new iframePrint.contentWindow.XMLHttpRequest();
                        xhrImg.open("GET", elem.src, false);                        
                        xhrImg.onload = function (e) 
                        {
                            // si requete pas ok on quitte en nettoyant
                            if (false === ((xhrImg.readyState === 4) && (xhrImg.status === 200))) 
                            { 
                                return; 
                            }   
                            var binary = '';
                            var response = xhrImg.responseText;         
                            for(i=0;i<response.length;i++){
                                binary += String.fromCharCode(response.charCodeAt(i) & 0xff);
                            }        
                            elem.src = 'data:image/jpeg;base64,' + btoa(binary);                             
                        };          
                        xhrImg.overrideMimeType('text/plain; charset=x-user-defined');              
                        try {                            
                            xhrImg.send(null);  
                        }
                        catch(e){
                            //e
                        }                        
                        if (elem.complete && elem.onload) elem.onload();
                        else 
                        {
                            elem.style.opacity = 1;
                            // cas où 'image homothétique n'est pas prête => on la rend visible de force
                            if (  $(elem).parent().hasClass("wbHnImg") )
                            {
                                elem.parentElement.style.opacity = 1;
                                // $(elem).parent().add(elem).css({
                                //     opacity : 1
                                // });                     
                            }
                        }
                    }
                });  

                //if (iframePrint.contentWindow.document.body.onload) iframePrint.contentWindow.document.body.onload();
                iframePrint.contentWindow.$(iframePrint.contentWindow.document.body).trigger("DOMContentLoaded");
                iframePrint.contentWindow.$(iframePrint.contentWindow.document.body).trigger("load");
            };
            // demande le chargement de la page dans son agencement print
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            //TODO params pour agencement print ? 
            //xhr.send("WD_JSON_PROPRIETE_=&WD_BUTTON_CLICK_=A6");            
            //_JSL(_PAGE_, "", "_self", "", 0, "CHANGEMENTAGENCEMENT") mais en XHR et avec contrôle du onload
            // NSPCS.NSAjax.ExecuteEvenement(_PAGE_, sAlias, jqPlan.wbPlanGetIndice(), 14 /*EContenuRequeteEvenement.PlanDiffere*/, 78 /*ETraitementNavigateur.ChargementDifferePlan*/);
            // manque le post de tout le formulaire 
            xhr.send("WD_ACTION_=AGENCEMENTIMPRESSION");
        };

        // après l'impression (ok ou annulée)
        var apresImpression = function(e) 
        {
            // nettoyage        
            if (!iframePrint) return;
            iframePrint.remove();
            iframePrint = null;            
        };

        // écoute sur matchmedia et window
        if (window.matchMedia) 
        {
            var mediaQueryList = window.matchMedia('print');
            mediaQueryList.addListener(function(mql) 
            {
                // appelé que en cas d'aperçu
                if (mql.matches) 
                {
                    avantImpression();
                }
            });
        }
        // appelé pour le dialogue de print ou l'aperçu
        window.addEventListener('beforeprint', avantImpression);
        window.addEventListener('afterprint', apresImpression);

        // hack pour éviter que chrome ne cancel les XHR synchrones qui suivent
        var windowPrint = window.print;
        window.print = function(){
            avantImpression();
            windowPrint();
        };         
    })();
}

$(window).on("scroll.wb.cache.window trigger.wb.cache.window",function()
{
	var $window = $(this);
	window.nBordHautNavigateur = $window.scrollTop();	
	window.nBordGaucheNavigateur = $window.scrollLeft();
	window.nBordDroitNavigateur = window.nLargeurNavigateur + window.nBordGaucheNavigateur;
	window.nBordBasNavigateur = window.nBordHautNavigateur + window.nHauteurNavigateur;
});

$(window).on("resize.wb.cache.window trigger.wb.cache.window",function(jqEvent)
{
	var $window = $(this);	
	window.nHauteurNavigateur = $window.height();  
	window.nLargeurNavigateur = $window.width();  	
	window.nBordDroitNavigateur = window.nLargeurNavigateur + window.nBordGaucheNavigateur;
	window.nBordBasNavigateur = window.nBordHautNavigateur + window.nHauteurNavigateur;
    //mémorise la largeur dans un cookie pour les agencements
    //préseve l'agencement modifié par programmation au 1er affichage et ne touche pas au cas iframe de print
    if (oDescAgencements && (window === window.parent) && (oDescAgencements.indiceForce === -1 || jqEvent.type === "resize") )
    { 
       document.cookie = "wbNavigateurLargeur=" + document.documentElement.clientWidth + ";path=/"    ;    //pas d'exprires pour que le cookie dure le temps de la session
       if (window.wbTimerAgencementReload!==undefined) 
       {
           clearTimeout(window.wbTimerAgencementReload);
       }
       //changement d'agencement par redimensionnement du navigateur
       window.wbTimerAgencementReload = setTimeout(function()
       {
           if (nTrouveAgencementSelonLargeurMin(document.documentElement.clientWidth) != oDescAgencements.courant)
           {
               clearTimeout(window.wbTimerAgencementReload);
               //URL spéciale et appel de pcode 
               _JSL(_PAGE_, "", "_self", "", 0, "CHANGEMENTAGENCEMENT")
               //note : window.location.reload(); provoque une désynchro et ne permet pas de changer l'agencement
           }
       },300);
    }

});

})();

$(function(){

	function InitDepuisData(jqElement,sData,xValeurDefaut)
	{
		var nResultat = xValeurDefaut;
		if (jqElement.data(sData)!==undefined)		
			nResultat = jqElement.data(sData);	
			
		var jqParent = jqElement.parent();
		if (jqParent!==undefined && jqParent.attr("data-effet-marquee"))
		{
			if (jqParent.data(sData)!==undefined)		
				nResultat = jqParent.data(sData);			
		}
		return nResultat;
	}

	$("[data-effet-marquee=mono]").each(function(){	
		var jqThis = $(this);
		
		//paramètres du défilement
		var nHauteurDefilement 	= parseInt(InitDepuisData(jqThis,"height",jqThis.height()));
		var nLargeurDefilement 	= parseInt(InitDepuisData(jqThis,"width",jqThis.width()));
		var nScrollDelay		= parseInt(InitDepuisData(jqThis,"effet-vitesse",20));
		var sComportement		= InitDepuisData(jqThis,"effet-comportement","scroll");
		var jqMarquee 			= $("<marquee />");
		//Se place sur la balise dans laquelle injecter le marquee
		if (jqThis[0].tagName.toUpperCase() == "TABLE")
		{
			if (jqThis.find("[data-effet-marquee=mono]").length>0) return;
			jqThis = jqThis.find("td");
		}			
		if (jqThis[0].tagName.toUpperCase() == "A")
		{
			if (jqThis.children().first()[0]!==undefined && jqThis.children().first()[0].tagName.toUpperCase() == "SPAN")
			{
				jqThis = jqThis.children().first();
				if (jqThis[0]!==undefined && jqThis[0].tagName.toUpperCase() == "SPAN")
				{
					jqThis = jqThis.children().first();					
				}
			}			
		}
		//contournement de bug de hauteur du td toujours trop grande
		if (jqThis[0].tagName.toUpperCase() == "TD")
		{	
			jqThis.css("line-height","0");
			jqMarquee.css("line-height","normal");
		}			
		//dans jdThis on met le marquee		
		jqMarquee					
			.attr("scrollamount","1")
			.attr("truespeed","1")
			.attr("behavior", sComportement)
			.attr("scrolldelay",nScrollDelay)
			.html(jqThis.html())						
			.bind("mouseleave mouseblur",function(){ $(this).attr("scrolldelay",nScrollDelay); } )
			.bind("mouseover mousemove",function(){ $(this).attr("scrolldelay",100000000); } )
			//.css("display","block") //si block, le marquee est désactivé sous opéra => pas de défilement mais texte visible
			//.css("width",$("<span />").append(jqThis.html()).width())	=> largeur obtenue 0... l'idéal serait de tailler le marquee selon la largeur réel du texte et non du champ
		;
			
		//insère le marquee
		jqThis.html("").append(jqMarquee);					
	});

	//Effet de texte défilant
	$("[data-effet-marquee=multi]").each(function(){	
		var jqThis = $(this);

		
		//paramètres du défilement
		var nHauteurDefilement 	= parseInt(InitDepuisData(jqThis,"height",jqThis.height()));
		var nLargeurDefilement 	= parseInt(InitDepuisData(jqThis,"width",jqThis.width()));
		var nVitesse 			= parseInt(InitDepuisData(jqThis,"effet-vitesse",1500));
		var nDelai 				= parseInt(InitDepuisData(jqThis,"effet-delai",2000));		
		var sFonction 			= window.jQuery.ui ? "easeOutExpo" : "swing"; //defaut
		var sSens 				= "margin-top";//défaut		
		
		//test sur quelle balise porter l'action de défilement
		var bEstRiche =  (jqThis.text() != jqThis.html());
		if (jqThis[0].tagName.toUpperCase() == "TABLE")
		{
			if (jqThis.find("[data-effet-marquee=multi]").length>0) return;
			jqThis = jqThis.find("td");
		}			
		if (jqThis[0].tagName.toUpperCase() == "A")
		{
			var jqTest = jqThis;
			
			if (jqThis.children().first()[0]!==undefined && jqThis.children().first()[0].tagName.toUpperCase() == "SPAN")
			{
				jqTest = jqThis.children().first();
				if (jqTest[0]!==undefined && jqTest[0].tagName.toUpperCase() == "SPAN")
				{
					jqTest = jqTest.children().first();	
					bEstRiche = (jqTest.text() != jqTest.html());
					if (!bEstRiche)
					{
						//pas un bouton riche => on fait défiler les spans
						//jqThis = jqThis;
					}
					else
					{
						//un bouton riche ? on défile dans les spans
						jqThis = jqTest;
					}
				}
			}			
			
		}
		//cas du champ lien où la classe est appliquée 2 fois
		else if (jqThis.children().first().attr("data-effet-marquee"))		
		{
			return;//jqThis = jqThis.children().first();	
		}
		
		//limite le span à la taille d'édition du champ
		var jqSpanVue = $("<span/>")
			.css("overflow","hidden")
			.css("display","block")
			.css("position","relative")
			.css("height",nHauteurDefilement)
			.css("width",nLargeurDefilement)
		;		
		
		//tableau des écrans à défiler
		var tabEcrans = [];		
		if (!bEstRiche || jqThis.children().first().css("display")!="block") 
		{
			//création des écrans à partir du séparateur double RC
			tabEcrans = jqThis.html().split(/<br><br>|\n\n/);
		}
		else
		{
			//les fils sont des blocks 
			tabEcrans = jqThis.children();			
		}
		
		//force un déplacement du même écran
		if (tabEcrans.length<1) 
		{
			tabEcrans[0] = jqThis.html();
			tabEcrans[1] = jqThis.html();		
		}
		
		var jqListe = $("<ol />")
			.css("padding","0")
			.css("margin","0")
			.css("overflow","hidden")
			.css("display","block")
			.css("position","relative")
			.css("height",nHauteurDefilement)
			.css("width",nLargeurDefilement)	
		;
		
		
		var nNbElementRetires = 0;
		var nIndicePremierAffiche = -1;
		for(var i=0; i<tabEcrans.length; i++)
		{
			var xElementCourant = tabEcrans[i];
			
			//retire les écrans vides
			if (bEstRiche)
			{
				if ($(xElementCourant).text()=="")
				{
					continue;				
				}
			}
			else
			{
				if (xElementCourant=="")
				{	
					continue;
				}
			}
			
			//ajoute un écran
			jqListe.append(
			$("<li />")
				.css("padding","0")
				.css("margin","0")				
				.css("display","block")				
				.css("height",nHauteurDefilement)
				.css("width",nLargeurDefilement)	
				.css("overflow","hidden")					
				.html(xElementCourant)
			);
		}	
		
		//compte les déplacements (autant que d'écrans, moins 1)
		var nNbDeplacement = jqListe.children().length-1;

		//place le ul		
		jqThis.html("").append(jqListe);

		//rajoute un dernier écran repris du premier pour boucle dessus
		jqThis.children().first().append(jqListe.children().first().clone());
		
		//hauteur du texte
		var nHauteurTotale = nHauteurDefilement*(nNbDeplacement+1);
			
		var jqSpanTexte = jqListe.children().first();	
		
		function boucle(nOffset)
		{			
			if (nOffset==undefined) 
			{
				nOffset = 0;
				jqSpanTexte.css(sSens,"0");
			}
			else
			{
				//pour éviter que le texte ne défile de suite après la sortie de souris
				jqSpanTexte.delay(300);
			}
			
			//Anime le texte
			var nTop = nOffset * -nHauteurDefilement;
			for(var i=nOffset; i<=nNbDeplacement; ++i)
			{		
				var options = {};
				options[sSens] = nTop + "px";
				jqSpanTexte										
					
					.animate(
						 options
						,nVitesse
						,sFonction
						/*,(function(){ //pour l'animation au survol
							jqSpanTexte.parent()								
								.attr("data-margin",jqSpanTexte.css(sSens));
						})*/
					)				
					.animate(options,i==0 ? 0 : nDelai);					
				;	
				nTop -= nHauteurDefilement;
			}	
			var options = {};
			options[sSens] = "-"+nHauteurTotale+"px";
			jqSpanTexte.animate(options,nVitesse,sFonction,boucle);		
		}
		boucle();	
		
		//Arrête l'animation au survol ?
		/* à deboguer
		jqThis
		.bind("mouseover mousemove",function(){
			if (jqSpanTexte.parent().attr("data-margin") == jqSpanTexte.css(sSens))
				jqSpanTexte.clearQueue().stop();
		})
		.bind("mouseleave mouseblur",function(){					
			boucle( (parseInt(jqSpanTexte.parent().attr("data-margin"))/-nHauteurDefilement)+1 );
		})		
		;
		*/
	});
});

/*
 * Lazy Load - jQuery plugin for lazy loading images
 *
 * Copyright (c) 2007-2013 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *   http://www.appelsiini.net/projects/lazyload
 *
 * Version:  1.9.0-dev
 *
 */
 
(function($, window, document, undefined) {
    var $window = $(window);

    $.fn.lazyload = function(options) {
        var elements = this;
        var $container;
        var settings = {
            threshold       : 100,//$(window).height(),
            failure_limit   : 0,
            event           : "scroll",
            effect          : "show",
            container       : window,
            data_attribute  : "original",
            skip_invisible  : true,
            appear          : null,
            load            : null,
            placeholder     : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"
        };

        function update(el) {
            var counter = 0;
      
            el.each(function() {
                var $this = $(this);
                if (settings.skip_invisible && !$this.is(":visible")) {
                    return;
                }
                if ($.abovethetop(this, settings) ||
                    $.leftofbegin(this, settings)) {
                        /* Nothing. */
                } else if ((!$.belowthefold(this, settings) &&
                    !$.rightoffold(this, settings)) 
					//debug de quirks
					|| ($window.height()==0)) {
                        $this.trigger("appear");
                        /* if we found an image we'll load, reset the counter */
                        counter = 0;
                } else {					
                    if (++counter > settings.failure_limit) {
                        return false;
                    }
                }
            });

        }

        if(options) {

            $.extend(settings, options);
        }

        /* Cache container as jQuery as object. */
        $container = (settings.container === undefined ||
                      settings.container === window) ? $window : $(settings.container);

        /* Fire one scroll event per scroll. Not one scroll event per image. */
        if (0 === settings.event.indexOf("scroll")) {
            $container.bind(settings.event, function(event) {
                return update(elements);
            });
        }

        this.each(function() {
            var self = this;
            var $self = $(self);

            self.loaded = false;

            /* If no src attribute given use data:uri. */
            if ( 
				$self.attr("src") === undefined 
			|| 	$self.attr("src") === false 
			){
				//via data-src ?
				if ($self.attr("data-width") !== undefined)
				{
					var nHauteurChampEdition = $self.attr("data-height");//$self.height();
					var nLargeurChampEdition= $self.attr("data-width");//$self.width();
					
					//le src passe dans le fond pour permettre le centrage
					$self
						//.data("padding-top",$self.css("padding-top"))
						//.data("padding-left",$self.css("padding-left"))
						//.data("background",$self.css("background"))
						.css("background","url(" + ($self.attr("data-placeholder")) +") center center no-repeat transparent")//mieux vaut transparent que #e5e5e5
						//.removeAttr("data-src")
						//.data("src","")
						.data("lazyloadMire",1)
					;

					//padding pour conserver la même taille (cas d'ancrage au contenu)
					if ($self.height()==0)
						$self.css("padding-top",nHauteurChampEdition+"px");
					//cas d'ancrage au navigateur avec taille max / ou au contenu
					if ($self.css("width")==="auto")
						$self.css("padding-left","100%");//applique la largeur du parent <=> ancrage en largeur					
					if ($self.width()==0)
						$self.css("padding-left",nLargeurChampEdition+"px");
						
				}
				else
				{		
					//ancien fonctionnement, sans utiliser le fond pour le placeholder mais directement le src
					if ($self.attr("data-placeholder")!==undefined)
					{
						$self.attr("src", $self.attr("data-placeholder"));
					}
	                else 
					{	//obsolète ?
						if ($self.data("src")!==undefined)
						{
							$self.attr("src", $self.data("src")).removeAttr("data-src");
						}
						else 
						{
							$self.attr("src", settings.placeholder);
						}
					}
					
				}
            }
    		

			$self
			.bind("load", function() {
				//l'image est chargée sans trigger appear?
				//le test vérifie donc que la mire est toujours présente
				if ($self.data("lazyloadMire"))
				{	
					//ex : cas d'un affichage de popup contenant l'image => il faut être notifié sinon la mire sera affichée (voire même mire + image modifiée par code navigateur, cas QW#240626)
					self.loaded=false;
					update($self);				
				}
			});
			
			//en cas de mise à jour de html par ajax
			if (window["clWDUtil"]!==undefined)
			{
				clWDUtil.m_oNotificationsImagesVisibles.AddNotification(function(oChamp,domBalise)
				{
					//ne concerne que les fils du conteneur
					if (!domBalise || clWDUtil.bEstFils($self[0], domBalise))
					{
						$self.trigger("load");
					}
				});
			}
			
            /* When appear is triggered load original image. */
            $self.bind("appear", function() {
                if (!this.loaded) {
                    if (settings.appear) {
                        var elements_left = elements.length;
                        settings.appear.call(self, elements_left, settings);
                    }	
		
					var bSrcDejaFait = ($self.attr("data-"+settings.data_attribute)=="" && $self.attr("src")!="" && $self.attr("src")!=$self.attr("data-src"));					
                    var jqImgTmp =  $("<img />").bind("load", function() 
                    {
						//blindage du cas de rappel à load alors que l'élément est déjà en place dans le DOM
						if (this.parentNode) return;
						var nHauteurChampExec = Math.max($self.height(),parseInt($self.attr("data-height")));
						var nLargeurChampExec= Math.max($self.width(),parseInt($self.attr("data-width")));	
						//note le display initial pour le restaurer ensuite
						if ($self.attr("data-display-ori")===undefined)
						{
							$self.attr("data-display-ori",$self.css("display"));
						}							
						//ne masque pas si src déjà loadé car l'img s'affiche déjà 
						//donc on va simplement retirer les artefacts d'attente (spinner en fond, padding ...)
						if (!bSrcDejaFait) $self.hide();
						var original = (bSrcDejaFait) ? $self.attr("src") :  $self.attr("data-"+settings.data_attribute);
						
						//active l'animation si la largeur est non définie
						//et pas si le src est déjà loadé
						//et pas si l'image est en 100%
						//Débranche l'animation car finalement l'effet n'est pas agréable, mieux vaut le scale
						var bAnimationUtile = false;//!bSrcDejaFait && (self.style.width=="") && !$self.parent().parent().hasClass("dzSpan");

						//récupère le style de la balise img avant de l'altérer
						oStyleBaliseImg = self.style;//window.getComputedStyle(self);
						var bLargeurAuto = oStyleBaliseImg.width=="auto" || oStyleBaliseImg.width=="";
						var bHauteurAuto = oStyleBaliseImg.height=="auto" ||oStyleBaliseImg.height=="";
						var bLargeurPourcentage = oStyleBaliseImg.width=="100%";
						var bHauteurPourcentage = oStyleBaliseImg.height=="100%";
		
						//mémorise les dimensions (ancrage adapté au contenu ou pas)
						//permet de gérer l'adapté au contenu après plusieurs modif du src par prog
						if ($self.data("style-width") === undefined)
							$self.data("style-width", self.style.width);
						if ($self.data("style-height") === undefined)
							$self.data("style-height", self.style.height);								
							
						 self.style.width = $self.data("style-width");
						 self.style.height = $self.data("style-height");
						 
						var sLargeur = ($self.data("style-width")=="" ) ? (bSrcDejaFait ? self.width : this.width+"px")  : self.style.width;
						var sHauteur = ($self.data("style-height")=="") ? (bSrcDejaFait ? self.height: this.height+"px") : self.style.height;
						
						$self.css("width",nLargeurChampExec);
						$self.css("height",nHauteurChampExec);				

						//pas d'animation pour les images avec débordements
						//if (bAnimationUtile && ($self.parent().hasClass("dzSpan")||$self.parent().hasClass("dzSpanRiche"))) bAnimationUtile=false;
						//pas d'animation si la largeur est différente d'au moins 5px (évite de faire une anim pour 1px de diff)
						//if (bAnimationUtile && (Math.abs($self.width()-this.width))<50) bAnimationUtile=false;
						
						
						//retire le fond du placeholder
						$self
							.css("background","")//$self.data("background"))							
							.css("padding-top","")//$self.data("padding-top"))		
							.css("padding-left","")//$self.data("padding-left"))		
							.data("lazyloadMire",0)
						;							
					
                       // $self.hide();						   
                        if ($self.is("img")) 
						{
							// //pour IE, on applique le src (même si cela peut demander 2 fois le téléchargement dans le cas des images sans cache) car 
							// //en IE 7 : jquery fait une exception source. http://bugs.jquery.com/ticket/12577
							// //et sous les autres IE : une image sur 2 est chargée
							// if (bSrcDejaFait || navigator.userAgent.indexOf("MSIE")>0 || ($(document.body).hasClass("wbRwd")))
							// {
								//mieux vaut remplacer le src car la copie d'attributts perd les data et event listeners 
							 	$self.attr("src", original);
							// }								
							// else
							// {
							// 	var jqThis = $(this);
							// 	var tabAttributes = $self.prop("attributes");
							// 	$(tabAttributes).each(function()
							// 	{
							// 		jqThis.attr(this.name,this.value);
							// 	});
							//    $self.replaceWith(jqThis);
							//    $self = jqThis;
							//    $self.attr("src", original);	//blindage
							// }
							
                        } 
						else 
						{
                            $self.css("background-image", "url('" + original + "')");
                        }
						
						
                        //$self[settings.effect](settings.effect_speed);
						//effet forcé en dur :
						if ($self.queue().length==0)
						{
							self.nOpaciteInitiale = self.nOpaciteInitiale || $self.css("opacity");
							var nDuree = window.scrollY===0 ? 1000 : 400;
							$self.css("opacity",0).animate({opacity : self.nOpaciteInitiale},nDuree);
							//ajoute une animation de transformation, sur l'image ou son conteneur de débordement
							if (window.scrollY>0 && $self.css("opacity")==0 && self.src.indexOf( $self.attr("src"))==-1)//sauf si l'image est affichée dès le 1er affichage de la page
							{
								$self.add($self.parents(".dzSpan")).first().animate({content:1},{
									step : function (now)
									{
										$(this).css("transform", "scale(" + (0.8 + (now * 0.2)) +")");
										
									}
									, easing : "easeOutExpo"//note jquery-ui toujours inclus pour jquery-effet
									, duration : nDuree
								});	
							}
						}
						//retire le display none sans forcer block ou autre car l'image est
						//peut être en inline, ou pas, selon qu'elle est dans une ztr ou non, avec habillage ou pas
						$self.css("display",$self.attr("data-display-ori"));
				
                        $self[0].loaded = self.loaded = true;
						//pcode de onload?
					    // if ($self[0].onload)
					    // {					    	
					   	//  	$self[0].onload.apply($self[0],[]);
					    // }
					    $self.trigger("load");

						
						//avec ou sans animation ?
						//donne les dimensions de l'image :						
						//précise la largeur à partir de la largeur d'édition ou de l'image source selon l'ancrage demandé						
						// - Largeur
						if (bAnimationUtile && window.scrollY>0 && !bLargeurPourcentage) 
						{
							$self.stop(true,true).animate({width : sLargeur},{duration : 500, complete : function()
							{
								//retire la width si nécessaire
								if (bLargeurAuto)
								{
									$(this).css("width","auto");
								}
							}});
						}
						else 
						{
							$self.css("width" ,(bLargeurAuto ? "auto" : sLargeur));
						}
						// - Hauteur
						if (bAnimationUtile && window.scrollY>0 && !bHauteurPourcentage) 
						{
							$self.stop(true,true).animate({height : sHauteur},{duration : 500, complete : function()
							{
								//retire la width si nécessaire
								if (bHauteurAuto)
								{
									$(this).css("height","auto");
								}
							}});
						}	
						else 
						{
							$self.css("height" ,(bHauteurAuto ? "auto" : sHauteur));
						}							
						
                        /* Remove image from array so it is not looped next time. */
                        var temp = $.grep(elements, function(element) {
                            return !element.loaded;
                        });
                        elements = $(temp);

                        if (settings.load) {
                            var elements_left = elements.length;
                            settings.load.call(self, elements_left, settings);
                        }
                    });
						
					if (bSrcDejaFait)
					{
						$self.attr("data-"+settings.data_attribute,$self.attr("src"));
						jqImgTmp.trigger("load");
					}	
					else if(this.tagName.toLowerCase() == "img")
					{							
						jqImgTmp.attr("src", $self.attr("data-"+settings.data_attribute));
					}	
                }
            });

            /* When wanted event is triggered load original image */
            /* by triggering appear.                              */
            if (0 !== settings.event.indexOf("scroll")) {
                $self.bind(settings.event, function(event) {
                    if (!self.loaded) {
                        $self.trigger("appear");
                    }
                });
            }
        });

        /* Check if something appears when window is resized. */
        $window.bind("resize", function(event) {
            update(elements);
        });
        /* Check if something appears when window is resized. */
        $window.bind("resetappear", function(event) {
        	elements.push($self);
            update(elements);
        });        
              
        /* With IOS5 force loading images when navigating with back button. */
        /* Non optimal workaround. */
        if ((/iphone|ipod|ipad.*os 5/gi).test(navigator.appVersion)) {
            $window.bind("pageshow", function(event) {
                if (event.originalEvent && event.originalEvent.persisted) {
                    elements.each(function() {
                        $(this).trigger("appear");
                    });
                }
            });
        }

        /* Force initial check if images should appear. */
        $(document).ready(function() {
			//1er affichage décalé
           setTimeout(function(){ 
				update(elements);
			}, 20);
        });
        
        return this;
    };

    /* Convenience methods in jQuery namespace.           */
    /* Use as  $.belowthefold(element, {threshold : 100, container : window}) */
    $.belowthefold = function(element, settings) {
        var fold;
        var nOffsetParent = 0;
        if (settings.container === undefined || settings.container === window) {
            fold = window.nBordBasNavigateur;//(window.innerHeight ? window.innerHeight : $window.height()) + $window.scrollTop();
        } else {
            fold = settings.container.scrollTop + $(settings.container).offset().top + $(settings.container).height();
            nOffsetParent = $(settings.container).offset().top;
        }

        return fold <= (element.nPositionY||(element.nPositionY=$(element).offset().top)) - settings.threshold- nOffsetParent;
    };
    
    $.rightoffold = function(element, settings) {
        var fold;
        var nOffsetParent = 0;
        if (settings.container === undefined || settings.container === window) {
            fold = window.nBordDroitNavigateur;//||(window.nBordDroitNavigateur=($window.width() + $window.scrollLeft()));
        } else {
            fold = settings.container.scrollLeft + $(settings.container).offset().left + $(settings.container).width();
            nOffsetParent = $(settings.container).offset().left;
        }

        return fold <= (element.nPositionX||(element.nPositionX=$(element).offset().left)) - settings.threshold - nOffsetParent;
    };
        
    $.abovethetop = function(element, settings) {
        var fold;
        var nOffsetParent = 0;
        if (settings.container === undefined || settings.container === window) {
            fold = window.nBordHautNavigateur;//||(window.nBordHautNavigateur=$window.scrollTop());
        } else {
            fold = settings.container.scrollTop + $(settings.container).offset().top;
            nOffsetParent = $(settings.container).offset().top;
        }

        return fold >= (element.nPositionY||(element.nPositionY=$(element).offset().top)) + settings.threshold  + (element.nHauteurChamp||(element.nHauteurChamp=$(element).height()))- nOffsetParent;
    };
    
    $.leftofbegin = function(element, settings) {
        var fold;
        var nOffsetParent = 0;
        if (settings.container === undefined || settings.container === window) {
            fold = window.nBordGaucheNavigateur;//||(window.nBordGaucheNavigateur=($window.scrollLeft()));
        } else {
            fold = settings.container.scrollLeft + $(settings.container).offset().left;
            nOffsetParent = $(settings.container).offset().left;
        }

        return fold >= (element.nPositionX||(element.nPositionX=$(element).offset().left)) + settings.threshold + (element.nLargeurChamp||(element.nLargeurChamp=$(element).height())) - nOffsetParent;
    };

    $.inviewport = function(element, settings) {
         return !$.rightoffold(element, settings) && !$.leftofbegin(element, settings) &&
                !$.belowthefold(element, settings) && !$.abovethetop(element, settings);
     };

    /* Custom selectors for your convenience.   */
    /* Use as $("img:below-the-fold").something() or */
    /* $("img").filter(":below-the-fold").something() which is faster */

    $.extend($.expr[':'], {
        "below-the-fold" : function(a) { return $.belowthefold(a, {threshold : 0}); },
        "above-the-top"  : function(a) { return !$.belowthefold(a, {threshold : 0}); },
        "right-of-screen": function(a) { return $.rightoffold(a, {threshold : 0}); },
        "left-of-screen" : function(a) { return !$.rightoffold(a, {threshold : 0}); },
        "in-viewport"    : function(a) { return $.inviewport(a, {threshold : 0}); }
    });

})(jQuery, window, document);


/* Inutilisé 
// http://james.padolsey.com/javascript/special-scroll-events-for-jquery/ 

(function(){
    
    var special = jQuery.event.special,
        uid1 = 'D' + (+new Date()),
        uid2 = 'D' + (+new Date() + 1);
        
    special.scrollstart = {
        setup: function() {
            
            var timer,
                handler =  function(evt) {
                    
                    var _self = this,
                        _args = arguments;
                    
                    if (timer) {
                        clearTimeout(timer);
                    } else {
                        evt.type = 'scrollstart';
                        jQuery.event.dispatch.apply(_self, _args);
                    }
                    
                    timer = setTimeout( function(){
                        timer = null;
                    }, special.scrollstop.latency);
                    
                };
            
            jQuery(this).bind('scroll', handler).data(uid1, handler);
            
        },
        teardown: function(){
            jQuery(this).unbind( 'scroll', jQuery(this).data(uid1) );
        }
    };
    
    special.scrollstop = {
        latency: 300,
        setup: function() {
            
            var timer,
                    handler = function(evt) {
                    
                    var _self = this,
                        _args = arguments;
                    
                    if (timer) {
                        clearTimeout(timer);
                    }
                    
                    timer = setTimeout( function(){
                        
                        timer = null;
                        evt.type = 'scrollstop';
                        jQuery.event.dispatch.apply(_self, _args);
                        
                        
                    }, special.scrollstop.latency);
                    
                };
            
            jQuery(this).bind('scroll', handler).data(uid2, handler);
            
        },
        teardown: function() {
            jQuery(this).unbind( 'scroll', jQuery(this).data(uid2) );
        }
    };
    
})();
 */
 
$().ready(function(){
	
	function RechargeDiffere(oChamp, oElementConteneur)
	{
		//IMAGES
		$(oElementConteneur).find("[data-original]")
	    //listener de media query		  
	    //callback donnée pour les futurs appels
	    .data("wbMediaAttrCallback",function fListenerMenu(oListener,bMatches,sData,sNouvelleValeur)
	    {
	    	//ne traite que le data-original=
	    	if (sData !== "data-original")
	    	{
	    		return sNouvelleValeur;
	    	}
	    	//l'original de l'affichage différé devient la nouvelle source si le chargement différé a déjà été fait
	    	if (oListener.balise[0].loaded)
	    	{
	    		oListener.balise[0].loaded=false;	    	
	    		setTimeout(function(){oListener.balise.trigger("resetappear")},1);
	    	}
			return sNouvelleValeur;
	    })
		.lazyload(
		{
				// event: "scrollstop",
					
				//effect : "fadeIn"				
				//,
				appear : (function(elements_left, settings){
					$self = $(this);
					$self.addClass("wb-lazy-loading")//debug				
						//.data("data-opacity",$self.css("opacity"))
						//.css("opacity" , 0.5)
						;
					
				})
				,
				load : (function(elements_left, settings){
					$self = $(this);
					//flag l'image comme étant chargée
					$self.addClass("wb-lazy-loaded")
						.removeClass("wb-lazy-loading")					
						//.animate({opacity : $self.data("data-opacity")})				
						.attr("src",  $self.attr("data-"+settings.data_attribute))
				})
				
				//placeholder par défaut du produit
				//, placeholder : "25-ans.gif"
		})
		.bind("click mouseenter",function(){$(this).trigger("appear"); });//contournement au cas où l'image ne serait pas affichée
	}

	//en cas de mise à jour de html par ajax
	if (window["clWDUtil"]!==undefined) clWDUtil.m_oNotificationsAjoutHTML.AddNotification(RechargeDiffere)
	

	RechargeDiffere(undefined,$("body")[0]);

});


function wbSansAccent(s)
{
	var stSansAccent = ({
	"\x9e" : "z",
	"\x80" : "C",
	"\x81" : "U",
	"\x82" : "e",
	"\x83" : "a",
	"\x84" : "a",
	"\x85" : "a",
	"\x86" : "a",
	"\x87" : "c",
	"\x88" : "e",
	"\x89" : "e",
	"\x8a" : "S",
	"\x8b" : "i",
	"\x8c" : "i",
	"\x8d" : "i",
	"\x8e" : "A",
	"\x8f" : "A",
	"\x90" : "e",
	"\x93" : "o",
	"\x94" : "o",
	"\x95" : "o",
	"\x96" : "u",
	"\x97" : "u",
	"\x98" : "y",
	"\x99" : "O",
	"\x9a" : "s",
	"\x9f" : "Y",
	"\xa0" : "a",
	"\xa1" : "i",
	"\xa2" : "o",
	"\xa3" : "u",
	"\xa4" : "n",
	"\xa5" : "N",
	"\xc0" : "A",
	"\xc1" : "A",
	"\xc2" : "A",
	"\xc3" : "A",
	"\xc4" : "A",
	"\xc5" : "A",
	"\xc7" : "C",
	"\xc8" : "E",
	"\xc9" : "E",
	"\xca" : "E",
	"\xcb" : "E",
	"\xcc" : "I",
	"\xcd" : "I",
	"\xce" : "I",
	"\xcf" : "I",
	"\xd0" : "D",
	"\xd1" : "N",
	"\xd2" : "O",
	"\xd3" : "O",
	"\xd4" : "O",
	"\xd5" : "O",
	"\xd6" : "O",
	"\xd7" : "X",
	"\xd8" : "O",
	"\xd9" : "U",
	"\xda" : "U",
	"\xdb" : "U",
	"\xdc" : "U",
	"\xdd" : "Y",
	"\xe0" : "a",
	"\xe1" : "a",
	"\xe2" : "a",
	"\xe3" : "a",
	"\xe4" : "a",
	"\xe5" : "a",
	"\xe7" : "c",
	"\xe8" : "e",
	"\xe9" : "e",
	"\xea" : "e",
	"\xeb" : "e",
	"\xec" : "i",
	"\xed" : "i",
	"\xee" : "i",
	"\xef" : "i",
	"\xf1" : "n",
	"\xf2" : "o",
	"\xf3" : "o",
	"\xf4" : "o",
	"\xf5" : "o",
	"\xf6" : "o",
	"\xf8" : "o",
	"\xf9" : "u",
	"\xfa" : "u",
	"\xfb" : "u",
	"\xfc" : "u",
	"\xfd" : "y",
	"\xff" : "y"
	});
	function escapeRegExp(str) {
	  return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
	}
	for(sAccent in stSansAccent) 
	{
		if (!stSansAccent.hasOwnProperty(sAccent))
		{
			continue;
		}
		s = s.replace(new RegExp(escapeRegExp(sAccent), 'g'), stSansAccent[sAccent]);
	}
	
	return s;
}

var wbAutocompleteInit = undefined;
function wbAutocompleteDeclare() {

function split( val ) {
  return val.split( /,\s*/ );
}
function extractLast( term ) {
  return split( term ).pop();
}
function preg_quote( str ) {
	// http://kevin.vanzonneveld.net
	// +   original by: booeyOH
	// +   improved by: Ates Goral (http://magnetiq.com)
	// +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
	// +   bugfixed by: Onno Marsman
	// *     example 1: preg_quote("$40");
	// *     returns 1: '\$40'
	// *     example 2: preg_quote("*RRRING* Hello?");
	// *     returns 2: '\*RRRING\* Hello\?'
	// *     example 3: preg_quote("\\.+*?[^]$(){}=!<>|:");
	// *     returns 3: '\\\.\+\*\?\[\^\]\$\(\)\{\}\=\!\<\>\|\:'

	return (str+'').replace(/([\\\.\+\*\?\[\^\]\$\(\)\{\}\=\!\<\>\|\:])/g, "\\$1");
}	
$.widget( "ui.autocomplete",$.ui.autocomplete, {		
wbAutocompleteProg : [],
wbCache : {},
//SaisieAssistéeOuvre()
wbOuvreAutocompleteProg : function(tab) 
{ 	
	var jqChamp = $(this.element);
	//champ avec ouverture manuelle?
	var bManuelle = ($(this.element).data("saisieassistee-ouvertureauto")==0);
	
	//désactive temporairement le verrou d'ouverture
	if (bManuelle) jqChamp.data("saisieassistee-ouvertureauto",1);
	
	//transmet la demande d'ouverture de la liste
	jqChamp.autocomplete("search");
	
	//réactive le verrou d'ouverture
	if (bManuelle) jqChamp.data("saisieassistee-ouvertureauto",0);
} ,
//[%ALIAS_CODEHTML%]
wbConcatAutocompleteProg : function(tab) { this.wbAutocompleteProg = this.wbAutocompleteProg.concat(tab); return this;} ,
//SaisieAssistéeAjoute()
wbAddAutocompleteProg : function(s) { this.wbAutocompleteProg = this.wbAutocompleteProg.concat([s]); return this; } ,  
//SaisieAssistéeSupprimeTout()
wbRazAutocompleteProg : function() { this.wbAutocompleteProg = []; return this; } ,  
_renderItem: function( ul, item ) {
		var term = false==$(this.element).hasClass("wbAutocompleteMultiple") ? this.term  : extractLast( this.term );
		return $( "<li>" )
			.append( $( "<a>" ).html( 
				//"<span class=\"ui-autocomplete-term\">" +  item.label.substr(0,term.length) + "</span>" + item.label.substr(term.length) 					
				item.label.replace(new RegExp( "(" + preg_quote( term ) + ")" , 'gi' ),"<span class=\"ui-autocomplete-term\">$1</span>")
			) )
			.appendTo( ul );
		},
 _trigger: function( type, event, data ) {
		if ($(this.element).data("saisieassistee-ouvertureauto")==0)
		{
			//masque volontairement la liste si l'ouverture est manuelle
			if ((type=="open" || type=="close")) 
			{ 
				$(this.menu.element).hide(); 
				return; 
			}
		}
		return this._super(type, event, data );
},
	_searchTimeout: function( event ) {
		this.options.delay = $(this.element).data("saisieassistee-delai")>0 ? parseInt($(this.element).data("saisieassistee-delai")) : this.options.delay;
		return this._super(event );
	}		
  
});	

wbAutocompleteInit = function (sSelecteur)
{	
//init impossible avant que les données ne soient chargées
var oDocumentAutocomplete = $(document.body).data("wbAutocomplete");
if (!oDocumentAutocomplete)
{
	return;
}  	
var jqBalise = $( sSelecteur );
//cas de saisie assistée sur jeton
if (jqBalise.hasClass("wbSaisieJetonsWrap")) jqBalise=jqBalise.find(".wbSaisieJetonsInput").first();
jqBalise
  .filter(function()
  {
  	//évite de le faire 2 fois sur les mêmes instances
  	if ($(this).data("wbAutocompleteInit"))
  	{
  		return false;
  	}  	
  	var tabClasse = this.className.toString().split(" ");
  	var nIndexwbAutocomplete = tabClasse.indexOf("wbAutocomplete");
  	//cf. CECPHSaisie::VersFichierHTML, la classe est ajouté juste après
  	var sAlias = tabClasse[nIndexwbAutocomplete+1];
  	//les datas sauvées dans oDocumentAutocomplete sont placées dans this
	if (!oDocumentAutocomplete[sAlias])
	{
		return false;
	}
	//re init
	oDocumentAutocomplete[sAlias][0]($(this));
	//note la callback de valeur d'init car elle droit êtr appelée après autocomplete()
	$(this).data("wbAutocompleteInitCallbackValeur",oDocumentAutocomplete[sAlias][1]);
	return true;

  })
  .data("wbAutocompleteInit",1)
  // don't navigate away from the field on tab when selecting an item
  .bind( "keydown", function( event ) {
	if ( event.keyCode === $.ui.keyCode.TAB &&
		$( this ).data( "ui-autocomplete" ).menu.active ) {
	  event.preventDefault();
	}
  })
  .bind( "focus", function( event ) {
	
  })
  .on("trigger.wb.saisie.jeton.cree",function(){
  		//ferme la saisie assistée en ajout de jeton
  		jqBalise.autocomplete("close");
  })
  .autocomplete({
     classes : {"ui-autocomplete" : "-webdev-bc-3 -webdev-c-13 SAI"},
	delay: 200,		minLength:0,
	source: function( request, response ) {
		//champ dans le dom
		var jqThis = $(this.element);

		//terme à rechercher (à spliter si multiple)
		var term = false==jqThis.hasClass("wbAutocompleteMultiple") ? request.term  : extractLast( request.term );
		request.term = term;
		
		//déjà en cache ?
		if ( request.term in this.wbCache ) {
		  response( this.wbCache[ request.term ] );
		  return;
		}					
		//données initiales
		var tabDonnes = [];			
		//récupère le filtre demandé, ou filtre par défaut en commence par
		var nFiltre = (jqThis.data("saisieassistee-filtre")==undefined) ? 31979 : parseInt(jqThis.data("saisieassistee-filtre"));
		var bSansCasse = (jqThis.data("saisieassistee-sanscasse")==undefined) ? true : parseInt(jqThis.data("saisieassistee-sanscasse"));
		var funcFiltre = undefined;
        if(term)
		switch(nFiltre)
		{
			case  31978 : // IDPOP_FILTRE_EGAL		
				funcFiltre=function(s,term) 
				{
					return s == term;
				}				
				break;
			case  31979 : // IDPOP_FILTRE_COMMENCEPAR	
				funcFiltre=function(s,term) 
				{
					return s.substr(0,term.length) == term;
				}
				break;
			case  31980 : // IDPOP_FILTRE_CONTIENT	
				funcFiltre=function(s,term) 
				{
					return s.indexOf(term)>-1;
				}	
				break;
			case  31981 : // IDPOP_FILTRE_TERMINEPAR
				funcFiltre=function(s,term) 
				{
					return s.substr(s.length-term.length) == term;
				}		
				break;
			case  31982 : // IDPOP_FILTRE_DIFFERENT	
				funcFiltre=function(s,term) 
				{
					return s != term;
				}	
				break;
			case  31983 : // IDPOP_FILTRE_NOTCOMMENCEPAR
				funcFiltre=function(s,term) 
				{
					return s.substr(0,term.length) != term;
				}	
				break;
			case  31984 : // IDPOP_FILTRE_NOTCONTIENT	
				funcFiltre=function(s,term) 
				{
					return s.indexOf(term) == -1;
				}
				break;
			case  31985 : // IDPOP_FILTRE_NOTTERMINEPAR	
				funcFiltre=function(s,term) 
				{
					return s.substr(s.length-term.length) != term;
				}
				break;
			case  31986 : // IDPOP_FILTRE_SUPERIEUR		
				funcFiltre=function(s,term) 
				{
					return s > term;
				}
				break;
			case  31987 : // IDPOP_FILTRE_SUPERIEUROUEGAL
				funcFiltre=function(s,term) 
				{
					return s >= term;
				}
				break;
			case  31988 : // IDPOP_FILTRE_INFERIEUR		
				funcFiltre=function(s,term) 
				{
					return s < term;
				}
				break;
			case  31989 : // IDPOP_FILTRE_INFERIEUROUEGAL
				funcFiltre=function(s,term) 
				{
					return s <= term;
				}
				break;
			case  31990 : // IDPOP_RECONNAISSANCEVOC		
				//break; non géré
			default:
			case 0   : //pas de filtre
				break;				
		}
		if (funcFiltre!==undefined)
		{
			var sTermSansAccentCasse = bSansCasse ? wbSansAccent(request.term.toLowerCase()) : request.term;
			for(var i=0; i<this.wbAutocompleteProg.length; ++i)
			{
				if (funcFiltre(bSansCasse ? wbSansAccent(this.wbAutocompleteProg[i].toLowerCase()) : this.wbAutocompleteProg[i],sTermSansAccentCasse))
				{
					tabDonnes = tabDonnes.concat([this.wbAutocompleteProg[i]]);
				}
			}
		}
		else
		{		
			//tout
			tabDonnes = this.wbAutocompleteProg;		
		}		


        var oValeurChampCache = $("#"+this.element[0].name+ "_DATA").wbJsonParseAttr("value",true);
        function fFiltreJeton(data)
        {
            //si jeton filtre selon ses doublons
            if (data && oValeurChampCache && !oValeurChampCache.m_bJetonAutoriseDoublon)
            {
                var dataCopie = [];
                for(var iData=0; iData<data.length; ++iData)
                {
                    var bTrouve=false;
                    for(var iJeton=0; iJeton<oValeurChampCache.m_tabJetons.length; ++iJeton)
                    {
                       if (data[iData] == oValeurChampCache.m_tabJetons[iJeton].m_sValeur)
                       {
                              bTrouve=true;
                              break;
                       }
                    }

                    if (!bTrouve) dataCopie.push(data[iData]);
                }
                return dataCopie;
            }    
            return data;        
        }	
		
		var self = this;
		//demande au serveur des données pré filtrées
		if (jqThis.hasClass("wbAutocompleteFichier"))
		{
			//à la fin de l'appel AJAX wbConcatAutocompleteProg sera appelé avec le résultat
			clWDAJAXMain.AJAXExecuteEvenement(_PAGE_, jqThis.attr("id")||jqThis.closest(".wbSaisieJetonsWrap").attr("id"), 0, 11,//id transféré au div de wrap pour jeton
			(function(){
				//appelé en fin d'ajax avec this.wbAutocompleteProg déjà renseigné
				response(fFiltreJeton(self.wbAutocompleteProg));
				self.wbAutocompleteProg=[];
			}));			
		}
		else
		{
			//prend dans les données init 
			//sans appliquer de filtre sur les données navigateur
			response(fFiltreJeton(tabDonnes));
		}
	},
	search: function() {
	  // custom minLength
	  var term = extractLast( this.value );
      var nTailleMin = parseInt($(this).data("saisieassistee-taillemin"));
      
      if (nTailleMin === 0) return true;//pas de saisie mais on affiche

	  var nTailleMin = Math.max(1,nTailleMin);
	  if (term.length < nTailleMin ) {
		return false;
	  }
	},
	focus: function() {
	  // prevent value inserted on focus
	  return false;
	}
	,
	select: function( event, ui ) 
	{
		var jqChamp = $(this);
		//uniquement pour complétion multiple
		if (jqChamp.hasClass("wbAutocompleteMultiple"))
		{
			var terms = split( this.value );
			// remove the current input
			terms.pop();
			// add the selected item
			terms.push( ui.item.value );
			// add placeholder to get the comma-and-space at the end
			terms.push( "" );
			this.value = terms.join( ", " );	  
		}
		else 
		{
			jqChamp.val(ui.item.value);
		}

		//notifie le changement de valeur
		jqChamp.trigger("trigger.wb.autocomplete.select.post");

        // pcode de sélection dans l'assistance
        clWDUtil.pfGetTraitement(this.id, 93)(event);

		//retourne faux pour que jquery-ui ne fasse pas à nouveau le jqChamp.val qui met à jour l'input
		return false;
	}		
  })
  .each(function()
  {  	
	//reprend la callback de valeur d'init car elle droit êtr appelée après autocomplete()
	var fCallbackValeur = $(this).data("wbAutocompleteInitCallbackValeur");
	if (fCallbackValeur)
	{
		fCallbackValeur($(this));
		$(this).removeData("wbAutocompleteInitCallbackValeur")
	}
  })
  ;
  return jqBalise;
}

//1ere init
wbAutocompleteInit(".wbAutocomplete");

//les prochaines init seront lors d'ajout ajax
if (window["clWDUtil"]!==undefined) 
{
	if (clWDUtil.m_oNotificationsAjoutHTML)
	{
		clWDUtil.m_oNotificationsAjoutHTML.AddNotification(function(){wbAutocompleteInit(".wbAutocomplete");});
	}
	if (clWDUtil.m_oNotificationsFinAJAX)
	{
		clWDUtil.m_oNotificationsFinAJAX.AddNotification(function(){wbAutocompleteInit(".wbAutocomplete");});
	}
}

};
wbAutocompleteDeclare();

//parsé dès le chargement 
//mais ne sera exécuté qu'après le ready par la page générée cf. CECPHSaisie::vEcritAvantBodyFerme
function wbAutocompleteChargeData(sAlias,fCallbackInit,fCallbackValeur)
{
	//charge les data des balises avec autcomplete
	//
	if (!$(document.body).data("wbAutocomplete"))
	{
		//init avec objet vide
		//les indices seront les sélecteurs des inputs
		$(document.body).data("wbAutocomplete",{});
	}
	var oDocumentAutocomplete = $(document.body).data("wbAutocomplete");
	oDocumentAutocomplete[sAlias] = [fCallbackInit,fCallbackValeur];

	//appel au cas où le 1er ait été fait avant wbAutocompleteChargeData
	wbAutocompleteInit(".wbAutocomplete");
}


/*
 * @fileOverview TouchSwipe - jQuery Plugin
 * @version 1.6.14
 *
 * @author Matt Bryson http://www.github.com/mattbryson
 * @see https://github.com/mattbryson/TouchSwipe-Jquery-Plugin
 * @see http://labs.rampinteractive.co.uk/touchSwipe/
 * @see http://plugins.jquery.com/project/touchSwipe
 *
 * Copyright (c) 2010-2015 Matt Bryson
 * Dual licensed under the MIT or GPL Version 2 licenses.
 *
 */

/*
 *
 * Changelog
 * $Date: 2010-12-12 (Wed, 12 Dec 2010) $
 * $version: 1.0.0
 * $version: 1.0.1 - removed multibyte comments
 *
 * $Date: 2011-21-02 (Mon, 21 Feb 2011) $
 * $version: 1.1.0 	- added allowPageScroll property to allow swiping and scrolling of page
 *					- changed handler signatures so one handler can be used for multiple events
 * $Date: 2011-23-02 (Wed, 23 Feb 2011) $
 * $version: 1.2.0 	- added click handler. This is fired if the user simply clicks and does not swipe. The event object and click target are passed to handler.
 *					- If you use the http://code.google.com/p/jquery-ui-for-ipad-and-iphone/ plugin, you can also assign jQuery mouse events to children of a touchSwipe object.
 * $version: 1.2.1 	- removed console log!
 *
 * $version: 1.2.2 	- Fixed bug where scope was not preserved in callback methods.
 *
 * $Date: 2011-28-04 (Thurs, 28 April 2011) $
 * $version: 1.2.4 	- Changed licence terms to be MIT or GPL inline with jQuery. Added check for support of touch events to stop non compatible browsers erroring.
 *
 * $Date: 2011-27-09 (Tues, 27 September 2011) $
 * $version: 1.2.5 	- Added support for testing swipes with mouse on desktop browser (thanks to https://github.com/joelhy)
 *
 * $Date: 2012-14-05 (Mon, 14 May 2012) $
 * $version: 1.2.6 	- Added timeThreshold between start and end touch, so user can ignore slow swipes (thanks to Mark Chase). Default is null, all swipes are detected
 *
 * $Date: 2012-05-06 (Tues, 05 June 2012) $
 * $version: 1.2.7 	- Changed time threshold to have null default for backwards compatibility. Added duration param passed back in events, and refactored how time is handled.
 *
 * $Date: 2012-05-06 (Tues, 05 June 2012) $
 * $version: 1.2.8 	- Added the possibility to return a value like null or false in the trigger callback. In that way we can control when the touch start/move should take effect or not (simply by returning in some cases return null; or return false;) This effects the ontouchstart/ontouchmove event.
 *
 * $Date: 2012-06-06 (Wed, 06 June 2012) $
 * $version: 1.3.0 	- Refactored whole plugin to allow for methods to be executed, as well as exposed defaults for user override. Added 'enable', 'disable', and 'destroy' methods
 *
 * $Date: 2012-05-06 (Fri, 05 June 2012) $
 * $version: 1.3.1 	- Bug fixes  - bind() with false as last argument is no longer supported in jQuery 1.6, also, if you just click, the duration is now returned correctly.
 *
 * $Date: 2012-29-07 (Sun, 29 July 2012) $
 * $version: 1.3.2	- Added fallbackToMouseEvents option to NOT capture mouse events on non touch devices.
 * 			- Added "all" fingers value to the fingers property, so any combination of fingers triggers the swipe, allowing event handlers to check the finger count
 *
 * $Date: 2012-09-08 (Thurs, 9 Aug 2012) $
 * $version: 1.3.3	- Code tidy prep for minefied version
 *
 * $Date: 2012-04-10 (wed, 4 Oct 2012) $
 * $version: 1.4.0	- Added pinch support, pinchIn and pinchOut
 *
 * $Date: 2012-11-10 (Thurs, 11 Oct 2012) $
 * $version: 1.5.0	- Added excludedElements, a jquery selector that specifies child elements that do NOT trigger swipes. By default, this is one select that removes all form, input select, button and anchor elements.
 *
 * $Date: 2012-22-10 (Mon, 22 Oct 2012) $
 * $version: 1.5.1	- Fixed bug with jQuery 1.8 and trailing comma in excludedElements
 *					- Fixed bug with IE and eventPreventDefault()
 * $Date: 2013-01-12 (Fri, 12 Jan 2013) $
 * $version: 1.6.0	- Fixed bugs with pinching, mainly when both pinch and swipe enabled, as well as adding time threshold for multifinger gestures, so releasing one finger beofre the other doesnt trigger as single finger gesture.
 *					- made the demo site all static local HTML pages so they can be run locally by a developer
 *					- added jsDoc comments and added documentation for the plugin
 *					- code tidy
 *					- added triggerOnTouchLeave property that will end the event when the user swipes off the element.
 * $Date: 2013-03-23 (Sat, 23 Mar 2013) $
 * $version: 1.6.1	- Added support for ie8 touch events
 * $version: 1.6.2	- Added support for events binding with on / off / bind in jQ for all callback names.
 *                   - Deprecated the 'click' handler in favour of tap.
 *                   - added cancelThreshold property
 *                   - added option method to update init options at runtime
 * $version 1.6.3    - added doubletap, longtap events and longTapThreshold, doubleTapThreshold property
 *
 * $Date: 2013-04-04 (Thurs, 04 April 2013) $
 * $version 1.6.4    - Fixed bug with cancelThreshold introduced in 1.6.3, where swipe status no longer fired start event, and stopped once swiping back.
 *
 * $Date: 2013-08-24 (Sat, 24 Aug 2013) $
 * $version 1.6.5    - Merged a few pull requests fixing various bugs, added AMD support.
 *
 * $Date: 2014-06-04 (Wed, 04 June 2014) $
 * $version 1.6.6 	- Merge of pull requests.
 *    				- IE10 touch support
 *    				- Only prevent default event handling on valid swipe
 *    				- Separate license/changelog comment
 *    				- Detect if the swipe is valid at the end of the touch event.
 *    				- Pass fingerdata to event handlers.
 *    				- Add 'hold' gesture
 *    				- Be more tolerant about the tap distance
 *    				- Typos and minor fixes
 *
 * $Date: 2015-22-01 (Thurs, 22 Jan 2015) $
 * $version 1.6.7    - Added patch from https://github.com/mattbryson/TouchSwipe-Jquery-Plugin/issues/206 to fix memory leak
 *
 * $Date: 2015-2-2 (Mon, 2 Feb 2015) $
 * $version 1.6.8    - Added preventDefaultEvents option to proxy events regardless.
 *					- Fixed issue with swipe and pinch not triggering at the same time
 *
 * $Date: 2015-9-6 (Tues, 9 June 2015) $
 * $version 1.6.9    - Added PR from jdalton/hybrid to fix pointer events
 *					- Added scrolling demo
 *					- Added version property to plugin
 *
 * $Date: 2015-1-10 (Wed, 1 October 2015) $
 * $version 1.6.10    - Added PR from beatspace to fix tap events
 * $version 1.6.11    - Added PRs from indri-indri ( Doc tidyup), kkirsche ( Bower tidy up ), UziTech (preventDefaultEvents fixes )
 *					 - Allowed setting multiple options via .swipe("options", options_hash) and more simply .swipe(options_hash) or exisitng instances
 * $version 1.6.12    - Fixed bug with multi finger releases above 2 not triggering events
 *
 * $Date: 2015-12-18 (Fri, 18 December 2015) $
 * $version 1.6.13    - Added PRs
 *                    - Fixed #267 allowPageScroll not working correctly
 * $version 1.6.14    - Fixed #220 / #248 doubletap not firing with swipes, #223 commonJS compatible
 * $version 1.6.15    - More bug fixes
 */

/**
 * See (http://jquery.com/).
 * @name $
 * @class
 * See the jQuery Library  (http://jquery.com/) for full details.  This just
 * documents the function and classes that are added to jQuery by this plug-in.
 */

/**
 * See (http://jquery.com/)
 * @name fn
 * @class
 * See the jQuery Library  (http://jquery.com/) for full details.  This just
 * documents the function and classes that are added to jQuery by this plug-in.
 * @memberOf $
 */


(function(factory) {
  if (typeof define === 'function' && define.amd && define.amd.jQuery) {
    // AMD. Register as anonymous module.
    define(['jquery'], factory);
  } else if (typeof module !== 'undefined' && module.exports) {
    // CommonJS Module
    factory(require("jquery"));
  } else {
    // Browser globals.
    factory(jQuery);
  }
}(function($) {
  "use strict";

  //Constants
  var VERSION = "1.6.15",
    LEFT = "left",
    RIGHT = "right",
    UP = "up",
    DOWN = "down",
    IN = "in",
    OUT = "out",

    NONE = "none",
    AUTO = "auto",

    SWIPE = "swipe",
    PINCH = "pinch",
    TAP = "tap",
    DOUBLE_TAP = "doubletap",
    LONG_TAP = "longtap",
    HOLD = "hold",

    HORIZONTAL = "horizontal",
    VERTICAL = "vertical",

    ALL_FINGERS = "all",

    DOUBLE_TAP_THRESHOLD = 10,

    PHASE_START = "start",
    PHASE_MOVE = "move",
    PHASE_END = "end",
    PHASE_CANCEL = "cancel",

    SUPPORTS_TOUCH = 'ontouchstart' in window,

    SUPPORTS_POINTER_IE10 = window.navigator.msPointerEnabled && !window.navigator.pointerEnabled && !SUPPORTS_TOUCH,

    SUPPORTS_POINTER = (window.navigator.pointerEnabled || window.navigator.msPointerEnabled) && !SUPPORTS_TOUCH,

    PLUGIN_NS = 'TouchSwipe';



  /**
  * The default configuration, and available options to configure touch swipe with.
  * You can set the default values by updating any of the properties prior to instantiation.
  * @name $.fn.swipe.defaults
  * @namespace
  * @property {int} [fingers=1] The number of fingers to detect in a swipe. Any swipes that do not meet this requirement will NOT trigger swipe handlers.
  * @property {int} [threshold=75] The number of pixels that the user must move their finger by before it is considered a swipe.
  * @property {int} [cancelThreshold=null] The number of pixels that the user must move their finger back from the original swipe direction to cancel the gesture.
  * @property {int} [pinchThreshold=20] The number of pixels that the user must pinch their finger by before it is considered a pinch.
  * @property {int} [maxTimeThreshold=null] Time, in milliseconds, between touchStart and touchEnd must NOT exceed in order to be considered a swipe.
  * @property {int} [fingerReleaseThreshold=250] Time in milliseconds between releasing multiple fingers.  If 2 fingers are down, and are released one after the other, if they are within this threshold, it counts as a simultaneous release.
  * @property {int} [longTapThreshold=500] Time in milliseconds between tap and release for a long tap
  * @property {int} [doubleTapThreshold=200] Time in milliseconds between 2 taps to count as a double tap
  * @property {function} [swipe=null] A handler to catch all swipes. See {@link $.fn.swipe#event:swipe}
  * @property {function} [swipeLeft=null] A handler that is triggered for "left" swipes. See {@link $.fn.swipe#event:swipeLeft}
  * @property {function} [swipeRight=null] A handler that is triggered for "right" swipes. See {@link $.fn.swipe#event:swipeRight}
  * @property {function} [swipeUp=null] A handler that is triggered for "up" swipes. See {@link $.fn.swipe#event:swipeUp}
  * @property {function} [swipeDown=null] A handler that is triggered for "down" swipes. See {@link $.fn.swipe#event:swipeDown}
  * @property {function} [swipeStatus=null] A handler triggered for every phase of the swipe. See {@link $.fn.swipe#event:swipeStatus}
  * @property {function} [pinchIn=null] A handler triggered for pinch in events. See {@link $.fn.swipe#event:pinchIn}
  * @property {function} [pinchOut=null] A handler triggered for pinch out events. See {@link $.fn.swipe#event:pinchOut}
  * @property {function} [pinchStatus=null] A handler triggered for every phase of a pinch. See {@link $.fn.swipe#event:pinchStatus}
  * @property {function} [tap=null] A handler triggered when a user just taps on the item, rather than swipes it. If they do not move, tap is triggered, if they do move, it is not.
  * @property {function} [doubleTap=null] A handler triggered when a user double taps on the item. The delay between taps can be set with the doubleTapThreshold property. See {@link $.fn.swipe.defaults#doubleTapThreshold}
  * @property {function} [longTap=null] A handler triggered when a user long taps on the item. The delay between start and end can be set with the longTapThreshold property. See {@link $.fn.swipe.defaults#longTapThreshold}
  * @property (function) [hold=null] A handler triggered when a user reaches longTapThreshold on the item. See {@link $.fn.swipe.defaults#longTapThreshold}
  * @property {boolean} [triggerOnTouchEnd=true] If true, the swipe events are triggered when the touch end event is received (user releases finger).  If false, it will be triggered on reaching the threshold, and then cancel the touch event automatically.
  * @property {boolean} [triggerOnTouchLeave=false] If true, then when the user leaves the swipe object, the swipe will end and trigger appropriate handlers.
  * @property {string|undefined} [allowPageScroll='auto'] How the browser handles page scrolls when the user is swiping on a touchSwipe object. See {@link $.fn.swipe.pageScroll}.  <br/><br/>
  									<code>"auto"</code> : all undefined swipes will cause the page to scroll in that direction. <br/>
  									<code>"none"</code> : the page will not scroll when user swipes. <br/>
  									<code>"horizontal"</code> : will force page to scroll on horizontal swipes. <br/>
  									<code>"vertical"</code> : will force page to scroll on vertical swipes. <br/>
  * @property {boolean} [fallbackToMouseEvents=true] If true mouse events are used when run on a non touch device, false will stop swipes being triggered by mouse events on non tocuh devices.
  * @property {string} [excludedElements="button, input, select, textarea, a, .noSwipe"] A jquery selector that specifies child elements that do NOT trigger swipes. By default this excludes all form, input, select, button, anchor and .noSwipe elements.
  * @property {boolean} [preventDefaultEvents=true] by default default events are cancelled, so the page doesn't move.  You can dissable this so both native events fire as well as your handlers.

  */
  var defaults = {
    fingers: 1,
    threshold: 75,
    cancelThreshold: null,
    pinchThreshold: 20,
    maxTimeThreshold: null,
    fingerReleaseThreshold: 250,
    longTapThreshold: 500,
    doubleTapThreshold: 200,
    swipe: null,
    swipeLeft: null,
    swipeRight: null,
    swipeUp: null,
    swipeDown: null,
    swipeStatus: null,
    pinchIn: null,
    pinchOut: null,
    pinchStatus: null,
    click: null, //Deprecated since 1.6.2
    tap: null,
    doubleTap: null,
    longTap: null,
    hold: null,
    triggerOnTouchEnd: true,
    triggerOnTouchLeave: false,
    allowPageScroll: "auto",
    fallbackToMouseEvents: true,
    excludedElements: "label, button, input, select, textarea, a, .noSwipe",
    preventDefaultEvents: true
  };



  /**
   * Applies TouchSwipe behaviour to one or more jQuery objects.
   * The TouchSwipe plugin can be instantiated via this method, or methods within
   * TouchSwipe can be executed via this method as per jQuery plugin architecture.
   * An existing plugin can have its options changed simply by re calling .swipe(options)
   * @see TouchSwipe
   * @class
   * @param {Mixed} method If the current DOMNode is a TouchSwipe object, and <code>method</code> is a TouchSwipe method, then
   * the <code>method</code> is executed, and any following arguments are passed to the TouchSwipe method.
   * If <code>method</code> is an object, then the TouchSwipe class is instantiated on the current DOMNode, passing the
   * configuration properties defined in the object. See TouchSwipe
   *
   */
  $.fn.swipe = function(method) {
    var $this = $(this),
      plugin = $this.data(PLUGIN_NS);

    //Check if we are already instantiated and trying to execute a method
    if (plugin && typeof method === 'string') {
      if (plugin[method]) {
        return plugin[method].apply(this, Array.prototype.slice.call(arguments, 1));
      } else {
        $.error('Method ' + method + ' does not exist on jQuery.swipe');
      }
    }

    //Else update existing plugin with new options hash
    else if (plugin && typeof method === 'object') {
      plugin['option'].apply(this, arguments);
    }

    //Else not instantiated and trying to pass init object (or nothing)
    else if (!plugin && (typeof method === 'object' || !method)) {
      return init.apply(this, arguments);
    }

    return $this;
  };

  /**
   * The version of the plugin
   * @readonly
   */
  $.fn.swipe.version = VERSION;



  //Expose our defaults so a user could override the plugin defaults
  $.fn.swipe.defaults = defaults;

  /**
   * The phases that a touch event goes through.  The <code>phase</code> is passed to the event handlers.
   * These properties are read only, attempting to change them will not alter the values passed to the event handlers.
   * @namespace
   * @readonly
   * @property {string} PHASE_START Constant indicating the start phase of the touch event. Value is <code>"start"</code>.
   * @property {string} PHASE_MOVE Constant indicating the move phase of the touch event. Value is <code>"move"</code>.
   * @property {string} PHASE_END Constant indicating the end phase of the touch event. Value is <code>"end"</code>.
   * @property {string} PHASE_CANCEL Constant indicating the cancel phase of the touch event. Value is <code>"cancel"</code>.
   */
  $.fn.swipe.phases = {
    PHASE_START: PHASE_START,
    PHASE_MOVE: PHASE_MOVE,
    PHASE_END: PHASE_END,
    PHASE_CANCEL: PHASE_CANCEL
  };

  /**
   * The direction constants that are passed to the event handlers.
   * These properties are read only, attempting to change them will not alter the values passed to the event handlers.
   * @namespace
   * @readonly
   * @property {string} LEFT Constant indicating the left direction. Value is <code>"left"</code>.
   * @property {string} RIGHT Constant indicating the right direction. Value is <code>"right"</code>.
   * @property {string} UP Constant indicating the up direction. Value is <code>"up"</code>.
   * @property {string} DOWN Constant indicating the down direction. Value is <code>"cancel"</code>.
   * @property {string} IN Constant indicating the in direction. Value is <code>"in"</code>.
   * @property {string} OUT Constant indicating the out direction. Value is <code>"out"</code>.
   */
  $.fn.swipe.directions = {
    LEFT: LEFT,
    RIGHT: RIGHT,
    UP: UP,
    DOWN: DOWN,
    IN: IN,
    OUT: OUT
  };

  /**
   * The page scroll constants that can be used to set the value of <code>allowPageScroll</code> option
   * These properties are read only
   * @namespace
   * @readonly
   * @see $.fn.swipe.defaults#allowPageScroll
   * @property {string} NONE Constant indicating no page scrolling is allowed. Value is <code>"none"</code>.
   * @property {string} HORIZONTAL Constant indicating horizontal page scrolling is allowed. Value is <code>"horizontal"</code>.
   * @property {string} VERTICAL Constant indicating vertical page scrolling is allowed. Value is <code>"vertical"</code>.
   * @property {string} AUTO Constant indicating either horizontal or vertical will be allowed, depending on the swipe handlers registered. Value is <code>"auto"</code>.
   */
  $.fn.swipe.pageScroll = {
    NONE: NONE,
    HORIZONTAL: HORIZONTAL,
    VERTICAL: VERTICAL,
    AUTO: AUTO
  };

  /**
   * Constants representing the number of fingers used in a swipe.  These are used to set both the value of <code>fingers</code> in the
   * options object, as well as the value of the <code>fingers</code> event property.
   * These properties are read only, attempting to change them will not alter the values passed to the event handlers.
   * @namespace
   * @readonly
   * @see $.fn.swipe.defaults#fingers
   * @property {string} ONE Constant indicating 1 finger is to be detected / was detected. Value is <code>1</code>.
   * @property {string} TWO Constant indicating 2 fingers are to be detected / were detected. Value is <code>2</code>.
   * @property {string} THREE Constant indicating 3 finger are to be detected / were detected. Value is <code>3</code>.
   * @property {string} FOUR Constant indicating 4 finger are to be detected / were detected. Not all devices support this. Value is <code>4</code>.
   * @property {string} FIVE Constant indicating 5 finger are to be detected / were detected. Not all devices support this. Value is <code>5</code>.
   * @property {string} ALL Constant indicating any combination of finger are to be detected.  Value is <code>"all"</code>.
   */
  $.fn.swipe.fingers = {
    ONE: 1,
    TWO: 2,
    THREE: 3,
    FOUR: 4,
    FIVE: 5,
    ALL: ALL_FINGERS
  };

  /**
   * Initialise the plugin for each DOM element matched
   * This creates a new instance of the main TouchSwipe class for each DOM element, and then
   * saves a reference to that instance in the elements data property.
   * @internal
   */
  function init(options) {
    //Prep and extend the options
    if (options && (options.allowPageScroll === undefined && (options.swipe !== undefined || options.swipeStatus !== undefined))) {
      options.allowPageScroll = NONE;
    }

    //Check for deprecated options
    //Ensure that any old click handlers are assigned to the new tap, unless we have a tap
    if (options.click !== undefined && options.tap === undefined) {
      options.tap = options.click;
    }

    if (!options) {
      options = {};
    }

    //pass empty object so we dont modify the defaults
    options = $.extend({}, $.fn.swipe.defaults, options);

    //For each element instantiate the plugin
    return this.each(function() {
      var $this = $(this);

      //Check we havent already initialised the plugin
      var plugin = $this.data(PLUGIN_NS);

      if (!plugin) {
        plugin = new TouchSwipe(this, options);
        $this.data(PLUGIN_NS, plugin);
      }
    });
  }

  /**
   * Main TouchSwipe Plugin Class.
   * Do not use this to construct your TouchSwipe object, use the jQuery plugin method $.fn.swipe(); {@link $.fn.swipe}
   * @private
   * @name TouchSwipe
   * @param {DOMNode} element The HTML DOM object to apply to plugin to
   * @param {Object} options The options to configure the plugin with.  @link {$.fn.swipe.defaults}
   * @see $.fh.swipe.defaults
   * @see $.fh.swipe
   * @class
   */
  function TouchSwipe(element, options) {

    //take a local/instacne level copy of the options - should make it this.options really...
    var options = $.extend({}, options);

    var useTouchEvents = (SUPPORTS_TOUCH || SUPPORTS_POINTER || !options.fallbackToMouseEvents),
      START_EV = useTouchEvents ? (SUPPORTS_POINTER ? (SUPPORTS_POINTER_IE10 ? 'MSPointerDown' : 'pointerdown') : 'touchstart') : 'mousedown',
      MOVE_EV = useTouchEvents ? (SUPPORTS_POINTER ? (SUPPORTS_POINTER_IE10 ? 'MSPointerMove' : 'pointermove') : 'touchmove') : 'mousemove',
      END_EV = useTouchEvents ? (SUPPORTS_POINTER ? (SUPPORTS_POINTER_IE10 ? 'MSPointerUp' : 'pointerup') : 'touchend') : 'mouseup',
      LEAVE_EV = useTouchEvents ? (SUPPORTS_POINTER ? 'mouseleave' : null) : 'mouseleave', //we manually detect leave on touch devices, so null event here
      CANCEL_EV = (SUPPORTS_POINTER ? (SUPPORTS_POINTER_IE10 ? 'MSPointerCancel' : 'pointercancel') : 'touchcancel');



    //touch properties
    var distance = 0,
      direction = null,
      currentDirection = null,
      duration = 0,
      startTouchesDistance = 0,
      endTouchesDistance = 0,
      pinchZoom = 1,
      pinchDistance = 0,
      pinchDirection = 0,
      maximumsMap = null;



    //jQuery wrapped element for this instance
    var $element = $(element);

    //Current phase of th touch cycle
    var phase = "start";

    // the current number of fingers being used.
    var fingerCount = 0;

    //track mouse points / delta
    var fingerData = {};

    //track times
    var startTime = 0,
      endTime = 0,
      previousTouchEndTime = 0,
      fingerCountAtRelease = 0,
      doubleTapStartTime = 0;

    //Timeouts
    var singleTapTimeout = null,
      holdTimeout = null;

    // Add gestures to all swipable areas if supported
    try {
      $element.bind(START_EV, touchStart);
      $element.bind(CANCEL_EV, touchCancel);
    } catch (e) {
      $.error('events not supported ' + START_EV + ',' + CANCEL_EV + ' on jQuery.swipe');
    }

    //
    //Public methods
    //

    /**
     * re-enables the swipe plugin with the previous configuration
     * @function
     * @name $.fn.swipe#enable
     * @return {DOMNode} The Dom element that was registered with TouchSwipe
     * @example $("#element").swipe("enable");
     */
    this.enable = function() {
      $element.bind(START_EV, touchStart);
      $element.bind(CANCEL_EV, touchCancel);
      return $element;
    };

    /**
     * disables the swipe plugin
     * @function
     * @name $.fn.swipe#disable
     * @return {DOMNode} The Dom element that is now registered with TouchSwipe
     * @example $("#element").swipe("disable");
     */
    this.disable = function() {
      removeListeners();
      return $element;
    };

    /**
     * Destroy the swipe plugin completely. To use any swipe methods, you must re initialise the plugin.
     * @function
     * @name $.fn.swipe#destroy
     * @example $("#element").swipe("destroy");
     */
    this.destroy = function() {
      removeListeners();
      $element.data(PLUGIN_NS, null);
      $element = null;
    };


    /**
     * Allows run time updating of the swipe configuration options.
     * @function
     * @name $.fn.swipe#option
     * @param {String} property The option property to get or set, or a has of multiple options to set
     * @param {Object} [value] The value to set the property to
     * @return {Object} If only a property name is passed, then that property value is returned. If nothing is passed the current options hash is returned.
     * @example $("#element").swipe("option", "threshold"); // return the threshold
     * @example $("#element").swipe("option", "threshold", 100); // set the threshold after init
     * @example $("#element").swipe("option", {threshold:100, fingers:3} ); // set multiple properties after init
     * @example $("#element").swipe({threshold:100, fingers:3} ); // set multiple properties after init - the "option" method is optional!
     * @example $("#element").swipe("option"); // Return the current options hash
     * @see $.fn.swipe.defaults
     *
     */
    this.option = function(property, value) {

      if (typeof property === 'object') {
        options = $.extend(options, property);
      } else if (options[property] !== undefined) {
        if (value === undefined) {
          return options[property];
        } else {
          options[property] = value;
        }
      } else if (!property) {
        return options;
      } else {
        $.error('Option ' + property + ' does not exist on jQuery.swipe.options');
      }

      return null;
    }



    //
    // Private methods
    //

    //
    // EVENTS
    //
    /**
     * Event handler for a touch start event.
     * Stops the default click event from triggering and stores where we touched
     * @inner
     * @param {object} jqEvent The normalised jQuery event object.
     */
    function touchStart(jqEvent) {

      //If we already in a touch event (a finger already in use) then ignore subsequent ones..
      if (getTouchInProgress()) {
        return;
      }

      //Check if this element matches any in the excluded elements selectors,  or its parent is excluded, if so, DON'T swipe
      if ($(jqEvent.target).closest(options.excludedElements, $element).length > 0) {
        return;
      }

      //As we use Jquery bind for events, we need to target the original event object
      //If these events are being programmatically triggered, we don't have an original event object, so use the Jq one.
      var event = jqEvent.originalEvent ? jqEvent.originalEvent : jqEvent;

      var ret,
        touches = event.touches,
        evt = touches ? touches[0] : event;

      phase = PHASE_START;

      //If we support touches, get the finger count
      if (touches) {
        // get the total number of fingers touching the screen
        fingerCount = touches.length;
      }
      //Else this is the desktop, so stop the browser from dragging content
      else if (options.preventDefaultEvents !== false) {
        jqEvent.preventDefault(); //call this on jq event so we are cross browser
      }

      //clear vars..
      distance = 0;
      direction = null;
      currentDirection=null;
      pinchDirection = null;
      duration = 0;
      startTouchesDistance = 0;
      endTouchesDistance = 0;
      pinchZoom = 1;
      pinchDistance = 0;
      maximumsMap = createMaximumsData();
      cancelMultiFingerRelease();

      //Create the default finger data
      createFingerData(0, evt);

      // check the number of fingers is what we are looking for, or we are capturing pinches
      if (!touches || (fingerCount === options.fingers || options.fingers === ALL_FINGERS) || hasPinches()) {
        // get the coordinates of the touch
        startTime = getTimeStamp();

        if (fingerCount == 2) {
          //Keep track of the initial pinch distance, so we can calculate the diff later
          //Store second finger data as start
          createFingerData(1, touches[1]);
          startTouchesDistance = endTouchesDistance = calculateTouchesDistance(fingerData[0].start, fingerData[1].start);
        }

        if (options.swipeStatus || options.pinchStatus) {
          ret = triggerHandler(event, phase);
        }
      } else {
        //A touch with more or less than the fingers we are looking for, so cancel
        ret = false;
      }

      //If we have a return value from the users handler, then return and cancel
      if (ret === false) {
        phase = PHASE_CANCEL;
        triggerHandler(event, phase);
        return ret;
      } else {
        if (options.hold) {
          holdTimeout = setTimeout($.proxy(function() {
            //Trigger the event
            $element.trigger('hold', [event.target]);
            //Fire the callback
            if (options.hold) {
              ret = options.hold.call($element, event, event.target);
            }
          }, this), options.longTapThreshold);
        }

        setTouchInProgress(true);
      }

      return null;
    };



    /**
     * Event handler for a touch move event.
     * If we change fingers during move, then cancel the event
     * @inner
     * @param {object} jqEvent The normalised jQuery event object.
     */
    function touchMove(jqEvent) {

      //As we use Jquery bind for events, we need to target the original event object
      //If these events are being programmatically triggered, we don't have an original event object, so use the Jq one.
      var event = jqEvent.originalEvent ? jqEvent.originalEvent : jqEvent;

      //If we are ending, cancelling, or within the threshold of 2 fingers being released, don't track anything..
      if (phase === PHASE_END || phase === PHASE_CANCEL || inMultiFingerRelease())
        return;

      var ret,
        touches = event.touches,
        evt = touches ? touches[0] : event;


      //Update the  finger data
      var currentFinger = updateFingerData(evt);
      endTime = getTimeStamp();

      if (touches) {
        fingerCount = touches.length;
      }

      if (options.hold)
        clearTimeout(holdTimeout);

      phase = PHASE_MOVE;

      //If we have 2 fingers get Touches distance as well
      if (fingerCount == 2) {

        //Keep track of the initial pinch distance, so we can calculate the diff later
        //We do this here as well as the start event, in case they start with 1 finger, and the press 2 fingers
        if (startTouchesDistance == 0) {
          //Create second finger if this is the first time...
          createFingerData(1, touches[1]);

          startTouchesDistance = endTouchesDistance = calculateTouchesDistance(fingerData[0].start, fingerData[1].start);
        } else {
          //Else just update the second finger
          updateFingerData(touches[1]);

          endTouchesDistance = calculateTouchesDistance(fingerData[0].end, fingerData[1].end);
          pinchDirection = calculatePinchDirection(fingerData[0].end, fingerData[1].end);
        }

        pinchZoom = calculatePinchZoom(startTouchesDistance, endTouchesDistance);
        pinchDistance = Math.abs(startTouchesDistance - endTouchesDistance);
      }

      if ((fingerCount === options.fingers || options.fingers === ALL_FINGERS) || !touches || hasPinches()) {

        //The overall direction of the swipe. From start to now.
        direction = calculateDirection(currentFinger.start, currentFinger.end);

        //The immediate direction of the swipe, direction between the last movement and this one.
        currentDirection = calculateDirection(currentFinger.last, currentFinger.end);

        //Check if we need to prevent default event (page scroll / pinch zoom) or not
        validateDefaultEvent(jqEvent, currentDirection);

        //Distance and duration are all off the main finger
        distance = calculateDistance(currentFinger.start, currentFinger.end);
        duration = calculateDuration();

        //Cache the maximum distance we made in this direction
        setMaxDistance(direction, distance);

        //Trigger status handler
        ret = triggerHandler(event, phase);


        //If we trigger end events when threshold are met, or trigger events when touch leaves element
        if (!options.triggerOnTouchEnd || options.triggerOnTouchLeave) {

          var inBounds = true;

          //If checking if we leave the element, run the bounds check (we can use touchleave as its not supported on webkit)
          if (options.triggerOnTouchLeave) {
            var bounds = getbounds(this);
            inBounds = isInBounds(currentFinger.end, bounds);
          }

          //Trigger end handles as we swipe if thresholds met or if we have left the element if the user has asked to check these..
          if (!options.triggerOnTouchEnd && inBounds) {
            phase = getNextPhase(PHASE_MOVE);
          }
          //We end if out of bounds here, so set current phase to END, and check if its modified
          else if (options.triggerOnTouchLeave && !inBounds) {
            phase = getNextPhase(PHASE_END);
          }

          if (phase == PHASE_CANCEL || phase == PHASE_END) {
            triggerHandler(event, phase);
          }
        }
      } else {
        phase = PHASE_CANCEL;
        triggerHandler(event, phase);
      }

      if (ret === false) {
        phase = PHASE_CANCEL;
        triggerHandler(event, phase);
      }
    }




    /**
     * Event handler for a touch end event.
     * Calculate the direction and trigger events
     * @inner
     * @param {object} jqEvent The normalised jQuery event object.
     */
    function touchEnd(jqEvent) {
      //As we use Jquery bind for events, we need to target the original event object
      //If these events are being programmatically triggered, we don't have an original event object, so use the Jq one.
      var event = jqEvent.originalEvent ? jqEvent.originalEvent : jqEvent,
        touches = event.touches;

      //If we are still in a touch with the device wait a fraction and see if the other finger comes up
      //if it does within the threshold, then we treat it as a multi release, not a single release and end the touch / swipe
      if (touches) {
        if (touches.length && !inMultiFingerRelease()) {
          startMultiFingerRelease(event);
          return true;
        } else if (touches.length && inMultiFingerRelease()) {
          return true;
        }
      }

      //If a previous finger has been released, check how long ago, if within the threshold, then assume it was a multifinger release.
      //This is used to allow 2 fingers to release fractionally after each other, whilst maintaining the event as containing 2 fingers, not 1
      if (inMultiFingerRelease()) {
        fingerCount = fingerCountAtRelease;
      }

      //Set end of swipe
      endTime = getTimeStamp();

      //Get duration incase move was never fired
      duration = calculateDuration();

      //If we trigger handlers at end of swipe OR, we trigger during, but they didnt trigger and we are still in the move phase
      if (didSwipeBackToCancel() || !validateSwipeDistance()) {
        phase = PHASE_CANCEL;
        triggerHandler(event, phase);
      } else if (options.triggerOnTouchEnd || (options.triggerOnTouchEnd == false && phase === PHASE_MOVE)) {
        //call this on jq event so we are cross browser
        if (options.preventDefaultEvents !== false) {
          jqEvent.preventDefault();
        }
        phase = PHASE_END;
        triggerHandler(event, phase);
      }
      //Special cases - A tap should always fire on touch end regardless,
      //So here we manually trigger the tap end handler by itself
      //We dont run trigger handler as it will re-trigger events that may have fired already
      else if (!options.triggerOnTouchEnd && hasTap()) {
        //Trigger the pinch events...
        phase = PHASE_END;
        triggerHandlerForGesture(event, phase, TAP);
      } else if (phase === PHASE_MOVE) {
        phase = PHASE_CANCEL;
        triggerHandler(event, phase);
      }

      setTouchInProgress(false);

      return null;
    }



    /**
     * Event handler for a touch cancel event.
     * Clears current vars
     * @inner
     */
    function touchCancel() {
      // reset the variables back to default values
      fingerCount = 0;
      endTime = 0;
      startTime = 0;
      startTouchesDistance = 0;
      endTouchesDistance = 0;
      pinchZoom = 1;

      //If we were in progress of tracking a possible multi touch end, then re set it.
      cancelMultiFingerRelease();

      setTouchInProgress(false);
    }


    /**
     * Event handler for a touch leave event.
     * This is only triggered on desktops, in touch we work this out manually
     * as the touchleave event is not supported in webkit
     * @inner
     */
    function touchLeave(jqEvent) {
      //If these events are being programmatically triggered, we don't have an original event object, so use the Jq one.
      var event = jqEvent.originalEvent ? jqEvent.originalEvent : jqEvent;

      //If we have the trigger on leave property set....
      if (options.triggerOnTouchLeave) {
        phase = getNextPhase(PHASE_END);
        triggerHandler(event, phase);
      }
    }

    /**
     * Removes all listeners that were associated with the plugin
     * @inner
     */
    function removeListeners() {
      $element.unbind(START_EV, touchStart);
      $element.unbind(CANCEL_EV, touchCancel);
      $element.unbind(MOVE_EV, touchMove);
      $element.unbind(END_EV, touchEnd);

      //we only have leave events on desktop, we manually calculate leave on touch as its not supported in webkit
      if (LEAVE_EV) {
        $element.unbind(LEAVE_EV, touchLeave);
      }

      setTouchInProgress(false);
    }


    /**
     * Checks if the time and distance thresholds have been met, and if so then the appropriate handlers are fired.
     */
    function getNextPhase(currentPhase) {

      var nextPhase = currentPhase;

      // Ensure we have valid swipe (under time and over distance  and check if we are out of bound...)
      var validTime = validateSwipeTime();
      var validDistance = validateSwipeDistance();
      var didCancel = didSwipeBackToCancel();

      //If we have exceeded our time, then cancel
      if (!validTime || didCancel) {
        nextPhase = PHASE_CANCEL;
      }
      //Else if we are moving, and have reached distance then end
      else if (validDistance && currentPhase == PHASE_MOVE && (!options.triggerOnTouchEnd || options.triggerOnTouchLeave)) {
        nextPhase = PHASE_END;
      }
      //Else if we have ended by leaving and didn't reach distance, then cancel
      else if (!validDistance && currentPhase == PHASE_END && options.triggerOnTouchLeave) {
        nextPhase = PHASE_CANCEL;
      }

      return nextPhase;
    }


    /**
     * Trigger the relevant event handler
     * The handlers are passed the original event, the element that was swiped, and in the case of the catch all handler, the direction that was swiped, "left", "right", "up", or "down"
     * @param {object} event the original event object
     * @param {string} phase the phase of the swipe (start, end cancel etc) {@link $.fn.swipe.phases}
     * @inner
     */
    function triggerHandler(event, phase) {



      var ret,
        touches = event.touches;

      // SWIPE GESTURES
      if (didSwipe() || hasSwipes()) {
          ret = triggerHandlerForGesture(event, phase, SWIPE);
      }

      // PINCH GESTURES (if the above didn't cancel)
      if ((didPinch() || hasPinches()) && ret !== false) {
          ret = triggerHandlerForGesture(event, phase, PINCH);
      }

      // CLICK / TAP (if the above didn't cancel)
      if (didDoubleTap() && ret !== false) {
        //Trigger the tap events...
        ret = triggerHandlerForGesture(event, phase, DOUBLE_TAP);
      }

      // CLICK / TAP (if the above didn't cancel)
      else if (didLongTap() && ret !== false) {
        //Trigger the tap events...
        ret = triggerHandlerForGesture(event, phase, LONG_TAP);
      }

      // CLICK / TAP (if the above didn't cancel)
      else if (didTap() && ret !== false) {
        //Trigger the tap event..
        ret = triggerHandlerForGesture(event, phase, TAP);
      }

      // If we are cancelling the gesture, then manually trigger the reset handler
      if (phase === PHASE_CANCEL) {
        if (hasSwipes()) {
          ret = triggerHandlerForGesture(event, phase, SWIPE);
        }

        if (hasPinches()) {
          ret = triggerHandlerForGesture(event, phase, PINCH);
        }
        touchCancel(event);
      }

      // If we are ending the gesture, then manually trigger the reset handler IF all fingers are off
      if (phase === PHASE_END) {
        //If we support touch, then check that all fingers are off before we cancel
        if (touches) {
          if (!touches.length) {
            touchCancel(event);
          }
        } else {
          touchCancel(event);
        }
      }

      return ret;
    }



    /**
     * Trigger the relevant event handler
     * The handlers are passed the original event, the element that was swiped, and in the case of the catch all handler, the direction that was swiped, "left", "right", "up", or "down"
     * @param {object} event the original event object
     * @param {string} phase the phase of the swipe (start, end cancel etc) {@link $.fn.swipe.phases}
     * @param {string} gesture the gesture to trigger a handler for : PINCH or SWIPE {@link $.fn.swipe.gestures}
     * @return Boolean False, to indicate that the event should stop propagation, or void.
     * @inner
     */
    function triggerHandlerForGesture(event, phase, gesture) {

      var ret;

      //SWIPES....
      if (gesture == SWIPE) {
        //Trigger status every time..
        $element.trigger('swipeStatus', [phase, direction || null, distance || 0, duration || 0, fingerCount, fingerData, currentDirection]);

        if (options.swipeStatus) {
          ret = options.swipeStatus.call($element, event, phase, direction || null, distance || 0, duration || 0, fingerCount, fingerData, currentDirection);
          //If the status cancels, then dont run the subsequent event handlers..
          if (ret === false) return false;
        }

        if (phase == PHASE_END && validateSwipe()) {

          //Cancel any taps that were in progress...
          clearTimeout(singleTapTimeout);
          clearTimeout(holdTimeout);

          $element.trigger('swipe', [direction, distance, duration, fingerCount, fingerData, currentDirection]);

          if (options.swipe) {
            ret = options.swipe.call($element, event, direction, distance, duration, fingerCount, fingerData, currentDirection);
            //If the status cancels, then dont run the subsequent event handlers..
            if (ret === false) return false;
          }

          //trigger direction specific event handlers
          switch (direction) {
            case LEFT:
              $element.trigger('swipeLeft', [direction, distance, duration, fingerCount, fingerData, currentDirection]);

              if (options.swipeLeft) {
                ret = options.swipeLeft.call($element, event, direction, distance, duration, fingerCount, fingerData, currentDirection);
              }
              break;

            case RIGHT:
              $element.trigger('swipeRight', [direction, distance, duration, fingerCount, fingerData, currentDirection]);

              if (options.swipeRight) {
                ret = options.swipeRight.call($element, event, direction, distance, duration, fingerCount, fingerData, currentDirection);
              }
              break;

            case UP:
              $element.trigger('swipeUp', [direction, distance, duration, fingerCount, fingerData, currentDirection]);

              if (options.swipeUp) {
                ret = options.swipeUp.call($element, event, direction, distance, duration, fingerCount, fingerData, currentDirection);
              }
              break;

            case DOWN:
              $element.trigger('swipeDown', [direction, distance, duration, fingerCount, fingerData, currentDirection]);

              if (options.swipeDown) {
                ret = options.swipeDown.call($element, event, direction, distance, duration, fingerCount, fingerData, currentDirection);
              }
              break;
          }
        }
      }


      //PINCHES....
      if (gesture == PINCH) {
        $element.trigger('pinchStatus', [phase, pinchDirection || null, pinchDistance || 0, duration || 0, fingerCount, pinchZoom, fingerData]);

        if (options.pinchStatus) {
          ret = options.pinchStatus.call($element, event, phase, pinchDirection || null, pinchDistance || 0, duration || 0, fingerCount, pinchZoom, fingerData);
          //If the status cancels, then dont run the subsequent event handlers..
          if (ret === false) return false;
        }

        if (phase == PHASE_END && validatePinch()) {

          switch (pinchDirection) {
            case IN:
              $element.trigger('pinchIn', [pinchDirection || null, pinchDistance || 0, duration || 0, fingerCount, pinchZoom, fingerData]);

              if (options.pinchIn) {
                ret = options.pinchIn.call($element, event, pinchDirection || null, pinchDistance || 0, duration || 0, fingerCount, pinchZoom, fingerData);
              }
              break;

            case OUT:
              $element.trigger('pinchOut', [pinchDirection || null, pinchDistance || 0, duration || 0, fingerCount, pinchZoom, fingerData]);

              if (options.pinchOut) {
                ret = options.pinchOut.call($element, event, pinchDirection || null, pinchDistance || 0, duration || 0, fingerCount, pinchZoom, fingerData);
              }
              break;
          }
        }
      }

      if (gesture == TAP) {
        if (phase === PHASE_CANCEL || phase === PHASE_END) {

          clearTimeout(singleTapTimeout);
          clearTimeout(holdTimeout);

          //If we are also looking for doubelTaps, wait incase this is one...
          if (hasDoubleTap() && !inDoubleTap()) {
            doubleTapStartTime = getTimeStamp();

            //Now wait for the double tap timeout, and trigger this single tap
            //if its not cancelled by a double tap
            singleTapTimeout = setTimeout($.proxy(function() {
              doubleTapStartTime = null;
              $element.trigger('tap', [event.target]);

              if (options.tap) {
                ret = options.tap.call($element, event, event.target);
              }
            }, this), options.doubleTapThreshold);

          } else {
            doubleTapStartTime = null;
            $element.trigger('tap', [event.target]);
            if (options.tap) {
              ret = options.tap.call($element, event, event.target);
            }
          }
        }
      } else if (gesture == DOUBLE_TAP) {
        if (phase === PHASE_CANCEL || phase === PHASE_END) {
          clearTimeout(singleTapTimeout);
          clearTimeout(holdTimeout);
          doubleTapStartTime = null;
          $element.trigger('doubletap', [event.target]);

          if (options.doubleTap) {
            ret = options.doubleTap.call($element, event, event.target);
          }
        }
      } else if (gesture == LONG_TAP) {
        if (phase === PHASE_CANCEL || phase === PHASE_END) {
          clearTimeout(singleTapTimeout);
          doubleTapStartTime = null;

          $element.trigger('longtap', [event.target]);
          if (options.longTap) {
            ret = options.longTap.call($element, event, event.target);
          }
        }
      }

      return ret;
    }


    //
    // GESTURE VALIDATION
    //

    /**
     * Checks the user has swipe far enough
     * @return Boolean if <code>threshold</code> has been set, return true if the threshold was met, else false.
     * If no threshold was set, then we return true.
     * @inner
     */
    function validateSwipeDistance() {
      var valid = true;
      //If we made it past the min swipe distance..
      if (options.threshold !== null) {
        valid = distance >= options.threshold;
      }

      return valid;
    }

    /**
     * Checks the user has swiped back to cancel.
     * @return Boolean if <code>cancelThreshold</code> has been set, return true if the cancelThreshold was met, else false.
     * If no cancelThreshold was set, then we return true.
     * @inner
     */
    function didSwipeBackToCancel() {
      var cancelled = false;
      if (options.cancelThreshold !== null && direction !== null) {
        cancelled = (getMaxDistance(direction) - distance) >= options.cancelThreshold;
      }

      return cancelled;
    }

    /**
     * Checks the user has pinched far enough
     * @return Boolean if <code>pinchThreshold</code> has been set, return true if the threshold was met, else false.
     * If no threshold was set, then we return true.
     * @inner
     */
    function validatePinchDistance() {
      if (options.pinchThreshold !== null) {
        return pinchDistance >= options.pinchThreshold;
      }
      return true;
    }

    /**
     * Checks that the time taken to swipe meets the minimum / maximum requirements
     * @return Boolean
     * @inner
     */
    function validateSwipeTime() {
      var result;
      //If no time set, then return true
      if (options.maxTimeThreshold) {
        if (duration >= options.maxTimeThreshold) {
          result = false;
        } else {
          result = true;
        }
      } else {
        result = true;
      }

      return result;
    }



    /**
     * Checks direction of the swipe and the value allowPageScroll to see if we should allow or prevent the default behaviour from occurring.
     * This will essentially allow page scrolling or not when the user is swiping on a touchSwipe object.
     * @param {object} jqEvent The normalised jQuery representation of the event object.
     * @param {string} direction The direction of the event. See {@link $.fn.swipe.directions}
     * @see $.fn.swipe.directions
     * @inner
     */
    function validateDefaultEvent(jqEvent, direction) {

      //If the option is set, allways allow the event to bubble up (let user handle weirdness)
      if (options.preventDefaultEvents === false) {
        return;
      }

      if (options.allowPageScroll === NONE) {
        jqEvent.preventDefault();
      } else {
        var auto = options.allowPageScroll === AUTO;

        switch (direction) {
          case LEFT:
            if ((options.swipeLeft && auto) || (!auto && options.allowPageScroll != HORIZONTAL)) {
              jqEvent.preventDefault();
            }
            break;

          case RIGHT:
            if ((options.swipeRight && auto) || (!auto && options.allowPageScroll != HORIZONTAL)) {
              jqEvent.preventDefault();
            }
            break;

          case UP:
            if ((options.swipeUp && auto) || (!auto && options.allowPageScroll != VERTICAL)) {
              jqEvent.preventDefault();
            }
            break;

          case DOWN:
            if ((options.swipeDown && auto) || (!auto && options.allowPageScroll != VERTICAL)) {
              jqEvent.preventDefault();
            }
            break;
        }
      }

    }


    // PINCHES
    /**
     * Returns true of the current pinch meets the thresholds
     * @return Boolean
     * @inner
     */
    function validatePinch() {
      var hasCorrectFingerCount = validateFingers();
      var hasEndPoint = validateEndPoint();
      var hasCorrectDistance = validatePinchDistance();
      return hasCorrectFingerCount && hasEndPoint && hasCorrectDistance;

    }

    /**
     * Returns true if any Pinch events have been registered
     * @return Boolean
     * @inner
     */
    function hasPinches() {
      //Enure we dont return 0 or null for false values
      return !!(options.pinchStatus || options.pinchIn || options.pinchOut);
    }

    /**
     * Returns true if we are detecting pinches, and have one
     * @return Boolean
     * @inner
     */
    function didPinch() {
      //Enure we dont return 0 or null for false values
      return !!(validatePinch() && hasPinches());
    }




    // SWIPES
    /**
     * Returns true if the current swipe meets the thresholds
     * @return Boolean
     * @inner
     */
    function validateSwipe() {
      //Check validity of swipe
      var hasValidTime = validateSwipeTime();
      var hasValidDistance = validateSwipeDistance();
      var hasCorrectFingerCount = validateFingers();
      var hasEndPoint = validateEndPoint();
      var didCancel = didSwipeBackToCancel();

      // if the user swiped more than the minimum length, perform the appropriate action
      // hasValidDistance is null when no distance is set
      var valid = !didCancel && hasEndPoint && hasCorrectFingerCount && hasValidDistance && hasValidTime;

      return valid;
    }

    /**
     * Returns true if any Swipe events have been registered
     * @return Boolean
     * @inner
     */
    function hasSwipes() {
      //Enure we dont return 0 or null for false values
      return !!(options.swipe || options.swipeStatus || options.swipeLeft || options.swipeRight || options.swipeUp || options.swipeDown);
    }


    /**
     * Returns true if we are detecting swipes and have one
     * @return Boolean
     * @inner
     */
    function didSwipe() {
      //Enure we dont return 0 or null for false values
      return !!(validateSwipe() && hasSwipes());
    }

    /**
     * Returns true if we have matched the number of fingers we are looking for
     * @return Boolean
     * @inner
     */
    function validateFingers() {
      //The number of fingers we want were matched, or on desktop we ignore
      return ((fingerCount === options.fingers || options.fingers === ALL_FINGERS) || !SUPPORTS_TOUCH);
    }

    /**
     * Returns true if we have an end point for the swipe
     * @return Boolean
     * @inner
     */
    function validateEndPoint() {
      //We have an end value for the finger
      return fingerData[0].end.x !== 0;
    }

    // TAP / CLICK
    /**
     * Returns true if a click / tap events have been registered
     * @return Boolean
     * @inner
     */
    function hasTap() {
      //Enure we dont return 0 or null for false values
      return !!(options.tap);
    }

    /**
     * Returns true if a double tap events have been registered
     * @return Boolean
     * @inner
     */
    function hasDoubleTap() {
      //Enure we dont return 0 or null for false values
      return !!(options.doubleTap);
    }

    /**
     * Returns true if any long tap events have been registered
     * @return Boolean
     * @inner
     */
    function hasLongTap() {
      //Enure we dont return 0 or null for false values
      return !!(options.longTap);
    }

    /**
     * Returns true if we could be in the process of a double tap (one tap has occurred, we are listening for double taps, and the threshold hasn't past.
     * @return Boolean
     * @inner
     */
    function validateDoubleTap() {
      if (doubleTapStartTime == null) {
        return false;
      }
      var now = getTimeStamp();
      return (hasDoubleTap() && ((now - doubleTapStartTime) <= options.doubleTapThreshold));
    }

    /**
     * Returns true if we could be in the process of a double tap (one tap has occurred, we are listening for double taps, and the threshold hasn't past.
     * @return Boolean
     * @inner
     */
    function inDoubleTap() {
      return validateDoubleTap();
    }


    /**
     * Returns true if we have a valid tap
     * @return Boolean
     * @inner
     */
    function validateTap() {
      return ((fingerCount === 1 || !SUPPORTS_TOUCH) && (isNaN(distance) || distance < options.threshold));
    }

    /**
     * Returns true if we have a valid long tap
     * @return Boolean
     * @inner
     */
    function validateLongTap() {
      //slight threshold on moving finger
      return ((duration > options.longTapThreshold) && (distance < DOUBLE_TAP_THRESHOLD));
    }

    /**
     * Returns true if we are detecting taps and have one
     * @return Boolean
     * @inner
     */
    function didTap() {
      //Enure we dont return 0 or null for false values
      return !!(validateTap() && hasTap());
    }


    /**
     * Returns true if we are detecting double taps and have one
     * @return Boolean
     * @inner
     */
    function didDoubleTap() {
      //Enure we dont return 0 or null for false values
      return !!(validateDoubleTap() && hasDoubleTap());
    }

    /**
     * Returns true if we are detecting long taps and have one
     * @return Boolean
     * @inner
     */
    function didLongTap() {
      //Enure we dont return 0 or null for false values
      return !!(validateLongTap() && hasLongTap());
    }




    // MULTI FINGER TOUCH
    /**
     * Starts tracking the time between 2 finger releases, and keeps track of how many fingers we initially had up
     * @inner
     */
    function startMultiFingerRelease(event) {
      previousTouchEndTime = getTimeStamp();
      fingerCountAtRelease = event.touches.length + 1;
    }

    /**
     * Cancels the tracking of time between 2 finger releases, and resets counters
     * @inner
     */
    function cancelMultiFingerRelease() {
      previousTouchEndTime = 0;
      fingerCountAtRelease = 0;
    }

    /**
     * Checks if we are in the threshold between 2 fingers being released
     * @return Boolean
     * @inner
     */
    function inMultiFingerRelease() {

      var withinThreshold = false;

      if (previousTouchEndTime) {
        var diff = getTimeStamp() - previousTouchEndTime
        if (diff <= options.fingerReleaseThreshold) {
          withinThreshold = true;
        }
      }

      return withinThreshold;
    }


    /**
     * gets a data flag to indicate that a touch is in progress
     * @return Boolean
     * @inner
     */
    function getTouchInProgress() {
      //strict equality to ensure only true and false are returned
      return !!($element.data(PLUGIN_NS + '_intouch') === true);
    }

    /**
     * Sets a data flag to indicate that a touch is in progress
     * @param {boolean} val The value to set the property to
     * @inner
     */
    function setTouchInProgress(val) {

      //If destroy is called in an event handler, we have no el, and we have already cleaned up, so return.
      if(!$element) { return; }

      //Add or remove event listeners depending on touch status
      if (val === true) {
        $element.bind(MOVE_EV, touchMove);
        $element.bind(END_EV, touchEnd);

        //we only have leave events on desktop, we manually calcuate leave on touch as its not supported in webkit
        if (LEAVE_EV) {
          $element.bind(LEAVE_EV, touchLeave);
        }
      } else {

        $element.unbind(MOVE_EV, touchMove, false);
        $element.unbind(END_EV, touchEnd, false);

        //we only have leave events on desktop, we manually calcuate leave on touch as its not supported in webkit
        if (LEAVE_EV) {
          $element.unbind(LEAVE_EV, touchLeave, false);
        }
      }


      //strict equality to ensure only true and false can update the value
      $element.data(PLUGIN_NS + '_intouch', val === true);
    }


    /**
     * Creates the finger data for the touch/finger in the event object.
     * @param {int} id The id to store the finger data under (usually the order the fingers were pressed)
     * @param {object} evt The event object containing finger data
     * @return finger data object
     * @inner
     */
    function createFingerData(id, evt) {
      var f = {
        start: {
          x: 0,
          y: 0
        },
        last: {
          x: 0,
          y: 0
        },
        end: {
          x: 0,
          y: 0
        }
      };
      f.start.x = f.last.x = f.end.x = evt.pageX || evt.clientX;
      f.start.y = f.last.y = f.end.y = evt.pageY || evt.clientY;
      fingerData[id] = f;
      return f;
    }

    /**
     * Updates the finger data for a particular event object
     * @param {object} evt The event object containing the touch/finger data to upadte
     * @return a finger data object.
     * @inner
     */
    function updateFingerData(evt) {
      var id = evt.identifier !== undefined ? evt.identifier : 0;
      var f = getFingerData(id);

      if (f === null) {
        f = createFingerData(id, evt);
      }

      f.last.x = f.end.x;
      f.last.y = f.end.y;

      f.end.x = evt.pageX || evt.clientX;
      f.end.y = evt.pageY || evt.clientY;

      return f;
    }

    /**
     * Returns a finger data object by its event ID.
     * Each touch event has an identifier property, which is used
     * to track repeat touches
     * @param {int} id The unique id of the finger in the sequence of touch events.
     * @return a finger data object.
     * @inner
     */
    function getFingerData(id) {
      return fingerData[id] || null;
    }


    /**
     * Sets the maximum distance swiped in the given direction.
     * If the new value is lower than the current value, the max value is not changed.
     * @param {string}  direction The direction of the swipe
     * @param {int}  distance The distance of the swipe
     * @inner
     */
    function setMaxDistance(direction, distance) {
      distance = Math.max(distance, getMaxDistance(direction));
      maximumsMap[direction].distance = distance;
    }

    /**
     * gets the maximum distance swiped in the given direction.
     * @param {string}  direction The direction of the swipe
     * @return int  The distance of the swipe
     * @inner
     */
    function getMaxDistance(direction) {
      if (maximumsMap[direction]) return maximumsMap[direction].distance;
      return undefined;
    }

    /**
     * Creats a map of directions to maximum swiped values.
     * @return Object A dictionary of maximum values, indexed by direction.
     * @inner
     */
    function createMaximumsData() {
      var maxData = {};
      maxData[LEFT] = createMaximumVO(LEFT);
      maxData[RIGHT] = createMaximumVO(RIGHT);
      maxData[UP] = createMaximumVO(UP);
      maxData[DOWN] = createMaximumVO(DOWN);

      return maxData;
    }

    /**
     * Creates a map maximum swiped values for a given swipe direction
     * @param {string} The direction that these values will be associated with
     * @return Object Maximum values
     * @inner
     */
    function createMaximumVO(dir) {
      return {
        direction: dir,
        distance: 0
      }
    }


    //
    // MATHS / UTILS
    //

    /**
     * Calculate the duration of the swipe
     * @return int
     * @inner
     */
    function calculateDuration() {
      return endTime - startTime;
    }

    /**
     * Calculate the distance between 2 touches (pinch)
     * @param {point} startPoint A point object containing x and y co-ordinates
     * @param {point} endPoint A point object containing x and y co-ordinates
     * @return int;
     * @inner
     */
    function calculateTouchesDistance(startPoint, endPoint) {
      var diffX = Math.abs(startPoint.x - endPoint.x);
      var diffY = Math.abs(startPoint.y - endPoint.y);

      return Math.round(Math.sqrt(diffX * diffX + diffY * diffY));
    }

    /**
     * Calculate the zoom factor between the start and end distances
     * @param {int} startDistance Distance (between 2 fingers) the user started pinching at
     * @param {int} endDistance Distance (between 2 fingers) the user ended pinching at
     * @return float The zoom value from 0 to 1.
     * @inner
     */
    function calculatePinchZoom(startDistance, endDistance) {
      var percent = (endDistance / startDistance) * 1;
      return percent.toFixed(2);
    }


    /**
     * Returns the pinch direction, either IN or OUT for the given points
     * @return string Either {@link $.fn.swipe.directions.IN} or {@link $.fn.swipe.directions.OUT}
     * @see $.fn.swipe.directions
     * @inner
     */
    function calculatePinchDirection() {
      if (pinchZoom < 1) {
        return OUT;
      } else {
        return IN;
      }
    }


    /**
     * Calculate the length / distance of the swipe
     * @param {point} startPoint A point object containing x and y co-ordinates
     * @param {point} endPoint A point object containing x and y co-ordinates
     * @return int
     * @inner
     */
    function calculateDistance(startPoint, endPoint) {
      return Math.round(Math.sqrt(Math.pow(endPoint.x - startPoint.x, 2) + Math.pow(endPoint.y - startPoint.y, 2)));
    }

    /**
     * Calculate the angle of the swipe
     * @param {point} startPoint A point object containing x and y co-ordinates
     * @param {point} endPoint A point object containing x and y co-ordinates
     * @return int
     * @inner
     */
    function calculateAngle(startPoint, endPoint) {
      var x = startPoint.x - endPoint.x;
      var y = endPoint.y - startPoint.y;
      var r = Math.atan2(y, x); //radians
      var angle = Math.round(r * 180 / Math.PI); //degrees

      //ensure value is positive
      if (angle < 0) {
        angle = 360 - Math.abs(angle);
      }

      return angle;
    }

    /**
     * Calculate the direction of the swipe
     * This will also call calculateAngle to get the latest angle of swipe
     * @param {point} startPoint A point object containing x and y co-ordinates
     * @param {point} endPoint A point object containing x and y co-ordinates
     * @return string Either {@link $.fn.swipe.directions.LEFT} / {@link $.fn.swipe.directions.RIGHT} / {@link $.fn.swipe.directions.DOWN} / {@link $.fn.swipe.directions.UP}
     * @see $.fn.swipe.directions
     * @inner
     */
    function calculateDirection(startPoint, endPoint) {
      var angle = calculateAngle(startPoint, endPoint);

      if ((angle <= 45) && (angle >= 0)) {
        return LEFT;
      } else if ((angle <= 360) && (angle >= 315)) {
        return LEFT;
      } else if ((angle >= 135) && (angle <= 225)) {
        return RIGHT;
      } else if ((angle > 45) && (angle < 135)) {
        return DOWN;
      } else {
        return UP;
      }
    }


    /**
     * Returns a MS time stamp of the current time
     * @return int
     * @inner
     */
    function getTimeStamp() {
      var now = new Date();
      return now.getTime();
    }



    /**
     * Returns a bounds object with left, right, top and bottom properties for the element specified.
     * @param {DomNode} The DOM node to get the bounds for.
     */
    function getbounds(el) {
      el = $(el);
      var offset = el.offset();

      var bounds = {
        left: offset.left,
        right: offset.left + el.outerWidth(),
        top: offset.top,
        bottom: offset.top + el.outerHeight()
      }

      return bounds;
    }


    /**
     * Checks if the point object is in the bounds object.
     * @param {object} point A point object.
     * @param {int} point.x The x value of the point.
     * @param {int} point.y The x value of the point.
     * @param {object} bounds The bounds object to test
     * @param {int} bounds.left The leftmost value
     * @param {int} bounds.right The righttmost value
     * @param {int} bounds.top The topmost value
     * @param {int} bounds.bottom The bottommost value
     */
    function isInBounds(point, bounds) {
      return (point.x > bounds.left && point.x < bounds.right && point.y > bounds.top && point.y < bounds.bottom);
    };


  }




  /**
   * A catch all handler that is triggered for all swipe directions.
   * @name $.fn.swipe#swipe
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {int} direction The direction the user swiped in. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user swiped
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {object} fingerData The coordinates of fingers in event
   * @param {string} currentDirection The current direction the user is swiping.
   */




  /**
   * A handler that is triggered for "left" swipes.
   * @name $.fn.swipe#swipeLeft
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {int} direction The direction the user swiped in. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user swiped
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {object} fingerData The coordinates of fingers in event
   * @param {string} currentDirection The current direction the user is swiping.
   */

  /**
   * A handler that is triggered for "right" swipes.
   * @name $.fn.swipe#swipeRight
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {int} direction The direction the user swiped in. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user swiped
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {object} fingerData The coordinates of fingers in event
   * @param {string} currentDirection The current direction the user is swiping.
   */

  /**
   * A handler that is triggered for "up" swipes.
   * @name $.fn.swipe#swipeUp
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {int} direction The direction the user swiped in. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user swiped
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {object} fingerData The coordinates of fingers in event
   * @param {string} currentDirection The current direction the user is swiping.
   */

  /**
   * A handler that is triggered for "down" swipes.
   * @name $.fn.swipe#swipeDown
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {int} direction The direction the user swiped in. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user swiped
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {object} fingerData The coordinates of fingers in event
   * @param {string} currentDirection The current direction the user is swiping.
   */

  /**
   * A handler triggered for every phase of the swipe. This handler is constantly fired for the duration of the pinch.
   * This is triggered regardless of swipe thresholds.
   * @name $.fn.swipe#swipeStatus
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {string} phase The phase of the swipe event. See {@link $.fn.swipe.phases}
   * @param {string} direction The direction the user swiped in. This is null if the user has yet to move. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user swiped. This is 0 if the user has yet to move.
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {object} fingerData The coordinates of fingers in event
   * @param {string} currentDirection The current direction the user is swiping.
   */

  /**
   * A handler triggered for pinch in events.
   * @name $.fn.swipe#pinchIn
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {int} direction The direction the user pinched in. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user pinched
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {int} zoom The zoom/scale level the user pinched too, 0-1.
   * @param {object} fingerData The coordinates of fingers in event
   */

  /**
   * A handler triggered for pinch out events.
   * @name $.fn.swipe#pinchOut
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {int} direction The direction the user pinched in. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user pinched
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {int} zoom The zoom/scale level the user pinched too, 0-1.
   * @param {object} fingerData The coordinates of fingers in event
   */

  /**
   * A handler triggered for all pinch events. This handler is constantly fired for the duration of the pinch. This is triggered regardless of thresholds.
   * @name $.fn.swipe#pinchStatus
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {int} direction The direction the user pinched in. See {@link $.fn.swipe.directions}
   * @param {int} distance The distance the user pinched
   * @param {int} duration The duration of the swipe in milliseconds
   * @param {int} fingerCount The number of fingers used. See {@link $.fn.swipe.fingers}
   * @param {int} zoom The zoom/scale level the user pinched too, 0-1.
   * @param {object} fingerData The coordinates of fingers in event
   */

  /**
   * A click handler triggered when a user simply clicks, rather than swipes on an element.
   * This is deprecated since version 1.6.2, any assignment to click will be assigned to the tap handler.
   * You cannot use <code>on</code> to bind to this event as the default jQ <code>click</code> event will be triggered.
   * Use the <code>tap</code> event instead.
   * @name $.fn.swipe#click
   * @event
   * @deprecated since version 1.6.2, please use {@link $.fn.swipe#tap} instead
   * @default null
   * @param {EventObject} event The original event object
   * @param {DomObject} target The element clicked on.
   */

  /**
   * A click / tap handler triggered when a user simply clicks or taps, rather than swipes on an element.
   * @name $.fn.swipe#tap
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {DomObject} target The element clicked on.
   */

  /**
   * A double tap handler triggered when a user double clicks or taps on an element.
   * You can set the time delay for a double tap with the {@link $.fn.swipe.defaults#doubleTapThreshold} property.
   * Note: If you set both <code>doubleTap</code> and <code>tap</code> handlers, the <code>tap</code> event will be delayed by the <code>doubleTapThreshold</code>
   * as the script needs to check if its a double tap.
   * @name $.fn.swipe#doubleTap
   * @see  $.fn.swipe.defaults#doubleTapThreshold
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {DomObject} target The element clicked on.
   */

  /**
   * A long tap handler triggered once a tap has been release if the tap was longer than the longTapThreshold.
   * You can set the time delay for a long tap with the {@link $.fn.swipe.defaults#longTapThreshold} property.
   * @name $.fn.swipe#longTap
   * @see  $.fn.swipe.defaults#longTapThreshold
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {DomObject} target The element clicked on.
   */

  /**
   * A hold tap handler triggered as soon as the longTapThreshold is reached
   * You can set the time delay for a long tap with the {@link $.fn.swipe.defaults#longTapThreshold} property.
   * @name $.fn.swipe#hold
   * @see  $.fn.swipe.defaults#longTapThreshold
   * @event
   * @default null
   * @param {EventObject} event The original event object
   * @param {DomObject} target The element clicked on.
   */

}));



//images animées 

//$(document.getElementsByClassName("wbImgAnim")).each
$(window).on("load.wb.imganim trigger.wb.imganim.reload trigger.wb.postUpdateLayoutSuperposableEpingle.apparition",function(){

	this.jqIgmAnim = $(document.getElementsByClassName ? document.getElementsByClassName("wbImgAnim") : undefined).filter("[data-wbimganim]");//blindage IE8

	if (!this.jqIgmAnim.length)
	{
		return;
	}	

	//init les images
	this.jqIgmAnim.each(function(){
		var jqThis = $(this);
		//this.oAnimationPlancheImage = jqThis.wbJsonParseAttr("wbimganim");
		try
		{
			this.oAnimationPlancheImage = this.oAnimationPlancheImage||JSON.parse(jqThis.attr("data-wbimganim").replace(/'/g,'"'));
		}
		catch (e)
		{
			if (window["clWDUtil"]) 
			{
				!clWDUtil.WDDebug || clWDUtil.WDDebug.assert(false, "JSON incorrect");
			}		
			return;
		}

		if (!this.oAnimationPlancheImage)
		{
			return;
		}

		//cas optimisé ?
		// plache verticale en boucle
		if (this.oAnimationPlancheImage.x === 1 && this.oAnimationPlancheImage.n === 0)
		{
		    var oThis = this;
		    if (oThis.jqStyleOptim) oThis.jqStyleOptim.remove();
        	oThis.jqStyleOptim = $("<style class='"+jqThis[0].classList[1]+"'></style>");
        	oThis.jqImgAnim = $(jqThis[0].firstElementChild);
        	$("head").append(oThis.jqStyleOptim);
 			var fAppliqueMajKF = function()
	        {
	        	window.requestIdleCallback ? cancelIdleCallback(oThis.timerMajKF) : clearTimeout(oThis.timerMajKF);		        	
	        	oThis.timerMajKF=undefined;
		        var nHauteur = jqThis.outerHeight() * oThis.oAnimationPlancheImage.y;
	        	oThis.jqImgAnim.css("animation-play-state","");
	        	//mets à jour quand même le contenu car il a été vidé par fMajKF pour faire animation-play-state:paused sur le style CSS de base indiquant 100%
		        // if (oThis.nHauteurCouranteAnimation === nHauteur)
	        	// {
	        	// 	return;
	        	// }
	        	if (bIEAvec11 && oThis.jqImgAnim[0].src.substr(-3)==="svg")
        		{
        			//pour aider IE à donner la taille en hauteur des svg
        			oThis.jqImgAnim.css({height : nHauteur});	
        		}
	        	oThis.nHauteurCouranteAnimation = nHauteur;

	        	var sKeyFrames = "@keyframes " + jqThis[0].classList[1] + "{ from { transform:translateY(0); } to { transform:translateY(-" + oThis.nHauteurCouranteAnimation + "px); } }";
	        	oThis.jqStyleOptim.html(sKeyFrames);
                oThis.wbImgAnimDejaInit = oThis.clientHeight > 0;
        	};
			//permet d'être notifié en cas de resize d'un champ alors que le navigateur n'a pas été resize (cas d'un changement de plan)
			var fMajKF = function (oEvent, bOnScroll, bSynchrone)
		    {
		        if (bOnScroll)
		        {
		            return;
		        }		        
		        if (oThis.timerMajKF!==undefined)
		        {
		        	window.requestIdleCallback ? cancelIdleCallback(oThis.timerMajKF) : clearTimeout(oThis.timerMajKF);		        	
		        }
		        else 
		        {
                    // si le champ est ancré ou s'il n'a jamais été affiché correctement 
                    if (!oThis.classList.contains("wbImgAnimLargeurPourcentage") && oThis.wbImgAnimDejaInit) 
                    {
                        //débranche
                        fMajKF = function() {};
                        return;
                    }

		        	oThis.jqStyleOptim.html("");
		        	oThis.jqImgAnim.css("animation-play-state","paused");
		        }
		        oThis.timerMajKF = undefined;
		        if (bSynchrone)
		        {
					fAppliqueMajKF();
		        }
		        else 
		        {
		        	oThis.timerMajKF =(window.requestIdleCallback ? window.requestIdleCallback(fAppliqueMajKF) : setTimeout(fAppliqueMajKF,1000));		        
		        }
		    };			
            if (!this.wbImgAnimDejaEcoute)
            {
               this.wbImgAnimDejaEcoute   = true;
                    
    		    clWDUtil.AttacheOnScrollResize(fMajKF); 
    		    //mets à jour en affichage de popup
    		    $(window).on("trigger.wb.postUpdateLayoutSuperposableEpingle.apparition.imganim",function(oEvent,domBalise)
    		    {
    		    	if (!domBalise || clWDUtil.bEstFils(oThis, domBalise))
    		    	{
    		    		fMajKF(oEvent,false,true);
    		    	}
    		    });
            }
		    //1er appel 
		    fMajKF(true);
		}
	});

});

//en cas de mise à jour de html par ajax
if (window["clWDUtil"]!==undefined) 
{
	if (clWDUtil.m_oNotificationsAjoutHTML)
	{
		clWDUtil.m_oNotificationsAjoutHTML.AddNotification(function(){$(window).trigger("trigger.wb.imganim.reload"); });
	}
	if (clWDUtil.m_oNotificationsFinAJAX)
	{
		clWDUtil.m_oNotificationsFinAJAX.AddNotification(function(){ $(window).trigger("trigger.wb.imganim.reload"); });
	}
}


function eIMG_MODE() { }
eIMG_MODE.imgModeMini					=(eIMG_MODE.i=0); 
eIMG_MODE.imgNormal						=++eIMG_MODE.i;				//affichage en 100%, offset personnalisé
eIMG_MODE.imgCentre						=++eIMG_MODE.i;				//affichage en 100%, centré
eIMG_MODE.imgEtire						=++eIMG_MODE.i;				//affichage étiré du rectangle d'origine pour occuper toute la zone de destination
eIMG_MODE.imgRepete						=++eIMG_MODE.i;				//affichage répété du rectangle d'origine pour occuper toute la zone toute la zone de destination
eIMG_MODE.imgHomothetique				=++eIMG_MODE.i;				//affichage etiré homothétique du rectangle d'origine pour occuper au mieux la zone de destination
eIMG_MODE.imgHomothetiqueCentre			=++eIMG_MODE.i;				//idem homothétique mais centré
eIMG_MODE.imgHomothetiqueLarge			=++eIMG_MODE.i;				//idem homothétique, mais garde la plus petite proportion au lieu de la plus grande
eIMG_MODE.imgHomothetiqueCentreLarge	=++eIMG_MODE.i;				//idem homothétique centré, mais garde la plus petite proportion au lieu de la plus grande
eIMG_MODE.imgAdapte						=++eIMG_MODE.i;				//affichage en 100% s'il y a la place, Homothétique sinon
eIMG_MODE.imgAdapteCentre				=++eIMG_MODE.i;				//comme le précédent mais centré
//11
eIMG_MODE.IMG_MODE_NAVIGATEUR_MINI_INCLUS = 
eIMG_MODE.imgNavigateurHomothetiqueLargeur 						=++eIMG_MODE.i;		//le navigateur effectue une homothétie selon la largeur et pousse la hauteur du champ (la largeur peut être fixe ou ancrée au navigateur, la hauteur est ancrée au contenu)
eIMG_MODE.imgNavigateurAdapteLargeur 							=++eIMG_MODE.i;		//le navigateur adapte la largeur (100% s'il y a la place, homothétique sinon) et pousse la hauteur du champ (la hauteur et la largeur sont ancrées au contenu)
eIMG_MODE.imgNavigateurHomothetiqueLargeurDebordementHauteur	=++eIMG_MODE.i;		//le navigateur effectue une homothétie selon la largeur et tronque selon la hauteur du champ (la largeur et hauteur peuvent être fixes ou ancrées au navigateur)
eIMG_MODE.imgNavigateurAdapteLargeurDebordementHauteur			=++eIMG_MODE.i;		//le navigateur adapte la largeur (100% s'il y a la place, homothétique sinon) et tronque selon la hauteur du champ (la largeur est au contenu, la hauteur peut être fixe ou ancrée au navigateur)
//modes homothétiques navigateur complet (WX23)
//15
eIMG_MODE.imgNavigateurCentre 					=++eIMG_MODE.i;		//affichage en 100%, centré
eIMG_MODE.imgNavigateurHomothetique				=++eIMG_MODE.i;		//affichage etiré homothétique du rectangle d'origine pour occuper au mieux la zone de destination
eIMG_MODE.imgNavigateurHomothetiqueCentre		=++eIMG_MODE.i;		//idem homothétique mais centré
eIMG_MODE.imgNavigateurHomothetiqueLarge		=++eIMG_MODE.i;		//idem homothétique, mais garde la plus petite proportion au lieu de la plus grande
eIMG_MODE.imgNavigateurHomothetiqueCentreLarge	=++eIMG_MODE.i;		//idem homothétique centré, mais garde la plus petite proportion au lieu de la plus grande
eIMG_MODE.imgNavigateurAdapte					=++eIMG_MODE.i;		//affichage en 100% s'il y a la place, Homothétique sinon
eIMG_MODE.imgNavigateurAdapteCentre				=++eIMG_MODE.i;		//comme le précédent mais centré
//22
eIMG_MODE.imgNavigateurAdapteLargeCentre		=++eIMG_MODE.i;
eIMG_MODE.imgAdapteLargeCentre					=++eIMG_MODE.i;

//Lecture Orientation EXIF
function getOrientation(file, callback) {
    if (!window.fetch/*pas dispo sous IE11*/ || !window.FileReader/*IE 10+*/ || !window.DataView/*IE 10+*/)
       {
           callback(1,undefined);
           return;
       }

    var reader = new FileReader();
    try{
        fetch(file )
        .then(function(response) {
            return response.blob();
        }).then(function(myBlob) {
            //var objectURL = URL.createObjectURL(myBlob);
            reader.onload = function(e) {

                var view = new DataView(e.target.result);
                if (view.getUint16(0, false) != 0xFFD8)
                {
                    return callback(-2,myBlob);
                }
                var length = view.byteLength, offset = 2;
                while (offset < length) 
                {
                    if (view.getUint16(offset+2, false) <= 8) return callback(-1,myBlob);
                    var marker = view.getUint16(offset, false);
                    offset += 2;
                    if (marker == 0xFFE1) 
                    {
                        if (view.getUint32(offset += 2, false) != 0x45786966) 
                        {
                            return callback(-1,myBlob);
                        }

                        var little = view.getUint16(offset += 6, false) == 0x4949;
                        offset += view.getUint32(offset + 4, little);
                        var tags = view.getUint16(offset, little);
                        offset += 2;
                        for (var i = 0; i < tags; i++)
                        {
                            if (view.getUint16(offset + (i * 12), little) == 0x0112)
                            {
                                return callback(view.getUint16(offset + (i * 12) + 8, little),myBlob);
                            }
                        }
                    }
                    else if ((marker & 0xFF00) != 0xFF00)
                    {
                        break;
                    }
                    else
                    { 
                        offset += view.getUint16(offset, false);
                    }
                }
                return callback(-1,myBlob);
            };
            reader.readAsArrayBuffer(myBlob);
        });
    }
    catch (e) {//cas du CORS
        callback(1,undefined);
    }      
}
//mode homothétique d'image 
function wbImgHomNav(domBaliseImg,eMode,bAvecLectureOrientationExif)
{

	if (!domBaliseImg.parentNode) return;//blindage du onload du clone
	//console.log(domBaliseImg,"wbImgHomNav");
	if (nIE!=0 && nIE<9) return;//blindage IE8

	//if (domBaliseImg.src == imgVide) return;//blindage img vide 

	var jqMonImg = $(domBaliseImg);
	//en rwd, attend le changement de tranche initial
 	if (jqMonImg.attr("data-media") && !jqMonImg.data("attrSrcOri"))
 	{
 		//NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(function(){wbImgHomNav(domBaliseImg,eMode);});
 		jqMonImg.data('wbOnRemoveDataMedia',function(){wbImgHomNav(domBaliseImg,eMode);});
    	return;
 	}
	var jqMonParent = jqMonImg.parent();//div .wbHnImg
 	var domBaliseParent = jqMonParent[0];
 	domBaliseParent.wbModeAffichage = eMode;

	//lors du premier affichage 
	if (!domBaliseParent.bPremierAffichageDejaFait)
	{
		//il faut migrer certaines propriétés vers le parent 
		//pour le style etc...
		var tabAttributes = jqMonImg.prop("attributes");
		$(tabAttributes).each(function()
		{
			//on laisse onload et le src n'a pas de sens 
			var sNomAttr = this.name.toLowerCase();
			var valeur = this.value;

			//à conserver
			//ne prend pas les data-media de l'img, car les data- seront mis  jour en changement de tranche dans l'img
			if (sNomAttr==="src" || sNomAttr==="alt" || sNomAttr==="title" || sNomAttr==="onload" || sNomAttr.indexOf("data-")===0)
			{
				return;
			}

			//à transférer
			//	
			//concat les classes et styles (pour garder le opacity:0 initial)
			if (sNomAttr==="class")
			{
				valeur+=" "+jqMonParent.attr("class");
			}
			//concat les classes et styles (pour garder le opacity:0 initial)
			if (sNomAttr==="style")
			{
				valeur+=";"+jqMonParent.attr("style");
			}			
			//déplace l'attribut sur le parent
			jqMonParent.attr(this.name,valeur);
			jqMonImg.removeAttr(this.name);
		});

		//interdit le <i> d'être le référant d'un autre champ, on laisse ça sur le <img> car il a les data (et il a les data car jusqu'au bout on ne sait pas si on est sous IE<9 ou pas)
		if (jqMonParent.hasClass("ancragesupref"))
		{
			jqMonParent.removeClass("ancragesupref");
			jqMonImg.addClass("ancragesupref");
		}

		//l'image doit prendre toute la place 
		//note : la taille de l'img pouvait venir du style ou d'un css à part
		jqMonImg.css({width : '100%', height : '100%'});
		domBaliseParent.bPremierAffichageDejaFait=true;
	}

	//arrête le resize de l'image car elle a changé
	$(window).off("resize.wb.img.homothetique.adapte." + domBaliseParent.id );
	jqMonParent.off("trigger.wb.img.homothetique.adapte");

	function appliqueHomothetie(nLargeurImg,nHauteurImg,bContain,bCover)
	{
        //passe l'image en fond du parent
        var sSourceImage = domBaliseImg.src;
        //debug des RCs dans un data URI base64
        if (sSourceImage.substr(0,"data:".length) === "data:")
        {
            sSourceImage=sSourceImage.replace(/[\n\r]/g,'');
        }

        var fHomothetieSelonOrientation = function(orientation,blob) 
        {

        var oCss = {};
        //raz
        oCss["background-size"] = "";
        oCss["background-position"] = "";
        oCss["background-repeat"] = "no-repeat";    

        oCss["background-image"] = "url('" + sSourceImage  + "')";    

        //https://stackoverflow.com/questions/19463126/how-to-draw-photo-with-correct-orientation-in-canvas-after-capture-photo-by-usin
        if (orientation>1)
       {
           oCss["image-orientation"] = "none";   
            var can = document.createElement("canvas");
            var ctx = can.getContext('2d');

            can.style.width = can.width = nLargeurImg;
            can.style.height = can.height = nHauteurImg;

            ctx.save();

            if (orientation > 4)
            {
                can.width  = nHauteurImg; can.style.width  = nHauteurImg;
                can.height = nLargeurImg;  can.style.height = nLargeurImg;
            }

            switch(orientation)
            {
                default:
                case 1: 
                    // déjà ok
                    break;
                case 2:
                    // horizontal flip
                    ctx.translate(can.width, 0);
                    ctx.scale(-1, 1);
                    break;
                case 3:
                    // 180° rotate left
                    ctx.translate(can.width, can.height);
                    ctx.rotate(Math.PI);
                    break;
                case 4:
                    // vertical flip
                    ctx.translate(0, can.height);
                    ctx.scale(1, -1);
                    break;
                case 5:
                    // vertical flip + 90 rotate right
                    ctx.rotate(0.5 * Math.PI);
                    ctx.scale(1, -1);
                    break;
                case 6:
                    // 90° rotate right
                    ctx.rotate(0.5 * Math.PI);
                    ctx.translate(0, -can.width);
                    break;
                case 7:
                    // horizontal flip + 90 rotate right
                    ctx.rotate(0.5 * Math.PI);
                    ctx.translate(can.height, -can.width);
                    ctx.scale(-1, 1);
                    break;
                case 8:
                    // 90° rotate left
                    ctx.rotate(-0.5 * Math.PI);
                    ctx.translate(-can.height, 0);
                    break;
            }
         
            ctx.drawImage(domBaliseImg, 0, 0);
            ctx.restore();
            var dataURL = can.toDataURL();    
            oCss["background-image"] = "url('" + dataURL  + "')";                    
       }
       
       //applique l'homothétie
        var bEstChpRefGalerieColonne = (jqMonImg.hasClass("wbGalerieChpRef") || jqMonParent.hasClass("wbGalerieChpRef")) && jqMonParent.closest(".wbGalerie").hasClass("wbGalerieColonne");
        var bSansAgrandissement = false;
        switch(eMode)
        {            
            case eIMG_MODE.imgNavigateurCentre:
                //100% centré
                //background-size:PX PX
                //background-position:center center
                oCss["background-size"] = nLargeurImg + "px "+nHauteurImg+"px";
                oCss["background-position"] = "center center";
                bSansAgrandissement=true;
                break;
                
            case eIMG_MODE.imgRepete:
                //
                //Répété
                //background-repeat:repeat        
                oCss["background-repeat"] = "repeat";        
                break;
                
            case eIMG_MODE.imgNavigateurHomothetique:
                //
                //Homothétique
                //background-size:contain
                oCss["background-size"] = "contain";                
                break;
                
            case eIMG_MODE.imgNavigateurHomothetiqueLarge:
                //
                //Homothétique étendu
                //background-size:cover
                oCss["background-size"] = "cover";
                break;    
                
            case eIMG_MODE.imgNavigateurHomothetiqueCentre    :
                //
                //Homothétique centré
                //background-size:contain
                //background-position:center center
                oCss["background-size"] = "contain";    
                oCss["background-position"] = "center center";            
                break;
                
            case eIMG_MODE.imgNavigateurHomothetiqueCentreLarge:            
                //
                //Homothétique étendu
                //background-size:cover
                //background-position:center center
                oCss["background-size"] = "cover";    
                oCss["background-position"] = "center center";            
                break;
                
            case eIMG_MODE.imgNavigateurAdapte:        
                //
                //Homothétique sans agrandissement
                //background-size:PX PX
                oCss["background-size"] = bContain ? "contain" : (nLargeurImg + "px "+nHauteurImg+"px") ;                    
                bSansAgrandissement=true;
                break;
                
            case eIMG_MODE.imgNavigateurAdapteCentre:
                //Homothétique centré sans agrandissement
                //background-size:PX PX
                //background-position:centré centré
                oCss["background-size"] = bContain ? "contain" : (nLargeurImg + "px "+nHauteurImg+"px");
                oCss["background-position"] = "center center";            
                bSansAgrandissement=true;
                break;    

            case eIMG_MODE.imgNavigateurAdapteLargeCentre:
                oCss["background-size"] = bCover ? "cover" : (nLargeurImg + "px "+nHauteurImg+"px");
                oCss["background-position"] = "center center";                            
                bSansAgrandissement=true;
                break;        
                
            default:
                //TODO?
                //eIMG_MODE.imgNavigateurNormal                                
                //eIMG_MODE.imgNavigateurEtire                            
        }    
        if (bSansAgrandissement && bEstChpRefGalerieColonne)
        {
            jqMonImg.css({maxHeight : nHauteurImg});
        }
    
        jqMonParent.css(oCss);

       };

        if (bAvecLectureOrientationExif)
            getOrientation(sSourceImage, fHomothetieSelonOrientation);
        else 
            fHomothetieSelonOrientation(1,undefined);       

    }

	//dimension de l'image selon la source et le navigateur pour les modes sans agrandissement
	var nLargeurImg = jqMonImg[0].naturalWidth;//pas .width car le champ peut avoir un width:px
	var nHauteurImg = jqMonImg[0].naturalHeight;//pas .height car le champ peut avoir un height:px
	if (eMode == eIMG_MODE.imgNavigateurCentre || eMode >= eIMG_MODE.imgNavigateurAdapte )//sans agrandissement
	{
		//doit on forcément le placer dans la page pour ocnnaître sa taille?
		if (nHauteurImg==0)
		{
    		//lit les dimensions de l'image 
    		var jqMonClone = jqMonImg.clone(false).attr("onload","");//sans events ni data + //retire les onload inline
    		var domMonClone = jqMonClone.get(0);
            //utilité du clone : mettre des dimension en auto pour lire les dimensions naturelles de l'image source
    		jqMonClone.css({width : 'auto', height : 'auto'});
			jqMonClone.css({visibility : 'hidden', position : 'fixed'});//invisible
			document.body.appendChild(domMonClone);
			nLargeurImg = domMonClone.naturalWidth||domMonClone.width;
			nHauteurImg = domMonClone.naturalHeight||domMonClone.height;
			document.body.removeChild(domMonClone);
		}

		var dRatio = nHauteurImg==0 ? 1 : nLargeurImg / nHauteurImg;

		jqMonImg[0].onRecalculHomothetie = function()
		{

			if (domBaliseParent.bPremierRecalculHomothetieDejaFait || !jqMonImg[0].nLargeurInitiale)
			{				
				var nLargeurChamp = jqMonImg.width();
				//le parent est plus grand s'il y a un min-height sur le champ image
				//ou s'il y a un max-height sur img à cause du sans agrandissement
				var bEstBaliseDOM = jqMonParent.length && jqMonParent[0].nodeType === 1;
				!clWDUtil.WDDebug || clWDUtil.WDDebug.assert(bEstBaliseDOM);				
				var nHauteurChamp = Math.max(jqMonImg.height(),(bEstBaliseDOM ? jqMonParent.height() : 0));
			}
			else 
			{
				var nLargeurChamp = jqMonImg[0].nLargeurInitiale;
				var nHauteurChamp = jqMonImg[0].nHauteurInitiale;
			}

			domBaliseParent.bPremierRecalculHomothetieDejaFait=true;

			var nLargeurImgCalcul = nLargeurImg;
			var nHauteurImgCalcul = nHauteurImg;


			var bContain = false;
			var bCover = false;

			//méthode plus sûre de comparaison?
			//var bSrcPlusGrandeQueChamp=(nHauteurChamp < nHauteurImg) && (nLargeurChamp < nLargeurImg);

			if(nLargeurImg>nHauteurImg)
			{
				//paysage
				if(nLargeurChamp < nLargeurImg)
				{
					bContain=true;
				}				
			}
			else
			{
				//portrait
				if(nHauteurChamp < nHauteurImg)
				{
					bContain=true;
				}
			}

			if (nHauteurImg>nHauteurChamp && nLargeurImg>nLargeurChamp)
			{
				bCover=true;
			}

			//applique l'homothétie immédiatement pour un chargement issu de chargement différé
			function fAppliqueHomothetie(){ appliqueHomothetie(nLargeurImgCalcul,nHauteurImgCalcul,bContain,bCover);}
			jqMonImg[0].loaded ? fAppliqueHomothetie() : requestAnimationFrame(fAppliqueHomothetie);
		};
		//1er appel
		jqMonImg[0].onRecalculHomothetie();//fera le appliqueHomothetie
		//et le refait à chaque resize
		$(window).on("resize.wb.img.homothetique.adapte." + domBaliseParent.id ,jqMonImg[0].onRecalculHomothetie);
		jqMonParent.on("trigger.wb.img.homothetique.adapte" ,jqMonImg[0].onRecalculHomothetie);
	}
	else 
	{
		appliqueHomothetie(nLargeurImg,nHauteurImg);
	}

	//rend visible l'image
	jqMonParent.css("opacity",1);
}

//cas de onload avant le parsing de la fonction
$(function(){
	if (!window['wbImgHomNav_DejaLoaded'])
	{
		return;
	}
	//prépare toutes les dimensions de champs pour éviter les layout intermédiaires
	for(var i =0; i<window['wbImgHomNav_DejaLoaded'].length; ++i)
	{
		var jqMonImg = $(window['wbImgHomNav_DejaLoaded'][i][0]);
		jqMonImg[0].nLargeurInitiale  = jqMonImg.width();
		//le parent est plus grand s'il y a un min-height sur le champ image
		//ou s'il y a un max-height sur img à cause du sans agrandissement
		jqMonImg[0].nHauteurInitiale = Math.max(jqMonImg.height(),jqMonImg.parent().height());
	}

	var fNow = function() { return (window.performance&&window.performance.now) ? window.performance.now() : new Date(); };
	var dateInit = fNow();
	var tempsMaxMs = 100;
	function rafImgHomNav()
	{
		var img = window['wbImgHomNav_DejaLoaded'] ? window['wbImgHomNav_DejaLoaded'].shift() : undefined;
		if (!img)
		{
			window['wbImgHomNav_DejaLoaded']=undefined;
			return;
		}
		wbImgHomNav(img[0],img[1],img[2]);
		if (fNow() - dateInit>tempsMaxMs)
		{
			dateInit = fNow();
			requestAnimationFrame(rafImgHomNav);
		}
		else 
		{
			rafImgHomNav();
		}
	}
	requestAnimationFrame(rafImgHomNav);
});

/*!
 * Masonry PACKAGED v3.3.2
 * Cascading grid layout library
 * http://masonry.desandro.com
 * MIT License
 * by David DeSandro
 */

/**
 * Bridget makes jQuery widgets
 * v1.1.0
 * MIT license
 */

if (!bIEQuirks) ( function( window ) {



// -------------------------- utils -------------------------- //

var slice = Array.prototype.slice;

function noop() {}

// -------------------------- definition -------------------------- //

function defineBridget( $ ) {

// bail if no jQuery
if ( !$ ) {
  return;
}

// -------------------------- addOptionMethod -------------------------- //

/**
 * adds option method -> $().plugin('option', {...})
 * @param {Function} PluginClass - constructor class
 */
function addOptionMethod( PluginClass ) {
  // don't overwrite original option method
  if ( PluginClass.prototype.option ) {
    return;
  }

  // option setter
  PluginClass.prototype.option = function( opts ) {
    // bail out if not an object
    if ( !$.isPlainObject( opts ) ){
      return;
    }
    this.options = $.extend( true, this.options, opts );
  };
}

// -------------------------- plugin bridge -------------------------- //

// helper function for logging errors
// $.error breaks jQuery chaining
var logError = typeof console === 'undefined' ? noop :
  function( message ) {
    console.error( message );
  };

/**
 * jQuery plugin bridge, access methods like $elem.plugin('method')
 * @param {String} namespace - plugin name
 * @param {Function} PluginClass - constructor class
 */
function bridge( namespace, PluginClass ) {
  // add to jQuery fn namespace
  $.fn[ namespace ] = function( options ) {
    if ( typeof options === 'string' ) {
      // call plugin method when first argument is a string
      // get arguments for method
      var args = slice.call( arguments, 1 );

      for ( var i=0, len = this.length; i < len; i++ ) {
        var elem = this[i];
        var instance = $.data( elem, namespace );
        if ( !instance ) {
          logError( "cannot call methods on " + namespace + " prior to initialization; " +
            "attempted to call '" + options + "'" );
          continue;
        }
        if ( !$.isFunction( instance[options] ) || options.charAt(0) === '_' ) {
          logError( "no such method '" + options + "' for " + namespace + " instance" );
          continue;
        }

        // trigger method with arguments
        var returnValue = instance[ options ].apply( instance, args );

        // break look and return first value if provided
        if ( returnValue !== undefined ) {
          return returnValue;
        }
      }
      // return this if no return value
      return this;
    } else {
      return this.each( function() {
        var instance = $.data( this, namespace );
        if ( instance ) {
          // apply options & init
          instance.option( options );
          instance._init();
        } else {
          // initialize new instance
          instance = new PluginClass( this, options );
          $.data( this, namespace, instance );
        }
      });
    }
  };

}

// -------------------------- bridget -------------------------- //

/**
 * converts a Prototypical class into a proper jQuery plugin
 *   the class must have a ._init method
 * @param {String} namespace - plugin name, used in $().pluginName
 * @param {Function} PluginClass - constructor class
 */
$.bridget = function( namespace, PluginClass ) {
  addOptionMethod( PluginClass );
  bridge( namespace, PluginClass );
};

return $.bridget;

}

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'jquery-bridget/jquery.bridget',[ 'jquery' ], defineBridget );
} else if ( typeof exports === 'object' ) {
  defineBridget( require('jquery') );
} else {
  // get jquery from browser global
  defineBridget( window.jQuery );
}

})( window );

/*!
 * eventie v1.0.6
 * event binding helper
 *   eventie.bind( elem, 'click', myFn )
 *   eventie.unbind( elem, 'click', myFn )
 * MIT license
 */

/*jshint browser: true, undef: true, unused: true */
/*global define: false, module: false */

( function( window ) {



var docElem = document.documentElement;

var bind = function() {};

function getIEEvent( obj ) {
  var event = window.event;
  // add event.target
  event.target = event.target || event.srcElement || obj;
  return event;
}

if ( docElem.addEventListener ) {
  bind = function( obj, type, fn ) {
    obj.addEventListener( type, fn, false );
  };
} else if ( docElem.attachEvent ) {
  bind = function( obj, type, fn ) {
    obj[ type + fn ] = fn.handleEvent ?
      function() {
        var event = getIEEvent( obj );
        fn.handleEvent.call( fn, event );
      } :
      function() {
        var event = getIEEvent( obj );
        fn.call( obj, event );
      };
    obj.attachEvent( "on" + type, obj[ type + fn ] );
  };
}

var unbind = function() {};

if ( docElem.removeEventListener ) {
  unbind = function( obj, type, fn ) {
    obj.removeEventListener( type, fn, false );
  };
} else if ( docElem.detachEvent ) {
  unbind = function( obj, type, fn ) {
    obj.detachEvent( "on" + type, obj[ type + fn ] );
    try {
      delete obj[ type + fn ];
    } catch ( err ) {
      // can't delete window object properties
      obj[ type + fn ] = undefined;
    }
  };
}

var eventie = {
  bind: bind,
  unbind: unbind
};

// ----- module definition ----- //

if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'eventie/eventie',eventie );
} else if ( typeof exports === 'object' ) {
  // CommonJS
  module.exports = eventie;
} else {
  // browser global
  window.eventie = eventie;
}

})( window );

/*!
 * EventEmitter v4.2.11 - git.io/ee
 * Unlicense - http://unlicense.org/
 * Oliver Caldwell - http://oli.me.uk/
 * @preserve
 */

;(function () {
    

    /**
     * Class for managing events.
     * Can be extended to provide event functionality in other classes.
     *
     * @class EventEmitter Manages event registering and emitting.
     */
    function EventEmitter() {}

    // Shortcuts to improve speed and size
    var proto = EventEmitter.prototype;
    var exports = this;
    var originalGlobalValue = exports.EventEmitter;

    /**
     * Finds the index of the listener for the event in its storage array.
     *
     * @param {Function[]} listeners Array of listeners to search through.
     * @param {Function} listener Method to look for.
     * @return {Number} Index of the specified listener, -1 if not found
     * @api private
     */
    function indexOfListener(listeners, listener) {
        var i = listeners.length;
        while (i--) {
            if (listeners[i].listener === listener) {
                return i;
            }
        }

        return -1;
    }

    /**
     * Alias a method while keeping the context correct, to allow for overwriting of target method.
     *
     * @param {String} name The name of the target method.
     * @return {Function} The aliased method
     * @api private
     */
    function alias(name) {
        return function aliasClosure() {
            return this[name].apply(this, arguments);
        };
    }

    /**
     * Returns the listener array for the specified event.
     * Will initialise the event object and listener arrays if required.
     * Will return an object if you use a regex search. The object contains keys for each matched event. So /ba[rz]/ might return an object containing bar and baz. But only if you have either defined them with defineEvent or added some listeners to them.
     * Each property in the object response is an array of listener functions.
     *
     * @param {String|RegExp} evt Name of the event to return the listeners from.
     * @return {Function[]|Object} All listener functions for the event.
     */
    proto.getListeners = function getListeners(evt) {
        var events = this._getEvents();
        var response;
        var key;

        // Return a concatenated array of all matching events if
        // the selector is a regular expression.
        if (evt instanceof RegExp) {
            response = {};
            for (key in events) {
                if (events.hasOwnProperty(key) && evt.test(key)) {
                    response[key] = events[key];
                }
            }
        }
        else {
            response = events[evt] || (events[evt] = []);
        }

        return response;
    };

    /**
     * Takes a list of listener objects and flattens it into a list of listener functions.
     *
     * @param {Object[]} listeners Raw listener objects.
     * @return {Function[]} Just the listener functions.
     */
    proto.flattenListeners = function flattenListeners(listeners) {
        var flatListeners = [];
        var i;

        for (i = 0; i < listeners.length; i += 1) {
            flatListeners.push(listeners[i].listener);
        }

        return flatListeners;
    };

    /**
     * Fetches the requested listeners via getListeners but will always return the results inside an object. This is mainly for internal use but others may find it useful.
     *
     * @param {String|RegExp} evt Name of the event to return the listeners from.
     * @return {Object} All listener functions for an event in an object.
     */
    proto.getListenersAsObject = function getListenersAsObject(evt) {
        var listeners = this.getListeners(evt);
        var response;

        if (listeners instanceof Array) {
            response = {};
            response[evt] = listeners;
        }

        return response || listeners;
    };

    /**
     * Adds a listener function to the specified event.
     * The listener will not be added if it is a duplicate.
     * If the listener returns true then it will be removed after it is called.
     * If you pass a regular expression as the event name then the listener will be added to all events that match it.
     *
     * @param {String|RegExp} evt Name of the event to attach the listener to.
     * @param {Function} listener Method to be called when the event is emitted. If the function returns true then it will be removed after calling.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.addListener = function addListener(evt, listener) {
        var listeners = this.getListenersAsObject(evt);
        var listenerIsWrapped = typeof listener === 'object';
        var key;

        for (key in listeners) {
            if (listeners.hasOwnProperty(key) && indexOfListener(listeners[key], listener) === -1) {
                listeners[key].push(listenerIsWrapped ? listener : {
                    listener: listener,
                    once: false
                });
            }
        }

        return this;
    };

    /**
     * Alias of addListener
     */
    proto.on = alias('addListener');

    /**
     * Semi-alias of addListener. It will add a listener that will be
     * automatically removed after its first execution.
     *
     * @param {String|RegExp} evt Name of the event to attach the listener to.
     * @param {Function} listener Method to be called when the event is emitted. If the function returns true then it will be removed after calling.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.addOnceListener = function addOnceListener(evt, listener) {
        return this.addListener(evt, {
            listener: listener,
            once: true
        });
    };

    /**
     * Alias of addOnceListener.
     */
    proto.once = alias('addOnceListener');

    /**
     * Defines an event name. This is required if you want to use a regex to add a listener to multiple events at once. If you don't do this then how do you expect it to know what event to add to? Should it just add to every possible match for a regex? No. That is scary and bad.
     * You need to tell it what event names should be matched by a regex.
     *
     * @param {String} evt Name of the event to create.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.defineEvent = function defineEvent(evt) {
        this.getListeners(evt);
        return this;
    };

    /**
     * Uses defineEvent to define multiple events.
     *
     * @param {String[]} evts An array of event names to define.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.defineEvents = function defineEvents(evts) {
        for (var i = 0; i < evts.length; i += 1) {
            this.defineEvent(evts[i]);
        }
        return this;
    };

    /**
     * Removes a listener function from the specified event.
     * When passed a regular expression as the event name, it will remove the listener from all events that match it.
     *
     * @param {String|RegExp} evt Name of the event to remove the listener from.
     * @param {Function} listener Method to remove from the event.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.removeListener = function removeListener(evt, listener) {
        var listeners = this.getListenersAsObject(evt);
        var index;
        var key;

        for (key in listeners) {
            if (listeners.hasOwnProperty(key)) {
                index = indexOfListener(listeners[key], listener);

                if (index !== -1) {
                    listeners[key].splice(index, 1);
                }
            }
        }

        return this;
    };

    /**
     * Alias of removeListener
     */
    proto.off = alias('removeListener');

    /**
     * Adds listeners in bulk using the manipulateListeners method.
     * If you pass an object as the second argument you can add to multiple events at once. The object should contain key value pairs of events and listeners or listener arrays. You can also pass it an event name and an array of listeners to be added.
     * You can also pass it a regular expression to add the array of listeners to all events that match it.
     * Yeah, this function does quite a bit. That's probably a bad thing.
     *
     * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to add to multiple events at once.
     * @param {Function[]} [listeners] An optional array of listener functions to add.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.addListeners = function addListeners(evt, listeners) {
        // Pass through to manipulateListeners
        return this.manipulateListeners(false, evt, listeners);
    };

    /**
     * Removes listeners in bulk using the manipulateListeners method.
     * If you pass an object as the second argument you can remove from multiple events at once. The object should contain key value pairs of events and listeners or listener arrays.
     * You can also pass it an event name and an array of listeners to be removed.
     * You can also pass it a regular expression to remove the listeners from all events that match it.
     *
     * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to remove from multiple events at once.
     * @param {Function[]} [listeners] An optional array of listener functions to remove.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.removeListeners = function removeListeners(evt, listeners) {
        // Pass through to manipulateListeners
        return this.manipulateListeners(true, evt, listeners);
    };

    /**
     * Edits listeners in bulk. The addListeners and removeListeners methods both use this to do their job. You should really use those instead, this is a little lower level.
     * The first argument will determine if the listeners are removed (true) or added (false).
     * If you pass an object as the second argument you can add/remove from multiple events at once. The object should contain key value pairs of events and listeners or listener arrays.
     * You can also pass it an event name and an array of listeners to be added/removed.
     * You can also pass it a regular expression to manipulate the listeners of all events that match it.
     *
     * @param {Boolean} remove True if you want to remove listeners, false if you want to add.
     * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to add/remove from multiple events at once.
     * @param {Function[]} [listeners] An optional array of listener functions to add/remove.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.manipulateListeners = function manipulateListeners(remove, evt, listeners) {
        var i;
        var value;
        var single = remove ? this.removeListener : this.addListener;
        var multiple = remove ? this.removeListeners : this.addListeners;

        // If evt is an object then pass each of its properties to this method
        if (typeof evt === 'object' && !(evt instanceof RegExp)) {
            for (i in evt) {
                if (evt.hasOwnProperty(i) && (value = evt[i])) {
                    // Pass the single listener straight through to the singular method
                    if (typeof value === 'function') {
                        single.call(this, i, value);
                    }
                    else {
                        // Otherwise pass back to the multiple function
                        multiple.call(this, i, value);
                    }
                }
            }
        }
        else {
            // So evt must be a string
            // And listeners must be an array of listeners
            // Loop over it and pass each one to the multiple method
            i = listeners.length;
            while (i--) {
                single.call(this, evt, listeners[i]);
            }
        }

        return this;
    };

    /**
     * Removes all listeners from a specified event.
     * If you do not specify an event then all listeners will be removed.
     * That means every event will be emptied.
     * You can also pass a regex to remove all events that match it.
     *
     * @param {String|RegExp} [evt] Optional name of the event to remove all listeners for. Will remove from every event if not passed.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.removeEvent = function removeEvent(evt) {
        var type = typeof evt;
        var events = this._getEvents();
        var key;

        // Remove different things depending on the state of evt
        if (type === 'string') {
            // Remove all listeners for the specified event
            delete events[evt];
        }
        else if (evt instanceof RegExp) {
            // Remove all events matching the regex.
            for (key in events) {
                if (events.hasOwnProperty(key) && evt.test(key)) {
                    delete events[key];
                }
            }
        }
        else {
            // Remove all listeners in all events
            delete this._events;
        }

        return this;
    };

    /**
     * Alias of removeEvent.
     *
     * Added to mirror the node API.
     */
    proto.removeAllListeners = alias('removeEvent');

    /**
     * Emits an event of your choice.
     * When emitted, every listener attached to that event will be executed.
     * If you pass the optional argument array then those arguments will be passed to every listener upon execution.
     * Because it uses `apply`, your array of arguments will be passed as if you wrote them out separately.
     * So they will not arrive within the array on the other side, they will be separate.
     * You can also pass a regular expression to emit to all events that match it.
     *
     * @param {String|RegExp} evt Name of the event to emit and execute listeners for.
     * @param {Array} [args] Optional array of arguments to be passed to each listener.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.emitEvent = function emitEvent(evt, args) {
        var listeners = this.getListenersAsObject(evt);
        var listener;
        var i;
        var key;
        var response;

        for (key in listeners) {
            if (listeners.hasOwnProperty(key)) {
                i = listeners[key].length;

                while (i--) {
                    // If the listener returns true then it shall be removed from the event
                    // The function is executed either with a basic call or an apply if there is an args array
                    listener = listeners[key][i];

                    if (listener.once === true) {
                        this.removeListener(evt, listener.listener);
                    }

                    response = listener.listener.apply(this, args || []);

                    if (response === this._getOnceReturnValue()) {
                        this.removeListener(evt, listener.listener);
                    }
                }
            }
        }

        return this;
    };

    /**
     * Alias of emitEvent
     */
    proto.trigger = alias('emitEvent');

    /**
     * Subtly different from emitEvent in that it will pass its arguments on to the listeners, as opposed to taking a single array of arguments to pass on.
     * As with emitEvent, you can pass a regex in place of the event name to emit to all events that match it.
     *
     * @param {String|RegExp} evt Name of the event to emit and execute listeners for.
     * @param {...*} Optional additional arguments to be passed to each listener.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.emit = function emit(evt) {
        var args = Array.prototype.slice.call(arguments, 1);
        return this.emitEvent(evt, args);
    };

    /**
     * Sets the current value to check against when executing listeners. If a
     * listeners return value matches the one set here then it will be removed
     * after execution. This value defaults to true.
     *
     * @param {*} value The new value to check for when executing listeners.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.setOnceReturnValue = function setOnceReturnValue(value) {
        this._onceReturnValue = value;
        return this;
    };

    /**
     * Fetches the current value to check against when executing listeners. If
     * the listeners return value matches this one then it should be removed
     * automatically. It will return true by default.
     *
     * @return {*|Boolean} The current value to check for or the default, true.
     * @api private
     */
    proto._getOnceReturnValue = function _getOnceReturnValue() {
        if (this.hasOwnProperty('_onceReturnValue')) {
            return this._onceReturnValue;
        }
        else {
            return true;
        }
    };

    /**
     * Fetches the events object and creates one if required.
     *
     * @return {Object} The events storage object.
     * @api private
     */
    proto._getEvents = function _getEvents() {
        return this._events || (this._events = {});
    };

    /**
     * Reverts the global {@link EventEmitter} to its previous value and returns a reference to this version.
     *
     * @return {Function} Non conflicting EventEmitter class.
     */
    EventEmitter.noConflict = function noConflict() {
        exports.EventEmitter = originalGlobalValue;
        return EventEmitter;
    };

    // Expose the class either via AMD, CommonJS or the global object
    if (typeof define === 'function' && define.amd) {
        define('eventEmitter/EventEmitter',[],function () {
            return EventEmitter;
        });
    }
    else if (typeof module === 'object' && module.exports){
        module.exports = EventEmitter;
    }
    else {
        exports.EventEmitter = EventEmitter;
    }
}.call(this));

/*!
 * getStyleProperty v1.0.4
 * original by kangax
 * http://perfectionkills.com/feature-testing-css-properties/
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true */
/*global define: false, exports: false, module: false */

( function( window ) {



var prefixes = 'Webkit Moz ms Ms O'.split(' ');
var docElemStyle = document.documentElement.style;

function getStyleProperty( propName ) {
  if ( !propName ) {
    return;
  }

  // test standard property first
  if ( typeof docElemStyle[ propName ] === 'string' ) {
    return propName;
  }

  // capitalize
  propName = propName.charAt(0).toUpperCase() + propName.slice(1);

  // test vendor specific properties
  var prefixed;
  for ( var i=0, len = prefixes.length; i < len; i++ ) {
    prefixed = prefixes[i] + propName;
    if ( typeof docElemStyle[ prefixed ] === 'string' ) {
      return prefixed;
    }
  }
}

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'get-style-property/get-style-property',[],function() {
    return getStyleProperty;
  });
} else if ( typeof exports === 'object' ) {
  // CommonJS for Component
  module.exports = getStyleProperty;
} else {
  // browser global
  window.getStyleProperty = getStyleProperty;
}

})( window );

/*!
 * getSize v1.2.2
 * measure size of elements
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true, unused: true */
/*global define: false, exports: false, require: false, module: false, console: false */

( function( window, undefined ) {



// -------------------------- helpers -------------------------- //

// get a number from a string, not a percentage
function getStyleSize( value ) {
  var num = parseFloat( value );
  // not a percent like '100%', and a number
  var isValid = value.indexOf('%') === -1 && !isNaN( num );
  return isValid && num;
}

function noop() {}

var logError = typeof console === 'undefined' ? noop :
  function( message ) {
    console.error( message );
  };

// -------------------------- measurements -------------------------- //

var measurements = [
  'paddingLeft',
  'paddingRight',
  'paddingTop',
  'paddingBottom',
  'marginLeft',
  'marginRight',
  'marginTop',
  'marginBottom',
  'borderLeftWidth',
  'borderRightWidth',
  'borderTopWidth',
  'borderBottomWidth'
];

function getZeroSize() {
  var size = {
    width: 0,
    height: 0,
    innerWidth: 0,
    innerHeight: 0,
    outerWidth: 0,
    outerHeight: 0
  };
  for ( var i=0, len = measurements.length; i < len; i++ ) {
    var measurement = measurements[i];
    size[ measurement ] = 0;
  }
  return size;
}



function defineGetSize( getStyleProperty ) {

// -------------------------- setup -------------------------- //

var isSetup = false;

var getStyle, boxSizingProp, isBoxSizeOuter;

/**
 * setup vars and functions
 * do it on initial getSize(), rather than on script load
 * For Firefox bug https://bugzilla.mozilla.org/show_bug.cgi?id=548397
 */
function setup() {
  // setup once
  if ( isSetup ) {
    return;
  }
  isSetup = true;

  var getComputedStyle = window.getComputedStyle;
  getStyle = ( function() {
    var getStyleFn = getComputedStyle ?
      function( elem ) {
        return getComputedStyle( elem, null );
      } :
      function( elem ) {
        return elem.currentStyle;
      };

      return function getStyle( elem ) {
        var style = getStyleFn( elem );
        if ( !style ) {
          logError( 'Style returned ' + style +
            '. Are you running this code in a hidden iframe on Firefox? ' +
            'See http://bit.ly/getsizebug1' );
        }
        return style;
      };
  })();

  // -------------------------- box sizing -------------------------- //

  boxSizingProp = getStyleProperty('boxSizing');

  /**
   * WebKit measures the outer-width on style.width on border-box elems
   * IE & Firefox measures the inner-width
   */
  if ( boxSizingProp ) {
    var div = document.createElement('div');
    div.style.width = '200px';
    div.style.padding = '1px 2px 3px 4px';
    div.style.borderStyle = 'solid';
    div.style.borderWidth = '1px 2px 3px 4px';
    div.style[ boxSizingProp ] = 'border-box';

    var body = document.body || document.documentElement;
    body.appendChild( div );
    var style = getStyle( div );

    isBoxSizeOuter = getStyleSize( style.width ) === 200;
    body.removeChild( div );
  }

}

// -------------------------- getSize -------------------------- //

function getSize( elem ) {
  setup();

  // use querySeletor if elem is string
  if ( typeof elem === 'string' ) {
    elem = document.querySelector( elem );
  }

  // do not proceed on non-objects
  if ( !elem || typeof elem !== 'object' || !elem.nodeType ) {
    return;
  }

  var style = getStyle( elem );

  // if hidden, everything is 0
  if ( style.display === 'none' ) {
    return getZeroSize();
  }

  var size = {};
  size.width = elem.offsetWidth;
  size.height = elem.offsetHeight;

  var isBorderBox = size.isBorderBox = !!( boxSizingProp &&
    style[ boxSizingProp ] && style[ boxSizingProp ] === 'border-box' );

  // get all measurements
  for ( var i=0, len = measurements.length; i < len; i++ ) {
    var measurement = measurements[i];
    var value = style[ measurement ];
    value = mungeNonPixel( elem, value );
    var num = parseFloat( value );
    // any 'auto', 'medium' value will be 0
    size[ measurement ] = !isNaN( num ) ? num : 0;
  }

  var paddingWidth = size.paddingLeft + size.paddingRight;
  var paddingHeight = size.paddingTop + size.paddingBottom;
  var marginWidth = size.marginLeft + size.marginRight;
  var marginHeight = size.marginTop + size.marginBottom;
  var borderWidth = size.borderLeftWidth + size.borderRightWidth;
  var borderHeight = size.borderTopWidth + size.borderBottomWidth;

  var isBorderBoxSizeOuter = isBorderBox && isBoxSizeOuter;

  // overwrite width and height if we can get it from style
  var styleWidth = getStyleSize( style.width );
  if ( styleWidth !== false ) {
    size.width = styleWidth +
      // add padding and border unless it's already including it
      ( isBorderBoxSizeOuter ? 0 : paddingWidth + borderWidth );
  }

  var styleHeight = getStyleSize( style.height );
  if ( styleHeight !== false ) {
    size.height = styleHeight +
      // add padding and border unless it's already including it
      ( isBorderBoxSizeOuter ? 0 : paddingHeight + borderHeight );
  }

  size.innerWidth = size.width - ( paddingWidth + borderWidth );
  size.innerHeight = size.height - ( paddingHeight + borderHeight );

  size.outerWidth = size.width + marginWidth;
  size.outerHeight = size.height + marginHeight;

  return size;
}

// IE8 returns percent values, not pixels
// taken from jQuery's curCSS
function mungeNonPixel( elem, value ) {
  // IE8 and has percent value
  if ( window.getComputedStyle || value.indexOf('%') === -1 ) {
    return value;
  }
  var style = elem.style;
  // Remember the original values
  var left = style.left;
  var rs = elem.runtimeStyle;
  var rsLeft = rs && rs.left;

  // Put in the new values to get a computed value out
  if ( rsLeft ) {
    rs.left = elem.currentStyle.left;
  }
  style.left = value;
  value = style.pixelLeft;

  // Revert the changed values
  style.left = left;
  if ( rsLeft ) {
    rs.left = rsLeft;
  }

  return value;
}

return getSize;

}

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD for RequireJS
  define( 'get-size/get-size',[ 'get-style-property/get-style-property' ], defineGetSize );
} else if ( typeof exports === 'object' ) {
  // CommonJS for Component
  module.exports = defineGetSize( require('desandro-get-style-property') );
} else {
  // browser global
  window.getSize = defineGetSize( window.getStyleProperty );
}

})( window );

/*!
 * docReady v1.0.4
 * Cross browser DOMContentLoaded event emitter
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true, unused: true*/
/*global define: false, require: false, module: false */

( function( window ) {



var document = window.document;
// collection of functions to be triggered on ready
var queue = [];

function docReady( fn ) {
  // throw out non-functions
  if ( typeof fn !== 'function' ) {
    return;
  }

  if ( docReady.isReady ) {
    // ready now, hit it
    fn();
  } else {
    // queue function when ready
    queue.push( fn );
  }
}

docReady.isReady = false;

// triggered on various doc ready events
function onReady( event ) {
  // bail if already triggered or IE8 document is not ready just yet
  var isIE8NotReady = event.type === 'readystatechange' && document.readyState !== 'complete';
  if ( docReady.isReady || isIE8NotReady ) {
    return;
  }

  trigger();
}

function trigger() {
  docReady.isReady = true;
  // process queue
  for ( var i=0, len = queue.length; i < len; i++ ) {
    var fn = queue[i];
    fn();
  }
}

function defineDocReady( eventie ) {
  // trigger ready if page is ready
  if ( document.readyState === 'complete' ) {
    trigger();
  } else {
    // listen for events
    eventie.bind( document, 'DOMContentLoaded', onReady );
    eventie.bind( document, 'readystatechange', onReady );
    eventie.bind( window, 'load', onReady );
  }

  return docReady;
}

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'doc-ready/doc-ready',[ 'eventie/eventie' ], defineDocReady );
} else if ( typeof exports === 'object' ) {
  module.exports = defineDocReady( require('eventie') );
} else {
  // browser global
  window.docReady = defineDocReady( window.eventie );
}

})( window );

/**
 * matchesSelector v1.0.3
 * matchesSelector( element, '.selector' )
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true, unused: true */
/*global define: false, module: false */

( function( ElemProto ) {

  

  var matchesMethod = ( function() {
    // check for the standard method name first
    if ( ElemProto.matches ) {
      return 'matches';
    }
    // check un-prefixed
    if ( ElemProto.matchesSelector ) {
      return 'matchesSelector';
    }
    // check vendor prefixes
    var prefixes = [ 'webkit', 'moz', 'ms', 'o' ];

    for ( var i=0, len = prefixes.length; i < len; i++ ) {
      var prefix = prefixes[i];
      var method = prefix + 'MatchesSelector';
      if ( ElemProto[ method ] ) {
        return method;
      }
    }
  })();

  // ----- match ----- //

  function match( elem, selector ) {
    return elem[ matchesMethod ]( selector );
  }

  // ----- appendToFragment ----- //

  function checkParent( elem ) {
    // not needed if already has parent
    if ( elem.parentNode ) {
      return;
    }
    var fragment = document.createDocumentFragment();
    fragment.appendChild( elem );
  }

  // ----- query ----- //

  // fall back to using QSA
  // thx @jonathantneal https://gist.github.com/3062955
  function query( elem, selector ) {
    // append to fragment if no parent
    checkParent( elem );

    // match elem with all selected elems of parent
    var elems = elem.parentNode.querySelectorAll( selector );
    for ( var i=0, len = elems.length; i < len; i++ ) {
      // return true if match
      if ( elems[i] === elem ) {
        return true;
      }
    }
    // otherwise return false
    return false;
  }

  // ----- matchChild ----- //

  function matchChild( elem, selector ) {
    checkParent( elem );
    return match( elem, selector );
  }

  // ----- matchesSelector ----- //

  var matchesSelector;

  if ( matchesMethod ) {
    // IE9 supports matchesSelector, but doesn't work on orphaned elems
    // check for that
    var div = document.createElement('div');
    var supportsOrphans = match( div, 'div' );
    matchesSelector = supportsOrphans ? match : matchChild;
  } else {
    matchesSelector = query;
  }

  // transport
  if ( typeof define === 'function' && define.amd ) {
    // AMD
    define( 'matches-selector/matches-selector',[],function() {
      return matchesSelector;
    });
  } else if ( typeof exports === 'object' ) {
    module.exports = matchesSelector;
  }
  else {
    // browser global
    window.matchesSelector = matchesSelector;
  }

})( (window.Element ? Element.prototype : document.documentElement) );

/**
 * Fizzy UI utils v1.0.1
 * MIT license
 */

/*jshint browser: true, undef: true, unused: true, strict: true */

( function( window, factory ) {
  /*global define: false, module: false, require: false */
  
  // universal module definition

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'fizzy-ui-utils/utils',[
      'doc-ready/doc-ready',
      'matches-selector/matches-selector'
    ], function( docReady, matchesSelector ) {
      return factory( window, docReady, matchesSelector );
    });
  } else if ( typeof exports == 'object' ) {
    // CommonJS
    module.exports = factory(
      window,
      require('doc-ready'),
      require('desandro-matches-selector')
    );
  } else {
    // browser global
    window.fizzyUIUtils = factory(
      window,
      window.docReady,
      window.matchesSelector
    );
  }

}( window, function factory( window, docReady, matchesSelector ) {



var utils = {};

// ----- extend ----- //

// extends objects
utils.extend = function( a, b ) {
  for ( var prop in b ) {
    a[ prop ] = b[ prop ];
  }
  return a;
};

// ----- modulo ----- //

utils.modulo = function( num, div ) {
  return ( ( num % div ) + div ) % div;
};

// ----- isArray ----- //
  
var objToString = Object.prototype.toString;
utils.isArray = function( obj ) {
  return objToString.call( obj ) == '[object Array]';
};

// ----- makeArray ----- //

// turn element or nodeList into an array
utils.makeArray = function( obj ) {
  var ary = [];
  if ( utils.isArray( obj ) ) {
    // use object if already an array
    ary = obj;
  } else if ( obj && typeof obj.length == 'number' ) {
    // convert nodeList to array
    for ( var i=0, len = obj.length; i < len; i++ ) {
      ary.push( obj[i] );
    }
  } else {
    // array of single index
    ary.push( obj );
  }
  return ary;
};

// ----- indexOf ----- //

// index of helper cause IE8
utils.indexOf = Array.prototype.indexOf ? function( ary, obj ) {
    return ary.indexOf( obj );
  } : function( ary, obj ) {
    for ( var i=0, len = ary.length; i < len; i++ ) {
      if ( ary[i] === obj ) {
        return i;
      }
    }
    return -1;
  };

// ----- removeFrom ----- //

utils.removeFrom = function( ary, obj ) {
  var index = utils.indexOf( ary, obj );
  if ( index != -1 ) {
    ary.splice( index, 1 );
  }
};

// ----- isElement ----- //

// http://stackoverflow.com/a/384380/182183
utils.isElement = ( typeof HTMLElement == 'function' || typeof HTMLElement == 'object' ) ?
  function isElementDOM2( obj ) {
    return obj instanceof HTMLElement;
  } :
  function isElementQuirky( obj ) {
    return obj && typeof obj == 'object' &&
      obj.nodeType == 1 && typeof obj.nodeName == 'string';
  };

// ----- setText ----- //

utils.setText = ( function() {
  var setTextProperty;
  function setText( elem, text ) {
    // only check setTextProperty once
    setTextProperty = setTextProperty || ( document.documentElement.textContent !== undefined ? 'textContent' : 'innerText' );
    elem[ setTextProperty ] = text;
  }
  return setText;
})();

// ----- getParent ----- //

utils.getParent = function( elem, selector ) {
  while ( elem != document.body ) {
    elem = elem.parentNode;
    if ( matchesSelector( elem, selector ) ) {
      return elem;
    }
  }
};

// ----- getQueryElement ----- //

// use element as selector string
utils.getQueryElement = function( elem ) {
  if ( typeof elem == 'string' ) {
    return document.querySelector( elem );
  }
  return elem;
};

// ----- handleEvent ----- //

// enable .ontype to trigger from .addEventListener( elem, 'type' )
utils.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

// ----- filterFindElements ----- //

utils.filterFindElements = function( elems, selector ) {
  // make array of elems
  elems = utils.makeArray( elems );
  var ffElems = [];

  for ( var i=0, len = elems.length; i < len; i++ ) {
    var elem = elems[i];
    // check that elem is an actual element
    if ( !utils.isElement( elem ) ) {
      continue;
    }
    // filter & find items if we have a selector
    if ( selector ) {
      // filter siblings
      if ( matchesSelector( elem, selector ) ) {
        ffElems.push( elem );
      }
      // find children
      var childElems = elem.querySelectorAll( selector );
      // concat childElems to filterFound array
      for ( var j=0, jLen = childElems.length; j < jLen; j++ ) {
        ffElems.push( childElems[j] );
      }
    } else {
      ffElems.push( elem );
    }
  }

  return ffElems;
};

// ----- debounceMethod ----- //

utils.debounceMethod = function( _class, methodName, threshold ) {
  // original method
  var method = _class.prototype[ methodName ];
  var timeoutName = methodName + 'Timeout';

  _class.prototype[ methodName ] = function() {
    var timeout = this[ timeoutName ];
    if ( timeout ) {
      clearTimeout( timeout );
    }
    var args = arguments;

    var _this = this;
    this[ timeoutName ] = setTimeout( function() {
      method.apply( _this, args );
      delete _this[ timeoutName ];
    }, threshold || 100 );
  };
};

// ----- htmlInit ----- //

// http://jamesroberts.name/blog/2010/02/22/string-functions-for-javascript-trim-to-camel-case-to-dashed-and-to-underscore/
utils.toDashed = function( str ) {
  return str.replace( /(.)([A-Z])/g, function( match, $1, $2 ) {
    return $1 + '-' + $2;
  }).toLowerCase();
};

var console = window.console;
/**
 * allow user to initialize classes via .js-namespace class
 * htmlInit( Widget, 'widgetName' )
 * options are parsed from data-namespace-option attribute
 */
utils.htmlInit = function( WidgetClass, namespace ) {
  docReady( function() {
    var dashedNamespace = utils.toDashed( namespace );
    var elems = document.querySelectorAll ? document.querySelectorAll( '.js-' + dashedNamespace ) : [];
    var dataAttr = 'data-' + dashedNamespace + '-options';

    for ( var i=0, len = elems.length; i < len; i++ ) {
      var elem = elems[i];
      var attr = elem.getAttribute( dataAttr );
      var options;
      try {
        options = attr && JSON.parse( attr );
      } catch ( error ) {
        // log error, do not initialize
        if ( console ) {
          console.error( 'Error parsing ' + dataAttr + ' on ' +
            elem.nodeName.toLowerCase() + ( elem.id ? '#' + elem.id : '' ) + ': ' +
            error );
        }
        continue;
      }
      // initialize
      var instance = new WidgetClass( elem, options );
      // make available via $().data('layoutname')
      var jQuery = window.jQuery;
      if ( jQuery ) {
        jQuery.data( elem, namespace, instance );
      }
    }
  });
};

// -----  ----- //

return utils;

}));

/**
 * Outlayer Item
 */

( function( window, factory ) {
  
  // universal module definition
  if ( typeof define === 'function' && define.amd ) {
    // AMD
    define( 'outlayer/item',[
        'eventEmitter/EventEmitter',
        'get-size/get-size',
        'get-style-property/get-style-property',
        'fizzy-ui-utils/utils'
      ],
      function( EventEmitter, getSize, getStyleProperty, utils ) {
        return factory( window, EventEmitter, getSize, getStyleProperty, utils );
      }
    );
  } else if (typeof exports === 'object') {
    // CommonJS
    module.exports = factory(
      window,
      require('wolfy87-eventemitter'),
      require('get-size'),
      require('desandro-get-style-property'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    window.Outlayer = {};
    window.Outlayer.Item = factory(
      window,
      window.EventEmitter,
      window.getSize,
      window.getStyleProperty,
      window.fizzyUIUtils
    );
  }

}( window, function factory( window, EventEmitter, getSize, getStyleProperty, utils ) {


// ----- helpers ----- //

var getComputedStyle = window.getComputedStyle;
var getStyle = getComputedStyle ?
  function( elem ) {
    return getComputedStyle( elem, null );
  } :
  function( elem ) {
    return elem.currentStyle;
  };


function isEmptyObj( obj ) {
  for ( var prop in obj ) {
    return false;
  }
  prop = null;
  return true;
}

// -------------------------- CSS3 support -------------------------- //

var transitionProperty = getStyleProperty('transition');
var transformProperty = getStyleProperty('transform');
var supportsCSS3 = transitionProperty && transformProperty;
var is3d = !!getStyleProperty('perspective');

var transitionEndEvent = {
  WebkitTransition: 'webkitTransitionEnd',
  MozTransition: 'transitionend',
  OTransition: 'otransitionend',
  transition: 'transitionend'
}[ transitionProperty ];

// properties that could have vendor prefix
var prefixableProperties = [
  'transform',
  'transition',
  'transitionDuration',
  'transitionProperty'
];

// cache all vendor properties
var vendorProperties = ( function() {
  var cache = {};
  for ( var i=0, len = prefixableProperties.length; i < len; i++ ) {
    var prop = prefixableProperties[i];
    var supportedProp = getStyleProperty( prop );
    if ( supportedProp && supportedProp !== prop ) {
      cache[ prop ] = supportedProp;
    }
  }
  return cache;
})();

// -------------------------- Item -------------------------- //

function Item( element, layout ) {
  if ( !element ) {
    return;
  }

  this.element = element;
  // parent layout class, i.e. Masonry, Isotope, or Packery
  this.layout = layout;
  this.position = {
    x: 0,
    y: 0
  };

  this._create();
}

// inherit EventEmitter
utils.extend( Item.prototype, EventEmitter.prototype );

Item.prototype._create = function() {
  // transition objects
  this._transn = {
    ingProperties: {},
    clean: {},
    onEnd: {}
  };

  this.css({
    position: 'absolute'
  });
};

// trigger specified handler for event type
Item.prototype.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

Item.prototype.getSize = function() {
  this.size = getSize( this.element );
};

/**
 * apply CSS styles to element
 * @param {Object} style
 */
Item.prototype.css = function( style ) {
  var elemStyle = this.element.style;

  for ( var prop in style ) {
    // use vendor property if available
    var supportedProp = vendorProperties[ prop ] || prop;
    elemStyle[ supportedProp ] = style[ prop ];
  }
};

 // measure position, and sets it
Item.prototype.getPosition = function() {
  var style = getStyle( this.element );
  var layoutOptions = this.layout.options;
  var isOriginLeft = layoutOptions.isOriginLeft;
  var isOriginTop = layoutOptions.isOriginTop;
  var xValue = style[ isOriginLeft ? 'left' : 'right' ];
  var yValue = style[ isOriginTop ? 'top' : 'bottom' ];
  // convert percent to pixels
  var layoutSize = this.layout.size;
  var x = xValue.indexOf('%') != -1 ?
    ( parseFloat( xValue ) / 100 ) * layoutSize.width : parseInt( xValue, 10 );
  var y = yValue.indexOf('%') != -1 ?
    ( parseFloat( yValue ) / 100 ) * layoutSize.height : parseInt( yValue, 10 );

  // clean up 'auto' or other non-integer values
  x = isNaN( x ) ? 0 : x;
  y = isNaN( y ) ? 0 : y;
  // remove padding from measurement
  x -= isOriginLeft ? layoutSize.paddingLeft : layoutSize.paddingRight;
  y -= isOriginTop ? layoutSize.paddingTop : layoutSize.paddingBottom;

  this.position.x = x;
  this.position.y = y;
};

// set settled position, apply padding
Item.prototype.layoutPosition = function() {
  var layoutSize = this.layout.size;
  var layoutOptions = this.layout.options;
  var style = {};

  // x
  var xPadding = layoutOptions.isOriginLeft ? 'paddingLeft' : 'paddingRight';
  var xProperty = layoutOptions.isOriginLeft ? 'left' : 'right';
  var xResetProperty = layoutOptions.isOriginLeft ? 'right' : 'left';

  var x = this.position.x + layoutSize[ xPadding ];
  // set in percentage or pixels
  style[ xProperty ] = this.getXValue( x );
  // reset other property
  style[ xResetProperty ] = '';

  // y
  var yPadding = layoutOptions.isOriginTop ? 'paddingTop' : 'paddingBottom';
  var yProperty = layoutOptions.isOriginTop ? 'top' : 'bottom';
  var yResetProperty = layoutOptions.isOriginTop ? 'bottom' : 'top';

  var y = this.position.y + layoutSize[ yPadding ];
  // set in percentage or pixels
  style[ yProperty ] = this.getYValue( y );
  // reset other property
  style[ yResetProperty ] = '';

  this.css( style );
  this.emitEvent( 'layout', [ this ] );
};

Item.prototype.getXValue = function( x ) {
  var layoutOptions = this.layout.options;
  return layoutOptions.percentPosition && !layoutOptions.isHorizontal ?
    ( ( x / this.layout.size.width ) * 100 ) + '%' : x + 'px';
};

Item.prototype.getYValue = function( y ) {
  var layoutOptions = this.layout.options;
  return layoutOptions.percentPosition && layoutOptions.isHorizontal ?
    ( ( y / this.layout.size.height ) * 100 ) + '%' : y + 'px';
};


Item.prototype._transitionTo = function( x, y ) {
  this.getPosition();
  // get current x & y from top/left
  var curX = this.position.x;
  var curY = this.position.y;

  var compareX = parseInt( x, 10 );
  var compareY = parseInt( y, 10 );
  var didNotMove = compareX === this.position.x && compareY === this.position.y;

  // save end position
  this.setPosition( x, y );

  // if did not move and not transitioning, just go to layout
  if ( didNotMove && !this.isTransitioning ) {
    this.layoutPosition();
    return;
  }

  var transX = x - curX;
  var transY = y - curY;
  var transitionStyle = {};
  transitionStyle.transform = this.getTranslate( transX, transY );

  this.transition({
    to: transitionStyle,
    onTransitionEnd: {
      transform: this.layoutPosition
    },
    isCleaning: true
  });
};

Item.prototype.getTranslate = function( x, y ) {
  // flip cooridinates if origin on right or bottom
  var layoutOptions = this.layout.options;
  x = layoutOptions.isOriginLeft ? x : -x;
  y = layoutOptions.isOriginTop ? y : -y;

  if ( is3d ) {
    return 'translate3d(' + x + 'px, ' + y + 'px, 0)';
  }

  return 'translate(' + x + 'px, ' + y + 'px)';
};

// non transition + transform support
Item.prototype.goTo = function( x, y ) {
  this.setPosition( x, y );
  this.layoutPosition();
};

// use transition and transforms if supported
Item.prototype.moveTo = supportsCSS3 ?
  Item.prototype._transitionTo : Item.prototype.goTo;

Item.prototype.setPosition = function( x, y ) {
  this.position.x = parseInt( x, 10 );
  this.position.y = parseInt( y, 10 );
};

// ----- transition ----- //

/**
 * @param {Object} style - CSS
 * @param {Function} onTransitionEnd
 */

// non transition, just trigger callback
Item.prototype._nonTransition = function( args ) {
  this.css( args.to );
  if ( args.isCleaning ) {
    this._removeStyles( args.to );
  }
  for ( var prop in args.onTransitionEnd ) {
    args.onTransitionEnd[ prop ].call( this );
  }
};

/**
 * proper transition
 * @param {Object} args - arguments
 *   @param {Object} to - style to transition to
 *   @param {Object} from - style to start transition from
 *   @param {Boolean} isCleaning - removes transition styles after transition
 *   @param {Function} onTransitionEnd - callback
 */
Item.prototype._transition = function( args ) {
  // redirect to nonTransition if no transition duration
  if ( !parseFloat( this.layout.options.transitionDuration ) ) {
    this._nonTransition( args );
    return;
  }

  var _transition = this._transn;
  // keep track of onTransitionEnd callback by css property
  for ( var prop in args.onTransitionEnd ) {
    _transition.onEnd[ prop ] = args.onTransitionEnd[ prop ];
  }
  // keep track of properties that are transitioning
  for ( prop in args.to ) {
    _transition.ingProperties[ prop ] = true;
    // keep track of properties to clean up when transition is done
    if ( args.isCleaning ) {
      _transition.clean[ prop ] = true;
    }
  }

  // set from styles
  if ( args.from ) {
    this.css( args.from );
    // force redraw. http://blog.alexmaccaw.com/css-transitions
    var h = this.element.offsetHeight;
    // hack for JSHint to hush about unused var
    h = null;
  }
  // enable transition
  this.enableTransition( args.to );
  // set styles that are transitioning
  this.css( args.to );

  this.isTransitioning = true;

};

// dash before all cap letters, including first for
// WebkitTransform => -webkit-transform
function toDashedAll( str ) {
  return str.replace( /([A-Z])/g, function( $1 ) {
    return '-' + $1.toLowerCase();
  });
}

var transitionProps = 'opacity,' +
  toDashedAll( vendorProperties.transform || 'transform' );

Item.prototype.enableTransition = function(/* style */) {
  // HACK changing transitionProperty during a transition
  // will cause transition to jump
  if ( this.isTransitioning ) {
    return;
  }

  // make `transition: foo, bar, baz` from style object
  // HACK un-comment this when enableTransition can work
  // while a transition is happening
  // var transitionValues = [];
  // for ( var prop in style ) {
  //   // dash-ify camelCased properties like WebkitTransition
  //   prop = vendorProperties[ prop ] || prop;
  //   transitionValues.push( toDashedAll( prop ) );
  // }
  // enable transition styles
  this.css({
    transitionProperty: transitionProps,
    transitionDuration: this.layout.options.transitionDuration
  });
  // listen for transition end event
  this.element.addEventListener( transitionEndEvent, this, false );
};

Item.prototype.transition = Item.prototype[ transitionProperty ? '_transition' : '_nonTransition' ];

// ----- events ----- //

Item.prototype.onwebkitTransitionEnd = function( event ) {
  this.ontransitionend( event );
};

Item.prototype.onotransitionend = function( event ) {
  this.ontransitionend( event );
};

// properties that I munge to make my life easier
var dashedVendorProperties = {
  '-webkit-transform': 'transform',
  '-moz-transform': 'transform',
  '-o-transform': 'transform'
};

Item.prototype.ontransitionend = function( event ) {
  // disregard bubbled events from children
  if ( event.target !== this.element ) {
    return;
  }
  var _transition = this._transn;
  // get property name of transitioned property, convert to prefix-free
  var propertyName = dashedVendorProperties[ event.propertyName ] || event.propertyName;

  // remove property that has completed transitioning
  delete _transition.ingProperties[ propertyName ];
  // check if any properties are still transitioning
  if ( isEmptyObj( _transition.ingProperties ) ) {
    // all properties have completed transitioning
    this.disableTransition();
  }
  // clean style
  if ( propertyName in _transition.clean ) {
    // clean up style
    this.element.style[ event.propertyName ] = '';
    delete _transition.clean[ propertyName ];
  }
  // trigger onTransitionEnd callback
  if ( propertyName in _transition.onEnd ) {
    var onTransitionEnd = _transition.onEnd[ propertyName ];
    onTransitionEnd.call( this );
    delete _transition.onEnd[ propertyName ];
  }

  this.emitEvent( 'transitionEnd', [ this ] );
};

Item.prototype.disableTransition = function() {
  this.removeTransitionStyles();
  this.element.removeEventListener( transitionEndEvent, this, false );
  this.isTransitioning = false;
};

/**
 * removes style property from element
 * @param {Object} style
**/
Item.prototype._removeStyles = function( style ) {
  // clean up transition styles
  var cleanStyle = {};
  for ( var prop in style ) {
    cleanStyle[ prop ] = '';
  }
  this.css( cleanStyle );
};

var cleanTransitionStyle = {
  transitionProperty: '',
  transitionDuration: ''
};

Item.prototype.removeTransitionStyles = function() {
  // remove transition
  this.css( cleanTransitionStyle );
};

// ----- show/hide/remove ----- //

// remove element from DOM
Item.prototype.removeElem = function() {
  this.element.parentNode.removeChild( this.element );
  // remove display: none
  this.css({ display: '' });
  this.emitEvent( 'remove', [ this ] );
};

Item.prototype.remove = function() {
  // just remove element if no transition support or no transition
  if ( !transitionProperty || !parseFloat( this.layout.options.transitionDuration ) ) {
    this.removeElem();
    return;
  }

  // start transition
  var _this = this;
  this.once( 'transitionEnd', function() {
    _this.removeElem();
  });
  this.hide();
};

Item.prototype.reveal = function() {
  delete this.isHidden;
  // remove display: none
  this.css({ display: '' });

  var options = this.layout.options;

  var onTransitionEnd = {};
  var transitionEndProperty = this.getHideRevealTransitionEndProperty('visibleStyle');
  onTransitionEnd[ transitionEndProperty ] = this.onRevealTransitionEnd;

  this.transition({
    from: options.hiddenStyle,
    to: options.visibleStyle,
    isCleaning: true,
    onTransitionEnd: onTransitionEnd
  });
};

Item.prototype.onRevealTransitionEnd = function() {
  // check if still visible
  // during transition, item may have been hidden
  if ( !this.isHidden ) {
    this.emitEvent('reveal');
  }
};

/**
 * get style property use for hide/reveal transition end
 * @param {String} styleProperty - hiddenStyle/visibleStyle
 * @returns {String}
 */
Item.prototype.getHideRevealTransitionEndProperty = function( styleProperty ) {
  var optionStyle = this.layout.options[ styleProperty ];
  // use opacity
  if ( optionStyle.opacity ) {
    return 'opacity';
  }
  // get first property
  for ( var prop in optionStyle ) {
    return prop;
  }
};

Item.prototype.hide = function() {
  // set flag
  this.isHidden = true;
  // remove display: none
  this.css({ display: '' });

  var options = this.layout.options;

  var onTransitionEnd = {};
  var transitionEndProperty = this.getHideRevealTransitionEndProperty('hiddenStyle');
  onTransitionEnd[ transitionEndProperty ] = this.onHideTransitionEnd;

  this.transition({
    from: options.visibleStyle,
    to: options.hiddenStyle,
    // keep hidden stuff hidden
    isCleaning: true,
    onTransitionEnd: onTransitionEnd
  });
};

Item.prototype.onHideTransitionEnd = function() {
  // check if still hidden
  // during transition, item may have been un-hidden
  if ( this.isHidden ) {
    this.css({ display: 'none' });
    this.emitEvent('hide');
  }
};

Item.prototype.destroy = function() {
  this.css({
    position: '',
    left: '',
    right: '',
    top: '',
    bottom: '',
    transition: '',
    transform: ''
  });
};

return Item;

}));

/*!
 * Outlayer v1.4.2
 * the brains and guts of a layout library
 * MIT license
 */

( function( window, factory ) {
  
  // universal module definition

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'outlayer/outlayer',[
        'eventie/eventie',
        'eventEmitter/EventEmitter',
        'get-size/get-size',
        'fizzy-ui-utils/utils',
        './item'
      ],
      function( eventie, EventEmitter, getSize, utils, Item ) {
        return factory( window, eventie, EventEmitter, getSize, utils, Item);
      }
    );
  } else if ( typeof exports == 'object' ) {
    // CommonJS
    module.exports = factory(
      window,
      require('eventie'),
      require('wolfy87-eventemitter'),
      require('get-size'),
      require('fizzy-ui-utils'),
      require('./item')
    );
  } else {
    // browser global
    window.Outlayer = factory(
      window,
      window.eventie,
      window.EventEmitter,
      window.getSize,
      window.fizzyUIUtils,
      window.Outlayer.Item
    );
  }

}( window, function factory( window, eventie, EventEmitter, getSize, utils, Item ) {


// ----- vars ----- //

var console = window.console;
var jQuery = window.jQuery;
var noop = function() {};

// -------------------------- Outlayer -------------------------- //

// globally unique identifiers
var GUID = 0;
// internal store of all Outlayer intances
var instances = {};


/**
 * @param {Element, String} element
 * @param {Object} options
 * @constructor
 */
function Outlayer( element, options ) {
  var queryElement = utils.getQueryElement( element );
  if ( !queryElement ) {
    if ( console ) {
      console.error( 'Bad element for ' + this.constructor.namespace +
        ': ' + ( queryElement || element ) );
    }
    return;
  }
  this.element = queryElement;
  // add jQuery
  if ( jQuery ) {
    this.$element = jQuery( this.element );
  }

  // options
  this.options = utils.extend( {}, this.constructor.defaults );
  this.option( options );

  // add id for Outlayer.getFromElement
  var id = ++GUID;
  this.element.outlayerGUID = id; // expando
  instances[ id ] = this; // associate via id

  // kick it off
  this._create();

  if ( this.options.isInitLayout ) {
    this.layout();
  }
}

// settings are for internal use only
Outlayer.namespace = 'outlayer';
Outlayer.Item = Item;

// default options
Outlayer.defaults = {
  containerStyle: {
    position: 'relative'
  },
  isInitLayout: true,
  isOriginLeft: true,
  isOriginTop: true,
  isResizeBound: true,
  isResizingContainer: true,
  // item options
  transitionDuration: '0.4s',
  hiddenStyle: {
    opacity: 0,
    transform: 'scale(0.001)'
  },
  visibleStyle: {
    opacity: 1,
    transform: 'scale(1)'
  }
};

// inherit EventEmitter
utils.extend( Outlayer.prototype, EventEmitter.prototype );

/**
 * set options
 * @param {Object} opts
 */
Outlayer.prototype.option = function( opts ) {
  utils.extend( this.options, opts );
};

Outlayer.prototype._create = function() {
  // get items from children
  this.reloadItems();
  // elements that affect layout, but are not laid out
  this.stamps = [];
  this.stamp( this.options.stamp );
  // set container style
  utils.extend( this.element.style, this.options.containerStyle );

  // bind resize method
  if ( this.options.isResizeBound ) {
    this.bindResize();
  }
};

// goes through all children again and gets bricks in proper order
Outlayer.prototype.reloadItems = function() {
  // collection of item elements
  this.items = this._itemize( this.element.children );
};


/**
 * turn elements into Outlayer.Items to be used in layout
 * @param {Array or NodeList or HTMLElement} elems
 * @returns {Array} items - collection of new Outlayer Items
 */
Outlayer.prototype._itemize = function( elems ) {

  var itemElems = this._filterFindItemElements( elems );
  var Item = this.constructor.Item;

  // create new Outlayer Items for collection
  var items = [];
  for ( var i=0, len = itemElems.length; i < len; i++ ) {
    var elem = itemElems[i];
    var item = new Item( elem, this );
    items.push( item );
  }

  return items;
};

/**
 * get item elements to be used in layout
 * @param {Array or NodeList or HTMLElement} elems
 * @returns {Array} items - item elements
 */
Outlayer.prototype._filterFindItemElements = function( elems ) {
  return utils.filterFindElements( elems, this.options.itemSelector );
};

/**
 * getter method for getting item elements
 * @returns {Array} elems - collection of item elements
 */
Outlayer.prototype.getItemElements = function() {
  var elems = [];
  for ( var i=0, len = this.items.length; i < len; i++ ) {
    elems.push( this.items[i].element );
  }
  return elems;
};

// ----- init & layout ----- //

/**
 * lays out all items
 */
Outlayer.prototype.layout = function() {
  this._resetLayout();
  this._manageStamps();

  // don't animate first layout
  var isInstant = this.options.isLayoutInstant !== undefined ?
    this.options.isLayoutInstant : !this._isLayoutInited;
  this.layoutItems( this.items, isInstant );

  // flag for initalized
  this._isLayoutInited = true;
};

// _init is alias for layout
Outlayer.prototype._init = Outlayer.prototype.layout;

/**
 * logic before any new layout
 */
Outlayer.prototype._resetLayout = function() {
  this.getSize();
};


Outlayer.prototype.getSize = function() {
  this.size = getSize( this.element );
};

/**
 * get measurement from option, for columnWidth, rowHeight, gutter
 * if option is String -> get element from selector string, & get size of element
 * if option is Element -> get size of element
 * else use option as a number
 *
 * @param {String} measurement
 * @param {String} size - width or height
 * @private
 */
Outlayer.prototype._getMeasurement = function( measurement, size ) {
  var option = this.options[ measurement ];
  var elem;
  if ( !option ) {
    // default to 0
    this[ measurement ] = 0;
  } else {
    // use option as an element
    if ( typeof option === 'string' ) {
      elem = this.element.querySelector( option );
    } else if ( utils.isElement( option ) ) {
      elem = option;
    }
    // use size of element, if element
    this[ measurement ] = elem ? getSize( elem )[ size ] : option;
  }
};

/**
 * layout a collection of item elements
 * @api public
 */
Outlayer.prototype.layoutItems = function( items, isInstant ) {
  items = this._getItemsForLayout( items );

  this._layoutItems( items, isInstant );

  this._postLayout();
};

/**
 * get the items to be laid out
 * you may want to skip over some items
 * @param {Array} items
 * @returns {Array} items
 */
Outlayer.prototype._getItemsForLayout = function( items ) {
  var layoutItems = [];
  for ( var i=0, len = items.length; i < len; i++ ) {
    var item = items[i];
    if ( !item.isIgnored ) {
      layoutItems.push( item );
    }
  }
  return layoutItems;
};

/**
 * layout items
 * @param {Array} items
 * @param {Boolean} isInstant
 */
Outlayer.prototype._layoutItems = function( items, isInstant ) {
  this._emitCompleteOnItems( 'layout', items );

  if ( !items || !items.length ) {
    // no items, emit event with empty array
    return;
  }

  var queue = [];

  for ( var i=0, len = items.length; i < len; i++ ) {
    var item = items[i];
    // get x/y object from method
    var position = this._getItemLayoutPosition( item );
    // enqueue
    position.item = item;
    position.isInstant = isInstant || item.isLayoutInstant;
    queue.push( position );
  }

  this._processLayoutQueue( queue );
};

/**
 * get item layout position
 * @param {Outlayer.Item} item
 * @returns {Object} x and y position
 */
Outlayer.prototype._getItemLayoutPosition = function( /* item */ ) {
  return {
    x: 0,
    y: 0
  };
};

/**
 * iterate over array and position each item
 * Reason being - separating this logic prevents 'layout invalidation'
 * thx @paul_irish
 * @param {Array} queue
 */
Outlayer.prototype._processLayoutQueue = function( queue ) {
  for ( var i=0, len = queue.length; i < len; i++ ) {
    var obj = queue[i];
    this._positionItem( obj.item, obj.x, obj.y, obj.isInstant );
  }
};

/**
 * Sets position of item in DOM
 * @param {Outlayer.Item} item
 * @param {Number} x - horizontal position
 * @param {Number} y - vertical position
 * @param {Boolean} isInstant - disables transitions
 */
Outlayer.prototype._positionItem = function( item, x, y, isInstant ) {
  if ( isInstant ) {
    // if not transition, just set CSS
    item.goTo( x, y );
  } else {
    item.moveTo( x, y );
  }
};

/**
 * Any logic you want to do after each layout,
 * i.e. size the container
 */
Outlayer.prototype._postLayout = function() {
  this.resizeContainer();
};

Outlayer.prototype.resizeContainer = function() {
  if ( !this.options.isResizingContainer ) {
    return;
  }
  var size = this._getContainerSize();
  if ( size ) {
    this._setContainerMeasure( size.width, true );
    this._setContainerMeasure( size.height, false );
  }
};

/**
 * Sets width or height of container if returned
 * @returns {Object} size
 *   @param {Number} width
 *   @param {Number} height
 */
Outlayer.prototype._getContainerSize = noop;

/**
 * @param {Number} measure - size of width or height
 * @param {Boolean} isWidth
 */
Outlayer.prototype._setContainerMeasure = function( measure, isWidth ) {
  if ( measure === undefined ) {
    return;
  }

  var elemSize = this.size;
  // add padding and border width if border box
  if ( elemSize.isBorderBox ) {
    measure += isWidth ? elemSize.paddingLeft + elemSize.paddingRight +
      elemSize.borderLeftWidth + elemSize.borderRightWidth :
      elemSize.paddingBottom + elemSize.paddingTop +
      elemSize.borderTopWidth + elemSize.borderBottomWidth;
  }

  measure = Math.max( measure, 0 );
  this.element.style[ isWidth ? 'width' : 'height' ] = measure + 'px';
};

/**
 * emit eventComplete on a collection of items events
 * @param {String} eventName
 * @param {Array} items - Outlayer.Items
 */
Outlayer.prototype._emitCompleteOnItems = function( eventName, items ) {
  var _this = this;
  function onComplete() {
    _this.dispatchEvent( eventName + 'Complete', null, [ items ] );
  }

  var count = items.length;
  if ( !items || !count ) {
    onComplete();
    return;
  }

  var doneCount = 0;
  function tick() {
    doneCount++;
    if ( doneCount === count ) {
      onComplete();
    }
  }

  // bind callback
  for ( var i=0, len = items.length; i < len; i++ ) {
    var item = items[i];
    item.once( eventName, tick );
  }
};

/**
 * emits events via eventEmitter and jQuery events
 * @param {String} type - name of event
 * @param {Event} event - original event
 * @param {Array} args - extra arguments
 */
Outlayer.prototype.dispatchEvent = function( type, event, args ) {
  // add original event to arguments
  var emitArgs = event ? [ event ].concat( args ) : args;
  this.emitEvent( type, emitArgs );

  if ( jQuery ) {
    // set this.$element
    this.$element = this.$element || jQuery( this.element );
    if ( event ) {
      // create jQuery event
      var $event = jQuery.Event( event );
      $event.type = type;
      this.$element.trigger( $event, args );
    } else {
      // just trigger with type if no event available
      this.$element.trigger( type, args );
    }
  }
};

// -------------------------- ignore & stamps -------------------------- //


/**
 * keep item in collection, but do not lay it out
 * ignored items do not get skipped in layout
 * @param {Element} elem
 */
Outlayer.prototype.ignore = function( elem ) {
  var item = this.getItem( elem );
  if ( item ) {
    item.isIgnored = true;
  }
};

/**
 * return item to layout collection
 * @param {Element} elem
 */
Outlayer.prototype.unignore = function( elem ) {
  var item = this.getItem( elem );
  if ( item ) {
    delete item.isIgnored;
  }
};

/**
 * adds elements to stamps
 * @param {NodeList, Array, Element, or String} elems
 */
Outlayer.prototype.stamp = function( elems ) {
  elems = this._find( elems );
  if ( !elems ) {
    return;
  }

  this.stamps = this.stamps.concat( elems );
  // ignore
  for ( var i=0, len = elems.length; i < len; i++ ) {
    var elem = elems[i];
    this.ignore( elem );
  }
};

/**
 * removes elements to stamps
 * @param {NodeList, Array, or Element} elems
 */
Outlayer.prototype.unstamp = function( elems ) {
  elems = this._find( elems );
  if ( !elems ){
    return;
  }

  for ( var i=0, len = elems.length; i < len; i++ ) {
    var elem = elems[i];
    // filter out removed stamp elements
    utils.removeFrom( this.stamps, elem );
    this.unignore( elem );
  }

};

/**
 * finds child elements
 * @param {NodeList, Array, Element, or String} elems
 * @returns {Array} elems
 */
Outlayer.prototype._find = function( elems ) {
  if ( !elems ) {
    return;
  }
  // if string, use argument as selector string
  if ( typeof elems === 'string' ) {
    elems = this.element.querySelectorAll( elems );
  }
  elems = utils.makeArray( elems );
  return elems;
};

Outlayer.prototype._manageStamps = function() {
  if ( !this.stamps || !this.stamps.length ) {
    return;
  }

  this._getBoundingRect();

  for ( var i=0, len = this.stamps.length; i < len; i++ ) {
    var stamp = this.stamps[i];
    this._manageStamp( stamp );
  }
};

// update boundingLeft / Top
Outlayer.prototype._getBoundingRect = function() {
  // get bounding rect for container element
  var boundingRect = this.element.getBoundingClientRect();
  var size = this.size;
  this._boundingRect = {
    left: boundingRect.left + size.paddingLeft + size.borderLeftWidth,
    top: boundingRect.top + size.paddingTop + size.borderTopWidth,
    right: boundingRect.right - ( size.paddingRight + size.borderRightWidth ),
    bottom: boundingRect.bottom - ( size.paddingBottom + size.borderBottomWidth )
  };
};

/**
 * @param {Element} stamp
**/
Outlayer.prototype._manageStamp = noop;

/**
 * get x/y position of element relative to container element
 * @param {Element} elem
 * @returns {Object} offset - has left, top, right, bottom
 */
Outlayer.prototype._getElementOffset = function( elem ) {
  var boundingRect = elem.getBoundingClientRect();
  var thisRect = this._boundingRect;
  var size = getSize( elem );
  var offset = {
    left: boundingRect.left - thisRect.left - size.marginLeft,
    top: boundingRect.top - thisRect.top - size.marginTop,
    right: thisRect.right - boundingRect.right - size.marginRight,
    bottom: thisRect.bottom - boundingRect.bottom - size.marginBottom
  };
  return offset;
};

// -------------------------- resize -------------------------- //

// enable event handlers for listeners
// i.e. resize -> onresize
Outlayer.prototype.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

/**
 * Bind layout to window resizing
 */
Outlayer.prototype.bindResize = function() {
  // bind just one listener
  if ( this.isResizeBound ) {
    return;
  }
  eventie.bind( window, 'resize', this );
  this.isResizeBound = true;
};

/**
 * Unbind layout to window resizing
 */
Outlayer.prototype.unbindResize = function() {
  if ( this.isResizeBound ) {
    eventie.unbind( window, 'resize', this );
  }
  this.isResizeBound = false;
};

// original debounce by John Hann
// http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/

// this fires every resize
Outlayer.prototype.onresize = function() {
  if ( this.resizeTimeout ) {
    clearTimeout( this.resizeTimeout );
  }

  var _this = this;
  function delayed() {
    _this.resize();
    delete _this.resizeTimeout;
  }

  this.resizeTimeout = setTimeout( delayed, 100 );
};

// debounced, layout on resize
Outlayer.prototype.resize = function() {
  // don't trigger if size did not change
  // or if resize was unbound. See #9
  if ( !this.isResizeBound || !this.needsResizeLayout() ) {
    return;
  }

  this.layout();
};

/**
 * check if layout is needed post layout
 * @returns Boolean
 */
Outlayer.prototype.needsResizeLayout = function() {
  var size = getSize( this.element );
  // check that this.size and size are there
  // IE8 triggers resize on body size change, so they might not be
  var hasSizes = this.size && size;
  return hasSizes && size.innerWidth !== this.size.innerWidth;
};

// -------------------------- methods -------------------------- //

/**
 * add items to Outlayer instance
 * @param {Array or NodeList or Element} elems
 * @returns {Array} items - Outlayer.Items
**/
Outlayer.prototype.addItems = function( elems ) {
  var items = this._itemize( elems );
  // add items to collection
  if ( items.length ) {
    this.items = this.items.concat( items );
  }
  return items;
};

/**
 * Layout newly-appended item elements
 * @param {Array or NodeList or Element} elems
 */
Outlayer.prototype.appended = function( elems ) {
  var items = this.addItems( elems );
  if ( !items.length ) {
    return;
  }
  // layout and reveal just the new items
  this.layoutItems( items, true );
  this.reveal( items );
};

/**
 * Layout prepended elements
 * @param {Array or NodeList or Element} elems
 */
Outlayer.prototype.prepended = function( elems ) {
  var items = this._itemize( elems );
  if ( !items.length ) {
    return;
  }
  // add items to beginning of collection
  var previousItems = this.items.slice(0);
  this.items = items.concat( previousItems );
  // start new layout
  this._resetLayout();
  this._manageStamps();
  // layout new stuff without transition
  this.layoutItems( items, true );
  this.reveal( items );
  // layout previous items
  this.layoutItems( previousItems );
};

/**
 * reveal a collection of items
 * @param {Array of Outlayer.Items} items
 */
Outlayer.prototype.reveal = function( items ) {
  this._emitCompleteOnItems( 'reveal', items );

  var len = items && items.length;
  for ( var i=0; len && i < len; i++ ) {
    var item = items[i];
    item.reveal();
  }
};

/**
 * hide a collection of items
 * @param {Array of Outlayer.Items} items
 */
Outlayer.prototype.hide = function( items ) {
  this._emitCompleteOnItems( 'hide', items );

  var len = items && items.length;
  for ( var i=0; len && i < len; i++ ) {
    var item = items[i];
    item.hide();
  }
};

/**
 * reveal item elements
 * @param {Array}, {Element}, {NodeList} items
 */
Outlayer.prototype.revealItemElements = function( elems ) {
  var items = this.getItems( elems );
  this.reveal( items );
};

/**
 * hide item elements
 * @param {Array}, {Element}, {NodeList} items
 */
Outlayer.prototype.hideItemElements = function( elems ) {
  var items = this.getItems( elems );
  this.hide( items );
};

/**
 * get Outlayer.Item, given an Element
 * @param {Element} elem
 * @param {Function} callback
 * @returns {Outlayer.Item} item
 */
Outlayer.prototype.getItem = function( elem ) {
  // loop through items to get the one that matches
  for ( var i=0, len = this.items.length; i < len; i++ ) {
    var item = this.items[i];
    if ( item.element === elem ) {
      // return item
      return item;
    }
  }
};

/**
 * get collection of Outlayer.Items, given Elements
 * @param {Array} elems
 * @returns {Array} items - Outlayer.Items
 */
Outlayer.prototype.getItems = function( elems ) {
  elems = utils.makeArray( elems );
  var items = [];
  for ( var i=0, len = elems.length; i < len; i++ ) {
    var elem = elems[i];
    var item = this.getItem( elem );
    if ( item ) {
      items.push( item );
    }
  }

  return items;
};

/**
 * remove element(s) from instance and DOM
 * @param {Array or NodeList or Element} elems
 */
Outlayer.prototype.remove = function( elems ) {
  var removeItems = this.getItems( elems );

  this._emitCompleteOnItems( 'remove', removeItems );

  // bail if no items to remove
  if ( !removeItems || !removeItems.length ) {
    return;
  }

  for ( var i=0, len = removeItems.length; i < len; i++ ) {
    var item = removeItems[i];
    item.remove();
    // remove item from collection
    utils.removeFrom( this.items, item );
  }
};

// ----- destroy ----- //

// remove and disable Outlayer instance
Outlayer.prototype.destroy = function() {
  // clean up dynamic styles
  var style = this.element.style;
  style.height = '';
  style.position = '';
  style.width = '';
  // destroy items
  for ( var i=0, len = this.items.length; i < len; i++ ) {
    var item = this.items[i];
    item.destroy();
  }

  this.unbindResize();

  var id = this.element.outlayerGUID;
  delete instances[ id ]; // remove reference to instance by id
  delete this.element.outlayerGUID;
  // remove data for jQuery
  if ( jQuery ) {
    jQuery.removeData( this.element, this.constructor.namespace );
  }

};

// -------------------------- data -------------------------- //

/**
 * get Outlayer instance from element
 * @param {Element} elem
 * @returns {Outlayer}
 */
Outlayer.data = function( elem ) {
  elem = utils.getQueryElement( elem );
  var id = elem && elem.outlayerGUID;
  return id && instances[ id ];
};


// -------------------------- create Outlayer class -------------------------- //

/**
 * create a layout class
 * @param {String} namespace
 */
Outlayer.create = function( namespace, options ) {
  // sub-class Outlayer
  function Layout() {
    Outlayer.apply( this, arguments );
  }
  // inherit Outlayer prototype, use Object.create if there
  if ( Object.create ) {
    Layout.prototype = Object.create( Outlayer.prototype );
  } else {
    utils.extend( Layout.prototype, Outlayer.prototype );
  }
  // set contructor, used for namespace and Item
  Layout.prototype.constructor = Layout;

  Layout.defaults = utils.extend( {}, Outlayer.defaults );
  // apply new options
  utils.extend( Layout.defaults, options );
  // keep prototype.settings for backwards compatibility (Packery v1.2.0)
  Layout.prototype.settings = {};

  Layout.namespace = namespace;

  Layout.data = Outlayer.data;

  // sub-class Item
  Layout.Item = function LayoutItem() {
    Item.apply( this, arguments );
  };

  Layout.Item.prototype = new Item();

  // -------------------------- declarative -------------------------- //

  //utils.htmlInit( Layout, namespace );//GF init fait par WDHTML

  // -------------------------- jQuery bridge -------------------------- //

  // make into jQuery plugin
  if ( jQuery && jQuery.bridget ) {
    jQuery.bridget( namespace, Layout );
  }

  return Layout;
};

// ----- fin ----- //

// back in global
Outlayer.Item = Item;

return Outlayer;

}));


/*!
 * Masonry v3.3.2
 * Cascading grid layout library
 * http://masonry.desandro.com
 * MIT License
 * by David DeSandro
 */

( function( window, factory ) {
  
  // universal module definition
  if ( typeof define === 'function' && define.amd ) {
    // AMD
    define( [
        'outlayer/outlayer',
        'get-size/get-size',
        'fizzy-ui-utils/utils'
      ],
      factory );
  } else if ( typeof exports === 'object' ) {
    // CommonJS
    module.exports = factory(
      require('outlayer'),
      require('get-size'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    window.Masonry = factory(
      window.Outlayer,
      window.getSize,
      window.fizzyUIUtils
    );
  }

}( window, function factory( Outlayer, getSize, utils ) {



// -------------------------- masonryDefinition -------------------------- //

  // create an Outlayer layout class
  var Masonry = Outlayer.create('masonry');

  Masonry.prototype._resetLayout = function() {
    this.getSize();
    this._getMeasurement( 'columnWidth', 'outerWidth' );
    this._getMeasurement( 'gutter', 'outerWidth' );
    this.measureColumns();

    // reset column Y
    var i = this.cols;
    this.colYs = [];
    while (i--) {
      this.colYs.push( 0 );
    }

    this.maxY = 0;
  };

  Masonry.prototype.measureColumns = function() {
    this.getContainerWidth();
    // if columnWidth is 0, default to outerWidth of first item
    if ( !this.columnWidth ) {
      var firstItem = this.items[0];
      var firstItemElem = firstItem && firstItem.element;
      // columnWidth fall back to item of first element
      this.columnWidth = firstItemElem && getSize( firstItemElem ).outerWidth ||
        // if first elem has no width, default to size of container
        this.containerWidth;
    }

    var columnWidth = this.columnWidth += this.gutter;

    // calculate columns
    var containerWidth = this.containerWidth + this.gutter;
    var cols = containerWidth / columnWidth;
    // fix rounding errors, typically with gutters
    var excess = columnWidth - containerWidth % columnWidth;
    // if overshoot is less than a pixel, round up, otherwise floor it
    var mathMethod = excess && excess < 1 ? 'round' : 'floor';
    cols = Math[ mathMethod ]( cols );
    this.cols = Math.max( cols, 1 );
  };

  Masonry.prototype.getContainerWidth = function() {
    // container is parent if fit width
    var container = this.options.isFitWidth ? this.element.parentNode : this.element;
    // check that this.size and size are there
    // IE8 triggers resize on body size change, so they might not be
    var size = getSize( container );
    this.containerWidth = size && size.innerWidth;
  };

  Masonry.prototype._getItemLayoutPosition = function( item ) {
    item.getSize();
    // how many columns does this brick span
    var remainder = item.size.outerWidth % this.columnWidth;
    var mathMethod = remainder && remainder < 1 ? 'round' : 'ceil';
    // round if off by 1 pixel, otherwise use ceil
    var colSpan = Math[ mathMethod ]( item.size.outerWidth / this.columnWidth );
    colSpan = Math.min( colSpan, this.cols );

    var colGroup = this._getColGroup( colSpan );
    // get the minimum Y value from the columns
    var minimumY = Math.min.apply( Math, colGroup );
    var shortColIndex = utils.indexOf( colGroup, minimumY );

    // position the brick
    var position = {
      x: this.columnWidth * shortColIndex,
      y: minimumY
    };

    // apply setHeight to necessary columns
    var setHeight = minimumY + item.size.outerHeight;
    var setSpan = this.cols + 1 - colGroup.length;
    for ( var i = 0; i < setSpan; i++ ) {
      this.colYs[ shortColIndex + i ] = setHeight;
    }

    return position;
  };

  /**
   * @param {Number} colSpan - number of columns the element spans
   * @returns {Array} colGroup
   */
  Masonry.prototype._getColGroup = function( colSpan ) {
    if ( colSpan < 2 ) {
      // if brick spans only one column, use all the column Ys
      return this.colYs;
    }

    var colGroup = [];
    // how many different places could this brick fit horizontally
    var groupCount = this.cols + 1 - colSpan;
    // for each group potential horizontal position
    for ( var i = 0; i < groupCount; i++ ) {
      // make an array of colY values for that one group
      var groupColYs = this.colYs.slice( i, i + colSpan );
      // and get the max value of the array
      colGroup[i] = Math.max.apply( Math, groupColYs );
    }
    return colGroup;
  };

  Masonry.prototype._manageStamp = function( stamp ) {
    var stampSize = getSize( stamp );
    var offset = this._getElementOffset( stamp );
    // get the columns that this stamp affects
    var firstX = this.options.isOriginLeft ? offset.left : offset.right;
    var lastX = firstX + stampSize.outerWidth;
    var firstCol = Math.floor( firstX / this.columnWidth );
    firstCol = Math.max( 0, firstCol );
    var lastCol = Math.floor( lastX / this.columnWidth );
    // lastCol should not go over if multiple of columnWidth #425
    lastCol -= lastX % this.columnWidth ? 0 : 1;
    lastCol = Math.min( this.cols - 1, lastCol );
    // set colYs to bottom of the stamp
    var stampMaxY = ( this.options.isOriginTop ? offset.top : offset.bottom ) +
      stampSize.outerHeight;
    for ( var i = firstCol; i <= lastCol; i++ ) {
      this.colYs[i] = Math.max( stampMaxY, this.colYs[i] );
    }
  };

  Masonry.prototype._getContainerSize = function() {
    this.maxY = Math.max.apply( Math, this.colYs );
    var size = {
      height: this.maxY
    };

    if ( this.options.isFitWidth ) {
      size.width = this._getContainerFitWidth();
    }

    return size;
  };

  Masonry.prototype._getContainerFitWidth = function() {
    var unusedCols = 0;
    // count unused columns
    var i = this.cols;
    while ( --i ) {
      if ( this.colYs[i] !== 0 ) {
        break;
      }
      unusedCols++;
    }
    // fit container to columns that have been used
    return ( this.cols - unusedCols ) * this.columnWidth - this.gutter;
  };

  Masonry.prototype.needsResizeLayout = function() {
    var previousWidth = this.containerWidth;
    this.getContainerWidth();
    return previousWidth !== this.containerWidth;
  };

  return Masonry;

}));

/*!
 * imagesLoaded PACKAGED v3.2.0
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */

/*!
 * EventEmitter v4.2.6 - git.io/ee
 * Oliver Caldwell
 * MIT license
 * @preserve
 */
if (!bIEQuirks)
(function () {
	'use strict';

	/**
	 * Class for managing events.
	 * Can be extended to provide event functionality in other classes.
	 *
	 * @class EventEmitter Manages event registering and emitting.
	 */
	function EventEmitter() {}

	// Shortcuts to improve speed and size
	var proto = EventEmitter.prototype;
	var exports = this;
	var originalGlobalValue = exports.EventEmitter;

	/**
	 * Finds the index of the listener for the event in it's storage array.
	 *
	 * @param {Function[]} listeners Array of listeners to search through.
	 * @param {Function} listener Method to look for.
	 * @return {Number} Index of the specified listener, -1 if not found
	 * @api private
	 */
	function indexOfListener(listeners, listener) {
		var i = listeners.length;
		while (i--) {
			if (listeners[i].listener === listener) {
				return i;
			}
		}

		return -1;
	}

	/**
	 * Alias a method while keeping the context correct, to allow for overwriting of target method.
	 *
	 * @param {String} name The name of the target method.
	 * @return {Function} The aliased method
	 * @api private
	 */
	function alias(name) {
		return function aliasClosure() {
			return this[name].apply(this, arguments);
		};
	}

	/**
	 * Returns the listener array for the specified event.
	 * Will initialise the event object and listener arrays if required.
	 * Will return an object if you use a regex search. The object contains keys for each matched event. So /ba[rz]/ might return an object containing bar and baz. But only if you have either defined them with defineEvent or added some listeners to them.
	 * Each property in the object response is an array of listener functions.
	 *
	 * @param {String|RegExp} evt Name of the event to return the listeners from.
	 * @return {Function[]|Object} All listener functions for the event.
	 */
	proto.getListeners = function getListeners(evt) {
		var events = this._getEvents();
		var response;
		var key;

		// Return a concatenated array of all matching events if
		// the selector is a regular expression.
		if (typeof evt === 'object') {
			response = {};
			for (key in events) {
				if (events.hasOwnProperty(key) && evt.test(key)) {
					response[key] = events[key];
				}
			}
		}
		else {
			response = events[evt] || (events[evt] = []);
		}

		return response;
	};

	/**
	 * Takes a list of listener objects and flattens it into a list of listener functions.
	 *
	 * @param {Object[]} listeners Raw listener objects.
	 * @return {Function[]} Just the listener functions.
	 */
	proto.flattenListeners = function flattenListeners(listeners) {
		var flatListeners = [];
		var i;

		for (i = 0; i < listeners.length; i += 1) {
			flatListeners.push(listeners[i].listener);
		}

		return flatListeners;
	};

	/**
	 * Fetches the requested listeners via getListeners but will always return the results inside an object. This is mainly for internal use but others may find it useful.
	 *
	 * @param {String|RegExp} evt Name of the event to return the listeners from.
	 * @return {Object} All listener functions for an event in an object.
	 */
	proto.getListenersAsObject = function getListenersAsObject(evt) {
		var listeners = this.getListeners(evt);
		var response;

		if (listeners instanceof Array) {
			response = {};
			response[evt] = listeners;
		}

		return response || listeners;
	};

	/**
	 * Adds a listener function to the specified event.
	 * The listener will not be added if it is a duplicate.
	 * If the listener returns true then it will be removed after it is called.
	 * If you pass a regular expression as the event name then the listener will be added to all events that match it.
	 *
	 * @param {String|RegExp} evt Name of the event to attach the listener to.
	 * @param {Function} listener Method to be called when the event is emitted. If the function returns true then it will be removed after calling.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.addListener = function addListener(evt, listener) {
		var listeners = this.getListenersAsObject(evt);
		var listenerIsWrapped = typeof listener === 'object';
		var key;

		for (key in listeners) {
			if (listeners.hasOwnProperty(key) && indexOfListener(listeners[key], listener) === -1) {
				listeners[key].push(listenerIsWrapped ? listener : {
					listener: listener,
					once: false
				});
			}
		}

		return this;
	};

	/**
	 * Alias of addListener
	 */
	proto.on = alias('addListener');

	/**
	 * Semi-alias of addListener. It will add a listener that will be
	 * automatically removed after it's first execution.
	 *
	 * @param {String|RegExp} evt Name of the event to attach the listener to.
	 * @param {Function} listener Method to be called when the event is emitted. If the function returns true then it will be removed after calling.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.addOnceListener = function addOnceListener(evt, listener) {
		return this.addListener(evt, {
			listener: listener,
			once: true
		});
	};

	/**
	 * Alias of addOnceListener.
	 */
	proto.once = alias('addOnceListener');

	/**
	 * Defines an event name. This is required if you want to use a regex to add a listener to multiple events at once. If you don't do this then how do you expect it to know what event to add to? Should it just add to every possible match for a regex? No. That is scary and bad.
	 * You need to tell it what event names should be matched by a regex.
	 *
	 * @param {String} evt Name of the event to create.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.defineEvent = function defineEvent(evt) {
		this.getListeners(evt);
		return this;
	};

	/**
	 * Uses defineEvent to define multiple events.
	 *
	 * @param {String[]} evts An array of event names to define.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.defineEvents = function defineEvents(evts) {
		for (var i = 0; i < evts.length; i += 1) {
			this.defineEvent(evts[i]);
		}
		return this;
	};

	/**
	 * Removes a listener function from the specified event.
	 * When passed a regular expression as the event name, it will remove the listener from all events that match it.
	 *
	 * @param {String|RegExp} evt Name of the event to remove the listener from.
	 * @param {Function} listener Method to remove from the event.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.removeListener = function removeListener(evt, listener) {
		var listeners = this.getListenersAsObject(evt);
		var index;
		var key;

		for (key in listeners) {
			if (listeners.hasOwnProperty(key)) {
				index = indexOfListener(listeners[key], listener);

				if (index !== -1) {
					listeners[key].splice(index, 1);
				}
			}
		}

		return this;
	};

	/**
	 * Alias of removeListener
	 */
	proto.off = alias('removeListener');

	/**
	 * Adds listeners in bulk using the manipulateListeners method.
	 * If you pass an object as the second argument you can add to multiple events at once. The object should contain key value pairs of events and listeners or listener arrays. You can also pass it an event name and an array of listeners to be added.
	 * You can also pass it a regular expression to add the array of listeners to all events that match it.
	 * Yeah, this function does quite a bit. That's probably a bad thing.
	 *
	 * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to add to multiple events at once.
	 * @param {Function[]} [listeners] An optional array of listener functions to add.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.addListeners = function addListeners(evt, listeners) {
		// Pass through to manipulateListeners
		return this.manipulateListeners(false, evt, listeners);
	};

	/**
	 * Removes listeners in bulk using the manipulateListeners method.
	 * If you pass an object as the second argument you can remove from multiple events at once. The object should contain key value pairs of events and listeners or listener arrays.
	 * You can also pass it an event name and an array of listeners to be removed.
	 * You can also pass it a regular expression to remove the listeners from all events that match it.
	 *
	 * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to remove from multiple events at once.
	 * @param {Function[]} [listeners] An optional array of listener functions to remove.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.removeListeners = function removeListeners(evt, listeners) {
		// Pass through to manipulateListeners
		return this.manipulateListeners(true, evt, listeners);
	};

	/**
	 * Edits listeners in bulk. The addListeners and removeListeners methods both use this to do their job. You should really use those instead, this is a little lower level.
	 * The first argument will determine if the listeners are removed (true) or added (false).
	 * If you pass an object as the second argument you can add/remove from multiple events at once. The object should contain key value pairs of events and listeners or listener arrays.
	 * You can also pass it an event name and an array of listeners to be added/removed.
	 * You can also pass it a regular expression to manipulate the listeners of all events that match it.
	 *
	 * @param {Boolean} remove True if you want to remove listeners, false if you want to add.
	 * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to add/remove from multiple events at once.
	 * @param {Function[]} [listeners] An optional array of listener functions to add/remove.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.manipulateListeners = function manipulateListeners(remove, evt, listeners) {
		var i;
		var value;
		var single = remove ? this.removeListener : this.addListener;
		var multiple = remove ? this.removeListeners : this.addListeners;

		// If evt is an object then pass each of it's properties to this method
		if (typeof evt === 'object' && !(evt instanceof RegExp)) {
			for (i in evt) {
				if (evt.hasOwnProperty(i) && (value = evt[i])) {
					// Pass the single listener straight through to the singular method
					if (typeof value === 'function') {
						single.call(this, i, value);
					}
					else {
						// Otherwise pass back to the multiple function
						multiple.call(this, i, value);
					}
				}
			}
		}
		else {
			// So evt must be a string
			// And listeners must be an array of listeners
			// Loop over it and pass each one to the multiple method
			i = listeners.length;
			while (i--) {
				single.call(this, evt, listeners[i]);
			}
		}

		return this;
	};

	/**
	 * Removes all listeners from a specified event.
	 * If you do not specify an event then all listeners will be removed.
	 * That means every event will be emptied.
	 * You can also pass a regex to remove all events that match it.
	 *
	 * @param {String|RegExp} [evt] Optional name of the event to remove all listeners for. Will remove from every event if not passed.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.removeEvent = function removeEvent(evt) {
		var type = typeof evt;
		var events = this._getEvents();
		var key;

		// Remove different things depending on the state of evt
		if (type === 'string') {
			// Remove all listeners for the specified event
			delete events[evt];
		}
		else if (type === 'object') {
			// Remove all events matching the regex.
			for (key in events) {
				if (events.hasOwnProperty(key) && evt.test(key)) {
					delete events[key];
				}
			}
		}
		else {
			// Remove all listeners in all events
			delete this._events;
		}

		return this;
	};

	/**
	 * Alias of removeEvent.
	 *
	 * Added to mirror the node API.
	 */
	proto.removeAllListeners = alias('removeEvent');

	/**
	 * Emits an event of your choice.
	 * When emitted, every listener attached to that event will be executed.
	 * If you pass the optional argument array then those arguments will be passed to every listener upon execution.
	 * Because it uses `apply`, your array of arguments will be passed as if you wrote them out separately.
	 * So they will not arrive within the array on the other side, they will be separate.
	 * You can also pass a regular expression to emit to all events that match it.
	 *
	 * @param {String|RegExp} evt Name of the event to emit and execute listeners for.
	 * @param {Array} [args] Optional array of arguments to be passed to each listener.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.emitEvent = function emitEvent(evt, args) {
		var listeners = this.getListenersAsObject(evt);
		var listener;
		var i;
		var key;
		var response;

		for (key in listeners) {
			if (listeners.hasOwnProperty(key)) {
				i = listeners[key].length;

				while (i--) {
					// If the listener returns true then it shall be removed from the event
					// The function is executed either with a basic call or an apply if there is an args array
					listener = listeners[key][i];

					if (listener.once === true) {
						this.removeListener(evt, listener.listener);
					}

					response = listener.listener.apply(this, args || []);

					if (response === this._getOnceReturnValue()) {
						this.removeListener(evt, listener.listener);
					}
				}
			}
		}

		return this;
	};

	/**
	 * Alias of emitEvent
	 */
	proto.trigger = alias('emitEvent');

	/**
	 * Subtly different from emitEvent in that it will pass its arguments on to the listeners, as opposed to taking a single array of arguments to pass on.
	 * As with emitEvent, you can pass a regex in place of the event name to emit to all events that match it.
	 *
	 * @param {String|RegExp} evt Name of the event to emit and execute listeners for.
	 * @param {...*} Optional additional arguments to be passed to each listener.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.emit = function emit(evt) {
		var args = Array.prototype.slice.call(arguments, 1);
		return this.emitEvent(evt, args);
	};

	/**
	 * Sets the current value to check against when executing listeners. If a
	 * listeners return value matches the one set here then it will be removed
	 * after execution. This value defaults to true.
	 *
	 * @param {*} value The new value to check for when executing listeners.
	 * @return {Object} Current instance of EventEmitter for chaining.
	 */
	proto.setOnceReturnValue = function setOnceReturnValue(value) {
		this._onceReturnValue = value;
		return this;
	};

	/**
	 * Fetches the current value to check against when executing listeners. If
	 * the listeners return value matches this one then it should be removed
	 * automatically. It will return true by default.
	 *
	 * @return {*|Boolean} The current value to check for or the default, true.
	 * @api private
	 */
	proto._getOnceReturnValue = function _getOnceReturnValue() {
		if (this.hasOwnProperty('_onceReturnValue')) {
			return this._onceReturnValue;
		}
		else {
			return true;
		}
	};

	/**
	 * Fetches the events object and creates one if required.
	 *
	 * @return {Object} The events storage object.
	 * @api private
	 */
	proto._getEvents = function _getEvents() {
		return this._events || (this._events = {});
	};

	/**
	 * Reverts the global {@link EventEmitter} to its previous value and returns a reference to this version.
	 *
	 * @return {Function} Non conflicting EventEmitter class.
	 */
	EventEmitter.noConflict = function noConflict() {
		exports.EventEmitter = originalGlobalValue;
		return EventEmitter;
	};

	// Expose the class either via AMD, CommonJS or the global object
	if (typeof define === 'function' && define.amd) {
		define('eventEmitter/EventEmitter',[],function () {
			return EventEmitter;
		});
	}
	else if (typeof module === 'object' && module.exports){
		module.exports = EventEmitter;
	}
	else {
		this.EventEmitter = EventEmitter;
	}
}.call(this));

/*!
 * eventie v1.0.4
 * event binding helper
 *   eventie.bind( elem, 'click', myFn )
 *   eventie.unbind( elem, 'click', myFn )
 */

/*jshint browser: true, undef: true, unused: true */
/*global define: false */

( function( window ) {



var docElem = document.documentElement;

var bind = function() {};

function getIEEvent( obj ) {
  var event = window.event;
  // add event.target
  event.target = event.target || event.srcElement || obj;
  return event;
}

if ( docElem.addEventListener ) {
  bind = function( obj, type, fn ) {
    obj.addEventListener( type, fn, false );
  };
} else if ( docElem.attachEvent ) {
  bind = function( obj, type, fn ) {
    obj[ type + fn ] = fn.handleEvent ?
      function() {
        var event = getIEEvent( obj );
        fn.handleEvent.call( fn, event );
      } :
      function() {
        var event = getIEEvent( obj );
        fn.call( obj, event );
      };
    obj.attachEvent( "on" + type, obj[ type + fn ] );
  };
}

var unbind = function() {};

if ( docElem.removeEventListener ) {
  unbind = function( obj, type, fn ) {
    obj.removeEventListener( type, fn, false );
  };
} else if ( docElem.detachEvent ) {
  unbind = function( obj, type, fn ) {
    obj.detachEvent( "on" + type, obj[ type + fn ] );
    try {
      delete obj[ type + fn ];
    } catch ( err ) {
      // can't delete window object properties
      obj[ type + fn ] = undefined;
    }
  };
}

var eventie = {
  bind: bind,
  unbind: unbind
};

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'eventie/eventie',eventie );
} else {
  // browser global
  window.eventie = eventie;
}

})( this );

/*!
 * imagesLoaded v3.2.0
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */

( function( window, factory ) { 'use strict';
  // universal module definition

  /*global define: false, module: false, require: false */

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( [
      'eventEmitter/EventEmitter',
      'eventie/eventie'
    ], function( EventEmitter, eventie ) {
      return factory( window, EventEmitter, eventie );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('wolfy87-eventemitter'),
      require('eventie')
    );
  } else {
    // browser global
    window.imagesLoaded = factory(
      window,
      window.EventEmitter,
      window.eventie
    );
  }

})( window,

// --------------------------  factory -------------------------- //

function factory( window, EventEmitter, eventie ) {



var $ = window.jQuery;
var console = window.console;

// -------------------------- helpers -------------------------- //

// extend objects
function extend( a, b ) {
  for ( var prop in b ) {
    a[ prop ] = b[ prop ];
  }
  return a;
}

var objToString = Object.prototype.toString;
function isArray( obj ) {
  return objToString.call( obj ) == '[object Array]';
}

// turn element or nodeList into an array
function makeArray( obj ) {
  var ary = [];
  if ( isArray( obj ) ) {
    // use object if already an array
    ary = obj;
  } else if ( typeof obj.length == 'number' ) {
    // convert nodeList to array
    for ( var i=0; i < obj.length; i++ ) {
      ary.push( obj[i] );
    }
  } else {
    // array of single index
    ary.push( obj );
  }
  return ary;
}

  // -------------------------- imagesLoaded -------------------------- //

  /**
   * @param {Array, Element, NodeList, String} elem
   * @param {Object or Function} options - if function, use as callback
   * @param {Function} onAlways - callback function
   */
  function ImagesLoaded( elem, options, onAlways ) {
    // coerce ImagesLoaded() without new, to be new ImagesLoaded()
    if ( !( this instanceof ImagesLoaded ) ) {
      return new ImagesLoaded( elem, options, onAlways );
    }
    // use elem as selector string
    if ( typeof elem == 'string' ) {
      elem = document.querySelectorAll( elem );
    }

    this.elements = makeArray( elem );
    this.options = extend( {}, this.options );

    if ( typeof options == 'function' ) {
      onAlways = options;
    } else {
      extend( this.options, options );
    }

    if ( onAlways ) {
      this.on( 'always', onAlways );
    }

    this.getImages();

    if ( $ ) {
      // add jQuery Deferred object
      this.jqDeferred = new $.Deferred();
    }

    // HACK check async to allow time to bind listeners
    var _this = this;
    setTimeout( function() {
      _this.check();
    });
  }

  ImagesLoaded.prototype = new EventEmitter();

  ImagesLoaded.prototype.options = {};

  ImagesLoaded.prototype.getImages = function() {
    this.images = [];

    // filter & find items if we have an item selector
    for ( var i=0; i < this.elements.length; i++ ) {
      var elem = this.elements[i];
      this.addElementImages( elem );
    }
  };

  /**
   * @param {Node} element
   */
  ImagesLoaded.prototype.addElementImages = function( elem ) {
    // filter siblings
    if ( elem.nodeName == 'IMG' ) {
      this.addImage( elem );
    }
    // get background image on element
    if ( this.options.background === true ) {
      this.addElementBackgroundImages( elem );
    }

    // find children
    // no non-element nodes, #143
    var nodeType = elem.nodeType;
    if ( !nodeType || !elementNodeTypes[ nodeType ] ) {
      return;
    }
    var childImgs = elem.querySelectorAll('img');
    // concat childElems to filterFound array
    for ( var i=0; i < childImgs.length; i++ ) {
      var img = childImgs[i];
      this.addImage( img );
    }

    // get child background images
    if ( typeof this.options.background == 'string' ) {
      var children = elem.querySelectorAll( this.options.background );
      for ( i=0; i < children.length; i++ ) {
        var child = children[i];
        this.addElementBackgroundImages( child );
      }
    }
  };

  var elementNodeTypes = {
    1: true,
    9: true,
    11: true
  };

  ImagesLoaded.prototype.addElementBackgroundImages = function( elem ) {
    var style = getStyle( elem );
    // get url inside url("...")
    var reURL = /url\(['"]*([^'"\)]+)['"]*\)/gi;
    var matches = reURL.exec( style.backgroundImage );
    while ( matches !== null ) {
      var url = matches && matches[1];
      if ( url ) {
        this.addBackground( url, elem );
      }
      matches = reURL.exec( style.backgroundImage );
    }
  };

  // IE8
  var getStyle = window.getComputedStyle || function( elem ) {
    return elem.currentStyle;
  };

  /**
   * @param {Image} img
   */
  ImagesLoaded.prototype.addImage = function( img ) {
    var loadingImage = new LoadingImage( img );
    this.images.push( loadingImage );
  };

  ImagesLoaded.prototype.addBackground = function( url, elem ) {
    var background = new Background( url, elem );
    this.images.push( background );
  };

  ImagesLoaded.prototype.check = function() {
    var _this = this;
    this.progressedCount = 0;
    this.hasAnyBroken = false;
    // complete if no images
    if ( !this.images.length ) {
      this.complete();
      return;
    }

    function onProgress( image, elem, message ) {
      // HACK - Chrome triggers event before object properties have changed. #83
      setTimeout( function() {
        _this.progress( image, elem, message );
      });
    }

    for ( var i=0; i < this.images.length; i++ ) {
      var loadingImage = this.images[i];
      loadingImage.once( 'progress', onProgress );
      loadingImage.check();
    }
  };

  ImagesLoaded.prototype.progress = function( image, elem, message ) {
    this.progressedCount++;
    this.hasAnyBroken = this.hasAnyBroken || !image.isLoaded;
    // progress event
    this.emit( 'progress', this, image, elem );
    if ( this.jqDeferred && this.jqDeferred.notify ) {
      this.jqDeferred.notify( this, image );
    }
    // check if completed
    if ( this.progressedCount == this.images.length ) {
      this.complete();
    }

    if ( this.options.debug && console ) {
      console.log( 'progress: ' + message, image, elem );
    }
  };

  ImagesLoaded.prototype.complete = function() {
    var eventName = this.hasAnyBroken ? 'fail' : 'done';
    this.isComplete = true;
    this.emit( eventName, this );
    this.emit( 'always', this );
    if ( this.jqDeferred ) {
      var jqMethod = this.hasAnyBroken ? 'reject' : 'resolve';
      this.jqDeferred[ jqMethod ]( this );
    }
  };

  // --------------------------  -------------------------- //

  function LoadingImage( img ) {
    this.img = img;
  }

  LoadingImage.prototype = new EventEmitter();

  LoadingImage.prototype.check = function() {
    // If complete is true and browser supports natural sizes,
    // try to check for image status manually.
    var isComplete = this.getIsImageComplete();
    if ( isComplete ) {
      // report based on naturalWidth
      this.confirm( this.img.naturalWidth !== 0, 'naturalWidth' );
      return;
    }

    // If none of the checks above matched, simulate loading on detached element.
    this.proxyImage = new Image();
    eventie.bind( this.proxyImage, 'load', this );
    eventie.bind( this.proxyImage, 'error', this );
    // bind to image as well for Firefox. #191
    eventie.bind( this.img, 'load', this );
    eventie.bind( this.img, 'error', this );
    this.proxyImage.src = this.img.src;
  };

  LoadingImage.prototype.getIsImageComplete = function() {
    return this.img.complete && this.img.naturalWidth !== undefined;
  };

  LoadingImage.prototype.confirm = function( isLoaded, message ) {
    this.isLoaded = isLoaded;
    this.emit( 'progress', this, this.img, message );
  };

  // ----- events ----- //

  // trigger specified handler for event type
  LoadingImage.prototype.handleEvent = function( event ) {
    var method = 'on' + event.type;
    if ( this[ method ] ) {
      this[ method ]( event );
    }
  };

  LoadingImage.prototype.onload = function() {
    this.confirm( true, 'onload' );
    this.unbindEvents();
  };

  LoadingImage.prototype.onerror = function() {
    this.confirm( false, 'onerror' );
    this.unbindEvents();
  };

  LoadingImage.prototype.unbindEvents = function() {
    eventie.unbind( this.proxyImage, 'load', this );
    eventie.unbind( this.proxyImage, 'error', this );
    eventie.unbind( this.img, 'load', this );
    eventie.unbind( this.img, 'error', this );
  };

  // -------------------------- Background -------------------------- //

  function Background( url, element ) {
    this.url = url;
    this.element = element;
    this.img = new Image();
  }

  // inherit LoadingImage prototype
  Background.prototype = new LoadingImage();

  Background.prototype.check = function() {
    eventie.bind( this.img, 'load', this );
    eventie.bind( this.img, 'error', this );
    this.img.src = this.url;
    // check if image is already complete
    var isComplete = this.getIsImageComplete();
    if ( isComplete ) {
      this.confirm( this.img.naturalWidth !== 0, 'naturalWidth' );
      this.unbindEvents();
    }
  };

  Background.prototype.unbindEvents = function() {
    eventie.unbind( this.img, 'load', this );
    eventie.unbind( this.img, 'error', this );
  };

  Background.prototype.confirm = function( isLoaded, message ) {
    this.isLoaded = isLoaded;
    this.emit( 'progress', this, this.element, message );
  };

  // -------------------------- jQuery -------------------------- //

  ImagesLoaded.makeJQueryPlugin = function( jQuery ) {
    jQuery = jQuery || window.jQuery;
    if ( !jQuery ) {
      return;
    }
    // set local variable
    $ = jQuery;
    // $().imagesLoaded()
    $.fn.imagesLoaded = function( options, callback ) {
      var instance = new ImagesLoaded( this, options, callback );
      return instance.jqDeferred.promise( $(this) );
    };
  };
  // try making plugin
  ImagesLoaded.makeJQueryPlugin();

  // --------------------------  -------------------------- //

  return ImagesLoaded;

});


//Quid de l'exécution du script dès le DOMContentLoad pour afficher a galerie au fur et à mesure ?
//=> On laisse le <script src> en fin avec on(DOMCONtentload) et à voir au besoin s'il faut vraiment interrompre plus tôt car cela impose d'inclure jQuery + script

//+ pour un affichage repide à partir du cache avec les couleurs principale il faut une évolution côté serveur 
//le code ici dans jquery-effet est appelé tard, une fois que jquery jquery ui jquery-effet sont chargés puis trigger le DOMContentLoaded 
//et si on met ce script directement dans le HTML il va manquer les dépendances jquery...
//et avec un script minime on peut avoir des carrés de couleur pendant le chargement mais FR dit non 
// <script>
// 	//<!--
// 	//
// try 
// {
// 	var t0 = window.performance.now();
// 	console.log(t0);
// 	var tab = JSON.parse(localStorage.tabInfoCache);
// }
// catch (e)
// {
// 	console.log(e);
// 	tab = [];
// }
// var parent = document.getElementById("con-A1");
// //parent.style.display = "none";
// var fils = parent.children ;
// var nLargeurTotale = 0;

// for(var i=0; 1&&i<tab.length; ++i)
// {
// 	var ref = fils[i].querySelector(".wbGalerieChpRef");
//     ref.parentNode.style.width = tab[i].twidth;
//     ref.parentNode.style.height = tab[i].theight;
//     ref.parentNode.style.backgroundColor = tab[i].color;
//     ref.parentNode.style.opacity = 1;
    
//     ref.parentNode.style.height = ref.attributes.getNamedItem("data-height").value+"px";
//     var n = parseFloat(ref.attributes.getNamedItem("data-width").value);
//     var h = parseFloat(ref.attributes.getNamedItem("data-height").value);
//     ref.parentNode.style.width = n+"px";

//     fils[i].style.height = ((parseFloat(fils[i].attributes.getNamedItem("data-height").value) - h) + h/* tab[i].theight*/)+"px";
//     fils[i].style.width = ((parseFloat(fils[i].attributes.getNamedItem("data-width").value) - n) + n/*tab[i].twidth*/)+"px";

// 	//console.log(ref.parentNode.getBoundingClientRect());
// }
// //parent.style.display = "block";
// //var s = parent.innerHTML;
// //parent.innerHTML = "";
// parent.style.display = "block";
// parent.style.margin = "0 auto";
// parent.style.width = (Math.floor(/*parent.getBoundingClientRect().width*/window.innerWidth / n) * n)  +"px";
// var t1 = window.performance.now();
// console.log(t1);
// console.log(t1-t0 + " en ms");
// //-->
// </script>

//..DuréeAnimation
$.fn.wbSetDureeAnimation = function(nNumber) 
{
	this.attr("data-wbGalerieDureeAnimation",nNumber);
};

$.fn.wbGetDureeAnimation = function(nNumber,dDureeDefaut) 
{
	var nDuree = this.attr("data-wbGalerieDureeAnimation");
	if (nDuree!==undefined)
	{
		nDuree = parseFloat(nDuree);		
		if (!isNaN(nDuree))
		{
			return nDuree;
		}
	}
	return dDureeDefaut;
};

//Init de galerie dès le DOMContentLoaded
var GALERIE_ZOOM_CANVAS = true;
var GALERIE_ZOOM_CANVAS_CLONE = true;
$(window).on("DOMContentLoaded.wb.galerie trigger.wb.plan.action.set.fin",function() //+re appeler en cas de chargement différé
{
	var jqListeGaleries = $(".wbGalerie>tbody>tr>td");
	if (!jqListeGaleries.length) return;

	//source: https://github.com/GoogleChromeLabs/ui-element-samples/blob/gh-pages/expand-collapse/demo.js	
	// From Tween.js (MIT license)
	// @see https://github.com/tweenjs/tween.js/blob/master/src/Tween.js#L480-L484
	var timingFunctionExpand = function (t) 
	{
		return --t * t * t * t * t + 1;
	};
	// From Tween.js (MIT license)
	// @see https://github.com/tweenjs/tween.js/blob/master/src/Tween.js#L480-L484
	var timingFunctionCollapse = function (t) 
	{
		if ((t *= 2) < 1) 
		{
			return 0.5 * t * t * t * t * t;
		}
		return 0.5 * ((t -= 2) * t * t * t * t + 2);
	};

	//standard curve 
	//source: https://material.io/guidelines/motion/duration-easing.html#duration-easing-natural-easing-curves						
	function dGetTempsSelonStandardCurve(now,duree)
	{
		var oBezier = new clWDUtil.WDBezier(0.4, 0.0, 0.2, 1);	
		return oBezier.dCalcule( now, duree );		
	}

	//source: https://stackoverflow.com/questions/34681457/html5-canvas-bezier-curve-get-all-the-points

	// Given the 4 control points on a Bezier curve 
	// get x,y at interval T along the curve (0<=T<=1)
	// The curve starts when T==0 and ends when T==1
	function getCubicBezierXYatPercent(startPt, controlPt1, controlPt2, endPt, percent) 
	{
	    var x = CubicN(percent, startPt.x, controlPt1.x, controlPt2.x, endPt.x);
	    var y = CubicN(percent, startPt.y, controlPt1.y, controlPt2.y, endPt.y);
	    return ({
	        x: x,
	        y: y
	    });
	}

	// cubic helper formula
	function CubicN(T, a, b, c, d) 
	{
	    var t2 = T * T;
	    var t3 = t2 * T;
	    return a + (-a * 3 + T * (3 * a - a * T)) * T + (3 * b + T * (-6 * b + b * 3 * T)) * T + (c * 3 - c * 3 * T) * t2 + d * t3;
	}

	function oGetPositionDansArc(oCssInvert,now)
	{
		//source : https://greensock.com/forums/topic/16081-material-design-effects-with-bezier-curve/
		// via : https://codepen.io/osublake/pen/oZxobX

		var p0 = oCssInvert;
		var p3 = { x : 0, y : 0};
		var p1 = {};
		var p2 = {};
		var kappa = 0.551915024494;

		var dx = p3.x - p0.x;
		var dy = p3.y - p0.y;
		  
		if (p3.y > p0.y) {
		    
		  p1.x = p0.x;
		  p1.y = p0.y + (dy * kappa);  
		  p2.x = p3.x - (dx * kappa);
		  p2.y = p3.y;
		    
		} else {
		    
		  p1.x = p0.x + (dx * kappa);
		  p1.y = p0.y;  
		  p2.x = p3.x;
		  p2.y = p3.y - (dy * kappa);
		}



		return getCubicBezierXYatPercent(p0,p1,p2,p3,now);
	}	

	//Globales à toutes les galerie 

	//cf. https://material.io/guidelines/motion/duration-easing.html#duration-easing-natural-easing-curves
	var ZOOM_DURATION_IN = 250;		    	
	var ZOOM_DURATION_IN_DELAY = 0;// pour voir un peu le rippleGalerie 
	var ZOOM_DURATION_OUT = 250;//375;
	var ZOOM_DURATION_SWIPE = 250;	

	//cf. https://material.io/guidelines/motion/movement.html#movement-movement-within-screen-bounds
	var ZOOM_MOVE_ARC = false;
	var ZOOM_MOVE_CHOREGRAPHY=false;
	var ZOOM_MOVE_OPACITY=true;//évite la superposition visible du zoom déformé sur la répétition
	var ZOOM_MOVE_CHOREGRAPHY_SYMETRIQUE=true && ZOOM_MOVE_CHOREGRAPHY;

	var PINCH_COEFF 	= 1.3;		//zoom d'un tiers	
	var LAYOUT_DURATION = 150;		

	var ZOOM_COEFF_MIN = 0.3;
	var ZOOM_COEFF_MAX = 3;	
	var fZOOM_MARGIN_HAUTEUR = function(){ return Math.min(150,0.15*window.nHauteurNavigateur); };

	//vrai si on utilise un canvas pour dessienr la répétition zoomée en vignette de fond	
	var GALERIE_ZOOM_BLUR_CANVAS = 0;//CHA dit non
	var GALERIE_ZOOM_RIPPLE = false;

	var STYLE_GALERIE_AJOUTE_DANS_PAGE = false;

	var ZOOM_EFFET_FLIP_AUTORISE = true;
	var ZOOM_EFFET_TRANSLATE_DEFAUT = true;
	var ZOOM_EFFET_TRANSLATE_SWIPE_ONLY = true;
	var ZOOM_EFFET_SCALE_DEFAUT = false;

	var MODE_COLONNE_MEME_HAUTEUR_DEFAUT = false;
	var MODE_COLONNE_MEME_HAUTEUR_NOMBRE_LIGNE_MIN = 5;//nombre de ligne minimum pour autoriser la répartition des trous

	var ZOOM_HAUTEUR_MIN = 48;//cf taille du doigt de google https://developers.google.com/speed/docs/insights/SizeTapTargetsAppropriately?hl=fr

	var CACHE_TIMER_NOTIF = 3000;//ms
	var CACHE_FOND_DATAURI = false;

	// enum ePARTIEGALERIE
	// {
	// 	ePARTIEGALERIE_MIN	= 0,
	 	var eFlechePrecedent	= 0;		//Toujours à gauche, au milieu
		var eFlecheSuivant = 1;				//Toujours à gauche, au milieu
		var eCroix = 2;						//Selon bAncrageXXX

	// 	//autre

	// 	ePARTIEGALERIE_MAX_INVALIDE
	// };	

	//force un ascenseur vertical pour éviter les problèmes du dessin qui est lancé avant le besoin d'ascenseur mais qui en crée le bsoin ensuite => galerie dans une page vierge
	$(document.body).css({overflowY : 'scroll'});

	//indice des éléments à envoyer au serveur 
	var oNotifServeurEnAttente = {};//<Objet JS avec <Clé>:"<Valeur en stringify>>
	var nIdTimerNotifCacheMisAJour;

	function fInitGalerie()
	{
		if (this.bGalerieDejaInit)
		{
			return;
		}
		this.bGalerieDejaInit = true;

		//globales sans reinit ////////////////
		//
		//Préapration de la galerie
		var jqGalerie = $(this).addClass("wbGalerieTd");//permet de retrouver facilement le td  con-A1
		var jqTableGalerie = jqGalerie.closest(".wbGalerie");
		//conserve la balise parente, utile pour déterminer la largeur disponible pour la galerie cf. nMajContainerWidth	
		var jqBalisePositionnement = jqTableGalerie.parent();

		//code sans reinit ////////////////
		//
		//flag pour activer/desactiver la répartition des trous
		var MODE_COLONNE_MEME_HAUTEUR = MODE_COLONNE_MEME_HAUTEUR_DEFAUT;
		if (MODE_COLONNE_MEME_HAUTEUR && jqTableGalerie.hasClass("wbGalerieColonneSansHauteurRepartie"))
		{
			MODE_COLONNE_MEME_HAUTEUR=false;
		}
		//autorise le flou de fond si la machine est suffisament performante 
		//Desktop uniquement 
		if (!bTouch) 
		{
			jqGalerie.addClass("wbGalerieFondFlou");
		}

		//globales avec reinit ////////////////
		//
		var jqRepetitions;
		//champs superposables dans la galerie par ligne
		var tabChampsSuperposables;
		var tabRepetitionsChampReference;
		//cache du serveur
		var	realItems;
		//liste des champs de références
		var jqRepetitionsChampReference;
		//var oOffsetGalerie = jqGalerie.offset();//TODO OPTIM offset galerie
		//mode de galerie
		var MODE_LIGNE;
		var MODE_COLONNE;
		var MODE_COLONNE_INFO;
		var lastMODE_COLONNE_INFO;
		var nbcols;
		var nDernierLargeur;
		var MODE_COLONNE_MASONRY_ONLAYOUT = undefined;
		var MODE_COLONNE_MASONRY_AVANT_LAYOUT = undefined;		

		//la hauteur min de la répétition
		var nLargeurRepetitionEdition;
		var nHauteurRepetitionEdition;

		var fPrepareFermetureDernierZoom;
		var fPrepareOuverturePremierZoom;

		//la hauteur min du champ de référence
		var nLargeurChampRefEdition;
		var nHauteurChampRefEdition;

		//infos de zoom 		
		var ZOOM_OPTIONS = undefined;
		var jqFleches = $();
		var jqFlecheSuivant = $();
		var jqFlechePrecedent = $();
		var jqCroix = $();

		var PINCH_DISTANCE 	= undefined;//PINCH_DISTANCE propritionnel à la taille des répétitions		

		//récupère les styles pour cette galerie pour cette vue
		var oInfoZoom = undefined;

		var dCoeffZoomPinch = 1;
		var dIncrementLargeurZoomPinch = 0;
		var dIncrementHauteurZoomPinch = 0;

		var eModeAffichageNav;
        var bAvecLectureOrientationEXIF;

		//ligne pour le mode ligne
		var rows = [];

		//..DuréeAnimation du champ, par défaut
		var DUREE_ANIMATION = LAYOUT_DURATION;


		//Fonctions de la galerie

		function NotifCacheMisAJour(nIndiceElemMisAJour)
		{
			var elem = realItems[nIndiceElemMisAJour];
			if (!elem || !clWDUtil.oGetImageInformations)
			{
				//blindage
				return;
			}
			//vérifie que le cache n'avait pas déjà les bonnes valeurs 
			var oCache = clWDUtil.oGetImageInformations();	
			var bCacheAJour = true;	
			//pour la petite image	
			if (  elem.id && (
				//absent du cache
				(oCache[elem.id]===undefined )
			|| 	//pas la bonne largeur dans le cache 
				(oCache[elem.id].twidth != elem.twidth)
			|| 	//pas la bonne hauteur dans le cache 
				(oCache[elem.id].theight != elem.theight)
			|| 	//pas la bonne couleur dans le cache 
				(oCache[elem.id].color != elem.color)				
			))
			{
				//conserve uniquement les données à envoyer au serveur
				oNotifServeurEnAttente[elem.id] = 
				{
					twidth : elem.twidth
				,	theight : elem.theight
				,	color : elem.color
				,	dataurl : elem.dataurl
				};	
				//il faut mettre à jour le cache
				bCacheAJour = false;	
			}

			//pour la grande image
			if (  elem.idHD && (
				//absent du cache
				(oCache[elem.idHD]===undefined )
			|| 	//pas la bonne largeur dans le cache 
				(oCache[elem.idHD].twidth != elem.iwidth)
			|| 	//pas la bonne hauteur dans le cache 
				(oCache[elem.idHD].theight != elem.iheight)
			|| 	//pas la bonne couleur dans le cache 
				(oCache[elem.idHD].color != elem.color)				
			))
			{
				oNotifServeurEnAttente[elem.idHD] = 
				{
					twidth : elem.iwidth
				,	theight : elem.iheight
				//la couleur n'est pas connue pour la grande image, et n'a d'intérêt que si elle existe directement dans la galerie
				//on prend celle déjà en cache ou celle de la vignette
				,	color : ((oCache[elem.idHD] && oCache[elem.idHD].color) ? oCache[elem.idHD].color : elem.color)
				,	dataurl : ((oCache[elem.idHD] && oCache[elem.idHD].dataurl) ? oCache[elem.idHD].dataurl : elem.dataurl)
				};	
				//il faut mettre à jour le cache de la grande image
				bCacheAJour = false;	
			}			

			if (bCacheAJour) 
			{
				//cache à jour
				return;
			}			
			//met à jour le cache local 
			clWDUtil.oGetImageInformations(oNotifServeurEnAttente);
			//annule le précédent timer de notif
			if (nIdTimerNotifCacheMisAJour)
			{
				clearTimeout(nIdTimerNotifCacheMisAJour);
			}
			//(re)lance le timer de notif
			nIdTimerNotifCacheMisAJour = setTimeout(function()
			{
				//envoie la notif au serveur
				NSPCS.NSAjax.ExecuteEvenementAsynchrone(_PAGE_, "", oNotifServeurEnAttente, 15 /*EContenuRequeteEvenement.ImageInformations*/, null);
				//raz 
				oNotifServeurEnAttente = {};
				clearTimeout(nIdTimerNotifCacheMisAJour);
				nIdTimerNotifCacheMisAJour=undefined;
			},CACHE_TIMER_NOTIF);
		}
		function nMajContainerWidth(bForceMaj)
		{
			if (bForceMaj || !jqGalerie[0].containerWidth)
			{
				//en zoning uniquement
				if (!clWDUtil.bRWD && (!jqBalisePositionnement[0].style.width || jqBalisePositionnement[0].style.width=="auto"))
				{
					//force à prendre toute la largeur
					jqBalisePositionnement.css({width:"100%"});
				}
				//prend la largeur du div de positionnement plutôt que la galerie qui peut être trop large 
				jqGalerie[0].containerWidth = jqBalisePositionnement.width();				
			}
			return jqGalerie[0].containerWidth;
		}		

		function construitZoomOptions()
		{			
			//1er zoom ?
			if (!jqGalerie[0].jqCelluleGFI)
			{
				// Ajoute la zone a la page
				$(document.body).append((jqGalerie[0].jqCelluleGFI=$(document.createElement('div'))).addClass(jqGalerie[0].id+"-GFI").on((bTouch ? "touchstart" : "click") + ".wb.galerie.zoom.ferme",function(event){
					//ferme le zoom au clic en dehors
					fFermeZoom(true);
					//évite de remonter le clic à l'image en dessous
					event.stopPropagation();
					event.preventDefault();
				}));	
			}
			var nGFITaux = window._GFI_A_===false ? 0 : (window._GFI_T_ || 60);//taux du GFI de PageTauxGFI()
			jqGalerie[0].jqCelluleGFI
			.css({
				position			: 'fixed'				
			,	width				: '100%'
			,	height				: '100%'
			,	left				: 0
			,	top					: 0
			,	zIndex				: 989
			,	pointerEvents		: ""
			,	backgroundColor		: 'rgba(102, 102, 102, ' + (nGFITaux/100) + ');'
			//pas sur opacity le GFI afin que les flèches et croix ne soient pas affectées
			});					

			if (ZOOM_OPTIONS) return;//déjà construit 
			ZOOM_OPTIONS = ZOOM_OPTIONS||jqTableGalerie.wbJsonParseAttr("data-wbGalerieOptions",true);			
			if (!ZOOM_OPTIONS) return;//blindage
			
			if (ZOOM_OPTIONS[eFlechePrecedent])
			{
				//ZOOM_OPTIONS[eFlechePrecedent].style
				//ZOOM_OPTIONS[eFlechePrecedent].surcharge
				//ZOOM_OPTIONS[eFlechePrecedent].planche
				//
				//<button type="button"  class="wbPlanBoutonPrecedent"
				//    onclick="{_JSL(_PAGE_,'A4','_self','','');} " 
				//    id="A4" class="BTN-Image wbp2etatsNS wbplanche wblien padding webdevclass-riche" 
				//    style="
				//			display:block;
				//			width:Wpx;
				//			height:Hpx;
				//			margin-top:-H/2px;
				//			position:absolute;top:50%;left:0;
				//			background-image:url(/WB21_WEB/res/btn_b6d82c881b344a7a1a916c1058117582268462de.png);
				//			-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
				//    &lt;
				//    </button>
				if (ZOOM_OPTIONS[eFlechePrecedent].planche)
				{
					ZOOM_OPTIONS[eFlechePrecedent].planche += " wbplanche";
				}
				jqFlechePrecedent = $(document.createElement('a'))
					.addClass("wbGalerieBoutonPrecedent padding"
						+ ' ' + (ZOOM_OPTIONS[eFlechePrecedent].style||"") 
						+ ' ' + (ZOOM_OPTIONS[eFlechePrecedent].surcharge||"") 
						+ ' ' + (ZOOM_OPTIONS[eFlechePrecedent].planche||"") 
					)
					.html("&lt;")
				;			
				//associe la flèche à l'affectation de plan
				jqFlechePrecedent.on((bTouch ? "touchstart" : "click") + ".wb.galerie.options.fleche.precedent",function(event){
					// if (jqFlechePrecedent.hasClass("wbgrise")) 
					// {
					// 	return;
					// }
					bZoomAvanceRecule(false);
					//évite de remonter le clic au GFI
					event.stopPropagation();
					event.preventDefault();	
				});
				//ajoutes aux nouveaux éléments qui seront insérés d'un coup dans la page
				jqFleches=jqFleches.add(jqFlechePrecedent);
			}	
			if (ZOOM_OPTIONS[eFlecheSuivant])
			{
				//ZOOM_OPTIONS[eFlecheSuivant].style
				//ZOOM_OPTIONS[eFlecheSuivant].surcharge
				//ZOOM_OPTIONS[eFlecheSuivant].planche
				if (ZOOM_OPTIONS[eFlecheSuivant].planche)
				{
					ZOOM_OPTIONS[eFlecheSuivant].planche += " wbplanche";
				}
				jqFlecheSuivant = $(document.createElement('a'))
					.addClass("wbGalerieBoutonSuivant padding"
					+ ' ' + (ZOOM_OPTIONS[eFlecheSuivant].style||"") 
					+ ' ' + (ZOOM_OPTIONS[eFlecheSuivant].surcharge||"")
					+ ' ' + (ZOOM_OPTIONS[eFlecheSuivant].planche||"") 
					)
					.html("&gt;")
				;							
				//associe la flèche à l'affectation de plan
				jqFlecheSuivant.on((bTouch ? "touchstart" : "click") + ".wb.galerie.options.fleche.suivant",function(event){
					// if (jqFlecheSuivant.hasClass("wbgrise")) 
					// {
					// 	return;
					// }
					bZoomAvanceRecule(true);
					//évite de remonter le clic au GFI
					event.stopPropagation();
					event.preventDefault();						
				});				
				//ajoutes aux nouveaux éléments qui seront insérés d'un coup dans la page
				jqFleches=jqFleches.add(jqFlecheSuivant);					
			}
			if (ZOOM_OPTIONS[eCroix])
			{
				//ZOOM_OPTIONS[eCroix].style
				//ZOOM_OPTIONS[eCroix].surcharge
				//ZOOM_OPTIONS[eCroix].planche
				if (ZOOM_OPTIONS[eCroix].planche)
				{
					ZOOM_OPTIONS[eCroix].planche += " wbplanche";
				}
				jqCroix = $(document.createElement('a'))
					.addClass("wbGalerieBoutonFermer padding"
					+ ' ' + (ZOOM_OPTIONS[eCroix].style||"") 
					+ ' ' + (ZOOM_OPTIONS[eCroix].surcharge||"")
					+ ' ' + (ZOOM_OPTIONS[eCroix].planche||"") 
					)
					.html("x")
				;							
				//associe la flèche à l'affectation de plan
				jqCroix.on( (bTouch ? "touchstart" : "click") + ".wb.galerie.options.croix.fermer",function(event){
						//ferme le zoom au clic en dehors
						fFermeZoom(true);
						//évite de remonter le clic au GFI (même si bon... le clic dans le GFI ferme également, mais par principe c'est comme ça)
						event.stopPropagation();
						event.preventDefault();						
				});				
				//ajoutes aux nouveaux éléments qui seront insérés d'un coup dans la page
				jqFleches=jqFleches.add(jqCroix);					
			}
			jqGalerie[0].jqCelluleGFI.after(jqFleches);			
		}


		function colonneMemeHauteur()
		{

			//SUGG de PAD, parallax pour aligner le mode colonne
			// $(window).off("scroll.wb.galerie.parallax");

			// requestAnimationFrame(function(){
			// var tabColonnes = {}; 
			// jqRepetitions.each(function()
			// {
			// 	if (!tabColonnes[this.style.left]) 
			// 	{ 
			// 		tabColonnes[this.style.left] = []; 
			// 	} 
			// 	tabColonnes[this.style.left].push($(this)); 
			// });

			// var tabHauteur = [];
			// var nCol = 0;
			// for(var i=0; i<tabColonnes.length; ++i)
			// {
			// 	tabHauteur[nCol] = [];

			// 	var nHauteurCumul = 0;

			// 	for(var nLigne =0; nLigne < tabColonnes[i].length; ++nLigne)
			// 	{
			// 		nHauteurCumul+= tabColonnes[i][nLigne].height();
			// 	}
			// 	tabHauteur[nCol] =nHauteurCumul;
			// 	++nCol;
			// }

			// var nMaxHauteurColonne = 0;
			// for(var j=0; j<tabHauteur.length; ++j)
			// {
			// 	nMaxHauteurColonne = Math.max(nMaxHauteurColonne, tabHauteur[j]);
			// }
			// //vs ? prend la hauteur dans le champ galerie?
			// //nMaxHauteurColonne = parseFloat(jqGalerie[0].style.height);


			// var nBordHautGalerie = jqGalerie.offset().top;

			// $(window).on("scroll.wb.galerie.parallax",function(){
			

			// if (window.nBordHautNavigateur<nBordHautGalerie) return;
			// if (window.nBordBasNavigateur>nBordHautGalerie+nMaxHauteurColonne) return;

			// var nCol = 0;
			// for(var i=0; i<tabColonnes.length; ++i)
			// {
			// 	var nHauteurDiff = nMaxHauteurColonne  - tabHauteur[nCol];

			// 	var nScrollDejaParcouru = window.nBordHautNavigateur-nBordHautGalerie;

			// 	var nScrollTotal = nMaxHauteurColonne - window.nHauteurNavigateur;

			// 	var dPourcentage = nScrollDejaParcouru / nScrollTotal;

			// 	var nTranslate = dPourcentage * nHauteurDiff;

			// 	for(var nLigne =0; nLigne < tabColonnes[i].length; ++nLigne)
			// 	{
			// 		tabColonnes[i][nLigne][0].style.transform =  "translateY(" + nTranslate + "px";					
			// 	}
			// 	++nCol;
			// }

			// });

			// });

			if (!MODE_COLONNE_MEME_HAUTEUR) return;

			//retireTransition(); ne fait pas de différence..

			//requestAnimationFrame(function(){

			var tabColonnes = {}; 
			jqRepetitions.each(function()
			{
				if (!tabColonnes[this.style.left]) 
				{ 
					tabColonnes[this.style.left] = []; 
				} 
				tabColonnes[this.style.left].push($(this)); 
			});

			var tabHauteur = [];
			var nCol=0;
			var sLeftCol='';
			for(sLeftCol in tabColonnes) 
			{
				if (!tabColonnes.hasOwnProperty(sLeftCol))
				{
					continue;
				}
			
				//si une colonne a moins de ligne que le minimum attendu pour le faire, on annule
				if (tabColonnes[sLeftCol].length<MODE_COLONNE_MEME_HAUTEUR_NOMBRE_LIGNE_MIN)
				{
					return;
				}
				tabHauteur[nCol] = [];

				var nHauteurCumul = 0;

				for(var nLigne =0; nLigne < tabColonnes[sLeftCol].length; ++nLigne)
				{
					nHauteurCumul+= tabColonnes[sLeftCol][nLigne].height();
				}
				tabHauteur[nCol] =nHauteurCumul;
				++nCol;
			}

			var nMaxHauteurColonne = 0;
			for(var j=0; j<tabHauteur.length; ++j)
			{
				nMaxHauteurColonne = Math.max(nMaxHauteurColonne, tabHauteur[j]);
			}
			//vs ? prend la hauteur dans le champ galerie?
			//nMaxHauteurColonne = parseFloat(jqGalerie[0].style.height);
			nCol=0;
			for(sLeftCol in tabColonnes) 
			{
				if (!tabColonnes.hasOwnProperty(sLeftCol))
				{
					continue;
				}

				var nHauteurDiff = nMaxHauteurColonne  - tabHauteur[nCol];
				if (tabColonnes[sLeftCol].length<2) continue;
				var nHauteurARepartir = nHauteurDiff / (tabColonnes[sLeftCol].length-1);
				var nOffsetCol = 0;
				for(var nLigne =0; nLigne < tabColonnes[sLeftCol].length; ++nLigne)
				{
					var nTop = parseFloat(tabColonnes[sLeftCol][nLigne][0].style.top);
					//pas les premiers de la colonne 
					if (nTop==0) continue;
					nOffsetCol+=nHauteurARepartir;//cumul car les lignes ne se poussent pas naturellement
					tabColonnes[sLeftCol][nLigne][0].style.top = (nTop + nOffsetCol) + "px";
					//tabColonnes[sLeftCol][nLigne].css("marginTop",nOffsetCol);
				}
				++nCol;
			}

			//appliqueTransition();

			//});

		}

		function appliqueTransition()
		{
			if (DUREE_ANIMATION>0 && MODE_COLONNE) jqRepetitions.css({transition:'top ' + DUREE_ANIMATION + 'ms,left ' + DUREE_ANIMATION + 'ms,width ' + DUREE_ANIMATION + 'ms,height ' + DUREE_ANIMATION + 'ms'});	
		}
		function retireTransition()
		{
			if (DUREE_ANIMATION>0 && MODE_COLONNE) jqRepetitions.css({transition:'none'});
		}

		//appelé en cas de changement de tranche ou de pinch afin de recalculer les dimensions de référence au positionnement
		function setDimensionsReference()
		{

			//invalide le dernier calcul de layout car le changement de tranche a changé les contraintes de layout
			jqGalerie[0].nLargeurNavigateurDernierCalcul = undefined;

			//la hauteur min de la répétition
			var jqPremiereRepetition = jqRepetitions.eq(0);
			var jqPremiereRepetitionTd = jqPremiereRepetition.find("td.wbImpaire").first();

			//LARGEUR
			nLargeurRepetitionEdition = dCoeffZoomPinch * parseInt(/*jqPremiereRepetition.attr("data-min-width")||*/jqPremiereRepetition.attr("data-width"));
			//* zoom
			nLargeurRepetitionEdition+= dIncrementLargeurZoomPinch;
			
			//HAUTEUR
			nHauteurRepetitionEdition = dCoeffZoomPinch * parseInt(/*jqPremiereRepetition.attr("data-min-height")||*/jqPremiereRepetition.attr("data-height"));
			//* zoom
			nHauteurRepetitionEdition+= dIncrementHauteurZoomPinch;

			//la hauteur min du champ de référence
			if (jqRepetitionsChampReference.get(0))
			{
				var jqDivPremierChampRef = jqRepetitionsChampReference.eq(0);//premier <img> du <i> d'homothétie ou sur le i quand il aura récupéré les attributs
				var jqPremierChampRef = jqDivPremierChampRef.children().first();//premier <img> du <i> d'homothétie ou sur le i quand il aura récupéré les attributs
				nLargeurChampRefEdition = dCoeffZoomPinch * parseInt(/*jqPremierChampRef.attr("data-min-width")||*/jqPremierChampRef.attr("data-width")||jqPremierChampRef.parent().attr("data-width")||jqPremierChampRef.width());
				nHauteurChampRefEdition = dCoeffZoomPinch * parseInt(/*jqPremierChampRef.attr("data-min-height")||*/jqPremierChampRef.attr("data-height")||jqPremierChampRef.parent().attr("data-height")||jqPremierChampRef.height());
				eModeAffichageNav = jqDivPremierChampRef.attr("data-wbModeHomothetique");
                bAvecLectureOrientationEXIF = "1"==jqDivPremierChampRef.attr("data-wbExifOrientation");
			}

			//récupère les styles pour cette galerie pour cette vue
			oInfoZoom = jqTableGalerie.wbJsonParseAttr("data-wbGalerieZoom",true);

			//personnalisation de ..DuréeAnimation => en cas de modification AJAX il faut donc ré exécuter ce code 
			DUREE_ANIMATION = jqTableGalerie.wbGetDureeAnimation(DUREE_ANIMATION);

			MODE_LIGNE = jqTableGalerie.hasClass("wbGalerieLigne");
			MODE_COLONNE = !MODE_LIGNE;

			fPrepareFermetureDernierZoom = undefined;
			fPrepareOuverturePremierZoom = undefined;
			MODE_COLONNE_INFO = undefined;
			MODE_COLONNE_MASONRY_ONLAYOUT = undefined;
			MODE_COLONNE_MASONRY_AVANT_LAYOUT = undefined;

			//raz utile pour refaire un init propre
			lastMODE_COLONNE_INFO = undefined;
			nbcols = undefined;
			nDernierLargeur=undefined;

			jqRepetitions.css({transition:'none'});
			if (MODE_COLONNE)
			{
				//notif de fin de layout
				MODE_COLONNE_MASONRY_ONLAYOUT = function() { notifieFinLayout(); colonneMemeHauteur(); }

				fPrepareOuverturePremierZoom = function()
				{
					//pas de tranisition derrière le zoom
					retireTransition();
				};
				fPrepareFermetureDernierZoom = function(nIndice)
				{
					//sauve les nouvelles valeurs de positionnement pour l'effet flip de dezoom
					var jqRepetition = jqRepetitions.eq(nIndice)
					
					//pas de transition car on veut récupérer exactement les positions pour faure le FLIP
					retireTransition();

					//TODO Debug pourquoi ce css ?
					//jqRepetition.css({width:nLargeurRepetitionEdition,height:nHauteurRepetitionEdition});
					jqRepetition.css(jqRepetition[0].oInfoTaillePositionAvantPleinEcran);
					var jqChampRef = jqRepetitionsChampReference.eq(nIndice);
					//jqChampRef.css({width:nLargeurChampRefEdition,height:nHauteurChampRefEdition});
					jqChampRef.css(jqChampRef[0].oInfoTaillePositionAvantPleinEcran);
					//if (clWDUtil.bRWD) jqChampRef.css({width : ''});
					
					//lance un layout en quittant le dernier zoom car rien n'a été fait pendant les resize pendant le zoom 
					//MODE_COLONNE_MASONRY.masonry("layout");//doit être fait sans transition 
					//masonryConstruit(false,true);
					
					//FIRST : sauve la position de l'image 
					//LAST : applique les dimensions plein écran
					fSauveFirstLast(jqRepetition,jqChampRef);

					//remet la transition après
					return appliqueTransition;
				};
				//data-galerie-colonne
				//TODO OPTIM isResizingContainer:false pour éviter l'astuce du 100% juste avant le layout
				MODE_COLONNE_INFO = $.extend({init: {isResizingContainer :true,itemSelector:'.wbGalerieTd>table'/*évite le canvas*/,isLayoutInstant : true, isInitLayout : true, isResizeBound : false, transitionDuration: 0}},jqTableGalerie.wbJsonParseAttr("data-wbGalerieColonne"));
				if (MODE_COLONNE_INFO.nLargeurColonneVariable!==undefined)
				{
					MODE_COLONNE_INFO.nLargeurColonneVariable = parseFloat(MODE_COLONNE_INFO.nLargeurColonneVariable) || nLargeurRepetitionEdition;
					//donc on ancre
					MODE_COLONNE_INFO.init.columnWidth = undefined;
					MODE_COLONNE_INFO.init.percentPosition=true;
					MODE_COLONNE_MASONRY_AVANT_LAYOUT = function()
					{		

					  if (nDernierLargeur == window.nLargeurNavigateur) return;
					  nDernierLargeur = window.nLargeurNavigateur;	

					  var l = jqGalerie.width();
					  //blindage division par 0
					  if (MODE_COLONNE_INFO.nLargeurColonneVariable===0)
				  	  {
				  		jqRepetitions.css({width:'auto'});
				  		return;
				  	  }
					  var d = l / MODE_COLONNE_INFO.nLargeurColonneVariable;					  
					  var n = parseInt(d);
					  
					  //évite de refaire le layout pour le même nombre de colonne
					  if (nbcols == n)
					  {
					    return;
					  }					  
					  nbcols = n;
					  
					  jqRepetitions.css({width:(100/nbcols)+'%'});
					  
					  //MODE_COLONNE_MASONRY.masonry("layout");					  
					};					
				}
				else if (MODE_COLONNE_INFO.nNombreColonne!==undefined)
				{
					//TODO Debug Masonry fait revenir à la ligne si les N colonnes ne rentrent plus => donc c'est un nombre de colonne MAX
					MODE_COLONNE_INFO.nNombreColonne = parseFloat(MODE_COLONNE_INFO.nNombreColonne);
					//donc on ancre
					MODE_COLONNE_INFO.init.columnWidth = undefined;
					jqRepetitions.css({width:(100/MODE_COLONNE_INFO.nNombreColonne)+'%'});
					MODE_COLONNE_INFO.init.percentPosition=true;
				}
				else 
				{
					!clWDUtil.WDDebug || clWDUtil.WDDebug.assert(MODE_COLONNE_INFO.nLargeurColonneFixe!==undefined,"mode inconnu, on force largeur fixe, nb de col variable");
					MODE_COLONNE_INFO.nLargeurColonneFixe = parseFloat(MODE_COLONNE_INFO.nLargeurColonneFixe) || nLargeurRepetitionEdition;
					//donc on centre 
					MODE_COLONNE_INFO.init.columnWidth = MODE_COLONNE_INFO.nLargeurColonneFixe;
					MODE_COLONNE_INFO.init.isFitWidth = true;
					MODE_COLONNE_INFO.init.percentPosition=false;
					MODE_COLONNE_MASONRY_ONLAYOUT = function()
					{
					  colonneMemeHauteur();
				  	 //la galerie est centrée donc l'offset est différent
				  	 //oOffsetGalerie = jqGalerie.offset();	

					  var nDernierLargeurPrecedente = nDernierLargeur;
					  nDernierLargeur = window.nLargeurNavigateur;			  
					  if (nDernierLargeur!==undefined && nDernierLargeurPrecedente <= window.nLargeurNavigateur)
					  {
						  if (nDernierLargeur !== window.nLargeurNavigateur)
						  {
					  	  	 //toutes les répétitions ont changé de taille
						     notifieFinLayout(); 
						  } 
					  	  return;//inutile en agrandissement
					  } 

					  //car le fitWidth laisse trainer un width en PX qui empêche de redimensionner plus petit
					  jqGalerie.css({width:'100%'});					  
					  jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE.masonry("layout");		
					  //oOffsetGalerie = jqGalerie.offset();
					  notifieFinLayout(); 					  
					};	
				}					
			}
		}

		function bZoomAvanceRecule(bAvance,bDemarreAnimate,bInterditEffet)
		{
			var nIndiceRepetitionZoome = jqGalerie[0].nIndiceRepetitionZoome;

			if (isNaN(nIndiceRepetitionZoome))
			{
				//pas de zoom en cours 
				return false;
			}
			
			var jqRepetitionActuelle = jqRepetitions.eq(nIndiceRepetitionZoome);

			//TODO effet de transition de zoom
			var bEffet = !bInterditEffet;
			var bEffetTranslate=ZOOM_EFFET_TRANSLATE_DEFAUT && (!ZOOM_EFFET_TRANSLATE_SWIPE_ONLY || bDemarreAnimate===false);			
			var bEffetScale=ZOOM_EFFET_SCALE_DEFAUT;			

			var nIndiceProchain = !bAvance ? nIndiceRepetitionZoome-1 : nIndiceRepetitionZoome+1;
			var jqRepetition = nIndiceProchain<0 ? undefined : jqRepetitions.eq(nIndiceProchain);
			if (!jqRepetition || !jqRepetition.length)
			{
				//pas d'autre on laisse l'actuel 

				//shake
				jqRepetitionActuelle.animate({content:1},{start : function(){this.style.animation = "shakeLight 150ms ease-out"; },done : function(){this.style.animation = ""; }});

				//bEffet = false;//pas d'effet si on reste sur le même 
				//jqRepetition = jqRepetitions.eq(nIndiceRepetitionZoome);
				return false;
			}

			//termine de force toutes les animations
			jqRepetitions.stop(true,true);

			//applique un effet sur 2 répétitions zoomées
			if (bEffet)			
			{
				jqRepetitionActuelle[0].nLargeurAParcourirZoomAvanceRecule  = (bAvance ? 1 : -1) * 
					//((window.nLargeurNavigateur/2) + (jqRepetitionActuelle.width()/2));
					//realItems[nIndiceRepetitionZoome].twidth;
					(bEffetScale
					? jqRepetitionActuelle.width()
					: window.nLargeurNavigateur
					)
				;

				jqRepetitionActuelle[0].oAnimationZoomAvanceRecule = {
					duration:ZOOM_DURATION_SWIPE
				,	start:function()
					{
						//note : l'algo est fait avant que UpdateLayoutSuperpos soit appelé pour les champs dans la galerie 
						//car UpdateLayoutSuperposableEpingle sera appelé par la galerie elle même
						afficheImages(false,true,true);
						
						//remet le zoom sur la répétition sans anim 
						fOuvreZoom(jqRepetition,false);		

						//la répétition suivante doit passer dessous
						jqRepetition.css({zIndex : 990, transformOrigin : "center 0px"});
					}
				, 	step : function(now)
					{
						jqRepetition
							//la prochaine répétition translate moins que l'actuelle
							.css({opacity : ((now)), transform : "scale(" + (bEffetScale ? (0.8+ (0.2*now) ) : 1)  +") " + (bEffetTranslate ? "translateX("+((1-now)*(this.nLargeurAParcourirZoomAvanceRecule/(bEffetScale ? 3 : 1) ) )+"px)" : "")})				
						;
						jqRepetitionActuelle
							.css({opacity : (1-now), transform : (bEffetTranslate ? "translateX("+((now)*-this.nLargeurAParcourirZoomAvanceRecule)+"px)" : "")})				
						;						
					}
				,	done : function()
					{
						fFermeZoom(false, jqRepetitionActuelle);
						//remet son opacité à 1 en miniature
						jqRepetitionActuelle.css({opacity:1,transform : ""});
						jqRepetitionActuelle[0].oAnimationZoomAvanceRecule = undefined;

						//la répétition suivante doit repasser dessus
						jqRepetition.css({zIndex : "", transformOrigin : ""});
					}
				};
				if (bDemarreAnimate!==false)
				{
					jqRepetitionActuelle.animate({content : 1}, jqRepetitionActuelle[0].oAnimationZoomAvanceRecule);
				}
			}
			else 
			{
				//sans effet, ferme le zoom, recalcule le layout et ouvre la prochaine répétition
				fFermeZoom(false)

				//note : l'algo est fait avant que UpdateLayoutSuperpos soit appelé pour les champs dans la galerie 
				//car UpdateLayoutSuperposableEpingle sera appelé par la galerie elle même
				afficheImages(false,true,true);
				
				//remet le zoom sur la répétition sans anim 
				fOuvreZoom(jqRepetition,false);
			}		
			return true;	
		}

		function notifieFinLayout(nIndiceLigne,bSynchrone)
		{
			if (tabChampsSuperposables.length)
			{
				//tout ? 
				if (nIndiceLigne===undefined)
				{
					for(var i =0; i<tabChampsSuperposables.length; ++i)
					{
						notifieFinLayout(i,bSynchrone);
					}
					return;
				}
				else 
				{
					//pas de champs superposables dans la ligne
					if (tabChampsSuperposables[nIndiceLigne].length === 0)
					{
						return;
					}
				}				
				//une ligne 
				//ça permet de calculer directement les bonnes positions pour les ancrages superposables
				bSynchrone ? UpdateLayoutSuperposableEpingle(tabChampsSuperposables[nIndiceLigne],bSynchrone) : requestAnimationFrame(function(){ UpdateLayoutSuperposableEpingle(tabChampsSuperposables[nIndiceLigne]);});
				//recalcul les homothéties
				bSynchrone ? jqRepetitionsChampReference.eq(nIndiceLigne).trigger("trigger.wb.img.homothetique.adapte") : requestAnimationFrame(function(){ jqRepetitionsChampReference.eq(nIndiceLigne).trigger("trigger.wb.img.homothetique.adapte"); });
			}
		}

		function masonryConstruit(bJoueAnimationFLIP,bPendantZoom,bDepuisOnGalerie)
		{
			// //pas de masonry pendant le zoom...
			// if (bPendantZoom)
			// {
			// 	return;
			// }

			//SUGG recréer l'instance masonry si on modifie le mode de galerie par tranche 
			//if (!MODE_COLONNE_MASONRY || jqGalerie[0].lastMODE_COLONNE_INFO!=MODE_COLONNE_INFO )
			if (!jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE || lastMODE_COLONNE_INFO!=JSON.stringify(MODE_COLONNE_INFO) )
			{
				var bExistaitDeja = !!jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE;
				if (bExistaitDeja)
				{
					jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE.off( 'layoutComplete');
					jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE.masonry( 'destroy');

					retireTransition();

					if (MODE_COLONNE_MASONRY_AVANT_LAYOUT) 
					{
						MODE_COLONNE_MASONRY_AVANT_LAYOUT();
					}					
				}
				else 
				{
					//maj la largeur du conteneur pour le 1er affichage
					nMajContainerWidth(true);

					//TODO debug 1er affichage du cas Nb de col variable largeur variable 
					//car  l'appel systématique à MODE_COLONNE_MASONRY_AVANT_LAYOUT serait mieux maux cause un chevauchement de colonnes vu sur QW#301450
					if (!bDepuisOnGalerie && MODE_COLONNE_MASONRY_AVANT_LAYOUT) 
					{
						MODE_COLONNE_MASONRY_AVANT_LAYOUT();
						jqGalerie[0].nLargeurNavigateurDernierCalcul=undefined;
						requestAnimationFrame(function(){
							//var nForceReflow = jqRepetitions.width();
							requestAnimationFrame(function(){
								onResizeGalerie();
							});
						});
						return;
					}						
				}


				jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE = jqGalerie.masonry(MODE_COLONNE_INFO.init);
				//sauve les paramètres d'init
				//jqGalerie[0].lastMODE_COLONNE_INFO = $.extend({},MODE_COLONNE_INFO);
				lastMODE_COLONNE_INFO = JSON.stringify(MODE_COLONNE_INFO);

				if (MODE_COLONNE_MASONRY_ONLAYOUT) 
				{
					jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE.on( 'layoutComplete', MODE_COLONNE_MASONRY_ONLAYOUT );
					if (bExistaitDeja)
					{
						MODE_COLONNE_MASONRY_ONLAYOUT();
						//rétablit les transitions sauf pendant le zoom
						if (!bPendantZoom)
						{
							appliqueTransition();
						}
					}
					else 
					{							
						//1er appel car il y a isInitLayout
						notifieFinLayout(undefined,true);
						colonneMemeHauteur();
					}
				}
			}
			else 
			{
				if (MODE_COLONNE_MASONRY_AVANT_LAYOUT) MODE_COLONNE_MASONRY_AVANT_LAYOUT();
				//re layout //cf isResizeBound : false
				retireTransition();
				jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE.masonry("layout");				
				//rétablit les transitions sauf pendant le zoom
				if (!bPendantZoom)
				{
					appliqueTransition();
				}
			} 
		}

		/**
		 * Distribute a delta (integer value) to n items based on
		 * the size (width) of the items thumbnails.
		 * 
		 * @method calculateCutOff
		 * @property len the sum of the width of all thumbnails
		 * @property delta the delta (integer number) to be distributed
		 * @property items an array with items of one row
		 */
		function calculateCutOff(len, delta, items) {
			// resulting distribution
			var cutoff = new Array(items.length).fill(0);
			var cutsum = 0;
			var lenTraitableReste = 0;
			//détermine la largeur totale de référence 
			var nLargeurTotaleComprimable = len;
			//répartit ce qui n'a pas pu être coupé sur les éléments en taille min
			//TODO refaire sans le floor, a priori inutile de se compliquer avec ça pour ensuite traiter les restes
			while(nLargeurTotaleComprimable>0 && Math.floor(delta-cutsum)!=0)
			{
				var dValeurPrec = cutsum;
				var lenTraitableReste=0;
				for(var i=0; i<items.length; ++i) {
					var item = items[i];
					cutsum -= cutoff[i];
					// distribute the delta based on the proportion of
					// thumbnail size to length of all thumbnails.
					var fractOfLen = item.vwidth / nLargeurTotaleComprimable;
					cutoff[i] += Math.floor(fractOfLen * (delta-dValeurPrec));
					
					//respecter les largeurs min
					if (cutoff[i]>0 && item.vwidth-cutoff[i] < nLargeurChampRefEdition)
					{
						var nCoupable = item.vwidth - nLargeurChampRefEdition;
						//retire tout jusqu'à la largeur min
						cutoff[i] = nCoupable;

					}
					else lenTraitableReste += item.vwidth;
					
					cutsum += cutoff[i];
				}
				if (dValeurPrec === cutsum || nLargeurTotaleComprimable===lenTraitableReste)
				{
					break;
				}
				nLargeurTotaleComprimable=lenTraitableReste;
			}

			// still more pixel to distribute because of decimal
			// fractions that were omitted.
			var stillToCutOff = delta - cutsum;
			//d'abord les plus grands
			while(stillToCutOff >= 1) 
			{
				var dValeurPrec = stillToCutOff;
				for(var i=0; i<cutoff.length; ++i) 
				{
					var item = items[i];	
					if (item.vwidth-cutoff[i] == nLargeurChampRefEdition)
					{
						continue;
					}		
					// distribute pixels evenly until done
					cutoff[i]++;
					stillToCutOff--;
					if (stillToCutOff <= 0) break;
				}	
				if (dValeurPrec === stillToCutOff)
				{
					break;
				}
			}
			//puis tous
			while(stillToCutOff >= 1) 
			{
				var dValeurPrec = stillToCutOff;
				//du coup on peut descendre un peu sous la largeur min
				for(var i=0; i<cutoff.length; ++i) 
				{
					var item = items[i];							
					// distribute pixels evenly until done
					cutoff[i]++;
					stillToCutOff--;
					if (stillToCutOff <= 0) break;
				}
				if (dValeurPrec === stillToCutOff)
				{
					break;
				}	
			}	
			//reste
			if (cutoff[0] && stillToCutOff>0 && stillToCutOff<1)
			{
				cutoff[0]+=stillToCutOff;
			}		
			return cutoff;
		}

		function bAdapteLargeurLigne(rows,row,items,nHauteurLigne,oInOut,bConditionSortieTrouvee,nHauteurLignePrecedente,tabLargeurPrecedent,maxwidthPrecedent,bDernierLigneSansCasSortie)
		{			
			//TODO dernière ligne ? force à prendre la hauteur min? hauteur précédente (idée de FR) ?
			//if (items.length==0 /*&& row.length===1 && nHauteurLigne>nHauteurChampRefEdition*/)//même si plusieurs images composent la dernière ligne
			if (bDernierLigneSansCasSortie && items.length===0 && rows.length>0 )
			{
				var bCasToutSurUneColonne = rows.length && row.length===1;
				for(var iRow=0; bCasToutSurUneColonne && iRow<rows.length; ++iRow)
				{
					if (rows[iRow].length>1)
					{
						bCasToutSurUneColonne=false;
						break;
					}
				}
				if (bCasToutSurUneColonne)
				{
					//force à prendre toute la largeur 
					tabLargeurPrecedent[0] = maxwidthPrecedent;
					var item = row[0];
                    //demadne de FM, la dernière ligne ne doit pas être si haute
					nHauteurLigne = Math.min(oInOut.nMaxHauteurLigne, maxwidthPrecedent * (item.theight/item.twidth));
				}
				else 
				{					
					//vu avec CHA, pour la dernière ligne, si la hauteur faisant rentrer les images n'est pas la plus grande de la galerie
					//alors on accepte cette hauteur
					//cad, la hauteur des autres lignes de la galerie devient la hauteur max de la dernière ligne
					if (nHauteurLigne>oInOut.nMaxHauteurLigne)
					{
						//nHauteurLigne reste tel quel
						nHauteurLigne = nHauteurLignePrecedente || nHauteurChampRefEdition || nHauteurLigne;
					}
					
					for(var i=0; i<row.length; ++i) 
					{
						var item = row[i];
					 	tabLargeurPrecedent[i] = Math.max(nLargeurChampRefEdition, Math.min(maxwidthPrecedent, nHauteurLigne * (item.twidth/item.theight) ));
					}
				}
			}	

			//largeurs selon la hauteur de ligne
			var len=0;
			for(var i=0; i<row.length; ++i) {
				var item = row[i];
				item.vx = 0;
				// if (nMinLargeur < nLargeurChampRefEdition)
				// {
				 	item.vwidth =  Math.min(maxwidthPrecedent, tabLargeurPrecedent[i]);
				 	item.vheight = nHauteurLigne;
				// }
				// else 
				// {						
				// 	item.vwidth =  Math.max(nLargeurChampRefEdition, Math.min(maxwidthPrecedent, nHauteurLigne * (item.twidth/item.theight) ));
				// 	item.vheight = Math.max(nHauteurChampRefEdition, item.vwidth * (item.theight/item.twidth));								
				// }
				len += item.vwidth;
			}	

			// calculate by how many pixels too long?
			var delta = len - maxwidthPrecedent;

			// if the line is too long, make images smaller
			// sauf la dernière ligne
			var cutoff = [];
			if((items.length>0 || delta>0) && row.length > 0 && delta != 0) {

				// calculate the distribution to each image in the row
				cutoff = calculateCutOff(len, delta, row);

				for(var i=0; i<row.length; ++i) {
					var pixelsToRemove = cutoff[i];
					var item = row[i];
					// shrink the width of the image by pixelsToRemove
					item.vwidth -= pixelsToRemove;
				}
			} else {
				//cas de ligne incomplète, du coup ça rentre sans rien ajuster

				//test de hauteur max ?
			}

			//respecte la largeur min ?
			for(var i=0; i<row.length; ++i) {
				var item = row[i];
				if (item.vwidth < nLargeurChampRefEdition)
				{
					return false;
				}
			}
			return true;
		}

		/**
		 * Takes images from the items array (removes them) as 
		 * long as they fit into a width of maxwidth pixels.
		 *
		 * @method buildImageRow
		 */
		function buildImageRow(maxwidthExterne, items, rows,oInOut) 
		{
			var row = [], nHauteurLigne = undefined;
			var nHauteurLignePrecedente = rows.length === 0 ? 0 : rows[rows.length-1].vheight;
			var maxwidthPrecedent = 0;
			var nLargeurTotaleImages = 0;
			var nLargeurTotaleImagesComplet = 0;
			var dProportionLargeurTotales = 0;
			var tabLargeurPrecedent = [];
			var bConditionSortieTrouvee=false;
			var item;
			while(items.length > 0)
			{	
				bConditionSortieTrouvee=false;
				//ajoute dans la ligne
				var elem = items.shift();
				row.push(elem);

				//nLargeurTotaleImages += elem.twidth;
				nLargeurTotaleImages = 0;
				nLargeurTotaleImagesComplet = 0;
				//dProportionLargeurTotales += elem.twidth/elem.theight;
				dProportionLargeurTotales = 0;

				//maxwidthExterne est la largeur de la ZR
				//mais le cumul des images doit tenir compte de ce qui entoure les images 
				var maxwidthComplet = maxwidthExterne - (nLargeurRepetitionEdition - nLargeurChampRefEdition)*row.length;
				var maxwidth = maxwidthComplet;

				var nMaxHauteur = 0;
				var nMinHauteur = undefined;
				var nMinLargeur = maxwidth;
				var bSousLargeurMin=false;
				var tabLargeur = [];

				var tabDimensions = [];
				//parcourt la ligne pour déterminer les proportions selon les rapports de proportions ou les dimensions d'édition 
				for(var iRow=0; iRow<row.length; ++iRow)
				{
					item = row[iRow];	

					// var nLargeurCalcul = item.twidth;	

					// //borné par la largeur 
					// if (item.twidth < nLargeurChampRefEdition)
					// {
					// 	nLargeurCalcul = nLargeurChampRefEdition;
					// }

					// var nHauteurCalcul = nLargeurCalcul * (item.theight/item.twidth);

					// //borné par la hauteur 
					// if (item.theight < nHauteurCalcul)
					// {
					// 	//SUGG définir une largeur max ?

					// 	nHauteurCalcul = nHauteurChampRefEdition;
					// }

					//si la largeur ou la hauteur de la source est plus petite que la dimension du champ de référence
					//on force à la taille du champ de référence
					var oDimension = {cx : item.twidth, cy : item.theight };
					if ( (item.twidth < nLargeurChampRefEdition) || (item.theight < nHauteurChampRefEdition) )
					{
						oDimension.cx = nLargeurChampRefEdition;
						oDimension.cy = nHauteurChampRefEdition;

						maxwidth -= nLargeurChampRefEdition;
					}
					else 
					{						
						nLargeurTotaleImages += oDimension.cx;
						dProportionLargeurTotales += (oDimension.cx/oDimension.cy);					
					}
					
					nLargeurTotaleImagesComplet+= oDimension.cx;

					tabDimensions.push(oDimension);

				}				
				var bAuMoinsUneSousHauteurMinEdition = false;
				//parcourt la ligne pour ajuster la hauteur
				for(var iRow=0; iRow<row.length; ++iRow)
				{
					item = row[iRow];	

					var oDimension = tabDimensions[iRow];	

					//poids selon les largeurs naturelles des images 
					//var dPoidsLargeurImg = item.twidth / nLargeurTotaleImages;
					var dPoidsLargeurImg = oDimension.cx / nLargeurTotaleImages;

					//poids selon la largeur en proportion
					//donc si une petite image paysage est à côté d'une très grande image carrée, la petite image sera affichée plus large
					//var dProportionLargeurImg = item.twidth/item.theight;
					var dProportionLargeurImg = oDimension.cx/oDimension.cy;
					dPoidsLargeurImg = dProportionLargeurImg / dProportionLargeurTotales;

					var nLargeurImgSelonPoids = dPoidsLargeurImg * maxwidth;//peut être affichée plus grande, le mode homothétique fait le reste Math.min(item.twidth, dPoidsLargeurImg * maxwidth);
					if (nLargeurImgSelonPoids < nLargeurChampRefEdition) 
					{
						nLargeurImgSelonPoids = nLargeurChampRefEdition;
					}

					//var nHauteurImgSelonSaLargeurSelonPoids = nLargeurImgSelonPoids * (item.theight/item.twidth);
					var nHauteurImgSelonSaLargeurSelonPoids = nLargeurImgSelonPoids * (oDimension.cy/oDimension.cx);
					// if (nHauteurImgSelonSaLargeurSelonPoids < nHauteurChampRefEdition) 
					// {
					// 	nHauteurImgSelonSaLargeurSelonPoids = nHauteurChampRefEdition;
					// }

					if ( (oDimension.cx === nLargeurChampRefEdition) && (oDimension.cy === nHauteurChampRefEdition) )
					{
						nLargeurImgSelonPoids = oDimension.cx;
						nHauteurImgSelonSaLargeurSelonPoids = oDimension.cy;
					}

					tabLargeur.push(nLargeurImgSelonPoids);

					nMaxHauteur = Math.max(nMaxHauteur,nHauteurImgSelonSaLargeurSelonPoids);
					//SUGG : arrêter dès qu'une image dans la ligne est moins haute que la hauteur min
					if (nMaxHauteur<nHauteurChampRefEdition)
					{
						bAuMoinsUneSousHauteurMinEdition=true;
					}
					nMinHauteur = nMinHauteur===undefined ? nHauteurImgSelonSaLargeurSelonPoids : Math.min(nMinHauteur,nHauteurImgSelonSaLargeurSelonPoids);
					nMinLargeur = Math.min(nMinLargeur,nLargeurImgSelonPoids);
				}

				var nHauteurLigneCourante = Math.max(nHauteurChampRefEdition,nMinHauteur);//ou nMaxHauteur

				bConditionSortieTrouvee = /*(nLargeurTotaleImagesComplet>maxwidthComplet) ||*/  (nMinLargeur < nLargeurChampRefEdition) || (bAuMoinsUneSousHauteurMinEdition ||nMaxHauteur < nHauteurChampRefEdition);
				var bCetteLigneRespecteLargeurMin = bAdapteLargeurLigne(rows,row,items,nHauteurLigne,oInOut,bConditionSortieTrouvee,nHauteurLigne,tabLargeur.slice()/*copie*/,maxwidthComplet,false);

				//on est passé sous la hauteur min ou sous la largeur min
				if (!bCetteLigneRespecteLargeurMin || bConditionSortieTrouvee)
				{
					//on quitte, on garde la hauteur précédente
					//et on remet l'item dans la liste car il ne sera pas dans cette ligne
					if (row.length==1)
					{
						//TODO seul ?

						//1 seule image présente et elle est déjà moins haute que la hauteur min 
						//on force la hauteur min
						nHauteurLigne = nHauteurChampRefEdition;
						tabLargeurPrecedent[0] = nLargeurChampRefEdition;

						
						// row[0].vwidth =  maxwidth;
						// row[0].vheight = item.vwidth * (item.theight/item.twidth);					
					} 
					else
					{
						// //prend la plus petite hauteur pour les images homothétiques sans agrandissement
						// if 
						// (
						// 	//mode sans agrandissement sans étendu 
						// 	(
						// 		(eModeAffichageNav >= eIMG_MODE.imgNavigateurCentre)
						// 	&&
						// 		(eModeAffichageNav < eIMG_MODE.imgNavigateurAdapte) 
						// 	)

						//  && 
						//  	//hauteur suffisante pour dépasser la contrainte de taille min d'édition
						//  	nMinHauteur>nHauteurChampRefEdition
						//  )
						// {
						// 	nHauteurLigne = Math.max(nHauteurChampRefEdition,nMinHauteur);
						// }
						items.unshift(row.pop());
					}
					bConditionSortieTrouvee=true;
					break;
				}		

				tabLargeurPrecedent = tabLargeur;
				maxwidthPrecedent = maxwidthComplet;

				//sauve la hauteur pour qu'en quittant on ait la dernière hauteur calculée
				nHauteurLigne = nHauteurLigneCourante;
			}

			bAdapteLargeurLigne(rows,row,items,nHauteurLigne,oInOut,bConditionSortieTrouvee,nHauteurLignePrecedente,tabLargeurPrecedent,maxwidthPrecedent || maxwidthComplet,items.length===0);

			oInOut.nMaxHauteurLigne = Math.max(oInOut.nMaxHauteurLigne,nHauteurLigne);
			oInOut.nOffsetIndice += row.length;

			return row;	

		}

		/**
		 * Updates an exisiting tthumbnail in the image area. 
		 */
		function updateImageElement(item,iIndice,jqRepetition,jqChampRef,oOffset,bDepuisPinch,bJoueAnimationFLIP) {

			var bDepuisCreate = !item.bDejaCree;
			item.bDejaCree=true;
			// //évite l'astuce de fond pendant le chargement de l'image
			// if (jqChampRef[0].complete)
			// {
			// 	if (jqChampRef[0].src != imgVide)
			// 	{
			// 		jqChampRef.css({
			// 			backgroundImage			:"url('" + jqChampRef[0].src + "')"		
			// 		});			
			// 	}
			// 	//l'image devient vide pour qu'on y voit son fond
			// 	jqChampRef.attr("src",imgVide);
			// }

			var oLastUpdate = jqRepetition[0].lastUpdate ? jqRepetition[0].lastUpdate.repetition : undefined;
			var bAnimate = DUREE_ANIMATION>0 && bJoueAnimationFLIP && !bDepuisCreate && !!oLastUpdate;
			var bDemarreAnimate = bAnimate && !bDepuisPinch;

			var nLargeur = (nLargeurRepetitionEdition-nLargeurChampRefEdition+(item.vwidth|| 120));
			var nHauteur = (nHauteurRepetitionEdition-nHauteurChampRefEdition+(item.vheight|| item.theight|| 120));

			var oCssRepetition = {
				width 					: nLargeur
			,	height					: nHauteur
			,	top 					: oOffset.nOffsetTop
			,	left 					: oOffset.nOffsetLeft
			};

			if (bAnimate) 
			{
				//annule l'anim d'avant et place un délai
				;
			    
			    // Update the invert values.
			    var oCssInvert = {};
			    oCssInvert.x = oLastUpdate.left - oCssRepetition.left;
			    oCssInvert.y = oLastUpdate.top - oCssRepetition.top;
			    oCssInvert.sx = oLastUpdate.width / oCssRepetition.width;
			    oCssInvert.sy = oLastUpdate.height / oCssRepetition.height;

			    oCssRepetition.transformOrigin = '0 0';
			    oCssRepetition.transform = "translate(" + oCssInvert.x +"px, " + oCssInvert.y + "px) scale("+oCssInvert.sx+", "+oCssInvert.sy+")";	
			}

			//TODO changer pour utiliser le mode homothétique étendu centré navigateur de force
			jqChampRef.css({
				width 					:item.vwidth
			,	height					:(item.vheight || item.theight)
			});
			if (clWDUtil.bRWD) jqChampRef.css({width : ''});

			jqRepetition.css(oCssRepetition);

			if (bAnimate)
			{

				//callback d'animation
				jqRepetition[0].onAnimateStep = function (remappedTime)
				{
					var update = {
						x: oCssInvert.x * (1 - remappedTime),
						y: oCssInvert.y * (1 - remappedTime),
						sx: oCssInvert.sx + (1 - oCssInvert.sx) * remappedTime,
						sy: oCssInvert.sy + (1 - oCssInvert.sy) * remappedTime
					};

					this.style.transform = "translate(" + update.x +"px, " + update.y + "px) scale("+update.sx+", "+update.sy+")";						
				};

				jqRepetition[0].onAnimationStart = function()
				{
					jqRepetition
					//.delay(30*iIndice) //CHA AMO : c'est horrible
					.animate({content:1},
					{
						//demande de CHA, réduire à 150ms comme pinterest
						duration : DUREE_ANIMATION
					,	step : jqRepetition[0].onAnimateStep
					, 	done : function() 
						{
							//raz la callback
							this.onAnimateStep=undefined;
							//fait en double ? pourtant ça semble utile...
							//cette répétition a changé de taille
							notifieFinLayout(iIndice); //ASYNC, 2 fois plus performance pendant le pinch
						}
					})
					;
				};

				if (bDemarreAnimate)
				{
					//arrête là toute animation
					jqRepetition.stop(true,true);
					jqRepetition[0].onAnimationStart();
				}
			}

			//décale les suivants de la ligne
			oOffset.nOffsetLeft+=nLargeur;

			//sauve l'item utilisé (copie)
			jqRepetition[0].lastUpdate = { item : $.extend({},item) , repetition : $.extend({},oCssRepetition) };

			//cette répétition a changé de taille
			notifieFinLayout(iIndice);//ASYNC, 2 fois plus performance pendant le pinch

			return nHauteur;
		}	

		//stocke les dimensions réellement chargées dans data wbGalerieChpRefImg
		function wbOnLoadGalerieImg(jqDivImg,iElem)
		{
			if (jqGalerie.hasClass("wbGalerieChargementVignetteImage")) return;//blindage pour vignette
			var domImg = jqDivImg.get(0).firstElementChild;
			//ignore l'image vide
			//if (domImg.src == imgVide) return;

			var img = new Image();
			var nIndiceElem = iElem;
			function fOnLoad(bDepuisOnError) 
			{		
				var domThis = this;	
				var jqChampRef = jqRepetitionsChampReference.eq(nIndiceElem);

				//TODO OPTIM : en cas de fermeture du zoom d'une vignette, on redéclenche le onload en réaffectant le src de vignette (qui était à la valeur de la grande image pendant le zoom)
				//console.log(jqChampRef[0].src + "chargé, ordre visuel " + jqChampRef.closest(".wbGalerieTd>table").index() );
				//wbGalerieChpRefImgFaireOnLoad est faux sauf si on est dans le cas d'erreur de l'image à chargement différé
				jqChampRef[0].firstElementChild.wbGalerieChpRefImgFaireOnLoad=bDepuisOnError&&jqChampRef[0].firstElementChild.attributes.getNamedItem("data-original");	
				
				//inutile si l'image n'a pas été trouvée (erreur 404)
				if (bDepuisOnError)
				{
					return;
				}
				
				var elem = realItems[nIndiceElem];
				if (!elem.color)
				{
					try 
					{
						//calcule un flou et une couleur principale
						requestAnimationFrame(function(){//rAF pour ne pas bloquer le DOMContentLoad
							var colorThief = new ColorThief();		
							//vignette façon facebook https://code.facebook.com/posts/991252547593574/the-technology-behind-preview-photos/
							var oVignetteDataURL = CACHE_FOND_DATAURI ? { width : 42, height : Math.round(42*(domThis.height/domThis.width)), dataurl : '', quality : 0.92, radius : 10 } : undefined;
                            try {
    							elem.color="rgb(" + colorThief.getColor(domThis,false/*optim sans appendChild*/,undefined, oVignetteDataURL).join(",") + ")";
                            }catch (e) 
                            {
                                elem.color="rgb(255,255,255)";
                                !clWDUtil.WDDebug||clWDUtil.WDDebug.assert(false,e);
                            }
							if (CACHE_FOND_DATAURI)
							{
								elem.dataurl = oVignetteDataURL.dataurl;	
							}
							jqDivImg.css({opacity : 1/*pour test en l'absence de cache , backgroundColor : elem.color */});				
							jqChampRef[0].firstElementChild.wbGalerieChpRefImgCouleurFondDejaFaite=true;

							//indique que le cache a été mis à jour
							NotifCacheMisAJour(nIndiceElem);
						});
					} 
					catch (e) 
					{
						!clWDUtil.WDDebug||clWDUtil.WDDebug.assert(false,e);
					}
				}

				jqGalerie.data("wbGalerieRelayoutRequis",true);

				var elem = realItems[nIndiceElem];
				//trouve les dimensions de l'image chargée
				elem.twidth=domThis.naturalWidth||domThis.width||nLargeurChampRefEdition;
				elem.theight=domThis.naturalHeight||domThis.height||nHauteurChampRefEdition;

                function _finOnload()
                {                    
    				//indique que le cache a été mis à jour
    				NotifCacheMisAJour(nIndiceElem);

    				//image présente donc inutile de garder la couleur de fond 
    				jqDivImg.css({backgroundColor : ""});					

    				//relance le calcul
    				//rAF pour laisser passer les onload à la chaîne et faire un seul afficheImages
    				requestAnimationFrame(function(){
    					if (jqGalerie.hasClass("wbGaleriePleinEcranEnCours"))
    					{
    						//sera fait en fermeture de zoom
    						return;
    					}
    					if (jqGalerie.data("wbGalerieRelayoutRequis"))
    					{
    						//évite de le faire pour chaque image 
    						jqGalerie.data("wbGalerieRelayoutRequis",!afficheImages());
    					}
    				});
                }

                //inverse les dimensions selon l'orientation 
                if (bAvecLectureOrientationEXIF)
                {
                    getOrientation(domImg.src, function(orientation){
                        if (orientation > 4)
                        {
                            var tmp = elem.twidth
                            elem.twidth = elem.theight;
                            elem.theight=tmp;
                        }
                        _finOnload();
                    });
                }   
                else 
                {
                    _finOnload();
                }             
			}
			//l'image est utilisable immediatement
			if (domImg.naturalWidth && domImg.naturalHeight)
			{
				fOnLoad.apply(domImg,[]);
				return;
			}
			//pas d'image pas de chargement (se produit en cas de chargement différé, le src est initialement vide)
			if (!domImg.src)
			{
				fOnLoad.apply(this,[true]);
				return;
			}
			//l'image doit être chargée
			img.onload = fOnLoad;
			img.onerror = function() { fOnLoad.apply(this,[true]); }
			//charge l'image pour déterminer ses dimensions
			img.src = domImg.src;
		}

		var afficheImages = function (bDepuisPinch,bJoueAnimationFLIP,bPendantZoom,bDepuisOnGalerie) {

			//if (jqGalerie.hasClass("wbGaleriePleinEcranEnCours")) return;//évite le layout alors qu'il y a un plein écran
			if (bJoueAnimationFLIP===undefined) bJoueAnimationFLIP=true;
			var nNbItemsDispoConsecutifs = 0;
			//parcourt les éléments fournis par le serveur (cache)
			//et assure que les dimensions sont définies			
			var bAuMoinsUneImageEnAttente = false;
			for(var iElem=0; iElem<realItems.length; ++iElem)
			{
				var elem = realItems[iElem];
				var jqChampRef=jqRepetitionsChampReference.eq(iElem);
				var domDivHomothetiqueNav = jqChampRef.get(0);
				if (!domDivHomothetiqueNav) { ++nNbItemsDispoConsecutifs; continue; }//blindage
				var domImg = domDivHomothetiqueNav.firstElementChild;
				//pas de taille en cache ?
				if (elem.src!=domImg.src || elem.twidth===undefined || elem.theight===undefined)
				{
					//utilise arbirtrairement la taille d'édition (du champ de référence)
					elem.twidth = nLargeurChampRefEdition;
					elem.theight = nHauteurChampRefEdition;		
					elem.src = domImg.src;	//TODO remplacer par le hash serveur ?	
					domImg.wbGalerieChpRefImgFaireOnLoad=true;
				}
				else if (!domImg.wbGalerieChpRefImgCouleurFondDejaFaite)
				{
					domImg.wbGalerieChpRefImgCouleurFondDejaFaite=true;
					domImg.wbGalerieChpRefImgFaireOnLoad=true;
					jqChampRef.css({opacity : 1, backgroundColor : elem.color, backgroundImage : (elem.dataurl ? ("url('" + elem.dataurl + "')") : undefined), backgroundSize : 'cover' });		

					if (jqTableGalerie.hasClass("wbGaleriePleinPinch"))
					{
						//création d'un niveau de calque par répétition pour que les chevauchements soient dans leur ordre d'indice (sinon les champs superposables dans les répétitions passent au dessus)		
						jqRepetitions.eq(iElem).find("td").first().css({transformStyle : "preserve-3d", transform : "translateZ(" + (iElem+1) + "px)" });
						//TODO PINCH ce niveau de calque impose sous iOS d'avoir un translateZ sur tous les éléments avec zIndex 
						//comme par exemple une zone épinglé, le GFI, et la répétition zoomée => cela va au delà de la galerie elle même (un hook jquery sur zIndex ne suffit pas)
					}
				}

				//le champ de référence est il chargé ?
				var bCetteImageEstEnAttente = false;
				if (domImg.wbGalerieChpRefImgFaireOnLoad)
				{	
					bCetteImageEstEnAttente = true;
					//maj les dimensions du cache au chargement (une seule fois)
					if (!domImg.wbGalerieChpRefImgDejaOnLoadBind)
					{
						domImg.wbGalerieChpRefImgDejaOnLoadBind=true;	

						domImg.wbGalerieIndiceChpRef = iElem;//scope
						//fait systématiquement le bind pour gérer les modif navigateur
						$(domImg).on("load error",function()
						{
							wbOnLoadGalerieImg($(this.parentNode)/*parent est le div d'homothétie navigateur*/,this.wbGalerieIndiceChpRef);
							//jqImg.data("wbGalerieChpRefImg" est setté
						});					

						//img renseignée (pas différée) et déjà chargée, depuis le cache ?
						if (domImg.complete)
						{
							//il y a une source 
							if (domImg.src)
							{
								// //appelle le pcode de onload
								// if (jqChampRef[0].firstElementChild.onload)
								// {
								// 	jqChampRef[0].firstElementChild.onload.apply(jqChampRef[0],[]);
								// }
								//màj de suite les dimensions du cache
								wbOnLoadGalerieImg(jqChampRef,iElem);
								//jqImg.data("wbGalerieChpRefImg" est setté
							}
							//pas de source et image différée 
							else if (domImg.attributes.getNamedItem("data-original"))	
							{
								//considère que cette image n'est pas en attente
								bCetteImageEstEnAttente=false;
							}	
						}
						
					}	
					//img renseignée (pas différée) et déjà chargée mais pas de onload appelé...
					else if (domImg.complete && domImg.src)
					{
						bCetteImageEstEnAttente=false;
						// //appelle le pcode de onload
						// if (jqChampRef[0].firstElementChild.onload)
						// {
						// 	jqChampRef[0].firstElementChild.onload.apply(jqChampRef[0],[]);
						// }						
						//màj de suite les dimensions du cache
						wbOnLoadGalerieImg(jqChampRef,iElem);
						//jqImg.data("wbGalerieChpRefImg" est setté
					}	
				}
					
				if (bCetteImageEstEnAttente)
				{
					bAuMoinsUneImageEnAttente=true;
				}
				if (!bAuMoinsUneImageEnAttente)
				{
					++nNbItemsDispoConsecutifs;
				}
			}
			//aucune image chargée 
			//le layout a déjà été fait pour cette taille	
			window.nLargeurPage=window.nLargeurPage || $(document.body).width();
			window.nLargeurNavigateur=window.nLargeurNavigateur || $(window).width();
			if (nNbItemsDispoConsecutifs==0 
				|| 
				(
						(this.nNbImagesDejaChargeesDansDernierLayout && this.nNbImagesDejaChargeesDansDernierLayout===nNbItemsDispoConsecutifs)
					&& 	(this.nLargeurPageDernierCalcul && this.nLargeurPageDernierCalcul == window.nLargeurPage)
					&& 	(this.nLargeurNavigateurDernierCalcul && this.nLargeurNavigateurDernierCalcul == window.nLargeurNavigateur)
					&&   !bDepuisPinch
				)
			)
			{
				return false;
			}

			this.nLargeurPageDernierCalcul 			=  window.nLargeurPage;
			this.nLargeurNavigateurDernierCalcul 	=  window.nLargeurNavigateur;
			//note le nombre d'images présentes lors du dernier  calcul 
			this.nNbImagesDejaChargeesDansDernierLayout=nNbItemsDispoConsecutifs;

			//console.log("GALERIE : LAYOUT");

			//ajoute le style avant afin que nMajContainerWidth traite bien le style effectif au final
			ajouteStyle();
			
			//soit en ligne soit en colonne
			if (MODE_LIGNE)
			{
				// Make a copy of the array
				var items = realItems.slice();
				// calculate rows of images which each row fitting into
				// the specified windowWidth.
				rows = [];
				var nOffsetIndice = 0;
				var nMaxHauteurLigne = 0;
				var oINOUT = {nMaxHauteurLigne  : 0, nOffsetIndice : 0};
				while(items.length > 0) 
				{
					rows.push(buildImageRow(nMajContainerWidth() , items, rows,oINOUT));					
				}
				//console.log("GALERIE : " + rows.length + " LIGNE(S)");
				var oOffset = {nOffsetLeft:0,nOffsetTop:0};
				var iIndice = 0;
				var nHauteurElement = 0;
				for(var r=0; r<rows.length; ++r) {
					oOffset.nOffsetLeft = 0;			
					for(var i=0; i<rows[r].length; ++i) {
						var item = rows[r][i];
						nHauteurElement=updateImageElement(item,iIndice,jqRepetitions.eq(iIndice),jqRepetitionsChampReference.eq(iIndice),oOffset,bDepuisPinch,bJoueAnimationFLIP);
						++iIndice;
					}
					oOffset.nOffsetTop+=nHauteurElement;
				}

				//pas de ligne ?
				if (rows.length===0)
				{
					//pas de galerie
					return false;
				}

				//règle la hauteur 
				jqGalerie.add(jqTableGalerie).css({height : oOffset.nOffsetTop});//, opacity : 1});
			}
			else 
			{
				masonryConstruit(bJoueAnimationFLIP,bPendantZoom,bDepuisOnGalerie);
			}
			if (!bAuMoinsUneImageEnAttente)
			{
				//rend visible le 1er affichage complet
				jqTableGalerie.addClass("wbGalerieComplete");
			}

			clWDUtil.WDDebug.log("realItems",realItems);

			jqGalerie.trigger("trigger.wb.galerie.layout.fin",bAuMoinsUneImageEnAttente);

			return bAuMoinsUneImageEnAttente;
		};
		//permet d'avoir this dans les appels à afficheImages
		afficheImages = afficheImages.bind(this);

		function ajouteStyle ()
		{
			if (STYLE_GALERIE_AJOUTE_DANS_PAGE) return; STYLE_GALERIE_AJOUTE_DANS_PAGE=true;			
			//Les proportions de la répétition proviennent du champ de référence. Tout ce qui dépasse sera tronqué.
			//note : le faire ici évite d'appliquer ces styles à la galerie avant que le JS soit exécuté avec une 1ère mise en page calculée
			$("head").append($('<style>.wbGalerie,.wbGalerie>tbody,.wbGalerie>tbody>tr,.wbGalerie>tbody>tr>td,td#' + (jqGalerie[0].id||'___') + '{ position:relative;width: 100%;display: block;margin: 0 auto;min-width: 0;}</style>'))
			//que pour la galerie en ligne
			$("head").append($('<style>.wbGalerieLigne .wbGalerieTd>table, .wbGalerieLigne .wbGalerieTd>table>tbody, .wbGalerieLigne .wbGalerieTd>table>tbody>tr, .wbGalerieLigne .wbGalerieTd>table>tbody>tr>td{display: block; overflow:hidden; clear:none !important; width:100%;height: 100%; position:absolute;will-change:top,left,width,height,transform;}</style>'))
		}

		function onResizeGalerie() 
		{
			if (jqGalerie[0].wbGalerieLayoutEnCours===true)
			{
				return;
			}
			//aucun timer en attente?
			if (jqGalerie[0].wbGalerieLayoutTimer===undefined) 
			{	
				
			}
			else
			{	//non=> il faut donc annuler le précédent timer
				cancelAnimationFrame(jqGalerie[0].wbGalerieLayoutTimer);
				//clearTimeout(jqGalerie[0].MajLargeurTrouVoletTimer);
			}	

			//màj la largeur 
			nMajContainerWidth(true);
			//oOffsetGalerie = jqGalerie.offset();

			//applique le layout
			jqGalerie[0].wbGalerieLayoutTimer = requestAnimationFrame(function()//demande de CHA, pas de timeout trop important
			//jqGalerie[0].wbGalerieLayoutTimer = setTimeout(function()
			{					
				jqGalerie[0].wbGalerieLayoutEnCours=true;
				
				var nIndiceRepetitionZoome = fFermeZoom(false);

				//note : l'algo est fait avant que UpdateLayoutSuperpos soit appelé pour les champs dans la galerie 
				//car UpdateLayoutSuperposableEpingle sera appelé par la galerie elle même
				afficheImages(false,nIndiceRepetitionZoome===false,nIndiceRepetitionZoome!==false,true);				

				if (nIndiceRepetitionZoome!==false)
				{
					//remet le zoom sur la répétition sans anim 
					fOuvreZoom(jqRepetitions.eq(nIndiceRepetitionZoome),false);
				}
				jqGalerie[0].wbGalerieLayoutEnCours=undefined;				
				jqGalerie[0].wbGalerieLayoutTimer=undefined;				
			});
			//},300);
		};
		
		function fOnModifGalerie()
		{
			//s'il y a des nouvelles lignes de ZR
			if (jqGalerie.children().filter(function(){return !this.style.position || (this.style.position === 'static');}).length)
			{
				//évite de le faire plusieurs fois pour la même galerie
				if (jqGalerie[0].wbGalerieOnModifTimer!==undefined)
				{
					cancelAnimationFrame(jqGalerie[0].wbGalerieOnModifTimer);
					jqGalerie[0].wbGalerieOnModifTimer=undefined;
				}
				jqGalerie[0].wbGalerieOnModifTimer= requestAnimationFrame(function() {  fReInit.apply(jqGalerie[0],[true]); 	});//init puis fait afficheImages();				
			}
			else  
			{
				afficheImages();
			}
		}


		function fFermeZoom(bJoueAnimationFLIP,jqRepetitionForce)
		{
			if (!ZOOM_EFFET_FLIP_AUTORISE) bJoueAnimationFLIP =false;
			if (!jqGalerie.hasClass("wbGaleriePleinEcranEnCours"))
				return false;

			var jqRepetition = jqRepetitionForce || jqGalerie.find(".wbGaleriePleinEcran").first();
			jqRepetition.removeClass("wbGaleriePleinEcran");
			var nIndice = jqRepetition.index();
			var jqChampRef = jqRepetitionsChampReference.eq(nIndice);
			jqChampRef.stop(true,true);
			jqRepetition.stop(true,true);//pour appeler done

			//en fin de zoom on retire l'image vignette
			if (jqChampRef[0].fRestaureImageVignette && !jqGalerie.hasClass("wbGalerieChargementVignetteImage"))
			{
				jqChampRef[0].fRestaureImageVignette();
			}
			
			//traitement fin zoom (et pas pendant un ferme/rouvre zoom de navigation ou resize)
			var fFinZoom = (bJoueAnimationFLIP && fPrepareFermetureDernierZoom) ? fPrepareFermetureDernierZoom(nIndice) : undefined;

			//LAST
			jqChampRef.css(jqChampRef[0].oInfoTaillePositionAvantPleinEcran);
			if (clWDUtil.bRWD) jqChampRef.css({width : ''});
			jqRepetition.css(jqRepetition[0].oInfoTaillePositionAvantPleinEcran);

			//supprime le canvas à l'emplacement initial 
			function fRetireCanvas()
			{
				//garde le canvas pendant la transition petite image -> grande image de champ vignette
				if (jqGalerie.hasClass("wbGalerieChargementVignetteImage"))
				{
					return;
				}

				if (jqRepetition[0].canvas) 
				{
                    // note : en cas de ZoneRépétéeSupprime de cette répétition au moment du dézoom (pendant l'animation) il est possible que jqRepetition[0].canvas soit sans parent
					jqRepetition[0].canvas.remove();
					jqRepetition[0].canvas=undefined;
				}
				if (jqRepetition[0].canvasFond) 
				{
					jqRepetition[0].canvasFond.remove();
					jqRepetition[0].canvasFond=undefined;
				}
			}			
			//jqGalerie.children("canvas").remove(); non car il faut garder les canvas des autres

			//notification de fermeture (pour LST)
			jqTableGalerie.trigger("trigger.wb.galerie.zoom.fin",nIndice);

			//recalcul les champs superposables
			notifieFinLayout(nIndice,true);//SYNCHRONE

			if (bJoueAnimationFLIP)
			{
				//INVERT
			    var oCssInvert = {};

				//transpose les positions de absolute vers fixes 
				var oOffsetGalerie = jqGalerie.offset();//TODO OPTIM offset galerie
			    oCssInvert.x = jqRepetition[0].oInfoTaillePositionApresPleinEcran.left + window.nBordGaucheNavigateur - jqRepetition[0].oInfoTaillePositionAvantPleinEcran.left - oOffsetGalerie.left;
			    oCssInvert.y = jqRepetition[0].oInfoTaillePositionApresPleinEcran.top   + window.nBordHautNavigateur -  jqRepetition[0].oInfoTaillePositionAvantPleinEcran.top - oOffsetGalerie.top;
			    oCssInvert.sx = jqRepetition[0].oInfoTaillePositionApresPleinEcran.width / jqRepetition[0].oInfoTaillePositionAvantPleinEcran.width;
			    oCssInvert.sy = jqRepetition[0].oInfoTaillePositionApresPleinEcran.height / jqRepetition[0].oInfoTaillePositionAvantPleinEcran.height;

			    jqRepetition.css({
		    		transformOrigin : '0 0'
		    	,	transform :"translate(" + oCssInvert.x +"px, " + oCssInvert.y + "px) scale("+oCssInvert.sx+", "+oCssInvert.sy+")"
		        }); 

			    //remet d'aplomb les champs superposable ???
		        //!UpdateLayoutSuperposableEpingle || UpdateLayoutSuperposableEpingle();

		        var jqElementAvecOpacite = jqRepetition.find("*").not(jqChampRef.parents().add(jqChampRef));
				//PLAY
				jqRepetition.animate({content:1},{
					duration : ZOOM_DURATION_OUT
				,	easing : "linear"
					//callback d'animation
				,	step : function (now)
				{

						var remappedTime = dGetTempsSelonStandardCurve(now, ZOOM_DURATION_OUT);
						//source : https://material.io/guidelines/motion/choreography.html#choreography-continuity
						//var remappedTimeX = (remappedTime<=(50/375)) ? 0 : Math.min(1,(remappedTime-(50/375))/(325/375));
						//var remappedTimeY = Math.min(1,remappedTime/ (325/375));
						//mais finalement je prends des valeurs au pif
						var remappedTimeX = new clWDUtil.WDBezier(0.55, 0.06, 0.68, 0.19).dCalcule( now, ZOOM_DURATION_OUT );//Math.min(1,remappedTime/ (275/375));
						var remappedTimeY = new clWDUtil.WDBezier(0.4, 0, 1, 1).dCalcule( now, ZOOM_DURATION_OUT );						
						
						//Arc downward 
						if (oCssInvert.y>0)
						{
							var tmp = remappedTimeY;
							remappedTimeY=remappedTimeX;
							remappedTimeX = tmp;
						}

						var remappedTimeW = remappedTimeY;
						var remappedTimeH = ZOOM_MOVE_CHOREGRAPHY_SYMETRIQUE ? remappedTimeY : remappedTimeX;

						//var remappedTimeOpacity = (remappedTime<=0.2) ? 0/*( (0.2-remappedTime) /0.2 )*/ : Math.min(1,(remappedTime-0.2)/0.4);
						var remappedTimeOpacity = remappedTime>=0.9 ? 1 : ((remappedTime<=0.5) ? 0/*( (0.2-remappedTime) /0.2 )*/ : Math.min(1,(remappedTime-0.5)/0.4));
						
						if (ZOOM_MOVE_OPACITY)
						{
							jqElementAvecOpacite.css("opacity",remappedTimeOpacity);
						}
						if (!ZOOM_MOVE_CHOREGRAPHY)
						{
							remappedTimeX = remappedTimeY = remappedTimeW = remappedTimeH = remappedTime;
						}
						
						var update = {
							x: oCssInvert.x * (1 - remappedTimeX),
							y: oCssInvert.y * (1 - remappedTimeY),
							sx: oCssInvert.sx + (1 - oCssInvert.sx) * remappedTimeW,
							sy: oCssInvert.sy + (1 - oCssInvert.sy) * remappedTimeH
						};

						//mouvement d'arc
						if (ZOOM_MOVE_ARC)
						{
							update.x=oGetPositionDansArc(oCssInvert,remappedTimeX).x;
							update.y=oGetPositionDansArc(oCssInvert,remappedTimeY).y;
						}

						this.style.transform = "translate(" + update.x +"px, " + update.y + "px) scale("+update.sx+", "+update.sy+")";

						//s'il y a un canvas clone, on fait un fadeOut pour éviter le décalage de backgroundImage 
						//car le cover par scale n'est pas équivalent, ça permet de disparaître au prodit du clone qui a un cover correct 
						//puis en fin d'anim de redevenir opaque et retirer le clone
						if (GALERIE_ZOOM_CANVAS_CLONE && jqRepetition[0].canvas) 
						{
							if (remappedTime>=0.9)
							{
								this.style.opacity=1-((remappedTime-0.9)/0.1);
							}
						}						
					}
				//force à être au dessus de la galerie pendant le zoomout
				,	start : function() 
					{
						jqRepetition.css({zIndex : 999});						
					}
				,	done : function()
					{								

						jqRepetition.css({zIndex : ""}); !fFinZoom||fFinZoom(); 

						if (ZOOM_MOVE_OPACITY)
						{
							jqElementAvecOpacite.css("opacity","");
						}					
					}				
				, 	always : function()
					{
						this.style.opacity=1;
						fRetireCanvas();
					}
				});
			}
			else 
			{
				fRetireCanvas();
			}

			//garde le canvas pendant la transition petite image -> grande image de champ vignette				
			//il n'y a plus rien de zoomé, on ferme le GFI et les listeners
			if (!jqGalerie.hasClass("wbGalerieChargementVignetteImage") && !jqGalerie.find(".wbGaleriePleinEcran").first().length)
			{
				//au clavier
				$(window).off("keydown.wb.galerie.zoom.fin trigger.wb.galerie.zoom.navigation");			
				//ferme le zoom 
				jqGalerie.removeClass("wbGaleriePleinEcranEnCours");
				//disparition du GFI sans prendre les clics pendant sa disparition
				jqGalerie[0].jqCelluleGFI.add(jqFleches).stop(true,false).css({pointerEvents : "none"});
				if (bJoueAnimationFLIP) 
				{
					jqGalerie[0].jqCelluleGFI.add(jqFleches).fadeOut({duration:ZOOM_DURATION_OUT,easing:"easeInOutQuad"}); 
				}
				else 
				jqGalerie[0].jqCelluleGFI.add(jqFleches).hide();
				//il n'y a plus de zoom
				jqGalerie[0].nIndiceRepetitionZoome = undefined;
				//évite de créer un calque pour les plans car perturebe le positionnement du zoom de galerie
				jqGalerie.parents(".wbPlanSimple").css("will-change","");

				if (jqGalerie.data("wbGalerieRelayoutRequis"))
				{
					//il y a eu une image chargée pendant qu'on regardait une autre zoomé
					jqGalerie.data("wbGalerieRelayoutRequis",!afficheImages());
				}

				//fin de tout canvas, blindage
				//TODO DEBUG utile?
				//jqGalerie.children("canvas").remove();

				//notifieFinLayout(); tout?
				// //recalcul les ancrages superposables à la fermeture du zoom
				// if (UpdateLayoutSuperposableEpingle)
				// {
				// 	UpdateLayoutSuperposableEpingle();
				// }				
			}
			//else, cas du fondu enchaîné entre 2 zooms

			return nIndice;		
		}
		function fSauveFirstLast(jqRepetition,jqChampRef)
		{
			//FIRST : sauve la position de l'image 
			jqRepetition[0].oInfoTaillePositionAvantPleinEcran = {
				top 		: parseFloat(jqRepetition.css("top"))
			,	left 		: parseFloat(jqRepetition.css("left"))
			,	width 		: parseFloat(jqRepetition.css("width"))
			,	height 		: parseFloat(jqRepetition.css("height"))
			};

			//LAST : applique les dimensions plein écran
			jqChampRef[0].oInfoTaillePositionAvantPleinEcran = {
				width 		: parseFloat(jqChampRef.css("width"))
			,	height 		: parseFloat(jqChampRef.css("height"))
			};
		}
		function fOuvreZoom(jqRepetition,bJoueAnimationFLIP,fCallbackFlipAlways)
		{
			//Sugg : effet fondu translaté comme une ouverture d'appli android 
			//$0.style.opacity=0; $0.style.transform="translate3d(0px, 42px, 0px)"; $0.style.transition="transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) 0s;"
			//vu sur https://onsenui.github.io/vue-onsenui-kitchensink/main.html?platform=android

			if (bJoueAnimationFLIP===undefined) bJoueAnimationFLIP=true;//FLIP par défaut
			if (!ZOOM_EFFET_FLIP_AUTORISE) bJoueAnimationFLIP =false;
      		var nIndice = jqRepetition.index();
      		//mémorise l'indice de répétition zoomée
      		jqGalerie[0].nIndiceRepetitionZoome = nIndice;
			var item = realItems[nIndice];
			if (!item || (!jqGalerie.hasClass("wbGaleriePleinEcranEnCours") && jqRepetition.queue().length)) return;//blindage si non trouvé ou anim en cours (cas de fin de swipe de fermeture de zoom)
			var jqChampRef = jqRepetitionsChampReference.eq(nIndice);


			var fCallbackFlipAlwaysVignette = undefined;
			//cas vignette 
			//grande image déjà connue ? non
			var sGrandeImage;
			//TODO OPTIM mettre en cache la connaissance de wbGalerieVignetteGrandeImage ?
			//et évite la réentrance car on lancera un fOuvreZoom
			if ( (sGrandeImage=jqChampRef.parent().attr("data-wbGalerieVignetteGrandeImage")) && !jqGalerie.hasClass("wbGalerieChargementVignetteImage"))
			{
				if (!jqChampRef[0].fRestaureImageVignette)
				{
					//pépare les callbacks de modification de l'image affichagée en vignette								
					var sSrcVignette = jqChampRef[0].firstElementChild.src;
					var sSrcImage = sGrandeImage;
					var itemVignette = $.extend({},item);

					function fOnLoad(event,bDepuisOnError)
					{						
						//twidth est pour la largeur de vignette 
						//iwidth et pour la largeur de l'image
						var nLargeurGrandeImage = realItems[nIndice].iwidth||realItems[nIndice].twidth||nLargeurChampRefEdition;
						var nHauteurGrandeImage = realItems[nIndice].iheight||realItems[nIndice].theight||nHauteurChampRefEdition;

						if (!bDepuisOnError)
						{										
							//TODO OPTIM refactorer wbOnLoadGalerieImg
							//trouve les dimensions de l'image chargée
							nLargeurGrandeImage = this.naturalWidth||this.width||nLargeurGrandeImage;
							nHauteurGrandeImage = this.naturalHeight||this.width||nHauteurGrandeImage;
						}

						jqChampRef[0].fRestaureImageVignette = function () 
						{ 
							if (bDepuisOnError)
							{
								//laisse tel quel
								return;
							}
							jqChampRef[0].firstElementChild.src = sSrcVignette; 
							//les dimensions de la répétition zoomée doivent être selon la grande image
							realItems[nIndice] = itemVignette;
							//sauve les dimensions de la grande image 
							realItems[nIndice].iwidth = nLargeurGrandeImage;
							realItems[nIndice].iheight = nHauteurGrandeImage;						
							//indique que le cache a été mis à jour
							NotifCacheMisAJour(nIndice);												
						};
						jqChampRef[0].fAppliqueGrandeImageVignette = function () 
						{ 
							if (bDepuisOnError)
							{
								//laisse tel quel
								return;
							}	
							
							jqGalerie.addClass("wbGalerieChargementVignetteImage");

							// //si la répétition est déjà en plein écran
							var bDejaZoomee = jqRepetition.hasClass("wbGaleriePleinEcran");
							//retaille le zoom
							if (bDejaZoomee)
							{
								var oBackupPositionAvantPleinEcranRep = $.extend({},jqRepetition[0].oInfoTaillePositionAvantPleinEcran);
								var oBackupPositionAvantPleinEcranChp = $.extend({},jqChampRef[0].oInfoTaillePositionAvantPleinEcran);

								fSauveFirstLast(jqRepetition,jqChampRef);
								jqRepetition.css({zIndex : 991});//au dessus des répétitions 

							    var oOffsetGalerie = jqGalerie.offset();//TODO OPTIM offset galerie
							    jqRepetition[0].oInfoTaillePositionAvantPleinEcran.left += window.nBordGaucheNavigateur - oOffsetGalerie.left;
							    jqRepetition[0].oInfoTaillePositionAvantPleinEcran.top += window.nBordHautNavigateur - oOffsetGalerie.top;

								fFermeZoom(false,jqRepetition);
								//fferme zoom appelle fRestaureImageVignette
								//afficheImages(false,false,true);
							}								

							realItems[nIndice].twidth = nLargeurGrandeImage;
							realItems[nIndice].theight = nHauteurGrandeImage;
							jqChampRef[0].firstElementChild.src = sSrcImage; 

							//retaille le zoom
							if (bDejaZoomee)
							{								
								fOuvreZoom(jqRepetition,true,function()
								{
									//rétablit le bon FLIP
									jqRepetition[0].oInfoTaillePositionAvantPleinEcran = oBackupPositionAvantPleinEcranRep;
									jqChampRef[0].oInfoTaillePositionAvantPleinEcran = oBackupPositionAvantPleinEcranChp;

									jqRepetition.css({zIndex : ''});//fin du au dessus des répétitions 

									// fFermeZoom(false,jqRepetition);
									// afficheImages(false,false,true);
									// //rétablit le bon FLIP
									// fSauveFirstLast(jqRepetition,jqChampRef);
									// fOuvreZoom(jqRepetition,false);
									jqGalerie.removeClass("wbGalerieChargementVignetteImage");
								});
							}
							else 
							{
								jqGalerie.removeClass("wbGalerieChargementVignetteImage");
							}
						};

						//l'image est chargée on applique les dimensions et le src
						jqRepetition.queue().length ? jqRepetition.queue(jqChampRef[0].fAppliqueGrandeImageVignette) : jqChampRef[0].fAppliqueGrandeImageVignette();				
					}

					//fCallbackFlipAlwaysVignette = function(){
						var img = new Image();
						//l'image doit être chargée
						img.onload = fOnLoad;
						img.onerror = function() { fOnLoad.apply(this,[undefined,true]); }
						//charge l'image pour déterminer ses dimensions
						img.src = sSrcImage;
						//l'image est utilisable immediatement
						if (img.complete && img.naturalWidth && img.naturalHeight)
						{
							fOnLoad.apply(img,[]);
						}
					//};
				}	
				else 
				{
					//l'image est chargée on applique les dimensions et le src
					jqChampRef[0].fAppliqueGrandeImageVignette();	
				}
			}

			if(bJoueAnimationFLIP && fPrepareOuverturePremierZoom) fPrepareOuverturePremierZoom();

			//place les flag de zoom à moins qu'on y soit déjà
			if (!jqGalerie.hasClass("wbGaleriePleinEcranEnCours"))//sauf cas fondu enchaîné
			{
				//GFI
				//ajoute les flèches et croix pour fermer
				construitZoomOptions();					
				if (bJoueAnimationFLIP) jqGalerie[0].jqCelluleGFI.add(jqFleches).css({opacity : 0}).fadeTo(ZOOM_DURATION_IN,1,"easeInOutQuad"); else jqGalerie[0].jqCelluleGFI.add(jqFleches).show();				
				jqFleches.css({pointerEvents : ""});//écoute les clics
				//évite de créer un calque pour les plans car perturebe le positionnement du zoom de galerie
				jqGalerie.parents(".wbPlanSimple").css("will-change","inherit");

		      	
				//au clavier
				$(window).on("keydown.wb.galerie.zoom.fin trigger.wb.galerie.zoom.navigation",function(event)
				{ 
					//ignore les repeats  (touche enfoncée) mais on reste sur le down afin de faire ignorer le scroll par la flèche
					var bEstRepete = (event.originalEvent && event.originalEvent.repeat);
					//if(bEstRepete) return;

					//optim pour ne pas traiter les touches
					if (isNaN(jqGalerie[0].nIndiceRepetitionZoome))
					{
						//pas de zoom en cours 
						return;
					}
					
					var bToucheTraitee=false;
					if (event.key == "Escape" ||event.key == "Esc")//Esc pour Edge IE
					{
						//termine de force toutes les animations
						jqRepetitions.stop(true,true);

						//ferme le zoom  sur ESC
						bToucheTraitee = (fFermeZoom(true) !== false);
					}
					else
					{
						//navigue
						if ((event.key == "ArrowRight")||(event.key == "Right"))//IE Right
						{
							var bAvance = true;
						}
						else if ((event.key == "ArrowLeft")||(event.key == "Left"))//IE Left
						{
							var bAvance = false;
						}
						else 
						{
							return;
						}

						bToucheTraitee=bZoomAvanceRecule(bAvance,true,bEstRepete);
					}
					if (bToucheTraitee)
					{
						event.stopPropagation();
						event.preventDefault();				
					}
				});	
			}	

      		//affiche la répétition en plein écran 

      		//masque la flèche inutile  
      		if (nIndice===0)
  			{
  				jqFlechePrecedent.addClass("wbgrise");
  			}
  			else 
  			{
  				jqFlechePrecedent.removeClass("wbgrise");
  			}
      		if (nIndice===jqRepetitions.length-1)
  			{
  				jqFlecheSuivant.addClass("wbgrise");
  			}
  			else 
  			{
  				jqFlecheSuivant.removeClass("wbgrise");
  			}  			

      		//calcul la taille et position 
      		//retire la marge gauche et droite pour ne pas chevaucher les flèches précédent/suivant 
      		var nMargesFleches = parseFloat(jqFlechePrecedent.css("width")||0) + parseFloat(jqFlechePrecedent.css("left")||0)*(5/3) + parseFloat(jqFlecheSuivant.css("width")||0) + parseFloat(jqFlecheSuivant.css("right")||0)*(5/3);
      		var nLargeurMax = window.nLargeurNavigateur - nMargesFleches;
      		//et pour la hauteur ? une marge arbitraire ?
      		var nHauteurMax = window.nHauteurNavigateur - fZOOM_MARGIN_HAUTEUR();

      		var nLargeurImgZoom;
      		var nHauteurImgZoom;

      		//dimension max de l'image dans une répétition plein écran, sans agrandissment
			var nLargeurImgMax = Math.max(nLargeurChampRefEdition,Math.min(item.twidth, nLargeurMax - (nLargeurRepetitionEdition - nLargeurChampRefEdition)));
			var nHauteurImgMax = Math.max(nHauteurChampRefEdition,Math.min(item.theight, nHauteurMax - (nHauteurRepetitionEdition - nHauteurChampRefEdition)));

      		//cas PAYSAGE
			nLargeurImgZoom = nLargeurImgMax;
			var nHauteurSelonLargeurImgMax = (item.theight/item.twidth) * nLargeurImgMax;
			nHauteurImgZoom=nHauteurSelonLargeurImgMax;

			//cas PORTRAIT
			if (nHauteurImgZoom>nHauteurImgMax)
			{
				nHauteurImgZoom = nHauteurImgMax;
				nLargeurImgZoom = (item.twidth/item.theight) * nHauteurImgZoom
			}

			//calcul de la répétition 
			var nLargeurRepetitionPleinEcran = Math.max(nLargeurRepetitionEdition ,nLargeurImgZoom + (nLargeurRepetitionEdition - nLargeurChampRefEdition));
			var nHauteurRepetitionPleinEcran = Math.max(nHauteurRepetitionEdition ,nHauteurImgZoom + (nHauteurRepetitionEdition - nHauteurChampRefEdition));

			var nTop = (window.nHauteurNavigateur - nHauteurRepetitionPleinEcran) / 2;
			var nLeft = (window.nLargeurNavigateur - nLargeurRepetitionPleinEcran) / 2;

			//FIRST : sauve la position de l'image 
			//LAST : applique les dimensions plein écran
			fSauveFirstLast(jqRepetition,jqChampRef);

			//demande de FR via BAL  : dessine un canvas à l'emplacement initial
			// ============ Message de FR du 16/10/2017 11:18 ============
			// Perso, je ne veux pas de trou. Désolé...			
			try { 
				if (!GALERIE_ZOOM_CANVAS_CLONE) //inutile de faire le fond s'il y a un clone
				jqGalerie.append( jqRepetition[0].canvasFond = $(document.createElement("canvas"))//TODO remplacer le canvas par une autre balise et adapter le css
					.css(jqRepetition[0].oInfoTaillePositionAvantPleinEcran)
					.css({
						backgroundColor : (item.color||jqChampRef.css("backgroundColor"))   ,  backgroundClip: "content-box",     boxSizing: "border-box"
					,	paddingTop : jqChampRef.offset().top -  jqRepetition.offset().top 
					,	paddingBottom : jqRepetition[0].oInfoTaillePositionAvantPleinEcran.height - ((jqChampRef.offset().top -  jqRepetition.offset().top) + jqChampRef[0].oInfoTaillePositionAvantPleinEcran.height)
					,	paddingLeft : jqChampRef.offset().left -  jqRepetition.offset().left 
					,	paddingRight : jqRepetition[0].oInfoTaillePositionAvantPleinEcran.width - ((jqChampRef.offset().left -  jqRepetition.offset().left) + jqChampRef[0].oInfoTaillePositionAvantPleinEcran.width)
					})
					//soit blur animé
					//.animate({content:1},{duration: ZOOM_DURATION_IN, step : function(now) {  $(this).css({filter : "blur(" + (GALERIE_ZOOM_BLUR_CANVAS*now) + "px)"}); } })
					//soit blur sec
					.css({filter: "blur(" + GALERIE_ZOOM_BLUR_CANVAS + "px)"})
				);
				if (GALERIE_ZOOM_CANVAS) 
				{
					if (GALERIE_ZOOM_CANVAS_CLONE)
					{
						if (!jqRepetition[0].canvas)//pas en double, comme pour le cas de clic sur vignette
						{								
							var jqClone = jqRepetition.clone(false,false);
							//retire les onload inline
							jqClone.find("img").attr("onload","");
							jqGalerie[0].appendChild(jqRepetition[0].canvas=jqClone[0]);
						}
					}
					else 
					{
						html2canvas(jqRepetition[0], {width : jqRepetition[0].oInfoTaillePositionAvantPleinEcran.width, height : jqRepetition[0].oInfoTaillePositionAvantPleinEcran.height,javascriptEnabled : false/*,async : false*/})
						.then(function(canvas) 
						{
			    			jqGalerie[0].appendChild(canvas);
							//grab the context from your destination canvas
							//var destCtx = canvasFond[0].getContext('2d');

							//call its drawImage() function passing it the source canvas directly
							//destCtx.drawImage(canvas, 0, 0, jqRepetition[0].oInfoTaillePositionAvantPleinEcran.width, jqRepetition[0].oInfoTaillePositionAvantPleinEcran.height);					
							//canvasFond.replaceWith(jqRepetition[0].canvas=$(canvas).css({filter: "blur(20px)"}).css(jqRepetition[0].oInfoTaillePositionAvantPleinEcran));
							//jqRepetition[0].canvas.hide().fadeIn(); 					

							 jqRepetition[0].canvas=$(canvas).css(jqRepetition[0].oInfoTaillePositionAvantPleinEcran).css({filter: "blur(" + GALERIE_ZOOM_BLUR_CANVAS + "px)"}).css({opacity:0}).animate(
							 	{opacity : 1}
							 ,
							 {	
							 	duration : ZOOM_DURATION_IN
							 ,	done:function()
							 	{
							 	//canvasFond.replaceWith(jqRepetition[0].canvas);
							 	}
							}); 						
			    			
							//if (bJoueAnimationFLIP) fFinally();
						});
					}
				}
			}
			catch(e)
			{
				//if (bJoueAnimationFLIP) fFinally();
			}

			var fFinally = function()
			{
			jqChampRef.css({
				width 		: nLargeurImgZoom
			,	height 		: nHauteurImgZoom
			});
			if (clWDUtil.bRWD) jqChampRef.css({width : ''});
			jqRepetition[0].oInfoTaillePositionApresPleinEcran = {
				top 		: nTop
			,	left 		: nLeft
			,	width 		: nLargeurRepetitionPleinEcran
			,	height 		: nHauteurRepetitionPleinEcran
			};
			jqRepetition.css(jqRepetition[0].oInfoTaillePositionApresPleinEcran);

			//notification d'ouverture (pour LST)
			jqTableGalerie.trigger("trigger.wb.galerie.zoom.debut",nIndice);

			//recalcul les champs superposables
			notifieFinLayout(nIndice,true);//SYNCHRONE

			if (bJoueAnimationFLIP)
			{				
				//INVERT
			    var oCssInvert = {};
			    var oOffsetGalerie = jqGalerie.offset();//TODO OPTIM offset galerie
			    oCssInvert.x = (oOffsetGalerie.left+jqRepetition[0].oInfoTaillePositionAvantPleinEcran.left-window.nBordGaucheNavigateur) - (jqRepetition[0].oInfoTaillePositionApresPleinEcran.left);
			    oCssInvert.y = (oOffsetGalerie.top+jqRepetition[0].oInfoTaillePositionAvantPleinEcran.top-window.nBordHautNavigateur) - (jqRepetition[0].oInfoTaillePositionApresPleinEcran.top);
			    oCssInvert.sx = jqRepetition[0].oInfoTaillePositionAvantPleinEcran.width / jqRepetition[0].oInfoTaillePositionApresPleinEcran.width;
			    oCssInvert.sy = jqRepetition[0].oInfoTaillePositionAvantPleinEcran.height / jqRepetition[0].oInfoTaillePositionApresPleinEcran.height;

			    jqRepetition.css({			    
		    		transformOrigin : '0 0'
		    	,	transform :"translate(" + oCssInvert.x +"px, " + oCssInvert.y + "px) scale("+oCssInvert.sx+", "+oCssInvert.sy+")"
		        });   

				//PLAY
				//la répétition entière a l'opacité modifiée afin de ne pas voir la répétition en double à cause du clone
				var jqElementAvecOpacite = (GALERIE_ZOOM_CANVAS_CLONE ? jqRepetition : jqRepetition.find("*").not(jqChampRef.parents().add(jqChampRef)));
				//évite le clignottement au chargement de la grande image car elle arrive après le zoom normal de la petite vignette
				var bZoomOpacity = ZOOM_MOVE_OPACITY && !jqGalerie.hasClass("wbGalerieChargementVignetteImage");
		        jqRepetition
				.animate({content:1},{
					duration : ZOOM_DURATION_IN
				,	easing : "linear"
					//callback d'animation
				,	step : function (now)
					{

						var remappedTime = dGetTempsSelonStandardCurve(now, ZOOM_DURATION_IN);

						//source: https://material.io/guidelines/motion/choreography.html#choreography-continuity
						//Math.min(1,remappedTime/ (275/375));
						//mais finalement je prends des valeurs au pif
						var remappedTimeY = new clWDUtil.WDBezier(0.55, 0.06, 0.68, 0.19).dCalcule( now, ZOOM_DURATION_IN );
						var remappedTimeX = new clWDUtil.WDBezier(0.4, 0, 1, 1).dCalcule( now, ZOOM_DURATION_IN );

						//Arc downward 
						if (oCssInvert.y<0)
						{
							var tmp = remappedTimeY;
							remappedTimeY=remappedTimeX;
							remappedTimeX = tmp;
						}
						
						var remappedTimeW = remappedTimeY;
						var remappedTimeH = ZOOM_MOVE_CHOREGRAPHY_SYMETRIQUE ? remappedTimeY : remappedTimeX;

						var remappedTimeOpacity = (remappedTime<=0.2) ? 0/*( (0.2-remappedTime) /0.2 )*/ : Math.min(1,(remappedTime-0.2)/0.4);

						if (bZoomOpacity)
						{
							jqElementAvecOpacite.css("opacity",remappedTimeOpacity);
						}
						if (!ZOOM_MOVE_CHOREGRAPHY)
						{
							remappedTimeX = remappedTimeY = remappedTimeW = remappedTimeH = remappedTime;
						}
						
						var update = {
							x: oCssInvert.x * (1 - remappedTimeX),
							y: oCssInvert.y * (1 - remappedTimeY),
							sx: oCssInvert.sx + (1 - oCssInvert.sx) * remappedTimeW,
							sy: oCssInvert.sy + (1 - oCssInvert.sy) * remappedTimeH
						};
						
						//mouvement d'arc
						if (ZOOM_MOVE_ARC)
						{
							update.x=oGetPositionDansArc(oCssInvert,remappedTimeX).x;
							update.y=oGetPositionDansArc(oCssInvert,remappedTimeY).y;
						}

						this.style.transform = "translate(" + update.x +"px, " + update.y + "px) scale("+update.sx+", "+update.sy+")";						
					}	
				,	done : function()
					{
						if (bZoomOpacity)
						{
							jqElementAvecOpacite.css("opacity","");
						}	
						!fCallbackFlipAlwaysVignette ||	fCallbackFlipAlwaysVignette();
					}			
				,	always : fCallbackFlipAlways
				});
			}


			jqRepetition.addClass("wbGaleriePleinEcran");

			//flag le plein écran en cours			
			jqGalerie.addClass("wbGaleriePleinEcranEnCours");

			};
			//if (!bJoueAnimationFLIP) 
				fFinally();
		}
 		

		//code de reinit ////////////////
		var fReInit = function (bDepuisOnGalerie)
		{
			jqRepetitions = jqGalerie.children();
			realItems = [];
			//champs superposables dans la galerie par ligne
			tabChampsSuperposables = [];
			tabRepetitionsChampReference = [];
			jqRepetitions.each(function(i){

				//il doit y avoir N éléments décrits pour les mêmes N répétitions trouvées
				realItems[i] = {};

				//prend le div parent, celui d'homothétie
				var jqRepetition = $(this);
				var jqRef = jqRepetition.find(".wbGalerieChpRef");
				if (!jqRef.hasClass("wbHnImg"))
					jqRef = jqRef.parent();


				//avec id de cache serveur ?
				if (clWDUtil.oGetImageInformations)
				{
					var oCache = clWDUtil.oGetImageInformations();
					var sIdCache = jqRef.attr("data-wbImgInfoCache");				
					//recherche dans le cache serveur 
					if (sIdCache && oCache[sIdCache])
					{
						realItems[i] = $.extend({},oCache[sIdCache]);
						//place le src pour que afficheImages sache qu'on a la bonne info
						realItems[i].src = jqRef.get(0).firstElementChild.src;
						var sIdCacheGrandeImage = jqRef.attr("data-wbImgInfoCacheGrandeImage");
						if (sIdCacheGrandeImage && oCache[sIdCacheGrandeImage])
						{
							realItems[i].idHD = sIdCacheGrandeImage;
							//copie les dimensions de la grande image dans le cache de la vignette
							var oElemGrandeImage = $.extend({},oCache[sIdCacheGrandeImage]);
							realItems[i].iwidth = oElemGrandeImage.twidth;
							realItems[i].iheight = oElemGrandeImage.theight;
						}
					}
					//place l'id pour notifier le serveur
					realItems[i].id = sIdCache;
				}

				tabRepetitionsChampReference.push(jqRef.get(0));
				if (window.UpdateLayoutSuperposableEpingle)
					tabChampsSuperposables.push(jqRepetition.find(".ancragesuph, .ancragesupl, .ancragesuprwd"));
			});
			//liste des champs de références
			jqRepetitionsChampReference = $(tabRepetitionsChampReference);		
			//retire les dimensions temporaires des répétitions 
			jqRepetitions.add(jqRepetitionsChampReference).add(jqGalerie).css({height:"",width:""});

			//instance de masonry
			//jqGalerie[0].MODE_COLONNE_MASONRY_INSTANCE; plutôt que var MODE_COLONNE_MASONRY_INSTANCE
			//afin de garder l'instance lors d'une ré init

			//init des globales à la galerie
			setDimensionsReference();

			//la transition sera appliquée par CSS sur les top left width et height
			appliqueTransition();

			//Init de la galerie

			//1er layout
			afficheImages(undefined,undefined,undefined,bDepuisOnGalerie);

			//Post init 

			//init à refaire pour les nouvelles lignes ?
	 		{		      
		      	//zoom par clic dans le fond
		      	if (jqTableGalerie.hasClass("wbGaleriePleinEcranClicFond"))
		      	{
			      	jqRepetitions.each(function(nIndiceRepetition){
		      			var jqRepetition = jqRepetitions.eq(nIndiceRepetition);
		      			//nouvelle ligne pas encore init ?
		      			if (jqRepetition[0].bInitPleinEcranClicFondDejaFait)
	      				{
	      					return;
	      				}
			      		jqRepetition[0].bInitPleinEcranClicFondDejaFait = true;
		      			var jqChampRef = jqRepetitionsChampReference.eq(nIndiceRepetition);
			      		if (GALERIE_ZOOM_RIPPLE)
			      		{
			      			jqRepetition.addClass("wbGalerieEffetRipple");
				      		//variables css mal supportées sur Edge et pas supportés sur IE
				      		if (!bIEAvec11 && !bEdge)
				      		{
					      		jqRepetition
					      		.addClass("wbGalerieEffetRippleCssVars")
								.on((bTouch ? "touchstart.wb.galerie.zoom pointerdown" : "mousedown") + ".wb.galerie.zoom",function(e)
								{
									var x = e.pageX - jqRepetition.offset().left;
									var y = e.pageY - jqRepetition.offset().top;
									var nTaille = Math.max( jqRepetition.width() , jqRepetition.height() ) / 2;

									jqRepetition.attr("style",$(this).attr("style") + " " +
										//contournement de .css qui ne supporte pas les vars css
										JSON.stringify({
											'--wb-galerie-ripple-padding':nTaille+'px',
											'--wb-galerie-ripple-left': (x - (nTaille))+'px' ,
											'--wb-galerie-ripple-top': (y - (nTaille))+'px'
										}).substr(1).replace("}",";").replace(/"/g,"").replace(/,/g,";") 
									);
								});
							}
						}


						var  bEstEventClick = function(event)
						{

				      		if (event.type === "touchstart")
			      			{
			      				jqRepetition[0].dLastDate = new Date();
			      				jqRepetition[0].nBordHautNavigateurLorsDuTouchStart = window.nBordHautNavigateur;
			      				return;
			      			}
			      			else if (event.type === "touchend")
			      			{
			      				var bClick = (jqRepetition[0].nBordHautNavigateurLorsDuTouchStart === window.nBordHautNavigateur) && (new Date() - jqRepetition[0].dLastDate)<300;
			      				if (!bClick)
		      					{
		      						return false;
		      					}
			      			}

				      		//vérification de la chaîne pour ne pas traiter les click qui auraient du être stop propagé
				      		var bClicAccepte = true;
				      		var domParent = event.target;
				      		while(domParent)
				  			{
                                //s'arrête si le clic est arrivé sur la répétition
				  				if (domParent == jqRepetition[0])
				  					break;
				  				var sNomBalise = domParent.tagName.toLowerCase();
                                //n'accepte pas le clic si le traget traverse un élément clicable, sauf si cet élément est justement le champ de référence
				  				//attention : sous IE img.href renvoie img.src...
				  				if ( (domParent.onclick && (false===clWDUtil.bAvecClasse(domParent,"wbGalerieChpRef"))) || domParent.getAttribute("href") || sNomBalise=="a" || sNomBalise=="label" || sNomBalise=="input" || sNomBalise=="textarea" || sNomBalise=="select" || sNomBalise=="button")
								{
									//clic sur le lien d'ouverture de vignette du champ de référence avec action popup automatique
									if (domParent.wbGalerieClicVignetteEnCours)
									{								
										//raz
										domParent.wbGalerieClicVignetteEnCours = undefined;
										//on accepte le clic et  lance le zoom 
										break;					
									}
									else 
									{		
										bClicAccepte=false;
										break;
									}
								}
								//remonte
								domParent = domParent.parentNode;
				  			}

				  			return bClicAccepte;
						}

						jqRepetition
						.on((bTouch ? "pointerdown" : "mousedown") + ".wb.galerie.zoom",function(event)
						{
							//ignore le zoom si on est déjà en zoom
							if (jqGalerie.hasClass("wbGaleriePleinEcranEnCours")) return;

							if (bEstEventClick(event))
							{
								jqRepetitions.removeClass("wbActif").removeClass("wbGalerieActif");//nettoie au cas où (cas d'un clic long sur une autre répétition)
								jqRepetition.addClass("wbActif").addClass("wbGalerieActif");
							}
						})
			      		.on((bTouch ? "touchstart.wb.galerie.zoom touchend" : "click") + ".wb.galerie.zoom",function(event)
			      		{
				      		//ignore le zoom si on est déjà en zoom
				      		if (jqGalerie.hasClass("wbGaleriePleinEcranEnCours")) return;

							var bClicAccepte = bEstEventClick(event);
							//le clic est accepté ou refusé ?
							//donc le clic est traité => donc on retire l'état actif
							if (bClicAccepte!==undefined)
							{
								jqRepetition.removeClass("wbActif").removeClass("wbGalerieActif");
							}
				  			if (bClicAccepte===true)//évite le cas d'un click sur un bouton 
				  			{
					      		if (ZOOM_DURATION_IN_DELAY>0) 
					      			setTimeout(function(){fOuvreZoom(jqRepetition,true);},ZOOM_DURATION_IN_DELAY);
					      		else 
					      			fOuvreZoom(jqRepetition,true);
				      		}
						});      		
					});      		


		      		//défilment du zoom au doigt 
		      		jqRepetitions.each(function(nIndiceRepetition){	      			
		      			var jqRepetition = jqRepetitions.eq(nIndiceRepetition);
		      			//nouvelle ligne pas encore init ?
		      			if (jqRepetition[0].bInitSwipeDejaFait)
	      				{
	      					return;
	      				}
			      		jqRepetition[0].bInitSwipeDejaFait = true;	      			
		      			jqRepetition[0].swipeLastDirection = undefined;
		      			jqRepetition.swipe({
							fingers:1
					    ,   triggerOnTouchEnd: true
					    ,	preventDefaultEvents : false//permet le scroll vertical
					    ,   excludedElements: "label, button, input, select, textarea, .noSwipe" //retire le a des exclusions afin d'autoriser le swipe d'images cliquables et vignette
					    ,   swipeStatus: function swipeStatus(event, phase, direction, distance, duration)     
					        {				
					        	//note : la phase de end/cancel n'a pas de touches.length		                
					        	if (!event.touches || !jqRepetition.hasClass("wbGaleriePleinEcran"))
				        		{
				        			return;
				        		}
								event.stopPropagation();
								event.preventDefault();		        		
					        	if (distance<5)
				        		{
				        			return;
				        		}						
								if (jqRepetition[0].swipeLastDirection && jqRepetition[0].swipeLastDirection!=direction)
								{
									//ignore les changements de sens 
									return;
								}
								
								var bLateral = (direction == "left" || direction == "right");

								//force un toucher près du bord à être le dernier 
								if (phase=="move" && event.touches.length)
								{
									var nPosX = event.touches[0].clientX;
									if (nPosX<32 || nPosX+32>window.nLargeurNavigateur)
									{
										phase = "end";
									}
								}

								if (!jqRepetition[0].swipeLastDirection)
								{
									if (!direction || !(phase == "start" || phase == "move"))
									{
										//attend de déterminer la direction	
										return;
									}							
					        		//translate pas à pas 
					        		if (bLateral)
					        		{
						        		if (false ===bZoomAvanceRecule((direction == "left"),false))
					        			{
					        				return;
					        			}
						        		jqRepetition[0].oAnimationZoomAvanceRecule.start.apply(jqRepetition[0],[]);
					        		}
									jqRepetition[0].swipeLastDirection=direction;
								}

								var dCoeff = Math.max(0,Math.min(1,Math.abs(distance / (jqRepetition[0].nLargeurAParcourirZoomAvanceRecule||(window.nHauteurNavigateur/2)))));

								if (bLateral && !jqRepetition[0].oAnimationZoomAvanceRecule)
								{
									return;
								}

								if (phase == "move")
								{							
									//phase de move 
									if (bLateral)
									{
										jqRepetition[0].oAnimationZoomAvanceRecule.step.apply(jqRepetition[0],[dCoeff]);
									}
									else
									{
										jqRepetition.css({
											transform 	: "translateY(" + (distance * ((direction=="up") ? -1 : 1) ) + "px)"
										//,	opacity 	: Math.max(0,1-dCoeff)
										});
										jqGalerie[0].jqCelluleGFI.css({
											opacity 	: Math.max(0,1-dCoeff)
										});
									}
									event.stopPropagation();
									event.preventDefault();							
									return;
								}

								//force el end et cancel selon le trajet fait 
								if (dCoeff>0.25) phase = "end"; else phase = "cancel";						

								//TODO jouer l'animation inverse pour le cancel
								if (phase == "end" || phase == "cancel")
								{
									if (bLateral)
									{
										//va jusqu'au bout 
										jqRepetition.animate({content : 1},$.extend({},jqRepetition[0].oAnimationZoomAvanceRecule,{								
											start : function(){} //car déjà fait 
										,	duration : (jqRepetition[0].oAnimationZoomAvanceRecule.duration>duration ? (jqRepetition[0].oAnimationZoomAvanceRecule.duration-duration) : jqRepetition[0].oAnimationZoomAvanceRecule.duration)
										,	step : function(now) 
										{								
											this.oAnimationZoomAvanceRecule.step.apply(this,[((1-dCoeff)*now  + dCoeff)])
										}
										}));
									}
									else
									{
										var nNouveauTop = parseFloat(jqRepetition[0].style.top) + (distance * ((direction=="up") ? -1 : 1) ) ;
										jqRepetition.css({
											top 		: nNouveauTop
										,	transform 	: ""
										//,	opacity 	: ""
										});	
										//jqGalerie[0].jqCelluleGFI.css({opacity 	: ""								});
										if (jqRepetition[0].oInfoTaillePositionApresPleinEcran)							
										{
											//pour le flip
											jqRepetition[0].oInfoTaillePositionApresPleinEcran.top = nNouveauTop;
										}
										//masque et donc ferme le zoom 
										fFermeZoom(true);
									}
								}
								// else if (phase == "cancel")
								// {
								// 	//annule la navigation précédente
								// 	if (false === bZoomAvanceRecule((jqRepetition[0].swipeLastDirection != "left")))
								// 	{
								// 		jqRepetition[0].swipeLastDirection = undefined;
								// 		return;
								// 	}
								// 	jqRepetition[0].oAnimationZoomAvanceRecule.start.apply(jqRepetition[0],[]);				
								// 	jqRepetition[0].oAnimationZoomAvanceRecule.step.apply(jqRepetition[0],[1]);
								// 	jqRepetition[0].oAnimationZoomAvanceRecule.done.apply(jqRepetition[0],[1]);
								// }

								//fin						
								jqRepetition[0].swipeLastDirection = undefined;
								event.stopPropagation();
								event.preventDefault();
					        } 				
					    ,   allowPageScroll: "none"
					    ,   threshold: 0	
						,	swipe:function(event, direction, distance, duration, fingerCount, fingerData) 
							{
								//rien
							}
		      			});//jqRepetition.swipe({

		      		});//jqRepetitions.each(function(nIndiceRepetition){

		      }//si zoom par clic au fond 

		   }//init à refaire pour les nouvelles lignes ?

		};//fReInit
		fReInit = fReInit.bind(this);

		//1er appel
		fReInit();		
 		{	 	
			//une fois les répétitions passées au chargement de data-media il faut refaire le layout de galerie
 			$(window).on("trigger.wb.rwd.media.reinit",fOnModifGalerie);

			//cas de ZRAjoute en AJAX, changement de tranche...
			if (window.NSPCS)
			{
				// Notifie aussi de la modification du HTML de la page
				NSPCS.NSUtil.ms_oNotificationsAjoutHTML.AddNotification(fOnModifGalerie);
				NSPCS.NSUtil.ms_oNotificationsFinAJAX.AddNotification(fOnModifGalerie);
				//changement de tranche => ré init les globales de tailles min 
				NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(function(domUNUSED,nIndiceTranche)
				{ 
					var bReInitRequis = true;
					if (jqGalerie[0].nIndiceTrancheDernierAffichage===undefined && nIndiceTranche===1)
					{
						//inutile de refaire l'affichage pour le changement de tranche initiale vers la tranche par défaut
						//car c'est exactement le même que l'init
						//et comme setDimensionsReference reset nLargeurNavigateurDernierCalcul du coup afficheImages est forcé
						bReInitRequis=false;
					}
					jqGalerie[0].nIndiceTrancheDernierAffichage = nIndiceTranche;
					if (!bReInitRequis)
					{
						return;
					}

					setDimensionsReference(); 

					//afficheImages sera appelé par le resize qui suit immédiatement
					onResizeGalerie();
				});
			}
			//en cas de mise à jour de html par ajax
			if (window["clWDUtil"]!==undefined) 
			{
				if (clWDUtil.m_oNotificationsAjoutHTML)
				{
					clWDUtil.m_oNotificationsAjoutHTML.AddNotification(fOnModifGalerie);
				}
				if (clWDUtil.m_oNotificationsFinAJAX)
				{
					clWDUtil.m_oNotificationsFinAJAX.AddNotification(fOnModifGalerie);
				}
			}

			//Binding de la galerie, layout à chaque rAF après resize
			$(window)
			//.scroll(function() { oOffsetGalerie = jqGalerie.offset(); })
			.resize(onResizeGalerie);


			//pinch
			if (jqTableGalerie.hasClass("wbGaleriePleinPinch"))
			jqGalerie.swipe( 
			{
			    pinchStatus:function(event, phase, pinchDirection, pinchDistance, duration, fingerCount, pinchZoom, fingerData)
			    { 
			    	//console.log("pinchStatus",arguments); 

			    	//pas 2 doigts ou pas de direction => ignore 
			    	if (!MODE_LIGNE ||fingerCount!=2 || (!pinchDirection)) return;

		    		//annule le comportement natif de l'event (zoom sur la page)
					event.stopPropagation();
		    		event.preventDefault();

			    	//sens pas encore sûr
			    	//if (duration<100)
			    	if ( (phase !="end") && (phase !="cancel"))
		    		{
		    			if (Math.abs(1-pinchZoom)<=0.02)
	    				{
	    					return;
	    				}
		    		}

		    		//annule toute frame de pinch à venir 
					if (jqGalerie[0].rafPinch)
					{
						cancelAnimationFrame(jqGalerie[0].rafPinch);
						jqGalerie[0].rafPinch = undefined;
					}	    		

					//freine le scale après un zoom au dela du min/max
		    		var ZOOM_MINMAX_SCALE_COEFF = 0.25;
		    		function appliqueScaleCoeff(z)
		    		{
		    			var nZoomActuel = parseFloat(z);
		    			//return nZoomActuel>1 ? (1+(nZoomActuel-1)*ZOOM_MINMAX_SCALE_COEFF) : (1-(1-nZoomActuel)*ZOOM_MINMAX_SCALE_COEFF);
		    			return nZoomActuel>1 ? (1-(nZoomActuel-1)*ZOOM_MINMAX_SCALE_COEFF) : (1-(1-nZoomActuel)*ZOOM_MINMAX_SCALE_COEFF);
		    		}

			    	var bAuDelaDuZoomMax = jqGalerie[0].lastPinchStatus && jqGalerie[0].lastPinchStatus.bAuDelaDuZoomMax;
			    	var bEnDecaDuZoomMin = jqGalerie[0].lastPinchStatus && jqGalerie[0].lastPinchStatus.bEnDecaDuZoomMin;
		    		var dDistanceOffset = jqGalerie[0].lastPinchStatus ? jqGalerie[0].lastPinchStatus.dDistanceOffset : 0;
		    		var dPinchZoomOffset = jqGalerie[0].lastPinchStatus ? jqGalerie[0].lastPinchStatus.dPinchZoomOffset : 1;
			    	var dZoom = parseFloat(pinchZoom) / dPinchZoomOffset;

		    		if (dZoom<1) pinchDirection="out";//blindage
			    	var dDistance = parseFloat(pinchDistance) - dDistanceOffset;

					//début de pinch
					function doPinch(bZoomIn)
					{
						//ré init des globales à la galerie

						//le pinch agit sur les tailles min
						PINCH_DISTANCE = jqRepetitions.eq(0).height();

						if (PINCH_DISTANCE<ZOOM_HAUTEUR_MIN)
						{
							bEnDecaDuZoomMin=true;
						}

						//arrête de zoomer quand on a une image par ligne
						if (dZoom>1 && rows[0].length==1)
						{
							bAuDelaDuZoomMax=true;
						}

						if (!bEnDecaDuZoomMin && !bAuDelaDuZoomMax)
						{
							dCoeffZoomPinch = (bZoomIn ?  (dCoeffZoomPinch*PINCH_COEFF) : (dCoeffZoomPinch/PINCH_COEFF) );//30% de zoom par pinch
							//SUGG le zoom peut utiliser dIncrementLargeurZoomPinch et dIncrementHauteurZoomPinch au lieu du coeff

							if (dCoeffZoomPinch<ZOOM_COEFF_MIN || dCoeffZoomPinch>ZOOM_COEFF_MAX)
							{
								//ignore
								if (dCoeffZoomPinch<ZOOM_COEFF_MIN) bEnDecaDuZoomMin=true;
								if (dCoeffZoomPinch>ZOOM_COEFF_MAX) bAuDelaDuZoomMax=true;
								dCoeffZoomPinch = Math.max(ZOOM_COEFF_MIN,Math.min(ZOOM_COEFF_MAX,dCoeffZoomPinch));//blindage si trop petit ou trop grand
							}
							else 
							{
								setDimensionsReference();		
								afficheImages(true);
								//jqRepetitions.get(0).onAnimateStep doit être setté désormais														
							}
							dPinchZoomOffset = pinchZoom;
						}
						else 
						{
							//raz les transformations précédentes
							jqRepetitions.each(function(){
								if (this.onAnimateStep)
								{
									//va à la fin du pinch précédent
									this.onAnimateStep.apply(this,[1]);
								}								
							})						
							.css({transform : ""})
							;
						}
						dDistanceOffset += dDistance;
						//console.log("zoom " + dCoeffZoomPinch);
					}

		    		//fin du pinch
		    		if (phase == "cancel" && Math.abs(pinchDistance / PINCH_DISTANCE)>0.25)
	    			{
	    				//si la phase est cancel mais que le pinch a fait plus de 25% de la distance on accepte
						phase = "end";
	    			}
		    		if (phase == "cancel" || phase == "end")
					{
						if (!jqGalerie[0].lastPinchStatus) return;

						if (bAuDelaDuZoomMax || bEnDecaDuZoomMin)
						{
							//revient au zoom 1
							var nZoomActuel = appliqueScaleCoeff(jqGalerie[0].lastPinchStatus.pinchZoom/dPinchZoomOffset);
							jqGalerie.animate({content : 1},
							{
								duration:DUREE_ANIMATION||150
							, 	step : function(now) { $(this).css({transform : "scale(" + (nZoomActuel + ((nZoomActuel<1 ? (1-nZoomActuel) : (nZoomActuel-1))*now)) + ")" }); }
							, 	done : function(now) { $(this).css({transform : "",transformOrigin : "" }); }
							});
						}
						else 
						{		    		
				    		if (phase == "cancel")
			    			{						
			    				//inverse le zoom
			    				var tmp = PINCH_DISTANCE;
			    				doPinch(pinchDirection!="in");
			    				PINCH_DISTANCE = tmp;
			    			}						
							else 
							{
								PINCH_DISTANCE = jqRepetitions.eq(0).height();
							}
							var dDistanceRestante = Math.min(1,(parseFloat(jqGalerie[0].lastPinchStatus.pinchDistance)-dDistanceOffset)/PINCH_DISTANCE);

							//finit le pinch
							jqRepetitions.each(function(){
								$(this).animate({content : 1},
									{
										duration : DUREE_ANIMATION||150
									, 	done : function() { }
									, 	step : function(now)
										{
											if (this.onAnimateStep)
											{
												var dNowAvecOffset = ((now * (1 - dDistanceRestante)) + dDistanceRestante);
												this.onAnimateStep.apply(this,[dNowAvecOffset]);//100px est pris comme timeline
											}
										}
									}
								);		
							});
						}
						jqGalerie[0].lastPinchStatus = undefined;	
						return;
					}


					//cas du premier pinch
					//cas où on a dépassé le zoom et il faut reprendre un zoom supplémentaire
					//cas changement de sens 
					if (!jqGalerie[0].lastPinchStatus || dDistance>PINCH_DISTANCE || (jqGalerie[0].lastPinchStatus.pinchDirection != pinchDirection) )//hauteur de champ pris comme timeline
					{					
						doPinch(pinchDirection=="in");
						if (jqGalerie[0].lastPinchStatus && jqGalerie[0].lastPinchStatus.pinchDirection != pinchDirection)
						{
							//console.log("inversion");
							doPinch(pinchDirection=="in");
						}
					}
				
					//console.log("onAnimateStep",arguments); 
					if (bEnDecaDuZoomMin || bAuDelaDuZoomMax)
					{
						//ignore et scale					
						jqGalerie[0].rafPinch=requestAnimationFrame(function(){
							jqGalerie.css({transform : "scale(" + appliqueScaleCoeff(dZoom) + ")",transformOrigin:"top center" });
						});
					}
					//continue le pinch
					else jqGalerie[0].rafPinch=requestAnimationFrame(function(){
						jqRepetitions.each(function(){
							if (this.onAnimateStep)
								this.onAnimateStep.apply(this,[Math.min(1,dDistance/PINCH_DISTANCE)]);//100px est pris comme timeline
						});
					});
				

					//TODO debug 
					//cas où on est revenu au point de départ
					
					jqGalerie[0].lastPinchStatus = { pinchDirection : pinchDirection, pinchDistance: pinchDistance, pinchZoom : dZoom, bEnDecaDuZoomMin : bEnDecaDuZoomMin, bAuDelaDuZoomMax : bAuDelaDuZoomMax, dDistanceOffset : dDistanceOffset, dPinchZoomOffset : dPinchZoomOffset };
			    }
			    //,doubleTap:oThis.dblclick,	tap : function(){/*permet au dbltap d'être traité*/}
			    //,longTap:, non, traité par le swipestatus
			    //,swipeStatus: oThis.swipeStatus
			    //,pinchThreshold:0 
			    ,excludedElements: "label, button, input, select, textarea, .noSwipe" //retire le a des exclusions afin d'autoriser le swipe d'images cliquables et vignette
	      	});


	      	//zoom par code WL
	      	jqGalerie
	      	.on("trigger.wb.galerie.zoom.ouvre",function(jqEvent,nIndiceRepetition)
	      	{
				var jqRepetition = jqRepetitions.eq(nIndiceRepetition-1);
				if (jqRepetition.length)
				{
					//masque et donc ferme le zoom précédent
					fFermeZoom(false);					
					//zoom 
					fOuvreZoom(jqRepetition,true);
				}
	      	})
	      	.on("trigger.wb.galerie.zoom.ferme",function(jqEvent)
	      	{
				//masque 
				fFermeZoom(true);				
	      	})
	      	;
	    }


	}//function fInitGalerie(bInitSecondaire)

	//pour chaque galerie
	jqListeGaleries.each(function(){ fInitGalerie.apply(this,[]);});
	
});

//source : http://www.quasimondo.com/StackBlurForCanvas/StackBlurDemo.html
/*
    StackBlur - a fast almost Gaussian Blur For Canvas
    Version:     0.5
    Author:        Mario Klingemann
    Contact:     mario@quasimondo.com
    Website:    http://www.quasimondo.com/StackBlurForCanvas
    Twitter:    @quasimondo
    In case you find this class useful - especially in commercial projects -
    I am not totally unhappy for a small donation to my PayPal account
    mario@quasimondo.de
    Or support me on flattr:
    https://flattr.com/thing/72791/StackBlur-a-fast-almost-Gaussian-Blur-Effect-for-CanvasJavascript
    Copyright (c) 2010 Mario Klingemann
    Permission is hereby granted, free of charge, to any person
    obtaining a copy of this software and associated documentation
    files (the "Software"), to deal in the Software without
    restriction, including without limitation the rights to use,
    copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following
    conditions:
    The above copyright notice and this permission notice shall be
    included in all copies or substantial portions of the Software.
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
    OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
    NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
    HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
    WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
    OTHER DEALINGS IN THE SOFTWARE.
    */


var mul_table = [
    512,512,456,512,328,456,335,512,405,328,271,456,388,335,292,512,
    454,405,364,328,298,271,496,456,420,388,360,335,312,292,273,512,
    482,454,428,405,383,364,345,328,312,298,284,271,259,496,475,456,
    437,420,404,388,374,360,347,335,323,312,302,292,282,273,265,512,
    497,482,468,454,441,428,417,405,394,383,373,364,354,345,337,328,
    320,312,305,298,291,284,278,271,265,259,507,496,485,475,465,456,
    446,437,428,420,412,404,396,388,381,374,367,360,354,347,341,335,
    329,323,318,312,307,302,297,292,287,282,278,273,269,265,261,512,
    505,497,489,482,475,468,461,454,447,441,435,428,422,417,411,405,
    399,394,389,383,378,373,368,364,359,354,350,345,341,337,332,328,
    324,320,316,312,309,305,301,298,294,291,287,284,281,278,274,271,
    268,265,262,259,257,507,501,496,491,485,480,475,470,465,460,456,
    451,446,442,437,433,428,424,420,416,412,408,404,400,396,392,388,
    385,381,377,374,370,367,363,360,357,354,350,347,344,341,338,335,
    332,329,326,323,320,318,315,312,310,307,304,302,299,297,294,292,
    289,287,285,282,280,278,275,273,271,269,267,265,263,261,259];


var shg_table = [
    9, 11, 12, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 17,
    17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 19,
    19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20,
    20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 21,
    21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21,
    21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22,
    22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
    22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23,
    23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
    23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
    23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
    23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
    24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
    24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
    24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
    24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24 ];


function processImage(img, canvas, radius, blurAlphaChannel)
{
    if (typeof(img) == 'string') {
        var img = document.getElementById(img);
    }
    else if (typeof HTMLImageElement !== 'undefined' && !img instanceof HTMLImageElement) {
        return;
    }
    var w = img.naturalWidth;
    var h = img.naturalHeight;

    if (typeof(canvas) == 'string') {
        var canvas = document.getElementById(canvas);
    }
    else if (typeof HTMLCanvasElement !== 'undefined' && !canvas instanceof HTMLCanvasElement) {
        return;
    }

    canvas.style.width  = w + 'px';
    canvas.style.height = h + 'px';
    canvas.width = w;
    canvas.height = h;

    var context = canvas.getContext('2d');
    context.clearRect(0, 0, w, h);
    context.drawImage(img, 0, 0);

    if (isNaN(radius) || radius < 1) return;

    if (blurAlphaChannel)
        processCanvasRGBA(canvas, 0, 0, w, h, radius);
    else
        processCanvasRGB(canvas, 0, 0, w, h, radius);
}

function getImageDataFromCanvas(canvas, top_x, top_y, width, height)
{
    if (typeof(canvas) == 'string')
        var canvas  = document.getElementById(canvas);
    else if (typeof HTMLCanvasElement !== 'undefined' && !canvas instanceof HTMLCanvasElement)
        return;

    var context = canvas.getContext('2d');
    var imageData;

    try {
        try {
            imageData = context.getImageData(top_x, top_y, width, height);
        } catch(e) {
            throw new Error("unable to access local image data: " + e);
            return;
        }
    } catch(e) {
        throw new Error("unable to access image data: " + e);
    }

    return imageData;
}

function processCanvasRGBA(canvas, top_x, top_y, width, height, radius)
{
    if (isNaN(radius) || radius < 1) return;
    radius |= 0;

    var imageData = getImageDataFromCanvas(canvas, top_x, top_y, width, height);

    imageData = processImageDataRGBA(imageData, top_x, top_y, width, height, radius);

    canvas.getContext('2d').putImageData(imageData, top_x, top_y);
}

function processImageDataRGBA(imageData, top_x, top_y, width, height, radius)
{
    var pixels = imageData.data;

    var x, y, i, p, yp, yi, yw, r_sum, g_sum, b_sum, a_sum,
        r_out_sum, g_out_sum, b_out_sum, a_out_sum,
        r_in_sum, g_in_sum, b_in_sum, a_in_sum,
        pr, pg, pb, pa, rbs;

    var div = radius + radius + 1;
    var w4 = width << 2;
    var widthMinus1  = width - 1;
    var heightMinus1 = height - 1;
    var radiusPlus1  = radius + 1;
    var sumFactor = radiusPlus1 * (radiusPlus1 + 1) / 2;

    var stackStart = new BlurStack();
    var stack = stackStart;
    for (i = 1; i < div; i++)
    {
        stack = stack.next = new BlurStack();
        if (i == radiusPlus1) var stackEnd = stack;
    }
    stack.next = stackStart;
    var stackIn = null;
    var stackOut = null;

    yw = yi = 0;

    var mul_sum = mul_table[radius];
    var shg_sum = shg_table[radius];

    for (y = 0; y < height; y++)
    {
        r_in_sum = g_in_sum = b_in_sum = a_in_sum = r_sum = g_sum = b_sum = a_sum = 0;

        r_out_sum = radiusPlus1 * (pr = pixels[yi]);
        g_out_sum = radiusPlus1 * (pg = pixels[yi+1]);
        b_out_sum = radiusPlus1 * (pb = pixels[yi+2]);
        a_out_sum = radiusPlus1 * (pa = pixels[yi+3]);

        r_sum += sumFactor * pr;
        g_sum += sumFactor * pg;
        b_sum += sumFactor * pb;
        a_sum += sumFactor * pa;

        stack = stackStart;

        for (i = 0; i < radiusPlus1; i++)
        {
            stack.r = pr;
            stack.g = pg;
            stack.b = pb;
            stack.a = pa;
            stack = stack.next;
        }

        for (i = 1; i < radiusPlus1; i++)
        {
            p = yi + ((widthMinus1 < i ? widthMinus1 : i) << 2);
            r_sum += (stack.r = (pr = pixels[p])) * (rbs = radiusPlus1 - i);
            g_sum += (stack.g = (pg = pixels[p+1])) * rbs;
            b_sum += (stack.b = (pb = pixels[p+2])) * rbs;
            a_sum += (stack.a = (pa = pixels[p+3])) * rbs;

            r_in_sum += pr;
            g_in_sum += pg;
            b_in_sum += pb;
            a_in_sum += pa;

            stack = stack.next;
        }


        stackIn = stackStart;
        stackOut = stackEnd;
        for (x = 0; x < width; x++)
        {
            pixels[yi+3] = pa = (a_sum * mul_sum) >> shg_sum;
            if (pa != 0)
            {
                pa = 255 / pa;
                pixels[yi]   = ((r_sum * mul_sum) >> shg_sum) * pa;
                pixels[yi+1] = ((g_sum * mul_sum) >> shg_sum) * pa;
                pixels[yi+2] = ((b_sum * mul_sum) >> shg_sum) * pa;
            } else {
                pixels[yi] = pixels[yi+1] = pixels[yi+2] = 0;
            }

            r_sum -= r_out_sum;
            g_sum -= g_out_sum;
            b_sum -= b_out_sum;
            a_sum -= a_out_sum;

            r_out_sum -= stackIn.r;
            g_out_sum -= stackIn.g;
            b_out_sum -= stackIn.b;
            a_out_sum -= stackIn.a;

            p =  (yw + ((p = x + radius + 1) < widthMinus1 ? p : widthMinus1)) << 2;

            r_in_sum += (stackIn.r = pixels[p]);
            g_in_sum += (stackIn.g = pixels[p+1]);
            b_in_sum += (stackIn.b = pixels[p+2]);
            a_in_sum += (stackIn.a = pixels[p+3]);

            r_sum += r_in_sum;
            g_sum += g_in_sum;
            b_sum += b_in_sum;
            a_sum += a_in_sum;

            stackIn = stackIn.next;

            r_out_sum += (pr = stackOut.r);
            g_out_sum += (pg = stackOut.g);
            b_out_sum += (pb = stackOut.b);
            a_out_sum += (pa = stackOut.a);

            r_in_sum -= pr;
            g_in_sum -= pg;
            b_in_sum -= pb;
            a_in_sum -= pa;

            stackOut = stackOut.next;

            yi += 4;
        }
        yw += width;
    }


    for (x = 0; x < width; x++)
    {
        g_in_sum = b_in_sum = a_in_sum = r_in_sum = g_sum = b_sum = a_sum = r_sum = 0;

        yi = x << 2;
        r_out_sum = radiusPlus1 * (pr = pixels[yi]);
        g_out_sum = radiusPlus1 * (pg = pixels[yi+1]);
        b_out_sum = radiusPlus1 * (pb = pixels[yi+2]);
        a_out_sum = radiusPlus1 * (pa = pixels[yi+3]);

        r_sum += sumFactor * pr;
        g_sum += sumFactor * pg;
        b_sum += sumFactor * pb;
        a_sum += sumFactor * pa;

        stack = stackStart;

        for (i = 0; i < radiusPlus1; i++)
        {
            stack.r = pr;
            stack.g = pg;
            stack.b = pb;
            stack.a = pa;
            stack = stack.next;
        }

        yp = width;

        for (i = 1; i <= radius; i++)
        {
            yi = (yp + x) << 2;

            r_sum += (stack.r = (pr = pixels[yi])) * (rbs = radiusPlus1 - i);
            g_sum += (stack.g = (pg = pixels[yi+1])) * rbs;
            b_sum += (stack.b = (pb = pixels[yi+2])) * rbs;
            a_sum += (stack.a = (pa = pixels[yi+3])) * rbs;

            r_in_sum += pr;
            g_in_sum += pg;
            b_in_sum += pb;
            a_in_sum += pa;

            stack = stack.next;

            if(i < heightMinus1)
            {
                yp += width;
            }
        }

        yi = x;
        stackIn = stackStart;
        stackOut = stackEnd;
        for (y = 0; y < height; y++)
        {
            p = yi << 2;
            pixels[p+3] = pa = (a_sum * mul_sum) >> shg_sum;
            if (pa > 0)
            {
                pa = 255 / pa;
                pixels[p]   = ((r_sum * mul_sum) >> shg_sum) * pa;
                pixels[p+1] = ((g_sum * mul_sum) >> shg_sum) * pa;
                pixels[p+2] = ((b_sum * mul_sum) >> shg_sum) * pa;
            } else {
                pixels[p] = pixels[p+1] = pixels[p+2] = 0;
            }

            r_sum -= r_out_sum;
            g_sum -= g_out_sum;
            b_sum -= b_out_sum;
            a_sum -= a_out_sum;

            r_out_sum -= stackIn.r;
            g_out_sum -= stackIn.g;
            b_out_sum -= stackIn.b;
            a_out_sum -= stackIn.a;

            p = (x + (((p = y + radiusPlus1) < heightMinus1 ? p : heightMinus1) * width)) << 2;

            r_sum += (r_in_sum += (stackIn.r = pixels[p]));
            g_sum += (g_in_sum += (stackIn.g = pixels[p+1]));
            b_sum += (b_in_sum += (stackIn.b = pixels[p+2]));
            a_sum += (a_in_sum += (stackIn.a = pixels[p+3]));

            stackIn = stackIn.next;

            r_out_sum += (pr = stackOut.r);
            g_out_sum += (pg = stackOut.g);
            b_out_sum += (pb = stackOut.b);
            a_out_sum += (pa = stackOut.a);

            r_in_sum -= pr;
            g_in_sum -= pg;
            b_in_sum -= pb;
            a_in_sum -= pa;

            stackOut = stackOut.next;

            yi += width;
        }
    }
    return imageData;
}

function processCanvasRGB(canvas, top_x, top_y, width, height, radius)
{
    if (isNaN(radius) || radius < 1) return;
    radius |= 0;

    var imageData = getImageDataFromCanvas(canvas, top_x, top_y, width, height);
    imageData = processImageDataRGB(imageData, top_x, top_y, width, height, radius);

    canvas.getContext('2d').putImageData(imageData, top_x, top_y);
}

function processImageDataRGB(imageData, top_x, top_y, width, height, radius)
{
    var pixels = imageData.data;

    var x, y, i, p, yp, yi, yw, r_sum, g_sum, b_sum,
        r_out_sum, g_out_sum, b_out_sum,
        r_in_sum, g_in_sum, b_in_sum,
        pr, pg, pb, rbs;

    var div = radius + radius + 1;
    var w4 = width << 2;
    var widthMinus1  = width - 1;
    var heightMinus1 = height - 1;
    var radiusPlus1  = radius + 1;
    var sumFactor = radiusPlus1 * (radiusPlus1 + 1) / 2;

    var stackStart = new BlurStack();
    var stack = stackStart;
    for (i = 1; i < div; i++)
    {
        stack = stack.next = new BlurStack();
        if (i == radiusPlus1) var stackEnd = stack;
    }
    stack.next = stackStart;
    var stackIn = null;
    var stackOut = null;

    yw = yi = 0;

    var mul_sum = mul_table[radius];
    var shg_sum = shg_table[radius];

    for (y = 0; y < height; y++)
    {
        r_in_sum = g_in_sum = b_in_sum = r_sum = g_sum = b_sum = 0;

        r_out_sum = radiusPlus1 * (pr = pixels[yi]);
        g_out_sum = radiusPlus1 * (pg = pixels[yi+1]);
        b_out_sum = radiusPlus1 * (pb = pixels[yi+2]);

        r_sum += sumFactor * pr;
        g_sum += sumFactor * pg;
        b_sum += sumFactor * pb;

        stack = stackStart;

        for (i = 0; i < radiusPlus1; i++)
        {
            stack.r = pr;
            stack.g = pg;
            stack.b = pb;
            stack = stack.next;
        }

        for (i = 1; i < radiusPlus1; i++)
        {
            p = yi + ((widthMinus1 < i ? widthMinus1 : i) << 2);
            r_sum += (stack.r = (pr = pixels[p])) * (rbs = radiusPlus1 - i);
            g_sum += (stack.g = (pg = pixels[p+1])) * rbs;
            b_sum += (stack.b = (pb = pixels[p+2])) * rbs;

            r_in_sum += pr;
            g_in_sum += pg;
            b_in_sum += pb;

            stack = stack.next;
        }


        stackIn = stackStart;
        stackOut = stackEnd;
        for (x = 0; x < width; x++)
        {
            pixels[yi]   = (r_sum * mul_sum) >> shg_sum;
            pixels[yi+1] = (g_sum * mul_sum) >> shg_sum;
            pixels[yi+2] = (b_sum * mul_sum) >> shg_sum;

            r_sum -= r_out_sum;
            g_sum -= g_out_sum;
            b_sum -= b_out_sum;

            r_out_sum -= stackIn.r;
            g_out_sum -= stackIn.g;
            b_out_sum -= stackIn.b;

            p =  (yw + ((p = x + radius + 1) < widthMinus1 ? p : widthMinus1)) << 2;

            r_in_sum += (stackIn.r = pixels[p]);
            g_in_sum += (stackIn.g = pixels[p+1]);
            b_in_sum += (stackIn.b = pixels[p+2]);

            r_sum += r_in_sum;
            g_sum += g_in_sum;
            b_sum += b_in_sum;

            stackIn = stackIn.next;

            r_out_sum += (pr = stackOut.r);
            g_out_sum += (pg = stackOut.g);
            b_out_sum += (pb = stackOut.b);

            r_in_sum -= pr;
            g_in_sum -= pg;
            b_in_sum -= pb;

            stackOut = stackOut.next;

            yi += 4;
        }
        yw += width;
    }


    for (x = 0; x < width; x++)
    {
        g_in_sum = b_in_sum = r_in_sum = g_sum = b_sum = r_sum = 0;

        yi = x << 2;
        r_out_sum = radiusPlus1 * (pr = pixels[yi]);
        g_out_sum = radiusPlus1 * (pg = pixels[yi+1]);
        b_out_sum = radiusPlus1 * (pb = pixels[yi+2]);

        r_sum += sumFactor * pr;
        g_sum += sumFactor * pg;
        b_sum += sumFactor * pb;

        stack = stackStart;

        for (i = 0; i < radiusPlus1; i++)
        {
            stack.r = pr;
            stack.g = pg;
            stack.b = pb;
            stack = stack.next;
        }

        yp = width;

        for (i = 1; i <= radius; i++)
        {
            yi = (yp + x) << 2;

            r_sum += (stack.r = (pr = pixels[yi])) * (rbs = radiusPlus1 - i);
            g_sum += (stack.g = (pg = pixels[yi+1])) * rbs;
            b_sum += (stack.b = (pb = pixels[yi+2])) * rbs;

            r_in_sum += pr;
            g_in_sum += pg;
            b_in_sum += pb;

            stack = stack.next;

            if(i < heightMinus1)
            {
                yp += width;
            }
        }

        yi = x;
        stackIn = stackStart;
        stackOut = stackEnd;
        for (y = 0; y < height; y++)
        {
            p = yi << 2;
            pixels[p]   = (r_sum * mul_sum) >> shg_sum;
            pixels[p+1] = (g_sum * mul_sum) >> shg_sum;
            pixels[p+2] = (b_sum * mul_sum) >> shg_sum;

            r_sum -= r_out_sum;
            g_sum -= g_out_sum;
            b_sum -= b_out_sum;

            r_out_sum -= stackIn.r;
            g_out_sum -= stackIn.g;
            b_out_sum -= stackIn.b;

            p = (x + (((p = y + radiusPlus1) < heightMinus1 ? p : heightMinus1) * width)) << 2;

            r_sum += (r_in_sum += (stackIn.r = pixels[p]));
            g_sum += (g_in_sum += (stackIn.g = pixels[p+1]));
            b_sum += (b_in_sum += (stackIn.b = pixels[p+2]));

            stackIn = stackIn.next;

            r_out_sum += (pr = stackOut.r);
            g_out_sum += (pg = stackOut.g);
            b_out_sum += (pb = stackOut.b);

            r_in_sum -= pr;
            g_in_sum -= pg;
            b_in_sum -= pb;

            stackOut = stackOut.next;

            yi += width;
        }
    }

    return imageData;
}

function BlurStack()
{
    this.r = 0;
    this.g = 0;
    this.b = 0;
    this.a = 0;
    this.next = null;
}

/*!
 * Color Thief v2.0
 * by Lokesh Dhakar - http://www.lokeshdhakar.com
 *
 * Thanks
 * ------
 * Nick Rabinowitz - For creating quantize.js.
 * John Schulz - For clean up and optimization. @JFSIII
 * Nathan Spady - For adding drag and drop support to the demo page.
 *
 * License
 * -------
 * Copyright 2011, 2015 Lokesh Dhakar
 * Released under the MIT license
 * https://raw.githubusercontent.com/lokesh/color-thief/master/LICENSE
 *
 */


/*
  CanvasImage Class
  Class that wraps the html image element and canvas.
  It also simplifies some of the canvas context manipulation
  with a set of helper functions.
*/
var CanvasImage = function (image,bCanvasDansDOM) {
    this.canvas  = document.createElement('canvas');
    this.context = this.canvas.getContext('2d');
    if (true == (this.bCanvasDansDOM = bCanvasDansDOM))
	    document.body.appendChild(this.canvas);

    this.width  = this.canvas.width  = image.width;
    this.height = this.canvas.height = image.height;

    this.context.drawImage(image, 0, 0, this.width, this.height);
};

CanvasImage.prototype.clear = function () {
    this.context.clearRect(0, 0, this.width, this.height);
};

CanvasImage.prototype.update = function (imageData) {
    this.context.putImageData(imageData, 0, 0);
};

CanvasImage.prototype.getPixelCount = function () {
    return this.width * this.height;
};

CanvasImage.prototype.getImageData = function () {
    return this.context.getImageData(0, 0, this.width, this.height);
};

CanvasImage.prototype.removeCanvas = function () {
	if (this.bCanvasDansDOM)
    	this.canvas.parentNode.removeChild(this.canvas);
};


var ColorThief = function () {};

/*
 * getColor(sourceImage[, quality])
 * returns {r: num, g: num, b: num}
 *
 * Use the median cut algorithm provided by quantize.js to cluster similar
 * colors and return the base color from the largest cluster.
 *
 * Quality is an optional argument. It needs to be an integer. 1 is the highest quality settings.
 * 10 is the default. There is a trade-off between quality and speed. The bigger the number, the
 * faster a color will be returned but the greater the likelihood that it will not be the visually
 * most dominant color.
 *
 * */
ColorThief.prototype.getColor = function(sourceImage, bCanvasDansDOM, quality, oDataUrlThumbnail) {
    var palette       = this.getPalette(sourceImage, bCanvasDansDOM, 5, quality, oDataUrlThumbnail);
    var dominantColor = palette[0];
    return dominantColor;
};


/*
 * getPalette(sourceImage[, colorCount, quality])
 * returns array[ {r: num, g: num, b: num}, {r: num, g: num, b: num}, ...]
 *
 * Use the median cut algorithm provided by quantize.js to cluster similar colors.
 *
 * colorCount determines the size of the palette; the number of colors returned. If not set, it
 * defaults to 10.
 *
 * BUGGY: Function does not always return the requested amount of colors. It can be +/- 2.
 *
 * quality is an optional argument. It needs to be an integer. 1 is the highest quality settings.
 * 10 is the default. There is a trade-off between quality and speed. The bigger the number, the
 * faster the palette generation but the greater the likelihood that colors will be missed.
 *
 *
 */
ColorThief.prototype.getPalette = function(sourceImage, bCanvasDansDOM, colorCount, quality, oDataUrlThumbnail) {

    if (typeof colorCount === 'undefined') {
        colorCount = 10;
    }
    if (typeof quality === 'undefined' || quality < 1) {
        quality = 10;
    }

    // Create custom CanvasImage object
    var image      = new CanvasImage(sourceImage,bCanvasDansDOM);
    var imageData  = image.getImageData();
    var pixels     = imageData.data;
    var pixelCount = image.getPixelCount();

    // Store the RGB values in an array format suitable for quantize function
    var pixelArray = [];
    for (var i = 0, offset, r, g, b, a; i < pixelCount; i = i + quality) {
        offset = i * 4;
        r = pixels[offset + 0];
        g = pixels[offset + 1];
        b = pixels[offset + 2];
        a = pixels[offset + 3];
        // If pixel is mostly opaque and not white
        if (a >= 125) {
            if (!(r > 250 && g > 250 && b > 250)) {
                pixelArray.push([r, g, b]);
            }
        }
    }

    // Send array to quantize function which clusters values
    // using median cut algorithm
    var cmap    = MMCQ.quantize(pixelArray, colorCount);
    var palette = cmap? cmap.palette() : null;

    //GF création d'une vignette
    if (oDataUrlThumbnail)
	{
		image.canvas.width = oDataUrlThumbnail.width;
		image.canvas.height = oDataUrlThumbnail.height;
		image.context.drawImage(sourceImage,0,0,oDataUrlThumbnail.width ,oDataUrlThumbnail.height);
		//avec flou ?
		if (oDataUrlThumbnail.radius)
		{
			processCanvasRGB(image.canvas,0,0,oDataUrlThumbnail.width,oDataUrlThumbnail.height,oDataUrlThumbnail.radius||90);		
		}
		oDataUrlThumbnail.dataurl = image.canvas.toDataURL("image/jpeg", oDataUrlThumbnail.quality||1);
	}

    // Clean up
    image.removeCanvas();

    return palette;
};




/*!
 * quantize.js Copyright 2008 Nick Rabinowitz.
 * Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
 */

// fill out a couple protovis dependencies
/*!
 * Block below copied from Protovis: http://mbostock.github.com/protovis/
 * Copyright 2010 Stanford Visualization Group
 * Licensed under the BSD License: http://www.opensource.org/licenses/bsd-license.php
 */
if (!pv) {
    var pv = {
        map: function(array, f) {
          var o = {};
          return f ? array.map(function(d, i) { o.index = i; return f.call(o, d); }) : array.slice();
        },
        naturalOrder: function(a, b) {
            return (a < b) ? -1 : ((a > b) ? 1 : 0);
        },
        sum: function(array, f) {
          var o = {};
          return array.reduce(f ? function(p, d, i) { o.index = i; return p + f.call(o, d); } : function(p, d) { return p + d; }, 0);
        },
        max: function(array, f) {
          return Math.max.apply(null, f ? pv.map(array, f) : array);
        }
    };
}



/**
 * Basic Javascript port of the MMCQ (modified median cut quantization)
 * algorithm from the Leptonica library (http://www.leptonica.com/).
 * Returns a color map you can use to map original pixels to the reduced
 * palette. Still a work in progress.
 *
 * @author Nick Rabinowitz
 * @example

// array of pixels as [R,G,B] arrays
var myPixels = [[190,197,190], [202,204,200], [207,214,210], [211,214,211], [205,207,207]
                // etc
                ];
var maxColors = 4;

var cmap = MMCQ.quantize(myPixels, maxColors);
var newPalette = cmap.palette();
var newPixels = myPixels.map(function(p) {
    return cmap.map(p);
});

 */
var MMCQ = (function() {
    // private constants
    var sigbits = 5,
        rshift = 8 - sigbits,
        maxIterations = 1000,
        fractByPopulations = 0.75;

    // get reduced-space color index for a pixel
    function getColorIndex(r, g, b) {
        return (r << (2 * sigbits)) + (g << sigbits) + b;
    }

    // Simple priority queue
    function PQueue(comparator) {
        var contents = [],
            sorted = false;

        function sort() {
            contents.sort(comparator);
            sorted = true;
        }

        return {
            push: function(o) {
                contents.push(o);
                sorted = false;
            },
            peek: function(index) {
                if (!sorted) sort();
                if (index===undefined) index = contents.length - 1;
                return contents[index];
            },
            pop: function() {
                if (!sorted) sort();
                return contents.pop();
            },
            size: function() {
                return contents.length;
            },
            map: function(f) {
                return contents.map(f);
            },
            debug: function() {
                if (!sorted) sort();
                return contents;
            }
        };
    }

    // 3d color space box
    function VBox(r1, r2, g1, g2, b1, b2, histo) {
        var vbox = this;
        vbox.r1 = r1;
        vbox.r2 = r2;
        vbox.g1 = g1;
        vbox.g2 = g2;
        vbox.b1 = b1;
        vbox.b2 = b2;
        vbox.histo = histo;
    }
    VBox.prototype = {
        volume: function(force) {
            var vbox = this;
            if (!vbox._volume || force) {
                vbox._volume = ((vbox.r2 - vbox.r1 + 1) * (vbox.g2 - vbox.g1 + 1) * (vbox.b2 - vbox.b1 + 1));
            }
            return vbox._volume;
        },
        count: function(force) {
            var vbox = this,
                histo = vbox.histo;
            if (!vbox._count_set || force) {
                var npix = 0,
                    i, j, k;
                for (i = vbox.r1; i <= vbox.r2; i++) {
                    for (j = vbox.g1; j <= vbox.g2; j++) {
                        for (k = vbox.b1; k <= vbox.b2; k++) {
                             index = getColorIndex(i,j,k);
                             npix += (histo[index] || 0);
                        }
                    }
                }
                vbox._count = npix;
                vbox._count_set = true;
            }
            return vbox._count;
        },
        copy: function() {
            var vbox = this;
            return new VBox(vbox.r1, vbox.r2, vbox.g1, vbox.g2, vbox.b1, vbox.b2, vbox.histo);
        },
        avg: function(force) {
            var vbox = this,
                histo = vbox.histo;
            if (!vbox._avg || force) {
                var ntot = 0,
                    mult = 1 << (8 - sigbits),
                    rsum = 0,
                    gsum = 0,
                    bsum = 0,
                    hval,
                    i, j, k, histoindex;
                for (i = vbox.r1; i <= vbox.r2; i++) {
                    for (j = vbox.g1; j <= vbox.g2; j++) {
                        for (k = vbox.b1; k <= vbox.b2; k++) {
                             histoindex = getColorIndex(i,j,k);
                             hval = histo[histoindex] || 0;
                             ntot += hval;
                             rsum += (hval * (i + 0.5) * mult);
                             gsum += (hval * (j + 0.5) * mult);
                             bsum += (hval * (k + 0.5) * mult);
                        }
                    }
                }
                if (ntot) {
                    vbox._avg = [~~(rsum/ntot), ~~(gsum/ntot), ~~(bsum/ntot)];
                } else {
//                    console.log('empty box');
                    vbox._avg = [
                        ~~(mult * (vbox.r1 + vbox.r2 + 1) / 2),
                        ~~(mult * (vbox.g1 + vbox.g2 + 1) / 2),
                        ~~(mult * (vbox.b1 + vbox.b2 + 1) / 2)
                    ];
                }
            }
            return vbox._avg;
        },
        contains: function(pixel) {
            var vbox = this,
                rval = pixel[0] >> rshift;
                gval = pixel[1] >> rshift;
                bval = pixel[2] >> rshift;
            return (rval >= vbox.r1 && rval <= vbox.r2 &&
                    gval >= vbox.g1 && gval <= vbox.g2 &&
                    bval >= vbox.b1 && bval <= vbox.b2);
        }
    };

    // Color map
    function CMap() {
        this.vboxes = new PQueue(function(a,b) {
            return pv.naturalOrder(
                a.vbox.count()*a.vbox.volume(),
                b.vbox.count()*b.vbox.volume()
            );
        });
    }
    CMap.prototype = {
        push: function(vbox) {
            this.vboxes.push({
                vbox: vbox,
                color: vbox.avg()
            });
        },
        palette: function() {
            return this.vboxes.map(function(vb) { return vb.color; });
        },
        size: function() {
            return this.vboxes.size();
        },
        map: function(color) {
            var vboxes = this.vboxes;
            for (var i=0; i<vboxes.size(); i++) {
                if (vboxes.peek(i).vbox.contains(color)) {
                    return vboxes.peek(i).color;
                }
            }
            return this.nearest(color);
        },
        nearest: function(color) {
            var vboxes = this.vboxes,
                d1, d2, pColor;
            for (var i=0; i<vboxes.size(); i++) {
                d2 = Math.sqrt(
                    Math.pow(color[0] - vboxes.peek(i).color[0], 2) +
                    Math.pow(color[1] - vboxes.peek(i).color[1], 2) +
                    Math.pow(color[2] - vboxes.peek(i).color[2], 2)
                );
                if (d2 < d1 || d1 === undefined) {
                    d1 = d2;
                    pColor = vboxes.peek(i).color;
                }
            }
            return pColor;
        },
        forcebw: function() {
            // XXX: won't  work yet
            var vboxes = this.vboxes;
            vboxes.sort(function(a,b) { return pv.naturalOrder(pv.sum(a.color), pv.sum(b.color));});

            // force darkest color to black if everything < 5
            var lowest = vboxes[0].color;
            if (lowest[0] < 5 && lowest[1] < 5 && lowest[2] < 5)
                vboxes[0].color = [0,0,0];

            // force lightest color to white if everything > 251
            var idx = vboxes.length-1,
                highest = vboxes[idx].color;
            if (highest[0] > 251 && highest[1] > 251 && highest[2] > 251)
                vboxes[idx].color = [255,255,255];
        }
    };

    // histo (1-d array, giving the number of pixels in
    // each quantized region of color space), or null on error
    function getHisto(pixels) {
        var histosize = 1 << (3 * sigbits),
            histo = new Array(histosize),
            index, rval, gval, bval;
        pixels.forEach(function(pixel) {
            rval = pixel[0] >> rshift;
            gval = pixel[1] >> rshift;
            bval = pixel[2] >> rshift;
            index = getColorIndex(rval, gval, bval);
            histo[index] = (histo[index] || 0) + 1;
        });
        return histo;
    }

    function vboxFromPixels(pixels, histo) {
        var rmin=1000000, rmax=0,
            gmin=1000000, gmax=0,
            bmin=1000000, bmax=0,
            rval, gval, bval;
        // find min/max
        pixels.forEach(function(pixel) {
            rval = pixel[0] >> rshift;
            gval = pixel[1] >> rshift;
            bval = pixel[2] >> rshift;
            if (rval < rmin) rmin = rval;
            else if (rval > rmax) rmax = rval;
            if (gval < gmin) gmin = gval;
            else if (gval > gmax) gmax = gval;
            if (bval < bmin) bmin = bval;
            else if (bval > bmax)  bmax = bval;
        });
        return new VBox(rmin, rmax, gmin, gmax, bmin, bmax, histo);
    }

    function medianCutApply(histo, vbox) {
        if (!vbox.count()) return;

        var rw = vbox.r2 - vbox.r1 + 1,
            gw = vbox.g2 - vbox.g1 + 1,
            bw = vbox.b2 - vbox.b1 + 1,
            maxw = pv.max([rw, gw, bw]);
        // only one pixel, no split
        if (vbox.count() == 1) {
            return [vbox.copy()];
        }
        /* Find the partial sum arrays along the selected axis. */
        var total = 0,
            partialsum = [],
            lookaheadsum = [],
            i, j, k, sum, index;
        if (maxw == rw) {
            for (i = vbox.r1; i <= vbox.r2; i++) {
                sum = 0;
                for (j = vbox.g1; j <= vbox.g2; j++) {
                    for (k = vbox.b1; k <= vbox.b2; k++) {
                        index = getColorIndex(i,j,k);
                        sum += (histo[index] || 0);
                    }
                }
                total += sum;
                partialsum[i] = total;
            }
        }
        else if (maxw == gw) {
            for (i = vbox.g1; i <= vbox.g2; i++) {
                sum = 0;
                for (j = vbox.r1; j <= vbox.r2; j++) {
                    for (k = vbox.b1; k <= vbox.b2; k++) {
                        index = getColorIndex(j,i,k);
                        sum += (histo[index] || 0);
                    }
                }
                total += sum;
                partialsum[i] = total;
            }
        }
        else {  /* maxw == bw */
            for (i = vbox.b1; i <= vbox.b2; i++) {
                sum = 0;
                for (j = vbox.r1; j <= vbox.r2; j++) {
                    for (k = vbox.g1; k <= vbox.g2; k++) {
                        index = getColorIndex(j,k,i);
                        sum += (histo[index] || 0);
                    }
                }
                total += sum;
                partialsum[i] = total;
            }
        }
        partialsum.forEach(function(d,i) {
            lookaheadsum[i] = total-d;
        });
        function doCut(color) {
            var dim1 = color + '1',
                dim2 = color + '2',
                left, right, vbox1, vbox2, d2, count2=0;
            for (i = vbox[dim1]; i <= vbox[dim2]; i++) {
                if (partialsum[i] > total / 2) {
                    vbox1 = vbox.copy();
                    vbox2 = vbox.copy();
                    left = i - vbox[dim1];
                    right = vbox[dim2] - i;
                    if (left <= right)
                        d2 = Math.min(vbox[dim2] - 1, ~~(i + right / 2));
                    else d2 = Math.max(vbox[dim1], ~~(i - 1 - left / 2));
                    // avoid 0-count boxes
                    while (!partialsum[d2]) d2++;
                    count2 = lookaheadsum[d2];
                    while (!count2 && partialsum[d2-1]) count2 = lookaheadsum[--d2];
                    // set dimensions
                    vbox1[dim2] = d2;
                    vbox2[dim1] = vbox1[dim2] + 1;
//                    console.log('vbox counts:', vbox.count(), vbox1.count(), vbox2.count());
                    return [vbox1, vbox2];
                }
            }

        }
        // determine the cut planes
        return maxw == rw ? doCut('r') :
            maxw == gw ? doCut('g') :
            doCut('b');
    }

    function quantize(pixels, maxcolors) {
        // short-circuit
        if (!pixels.length || maxcolors < 2 || maxcolors > 256) {
//            console.log('wrong number of maxcolors');
            return false;
        }

        // XXX: check color content and convert to grayscale if insufficient

        var histo = getHisto(pixels),
            histosize = 1 << (3 * sigbits);

        // check that we aren't below maxcolors already
        var nColors = 0;
        histo.forEach(function() { nColors++; });
        if (nColors <= maxcolors) {
            // XXX: generate the new colors from the histo and return
        }

        // get the beginning vbox from the colors
        var vbox = vboxFromPixels(pixels, histo),
            pq = new PQueue(function(a,b) { return pv.naturalOrder(a.count(), b.count()); });
        pq.push(vbox);

        // inner function to do the iteration
        function iter(lh, target) {
            var ncolors = 1,
                niters = 0,
                vbox;
            while (niters < maxIterations) {
                vbox = lh.pop();
                if (!vbox.count())  { /* just put it back */
                    lh.push(vbox);
                    niters++;
                    continue;
                }
                // do the cut
                var vboxes = medianCutApply(histo, vbox),
                    vbox1 = vboxes[0],
                    vbox2 = vboxes[1];

                if (!vbox1) {
//                    console.log("vbox1 not defined; shouldn't happen!");
                    return;
                }
                lh.push(vbox1);
                if (vbox2) {  /* vbox2 can be null */
                    lh.push(vbox2);
                    ncolors++;
                }
                if (ncolors >= target) return;
                if (niters++ > maxIterations) {
//                    console.log("infinite loop; perhaps too few pixels!");
                    return;
                }
            }
        }

        // first set of colors, sorted by population
        iter(pq, fractByPopulations * maxcolors);

        // Re-sort by the product of pixel occupancy times the size in color space.
        var pq2 = new PQueue(function(a,b) {
            return pv.naturalOrder(a.count()*a.volume(), b.count()*b.volume());
        });
        while (pq.size()) {
            pq2.push(pq.pop());
        }

        // next set - generate the median cuts using the (npix * vol) sorting.
        iter(pq2, maxcolors - pq2.size());

        // calculate the actual colors
        var cmap = new CMap();
        while (pq2.size()) {
            cmap.push(pq2.pop());
        }

        return cmap;
    }

    return {
        quantize: quantize
    };
})();

/*
  html2canvas 0.5.0-beta3 <http://html2canvas.hertzen.com>
  Copyright (c) 2016 Niklas von Hertzen

  Released under  License
*/

if (!bIEQuirks && GALERIE_ZOOM_CANVAS && !GALERIE_ZOOM_CANVAS_CLONE) !function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var f;"undefined"!=typeof window?f=window:"undefined"!=typeof global?f=global:"undefined"!=typeof self&&(f=self),f.html2canvas=e()}}(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(_dereq_,module,exports){
(function (global){
/*! http://mths.be/punycode v1.2.4 by @mathias */
;(function(root) {

	/** Detect free variables */
	var freeExports = typeof exports == 'object' && exports;
	var freeModule = typeof module == 'object' && module &&
		module.exports == freeExports && module;
	var freeGlobal = typeof global == 'object' && global;
	if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal) {
		root = freeGlobal;
	}

	/**
	 * The `punycode` object.
	 * @name punycode
	 * @type Object
	 */
	var punycode,

	/** Highest positive signed 32-bit float value */
	maxInt = 2147483647, // aka. 0x7FFFFFFF or 2^31-1

	/** Bootstring parameters */
	base = 36,
	tMin = 1,
	tMax = 26,
	skew = 38,
	damp = 700,
	initialBias = 72,
	initialN = 128, // 0x80
	delimiter = '-', // '\x2D'

	/** Regular expressions */
	regexPunycode = /^xn--/,
	regexNonASCII = /[^ -~]/, // unprintable ASCII chars + non-ASCII chars
	regexSeparators = /\x2E|\u3002|\uFF0E|\uFF61/g, // RFC 3490 separators

	/** Error messages */
	errors = {
		'overflow': 'Overflow: input needs wider integers to process',
		'not-basic': 'Illegal input >= 0x80 (not a basic code point)',
		'invalid-input': 'Invalid input'
	},

	/** Convenience shortcuts */
	baseMinusTMin = base - tMin,
	floor = Math.floor,
	stringFromCharCode = String.fromCharCode,

	/** Temporary variable */
	key;

	/*--------------------------------------------------------------------------*/

	/**
	 * A generic error utility function.
	 * @private
	 * @param {String} type The error type.
	 * @returns {Error} Throws a `RangeError` with the applicable error message.
	 */
	function error(type) {
		throw RangeError(errors[type]);
	}

	/**
	 * A generic `Array#map` utility function.
	 * @private
	 * @param {Array} array The array to iterate over.
	 * @param {Function} callback The function that gets called for every array
	 * item.
	 * @returns {Array} A new array of values returned by the callback function.
	 */
	function map(array, fn) {
		var length = array.length;
		while (length--) {
			array[length] = fn(array[length]);
		}
		return array;
	}

	/**
	 * A simple `Array#map`-like wrapper to work with domain name strings.
	 * @private
	 * @param {String} domain The domain name.
	 * @param {Function} callback The function that gets called for every
	 * character.
	 * @returns {Array} A new string of characters returned by the callback
	 * function.
	 */
	function mapDomain(string, fn) {
		return map(string.split(regexSeparators), fn).join('.');
	}

	/**
	 * Creates an array containing the numeric code points of each Unicode
	 * character in the string. While JavaScript uses UCS-2 internally,
	 * this function will convert a pair of surrogate halves (each of which
	 * UCS-2 exposes as separate characters) into a single code point,
	 * matching UTF-16.
	 * @see `punycode.ucs2.encode`
	 * @see <http://mathiasbynens.be/notes/javascript-encoding>
	 * @memberOf punycode.ucs2
	 * @name decode
	 * @param {String} string The Unicode input string (UCS-2).
	 * @returns {Array} The new array of code points.
	 */
	function ucs2decode(string) {
		var output = [],
		    counter = 0,
		    length = string.length,
		    value,
		    extra;
		while (counter < length) {
			value = string.charCodeAt(counter++);
			if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
				// high surrogate, and there is a next character
				extra = string.charCodeAt(counter++);
				if ((extra & 0xFC00) == 0xDC00) { // low surrogate
					output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
				} else {
					// unmatched surrogate; only append this code unit, in case the next
					// code unit is the high surrogate of a surrogate pair
					output.push(value);
					counter--;
				}
			} else {
				output.push(value);
			}
		}
		return output;
	}

	/**
	 * Creates a string based on an array of numeric code points.
	 * @see `punycode.ucs2.decode`
	 * @memberOf punycode.ucs2
	 * @name encode
	 * @param {Array} codePoints The array of numeric code points.
	 * @returns {String} The new Unicode string (UCS-2).
	 */
	function ucs2encode(array) {
		return map(array, function(value) {
			var output = '';
			if (value > 0xFFFF) {
				value -= 0x10000;
				output += stringFromCharCode(value >>> 10 & 0x3FF | 0xD800);
				value = 0xDC00 | value & 0x3FF;
			}
			output += stringFromCharCode(value);
			return output;
		}).join('');
	}

	/**
	 * Converts a basic code point into a digit/integer.
	 * @see `digitToBasic()`
	 * @private
	 * @param {Number} codePoint The basic numeric code point value.
	 * @returns {Number} The numeric value of a basic code point (for use in
	 * representing integers) in the range `0` to `base - 1`, or `base` if
	 * the code point does not represent a value.
	 */
	function basicToDigit(codePoint) {
		if (codePoint - 48 < 10) {
			return codePoint - 22;
		}
		if (codePoint - 65 < 26) {
			return codePoint - 65;
		}
		if (codePoint - 97 < 26) {
			return codePoint - 97;
		}
		return base;
	}

	/**
	 * Converts a digit/integer into a basic code point.
	 * @see `basicToDigit()`
	 * @private
	 * @param {Number} digit The numeric value of a basic code point.
	 * @returns {Number} The basic code point whose value (when used for
	 * representing integers) is `digit`, which needs to be in the range
	 * `0` to `base - 1`. If `flag` is non-zero, the uppercase form is
	 * used; else, the lowercase form is used. The behavior is undefined
	 * if `flag` is non-zero and `digit` has no uppercase form.
	 */
	function digitToBasic(digit, flag) {
		//  0..25 map to ASCII a..z or A..Z
		// 26..35 map to ASCII 0..9
		return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
	}

	/**
	 * Bias adaptation function as per section 3.4 of RFC 3492.
	 * http://tools.ietf.org/html/rfc3492#section-3.4
	 * @private
	 */
	function adapt(delta, numPoints, firstTime) {
		var k = 0;
		delta = firstTime ? floor(delta / damp) : delta >> 1;
		delta += floor(delta / numPoints);
		for (/* no initialization */; delta > baseMinusTMin * tMax >> 1; k += base) {
			delta = floor(delta / baseMinusTMin);
		}
		return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
	}

	/**
	 * Converts a Punycode string of ASCII-only symbols to a string of Unicode
	 * symbols.
	 * @memberOf punycode
	 * @param {String} input The Punycode string of ASCII-only symbols.
	 * @returns {String} The resulting string of Unicode symbols.
	 */
	function decode(input) {
		// Don't use UCS-2
		var output = [],
		    inputLength = input.length,
		    out,
		    i = 0,
		    n = initialN,
		    bias = initialBias,
		    basic,
		    j,
		    index,
		    oldi,
		    w,
		    k,
		    digit,
		    t,
		    /** Cached calculation results */
		    baseMinusT;

		// Handle the basic code points: let `basic` be the number of input code
		// points before the last delimiter, or `0` if there is none, then copy
		// the first basic code points to the output.

		basic = input.lastIndexOf(delimiter);
		if (basic < 0) {
			basic = 0;
		}

		for (j = 0; j < basic; ++j) {
			// if it's not a basic code point
			if (input.charCodeAt(j) >= 0x80) {
				error('not-basic');
			}
			output.push(input.charCodeAt(j));
		}

		// Main decoding loop: start just after the last delimiter if any basic code
		// points were copied; start at the beginning otherwise.

		for (index = basic > 0 ? basic + 1 : 0; index < inputLength; /* no final expression */) {

			// `index` is the index of the next character to be consumed.
			// Decode a generalized variable-length integer into `delta`,
			// which gets added to `i`. The overflow checking is easier
			// if we increase `i` as we go, then subtract off its starting
			// value at the end to obtain `delta`.
			for (oldi = i, w = 1, k = base; /* no condition */; k += base) {

				if (index >= inputLength) {
					error('invalid-input');
				}

				digit = basicToDigit(input.charCodeAt(index++));

				if (digit >= base || digit > floor((maxInt - i) / w)) {
					error('overflow');
				}

				i += digit * w;
				t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);

				if (digit < t) {
					break;
				}

				baseMinusT = base - t;
				if (w > floor(maxInt / baseMinusT)) {
					error('overflow');
				}

				w *= baseMinusT;

			}

			out = output.length + 1;
			bias = adapt(i - oldi, out, oldi == 0);

			// `i` was supposed to wrap around from `out` to `0`,
			// incrementing `n` each time, so we'll fix that now:
			if (floor(i / out) > maxInt - n) {
				error('overflow');
			}

			n += floor(i / out);
			i %= out;

			// Insert `n` at position `i` of the output
			output.splice(i++, 0, n);

		}

		return ucs2encode(output);
	}

	/**
	 * Converts a string of Unicode symbols to a Punycode string of ASCII-only
	 * symbols.
	 * @memberOf punycode
	 * @param {String} input The string of Unicode symbols.
	 * @returns {String} The resulting Punycode string of ASCII-only symbols.
	 */
	function encode(input) {
		var n,
		    delta,
		    handledCPCount,
		    basicLength,
		    bias,
		    j,
		    m,
		    q,
		    k,
		    t,
		    currentValue,
		    output = [],
		    /** `inputLength` will hold the number of code points in `input`. */
		    inputLength,
		    /** Cached calculation results */
		    handledCPCountPlusOne,
		    baseMinusT,
		    qMinusT;

		// Convert the input in UCS-2 to Unicode
		input = ucs2decode(input);

		// Cache the length
		inputLength = input.length;

		// Initialize the state
		n = initialN;
		delta = 0;
		bias = initialBias;

		// Handle the basic code points
		for (j = 0; j < inputLength; ++j) {
			currentValue = input[j];
			if (currentValue < 0x80) {
				output.push(stringFromCharCode(currentValue));
			}
		}

		handledCPCount = basicLength = output.length;

		// `handledCPCount` is the number of code points that have been handled;
		// `basicLength` is the number of basic code points.

		// Finish the basic string - if it is not empty - with a delimiter
		if (basicLength) {
			output.push(delimiter);
		}

		// Main encoding loop:
		while (handledCPCount < inputLength) {

			// All non-basic code points < n have been handled already. Find the next
			// larger one:
			for (m = maxInt, j = 0; j < inputLength; ++j) {
				currentValue = input[j];
				if (currentValue >= n && currentValue < m) {
					m = currentValue;
				}
			}

			// Increase `delta` enough to advance the decoder's <n,i> state to <m,0>,
			// but guard against overflow
			handledCPCountPlusOne = handledCPCount + 1;
			if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
				error('overflow');
			}

			delta += (m - n) * handledCPCountPlusOne;
			n = m;

			for (j = 0; j < inputLength; ++j) {
				currentValue = input[j];

				if (currentValue < n && ++delta > maxInt) {
					error('overflow');
				}

				if (currentValue == n) {
					// Represent delta as a generalized variable-length integer
					for (q = delta, k = base; /* no condition */; k += base) {
						t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
						if (q < t) {
							break;
						}
						qMinusT = q - t;
						baseMinusT = base - t;
						output.push(
							stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))
						);
						q = floor(qMinusT / baseMinusT);
					}

					output.push(stringFromCharCode(digitToBasic(q, 0)));
					bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
					delta = 0;
					++handledCPCount;
				}
			}

			++delta;
			++n;

		}
		return output.join('');
	}

	/**
	 * Converts a Punycode string representing a domain name to Unicode. Only the
	 * Punycoded parts of the domain name will be converted, i.e. it doesn't
	 * matter if you call it on a string that has already been converted to
	 * Unicode.
	 * @memberOf punycode
	 * @param {String} domain The Punycode domain name to convert to Unicode.
	 * @returns {String} The Unicode representation of the given Punycode
	 * string.
	 */
	function toUnicode(domain) {
		return mapDomain(domain, function(string) {
			return regexPunycode.test(string)
				? decode(string.slice(4).toLowerCase())
				: string;
		});
	}

	/**
	 * Converts a Unicode string representing a domain name to Punycode. Only the
	 * non-ASCII parts of the domain name will be converted, i.e. it doesn't
	 * matter if you call it with a domain that's already in ASCII.
	 * @memberOf punycode
	 * @param {String} domain The domain name to convert, as a Unicode string.
	 * @returns {String} The Punycode representation of the given domain name.
	 */
	function toASCII(domain) {
		return mapDomain(domain, function(string) {
			return regexNonASCII.test(string)
				? 'xn--' + encode(string)
				: string;
		});
	}

	/*--------------------------------------------------------------------------*/

	/** Define the public API */
	punycode = {
		/**
		 * A string representing the current Punycode.js version number.
		 * @memberOf punycode
		 * @type String
		 */
		'version': '1.2.4',
		/**
		 * An object of methods to convert from JavaScript's internal character
		 * representation (UCS-2) to Unicode code points, and back.
		 * @see <http://mathiasbynens.be/notes/javascript-encoding>
		 * @memberOf punycode
		 * @type Object
		 */
		'ucs2': {
			'decode': ucs2decode,
			'encode': ucs2encode
		},
		'decode': decode,
		'encode': encode,
		'toASCII': toASCII,
		'toUnicode': toUnicode
	};

	/** Expose `punycode` */
	// Some AMD build optimizers, like r.js, check for specific condition patterns
	// like the following:
	if (
		typeof define == 'function' &&
		typeof define.amd == 'object' &&
		define.amd
	) {
		define('punycode', function() {
			return punycode;
		});
	} else if (freeExports && !freeExports.nodeType) {
		if (freeModule) { // in Node.js or RingoJS v0.8.0+
			freeModule.exports = punycode;
		} else { // in Narwhal or RingoJS v0.7.0-
			for (key in punycode) {
				punycode.hasOwnProperty(key) && (freeExports[key] = punycode[key]);
			}
		}
	} else { // in Rhino or a web browser
		root.punycode = punycode;
	}

}(this));

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{}],2:[function(_dereq_,module,exports){
var log = _dereq_('./log');

function restoreOwnerScroll(ownerDocument, x, y) {
    if (ownerDocument.defaultView && (x !== ownerDocument.defaultView.pageXOffset || y !== ownerDocument.defaultView.pageYOffset)) {
        ownerDocument.defaultView.scrollTo(x, y);
    }
}

function cloneCanvasContents(canvas, clonedCanvas) {
    try {
        if (clonedCanvas) {
            clonedCanvas.width = canvas.width;
            clonedCanvas.height = canvas.height;
            clonedCanvas.getContext("2d").putImageData(canvas.getContext("2d").getImageData(0, 0, canvas.width, canvas.height), 0, 0);
        }
    } catch(e) {
        log("Unable to copy canvas content from", canvas, e);
    }
}

function cloneNode(node, javascriptEnabled) {
    var clone = node.nodeType === 3 ? document.createTextNode(node.nodeValue) : node.cloneNode(false);

    var child = node.firstChild;
    while(child) {
        if (javascriptEnabled === true || child.nodeType !== 1 || child.nodeName !== 'SCRIPT') {
            clone.appendChild(cloneNode(child, javascriptEnabled));
        }
        child = child.nextSibling;
    }

    if (node.nodeType === 1) {
        clone._scrollTop = node.scrollTop;
        clone._scrollLeft = node.scrollLeft;
        if (node.nodeName === "CANVAS") {
            cloneCanvasContents(node, clone);
        } else if (node.nodeName === "TEXTAREA" || node.nodeName === "SELECT") {
            clone.value = node.value;
        }
    }

    return clone;
}

function initNode(node) {
    if (node.nodeType === 1) {
        node.scrollTop = node._scrollTop;
        node.scrollLeft = node._scrollLeft;

        var child = node.firstChild;
        while(child) {
            initNode(child);
            child = child.nextSibling;
        }
    }
}

module.exports = function(ownerDocument, containerDocument, width, height, options, x ,y) {
    var documentElement = cloneNode(ownerDocument.documentElement, options.javascriptEnabled);
    //GF sans JS initial 
    if (!options.javascriptEnabled) $(documentElement).find("input,textarea,select,a,button,iframe").removeAttr("onfocus").removeAttr("onblur").removeAttr("onload");
    var container = containerDocument.createElement("iframe");

    container.className = "html2canvas-container";
    container.style.visibility = "hidden";
    container.style.position = "fixed";
    container.style.left = "-10000px";
    container.style.top = "0px";
    container.style.border = "0";
    container.width = width;
    container.height = height;
    container.scrolling = "no"; // ios won't scroll without it
    containerDocument.body.appendChild(container);

    return new Promise(function(resolve) {
        var documentClone = container.contentWindow.document;

        /* Chrome doesn't detect relative background-images assigned in inline <style> sheets when fetched through getComputedStyle
         if window url is about:blank, we can assign the url to current by writing onto the document
         */
        container.contentWindow.onload = container.onload = function() {
            var interval = setInterval(function() {
                if (documentClone.body.childNodes.length > 0) {
                    initNode(documentClone.documentElement);
                    clearInterval(interval);
                    if (options.type === "view") {
                        container.contentWindow.scrollTo(x, y);
                        if ((/(iPad|iPhone|iPod)/g).test(navigator.userAgent) && (container.contentWindow.scrollY !== y || container.contentWindow.scrollX !== x)) {
                            documentClone.documentElement.style.top = (-y) + "px";
                            documentClone.documentElement.style.left = (-x) + "px";
                            documentClone.documentElement.style.position = 'absolute';
                        }
                    }
                    resolve(container);
                }
            }, 50);
        };

        documentClone.open();
        documentClone.write("<!DOCTYPE html><html></html>");
        // Chrome scrolls the parent document for some reason after the write to the cloned window???
        restoreOwnerScroll(ownerDocument, x, y);
        documentClone.replaceChild(documentClone.adoptNode(documentElement), documentClone.documentElement);
        documentClone.close();
    });
};

},{"./log":13}],3:[function(_dereq_,module,exports){
// http://dev.w3.org/csswg/css-color/

function Color(value) {
    this.r = 0;
    this.g = 0;
    this.b = 0;
    this.a = null;
    var result = this.fromArray(value) ||
        this.namedColor(value) ||
        this.rgb(value) ||
        this.rgba(value) ||
        this.hex6(value) ||
        this.hex3(value);
}

Color.prototype.darken = function(amount) {
    var a = 1 - amount;
    return  new Color([
        Math.round(this.r * a),
        Math.round(this.g * a),
        Math.round(this.b * a),
        this.a
    ]);
};

Color.prototype.isTransparent = function() {
    return this.a === 0;
};

Color.prototype.isBlack = function() {
    return this.r === 0 && this.g === 0 && this.b === 0;
};

Color.prototype.fromArray = function(array) {
    if (Array.isArray(array)) {
        this.r = Math.min(array[0], 255);
        this.g = Math.min(array[1], 255);
        this.b = Math.min(array[2], 255);
        if (array.length > 3) {
            this.a = array[3];
        }
    }

    return (Array.isArray(array));
};

var _hex3 = /^#([a-f0-9]{3})$/i;

Color.prototype.hex3 = function(value) {
    var match = null;
    if ((match = value.match(_hex3)) !== null) {
        this.r = parseInt(match[1][0] + match[1][0], 16);
        this.g = parseInt(match[1][1] + match[1][1], 16);
        this.b = parseInt(match[1][2] + match[1][2], 16);
    }
    return match !== null;
};

var _hex6 = /^#([a-f0-9]{6})$/i;

Color.prototype.hex6 = function(value) {
    var match = null;
    if ((match = value.match(_hex6)) !== null) {
        this.r = parseInt(match[1].substring(0, 2), 16);
        this.g = parseInt(match[1].substring(2, 4), 16);
        this.b = parseInt(match[1].substring(4, 6), 16);
    }
    return match !== null;
};


var _rgb = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/;

Color.prototype.rgb = function(value) {
    var match = null;
    if ((match = value.match(_rgb)) !== null) {
        this.r = Number(match[1]);
        this.g = Number(match[2]);
        this.b = Number(match[3]);
    }
    return match !== null;
};

var _rgba = /^rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d?\.?\d+)\s*\)$/;

Color.prototype.rgba = function(value) {
    var match = null;
    if ((match = value.match(_rgba)) !== null) {
        this.r = Number(match[1]);
        this.g = Number(match[2]);
        this.b = Number(match[3]);
        this.a = Number(match[4]);
    }
    return match !== null;
};

Color.prototype.toString = function() {
    return this.a !== null && this.a !== 1 ?
    "rgba(" + [this.r, this.g, this.b, this.a].join(",") + ")" :
    "rgb(" + [this.r, this.g, this.b].join(",") + ")";
};

Color.prototype.namedColor = function(value) {
    value = value.toLowerCase();
    var color = colors[value];
    if (color) {
        this.r = color[0];
        this.g = color[1];
        this.b = color[2];
    } else if (value === "transparent") {
        this.r = this.g = this.b = this.a = 0;
        return true;
    }

    return !!color;
};

Color.prototype.isColor = true;

// JSON.stringify([].slice.call($$('.named-color-table tr'), 1).map(function(row) { return [row.childNodes[3].textContent, row.childNodes[5].textContent.trim().split(",").map(Number)] }).reduce(function(data, row) {data[row[0]] = row[1]; return data}, {}))
var colors = {
    "aliceblue": [240, 248, 255],
    "antiquewhite": [250, 235, 215],
    "aqua": [0, 255, 255],
    "aquamarine": [127, 255, 212],
    "azure": [240, 255, 255],
    "beige": [245, 245, 220],
    "bisque": [255, 228, 196],
    "black": [0, 0, 0],
    "blanchedalmond": [255, 235, 205],
    "blue": [0, 0, 255],
    "blueviolet": [138, 43, 226],
    "brown": [165, 42, 42],
    "burlywood": [222, 184, 135],
    "cadetblue": [95, 158, 160],
    "chartreuse": [127, 255, 0],
    "chocolate": [210, 105, 30],
    "coral": [255, 127, 80],
    "cornflowerblue": [100, 149, 237],
    "cornsilk": [255, 248, 220],
    "crimson": [220, 20, 60],
    "cyan": [0, 255, 255],
    "darkblue": [0, 0, 139],
    "darkcyan": [0, 139, 139],
    "darkgoldenrod": [184, 134, 11],
    "darkgray": [169, 169, 169],
    "darkgreen": [0, 100, 0],
    "darkgrey": [169, 169, 169],
    "darkkhaki": [189, 183, 107],
    "darkmagenta": [139, 0, 139],
    "darkolivegreen": [85, 107, 47],
    "darkorange": [255, 140, 0],
    "darkorchid": [153, 50, 204],
    "darkred": [139, 0, 0],
    "darksalmon": [233, 150, 122],
    "darkseagreen": [143, 188, 143],
    "darkslateblue": [72, 61, 139],
    "darkslategray": [47, 79, 79],
    "darkslategrey": [47, 79, 79],
    "darkturquoise": [0, 206, 209],
    "darkviolet": [148, 0, 211],
    "deeppink": [255, 20, 147],
    "deepskyblue": [0, 191, 255],
    "dimgray": [105, 105, 105],
    "dimgrey": [105, 105, 105],
    "dodgerblue": [30, 144, 255],
    "firebrick": [178, 34, 34],
    "floralwhite": [255, 250, 240],
    "forestgreen": [34, 139, 34],
    "fuchsia": [255, 0, 255],
    "gainsboro": [220, 220, 220],
    "ghostwhite": [248, 248, 255],
    "gold": [255, 215, 0],
    "goldenrod": [218, 165, 32],
    "gray": [128, 128, 128],
    "green": [0, 128, 0],
    "greenyellow": [173, 255, 47],
    "grey": [128, 128, 128],
    "honeydew": [240, 255, 240],
    "hotpink": [255, 105, 180],
    "indianred": [205, 92, 92],
    "indigo": [75, 0, 130],
    "ivory": [255, 255, 240],
    "khaki": [240, 230, 140],
    "lavender": [230, 230, 250],
    "lavenderblush": [255, 240, 245],
    "lawngreen": [124, 252, 0],
    "lemonchiffon": [255, 250, 205],
    "lightblue": [173, 216, 230],
    "lightcoral": [240, 128, 128],
    "lightcyan": [224, 255, 255],
    "lightgoldenrodyellow": [250, 250, 210],
    "lightgray": [211, 211, 211],
    "lightgreen": [144, 238, 144],
    "lightgrey": [211, 211, 211],
    "lightpink": [255, 182, 193],
    "lightsalmon": [255, 160, 122],
    "lightseagreen": [32, 178, 170],
    "lightskyblue": [135, 206, 250],
    "lightslategray": [119, 136, 153],
    "lightslategrey": [119, 136, 153],
    "lightsteelblue": [176, 196, 222],
    "lightyellow": [255, 255, 224],
    "lime": [0, 255, 0],
    "limegreen": [50, 205, 50],
    "linen": [250, 240, 230],
    "magenta": [255, 0, 255],
    "maroon": [128, 0, 0],
    "mediumaquamarine": [102, 205, 170],
    "mediumblue": [0, 0, 205],
    "mediumorchid": [186, 85, 211],
    "mediumpurple": [147, 112, 219],
    "mediumseagreen": [60, 179, 113],
    "mediumslateblue": [123, 104, 238],
    "mediumspringgreen": [0, 250, 154],
    "mediumturquoise": [72, 209, 204],
    "mediumvioletred": [199, 21, 133],
    "midnightblue": [25, 25, 112],
    "mintcream": [245, 255, 250],
    "mistyrose": [255, 228, 225],
    "moccasin": [255, 228, 181],
    "navajowhite": [255, 222, 173],
    "navy": [0, 0, 128],
    "oldlace": [253, 245, 230],
    "olive": [128, 128, 0],
    "olivedrab": [107, 142, 35],
    "orange": [255, 165, 0],
    "orangered": [255, 69, 0],
    "orchid": [218, 112, 214],
    "palegoldenrod": [238, 232, 170],
    "palegreen": [152, 251, 152],
    "paleturquoise": [175, 238, 238],
    "palevioletred": [219, 112, 147],
    "papayawhip": [255, 239, 213],
    "peachpuff": [255, 218, 185],
    "peru": [205, 133, 63],
    "pink": [255, 192, 203],
    "plum": [221, 160, 221],
    "powderblue": [176, 224, 230],
    "purple": [128, 0, 128],
    "rebeccapurple": [102, 51, 153],
    "red": [255, 0, 0],
    "rosybrown": [188, 143, 143],
    "royalblue": [65, 105, 225],
    "saddlebrown": [139, 69, 19],
    "salmon": [250, 128, 114],
    "sandybrown": [244, 164, 96],
    "seagreen": [46, 139, 87],
    "seashell": [255, 245, 238],
    "sienna": [160, 82, 45],
    "silver": [192, 192, 192],
    "skyblue": [135, 206, 235],
    "slateblue": [106, 90, 205],
    "slategray": [112, 128, 144],
    "slategrey": [112, 128, 144],
    "snow": [255, 250, 250],
    "springgreen": [0, 255, 127],
    "steelblue": [70, 130, 180],
    "tan": [210, 180, 140],
    "teal": [0, 128, 128],
    "thistle": [216, 191, 216],
    "tomato": [255, 99, 71],
    "turquoise": [64, 224, 208],
    "violet": [238, 130, 238],
    "wheat": [245, 222, 179],
    "white": [255, 255, 255],
    "whitesmoke": [245, 245, 245],
    "yellow": [255, 255, 0],
    "yellowgreen": [154, 205, 50]
};

module.exports = Color;

},{}],4:[function(_dereq_,module,exports){
var Support = _dereq_('./support');
var CanvasRenderer = _dereq_('./renderers/canvas');
var ImageLoader = _dereq_('./imageloader');
var NodeParser = _dereq_('./nodeparser');
var NodeContainer = _dereq_('./nodecontainer');
var log = _dereq_('./log');
var utils = _dereq_('./utils');
var createWindowClone = _dereq_('./clone');
var loadUrlDocument = _dereq_('./proxy').loadUrlDocument;
var getBounds = utils.getBounds;

var html2canvasNodeAttribute = "data-html2canvas-node";
var html2canvasCloneIndex = 0;

function html2canvas(nodeList, options) {
    var index = html2canvasCloneIndex++;
    options = options || {};
    if (options.logging) {
        log.options.logging = true;
        log.options.start = Date.now();
    }

    options.async = typeof(options.async) === "undefined" ? true : options.async;
    options.allowTaint = typeof(options.allowTaint) === "undefined" ? false : options.allowTaint;
    options.removeContainer = typeof(options.removeContainer) === "undefined" ? true : options.removeContainer;
    options.javascriptEnabled = typeof(options.javascriptEnabled) === "undefined" ? false : options.javascriptEnabled;
    options.imageTimeout = typeof(options.imageTimeout) === "undefined" ? 10000 : options.imageTimeout;
    options.renderer = typeof(options.renderer) === "function" ? options.renderer : CanvasRenderer;
    options.strict = !!options.strict;

    if (typeof(nodeList) === "string") {
        if (typeof(options.proxy) !== "string") {
            return Promise.reject("Proxy must be used when rendering url");
        }
        var width = options.width != null ? options.width : window.innerWidth;
        var height = options.height != null ? options.height : window.innerHeight;
        return loadUrlDocument(absoluteUrl(nodeList), options.proxy, document, width, height, options).then(function(container) {
            return renderWindow(container.contentWindow.document.documentElement, container, options, width, height);
        });
    }

    var node = ((nodeList === undefined) ? [document.documentElement] : ((nodeList.length) ? nodeList : [nodeList]))[0];
    node.setAttribute(html2canvasNodeAttribute + index, index);
    return renderDocument(node.ownerDocument, options, node.ownerDocument.defaultView.innerWidth, node.ownerDocument.defaultView.innerHeight, index).then(function(canvas) {
        if (typeof(options.onrendered) === "function") {
            log("options.onrendered is deprecated, html2canvas returns a Promise containing the canvas");
            options.onrendered(canvas);
        }
        return canvas;
    });
}

html2canvas.CanvasRenderer = CanvasRenderer;
html2canvas.NodeContainer = NodeContainer;
html2canvas.log = log;
html2canvas.utils = utils;

var html2canvasExport = (typeof(document) === "undefined" || typeof(Object.create) !== "function" || typeof(document.createElement("canvas").getContext) !== "function") ? function() {
    return Promise.reject("No canvas support");
} : html2canvas;

module.exports = html2canvasExport;

if (typeof(define) === 'function' && define.amd) {
    define('html2canvas', [], function() {
        return html2canvasExport;
    });
}

function renderDocument(document, options, windowWidth, windowHeight, html2canvasIndex) {
    return createWindowClone(document, document, windowWidth, windowHeight, options, document.defaultView.pageXOffset, document.defaultView.pageYOffset).then(function(container) {
        log("Document cloned");
        var attributeName = html2canvasNodeAttribute + html2canvasIndex;
        var selector = "[" + attributeName + "='" + html2canvasIndex + "']";
        document.querySelector(selector).removeAttribute(attributeName);
        var clonedWindow = container.contentWindow;
        var node = clonedWindow.document.querySelector(selector);
        var oncloneHandler = (typeof(options.onclone) === "function") ? Promise.resolve(options.onclone(clonedWindow.document)) : Promise.resolve(true);
        return oncloneHandler.then(function() {
            return renderWindow(node, container, options, windowWidth, windowHeight);
        });
    });
}

function renderWindow(node, container, options, windowWidth, windowHeight) {
    var clonedWindow = container.contentWindow;
    var support = new Support(clonedWindow.document);
    var imageLoader = new ImageLoader(options, support);
    var bounds = getBounds(node);
    var width = options.type === "view" ? windowWidth : documentWidth(clonedWindow.document);
    var height = options.type === "view" ? windowHeight : documentHeight(clonedWindow.document);
    var renderer = new options.renderer(width, height, imageLoader, options, document);
    var parser = new NodeParser(node, renderer, support, imageLoader, options);
    return parser.ready.then(function() {
        log("Finished rendering");
        var canvas;

        if (options.type === "view") {
            canvas = crop(renderer.canvas, {width: renderer.canvas.width, height: renderer.canvas.height, top: 0, left: 0, x: 0, y: 0});
        } else if (node === clonedWindow.document.body || node === clonedWindow.document.documentElement || options.canvas != null) {
            canvas = renderer.canvas;
        } else {
            canvas = crop(renderer.canvas, {width:  options.width != null ? options.width : bounds.width, height: options.height != null ? options.height : bounds.height, top: bounds.top, left: bounds.left, x: 0, y: 0});
        }

        cleanupContainer(container, options);
        return canvas;
    });
}

function cleanupContainer(container, options) {
    if (options.removeContainer) {
        container.parentNode.removeChild(container);
        log("Cleaned up container");
    }
}

function crop(canvas, bounds) {
    var croppedCanvas = document.createElement("canvas");
    var x1 = Math.min(canvas.width - 1, Math.max(0, bounds.left));
    var x2 = Math.min(canvas.width, Math.max(1, bounds.left + bounds.width));
    var y1 = Math.min(canvas.height - 1, Math.max(0, bounds.top));
    var y2 = Math.min(canvas.height, Math.max(1, bounds.top + bounds.height));
    croppedCanvas.width = bounds.width;
    croppedCanvas.height =  bounds.height;
    var width = x2-x1;
    var height = y2-y1;
    log("Cropping canvas at:", "left:", bounds.left, "top:", bounds.top, "width:", width, "height:", height);
    log("Resulting crop with width", bounds.width, "and height", bounds.height, "with x", x1, "and y", y1);
    croppedCanvas.getContext("2d").drawImage(canvas, x1, y1, width, height, bounds.x, bounds.y, width, height);
    return croppedCanvas;
}

function documentWidth (doc) {
    return Math.max(
        Math.max(doc.body.scrollWidth, doc.documentElement.scrollWidth),
        Math.max(doc.body.offsetWidth, doc.documentElement.offsetWidth),
        Math.max(doc.body.clientWidth, doc.documentElement.clientWidth)
    );
}

function documentHeight (doc) {
    return Math.max(
        Math.max(doc.body.scrollHeight, doc.documentElement.scrollHeight),
        Math.max(doc.body.offsetHeight, doc.documentElement.offsetHeight),
        Math.max(doc.body.clientHeight, doc.documentElement.clientHeight)
    );
}

function absoluteUrl(url) {
    var link = document.createElement("a");
    link.href = url;
    link.href = link.href;
    return link;
}

},{"./clone":2,"./imageloader":11,"./log":13,"./nodecontainer":14,"./nodeparser":15,"./proxy":16,"./renderers/canvas":20,"./support":22,"./utils":26}],5:[function(_dereq_,module,exports){
var log = _dereq_('./log');
var smallImage = _dereq_('./utils').smallImage;

function DummyImageContainer(src) {
    this.src = src;
    log("DummyImageContainer for", src);
    if (!this.promise || !this.image) {
        log("Initiating DummyImageContainer");
        DummyImageContainer.prototype.image = new Image();
        var image = this.image;
        DummyImageContainer.prototype.promise = new Promise(function(resolve, reject) {
            image.onload = resolve;
            image.onerror = reject;
            image.src = smallImage();
            if (image.complete === true) {
                resolve(image);
            }
        });
    }
}

module.exports = DummyImageContainer;

},{"./log":13,"./utils":26}],6:[function(_dereq_,module,exports){
var smallImage = _dereq_('./utils').smallImage;

function Font(family, size) {
    var container = document.createElement('div'),
        img = document.createElement('img'),
        span = document.createElement('span'),
        sampleText = 'Hidden Text',
        baseline,
        middle;

    container.style.visibility = "hidden";
    container.style.fontFamily = family;
    container.style.fontSize = size;
    container.style.margin = 0;
    container.style.padding = 0;

    document.body.appendChild(container);

    img.src = smallImage();
    img.width = 1;
    img.height = 1;

    img.style.margin = 0;
    img.style.padding = 0;
    img.style.verticalAlign = "baseline";

    span.style.fontFamily = family;
    span.style.fontSize = size;
    span.style.margin = 0;
    span.style.padding = 0;

    span.appendChild(document.createTextNode(sampleText));
    container.appendChild(span);
    container.appendChild(img);
    baseline = (img.offsetTop - span.offsetTop) + 1;

    container.removeChild(span);
    container.appendChild(document.createTextNode(sampleText));

    container.style.lineHeight = "normal";
    img.style.verticalAlign = "super";

    middle = (img.offsetTop-container.offsetTop) + 1;

    document.body.removeChild(container);

    this.baseline = baseline;
    this.lineWidth = 1;
    this.middle = middle;
}

module.exports = Font;

},{"./utils":26}],7:[function(_dereq_,module,exports){
var Font = _dereq_('./font');

function FontMetrics() {
    this.data = {};
}

FontMetrics.prototype.getMetrics = function(family, size) {
    if (this.data[family + "-" + size] === undefined) {
        this.data[family + "-" + size] = new Font(family, size);
    }
    return this.data[family + "-" + size];
};

module.exports = FontMetrics;

},{"./font":6}],8:[function(_dereq_,module,exports){
var utils = _dereq_('./utils');
var getBounds = utils.getBounds;
var loadUrlDocument = _dereq_('./proxy').loadUrlDocument;

function FrameContainer(container, sameOrigin, options) {
    this.image = null;
    this.src = container;
    var self = this;
    var bounds = getBounds(container);
    this.promise = (!sameOrigin ? this.proxyLoad(options.proxy, bounds, options) : new Promise(function(resolve) {
        if (container.contentWindow.document.URL === "about:blank" || container.contentWindow.document.documentElement == null) {
            container.contentWindow.onload = container.onload = function() {
                resolve(container);
            };
        } else {
            resolve(container);
        }
    })).then(function(container) {
        var html2canvas = _dereq_('./core');
        return html2canvas(container.contentWindow.document.documentElement, {type: 'view', width: container.width, height: container.height, proxy: options.proxy, javascriptEnabled: options.javascriptEnabled, removeContainer: options.removeContainer, allowTaint: options.allowTaint, imageTimeout: options.imageTimeout / 2});
    }).then(function(canvas) {
        return self.image = canvas;
    });
}

FrameContainer.prototype.proxyLoad = function(proxy, bounds, options) {
    var container = this.src;
    return loadUrlDocument(container.src, proxy, container.ownerDocument, bounds.width, bounds.height, options);
};

module.exports = FrameContainer;

},{"./core":4,"./proxy":16,"./utils":26}],9:[function(_dereq_,module,exports){
function GradientContainer(imageData) {
    this.src = imageData.value;
    this.colorStops = [];
    this.type = null;
    this.x0 = 0.5;
    this.y0 = 0.5;
    this.x1 = 0.5;
    this.y1 = 0.5;
    this.promise = Promise.resolve(true);
}

GradientContainer.TYPES = {
    LINEAR: 1,
    RADIAL: 2
};

// TODO: support hsl[a], negative %/length values
// TODO: support <angle> (e.g. -?\d{1,3}(?:\.\d+)deg, etc. : https://developer.mozilla.org/docs/Web/CSS/angle )
GradientContainer.REGEXP_COLORSTOP = /^\s*(rgba?\(\s*\d{1,3},\s*\d{1,3},\s*\d{1,3}(?:,\s*[0-9\.]+)?\s*\)|[a-z]{3,20}|#[a-f0-9]{3,6})(?:\s+(\d{1,3}(?:\.\d+)?)(%|px)?)?(?:\s|$)/i;

module.exports = GradientContainer;

},{}],10:[function(_dereq_,module,exports){
function ImageContainer(src, cors) {
    this.src = src;
    this.image = new Image();
    var self = this;
    this.tainted = null;
    this.promise = new Promise(function(resolve, reject) {
        self.image.onload = resolve;
        self.image.onerror = reject;
        if (cors) {
            self.image.crossOrigin = "anonymous";
        }
        self.image.src = src;
        if (self.image.complete === true) {
            resolve(self.image);
        }
    });
}

module.exports = ImageContainer;

},{}],11:[function(_dereq_,module,exports){
var log = _dereq_('./log');
var ImageContainer = _dereq_('./imagecontainer');
var DummyImageContainer = _dereq_('./dummyimagecontainer');
var ProxyImageContainer = _dereq_('./proxyimagecontainer');
var FrameContainer = _dereq_('./framecontainer');
var SVGContainer = _dereq_('./svgcontainer');
var SVGNodeContainer = _dereq_('./svgnodecontainer');
var LinearGradientContainer = _dereq_('./lineargradientcontainer');
var WebkitGradientContainer = _dereq_('./webkitgradientcontainer');
var bind = _dereq_('./utils').bind;

function ImageLoader(options, support) {
    this.link = null;
    this.options = options;
    this.support = support;
    this.origin = this.getOrigin(window.location.href);
}

ImageLoader.prototype.findImages = function(nodes) {
    var images = [];
    nodes.reduce(function(imageNodes, container) {
        switch(container.node.nodeName) {
        case "IMG":
            return imageNodes.concat([{
                args: [container.node.src],
                method: "url"
            }]);
        case "svg":
        case "IFRAME":
            return imageNodes.concat([{
                args: [container.node],
                method: container.node.nodeName
            }]);
        }
        return imageNodes;
    }, []).forEach(this.addImage(images, this.loadImage), this);
    return images;
};

ImageLoader.prototype.findBackgroundImage = function(images, container) {
    container.parseBackgroundImages().filter(this.hasImageBackground).forEach(this.addImage(images, this.loadImage), this);
    return images;
};

ImageLoader.prototype.addImage = function(images, callback) {
    return function(newImage) {
        newImage.args.forEach(function(image) {
            if (!this.imageExists(images, image)) {
                images.splice(0, 0, callback.call(this, newImage));
                log('Added image #' + (images.length), typeof(image) === "string" ? image.substring(0, 100) : image);
            }
        }, this);
    };
};

ImageLoader.prototype.hasImageBackground = function(imageData) {
    return imageData.method !== "none";
};

ImageLoader.prototype.loadImage = function(imageData) {
    if (imageData.method === "url") {
        var src = imageData.args[0];
        if (this.isSVG(src) && !this.support.svg && !this.options.allowTaint) {
            return new SVGContainer(src);
        } else if (src.match(/data:image\/.*;base64,/i)) {
            return new ImageContainer(src.replace(/url\(['"]{0,}|['"]{0,}\)$/ig, ''), false);
        } else if (this.isSameOrigin(src) || this.options.allowTaint === true || this.isSVG(src)) {
            return new ImageContainer(src, false);
        } else if (this.support.cors && !this.options.allowTaint && this.options.useCORS) {
            return new ImageContainer(src, true);
        } else if (this.options.proxy) {
            return new ProxyImageContainer(src, this.options.proxy);
        } else {
            return new DummyImageContainer(src);
        }
    } else if (imageData.method === "linear-gradient") {
        return new LinearGradientContainer(imageData);
    } else if (imageData.method === "gradient") {
        return new WebkitGradientContainer(imageData);
    } else if (imageData.method === "svg") {
        return new SVGNodeContainer(imageData.args[0], this.support.svg);
    } else if (imageData.method === "IFRAME") {
        return new FrameContainer(imageData.args[0], this.isSameOrigin(imageData.args[0].src), this.options);
    } else {
        return new DummyImageContainer(imageData);
    }
};

ImageLoader.prototype.isSVG = function(src) {
    return src.substring(src.length - 3).toLowerCase() === "svg" || SVGContainer.prototype.isInline(src);
};

ImageLoader.prototype.imageExists = function(images, src) {
    return images.some(function(image) {
        return image.src === src;
    });
};

ImageLoader.prototype.isSameOrigin = function(url) {
    return (this.getOrigin(url) === this.origin);
};

ImageLoader.prototype.getOrigin = function(url) {
    var link = this.link || (this.link = document.createElement("a"));
    link.href = url;
    link.href = link.href; // IE9, LOL! - http://jsfiddle.net/niklasvh/2e48b/
    return link.protocol + link.hostname + link.port;
};

ImageLoader.prototype.getPromise = function(container) {
    return this.timeout(container, this.options.imageTimeout)['catch'](function() {
        var dummy = new DummyImageContainer(container.src);
        return dummy.promise.then(function(image) {
            container.image = image;
        });
    });
};

ImageLoader.prototype.get = function(src) {
    var found = null;
    return this.images.some(function(img) {
        return (found = img).src === src;
    }) ? found : null;
};

ImageLoader.prototype.fetch = function(nodes) {
    this.images = nodes.reduce(bind(this.findBackgroundImage, this), this.findImages(nodes));
    this.images.forEach(function(image, index) {
        image.promise.then(function() {
            log("Succesfully loaded image #"+ (index+1), image);
        }, function(e) {
            log("Failed loading image #"+ (index+1), image, e);
        });
    });
    this.ready = Promise.all(this.images.map(this.getPromise, this));
    log("Finished searching images");
    return this;
};

ImageLoader.prototype.timeout = function(container, timeout) {
    var timer;
    var promise = Promise.race([container.promise, new Promise(function(res, reject) {
        timer = setTimeout(function() {
            log("Timed out loading image", container);
            reject(container);
        }, timeout);
    })]).then(function(container) {
        clearTimeout(timer);
        return container;
    });
    promise['catch'](function() {
        clearTimeout(timer);
    });
    return promise;
};

module.exports = ImageLoader;

},{"./dummyimagecontainer":5,"./framecontainer":8,"./imagecontainer":10,"./lineargradientcontainer":12,"./log":13,"./proxyimagecontainer":17,"./svgcontainer":23,"./svgnodecontainer":24,"./utils":26,"./webkitgradientcontainer":27}],12:[function(_dereq_,module,exports){
var GradientContainer = _dereq_('./gradientcontainer');
var Color = _dereq_('./color');

function LinearGradientContainer(imageData) {
    GradientContainer.apply(this, arguments);
    this.type = GradientContainer.TYPES.LINEAR;

    var hasDirection = LinearGradientContainer.REGEXP_DIRECTION.test( imageData.args[0] ) ||
        !GradientContainer.REGEXP_COLORSTOP.test( imageData.args[0] );

    if (hasDirection) {
        imageData.args[0].split(/\s+/).reverse().forEach(function(position, index) {
            switch(position) {
            case "left":
                this.x0 = 0;
                this.x1 = 1;
                break;
            case "top":
                this.y0 = 0;
                this.y1 = 1;
                break;
            case "right":
                this.x0 = 1;
                this.x1 = 0;
                break;
            case "bottom":
                this.y0 = 1;
                this.y1 = 0;
                break;
            case "to":
                var y0 = this.y0;
                var x0 = this.x0;
                this.y0 = this.y1;
                this.x0 = this.x1;
                this.x1 = x0;
                this.y1 = y0;
                break;
            case "center":
                break; // centered by default
            // Firefox internally converts position keywords to percentages:
            // http://www.w3.org/TR/2010/WD-CSS2-20101207/colors.html#propdef-background-position
            default: // percentage or absolute length
                // TODO: support absolute start point positions (e.g., use bounds to convert px to a ratio)
                var ratio = parseFloat(position, 10) * 1e-2;
                if (isNaN(ratio)) { // invalid or unhandled value
                    break;
                }
                if (index === 0) {
                    this.y0 = ratio;
                    this.y1 = 1 - this.y0;
                } else {
                    this.x0 = ratio;
                    this.x1 = 1 - this.x0;
                }
                break;
            }
        }, this);
    } else {
        this.y0 = 0;
        this.y1 = 1;
    }

    this.colorStops = imageData.args.slice(hasDirection ? 1 : 0).map(function(colorStop) {
        var colorStopMatch = colorStop.match(GradientContainer.REGEXP_COLORSTOP);
        var value = +colorStopMatch[2];
        var unit = value === 0 ? "%" : colorStopMatch[3]; // treat "0" as "0%"
        return {
            color: new Color(colorStopMatch[1]),
            // TODO: support absolute stop positions (e.g., compute gradient line length & convert px to ratio)
            stop: unit === "%" ? value / 100 : null
        };
    });

    if (this.colorStops[0].stop === null) {
        this.colorStops[0].stop = 0;
    }

    if (this.colorStops[this.colorStops.length - 1].stop === null) {
        this.colorStops[this.colorStops.length - 1].stop = 1;
    }

    // calculates and fills-in explicit stop positions when omitted from rule
    this.colorStops.forEach(function(colorStop, index) {
        if (colorStop.stop === null) {
            this.colorStops.slice(index).some(function(find, count) {
                if (find.stop !== null) {
                    colorStop.stop = ((find.stop - this.colorStops[index - 1].stop) / (count + 1)) + this.colorStops[index - 1].stop;
                    return true;
                } else {
                    return false;
                }
            }, this);
        }
    }, this);
}

LinearGradientContainer.prototype = Object.create(GradientContainer.prototype);

// TODO: support <angle> (e.g. -?\d{1,3}(?:\.\d+)deg, etc. : https://developer.mozilla.org/docs/Web/CSS/angle )
LinearGradientContainer.REGEXP_DIRECTION = /^\s*(?:to|left|right|top|bottom|center|\d{1,3}(?:\.\d+)?%?)(?:\s|$)/i;

module.exports = LinearGradientContainer;

},{"./color":3,"./gradientcontainer":9}],13:[function(_dereq_,module,exports){
var logger = function() {
    if (logger.options.logging && window.console && window.console.log) {
        Function.prototype.bind.call(window.console.log, (window.console)).apply(window.console, [(Date.now() - logger.options.start) + "ms", "html2canvas:"].concat([].slice.call(arguments, 0)));
    }
};

logger.options = {logging: false};
module.exports = logger;

},{}],14:[function(_dereq_,module,exports){
var Color = _dereq_('./color');
var utils = _dereq_('./utils');
var getBounds = utils.getBounds;
var parseBackgrounds = utils.parseBackgrounds;
var offsetBounds = utils.offsetBounds;

function NodeContainer(node, parent) {
    this.node = node;
    this.parent = parent;
    this.stack = null;
    this.bounds = null;
    this.borders = null;
    this.clip = [];
    this.backgroundClip = [];
    this.offsetBounds = null;
    this.visible = null;
    this.computedStyles = null;
    this.colors = {};
    this.styles = {};
    this.backgroundImages = null;
    this.transformData = null;
    this.transformMatrix = null;
    this.isPseudoElement = false;
    this.opacity = null;
}

NodeContainer.prototype.cloneTo = function(stack) {
    stack.visible = this.visible;
    stack.borders = this.borders;
    stack.bounds = this.bounds;
    stack.clip = this.clip;
    stack.backgroundClip = this.backgroundClip;
    stack.computedStyles = this.computedStyles;
    stack.styles = this.styles;
    stack.backgroundImages = this.backgroundImages;
    stack.opacity = this.opacity;
};

NodeContainer.prototype.getOpacity = function() {
    return this.opacity === null ? (this.opacity = this.cssFloat('opacity')) : this.opacity;
};

NodeContainer.prototype.assignStack = function(stack) {
    this.stack = stack;
    stack.children.push(this);
};

NodeContainer.prototype.isElementVisible = function() {
    return this.node.nodeType === Node.TEXT_NODE ? this.parent.visible : (
        this.css('display') !== "none" &&
        this.css('visibility') !== "hidden" &&
        !this.node.hasAttribute("data-html2canvas-ignore") &&
        (this.node.nodeName !== "INPUT" || this.node.getAttribute("type") !== "hidden")
    );
};

NodeContainer.prototype.css = function(attribute) {
    if (!this.computedStyles) {
        this.computedStyles = this.isPseudoElement ? this.parent.computedStyle(this.before ? ":before" : ":after") : this.computedStyle(null);
    }

    return this.styles[attribute] || (this.styles[attribute] = this.computedStyles[attribute]);
};

NodeContainer.prototype.prefixedCss = function(attribute) {
    var prefixes = ["webkit", "moz", "ms", "o"];
    var value = this.css(attribute);
    if (value === undefined) {
        prefixes.some(function(prefix) {
            value = this.css(prefix + attribute.substr(0, 1).toUpperCase() + attribute.substr(1));
            return value !== undefined;
        }, this);
    }
    return value === undefined ? null : value;
};

NodeContainer.prototype.computedStyle = function(type) {
    return this.node.ownerDocument.defaultView.getComputedStyle(this.node, type);
};

NodeContainer.prototype.cssInt = function(attribute) {
    var value = parseInt(this.css(attribute), 10);
    return (isNaN(value)) ? 0 : value; // borders in old IE are throwing 'medium' for demo.html
};

NodeContainer.prototype.color = function(attribute) {
    return this.colors[attribute] || (this.colors[attribute] = new Color(this.css(attribute)));
};

NodeContainer.prototype.cssFloat = function(attribute) {
    var value = parseFloat(this.css(attribute));
    return (isNaN(value)) ? 0 : value;
};

NodeContainer.prototype.fontWeight = function() {
    var weight = this.css("fontWeight");
    switch(parseInt(weight, 10)){
    case 401:
        weight = "bold";
        break;
    case 400:
        weight = "normal";
        break;
    }
    return weight;
};

NodeContainer.prototype.parseClip = function() {
    var matches = this.css('clip').match(this.CLIP);
    if (matches) {
        return {
            top: parseInt(matches[1], 10),
            right: parseInt(matches[2], 10),
            bottom: parseInt(matches[3], 10),
            left: parseInt(matches[4], 10)
        };
    }
    return null;
};

NodeContainer.prototype.parseBackgroundImages = function() {
    return this.backgroundImages || (this.backgroundImages = parseBackgrounds(this.css("backgroundImage")));
};

NodeContainer.prototype.cssList = function(property, index) {
    var value = (this.css(property) || '').split(',');
    value = value[index || 0] || value[0] || 'auto';
    value = value.trim().split(' ');
    if (value.length === 1) {
        value = [value[0], isPercentage(value[0]) ? 'auto' : value[0]];
    }
    return value;
};

NodeContainer.prototype.parseBackgroundSize = function(bounds, image, index) {
    var size = this.cssList("backgroundSize", index);
    var width, height;

    if (isPercentage(size[0])) {
        width = bounds.width * parseFloat(size[0]) / 100;
    } else if (/contain|cover/.test(size[0])) {
        var targetRatio = bounds.width / bounds.height, currentRatio = image.width / image.height;
        return (targetRatio < currentRatio ^ size[0] === 'contain') ?  {width: bounds.height * currentRatio, height: bounds.height} : {width: bounds.width, height: bounds.width / currentRatio};
    } else {
        width = parseInt(size[0], 10);
    }

    if (size[0] === 'auto' && size[1] === 'auto') {
        height = image.height;
    } else if (size[1] === 'auto') {
        height = width / image.width * image.height;
    } else if (isPercentage(size[1])) {
        height =  bounds.height * parseFloat(size[1]) / 100;
    } else {
        height = parseInt(size[1], 10);
    }

    if (size[0] === 'auto') {
        width = height / image.height * image.width;
    }

    return {width: width, height: height};
};

NodeContainer.prototype.parseBackgroundPosition = function(bounds, image, index, backgroundSize) {
    var position = this.cssList('backgroundPosition', index);
    var left, top;

    if (isPercentage(position[0])){
        left = (bounds.width - (backgroundSize || image).width) * (parseFloat(position[0]) / 100);
    } else {
        left = parseInt(position[0], 10);
    }

    if (position[1] === 'auto') {
        top = left / image.width * image.height;
    } else if (isPercentage(position[1])){
        top =  (bounds.height - (backgroundSize || image).height) * parseFloat(position[1]) / 100;
    } else {
        top = parseInt(position[1], 10);
    }

    if (position[0] === 'auto') {
        left = top / image.height * image.width;
    }

    return {left: left, top: top};
};

NodeContainer.prototype.parseBackgroundRepeat = function(index) {
    return this.cssList("backgroundRepeat", index)[0];
};

NodeContainer.prototype.parseTextShadows = function() {
    var textShadow = this.css("textShadow");
    var results = [];

    if (textShadow && textShadow !== 'none') {
        var shadows = textShadow.match(this.TEXT_SHADOW_PROPERTY);
        for (var i = 0; shadows && (i < shadows.length); i++) {
            var s = shadows[i].match(this.TEXT_SHADOW_VALUES);
            results.push({
                color: new Color(s[0]),
                offsetX: s[1] ? parseFloat(s[1].replace('px', '')) : 0,
                offsetY: s[2] ? parseFloat(s[2].replace('px', '')) : 0,
                blur: s[3] ? s[3].replace('px', '') : 0
            });
        }
    }
    return results;
};

NodeContainer.prototype.parseTransform = function() {
    if (!this.transformData) {
        if (this.hasTransform()) {
            var offset = this.parseBounds();
            var origin = this.prefixedCss("transformOrigin").split(" ").map(removePx).map(asFloat);
            origin[0] += offset.left;
            origin[1] += offset.top;
            this.transformData = {
                origin: origin,
                matrix: this.parseTransformMatrix()
            };
        } else {
            this.transformData = {
                origin: [0, 0],
                matrix: [1, 0, 0, 1, 0, 0]
            };
        }
    }
    return this.transformData;
};

NodeContainer.prototype.parseTransformMatrix = function() {
    if (!this.transformMatrix) {
        var transform = this.prefixedCss("transform");
        var matrix = transform ? parseMatrix(transform.match(this.MATRIX_PROPERTY)) : null;
        this.transformMatrix = matrix ? matrix : [1, 0, 0, 1, 0, 0];
    }
    return this.transformMatrix;
};

NodeContainer.prototype.parseBounds = function() {
    return this.bounds || (this.bounds = this.hasTransform() ? offsetBounds(this.node) : getBounds(this.node));
};

NodeContainer.prototype.hasTransform = function() {
    return this.parseTransformMatrix().join(",") !== "1,0,0,1,0,0" || (this.parent && this.parent.hasTransform());
};

NodeContainer.prototype.getValue = function() {
    var value = this.node.value || "";
    if (this.node.tagName === "SELECT") {
        value = selectionValue(this.node);
    } else if (this.node.type === "password") {
        value = Array(value.length + 1).join('\u2022'); // jshint ignore:line
    }
    return value.length === 0 ? (this.node.placeholder || "") : value;
};

NodeContainer.prototype.MATRIX_PROPERTY = /(matrix|matrix3d)\((.+)\)/;
NodeContainer.prototype.TEXT_SHADOW_PROPERTY = /((rgba|rgb)\([^\)]+\)(\s-?\d+px){0,})/g;
NodeContainer.prototype.TEXT_SHADOW_VALUES = /(-?\d+px)|(#.+)|(rgb\(.+\))|(rgba\(.+\))/g;
NodeContainer.prototype.CLIP = /^rect\((\d+)px,? (\d+)px,? (\d+)px,? (\d+)px\)$/;

function selectionValue(node) {
    var option = node.options[node.selectedIndex || 0];
    return option ? (option.text || "") : "";
}

function parseMatrix(match) {
    if (match && match[1] === "matrix") {
        return match[2].split(",").map(function(s) {
            return parseFloat(s.trim());
        });
    } else if (match && match[1] === "matrix3d") {
        var matrix3d = match[2].split(",").map(function(s) {
          return parseFloat(s.trim());
        });
        return [matrix3d[0], matrix3d[1], matrix3d[4], matrix3d[5], matrix3d[12], matrix3d[13]];
    }
}

function isPercentage(value) {
    return value.toString().indexOf("%") !== -1;
}

function removePx(str) {
    return str.replace("px", "");
}

function asFloat(str) {
    return parseFloat(str);
}

module.exports = NodeContainer;

},{"./color":3,"./utils":26}],15:[function(_dereq_,module,exports){
var log = _dereq_('./log');
var punycode = _dereq_('punycode');
var NodeContainer = _dereq_('./nodecontainer');
var TextContainer = _dereq_('./textcontainer');
var PseudoElementContainer = _dereq_('./pseudoelementcontainer');
var FontMetrics = _dereq_('./fontmetrics');
var Color = _dereq_('./color');
var StackingContext = _dereq_('./stackingcontext');
var utils = _dereq_('./utils');
var bind = utils.bind;
var getBounds = utils.getBounds;
var parseBackgrounds = utils.parseBackgrounds;
var offsetBounds = utils.offsetBounds;

function NodeParser(element, renderer, support, imageLoader, options) {
    log("Starting NodeParser");
    this.renderer = renderer;
    this.options = options;
    this.range = null;
    this.support = support;
    this.renderQueue = [];
    this.stack = new StackingContext(true, 1, element.ownerDocument, null);
    var parent = new NodeContainer(element, null);
    if (options.background) {
        renderer.rectangle(0, 0, renderer.width, renderer.height, new Color(options.background));
    }
    if (element === element.ownerDocument.documentElement) {
        // http://www.w3.org/TR/css3-background/#special-backgrounds
        var canvasBackground = new NodeContainer(parent.color('backgroundColor').isTransparent() ? element.ownerDocument.body : element.ownerDocument.documentElement, null);
        renderer.rectangle(0, 0, renderer.width, renderer.height, canvasBackground.color('backgroundColor'));
    }
    parent.visibile = parent.isElementVisible();
    this.createPseudoHideStyles(element.ownerDocument);
    this.disableAnimations(element.ownerDocument);
    this.nodes = flatten([parent].concat(this.getChildren(parent)).filter(function(container) {
        return container.visible = container.isElementVisible();
    }).map(this.getPseudoElements, this));
    this.fontMetrics = new FontMetrics();
    log("Fetched nodes, total:", this.nodes.length);
    log("Calculate overflow clips");
    this.calculateOverflowClips();
    log("Start fetching images");
    this.images = imageLoader.fetch(this.nodes.filter(isElement));
    this.ready = this.images.ready.then(bind(function() {
        log("Images loaded, starting parsing");
        log("Creating stacking contexts");
        this.createStackingContexts();
        log("Sorting stacking contexts");
        this.sortStackingContexts(this.stack);
        this.parse(this.stack);
        log("Render queue created with " + this.renderQueue.length + " items");
        return new Promise(bind(function(resolve) {
            if (!options.async) {
                this.renderQueue.forEach(this.paint, this);
                resolve();
            } else if (typeof(options.async) === "function") {
                options.async.call(this, this.renderQueue, resolve);
            } else if (this.renderQueue.length > 0){
                this.renderIndex = 0;
                this.asyncRenderer(this.renderQueue, resolve);
            } else {
                resolve();
            }
        }, this));
    }, this));
}

NodeParser.prototype.calculateOverflowClips = function() {
    this.nodes.forEach(function(container) {
        if (isElement(container)) {
            if (isPseudoElement(container)) {
                container.appendToDOM();
            }
            container.borders = this.parseBorders(container);
            var clip = (container.css('overflow') === "hidden") ? [container.borders.clip] : [];
            var cssClip = container.parseClip();
            if (cssClip && ["absolute", "fixed"].indexOf(container.css('position')) !== -1) {
                clip.push([["rect",
                        container.bounds.left + cssClip.left,
                        container.bounds.top + cssClip.top,
                        cssClip.right - cssClip.left,
                        cssClip.bottom - cssClip.top
                ]]);
            }
            container.clip = hasParentClip(container) ? container.parent.clip.concat(clip) : clip;
            container.backgroundClip = (container.css('overflow') !== "hidden") ? container.clip.concat([container.borders.clip]) : container.clip;
            if (isPseudoElement(container)) {
                container.cleanDOM();
            }
        } else if (isTextNode(container)) {
            container.clip = hasParentClip(container) ? container.parent.clip : [];
        }
        if (!isPseudoElement(container)) {
            container.bounds = null;
        }
    }, this);
};

function hasParentClip(container) {
    return container.parent && container.parent.clip.length;
}

NodeParser.prototype.asyncRenderer = function(queue, resolve, asyncTimer) {
    asyncTimer = asyncTimer || Date.now();
    this.paint(queue[this.renderIndex++]);
    if (queue.length === this.renderIndex) {
        resolve();
    } else if (asyncTimer + 20 > Date.now()) {
        this.asyncRenderer(queue, resolve, asyncTimer);
    } else {
        setTimeout(bind(function() {
            this.asyncRenderer(queue, resolve);
        }, this), 0);
    }
};

NodeParser.prototype.createPseudoHideStyles = function(document) {
    this.createStyles(document, '.' + PseudoElementContainer.prototype.PSEUDO_HIDE_ELEMENT_CLASS_BEFORE + ':before { content: "" !important; display: none !important; }' +
        '.' + PseudoElementContainer.prototype.PSEUDO_HIDE_ELEMENT_CLASS_AFTER + ':after { content: "" !important; display: none !important; }');
};

NodeParser.prototype.disableAnimations = function(document) {
    this.createStyles(document, '* { -webkit-animation: none !important; -moz-animation: none !important; -o-animation: none !important; animation: none !important; ' +
        '-webkit-transition: none !important; -moz-transition: none !important; -o-transition: none !important; transition: none !important;}');
};

NodeParser.prototype.createStyles = function(document, styles) {
    var hidePseudoElements = document.createElement('style');
    hidePseudoElements.innerHTML = styles;
    document.body.appendChild(hidePseudoElements);
};

NodeParser.prototype.getPseudoElements = function(container) {
    var nodes = [[container]];
    if (container.node.nodeType === Node.ELEMENT_NODE) {
        var before = this.getPseudoElement(container, ":before");
        var after = this.getPseudoElement(container, ":after");

        if (before) {
            nodes.push(before);
        }

        if (after) {
            nodes.push(after);
        }
    }
    return flatten(nodes);
};

function toCamelCase(str) {
    return str.replace(/(\-[a-z])/g, function(match){
        return match.toUpperCase().replace('-','');
    });
}

NodeParser.prototype.getPseudoElement = function(container, type) {
    var style = container.computedStyle(type);
    if(!style || !style.content || style.content === "none" || style.content === "-moz-alt-content" || style.display === "none") {
        return null;
    }

    var content = stripQuotes(style.content);
    var isImage = content.substr(0, 3) === 'url';
    var pseudoNode = document.createElement(isImage ? 'img' : 'html2canvaspseudoelement');
    var pseudoContainer = new PseudoElementContainer(pseudoNode, container, type);

    for (var i = style.length-1; i >= 0; i--) {
        var property = toCamelCase(style.item(i));
        pseudoNode.style[property] = style[property];
    }

    pseudoNode.className = PseudoElementContainer.prototype.PSEUDO_HIDE_ELEMENT_CLASS_BEFORE + " " + PseudoElementContainer.prototype.PSEUDO_HIDE_ELEMENT_CLASS_AFTER;

    if (isImage) {
        pseudoNode.src = parseBackgrounds(content)[0].args[0];
        return [pseudoContainer];
    } else {
        var text = document.createTextNode(content);
        pseudoNode.appendChild(text);
        return [pseudoContainer, new TextContainer(text, pseudoContainer)];
    }
};


NodeParser.prototype.getChildren = function(parentContainer) {
    return flatten([].filter.call(parentContainer.node.childNodes, renderableNode).map(function(node) {
        var container = [node.nodeType === Node.TEXT_NODE ? new TextContainer(node, parentContainer) : new NodeContainer(node, parentContainer)].filter(nonIgnoredElement);
        return node.nodeType === Node.ELEMENT_NODE && container.length && node.tagName !== "TEXTAREA" ? (container[0].isElementVisible() ? container.concat(this.getChildren(container[0])) : []) : container;
    }, this));
};

NodeParser.prototype.newStackingContext = function(container, hasOwnStacking) {
    var stack = new StackingContext(hasOwnStacking, container.getOpacity(), container.node, container.parent);
    container.cloneTo(stack);
    var parentStack = hasOwnStacking ? stack.getParentStack(this) : stack.parent.stack;
    parentStack.contexts.push(stack);
    container.stack = stack;
};

NodeParser.prototype.createStackingContexts = function() {
    this.nodes.forEach(function(container) {
        if (isElement(container) && (this.isRootElement(container) || hasOpacity(container) || isPositionedForStacking(container) || this.isBodyWithTransparentRoot(container) || container.hasTransform())) {
            this.newStackingContext(container, true);
        } else if (isElement(container) && ((isPositioned(container) && zIndex0(container)) || isInlineBlock(container) || isFloating(container))) {
            this.newStackingContext(container, false);
        } else {
            container.assignStack(container.parent.stack);
        }
    }, this);
};

NodeParser.prototype.isBodyWithTransparentRoot = function(container) {
    return container.node.nodeName === "BODY" && container.parent.color('backgroundColor').isTransparent();
};

NodeParser.prototype.isRootElement = function(container) {
    return container.parent === null;
};

NodeParser.prototype.sortStackingContexts = function(stack) {
    stack.contexts.sort(zIndexSort(stack.contexts.slice(0)));
    stack.contexts.forEach(this.sortStackingContexts, this);
};

NodeParser.prototype.parseTextBounds = function(container) {
    return function(text, index, textList) {
        if (container.parent.css("textDecoration").substr(0, 4) !== "none" || text.trim().length !== 0) {
            if (this.support.rangeBounds && !container.parent.hasTransform()) {
                var offset = textList.slice(0, index).join("").length;
                return this.getRangeBounds(container.node, offset, text.length);
            } else if (container.node && typeof(container.node.data) === "string") {
                var replacementNode = container.node.splitText(text.length);
                var bounds = this.getWrapperBounds(container.node, container.parent.hasTransform());
                container.node = replacementNode;
                return bounds;
            }
        } else if(!this.support.rangeBounds || container.parent.hasTransform()){
            container.node = container.node.splitText(text.length);
        }
        return {};
    };
};

NodeParser.prototype.getWrapperBounds = function(node, transform) {
    var wrapper = node.ownerDocument.createElement('html2canvaswrapper');
    var parent = node.parentNode,
        backupText = node.cloneNode(true);

    wrapper.appendChild(node.cloneNode(true));
    parent.replaceChild(wrapper, node);
    var bounds = transform ? offsetBounds(wrapper) : getBounds(wrapper);
    parent.replaceChild(backupText, wrapper);
    return bounds;
};

NodeParser.prototype.getRangeBounds = function(node, offset, length) {
    var range = this.range || (this.range = node.ownerDocument.createRange());
    range.setStart(node, offset);
    range.setEnd(node, offset + length);
    return range.getBoundingClientRect();
};

function ClearTransform() {}

NodeParser.prototype.parse = function(stack) {
    // http://www.w3.org/TR/CSS21/visuren.html#z-index
    var negativeZindex = stack.contexts.filter(negativeZIndex); // 2. the child stacking contexts with negative stack levels (most negative first).
    var descendantElements = stack.children.filter(isElement);
    var descendantNonFloats = descendantElements.filter(not(isFloating));
    var nonInlineNonPositionedDescendants = descendantNonFloats.filter(not(isPositioned)).filter(not(inlineLevel)); // 3 the in-flow, non-inline-level, non-positioned descendants.
    var nonPositionedFloats = descendantElements.filter(not(isPositioned)).filter(isFloating); // 4. the non-positioned floats.
    var inFlow = descendantNonFloats.filter(not(isPositioned)).filter(inlineLevel); // 5. the in-flow, inline-level, non-positioned descendants, including inline tables and inline blocks.
    var stackLevel0 = stack.contexts.concat(descendantNonFloats.filter(isPositioned)).filter(zIndex0); // 6. the child stacking contexts with stack level 0 and the positioned descendants with stack level 0.
    var text = stack.children.filter(isTextNode).filter(hasText);
    var positiveZindex = stack.contexts.filter(positiveZIndex); // 7. the child stacking contexts with positive stack levels (least positive first).
    negativeZindex.concat(nonInlineNonPositionedDescendants).concat(nonPositionedFloats)
        .concat(inFlow).concat(stackLevel0).concat(text).concat(positiveZindex).forEach(function(container) {
            this.renderQueue.push(container);
            if (isStackingContext(container)) {
                this.parse(container);
                this.renderQueue.push(new ClearTransform());
            }
        }, this);
};

NodeParser.prototype.paint = function(container) {
    try {
        if (container instanceof ClearTransform) {
            this.renderer.ctx.restore();
        } else if (isTextNode(container)) {
            if (isPseudoElement(container.parent)) {
                container.parent.appendToDOM();
            }
            this.paintText(container);
            if (isPseudoElement(container.parent)) {
                container.parent.cleanDOM();
            }
        } else {
            this.paintNode(container);
        }
    } catch(e) {
        log(e);
        if (this.options.strict) {
            throw e;
        }
    }
};

NodeParser.prototype.paintNode = function(container) {
    if (isStackingContext(container)) {
        this.renderer.setOpacity(container.opacity);
        this.renderer.ctx.save();
        if (container.hasTransform()) {
            this.renderer.setTransform(container.parseTransform());
        }
    }

    if (container.node.nodeName === "INPUT" && container.node.type === "checkbox") {
        this.paintCheckbox(container);
    } else if (container.node.nodeName === "INPUT" && container.node.type === "radio") {
        this.paintRadio(container);
    } else {
        this.paintElement(container);
    }
};

NodeParser.prototype.paintElement = function(container) {
    var bounds = container.parseBounds();
    this.renderer.clip(container.backgroundClip, function() {
        this.renderer.renderBackground(container, bounds, container.borders.borders.map(getWidth));
    }, this);

    this.renderer.clip(container.clip, function() {
        this.renderer.renderBorders(container.borders.borders);
    }, this);

    this.renderer.clip(container.backgroundClip, function() {
        switch (container.node.nodeName) {
        case "svg":
        case "IFRAME":
            var imgContainer = this.images.get(container.node);
            if (imgContainer) {
                this.renderer.renderImage(container, bounds, container.borders, imgContainer);
            } else {
                log("Error loading <" + container.node.nodeName + ">", container.node);
            }
            break;
        case "IMG":
            var imageContainer = this.images.get(container.node.src);
            if (imageContainer) {
                this.renderer.renderImage(container, bounds, container.borders, imageContainer);
            } else {
                log("Error loading <img>", container.node.src);
            }
            break;
        case "CANVAS":
            this.renderer.renderImage(container, bounds, container.borders, {image: container.node});
            break;
        case "SELECT":
        case "INPUT":
        case "TEXTAREA":
            this.paintFormValue(container);
            break;
        }
    }, this);
};

NodeParser.prototype.paintCheckbox = function(container) {
    var b = container.parseBounds();

    var size = Math.min(b.width, b.height);
    var bounds = {width: size - 1, height: size - 1, top: b.top, left: b.left};
    var r = [3, 3];
    var radius = [r, r, r, r];
    var borders = [1,1,1,1].map(function(w) {
        return {color: new Color('#A5A5A5'), width: w};
    });

    var borderPoints = calculateCurvePoints(bounds, radius, borders);

    this.renderer.clip(container.backgroundClip, function() {
        this.renderer.rectangle(bounds.left + 1, bounds.top + 1, bounds.width - 2, bounds.height - 2, new Color("#DEDEDE"));
        this.renderer.renderBorders(calculateBorders(borders, bounds, borderPoints, radius));
        if (container.node.checked) {
            this.renderer.font(new Color('#424242'), 'normal', 'normal', 'bold', (size - 3) + "px", 'arial');
            this.renderer.text("\u2714", bounds.left + size / 6, bounds.top + size - 1);
        }
    }, this);
};

NodeParser.prototype.paintRadio = function(container) {
    var bounds = container.parseBounds();

    var size = Math.min(bounds.width, bounds.height) - 2;

    this.renderer.clip(container.backgroundClip, function() {
        this.renderer.circleStroke(bounds.left + 1, bounds.top + 1, size, new Color('#DEDEDE'), 1, new Color('#A5A5A5'));
        if (container.node.checked) {
            this.renderer.circle(Math.ceil(bounds.left + size / 4) + 1, Math.ceil(bounds.top + size / 4) + 1, Math.floor(size / 2), new Color('#424242'));
        }
    }, this);
};

NodeParser.prototype.paintFormValue = function(container) {
    var value = container.getValue();
    if (value.length > 0) {
        var document = container.node.ownerDocument;
        var wrapper = document.createElement('html2canvaswrapper');
        var properties = ['lineHeight', 'textAlign', 'fontFamily', 'fontWeight', 'fontSize', 'color',
            'paddingLeft', 'paddingTop', 'paddingRight', 'paddingBottom',
            'width', 'height', 'borderLeftStyle', 'borderTopStyle', 'borderLeftWidth', 'borderTopWidth',
            'boxSizing', 'whiteSpace', 'wordWrap'];

        properties.forEach(function(property) {
            try {
                wrapper.style[property] = container.css(property);
            } catch(e) {
                // Older IE has issues with "border"
                log("html2canvas: Parse: Exception caught in renderFormValue: " + e.message);
            }
        });
        var bounds = container.parseBounds();
        wrapper.style.position = "fixed";
        wrapper.style.left = bounds.left + "px";
        wrapper.style.top = bounds.top + "px";
        wrapper.textContent = value;
        document.body.appendChild(wrapper);
        this.paintText(new TextContainer(wrapper.firstChild, container));
        document.body.removeChild(wrapper);
    }
};

NodeParser.prototype.paintText = function(container) {
    container.applyTextTransform();
    var characters = punycode.ucs2.decode(container.node.data);
    var textList = (!this.options.letterRendering || noLetterSpacing(container)) && !hasUnicode(container.node.data) ? getWords(characters) : characters.map(function(character) {
        return punycode.ucs2.encode([character]);
    });

    var weight = container.parent.fontWeight();
    var size = container.parent.css('fontSize');
    var family = container.parent.css('fontFamily');
    var shadows = container.parent.parseTextShadows();

    this.renderer.font(container.parent.color('color'), container.parent.css('fontStyle'), container.parent.css('fontVariant'), weight, size, family);
    if (shadows.length) {
        // TODO: support multiple text shadows
        this.renderer.fontShadow(shadows[0].color, shadows[0].offsetX, shadows[0].offsetY, shadows[0].blur);
    } else {
        this.renderer.clearShadow();
    }

    this.renderer.clip(container.parent.clip, function() {
        textList.map(this.parseTextBounds(container), this).forEach(function(bounds, index) {
            if (bounds) {
                this.renderer.text(textList[index], bounds.left, bounds.bottom);
                this.renderTextDecoration(container.parent, bounds, this.fontMetrics.getMetrics(family, size));
            }
        }, this);
    }, this);
};

NodeParser.prototype.renderTextDecoration = function(container, bounds, metrics) {
    switch(container.css("textDecoration").split(" ")[0]) {
    case "underline":
        // Draws a line at the baseline of the font
        // TODO As some browsers display the line as more than 1px if the font-size is big, need to take that into account both in position and size
        this.renderer.rectangle(bounds.left, Math.round(bounds.top + metrics.baseline + metrics.lineWidth), bounds.width, 1, container.color("color"));
        break;
    case "overline":
        this.renderer.rectangle(bounds.left, Math.round(bounds.top), bounds.width, 1, container.color("color"));
        break;
    case "line-through":
        // TODO try and find exact position for line-through
        this.renderer.rectangle(bounds.left, Math.ceil(bounds.top + metrics.middle + metrics.lineWidth), bounds.width, 1, container.color("color"));
        break;
    }
};

var borderColorTransforms = {
    inset: [
        ["darken", 0.60],
        ["darken", 0.10],
        ["darken", 0.10],
        ["darken", 0.60]
    ]
};

NodeParser.prototype.parseBorders = function(container) {
    var nodeBounds = container.parseBounds();
    var radius = getBorderRadiusData(container);
    var borders = ["Top", "Right", "Bottom", "Left"].map(function(side, index) {
        var style = container.css('border' + side + 'Style');
        var color = container.color('border' + side + 'Color');
        if (style === "inset" && color.isBlack()) {
            color = new Color([255, 255, 255, color.a]); // this is wrong, but
        }
        var colorTransform = borderColorTransforms[style] ? borderColorTransforms[style][index] : null;
        return {
            width: container.cssInt('border' + side + 'Width'),
            color: colorTransform ? color[colorTransform[0]](colorTransform[1]) : color,
            args: null
        };
    });
    var borderPoints = calculateCurvePoints(nodeBounds, radius, borders);

    return {
        clip: this.parseBackgroundClip(container, borderPoints, borders, radius, nodeBounds),
        borders: calculateBorders(borders, nodeBounds, borderPoints, radius)
    };
};

function calculateBorders(borders, nodeBounds, borderPoints, radius) {
    return borders.map(function(border, borderSide) {
        if (border.width > 0) {
            var bx = nodeBounds.left;
            var by = nodeBounds.top;
            var bw = nodeBounds.width;
            var bh = nodeBounds.height - (borders[2].width);

            switch(borderSide) {
            case 0:
                // top border
                bh = borders[0].width;
                border.args = drawSide({
                        c1: [bx, by],
                        c2: [bx + bw, by],
                        c3: [bx + bw - borders[1].width, by + bh],
                        c4: [bx + borders[3].width, by + bh]
                    }, radius[0], radius[1],
                    borderPoints.topLeftOuter, borderPoints.topLeftInner, borderPoints.topRightOuter, borderPoints.topRightInner);
                break;
            case 1:
                // right border
                bx = nodeBounds.left + nodeBounds.width - (borders[1].width);
                bw = borders[1].width;

                border.args = drawSide({
                        c1: [bx + bw, by],
                        c2: [bx + bw, by + bh + borders[2].width],
                        c3: [bx, by + bh],
                        c4: [bx, by + borders[0].width]
                    }, radius[1], radius[2],
                    borderPoints.topRightOuter, borderPoints.topRightInner, borderPoints.bottomRightOuter, borderPoints.bottomRightInner);
                break;
            case 2:
                // bottom border
                by = (by + nodeBounds.height) - (borders[2].width);
                bh = borders[2].width;
                border.args = drawSide({
                        c1: [bx + bw, by + bh],
                        c2: [bx, by + bh],
                        c3: [bx + borders[3].width, by],
                        c4: [bx + bw - borders[3].width, by]
                    }, radius[2], radius[3],
                    borderPoints.bottomRightOuter, borderPoints.bottomRightInner, borderPoints.bottomLeftOuter, borderPoints.bottomLeftInner);
                break;
            case 3:
                // left border
                bw = borders[3].width;
                border.args = drawSide({
                        c1: [bx, by + bh + borders[2].width],
                        c2: [bx, by],
                        c3: [bx + bw, by + borders[0].width],
                        c4: [bx + bw, by + bh]
                    }, radius[3], radius[0],
                    borderPoints.bottomLeftOuter, borderPoints.bottomLeftInner, borderPoints.topLeftOuter, borderPoints.topLeftInner);
                break;
            }
        }
        return border;
    });
}

NodeParser.prototype.parseBackgroundClip = function(container, borderPoints, borders, radius, bounds) {
    var backgroundClip = container.css('backgroundClip'),
        borderArgs = [];

    switch(backgroundClip) {
    case "content-box":
    case "padding-box":
        parseCorner(borderArgs, radius[0], radius[1], borderPoints.topLeftInner, borderPoints.topRightInner, bounds.left + borders[3].width, bounds.top + borders[0].width);
        parseCorner(borderArgs, radius[1], radius[2], borderPoints.topRightInner, borderPoints.bottomRightInner, bounds.left + bounds.width - borders[1].width, bounds.top + borders[0].width);
        parseCorner(borderArgs, radius[2], radius[3], borderPoints.bottomRightInner, borderPoints.bottomLeftInner, bounds.left + bounds.width - borders[1].width, bounds.top + bounds.height - borders[2].width);
        parseCorner(borderArgs, radius[3], radius[0], borderPoints.bottomLeftInner, borderPoints.topLeftInner, bounds.left + borders[3].width, bounds.top + bounds.height - borders[2].width);
        break;

    default:
        parseCorner(borderArgs, radius[0], radius[1], borderPoints.topLeftOuter, borderPoints.topRightOuter, bounds.left, bounds.top);
        parseCorner(borderArgs, radius[1], radius[2], borderPoints.topRightOuter, borderPoints.bottomRightOuter, bounds.left + bounds.width, bounds.top);
        parseCorner(borderArgs, radius[2], radius[3], borderPoints.bottomRightOuter, borderPoints.bottomLeftOuter, bounds.left + bounds.width, bounds.top + bounds.height);
        parseCorner(borderArgs, radius[3], radius[0], borderPoints.bottomLeftOuter, borderPoints.topLeftOuter, bounds.left, bounds.top + bounds.height);
        break;
    }

    return borderArgs;
};

function getCurvePoints(x, y, r1, r2) {
    var kappa = 4 * ((Math.sqrt(2) - 1) / 3);
    var ox = (r1) * kappa, // control point offset horizontal
        oy = (r2) * kappa, // control point offset vertical
        xm = x + r1, // x-middle
        ym = y + r2; // y-middle
    return {
        topLeft: bezierCurve({x: x, y: ym}, {x: x, y: ym - oy}, {x: xm - ox, y: y}, {x: xm, y: y}),
        topRight: bezierCurve({x: x, y: y}, {x: x + ox,y: y}, {x: xm, y: ym - oy}, {x: xm, y: ym}),
        bottomRight: bezierCurve({x: xm, y: y}, {x: xm, y: y + oy}, {x: x + ox, y: ym}, {x: x, y: ym}),
        bottomLeft: bezierCurve({x: xm, y: ym}, {x: xm - ox, y: ym}, {x: x, y: y + oy}, {x: x, y:y})
    };
}

function calculateCurvePoints(bounds, borderRadius, borders) {
    var x = bounds.left,
        y = bounds.top,
        width = bounds.width,
        height = bounds.height,

        tlh = borderRadius[0][0] < width / 2 ? borderRadius[0][0] : width / 2,
        tlv = borderRadius[0][1] < height / 2 ? borderRadius[0][1] : height / 2,
        trh = borderRadius[1][0] < width / 2 ? borderRadius[1][0] : width / 2,
        trv = borderRadius[1][1] < height / 2 ? borderRadius[1][1] : height / 2,
        brh = borderRadius[2][0] < width / 2 ? borderRadius[2][0] : width / 2,
        brv = borderRadius[2][1] < height / 2 ? borderRadius[2][1] : height / 2,
        blh = borderRadius[3][0] < width / 2 ? borderRadius[3][0] : width / 2,
        blv = borderRadius[3][1] < height / 2 ? borderRadius[3][1] : height / 2;

    var topWidth = width - trh,
        rightHeight = height - brv,
        bottomWidth = width - brh,
        leftHeight = height - blv;

    return {
        topLeftOuter: getCurvePoints(x, y, tlh, tlv).topLeft.subdivide(0.5),
        topLeftInner: getCurvePoints(x + borders[3].width, y + borders[0].width, Math.max(0, tlh - borders[3].width), Math.max(0, tlv - borders[0].width)).topLeft.subdivide(0.5),
        topRightOuter: getCurvePoints(x + topWidth, y, trh, trv).topRight.subdivide(0.5),
        topRightInner: getCurvePoints(x + Math.min(topWidth, width + borders[3].width), y + borders[0].width, (topWidth > width + borders[3].width) ? 0 :trh - borders[3].width, trv - borders[0].width).topRight.subdivide(0.5),
        bottomRightOuter: getCurvePoints(x + bottomWidth, y + rightHeight, brh, brv).bottomRight.subdivide(0.5),
        bottomRightInner: getCurvePoints(x + Math.min(bottomWidth, width - borders[3].width), y + Math.min(rightHeight, height + borders[0].width), Math.max(0, brh - borders[1].width),  brv - borders[2].width).bottomRight.subdivide(0.5),
        bottomLeftOuter: getCurvePoints(x, y + leftHeight, blh, blv).bottomLeft.subdivide(0.5),
        bottomLeftInner: getCurvePoints(x + borders[3].width, y + leftHeight, Math.max(0, blh - borders[3].width), blv - borders[2].width).bottomLeft.subdivide(0.5)
    };
}

function bezierCurve(start, startControl, endControl, end) {
    var lerp = function (a, b, t) {
        return {
            x: a.x + (b.x - a.x) * t,
            y: a.y + (b.y - a.y) * t
        };
    };

    return {
        start: start,
        startControl: startControl,
        endControl: endControl,
        end: end,
        subdivide: function(t) {
            var ab = lerp(start, startControl, t),
                bc = lerp(startControl, endControl, t),
                cd = lerp(endControl, end, t),
                abbc = lerp(ab, bc, t),
                bccd = lerp(bc, cd, t),
                dest = lerp(abbc, bccd, t);
            return [bezierCurve(start, ab, abbc, dest), bezierCurve(dest, bccd, cd, end)];
        },
        curveTo: function(borderArgs) {
            borderArgs.push(["bezierCurve", startControl.x, startControl.y, endControl.x, endControl.y, end.x, end.y]);
        },
        curveToReversed: function(borderArgs) {
            borderArgs.push(["bezierCurve", endControl.x, endControl.y, startControl.x, startControl.y, start.x, start.y]);
        }
    };
}

function drawSide(borderData, radius1, radius2, outer1, inner1, outer2, inner2) {
    var borderArgs = [];

    if (radius1[0] > 0 || radius1[1] > 0) {
        borderArgs.push(["line", outer1[1].start.x, outer1[1].start.y]);
        outer1[1].curveTo(borderArgs);
    } else {
        borderArgs.push([ "line", borderData.c1[0], borderData.c1[1]]);
    }

    if (radius2[0] > 0 || radius2[1] > 0) {
        borderArgs.push(["line", outer2[0].start.x, outer2[0].start.y]);
        outer2[0].curveTo(borderArgs);
        borderArgs.push(["line", inner2[0].end.x, inner2[0].end.y]);
        inner2[0].curveToReversed(borderArgs);
    } else {
        borderArgs.push(["line", borderData.c2[0], borderData.c2[1]]);
        borderArgs.push(["line", borderData.c3[0], borderData.c3[1]]);
    }

    if (radius1[0] > 0 || radius1[1] > 0) {
        borderArgs.push(["line", inner1[1].end.x, inner1[1].end.y]);
        inner1[1].curveToReversed(borderArgs);
    } else {
        borderArgs.push(["line", borderData.c4[0], borderData.c4[1]]);
    }

    return borderArgs;
}

function parseCorner(borderArgs, radius1, radius2, corner1, corner2, x, y) {
    if (radius1[0] > 0 || radius1[1] > 0) {
        borderArgs.push(["line", corner1[0].start.x, corner1[0].start.y]);
        corner1[0].curveTo(borderArgs);
        corner1[1].curveTo(borderArgs);
    } else {
        borderArgs.push(["line", x, y]);
    }

    if (radius2[0] > 0 || radius2[1] > 0) {
        borderArgs.push(["line", corner2[0].start.x, corner2[0].start.y]);
    }
}

function negativeZIndex(container) {
    return container.cssInt("zIndex") < 0;
}

function positiveZIndex(container) {
    return container.cssInt("zIndex") > 0;
}

function zIndex0(container) {
    return container.cssInt("zIndex") === 0;
}

function inlineLevel(container) {
    return ["inline", "inline-block", "inline-table"].indexOf(container.css("display")) !== -1;
}

function isStackingContext(container) {
    return (container instanceof StackingContext);
}

function hasText(container) {
    return container.node.data.trim().length > 0;
}

function noLetterSpacing(container) {
    return (/^(normal|none|0px)$/.test(container.parent.css("letterSpacing")));
}

function getBorderRadiusData(container) {
    return ["TopLeft", "TopRight", "BottomRight", "BottomLeft"].map(function(side) {
        var value = container.css('border' + side + 'Radius');
        var arr = value.split(" ");
        if (arr.length <= 1) {
            arr[1] = arr[0];
        }
        return arr.map(asInt);
    });
}

function renderableNode(node) {
    return (node.nodeType === Node.TEXT_NODE || node.nodeType === Node.ELEMENT_NODE);
}

function isPositionedForStacking(container) {
    var position = container.css("position");
    var zIndex = (["absolute", "relative", "fixed"].indexOf(position) !== -1) ? container.css("zIndex") : "auto";
    return zIndex !== "auto";
}

function isPositioned(container) {
    return container.css("position") !== "static";
}

function isFloating(container) {
    return container.css("float") !== "none";
}

function isInlineBlock(container) {
    return ["inline-block", "inline-table"].indexOf(container.css("display")) !== -1;
}

function not(callback) {
    var context = this;
    return function() {
        return !callback.apply(context, arguments);
    };
}

function isElement(container) {
    return container.node.nodeType === Node.ELEMENT_NODE;
}

function isPseudoElement(container) {
    return container.isPseudoElement === true;
}

function isTextNode(container) {
    return container.node.nodeType === Node.TEXT_NODE;
}

function zIndexSort(contexts) {
    return function(a, b) {
        return (a.cssInt("zIndex") + (contexts.indexOf(a) / contexts.length)) - (b.cssInt("zIndex") + (contexts.indexOf(b) / contexts.length));
    };
}

function hasOpacity(container) {
    return container.getOpacity() < 1;
}

function asInt(value) {
    return parseInt(value, 10);
}

function getWidth(border) {
    return border.width;
}

function nonIgnoredElement(nodeContainer) {
    return (nodeContainer.node.nodeType !== Node.ELEMENT_NODE || ["SCRIPT", "HEAD", "TITLE", "OBJECT", "BR", "OPTION"].indexOf(nodeContainer.node.nodeName) === -1);
}

function flatten(arrays) {
    return [].concat.apply([], arrays);
}

function stripQuotes(content) {
    var first = content.substr(0, 1);
    return (first === content.substr(content.length - 1) && first.match(/'|"/)) ? content.substr(1, content.length - 2) : content;
}

function getWords(characters) {
    var words = [], i = 0, onWordBoundary = false, word;
    while(characters.length) {
        if (isWordBoundary(characters[i]) === onWordBoundary) {
            word = characters.splice(0, i);
            if (word.length) {
                words.push(punycode.ucs2.encode(word));
            }
            onWordBoundary =! onWordBoundary;
            i = 0;
        } else {
            i++;
        }

        if (i >= characters.length) {
            word = characters.splice(0, i);
            if (word.length) {
                words.push(punycode.ucs2.encode(word));
            }
        }
    }
    return words;
}

function isWordBoundary(characterCode) {
    return [
        32, // <space>
        13, // \r
        10, // \n
        9, // \t
        45 // -
    ].indexOf(characterCode) !== -1;
}

function hasUnicode(string) {
    return (/[^\u0000-\u00ff]/).test(string);
}

module.exports = NodeParser;

},{"./color":3,"./fontmetrics":7,"./log":13,"./nodecontainer":14,"./pseudoelementcontainer":18,"./stackingcontext":21,"./textcontainer":25,"./utils":26,"punycode":1}],16:[function(_dereq_,module,exports){
var XHR = _dereq_('./xhr');
var utils = _dereq_('./utils');
var log = _dereq_('./log');
var createWindowClone = _dereq_('./clone');
var decode64 = utils.decode64;

function Proxy(src, proxyUrl, document) {
    var supportsCORS = ('withCredentials' in new XMLHttpRequest());
    if (!proxyUrl) {
        return Promise.reject("No proxy configured");
    }
    var callback = createCallback(supportsCORS);
    var url = createProxyUrl(proxyUrl, src, callback);

    return supportsCORS ? XHR(url) : (jsonp(document, url, callback).then(function(response) {
        return decode64(response.content);
    }));
}
var proxyCount = 0;

function ProxyURL(src, proxyUrl, document) {
    var supportsCORSImage = ('crossOrigin' in new Image());
    var callback = createCallback(supportsCORSImage);
    var url = createProxyUrl(proxyUrl, src, callback);
    return (supportsCORSImage ? Promise.resolve(url) : jsonp(document, url, callback).then(function(response) {
        return "data:" + response.type + ";base64," + response.content;
    }));
}

function jsonp(document, url, callback) {
    return new Promise(function(resolve, reject) {
        var s = document.createElement("script");
        var cleanup = function() {
            delete window.html2canvas.proxy[callback];
            document.body.removeChild(s);
        };
        window.html2canvas.proxy[callback] = function(response) {
            cleanup();
            resolve(response);
        };
        s.src = url;
        s.onerror = function(e) {
            cleanup();
            reject(e);
        };
        document.body.appendChild(s);
    });
}

function createCallback(useCORS) {
    return !useCORS ? "html2canvas_" + Date.now() + "_" + (++proxyCount) + "_" + Math.round(Math.random() * 100000) : "";
}

function createProxyUrl(proxyUrl, src, callback) {
    return proxyUrl + "?url=" + encodeURIComponent(src) + (callback.length ? "&callback=html2canvas.proxy." + callback : "");
}

function documentFromHTML(src) {
    return function(html) {
        var parser = new DOMParser(), doc;
        try {
            doc = parser.parseFromString(html, "text/html");
        } catch(e) {
            log("DOMParser not supported, falling back to createHTMLDocument");
            doc = document.implementation.createHTMLDocument("");
            try {
                doc.open();
                doc.write(html);
                doc.close();
            } catch(ee) {
                log("createHTMLDocument write not supported, falling back to document.body.innerHTML");
                doc.body.innerHTML = html; // ie9 doesnt support writing to documentElement
            }
        }

        var b = doc.querySelector("base");
        if (!b || !b.href.host) {
            var base = doc.createElement("base");
            base.href = src;
            doc.head.insertBefore(base, doc.head.firstChild);
        }

        return doc;
    };
}

function loadUrlDocument(src, proxy, document, width, height, options) {
    return new Proxy(src, proxy, window.document).then(documentFromHTML(src)).then(function(doc) {
        return createWindowClone(doc, document, width, height, options, 0, 0);
    });
}

exports.Proxy = Proxy;
exports.ProxyURL = ProxyURL;
exports.loadUrlDocument = loadUrlDocument;

},{"./clone":2,"./log":13,"./utils":26,"./xhr":28}],17:[function(_dereq_,module,exports){
var ProxyURL = _dereq_('./proxy').ProxyURL;

function ProxyImageContainer(src, proxy) {
    var link = document.createElement("a");
    link.href = src;
    src = link.href;
    this.src = src;
    this.image = new Image();
    var self = this;
    this.promise = new Promise(function(resolve, reject) {
        self.image.crossOrigin = "Anonymous";
        self.image.onload = resolve;
        self.image.onerror = reject;

        new ProxyURL(src, proxy, document).then(function(url) {
            self.image.src = url;
        })['catch'](reject);
    });
}

module.exports = ProxyImageContainer;

},{"./proxy":16}],18:[function(_dereq_,module,exports){
var NodeContainer = _dereq_('./nodecontainer');

function PseudoElementContainer(node, parent, type) {
    NodeContainer.call(this, node, parent);
    this.isPseudoElement = true;
    this.before = type === ":before";
}

PseudoElementContainer.prototype.cloneTo = function(stack) {
    PseudoElementContainer.prototype.cloneTo.call(this, stack);
    stack.isPseudoElement = true;
    stack.before = this.before;
};

PseudoElementContainer.prototype = Object.create(NodeContainer.prototype);

PseudoElementContainer.prototype.appendToDOM = function() {
    if (this.before) {
        this.parent.node.insertBefore(this.node, this.parent.node.firstChild);
    } else {
        this.parent.node.appendChild(this.node);
    }
    this.parent.node.className += " " + this.getHideClass();
};

PseudoElementContainer.prototype.cleanDOM = function() {
    this.node.parentNode.removeChild(this.node);
    this.parent.node.className = this.parent.node.className.replace(this.getHideClass(), "");
};

PseudoElementContainer.prototype.getHideClass = function() {
    return this["PSEUDO_HIDE_ELEMENT_CLASS_" + (this.before ? "BEFORE" : "AFTER")];
};

PseudoElementContainer.prototype.PSEUDO_HIDE_ELEMENT_CLASS_BEFORE = "___html2canvas___pseudoelement_before";
PseudoElementContainer.prototype.PSEUDO_HIDE_ELEMENT_CLASS_AFTER = "___html2canvas___pseudoelement_after";

module.exports = PseudoElementContainer;

},{"./nodecontainer":14}],19:[function(_dereq_,module,exports){
var log = _dereq_('./log');

function Renderer(width, height, images, options, document) {
    this.width = width;
    this.height = height;
    this.images = images;
    this.options = options;
    this.document = document;
}

Renderer.prototype.renderImage = function(container, bounds, borderData, imageContainer) {
    var paddingLeft = container.cssInt('paddingLeft'),
        paddingTop = container.cssInt('paddingTop'),
        paddingRight = container.cssInt('paddingRight'),
        paddingBottom = container.cssInt('paddingBottom'),
        borders = borderData.borders;

    var width = bounds.width - (borders[1].width + borders[3].width + paddingLeft + paddingRight);
    var height = bounds.height - (borders[0].width + borders[2].width + paddingTop + paddingBottom);
    this.drawImage(
        imageContainer,
        0,
        0,
        imageContainer.image.width || width,
        imageContainer.image.height || height,
        bounds.left + paddingLeft + borders[3].width,
        bounds.top + paddingTop + borders[0].width,
        width,
        height
    );
};

Renderer.prototype.renderBackground = function(container, bounds, borderData) {
    if (bounds.height > 0 && bounds.width > 0) {
        this.renderBackgroundColor(container, bounds);
        this.renderBackgroundImage(container, bounds, borderData);
    }
};

Renderer.prototype.renderBackgroundColor = function(container, bounds) {
    var color = container.color("backgroundColor");
    if (!color.isTransparent()) {
        this.rectangle(bounds.left, bounds.top, bounds.width, bounds.height, color);
    }
};

Renderer.prototype.renderBorders = function(borders) {
    borders.forEach(this.renderBorder, this);
};

Renderer.prototype.renderBorder = function(data) {
    if (!data.color.isTransparent() && data.args !== null) {
        this.drawShape(data.args, data.color);
    }
};

Renderer.prototype.renderBackgroundImage = function(container, bounds, borderData) {
    var backgroundImages = container.parseBackgroundImages();
    backgroundImages.reverse().forEach(function(backgroundImage, index, arr) {
        switch(backgroundImage.method) {
        case "url":
            var image = this.images.get(backgroundImage.args[0]);
            if (image) {
                this.renderBackgroundRepeating(container, bounds, image, arr.length - (index+1), borderData);
            } else {
                log("Error loading background-image", backgroundImage.args[0]);
            }
            break;
        case "linear-gradient":
        case "gradient":
            var gradientImage = this.images.get(backgroundImage.value);
            if (gradientImage) {
                this.renderBackgroundGradient(gradientImage, bounds, borderData);
            } else {
                log("Error loading background-image", backgroundImage.args[0]);
            }
            break;
        case "none":
            break;
        default:
            log("Unknown background-image type", backgroundImage.args[0]);
        }
    }, this);
};

Renderer.prototype.renderBackgroundRepeating = function(container, bounds, imageContainer, index, borderData) {
    var size = container.parseBackgroundSize(bounds, imageContainer.image, index);
    var position = container.parseBackgroundPosition(bounds, imageContainer.image, index, size);
    var repeat = container.parseBackgroundRepeat(index);
    switch (repeat) {
    case "repeat-x":
    case "repeat no-repeat":
        this.backgroundRepeatShape(imageContainer, position, size, bounds, bounds.left + borderData[3], bounds.top + position.top + borderData[0], 99999, size.height, borderData);
        break;
    case "repeat-y":
    case "no-repeat repeat":
        this.backgroundRepeatShape(imageContainer, position, size, bounds, bounds.left + position.left + borderData[3], bounds.top + borderData[0], size.width, 99999, borderData);
        break;
    case "no-repeat":
        this.backgroundRepeatShape(imageContainer, position, size, bounds, bounds.left + position.left + borderData[3], bounds.top + position.top + borderData[0], size.width, size.height, borderData);
        break;
    default:
        this.renderBackgroundRepeat(imageContainer, position, size, {top: bounds.top, left: bounds.left}, borderData[3], borderData[0]);
        break;
    }
};

module.exports = Renderer;

},{"./log":13}],20:[function(_dereq_,module,exports){
var Renderer = _dereq_('../renderer');
var LinearGradientContainer = _dereq_('../lineargradientcontainer');
var log = _dereq_('../log');

function CanvasRenderer(width, height) {
    Renderer.apply(this, arguments);
    this.canvas = this.options.canvas || this.document.createElement("canvas");
    if (!this.options.canvas) {
        this.canvas.width = width;
        this.canvas.height = height;
    }
    this.ctx = this.canvas.getContext("2d");
    this.taintCtx = this.document.createElement("canvas").getContext("2d");
    this.ctx.textBaseline = "bottom";
    this.variables = {};
    log("Initialized CanvasRenderer with size", width, "x", height);
}

CanvasRenderer.prototype = Object.create(Renderer.prototype);

CanvasRenderer.prototype.setFillStyle = function(fillStyle) {
    this.ctx.fillStyle = typeof(fillStyle) === "object" && !!fillStyle.isColor ? fillStyle.toString() : fillStyle;
    return this.ctx;
};

CanvasRenderer.prototype.rectangle = function(left, top, width, height, color) {
    this.setFillStyle(color).fillRect(left, top, width, height);
};

CanvasRenderer.prototype.circle = function(left, top, size, color) {
    this.setFillStyle(color);
    this.ctx.beginPath();
    this.ctx.arc(left + size / 2, top + size / 2, size / 2, 0, Math.PI*2, true);
    this.ctx.closePath();
    this.ctx.fill();
};

CanvasRenderer.prototype.circleStroke = function(left, top, size, color, stroke, strokeColor) {
    this.circle(left, top, size, color);
    this.ctx.strokeStyle = strokeColor.toString();
    this.ctx.stroke();
};

CanvasRenderer.prototype.drawShape = function(shape, color) {
    this.shape(shape);
    this.setFillStyle(color).fill();
};

CanvasRenderer.prototype.taints = function(imageContainer) {
    if (imageContainer.tainted === null) {
        this.taintCtx.drawImage(imageContainer.image, 0, 0);
        try {
            this.taintCtx.getImageData(0, 0, 1, 1);
            imageContainer.tainted = false;
        } catch(e) {
            this.taintCtx = document.createElement("canvas").getContext("2d");
            imageContainer.tainted = true;
        }
    }

    return imageContainer.tainted;
};

CanvasRenderer.prototype.drawImage = function(imageContainer, sx, sy, sw, sh, dx, dy, dw, dh) {
    if (!this.taints(imageContainer) || this.options.allowTaint) {
        this.ctx.drawImage(imageContainer.image, sx, sy, sw, sh, dx, dy, dw, dh);
    }
};

CanvasRenderer.prototype.clip = function(shapes, callback, context) {
    this.ctx.save();
    shapes.filter(hasEntries).forEach(function(shape) {
        this.shape(shape).clip();
    }, this);
    callback.call(context);
    this.ctx.restore();
};

CanvasRenderer.prototype.shape = function(shape) {
    this.ctx.beginPath();
    shape.forEach(function(point, index) {
        if (point[0] === "rect") {
            this.ctx.rect.apply(this.ctx, point.slice(1));
        } else {
            this.ctx[(index === 0) ? "moveTo" : point[0] + "To" ].apply(this.ctx, point.slice(1));
        }
    }, this);
    this.ctx.closePath();
    return this.ctx;
};

CanvasRenderer.prototype.font = function(color, style, variant, weight, size, family) {
    this.setFillStyle(color).font = [style, variant, weight, size, family].join(" ").split(",")[0];
};

CanvasRenderer.prototype.fontShadow = function(color, offsetX, offsetY, blur) {
    this.setVariable("shadowColor", color.toString())
        .setVariable("shadowOffsetY", offsetX)
        .setVariable("shadowOffsetX", offsetY)
        .setVariable("shadowBlur", blur);
};

CanvasRenderer.prototype.clearShadow = function() {
    this.setVariable("shadowColor", "rgba(0,0,0,0)");
};

CanvasRenderer.prototype.setOpacity = function(opacity) {
    this.ctx.globalAlpha = opacity;
};

CanvasRenderer.prototype.setTransform = function(transform) {
    this.ctx.translate(transform.origin[0], transform.origin[1]);
    this.ctx.transform.apply(this.ctx, transform.matrix);
    this.ctx.translate(-transform.origin[0], -transform.origin[1]);
};

CanvasRenderer.prototype.setVariable = function(property, value) {
    if (this.variables[property] !== value) {
        this.variables[property] = this.ctx[property] = value;
    }

    return this;
};

CanvasRenderer.prototype.text = function(text, left, bottom) {
    this.ctx.fillText(text, left, bottom);
};

CanvasRenderer.prototype.backgroundRepeatShape = function(imageContainer, backgroundPosition, size, bounds, left, top, width, height, borderData) {
    var shape = [
        ["line", Math.round(left), Math.round(top)],
        ["line", Math.round(left + width), Math.round(top)],
        ["line", Math.round(left + width), Math.round(height + top)],
        ["line", Math.round(left), Math.round(height + top)]
    ];
    this.clip([shape], function() {
        this.renderBackgroundRepeat(imageContainer, backgroundPosition, size, bounds, borderData[3], borderData[0]);
    }, this);
};

CanvasRenderer.prototype.renderBackgroundRepeat = function(imageContainer, backgroundPosition, size, bounds, borderLeft, borderTop) {
    var offsetX = Math.round(bounds.left + backgroundPosition.left + borderLeft), offsetY = Math.round(bounds.top + backgroundPosition.top + borderTop);
    this.setFillStyle(this.ctx.createPattern(this.resizeImage(imageContainer, size), "repeat"));
    this.ctx.translate(offsetX, offsetY);
    this.ctx.fill();
    this.ctx.translate(-offsetX, -offsetY);
};

CanvasRenderer.prototype.renderBackgroundGradient = function(gradientImage, bounds) {
    if (gradientImage instanceof LinearGradientContainer) {
        var gradient = this.ctx.createLinearGradient(
            bounds.left + bounds.width * gradientImage.x0,
            bounds.top + bounds.height * gradientImage.y0,
            bounds.left +  bounds.width * gradientImage.x1,
            bounds.top +  bounds.height * gradientImage.y1);
        gradientImage.colorStops.forEach(function(colorStop) {
            gradient.addColorStop(colorStop.stop, colorStop.color.toString());
        });
        this.rectangle(bounds.left, bounds.top, bounds.width, bounds.height, gradient);
    }
};

CanvasRenderer.prototype.resizeImage = function(imageContainer, size) {
    var image = imageContainer.image;
    if(image.width === size.width && image.height === size.height) {
        return image;
    }

    var ctx, canvas = document.createElement('canvas');
    canvas.width = size.width;
    canvas.height = size.height;
    ctx = canvas.getContext("2d");
    ctx.drawImage(image, 0, 0, image.width, image.height, 0, 0, size.width, size.height );
    return canvas;
};

function hasEntries(array) {
    return array.length > 0;
}

module.exports = CanvasRenderer;

},{"../lineargradientcontainer":12,"../log":13,"../renderer":19}],21:[function(_dereq_,module,exports){
var NodeContainer = _dereq_('./nodecontainer');

function StackingContext(hasOwnStacking, opacity, element, parent) {
    NodeContainer.call(this, element, parent);
    this.ownStacking = hasOwnStacking;
    this.contexts = [];
    this.children = [];
    this.opacity = (this.parent ? this.parent.stack.opacity : 1) * opacity;
}

StackingContext.prototype = Object.create(NodeContainer.prototype);

StackingContext.prototype.getParentStack = function(context) {
    var parentStack = (this.parent) ? this.parent.stack : null;
    return parentStack ? (parentStack.ownStacking ? parentStack : parentStack.getParentStack(context)) : context.stack;
};

module.exports = StackingContext;

},{"./nodecontainer":14}],22:[function(_dereq_,module,exports){
function Support(document) {
    this.rangeBounds = this.testRangeBounds(document);
    this.cors = this.testCORS();
    this.svg = this.testSVG();
}

Support.prototype.testRangeBounds = function(document) {
    var range, testElement, rangeBounds, rangeHeight, support = false;

    if (document.createRange) {
        range = document.createRange();
        if (range.getBoundingClientRect) {
            testElement = document.createElement('boundtest');
            testElement.style.height = "123px";
            testElement.style.display = "block";
            document.body.appendChild(testElement);

            range.selectNode(testElement);
            rangeBounds = range.getBoundingClientRect();
            rangeHeight = rangeBounds.height;

            if (rangeHeight === 123) {
                support = true;
            }
            document.body.removeChild(testElement);
        }
    }

    return support;
};

Support.prototype.testCORS = function() {
    return typeof((new Image()).crossOrigin) !== "undefined";
};

Support.prototype.testSVG = function() {
    var img = new Image();
    var canvas = document.createElement("canvas");
    var ctx =  canvas.getContext("2d");
    img.src = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'></svg>";

    try {
        ctx.drawImage(img, 0, 0);
        canvas.toDataURL();
    } catch(e) {
        return false;
    }
    return true;
};

module.exports = Support;

},{}],23:[function(_dereq_,module,exports){
var XHR = _dereq_('./xhr');
var decode64 = _dereq_('./utils').decode64;

function SVGContainer(src) {
    this.src = src;
    this.image = null;
    var self = this;

    this.promise = this.hasFabric().then(function() {
        return (self.isInline(src) ? Promise.resolve(self.inlineFormatting(src)) : XHR(src));
    }).then(function(svg) {
        return new Promise(function(resolve) {
            window.html2canvas.svg.fabric.loadSVGFromString(svg, self.createCanvas.call(self, resolve));
        });
    });
}

SVGContainer.prototype.hasFabric = function() {
    return !window.html2canvas.svg || !window.html2canvas.svg.fabric ? Promise.reject(new Error("html2canvas.svg.js is not loaded, cannot render svg")) : Promise.resolve();
};

SVGContainer.prototype.inlineFormatting = function(src) {
    return (/^data:image\/svg\+xml;base64,/.test(src)) ? this.decode64(this.removeContentType(src)) : this.removeContentType(src);
};

SVGContainer.prototype.removeContentType = function(src) {
    return src.replace(/^data:image\/svg\+xml(;base64)?,/,'');
};

SVGContainer.prototype.isInline = function(src) {
    return (/^data:image\/svg\+xml/i.test(src));
};

SVGContainer.prototype.createCanvas = function(resolve) {
    var self = this;
    return function (objects, options) {
        var canvas = new window.html2canvas.svg.fabric.StaticCanvas('c');
        self.image = canvas.lowerCanvasEl;
        canvas
            .setWidth(options.width)
            .setHeight(options.height)
            .add(window.html2canvas.svg.fabric.util.groupSVGElements(objects, options))
            .renderAll();
        resolve(canvas.lowerCanvasEl);
    };
};

SVGContainer.prototype.decode64 = function(str) {
    return (typeof(window.atob) === "function") ? window.atob(str) : decode64(str);
};

module.exports = SVGContainer;

},{"./utils":26,"./xhr":28}],24:[function(_dereq_,module,exports){
var SVGContainer = _dereq_('./svgcontainer');

function SVGNodeContainer(node, _native) {
    this.src = node;
    this.image = null;
    var self = this;

    this.promise = _native ? new Promise(function(resolve, reject) {
        self.image = new Image();
        self.image.onload = resolve;
        self.image.onerror = reject;
        self.image.src = "data:image/svg+xml," + (new XMLSerializer()).serializeToString(node);
        if (self.image.complete === true) {
            resolve(self.image);
        }
    }) : this.hasFabric().then(function() {
        return new Promise(function(resolve) {
            window.html2canvas.svg.fabric.parseSVGDocument(node, self.createCanvas.call(self, resolve));
        });
    });
}

SVGNodeContainer.prototype = Object.create(SVGContainer.prototype);

module.exports = SVGNodeContainer;

},{"./svgcontainer":23}],25:[function(_dereq_,module,exports){
var NodeContainer = _dereq_('./nodecontainer');

function TextContainer(node, parent) {
    NodeContainer.call(this, node, parent);
}

TextContainer.prototype = Object.create(NodeContainer.prototype);

TextContainer.prototype.applyTextTransform = function() {
    this.node.data = this.transform(this.parent.css("textTransform"));
};

TextContainer.prototype.transform = function(transform) {
    var text = this.node.data;
    switch(transform){
        case "lowercase":
            return text.toLowerCase();
        case "capitalize":
            return text.replace(/(^|\s|:|-|\(|\))([a-z])/g, capitalize);
        case "uppercase":
            return text.toUpperCase();
        default:
            return text;
    }
};

function capitalize(m, p1, p2) {
    if (m.length > 0) {
        return p1 + p2.toUpperCase();
    }
}

module.exports = TextContainer;

},{"./nodecontainer":14}],26:[function(_dereq_,module,exports){
exports.smallImage = function smallImage() {
    return "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
};

exports.bind = function(callback, context) {
    return function() {
        return callback.apply(context, arguments);
    };
};

/*
 * base64-arraybuffer
 * https://github.com/niklasvh/base64-arraybuffer
 *
 * Copyright (c) 2012 Niklas von Hertzen
 * Licensed under the MIT license.
 */

exports.decode64 = function(base64) {
    var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    var len = base64.length, i, encoded1, encoded2, encoded3, encoded4, byte1, byte2, byte3;

    var output = "";

    for (i = 0; i < len; i+=4) {
        encoded1 = chars.indexOf(base64[i]);
        encoded2 = chars.indexOf(base64[i+1]);
        encoded3 = chars.indexOf(base64[i+2]);
        encoded4 = chars.indexOf(base64[i+3]);

        byte1 = (encoded1 << 2) | (encoded2 >> 4);
        byte2 = ((encoded2 & 15) << 4) | (encoded3 >> 2);
        byte3 = ((encoded3 & 3) << 6) | encoded4;
        if (encoded3 === 64) {
            output += String.fromCharCode(byte1);
        } else if (encoded4 === 64 || encoded4 === -1) {
            output += String.fromCharCode(byte1, byte2);
        } else{
            output += String.fromCharCode(byte1, byte2, byte3);
        }
    }

    return output;
};

exports.getBounds = function(node) {
    if (node.getBoundingClientRect) {
        var clientRect = node.getBoundingClientRect();
        var width = node.offsetWidth == null ? clientRect.width : node.offsetWidth;
        return {
            top: clientRect.top,
            bottom: clientRect.bottom || (clientRect.top + clientRect.height),
            right: clientRect.left + width,
            left: clientRect.left,
            width:  width,
            height: node.offsetHeight == null ? clientRect.height : node.offsetHeight
        };
    }
    return {};
};

exports.offsetBounds = function(node) {
    var parent = node.offsetParent ? exports.offsetBounds(node.offsetParent) : {top: 0, left: 0};

    return {
        top: node.offsetTop + parent.top,
        bottom: node.offsetTop + node.offsetHeight + parent.top,
        right: node.offsetLeft + parent.left + node.offsetWidth,
        left: node.offsetLeft + parent.left,
        width: node.offsetWidth,
        height: node.offsetHeight
    };
};

exports.parseBackgrounds = function(backgroundImage) {
    var whitespace = ' \r\n\t',
        method, definition, prefix, prefix_i, block, results = [],
        mode = 0, numParen = 0, quote, args;
    var appendResult = function() {
        if(method) {
            if (definition.substr(0, 1) === '"') {
                definition = definition.substr(1, definition.length - 2);
            }
            if (definition) {
                args.push(definition);
            }
            if (method.substr(0, 1) === '-' && (prefix_i = method.indexOf('-', 1 ) + 1) > 0) {
                prefix = method.substr(0, prefix_i);
                method = method.substr(prefix_i);
            }
            results.push({
                prefix: prefix,
                method: method.toLowerCase(),
                value: block,
                args: args,
                image: null
            });
        }
        args = [];
        method = prefix = definition = block = '';
    };
    args = [];
    method = prefix = definition = block = '';
    backgroundImage.split("").forEach(function(c) {
        if (mode === 0 && whitespace.indexOf(c) > -1) {
            return;
        }
        switch(c) {
        case '"':
            if(!quote) {
                quote = c;
            } else if(quote === c) {
                quote = null;
            }
            break;
        case '(':
            if(quote) {
                break;
            } else if(mode === 0) {
                mode = 1;
                block += c;
                return;
            } else {
                numParen++;
            }
            break;
        case ')':
            if (quote) {
                break;
            } else if(mode === 1) {
                if(numParen === 0) {
                    mode = 0;
                    block += c;
                    appendResult();
                    return;
                } else {
                    numParen--;
                }
            }
            break;

        case ',':
            if (quote) {
                break;
            } else if(mode === 0) {
                appendResult();
                return;
            } else if (mode === 1) {
                if (numParen === 0 && !method.match(/^url$/i)) {
                    args.push(definition);
                    definition = '';
                    block += c;
                    return;
                }
            }
            break;
        }

        block += c;
        if (mode === 0) {
            method += c;
        } else {
            definition += c;
        }
    });

    appendResult();
    return results;
};

},{}],27:[function(_dereq_,module,exports){
var GradientContainer = _dereq_('./gradientcontainer');

function WebkitGradientContainer(imageData) {
    GradientContainer.apply(this, arguments);
    this.type = imageData.args[0] === "linear" ? GradientContainer.TYPES.LINEAR : GradientContainer.TYPES.RADIAL;
}

WebkitGradientContainer.prototype = Object.create(GradientContainer.prototype);

module.exports = WebkitGradientContainer;

},{"./gradientcontainer":9}],28:[function(_dereq_,module,exports){
function XHR(url) {
    return new Promise(function(resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url);

        xhr.onload = function() {
            if (xhr.status === 200) {
                resolve(xhr.responseText);
            } else {
                reject(new Error(xhr.statusText));
            }
        };

        xhr.onerror = function() {
            reject(new Error("Network Error"));
        };

        xhr.send();
    });
}

module.exports = XHR;

},{}]},{},[4])(4)
});

//Champ de saisie RWD
//
//Init dès le DOMContentLoaded
$(window).on("DOMContentLoaded.wb.saisie.rwd",function() 
{
	function jqTrouveLibelle(jqConteneur)
	{
		return jqConteneur.children().eq(0).find("td").add(jqConteneur.children().eq(0)).last();//le plus profond
	}
	function jqTrouveSaisie(jqConteneur)
	{
		var jqChampSaisie =  jqConteneur.children().eq(1).find("input,textarea,iframe").filter(function(){ return this.type !== "hidden" && this.type !== "checkbox" && this.type !== "radio";});
        var jqWrapJetons = jqChampSaisie.siblings(".wbSaisieJetonsWrap");
		if (jqWrapJetons.length)
		{
			return jqWrapJetons.find("input").last();
		}
		return jqChampSaisie.first();
	}
	function jqTrouveSaisiePaddingDepuisSaisie(jqChampSaisie)
	{
		var bSaisieJeton  = jqChampSaisie[0].wbSaisieJetonsInitDejaFait;
		if (bSaisieJeton)
		{
			return jqChampSaisie.siblings(".wbSaisieJetonsWrap");
		}
		return jqChampSaisie;
	}

	function bindLibChampEtat()
	{
		$(".wbLibChamp").each(function(){
			if (this.wbSaisieRwdBindDejaFait) return;
			this.wbSaisieRwdBindDejaFait=true;

			var jqConteneur = $(this);		
			var jqChampLibelle = jqTrouveLibelle(jqConteneur);
	
			function initChamp()
			{
				var jqChampSaisie = jqTrouveSaisie(jqConteneur);
				if (!jqChampSaisie || !jqChampSaisie.length)
				{
					jqConteneur.one("trigger.wb.saisie.rwd.riche",function(){					
						initChamp();
					});
					return;
				}
				if (jqChampSaisie.data("wbSaisieJetons") && !jqChampSaisie[0].wbSaisieJetonsInitDejaFait)
				{
					jqConteneur.one("trigger.wb.saisie.jeton.postinit",function(){					
						initChamp();
					});
					return;					
				}				

				var bSaisieJeton  = jqChampSaisie[0].wbSaisieJetonsInitDejaFait;
				var jqChampAvecPadding = jqTrouveSaisiePaddingDepuisSaisie(jqChampSaisie);
				var bEstSaisieRicheIFrame = jqChampSaisie[0].tagName.toLowerCase()==="iframe";
				//cas valeur affichée en valign top par le navigateur 
				var bEstValeurDessineeValignTop = jqChampSaisie[0].tagName.toLowerCase()==="textarea" || (bSaisieJeton&&jqChampAvecPadding.hasClass("wbSaisieJetonsWrapVertical"));
				var bEstEnHautDeSaisie = undefined;
				var nPaddingTopActuel = undefined;
				var nHauteurLib = undefined;
				var nMargeTop = undefined;
				var bAvecPaddingForce = false;

				var jqConteneurEtLibelleEtSaisie = jqConteneur.add(jqChampLibelle).add(jqChampSaisie);


                $(window).on("mouseup.wb.saisie.rwd trigger.wb.saisie.rwd.mouseup",function(){
                    jqConteneurEtLibelleEtSaisie.removeClass("wbActif");                    
                });

				//TODO JETON : appliquer les classes d'états sur le div ?
				// //applique les classe d'états sur le div de saisie à jetons
				// if (jqChampSaisie.prev().hasClass("bootstrap-tagsinput"))
				// {
				// 	jqConteneurEtLibelleEtSaisie=jqConteneurEtLibelleEtSaisie.add(jqChampSaisie.prev());
				// }

				var jqCible = (bEstSaisieRicheIFrame
				?	$(bIEAvec11 ? jqChampSaisie[0].contentDocument.body : jqChampSaisie[0].contentDocument)				
				: jqChampSaisie
				)

                //permet de relancer la position de libellé selon la valeur init à partir du conteneur (pratique pour la saisie riche)
                jqConteneur.on("trigger.wb.saisie.rwd.valeurinitDepuisConteneur",function(){ jqCible.trigger("trigger.wb.saisie.rwd.valeurinit"); });

				var fMajDimensionLibfunction = function()
				{
					//calcul sur un clone, plus discret
					var jqClone = jqConteneur.clone(false,false);
					jqClone.css({ visibility : "hidden", position : "fixed"});
					var jqCloneConteneurEtLibelleEtSaisie = jqClone.add(jqClone.children());						
					jqCloneConteneurEtLibelleEtSaisie.css("transition","none").addClass("wbFocus");
					$(document.body).append(jqClone);
					//si top:0 sur un position:non static et  margintop>=0 
					bEstEnHautDeSaisie = (parseInt(jqClone.children().first().css("top")) === 0);								
					//force une marge pour éviter le chevauchement
					nPaddingTopActuel = parseInt(jqTrouveSaisiePaddingDepuisSaisie(jqTrouveSaisie(jqClone)).css("paddingTop"));
					nHauteurLib = jqTrouveLibelle(jqClone).height();//tient compte de la transform	
					nMargeTop = parseInt(jqClone.children().first().css("marginTop"));					
					jqCloneConteneurEtLibelleEtSaisie.remove();	
				};

                var fMajDimensionLibfunctionSibesoin = function()
                {
                    if (bEstValeurDessineeValignTop && bEstEnHautDeSaisie===undefined)//1er focus 
                    {
                        fMajDimensionLibfunction();
                        //recalculer que à chaque changement de tranche
                        //TODO faire le recalcul de façon asynchrone
                        $(window).one("trigger.wb.rwd.tranche.changement",fMajDimensionLibfunction);            
                    }
                };

                var fAppliquePaddingForce = function(){

                    bAvecPaddingForce = bAvecPaddingForce || false;

                    //si aucun paddign forcé et qu'il faudrait peut être en mettre un
                    if (!bAvecPaddingForce && bEstValeurDessineeValignTop && bEstEnHautDeSaisie)
                    {
                        //si le padding du client n'est pas suffisant pour le libellé
                        if (nPaddingTopActuel<(nHauteurLib+nMargeTop))
                        {
                            //force un padding pour éviter le chevauchement
                            jqChampAvecPadding.css("paddingTop",(nHauteurLib+nMargeTop) + nPaddingTopActuel);
                            bAvecPaddingForce = true;
                        }                    
                    }
                };

				jqCible.on((bEstSaisieRicheIFrame?"click":"focus")+".wb.saisie.rwd trigger.wb.saisie.rwd.focus",function(){				

                    fMajDimensionLibfunctionSibesoin();
					
					jqConteneurEtLibelleEtSaisie.addClass("wbFocus");

                    fAppliquePaddingForce();

					if (bEstSaisieRicheIFrame)
					{
						$(document).one("click.wb.saisie.rwd.blur",function()
						{
							jqConteneurEtLibelleEtSaisie.removeClass("wbFocus");
						});
					}
				})
				.on("blur.wb.saisie.rwd trigger.wb.saisie.rwd.blur",function(){
					jqConteneurEtLibelleEtSaisie.removeClass("wbFocus");	
					//s'il y a un padding forcé mais que la saisie est désormais vide
					if (bAvecPaddingForce && !jqConteneurEtLibelleEtSaisie.hasClass("wbSaisieNonVide"))
					{
						//retire la marge qui évite le chevauchement	
						jqChampAvecPadding.css("paddingTop",nPaddingTopActuel);	
						bAvecPaddingForce=false;				
					}					
				})
				.on("keyup.wb.saisie.rwd trigger.wb.saisie.rwd.keyup change.wb.saisie.rwd trigger.wb.saisie.rwd.valeurinit trigger.wb.saisie.rwd.postaffectation trigger.wb.autocomplete.select.post",function(jqEvent){
					if ( (bEstSaisieRicheIFrame ? (!this.body ? '' : this.body.innerText.trim()) : this.value) )
					{
                        var bInit = (jqEvent.type.toLowerCase()==="trigger");
                        if (bInit) fMajDimensionLibfunctionSibesoin();
                        jqConteneurEtLibelleEtSaisie.addClass("wbSaisieNonVide");
                        if (bInit) fAppliquePaddingForce();
					}
                    else 
					jqConteneurEtLibelleEtSaisie.removeClass("wbSaisieNonVide");	
				})
				.on("mouseenter.wb.saisie.rwd trigger.wb.saisie.rwd.mouseenter", function(){
					jqConteneurEtLibelleEtSaisie.addClass("wbSurvol");
				})
				.on("mouseleave.wb.saisie.rwd trigger.wb.saisie.rwd.mouseleave",function(){
					jqConteneurEtLibelleEtSaisie.removeClass("wbSurvol");
				})
				.on("mousedown.wb.saisie.rwd trigger.wb.saisie.rwd.mousedown",function(){
					jqConteneurEtLibelleEtSaisie.addClass("wbActif");
				})
				.on("mouseup.wb.saisie.rwd trigger.wb.saisie.rwd.mouseup",function(){
					jqConteneurEtLibelleEtSaisie.removeClass("wbActif");	
				})
				.trigger("trigger.wb.saisie.rwd.valeurinit")
				;

			}
			initChamp();
		});
	}

	//cas de ZRAjoute en AJAX, changement de tranche...
	if (window.NSPCS)
	{
		// Notifie aussi de la modification du HTML de la page
		NSPCS.NSUtil.ms_oNotificationsAjoutHTML.AddNotification(bindLibChampEtat);
		NSPCS.NSUtil.ms_oNotificationsFinAJAX.AddNotification(bindLibChampEtat);		
		//NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(bindLibChampEtat);
	}
	//en cas de mise à jour de html par ajax
	if (window["clWDUtil"]!==undefined) 
	{
		if (clWDUtil.m_oNotificationsAjoutHTML)
		{
			clWDUtil.m_oNotificationsAjoutHTML.AddNotification(bindLibChampEtat);
		}
		if (clWDUtil.m_oNotificationsFinAJAX)
		{
			clWDUtil.m_oNotificationsFinAJAX.AddNotification(bindLibChampEtat);
		}
	}		

	//1er appel 
	bindLibChampEtat();
});

// met à jour la visibilité des cellule de champ disposition en fonction de la visibilité de leurs fils 
$(window).on("trigger.wb.rwd.tranche.changement trigger.wb.plan.action.set.fin trigger.wb.disposition.visible.maj",function()
{
	//parcours des champs dispositions
	$($(".wbChampDisposition").get().reverse()).each(function()
	{        
		var jqChampDisposition = $(this);	
		var nNbCellulesInvisibles = 0;
		//parcours des cellules de ce champ disposition
		jqChampDisposition.children()
			.each(function(){
				var domCelluleDisposition = this;
				var jqCelluleDisposition = $(domCelluleDisposition);
				//pas via data-att= car la WDxxxHTML ne peut pas le placer
				//var jqListeFilsDirects = jqCelluleDisposition.find("[data-wbdispositioncell=" + this.id + "]");
				//pas via --var car IE ne le supporte pas
				//var jqListeFilsDirects = $(jqCelluleDisposition[0].querySelectorAll("[style*=data-wbdispositioncell-" + this.id.toLowerCase() + "]"));
				//via content:'data-wb-dispositioncell-A1_1-layout-li';
				var jqListeFilsDirects = $(jqCelluleDisposition[0].querySelectorAll("[style*=data-wbdispositioncell-" + this.id + "],[style*=data-wbdispositioncell-" + this.id.toLowerCase() + "]"));
				//pas de fils direct avec visibilité dynamique ?
				if (jqListeFilsDirects.length==0)
				{
					return;
				}
				var bTousFilsDirectsInvisibles = true;
				jqListeFilsDirects.each(function(index,domFilsDirect)
				{
					var jqFilsDirect = jqListeFilsDirects.eq(index);

					if (jqFilsDirect.hasClass("d-0"))
					{
						//je suis un champ disposition fils direct de cellule d'un champ disposition parent
						//et tous mes fils sont masqués (leur calcul a déjà été fait avant d'arriver ici cf .reverse )
						//donc je suuis masqué 

						//continue
						return true;
					}

				     //lit la visibilité via
				     // - display 
				     // - visible 
				     // - clientWidth pour le cas RWD car s'il est masqué, 
				     // 			//NON  il est descendant d'un display:none et donc son clientWidth est 0 NON
				     //				//MAIS il est descendant d'un visibility:hidden donc son getComputedStyle( domFilsDirect ).visibility=="hidden"
					//if (jqFilsDirect.css("display")==="none" || jqFilsDirect.css("visibility")==="hidden" || domFilsDirect.clientWidth===0)

					if (domFilsDirect.style.display==="none" || domFilsDirect.style.visibility==="hidden")
				    {
						//invisible par ..Visible

						//continue
						return true;
				    }
					else if (getComputedStyle( domFilsDirect ).visibility=="hidden")//(domFilsDirect.clientWidth===0)
					{
						//qui masque ?
						//si c'est la cellulle disposition on ignore 
						if (getComputedStyle( domCelluleDisposition ).visibility!="hidden")
						{
							//masquage par un parent masqué ou lui même via d-0 => une balise du RWD 

							//invisible par RWD

							//continue
							return true;							
						}
					}

					//visible, donc tous ne sont pas invisibles
					bTousFilsDirectsInvisibles=false;
					//break;
					return false;
				});

				if (bTousFilsDirectsInvisibles)
				{
					jqCelluleDisposition.addClass("d-0");
					bToutesCellulesInvisibles=false;
					++nNbCellulesInvisibles;
				}
				else 
				{
					jqCelluleDisposition.removeClass("d-0");
				}
			})	
			;
			//masque le champ disposition à son tour
			// on met/retire la classe sur le ol (note : le champ disposition n'a plus de <table> généré par la WDxxxHTML)
			if (nNbCellulesInvisibles === jqChampDisposition.children().length)
			{
				jqChampDisposition.addClass("d-0");
			}
			else 
			{
				jqChampDisposition.removeClass("d-0");
			}
	});

});


jQuery().ready(function(event)
{
	//Vrai si l'évenement utilise une combinaison des touches de la liste
	function bToucheEnfoncee(keyPressEvent, lookupList, sValeurEnCoursRedef) 
	{
		//coller avec un RC dedans
		if (sValeurEnCoursRedef)
		{
			for(var i=0; i<sValeurEnCoursRedef.length;++ i)
			{
				if (bToucheEnfoncee({
					which : sValeurEnCoursRedef.charCodeAt(i)
				}, lookupList))
					return true;
			}			
		}

        if (keyPressEvent.namespace=="autocomplete.post.select.wb")
            return true;
            
		var found = false;
		$.each(lookupList, function (index, keyCombination) 
		{
			if  
				(
					(typeof (keyCombination) === 'number') 
						? (keyPressEvent.which === keyCombination) 
						: (keyPressEvent.which === keyCombination.charCodeAt(0)) 
				)
			{
				found = true;
				return false;
			}

			if (keyPressEvent.which!==undefined && keyPressEvent.which === keyCombination.which) 
			{
				var alt = !keyCombination.hasOwnProperty('altKey') || keyPressEvent.altKey === keyCombination.altKey,
				shift = !keyCombination.hasOwnProperty('shiftKey') || keyPressEvent.shiftKey === keyCombination.shiftKey,
				ctrl = !keyCombination.hasOwnProperty('ctrlKey') || keyPressEvent.ctrlKey === keyCombination.ctrlKey;
				if (alt && shift && ctrl) 
				{
					found = true;
					return false;
				}
			}
		});
		return found;
	}	
	//Retourne la position du caret dans l'input
	function doGetCaretPosition(domInput) 
	{
		var iCaretPos = 0;
		if (document.selection) //IE < 9
		{
			domInput.focus ();
			var oSel = document.selection.createRange();
			oSel.moveStart ('character', -domInput.value.length);
			iCaretPos = oSel.text.length;
		} 
		else if (domInput.selectionStart || domInput.selectionStart == '0') 
		{
			iCaretPos = domInput.selectionStart;
		}
		return (iCaretPos);
	}


	function compareJeton(oJeton1,oJeton2)
	{
		return getValeurMemoriseeDepuisUnJeton(oJeton1,true) == getValeurMemoriseeDepuisUnJeton(oJeton2,true);
	}
	function compareJetonAvecValeurDejaSansCasseAccent(oJeton1,sValeur)
	{
		return getValeurMemoriseeDepuisUnJeton(oJeton1,true) == sValeur;
	}	
	function getValeurMemoriseeDepuisUnJeton(oDinoJeton,bSansCasseAccent)
	{
		var r = oDinoJeton.m_sValeur || oDinoJeton.m_sLibelleHTML || oDinoJeton.m_sLibelle;
		if (bSansCasseAccent)
		{
			r = wbSansAccent(r).toLowerCase();
		}
		return r;
	}
	function encodeLibelleVersHTML(sLibelle)
	{
		return  jQuery('<div />').text(sLibelle).html();
	}
	function getValeurAfficheeDepuisUnJeton(oDinoJeton,bPourAffichageHTML)
	{
		//par défaut on affiche le libellé HTML en priorité sur le libellé
		var sValeurAffichee = oDinoJeton.m_sLibelleHTML;//sans nettoyer car justement on veut garder le html pour l'interpréter

		if (!sValeurAffichee)
		{
	    	//en l'absence de libellé html on prend le libellé
	    	if (oDinoJeton.m_sLibelle) 
	    	{
	    		//prend simplement le libellé
	    		sValeurAffichee = oDinoJeton.m_sLibelle;
			}
	    	//en l'absence de libellé on prend la valeur
			else if (oDinoJeton.m_sValeur) 
	    	{
	    		//prend la valeur et lui applique le masque
	    		sValeurAffichee = oDinoJeton.m_sValeur;

	    		//TODO JETON convertir la valeur mémorisée vers la valeur affichée selon le type de champ / masque etc.
	    	}

    		//nettoie la valeur à afficher car le libellé mémorisée ne contient pas de HTML à interpréter
    		if (bPourAffichageHTML)
    		{
    			sValeurAffichee = encodeLibelleVersHTML(sValeurAffichee);
    		}
    	}
    	
    	//sans espace pour un jeton plus petit
    	sValeurAffichee = $.trim(sValeurAffichee);

		return sValeurAffichee;
	}

	//IDescriptionChampSaisieJeton::ESENS
	var eHorizontalLargeurFixe = 0
	var eHorizontalLargeurAdapteeAuContenu = 1;
	//cas avec RC automatique
	var eVerticalHauteurFixe = 2;
	var eVerticalHauteurAdapteeAuContenu = 3;

	//vu avec FR 11/09/18 on débranche la multi sélection car ce n'est pas dispo en android ios win32
	var JETON_AUTORISE_MULTISELECTION=false;

	function init(event)
	{
		$("[data-wb-saisie-jetons]").each(function()
		{
			if (this.wbSaisieJetonsInitDejaFait) return;//continue
			this.wbSaisieJetonsInitDejaFait = true;

			//Globales à cette instance de saisie à jetons 

			var jqInput = $(this);
		    var placeholderText = this.hasAttribute('placeholder') ? jqInput.attr('placeholder') : '';
		    var nTailleIndication = Math.max(1, placeholderText.length);
		    //{ style : classe, surchare : classe, planche : classe}
		    var oOptions = $.extend({ sens : eHorizontalLargeurFixe, doublon : false, champ : {style : 'wbSaisieJetonsWrapDefautStyle ' + jqInput[0].id}},jqInput.wbJsonParseAttr("data-wb-saisie-jetons",true)||{});//, 
		    //{m_sJetonListeSeparateur : '',m_bJetonAutoriseDoublon : false,m_tabJetons : [	dino jeton, dino jeton 2,...]}
		    var oDonneesServeurInitiales;
		    //[ ",", ... , RC ]
			var tabSeparateurs;
		    var sType = jqInput.attr("type");
		    var sClasses = jqInput.attr("class");
		    var bEstFocus = jqInput.is(":focus");
		    jqInput
		    	//raz le style d'input pour qu'il soit transparent dans un wrapper qui récupère le stlye initial de cet input
		    	.attr('class',sClasses+ " wbSaisieJetonsInput")
		    	//align l'input avec les jetons
		    	.css({verticalAlign : "top"})
		    	//place le conteneur autour de l'input
		    	.wrap( $('<div class="'+sClasses.replace("wbAutocomplete","").replace("wbAutocompleteFichier","") +' wbSaisieJetonsWrap wbSaisieJetonWrap' + jqInput[0].id + '"></div>'));	    		
		    ;
			//wrap		    
		    var jqContainer = jqInput.parent();

		    //wrap inner
    		jqContainer.wrapInner($('<div class="wbSaisieJetonsInnerWrap"></div>'));
    		var jqInnerWrap = jqContainer.children().last();

		    //input pour écouter les TAB
		    jqContainer.parent().prepend($('<input type="text" style="position:fixed;top:-9999px;left:-9999px;opacity:0">'));
		    var jqListener =jqContainer.parent().children().first();
		    if (jqInput.attr("tabindex"))
	    	{
	    		jqListener.attr("tabindex",jqInput.attr("tabindex")	);
	    		jqInput.attr("tabindex",-1);
	    	}

    		//div absolute pour éviter de pousser le wrapper pour faire le défilement
			if ((oOptions.sens == eHorizontalLargeurFixe)||(oOptions.sens == eVerticalHauteurFixe))
	    	{
	    		jqInnerWrap.css({position:"absolute"});
	    	}
	    	else if (oOptions.sens == eHorizontalLargeurAdapteeAuContenu)
    		{
    			//force largeur au contenu
    			jqContainer.css({width:'auto',display:'table'});
    			jqInnerWrap.css({display:'table-cell',verticalAlign:'middle'});//+valign middle sur jetons?
    		}
    		else if (oOptions.sens == eVerticalHauteurAdapteeAuContenu)
    		{
    			//force largeur au contenu
    			jqContainer.css({height:'auto'});
    		}

	    	//classe de flag pour appliquer le css
		    if ((oOptions.sens == eHorizontalLargeurFixe)||(oOptions.sens == eHorizontalLargeurAdapteeAuContenu))
	    	{
	    		jqContainer.addClass("wbSaisieJetonsWrapHorizontal");
	    	}
	    	else 
	    	{
	    		jqContainer.addClass("wbSaisieJetonsWrapVertical");
	    	}

		    var domChampCache = document.getElementById(jqInput[0].id + '_DATA');

		    //transfère les class et id au wrapper 
		    jqContainer.addClass(oOptions.champ.style).attr("id", jqInput[0].id);            
		    jqInput.removeClass(oOptions.champ.style).attr("id","");

		    //sans croix ?
		    if (!oOptions.croix || oOptions.croix.avec===false)
	    	{
	    		jqContainer.addClass("wbSaisieJetonsSansCroix");	
	    	}
		    //croix par défaut?
	    	else if (!oOptions.croix.chemin)
		    {
		    	jqContainer.addClass("wbSaisieJetonsWrapDefautCroix");
		    }

            //restauration des appels jquery ui fait sur la balise input qui vient d'être wrappée, du coup on perd les init JS faits dessus
            // if (jqInput.data("wbAutocompleteInit"))
            // {
            //     jqInput.removeData("wbAutocompleteInit");
            //     wbAutocompleteInit(jqInput[0]);
            // }

		    //vide le champ de saisie car il sera rempli à partir des données de jetons 
		    jqInput.val('');
		    //récupère les données du serveur
		    chargeDepuisChampCache(true);

		    ecoute();

		    //avait le focus avant l'init ?
		    if (bEstFocus)
	    	{
	    		//remet donc le focus
	    		jqInput.focus();
	    	}
	    	else 
	    	{
	    		onPerteFocus();
	    	}

	    	jqInput.trigger("trigger.wb.saisie.jeton.postinit");

	    	function sauveVersChampCache()
	    	{
	    		//récupère les données depuis le DOM
	    		var oDonneSerialisees = $.extend({},oDonneesServeurInitiales);
	    		oDonneSerialisees.m_tabJetons = [];
		    	jqContainer.find(".wbJeton").each(function(i){
					oDonneSerialisees.m_tabJetons[i] = $(this).data("wbJeton");
		    	});
				domChampCache.value = JSON.stringify(oDonneSerialisees);
	    	}
	    	function chargeDepuisChampCache(bPremierAffichage)
	    	{
	    		var oValeurChampCache = $(domChampCache).wbJsonParseAttr("value",true)||{};

	    		//cas d'init ou rechargement depuis ajax
				if (!bPremierAffichage)
				{
					//pense à bien supprimer les jetons (de la mémoire et du DOM)
					supprimeToutJeton(true);//<-- supprime les infos du champ caché
				}

				oDonneesServeurInitiales = $.extend({ 
					m_sJetonListeSeparateur : ''
				,	m_bJetonAutoriseDoublon : false
				,	m_bJetonSupprimable : true
				,	m_tabJetons : [	]
				}
				,oValeurChampCache);

				//transforme la liste en tableau
				tabSeparateurs = [];
			    for(var iSep=0; oDonneesServeurInitiales.m_sJetonListeSeparateur && iSep<oDonneesServeurInitiales.m_sJetonListeSeparateur.length; ++iSep)
		    	{
					tabSeparateurs.push(oDonneesServeurInitiales.m_sJetonListeSeparateur[iSep]);
		    	}		    
				//force la touche entrée en plus
			    tabSeparateurs.push("\r");
			    tabSeparateurs.push("\n");

    			//maj ihm 
    			majJeton(event,true,true);
				majInput(bPremierAffichage/*conserve la valeur éventuellement mise dans la saisie depuis ajax*/);	    												

				//force le scroll au début au 1er affichage depuis serveur
				if (jqContainer[0].scrollTo)
				{
					jqContainer[0].scrollTo(0,0);
				}				
	    	}

		    function ecoute()
		    {

		    	//API : 
		    	//
		    	//fonctions composantes

				jqInput[0].wbJetonAjoute = function(sValeurMemoriseeOuDinoJeton,sValeurAffichee)
				{
					//syntaxe jeton
					if (typeof sValeurMemoriseeOuDinoJeton == "object")
						return ajouteJeton(sValeurMemoriseeOuDinoJeton);
					//syntaxe chaine
					return ajouteJeton({ m_sLibelle : sValeurAffichee, m_sValeur : sValeurMemoriseeOuDinoJeton });					
				};
				jqInput[0].wbJetonInsere = function(nPosWL,sValeurMemoriseeOuDinoJeton,sValeurAffichee)
				{					
					//syntaxe jeton
					if (typeof sValeurMemoriseeOuDinoJeton == "object")
						return ajouteJeton(sValeurMemoriseeOuDinoJeton,nPosWL);					
					//syntaxe chaine
					return ajouteJeton({ m_sLibelle : sValeurAffichee, m_sValeur : sValeurMemoriseeOuDinoJeton },nPosWL);	
				};
				jqInput[0].wbJetonOccurrence = function()
				{
					return jqContainer.find(".wbJeton").length;
				};
				jqInput[0].wbJetonSupprime = function(sValeurMemoriseeOuIndiceWL)
				{
                    //syntaxe avec valeur mémorisée
                    if (typeof sValeurMemoriseeOuIndiceWL == "string")
                    {
                        var bRetour;
                        var sValeurMemoriseeSansCasseAccent = wbSansAccent(sValeurMemoriseeOuIndiceWL).toLowerCase();                        
                        jqContainer.find(".wbJeton").each(function() 
                        { 
                            var jqJetonI = $(this);
                            if (compareJetonAvecValeurDejaSansCasseAccent(jqJetonI.data("wbJeton"),sValeurMemoriseeSansCasseAccent))
                            {
                                bRetour=supprimeJeton(jqJetonI,true);
                            } 
                        });
                        return bRetour;
                    }
                    //syntaxe avec indice
					return supprimeJeton(jqContainer.find(".wbJeton").eq(sValeurMemoriseeOuIndiceWL-1),true);
				};
				jqInput[0].wbJetonSupprimeTout = function()
				{
					supprimeToutJeton(true);
				};

				//fonctions utilitaires

				jqInput[0].wbGetDinoJeton = function(nIndiceWL)
				{
                    return jqContainer.find(".wbJeton").eq(nIndiceWL-1).data("wbJeton");
				};
                jqInput[0].wbGetJetonValeurMemoriseeChampSaisie = function()
                {
                    return getValeurDepuisTousLesJetons();
                };		
				jqInput[0].wbSetJetonValeurMemoriseeChampSaisie = function(sValeurSepareeParRC)
				{
					jqInput.val(sValeurSepareeParRC);
					//pense à bien supprimer les jetons (de la mémoire et du DOM)
					supprimeToutJeton(true);
					//màj l'IHM					
					majJeton();
		    		//met à jour le champ caché avec les modification faite sur les jetons
					sauveVersChampCache();					
				};							
				jqInput[0].wbGetJetonValeurAfficheeChampSaisie = function()
				{
					var r = getValeurDepuisTousLesJetons(true);
					if (jqInput[0].wbGetJetonSaisieEncours()!="")
					{
						r += "\n";
						r+= jqInput[0].wbGetJetonSaisieEncours();
					}
					return r;
				};				
				jqInput[0].wbJetonChargeDepuisChampCache = function()
				{
					return chargeDepuisChampCache();
				};			
				jqInput[0].wbGetJetonSaisieEncours = function()
				{
					return jqInput[0].type=="hidden" ? "" : jqInput.val();
				};	
				jqInput[0].wbSetJetonSaisieEncours = function(sNouvelleValeurEncours)
				{
					//si pas de focus => erreur 
					if (!jqContainer.hasClass("wbFocus"))
					{
						//erreur 
						return false;
					} 
					//mets à jour la valeur courante
					jqInput.val(sNouvelleValeurEncours);
					majInput();
					return true;
				};	
		    	//bind les event de flèches et de blur qui manipulent les tokens

		    	jqListener.on("focus.wb.saisie.jeton.tab",function(event)
		    	{
		    		//venu ici par TAB 
		    		if (jqInput[0].readOnly)
	    			{
	    				//lecture seule => sélectionne le premier jeton
	    				var jqPremierJeton = jqContainer.find(".wbJeton").first();
	    				if (!jqPremierJeton.length)
    					{
    						//passe au suivant 
    						//TODO savoir s'il ne faudrait pas plutôt passer au précédent si le focus provient d'un SHIFT+TAB, impossible à savoir ici
    						jqListener.emulateTab(/*event.shiftKey ? -1 : */1);

    						event.stopPropagation();
    						event.preventDefault();
    						return;
    					}
	    				selectionneJeton(jqPremierJeton);
	    			}
	    			
	    			//focus dans la saisie 
		    		onPriseFocus();
	    			
		    		jqInput.focus();  
		    	});

		    	//si la touche reste enfoncé on la traite
		    	jqInput.on("keydown.wb.saisie.jeton",onEnfonceTouche);
		    	//si la touche est relâchée on la traite
		    	jqInput.on("keypress.wb.saisie.jeton trigger.wb.autocomplete.select.post",onFrappeTouche);
		    	//cas du c/coller
		    	jqInput.on("paste.wb.saisie.jeton change.wb.saisie.jeton",function(event)
		    	{
					//cas du coller
					//https://stackoverflow.com/questions/2176861/javascript-get-clipboard-data-on-paste-event-cross-browser/6804718#6804718					
					onEnfonceTouche(event);
	    			onFrappeTouche(event,true);
		    	});

		    	//permet de garder la valeur mémorisée prête pour l'envoie du formulaire au serveur
		    	jqInput.on("focus.wb.saisie.jeton",onPriseFocus);
		    	jqInput.on("blur.wb.saisie.jeton",onPerteFocus);

                //pour que DonenFocus aille bien sur l'input 
                

		    	//clic sur le tout donne le focus à l'input 
		    	jqContainer.on("click.wb.saisie.jeton",jqInput[0].wbWrappeFocus = jqContainer[0].wbWrappeFocus = function(event)
		    	{ 		    	
		    		//ignore le clic sui on a déjà le focus sauf si l'appel vient de DonneFocus=>wbWrappeFocus, si on est en lecture seule
		    		//afin de donner le focus que dans les autres cas
		    		if ((event===undefined || !jqInput.data("wbSaisieJetonFocus")) && !jqInput[0].readOnly ) 
		    		{
		    			//et déclenche onPriseFocus
		    			//jqInput.trigger("focus.wb.saisie.jeton");

		    			//ne pas scroller vers la saisie si le clic est précisément sur un jeton 
		    			//onPriseFocus utile car les événemtnts sont sur l'input ensuite (flèche suppr etc.)
		    			var bJetonClic = event && event.target && $(event.target).hasClass("wbJeton");

						//mémorise la position de scroll
						if (bJetonClic && jqContainer[0].scrollTo)
						{
							var oScrollTo = {y : jqContainer[0].scrollTop,x : jqContainer[0].scrollLeft};
						}

		    			onPriseFocus(bJetonClic);

		    			//le navigateur va nativement scroller
		    			jqInput.focus();  //et exécute le code de onfocus                        

		    			//restaure le scroll pour que le clic sur un jeton ne scroll pas
		    			if (bJetonClic && jqContainer[0].scrollTo)
						{
							jqContainer[0].scrollTo(oScrollTo.x,oScrollTo.y);
						}
		    		}

		    	}).on("mousedown.wb.saisie.jeton",function(event)
		    	{ 		    	
		    		//seulement si on a le focus ici
		    		if (!jqContainer.hasClass("wbFocus")) return;
                    //ignore si on ne sort pas de l'input via ce mousedown   
                    if (event.target == jqInput[0]) return;
	    			//ignore le mousedown pour ne pas faire le blur de l'input
	    			event.preventDefault(); 
	    			event.stopPropagation(); 
		    	});

		    	jqInput.on("trigger.wb.saisie.jeton.cree trigger.wb.saisie.jeton.supprime",function(jqEvent,dinoJeton)
		    	{
		    		//met à jour le champ caché avec les modification faite sur les jetons
					sauveVersChampCache();

                    //met à jour la valeur caché avec RC lorsque le champ n'a pas le focus (cas depuis les fonctions WL SaisieAjouteJeton SaisieSupprimeJeton SaisieInsèreJeton)
                    if (!jqContainer.hasClass("wbFocus"))
                    {
                        //suppression du dernier jeton => il faut remettre le texte d'indication (jeton.saisie.supprime.wb)
                       if (jqEvent && jqEvent.namespace.indexOf("supprime")>-1 && jqInput.val().indexOf("\n")===-1)
                       {
                           onPriseFocus(jqEvent);
                           onPerteFocus(jqEvent);
                       }
                        //si le champ est caché
                       else if (!jqInput.data("wbSaisieJetonFocus"))
                        {
                            majInputValMemorisee();
                        }
                        //ou s'il doit être caché suite à cet ajout
                        else if (jqInput.val() == '')
                        {
                             onPerteFocus(jqEvent);
                        }
                    }

					//non à jqInput.trigger("change",dinoJeton);
					//car la saisie contient encore du texte qui peut être utilisé pour faire un ajout de plusieurs jetons
					//
					if (!jqContainer.find(".wbJeton").length && !jqContainer.hasClass("wbFocus"))
					{
						//force l'appel de sortie pour le libellé material
						jqContainer.closest(".wbSaisieNonVide").removeClass("wbSaisieNonVide");
						jqInput.trigger("trigger.wb.saisie.rwd.blur");
					}
		    	});
		    }

		    function onEnfonceTouche(event)
		    {		    	
		    	var jqJetonActif = jqContainer.find(".wbJeton.wbFocus");
		    	var bConserveSelection = false;
				var bPropage=true;
				switch (event.which) 
				{
				// TAB 
				case 9:
		    	{
		    		//TAB => transmettre au listener 
                    if (jqInput.data("wbSaisieJetonFocus") && jqInput.val()!="")
                    {
                        //ce TAB est une frappe de création de jeton, pas une tabulation de navigation
                        traiteFrappePourJeton();
                    }
		    		else 
                    {
                        jqListener.emulateTab(event.shiftKey ? -1 : 1);
                    }
					bPropage=false;	    					    		
		    	}
		    	break;					
				// ENTER 
				case 13:
					{
						//appel le pcode de clic du jeton via le clavier
						if (jqJetonActif.length)
						{
							//supprime tous les actifs
							jqJetonActif.each(function(){
			    				//pcode de clic de jeton
								clWDUtil.pfGetTraitement(jqInput[0].name, 86, undefined)(event,$(this).data("wbJeton"));		    			
							});
							//évite de déplacer le curseur dans la saisie
							bPropage=false;
							//conserve la sélection
							bConserveSelection=true;
						}	
					}
				break;
				// HOME
				case 36 :
					{
//force à déplacer la sélection de jeton SEULEMENT si le caret est au début, à noter que Gmail ne déplace pas si le texte est non vide
						if (doGetCaretPosition(jqInput[0]) === 0)
						{
							selectionneJeton(jqContainer.find(".wbJeton").first(),event.ctrlKey);
							bConserveSelection=true;
							//évite de déplacer le curseur dans la saisie
							bPropage=false;
						}
					}					
				break;
				// END
				case 35 :
					{
						//en affichage seul End sélectionne le dernier jeton
						if (jqInput[0].readOnly)
						{
							selectionneJeton(jqContainer.find(".wbJeton").last(),event.ctrlKey);
							bConserveSelection=true;
							//évite de déplacer le curseur dans la saisie
							bPropage=false;
						}
//force à déplacer la sélection de jeton vers le focus de la saisie
						//if (jqInput.val()=='')
						else
						{
							//selectionneJeton(jqContainer.find(".wbJeton").last());
							bConserveSelection=event.ctrlKey;
							//évite de déplacer le curseur dans la saisie
							//bPropage=false;
						}
					}		
				break;				
				// BACKSPACE
				case 8:					
					if (jqJetonActif.length>1)
					{
						//supprime tous les actifs
						jqJetonActif.each(function(){
							supprimeJeton($(this),false,event);
						});
						//évite de déplacer le curseur dans la saisie
						bPropage=false;
					}
					else if (jqJetonActif.length==1)
					{
						var jqPrecedent = jqJetonActif.prev(".wbJeton");						
						//supprime le jeton actif
						supprimeJeton(jqJetonActif,false,event);											
						if (jqPrecedent.length)
						{
							selectionneJeton(jqPrecedent);
							bConserveSelection=true;
							//évite de déplacer le curseur dans la saisie
							bPropage=false;
						}
					}				
					else if (doGetCaretPosition(jqInput[0]) === 0) 
					{
						var prev = jqInput.prev();
						if (prev.length) 
						{
							supprimeJeton(prev,false,event);
							//évite de déplacer le curseur dans la saisie
							bPropage=false;
						}
					}
				break;

				// DELETE
				case 46:
					if (jqJetonActif.length>1)
					{
						//supprime tous les actifs
						jqJetonActif.each(function(){
							supprimeJeton($(this),false,event);
						});		
						//évite de déplacer le curseur dans la saisie
						bPropage=false;				
					}
					else if (jqJetonActif.length==1)
					{
						var jqSuivant = jqJetonActif.next(".wbJeton");						
						supprimeJeton(jqJetonActif,false,event);
						if (jqSuivant.length)
						{
							selectionneJeton(jqSuivant);
							bConserveSelection=true;
							//évite de déplacer le curseur dans la saisie
							bPropage=false;
						}
					}				
					else if (doGetCaretPosition(jqInput[0]) === 0) 
					{
						var next = jqInput.next();
						if (next.length) 
						{
							supprimeJeton(next,false,event);
							//évite de déplacer le curseur dans la saisie
							bPropage=false;
						}
					}
				break;

				// ESC
				case 27:
					//supprime la sélection de jeton 
					//vide le texte
					jqInput.val('');
					//puis déplace la saisie en fin 
					deplaceSaisieEnFin();
					jqInput.focus();
					break;

				// LEFT ARROW
				case 37:
//force à déplacer la sélection de jeton 
					if (!jqJetonActif.length)
					{
						//si le caret est au début, à noter que Gmail ne déplace pas si le texte est non vide
						if (doGetCaretPosition(jqInput[0]) === 0) 
						//if (jqInput.val()=='')
						{
							selectionneJeton(jqContainer.find(".wbJeton").last());
							bConserveSelection=true;
							//évite de déplacer le curseur dans la saisie
							bPropage=false;
						}
					}
					else
					{
						if (jqJetonActif.prev(".wbJeton").length)
						{
							selectionneJeton(jqJetonActif.first().prev(".wbJeton"),event.shiftKey);
							//évite de déplacer le curseur dans la saisie
							bPropage=false
							bConserveSelection=true;
						}
						//conserve la sélection du premier jeton
						else bConserveSelection=true;
//force à déplacer la sélection de jeton 
						// //la sélection n'est pas conservée lorsque l'on revient vers la saisie
						// if (!jqJetonActif.prev("input").length)
						// {
						// 	bConserveSelection=true;
						// }
						break;
					}		
//force à déplacer la sélection de jeton 
					// //déplace la saisie
					// var jqJetonPrecedent = jqInput.prev();
					// if (jqInput.val().length === 0 && jqJetonPrecedent[0]) 
					// {
					// 	jqJetonPrecedent.before(jqInput.data("wbSaisieJetonDeplace",1));
					// 	jqInput.removeData("wbSaisieJetonDeplace").focus();
					// }
				break;

				// RIGHT ARROW
				case 39:
//force à déplacer la sélection de jeton 					
					if (!jqJetonActif.length)
					{
						// Si pas de jeton actif on ne sélectionne rien
						// if (jqInput.val()=='')
						// {
						// 	selectionneJeton(jqContainer.find(".wbJeton").first());
						// 	bConserveSelection=true;
						// }
					}
					else					
					{	//, à noter que Gmail ne déplace pas si le texte est non vide
												
						selectionneJeton(jqJetonActif.last().next(".wbJeton"),event.shiftKey);
						//évite de déplacer le curseur dans la saisie
						bPropage=false;
						bConserveSelection=jqJetonActif.next(".wbJeton").length;
						
//force à déplacer la sélection de jeton 						
						// //la sélection n'est pas conservée lorsque l'on revient vers la saisie
						// if (!jqJetonActif.next("input").length)
						// {
						// 	bConserveSelection=true;
						// }
						break;
					}	
//force à déplacer la sélection de jeton 
					// //déplace la saisie
					// var jqJetonSuivant = jqInput.next();
					// if (jqInput.val().length === 0 && jqJetonSuivant[0]) 
					// {
					// 	jqJetonSuivant.after(jqInput.data("wbSaisieJetonDeplace",1));
					// 	jqInput.removeData("wbSaisieJetonDeplace").focus();
					// }
				break;

				 default:
					//ignore les touches si un jetons est sélectionné 
					if (jqJetonActif.length)
					{
						//ctrl+c sur jeton
						if (( (event.which === 67 && event.ctrlKey) || (event.which === 16 && event.ctrlKey)) && jqInput[0].select && document.execCommand)
						{
							//copie la valeur du jeton
							//le c/coller d'un jeton doit créer directement le jeton, mais attention au cas de coller dans un texte déjà saisi
							var jqTexteCopie = $("<textarea style='opacity:0;position:fixed;top:-9999px;top:-999px;'/>"); 
							$(document.body).append(jqTexteCopie); 
							jqTexteCopie.val(jqJetonActif.data("wbJeton").m_sValeur + "\n");
							jqTexteCopie[0].select();
							document.execCommand("copy");
							jqTexteCopie.remove();							
						}
						bPropage=false;
						bConserveSelection=true;
					}
				}

				if (!bPropage)
				{
					event.stopPropagation();//évite de déplacer le curseur dans la saisie
					event.preventDefault();//évite de déplacer le curseur dans la saisie				
				}

				if (!bConserveSelection)
				{
					if (!JETON_AUTORISE_MULTISELECTION || (!event.ctrlKey&&!event.shiftKey))//cas multi sélection
						deselectionneToutJeton();
				}
				majInput(undefined,bConserveSelection);
		    }

		    function onFrappeTouche(event,bConserveSaisie)
		    {
		    	//si le champ est masqué, alros la valeur actuelle est la valeur mémorisée complète
		    	//ou si on appuie avec un jeton sélectionné (semble que FF IE EDge envoie un keypress sur un appuie de Flèche mais pas Chrome du coup on arrive ici et tente de rendre la saisie visible alors que la frappe n'est pas une saisie)
		    	if (!jqInput.data("wbSaisieJetonFocus") || jqContainer.find(".wbJeton.wbFocus").length)
		    	{		    		
		    		//laisse remonter l'event
		    		return;
		    	}
				//coller avec un RC dedans
				//https://stackoverflow.com/questions/2176861/javascript-get-clipboard-data-on-paste-event-cross-browser/6804718#6804718					
				var sValeurEnCoursRedef;
				if (jqInput.val()==='' && event && event.type=="paste" && (event.originalEvent.clipboardData || window.clipboardData))
				{
					sValeurEnCoursRedef = (event.originalEvent.clipboardData || window.clipboardData).getData('Text');
				}

				if (bToucheEnfoncee(event,tabSeparateurs,sValeurEnCoursRedef))
				{											
					//ignore le séparateur dans la saisie, toujours
					event.preventDefault();				
					
					//vide la saisie pour créer un jeton
					traiteFrappePourJeton(!!bConserveSaisie,event,sValeurEnCoursRedef);
				}
				else 
				{
					majInput();
				}

				event.stopPropagation();
		    }

		    function traiteFrappePourJeton(bConserveSaisie,event,sValeurEnCoursRedef)
		    {		    	
				if (majJeton(event,bConserveSaisie,false,sValeurEnCoursRedef)===false)
				{
					//jeton non créé 
					//ex : frappe sur entrée avec un texte vide => on laisse remonter le traitement de Entrée
					return;
				}
				majInput(!bConserveSaisie);		    	
		    }

		    function onJetonExisteDeja(jqListeDoublons)
		    {
		    	//jqListeDoublons.hide().fadeIn();
		    	//ou
				// jqListeDoublons.finish().animate({content:1},{ easing : "easeOutQuad", duration : 350,
				//     step: function(now)
				//     {
				// 		$(this).css("box-shadow", "0px 0px " + (35) + "px "+ (now * 12) + "px rgba(166,166,166," +  (1-now) + ")");
				//     }
				// });		    	
				jqInput.add(jqListeDoublons).finish().animate({content:1},
				{ 
					easing : "linear"
				, 	duration : 350
				,	start : function() { $(this).css("animation","shakeLightLittle 150ms ease-out"); }
				, 	complete: function(){  $(this).css("animation","");  }
				});
		    }

		    function supprimeToutJeton(bDepuisAppelWL)
		    {		 
		    	jqContainer.find(".wbJeton").each(function(){
					supprimeJeton($(this),bDepuisAppelWL);
		    	});		    	
		    }

		    function deselectionneToutJeton()
		    {
		    	jqContainer.find(".wbJeton").removeClass("wbFocus");
		    }
			
		    function selectionneJeton(jqJeton,bMultiple,bDepuisClic)
		    {
		    	//dans tous les cas le caret doit être au début 		    	
		    	if (jqInput[0].type!=="hidden") //blindage du cas hidden
		    		jqInput[0].selectionStart=jqInput[0].selectionEnd=0;
		    	
		    	//blindage
		    	if (!jqJeton || !jqJeton.length)
	    		{
	    			return;
	    		}
		    	var bDeja = jqJeton.hasClass("wbFocus");
		    	//FR	0	27/08/2018	14:48	Est-ce que les jetons seront multisélectionnables ?
		    	if (!bMultiple || !JETON_AUTORISE_MULTISELECTION)
		    		deselectionneToutJeton();
		    	if (!bDeja)
		    	{
		    		jqJeton.addClass("wbFocus");
		    		if (!bDepuisClic)//si provient d'un clic on ne change pas le scroll
		    		{
		    			//est il déjà entièrement visible ?
		    			var rectJeton = $.extend({},jqJeton.position(),{bottom: jqJeton.position().top+jqJeton.height(),
		    				right: jqJeton.position().left+jqJeton.width() });
		    			var rectContainer = {top: jqContainer.scrollTop(), bottom: jqContainer.scrollTop()+jqContainer.height(),
		    				left: jqContainer.scrollLeft(), right: jqContainer.scrollLeft()+jqContainer.width() }

		    			if ( 	(rectJeton.left >= rectContainer.left)
		    				&&	(rectJeton.right <= rectContainer.right)
 							&&	(rectJeton.top >= rectContainer.top)
		    				&&	(rectJeton.bottom <= rectContainer.bottom)
		    			)
		    			{
		    				//déjà visible
		    			}		    				
		    			else 
		    			{
		    				!jqJeton[0].scrollIntoView||jqJeton[0].scrollIntoView();
		    				//jqJeton.focus();
		    			}
		    		}
		    	}
		    }

			function supprimeJeton(jqJeton,bDepuisAppelWL,event) 
			{
				//récupère le jeton parmi oDonneesServeurInitiales.m_tabJetons
				var iIndiceDernierJetonTrouveDansTabJetons = -1;

				//blindage
				if (!jqJeton.length)
				{
					return false;
				}

				var oJeton = jqJeton.data("wbJeton");
				if (!bDepuisAppelWL)
				{
					//callback d'avant suppression de jeton par l'utiliateur
					if (false===clWDUtil.pfGetTraitement(jqInput[0].name, 83, undefined)(event,jqJeton.data("wbJeton")))
					{
						return false;
					}
				}
				
				var jqJetonSuivant = jqJeton.next('.wbJeton');
				if (jqJetonSuivant.length)
				{
					var nLargeurJeton = jqJeton.width();
					jqJetonSuivant.css("marginLeft",nLargeurJeton);
					jqJetonSuivant.animate({marginLeft : 0},{easing :"easeOutCubic", duration : 100});		
					//retire le jeton du DOM
					jqJeton.remove();									
				}
				else 
				{
					jqJeton.remove();									
					//retire le jeton du DOM en fin de fondu ?
					//jqJeton.animate({opacity:0},{easing :"easeOutCubic", duration : 100,complete : function(){$(this).remove();}});
				}
				if (!bDepuisAppelWL)
				{
					// GP 04/11/2021 : QW445750 : L'utilisateur a supprimé un jeton, ce n'est pas une édition du champ, ce n'est pas détecté comme une modification.
					// => On force la MAj du flag de ..Modifié pour ce champ.
					// GP 09/11/2021 : QW446587 : A faire après la suppression du jeton.
					if (window["NSPCS"])
					{
						NSPCS.NSChamps.OnInputModificationDecode(jqInput[0]);
					}
				}
				
				//retire le jeton de la mémoire et notifie sa suppression		
				jqInput.trigger("trigger.wb.saisie.jeton.supprime",oJeton);

				return true;
			}

		    function ajouteJeton(sValeurAfficheeOuDinoJeton,nPos,event,sValeurMemorisee)
		    {
		    	var oDinoJeton;
		    	if (typeof sValeurAfficheeOuDinoJeton == "object")
	    		{
		    		//syntaxe dino
					oDinoJeton = sValeurAfficheeOuDinoJeton;
	    		}
	    		else 
	    		{
	    			//syntaxe chaine
	    			oDinoJeton = { m_sLibelle : sValeurAfficheeOuDinoJeton, m_sValeur : sValeurMemorisee };
	    		}

    			//ni valeur ni libellé on ignore 
	    		if (!oDinoJeton.m_sLibelle && !oDinoJeton.m_sValeur) 
    			{
    				return false;
    			}

	    		//évite les doublons
	    		if (!oDonneesServeurInitiales.m_bJetonAutoriseDoublon)
	    		{
			    	//la valeur mémorisée pour la comparaison des doublon est la valeur, sinon le libellé html sinon le libellé 
			    	//Sans Accent Sans Casse sugg par MH
			    	var sValeurMemoriseeSansCasseAccent = getValeurMemoriseeDepuisUnJeton(oDinoJeton,true);
	    			var jqListeDoublons;
					if ((jqListeDoublons = jqContainer.find(".wbJeton").filter(function() 
					{ 
						var jqJetonI = $(this);
						if (compareJetonAvecValeurDejaSansCasseAccent(jqJetonI.data("wbJeton"),sValeurMemoriseeSansCasseAccent))
						{
							return true;
						} 
						return false; 
					} )).length)
					{
						onJetonExisteDeja(jqListeDoublons);
						return false;
					}
				}

	    		//par défaut on affiche le libellé HTML en priorité sur le libellé
	    		var sValeurAffichee = getValeurAfficheeDepuisUnJeton(oDinoJeton,true);

		    	//blindage chaine vide
		    	if (!sValeurAffichee.length)
		    	{
		    		return false;
		    	}

				// création de la balise du jeton
				// la valeur affichée est du HTML
				// la bulle est le format texte de la valeur affichée 
				var jqJeton = $('<span class="wbJeton">' + sValeurAffichee /*sans encodage*/ + '<span data-role="remove"></span></span>');
				//..Bulle
				if (oDinoJeton.m_sBulle)
				{
					jqJeton.attr("title", $("<div>"+oDinoJeton.m_sBulle+"</div>").text());
				}

				//croix personnalisée ?
				var oStyleJeton = oOptions.jeton;
				if (oStyleJeton)
				{
					jqJeton.addClass("padding"  
						+ ' ' + (oStyleJeton.style||"") 
						+ ' ' + (oStyleJeton.surcharge||"")						
					);			
					var oStyleCroix = oOptions.croix;						
					if (oStyleCroix)
					{
						//classe de planche d'animaton
						if (oStyleCroix.planche)
						{
							jqJeton.children().first().addClass("wbplanche " + oStyleCroix.planche);
						}
						//chemin de la croix
						if (oStyleCroix.chemin)
						{
							jqJeton.children().first().css({backgroundImage : 'url("' + oStyleCroix.chemin + '")'});
						}
					}
				}
			    else 
		    	{
		    		jqJeton.addClass("wbJetonDefaut");
		    	}

		    	//couleur 
		    	if (oDinoJeton.m_sCouleur)	jqJeton.css('color',oDinoJeton.m_sCouleur);
		    	//couleur fond
		    	if (oDinoJeton.m_sCouleurFond)	jqJeton.css('background-color',oDinoJeton.m_sCouleurFond);

				// ajoute en mémoire
				jqJeton.data('wbJeton', oDinoJeton);

				//ajoute dans le dom
				if (nPos!==undefined)
				{
					var jqJetonSuivant;
					if (nPos<=1)
					{
						//au début
						jqJetonSuivant = jqInput.parent().children(".wbJeton").first();
					} 
					else 
					{
						jqJetonSuivant = jqInput.parent().children(".wbJeton").eq(nPos-1);
					}
					if (!jqJetonSuivant.length)
					{
						//à la fin
						jqInput.before(jqJeton);
					}
					//à une place d'insertion
					else
					{
						jqJetonSuivant.before(jqJeton);	
					}
				}		
				else 
				{
					//à la place de la saisie
					jqInput.before(jqJeton);
				}

				//click sur croix de suppression de jeton
				jqJeton.on("click.wb.saisie.jeton","[data-role=remove]", function(event) { supprimeJeton(jqJeton,false,event); event.stopPropagation(); });				
				jqJeton.on("click.wb.saisie.jeton",function(event) 
				{ 
					switch(event.which)
					{
						//clic gauche
						case 1:	
							//sélectionne
							selectionneJeton(jqJeton, event.ctrlKey, true); 
							//event.stopPropagation();
			    			//pcode de clic de jeton
							clWDUtil.pfGetTraitement(jqInput[0].name, 86, undefined)(event,jqJeton.data("wbJeton"));
						default:
							//ignore
					}					
				}).on("mousedown.wb.saisie.jeton",function(event) 
				{ 
					switch(event.which)
					{
						//clic du milieu
						case 2:	
							//supprime 
							supprimeJeton(jqJeton,false,event); 
							//event.stopPropagation();
						break;
						default:
							//ignore
					}					
				});	
				jqInput.trigger("trigger.wb.saisie.jeton.cree",jqJeton);				

				//retourne l'indice d'ajout
				return jqJeton.prevAll(".wbJeton").length;
		    }

		    function majJeton(event,bConserveSaisie,bDepuisModeleJetonAussi,sValeurEnCoursRedef)
		    {
	    		var bRetour = false;

	    		//depuis les jetons
		    	for(var i=0; bDepuisModeleJetonAussi && i<oDonneesServeurInitiales.m_tabJetons.length; ++i)
		    	{
		    		if (!ajouteJeton(oDonneesServeurInitiales.m_tabJetons[i],undefined,event))
		    			bRetour = false;
		    	}	 

		    	//reprend la valeur complète du champ de saisie pour recréer les jetons 
		    	var sValeurEnCoursDeFrappe = sValeurEnCoursRedef||jqInput.val();

		    	if (!sValeurEnCoursDeFrappe)
	    		{
	    			return bRetour;
	    		}
		   
	    		var sValeurCourante = '';	
	    		for(var iCar=0; iCar<=sValeurEnCoursDeFrappe.length; ++iCar)
    			{
    				if (iCar==sValeurEnCoursDeFrappe.length || $.inArray(sValeurEnCoursDeFrappe[iCar],tabSeparateurs)>-1)
					{
						if (bConserveSaisie && iCar==sValeurEnCoursDeFrappe.length)
						{
							//laisse cette partie dans la saisie
							jqInput.val(sValeurCourante);
						}
						else 
						{
							var oDinoJeton = {m_sValeur : sValeurCourante};
							if (event && clWDUtil.pfGetTraitement(jqInput[0].name, 82, undefined)(event,oDinoJeton)===false)
							{
								bRetour = false;
								continue;
							}
							bRetour = bRetour || ajouteJeton(oDinoJeton,undefined,event);
						}
						sValeurCourante = '';
					}
					else 
					{
						sValeurCourante += sValeurEnCoursDeFrappe[iCar];
					}
    			}
    			return bRetour;
		    }

		    function majInput(bEfface,bConserveSelection)
		    {
		    	var textLength = 0;
		    	if (bEfface)
	    		{
	    			jqInput.val('');
	    		}
	    		else 
	    		{
			    	//recalcule la taille de l'input 
					textLength = jqInput.val().length;
	    		}
				if (!bConserveSelection && textLength)
				{
					deselectionneToutJeton();
				}
				var wordSpace = Math.ceil(textLength / 5);
				//var size = textLength + wordSpace + 1;
				jqInput.attr('size', Math.max(nTailleIndication, textLength));	
				if (!bConserveSelection && jqInput.attr("type")!="hidden")	    	
				{
					var x = jqInput.offset().left - jqContainer.offset().left;
					var y = jqInput.offset().top - jqContainer.offset().top;
					//remet dans la vue scrolél s'il y a un ascenseur
					if ( (jqContainer[0].scrollTo && jqContainer[0].scrollHeight > jqContainer[0].clientHeight&& (y<jqContainer[0].scrollTop || (y>jqContainer[0].scrollTop+jqContainer[0].clientHeight) ))
					||	(jqContainer[0].scrollTo && jqContainer[0].scrollWidth > jqContainer[0].clientWidth && (x<jqContainer[0].scrollLeft || (x>jqContainer[0].scrollLeft+jqContainer[0].clientWidth) )  )
					)
					{
						jqContainer[0].scrollTo(x,y);
					}
				}
		    }

		    function onPerteFocus(event)
		    {
		    	var bValNonVide = jqInput.val();
		    	if (bValNonVide)
		    	{
					//TODO si le blur a été causé par un TAB ou un "Suivant" (sur android) avec une valeur non vide 
					//alors on reste dans le champ 
					//dans tous les autres cas on quitte 
					//TODO en sortie de champ de saisie il faudrait conservé le texte saisie s'il n'est pas ajouté comme jeton (cas de doublon ou pcode d'ajout qui refuse)
					//		
					//mais comme en WEB il faut garder la valeur json dans le name lors de l'envoie de requête AJAX ou SUBMIT c'est difficile à faire					
					//											
					//en attendant on refuse la sortie si c'est non valide
		    		if (majJeton(event)===false)
	    			{
	    				event.preventDefault();
	    				event.stopPropagation();

		    			//re focus dans la saisie avec un délai pour éviter de boucler en cas de pcode d'ajout de jeton qui renvoie faux et faire Erreur() qui blur => refocus
                        setTimeout(function(){
    			    		onPriseFocus();	    	//raz val()		
    			    		jqInput.focus();  	
    	    				jqInput.val(bValNonVide);
                        },10);
			    		return;	    				
	    			}
		    	}
		    	deselectionneToutJeton();
		    	//le rendre transparent 
		    	jqInput.removeData("wbSaisieJetonFocus");

                majInputValMemorisee();

		    	jqContainer.removeClass("wbFocus");
				//remet la saisie en fin, sauf pendant un déplacement
				deplaceSaisieEnFin();
				
            // pourquoi remettre le focus en perte de focus si cela a créé un jeton ?
            // if (bValNonVide)
            // {
            //  			//re focus dans la saisie 
            //   		onPriseFocus();	    			
            //   		jqInput.focus();  						
            // }
		    }
            function majInputValMemorisee()
            {
		    	var sValeurDepuisTousLesJetons = getValeurDepuisTousLesJetons();

		    	if (sValeurDepuisTousLesJetons=="")
		    	{
					//s'il y a un texte d'indication on laisse le champ visible en text si la valeur est vide 
		    	}
		    	else 
		    	{		    		
			    	//mettre à jour l'input avec les valeurs mémorisées séparées par ,
			    	//le RC n'est pas supporté en value de type=text donc on le passe en hidden 
			    	jqInput
			    		.css("opacity",0)
			    		.attr("type","hidden")
			    		.val(sValeurDepuisTousLesJetons)
			    		.trigger("change")
			    		.attr("size",1)//évite que le champ soit grand quand on reprend le focus 
			    	;	
		    	}                
            }

		    function deplaceSaisieEnFin()
		    {
//force à déplacer la sélection de jeton, pas la saisie		    	
		     	//remet la saisie en fin, sauf pendant un déplacement
				// if (!jqInput.data("wbSaisieJetonDeplace"))
				// {
				// 	var jqDernierJeton = jqInput.siblings().last();
				// 	if (jqDernierJeton.length)
				// 	{						
				// 		jqDernierJeton.after(jqInput);
				// 		!jqDernierJeton[0].scrollIntoView||jqDernierJeton[0].scrollIntoView();
				// 	}
				// }
		    }
		    function onPriseFocus(bConserveSelection)
		    {		   
		    	//le RC n'est pas supporté en value de type=text donc on l'avait passé en hidden 
		    	//et on le remet en text
		    	jqInput
		    		.attr("type",sType)
		    		.data("wbSaisieJetonFocus",1)
		    		//et le rendre opaque
		    		jqInput.css("opacity",1)
		    	;
		    	if (!jqContainer.hasClass("wbFocus"))
		    	{
		    		//vider l'input 
		    		jqInput.val('');
    		    	jqContainer.addClass("wbFocus");
    		    	majInput(true,bConserveSelection);
		    	}
		    	else 
		    	{
		    		;//majInput(false,bConserveSelection);					
		    	}
		    	
		    }

		    function getValeurDepuisTousLesJetons(bValAffichee)
		    {
		    	var sMemorisee = '';		    	
		    	//la valeur sépare les valeurs mémorisées des jetons par des RCs (vu en réunion 25/06/18 FR PAD MH DL SAM)
		    	var sSep = "\n";
		    	jqContainer.find(".wbJeton").each(function(){
		    		if (sMemorisee!=='') sMemorisee += sSep;
		    		var oJeton = $(this).data("wbJeton");
					sMemorisee += (bValAffichee ? getValeurAfficheeDepuisUnJeton(oJeton) : getValeurMemoriseeDepuisUnJeton(oJeton));
		    	});	
		    	return sMemorisee;
		    }
		});		
	}

	//cas de ZRAjoute en AJAX, changement de tranche...
	if (window.NSPCS)
	{
		// Notifie aussi de la modification du HTML de la page
		NSPCS.NSUtil.ms_oNotificationsAjoutHTML.AddNotification(init);
		NSPCS.NSUtil.ms_oNotificationsFinAJAX.AddNotification(init);		
		//NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(init);
	}
	//en cas de mise à jour de html par ajax
	if (window["clWDUtil"]!==undefined) 
	{
		if (clWDUtil.m_oNotificationsAjoutHTML)
		{
			clWDUtil.m_oNotificationsAjoutHTML.AddNotification(init);
		}
		if (clWDUtil.m_oNotificationsFinAJAX)
		{
			clWDUtil.m_oNotificationsFinAJAX.AddNotification(init);
		}
	}		

	//1er appel 
	init(event);
});

//combo popup
$.fn.wbComboPopupOuvre = function(domEvent,jqPopup)
{	
	//blindage : absence de popup
	if (!jqPopup || !jqPopup.length)
		return;

	var oEventOuverture = $.event.fix(domEvent);

	//retire le blindage sous IE quirks
	if (!bIEQuirks)
	{
		//uniquement le clic gauche
		if (oEventOuverture.button!=0)
			return;

		//seulement le simple clic
		if (oEventOuverture.touches && oEventOuverture.touches.length>1)
			return;
	}

    //sugg forcer un curseur de main sur jqCombo ?
	var jqCombo = $(this);

	var fFermeComboPopup = function (oEventFermeture)
	{	
		if (oEventFermeture.type=="trigger")
		{
			//forcé volontairement => toujors ok
		}
		else if ( (oEventFermeture.type=="mousedown") || (oEventFermeture.type=="focusin"))
		{
			var jqCible = $(oEventFermeture.target);
			//le clic doit être en dehors de la popup de cette combo (gare au cas des combo popup dans une combo popup)
			if (jqCible.closest(jqPopup).length)
			{
				return;
			}			
		}
		else if (oEventFermeture.type=="keydown")
		{
			//touche ESC uniquement
			if (oEventFermeture.which!=27)
			{
				return;
			}
		}

		//rappellera fTraiteFermeture
		clWDUtil.CelluleFermeDialogue(jqPopup[0].id.substr("dww".length),document);		

		oEventFermeture.preventDefault();
		oEventFermeture.stopPropagation();
	};


	var fTraiteFermeture = function(jqEventTrigger)
	{
		//traitement de ..ValeurRenvoyée
        try
        {
        	//récupère Popup..ValeurRenvoyée
       		var oValeurRenvoyee = NSPCS.NSChamps.oGetChamp
       		(
       			jqPopup[0].id.substr("dww".length)
       		, 	90 /*NSPCS.NSChamps.EIDObjet.EIDObjet.Popup*/
       		)
       		.viGetPropriete
       		(
       			1 /*NSPCS.NSProprietes.EFamille.JS*/
       		, 	63 /*NSPCS.NSProprietes.EJS.ValeurRenvoyee*/
       		); 

	        //Traite Combo..Valeur=Popup..ValeurRenvoyée si le client renseigne une valeur
	        if (!NSPCS.NSChamps.bEstValeurRenvoyeeDefaut(oValeurRenvoyee))
	        {
	            //cherche si la valeur existe déjà
	            var jqOptionSel = jqCombo.children().filter(function(){ return this.innerText == oValeurRenvoyee.toString();});
	            // //non trouvé
	            // if (!jqOptionSel.length)
	            // {
	            //     //on l'ajoute => GP dit non car l'info ne sera pas transmise au serveur
	            //     jqOptionSel=$("<option>"+sValeurRenvoyeeHTML+"</option>");
	            //     jqCombo.append(jqOptionSel);
	            // }
	            //change la valeur sélectionnée de la combo
	            if (jqOptionSel.length)
		            jqCombo[0].selectedIndex = jqOptionSel.first().index();			        
	        }
    	}
    	catch(e)
    	{
    		//erreur en récupération de ..ValeurRenvoyée
    		clWDUtil.WDDebug.assert(false,e);
    	}

		//pcode de fermeture de popup
		clWDUtil.pfGetTraitement(jqCombo[0].name, 85, undefined)(jqEventTrigger);
        //cache la popup				    
		//déjà fait par PopupFerme jqPopup.removeClass("WDPopupVisible").css({left:0,top:0,display:"none"});
		//arrête l'écoute
		jqPopup.off("trigger.wb.combo.popup.ferme");		
		$(document.body).off("mousedown.wb.combo.popup.ferme focusin.wb.combo.popup.ferme keydown.wb.combo.popup.ferme trigger.wb.combo.popup.ferme");		
        $(window).off("resize.wb.combo.popup.ferme");
	};


	//évite de dérouler la combo native
	oEventOuverture.preventDefault();
    jqCombo[0].disabled=true;//pour Firefox android dont le preventDefault n'epêche pas l'ouverture native des <option>
	//oEventOuverture.stopPropagation(); non afin de laisser le code du client s'exécuter

    var fReEcoute= function(bComboOuverteEntreTemps){
        //écoute le mousedown après le passage de celui ci
        setTimeout(function()
        {
            jqCombo[0].disabled=false;//pour Firefox android dont le preventDefault n'epêche pas l'ouverture native des <option>
            if (bComboOuverteEntreTemps)
            {
                //$(document.body).on("mousedown.wb.combo.popup.ferme focusin.wb.combo.popup.ferme keydown.wb.combo.popup.ferme trigger.wb.combo.popup.ferme",fFermeComboPopup);
                //focusin.wb.combo.popup.ferme : pas possible car  peut être déclenché sur un élément qui est derrière la popup contenant la combo avec popup
                $(document.body).on("mousedown.wb.combo.popup.ferme keydown.wb.combo.popup.ferme trigger.wb.combo.popup.ferme resize.wb.combo.popup.ferme",fFermeComboPopup);
                $(window).on("resize.wb.combo.popup.ferme",fFermeComboPopup);
            }
        },10);        
    };

	//cas de reclic sur la combo 
	if (jqPopup.hasClass("WDPopupVisible"))
	{
		//exécute la fermeture de popup 
		fFermeComboPopup(oEventOuverture);
		//bloque
		oEventOuverture.stopPropagation();	
        //ré écoute ensuite
        fReEcoute(false);
		return;
	}

	//prépare pour le calcul de position
	jqPopup.css({visibility:"hidden",display:"block"});

    //position de la combo (re layout)
    var oPosCombo = jqCombo.offset(); 
    var oTailleCombo = {width : jqCombo.outerWidth(), height : jqCombo.outerHeight()}		;

	//style de popup
	var oPosPopup = {};
	oPosPopup.display="block";
	oPosPopup.visibility="visible";

	//taille de popup
	var oTaillePopup = {width : jqPopup.outerWidth(), height : jqPopup.outerHeight()}		;

	//calcul de position

    var nHauteurRestanteBas = window.nHauteurNavigateur - oPosCombo.top;
    //sous la combo?
    if ( (nHauteurRestanteBas > oTaillePopup.height) || ( (oPosCombo.top - oTaillePopup.height) <  window.nBordHautNavigateur))
    {
        //dessous
        oPosPopup.top=oPosCombo.top + oTailleCombo.height;
    }
    else 
    {
        //dessus ou calé au bord haut
        oPosPopup.top=oPosCombo.top - oTaillePopup.height;
    }

    //dépasserait à droite de l'écran
    if ((oPosCombo.left + oTaillePopup.width) > window.nLargeurNavigateur)
    {
        //cale à droite
        oPosPopup.left=window.nLargeurNavigateur-oTaillePopup.width;
    }
    else 
    {
    	//aligne sur le bord gauche de la combo
        oPosPopup.left=oPosCombo.left;
    }
	
	//affiche réellement et joue l'animation
	clWDUtil.CelluleAfficheDialogue(jqPopup[0].id.substr("dww".length),document,clWDUtil.ms_ePlaceSouris, undefined, 0, oPosPopup.left, oPosPopup.top, false, undefined);
	//jqPopup.css(oPosPopup).addClass("WDPopupVisible");
	jqPopup.on("trigger.wb.combo.popup.ferme",fTraiteFermeture);		

	//pcode d'ouverture de popup
    var sAliasChampAstuce = jqCombo[0].name;
    //blindage pour deviner l'alias à partir du nom construit dans les ZR
    if (sAliasChampAstuce.indexOf("zrl_")===0)
    {
        //mets à jour la position de la ligne sélectionnée dans la ZR
        //TODO le WDxxxHTML devrait plutôt mettre ce code qui place la ligne avant chaque onXXX 
        //sauf que ici le onmousedown peut être vide car le client n'a rien dans son pcode alors qu'en réalité il y aura ce code appelé
        var nLigne = parseInt(sAliasChampAstuce.substr(4/*zrl_*/,sAliasChampAstuce.indexOf("_",4/*zrl_*/)-4/*zrl_*/));
        if (!isNaN(nLigne)){
            var jqZR = jqCombo.closest("[id^=con-],[id$=_HTE],[id$=_TB]"); //classique ou navigateur
            var sZrAlias = jqZR.attr("id");
            if (sZrAlias.indexOf("con-")===0)  sZrAlias=sZrAlias.substr(4/*con-*/);  //cas zr classique
            else if (sZrAlias.indexOf("_HTE")===sZrAlias.length-4/*_HTE*/)  sZrAlias=sZrAlias.substr(0,sZrAlias.length-4/*_HTE*/); //cas zr navigateur
            else if (sZrAlias.indexOf("_TB")===sZrAlias.length-3/*_TB*/)  { sZrAlias=sZrAlias.substr(0,sZrAlias.length-3/*_TB*/); jqZR=jqZR.parent().closest("table"); } 

            jqZR.siblings("[name$='" + sZrAlias + "']").attr("value",nLigne);
        }
        sAliasChampAstuce = sAliasChampAstuce.substr(sAliasChampAstuce.lastIndexOf("ATT_")+"ATT_".length, sAliasChampAstuce.length - sAliasChampAstuce.lastIndexOf("_"));
    }

    var sAliasChamp = jqCombo.attr("data-wbAlias") || sAliasChampAstuce;

	clWDUtil.pfGetTraitement(sAliasChamp, 84, undefined)(oEventOuverture);

    fReEcoute(true);
};


//contournement de bug chrome 873440 corrigé en 72
if (bCrm && !bEdge && navigator && navigator.appVersion && (navigator.appVersion.indexOf("Chrome/70")>-1||navigator.appVersion.indexOf("Chrome/71")>-1))
{
	$(window).on("DOMContentLoaded.wb.chrome.cadrearrondi resize.wb.chrome.cadrearrondi trigger.wb.chrome.cadrearrondi trigger.wb.plan.action.set.fin trigger.wb.disposition.visible.maj",function() 
	{        
        var tabCallbackSetter = [];
        var tabCallbackMutater = [];
        $(".wbCadreArrondi9Img").each(function()
        {
            if (this.wbCadreArrondi9ImgDeja) return true; 

            var jqTable = $(this);
            var jqTBody = jqTable.children("tbody").first();
            //récupère les dimensions à partir du tbody car cela permet aussi de se réinitialisé en cas d'appel depuis MutationObserver en ignorant les tailles fixées à la table
            var nLargeurInit = jqTBody[0].offsetWidth;
            var nHauteurInit = jqTBody[0].offsetHeight;
            //pas traitable car dans un display none
            if (nLargeurInit==0 || nHauteurInit==0) return true; 

            this.wbCadreArrondi9ImgDeja=true;

            var jdTdPrincipal = this.jdTdPrincipal || jqTBody.children("tr").children("td").filter(function(){    
                return $(this).css("backgroundImage").indexOf("_wwcb1.png") > -1;
            });

            if (!jdTdPrincipal.length) return true;
            this.jdTdPrincipal = jdTdPrincipal;


			var jqLignePrincipale = jdTdPrincipal.parent();
			var jqLigneDimensionsTd = jqLignePrincipale.siblings().first().children("td");

			var nMargeGauche = jdTdPrincipal.index()>0 ? jqLigneDimensionsTd.first()[0].offsetWidth : 0;
			var nMargeDroite = jdTdPrincipal.index()<jqLigneDimensionsTd.length ? jqLigneDimensionsTd.last()[0].offsetWidth : 0;

			//le bug ne touche qu'1px
			--nMargeGauche;
			--nMargeDroite;

			var nMargeHaute = jqLignePrincipale.prev().length ? jqLignePrincipale.prev()[0].offsetHeight : 0;
			var nMargeBasse = jqLignePrincipale.next().length ? jqLignePrincipale.next()[0].offsetHeight : 0;

			//la marge doit tenir compte de la partie transparente de l'image 
			//?????
			//valeur empirique pour ne pas déborder dans la partie transparente
			nMargeHaute /= 2;
			++nMargeHaute;
			++nMargeHaute;
			++nMargeHaute;
			nMargeBasse /= 2;
			++nMargeBasse;
			++nMargeBasse;

            var bgcolor = jdTdPrincipal.css("background-color");
            var bgimg = jdTdPrincipal.css("background-image");

            tabCallbackSetter.push(function()
            {
                //récupère le style du td principal
                jqTable
                    //.attr("style",jqTable.attr("style") + jdTdPrincipal.attr("style")) <-- trop risqué et le cas de la page vient via #page et non style=
                    .css({
                        backgroundColor:bgcolor
                    ,   backgroundImage:bgimg
                    ,   backgroundClip:"content-box"
                    ,   backgroundOrigin:"content-box"
                    ,   boxSizing:"border-box"//pour le cumul padding et dimensions
                    ,   display:"grid"
                    ,   borderRadius:Math.max(nMargeGauche||nMargeDroite,nMargeHaute||nMargeBasse)
                    })
                ;

                //crée un blanc tournant pour ne pas appliquer le fond de la table sur les coins
                jqTable.css("paddingLeft",  nMargeGauche).css("paddingRight", nMargeDroite).css("paddingTop",  nMargeHaute).css("paddingBottom", nMargeBasse);
                //et une marge négative pour replacer les tr sur le blanc tournant
                jqTBody
                    .css("marginLeft", - nMargeGauche).css("marginRight", - nMargeDroite) 
                    .css("marginTop",  - nMargeHaute).css("marginBottom", - nMargeBasse)
                    .css("display","table").css("height","calc(100% + " + (nMargeHaute+nMargeBasse) + "px)").css("width","calc(100% + " + (nMargeGauche+nMargeDroite) + "px)");

                if (jqTable.hasClass("wbCadreArrondi9ImgAncrageLargeur"))
                {
                    jqTable.css("width","100%");
                }
                else 
                {
                    jqTable.css("width",nLargeurInit);
                }
                if (jqTable.hasClass("wbCadreArrondi9ImgAncrageHauteur"))
                {
                    jqTable.css("height","100%");
                }
                else 
                {
                    jqTable.css("height",nHauteurInit);
                }  
            });
            tabCallbackMutater.push(function()
            {            
                //pour être rappelé en cas de modif par JS pur
                var target = jdTdPrincipal.get(0);
                var config = { attributes: true, childList: true, characterData: true, subtree : true };
                if (window.MutationObserver && target)
                {
                    var domTable = jqTable.get(0);
                    if (!domTable.wbObserverCadreArrondi)
                    {
                        domTable.wbObserverCadreArrondi = new MutationObserver(function(mutations) {            
                            //force à réinitialiser (note : on est appelé en async par le navigateur ici)
                            //déconnecte toutes les écoutes le temps que cadrearrondi soit appelé car il les rebranchera
                            $(".wbCadreArrondi9Img").filter(function(){return !!this.wbObserverCadreArrondi;}).each(function(){this.wbObserverCadreArrondi.disconnect(); this.wbCadreArrondi9ImgDeja = false;});                       
                            $(window).trigger("trigger.wb.chrome.cadrearrondi");   
                        }); 
                    }
                    domTable.wbObserverCadreArrondi.observe(target, config);                
                }
            });

        });
        //2ème passe setter 
        requestAnimationFrame(function(){
            for(var iSetter=0; iSetter<tabCallbackSetter.length; tabCallbackSetter[iSetter++]());
        });
        //3ème passe mutateur
        requestAnimationFrame(function(){
            for(var iMutater=0; iMutater<tabCallbackMutater.length; tabCallbackMutater[iMutater++]());
        });
    });


	//en cas de mise à jour de html par ajax
	if (window["clWDUtil"]!==undefined) 
	{
		if (clWDUtil.m_oNotificationsAjoutHTML)
		{
			clWDUtil.m_oNotificationsAjoutHTML.AddNotification(function(){$(window).trigger("trigger.wb.chrome.cadrearrondi"); });
		}
		if (clWDUtil.m_oNotificationsFinAJAX)
		{
			clWDUtil.m_oNotificationsFinAJAX.AddNotification(function(){ $(window).trigger("trigger.wb.chrome.cadrearrondi"); });
		}
	}

}

//interrupteur à bascule 
//
$(window).on("DOMContentLoaded.wb.bascule.init",function() 
{
	function initBascule()
	{
		$(".wbInterrupteurBascule").each(function(){
			if (this.wbInterrupteurBasculeInitDejaFait) return;
			this.wbInterrupteurBasculeInitDejaFait=true;

			var jqConteneurTd 		= $(this);		
			var jqRadios 			= jqConteneurTd.children("input");	
			var jqLibelles 			= jqConteneurTd.children("label");	
			var jqCurseur 			= jqConteneurTd.children(".wbInterrupteurBascule-Curseur");
			var jqGlissiere 		= jqConteneurTd.children(".wbInterrupteurBascule-Glissiere");

			// var oOptions = $.extend(
			// //infos par défaut
			// { 
			// 	plancheCurseurOn 	: undefined 
			// ,	plancheCurseurOff 	: undefined 
			// }
			// ,
			// //infos venues de la génération
			// jqCurseur.wbJsonParseAttr("data-wb-interrupteur-bascule",true)||{}
			// );

			function nGetIndiceRadioSelectionnee(bViaClass)
			{
				return jqRadios.filter(function(){
					return (this.checked && (!bViaClass || !this.classList.contains("wbNotChecked"))) || (bViaClass && this.classList.contains("wbChecked"));
				}).index();
			}
			function setIndiceRadioSelectionnee(n,bViaClass)
			{
				//retire le flag visuel de coche
				jqRadios.removeClass("wbNotChecked").removeClass("wbChecked");
								
				if (bViaClass)
				{										
					//utilise un flag visuel de coche => pratique pour changer le rendu visuel sans changer la valeur 
					jqRadios.addClass("wbNotChecked");
					jqRadios.eq(n).removeClass("wbNotChecked").addClass("wbChecked")/*.addClass("wbActif")*/;
					return;
				}

				//coche réellment
				jqRadios[n].checked=true; 
                jqRadios.eq(n).trigger("change.wb.bascule");
			}
			function bascule(bViaClass)
			{
				var nNouvelIndiceSelectione =  nGetIndiceRadioSelectionnee(bViaClass)==0 ? 1 : 0;//2 valeurs possibles uniquement
				setIndiceRadioSelectionnee(nNouvelIndiceSelectione,bViaClass);												
			}
			function init()
			{

				var nPosLeftInit;
				var bDepartCoteLibelleExterneActif=false;
				var bEstUnDragEtPasUnClic=false;
                //OPTIM utiliser transform plutôt que left pour la position du curseur
				function onSwipeStatus(event, phase, direction, distance,duration, fingerCount, fingerData, currentDirection) 
				{
                    if (jqRadios[0].disabled)return;//cas grisé
                    if(event.button && event.button!=0)//évite le clic droit 
                        return;

                    /**
                     * Distance a touch can wander before we think the user is scrolling in dips.
                     * Note that this value defined here is only used as a fallback by legacy/misbehaving
                     * applications that do not provide a Context for determining density/configuration-dependent
                     * values.
                     *
                     * To alter this value, see the configuration resource config_viewConfigurationTouchSlop
                     * in frameworks/base/core/res/res/values/config.xml or the appropriate device resource overlay.
                     * It may be appropriate to tweak this on a device-specific basis in an overlay based on
                     * the characteristics of the touch panel and firmware.
                     */
                    //private static final int TOUCH_SLOP = 8;

					//au dela de 8px (dixit MH) de déplacement 
                    //ou de 500ms de temps écoulé depuis le doigt posé on considère que ce n'est plus un clic mais un petit drag
					if (distance>8)// || duration>500)
					{
                        //clic dépassé
						bEstUnDragEtPasUnClic=true;
					}
					if (bEstUnDragEtPasUnClic)
    				{
        				//évite le scroll vertical pendant le drag sur iOS
                        event.preventDefault();
                        event.stopPropagation();
                    }
					//corrige la direction pour ne prendre que l'horizontal
                    var id = (event && event.touches && event.touches[0] && event.touches[0] && event.touches[0].identifier) ? event.touches[0].identifier : 0;
                    if (direction && fingerData && fingerData[id] && fingerData[id].start && fingerData[id].end)// && !(direction == "left" || direction == "right"))
                    {
                        distance = fingerData[id].end.x - fingerData[id].start.x;
                        direction = "right";
                        if (distance<0)
                        {
                            distance = -distance;//ici on garde une distance positive selon la direction, ce sera inversé plus tard
                            direction = "left";
                        }
                    }
                    if (distance && direction== "left")
                    {
                        distance = -distance;   
                    }

					if (phase == "end" || phase == "cancel") 
					{						
						if (nPosLeftInit!==undefined) // blindage double appel + //distance est à 0 sur iOS au 1er comme au 2ème appel
						{							
							var bChangementValeur=false;
							if (jqConteneurTd[0].wbBasculeSortieEvent)
							{
								//cas où la fin du swipe provoque le changement de valeur
								if ( 
									//sortie du jqConteneurTd par les côtés
					 				(jqConteneurTd[0].wbBasculeSortieEvent.offsetX < 0 && nGetIndiceRadioSelectionnee()==1 ) 
					 			||	(jqConteneurTd[0].wbBasculeSortieEvent.offsetX > jqConteneurTd[0].clientWidth && nGetIndiceRadioSelectionnee()==0 )
									//sortie ailleurs en ayant assez déplacé le jqCurseur
								|| 	(nGetIndiceRadioSelectionnee()==1 && (jqCurseur[0].offsetLeft + jqCurseur[0].clientWidth/2) <   jqGlissiere[0].clientWidth/2)
								||	(nGetIndiceRadioSelectionnee()==0 && (jqCurseur[0].offsetLeft + jqCurseur[0].clientWidth/2) > jqGlissiere[0].clientWidth/2)
								) 
								{									
									bChangementValeur=true;
								}
								jqConteneurTd[0].wbBasculeSortieEvent=undefined;
							}
							else  
							{
                                //changement de valeur si la position du curseur au sein de la glissière change de moitié
								bChangementValeur = (jqCurseur[0].offsetLeft > jqCurseur[0].fGetPositionCurseurSelonFacteur(0.5)) != (nGetIndiceRadioSelectionnee()==1)
							}							
							if (bChangementValeur) 
							{
								bascule();
                                //drag traité
                                bEstUnDragEtPasUnClic=true;
							}
						}

						//raz pour laisse passer le CSS
						jqCurseur[0].style.left=""; 
                        jqCurseur[0].classList.remove("wbActif"); 
                        jqGlissiere[0].classList.remove("wbActif"); 
						jqConteneurTd[0].classList.remove("wbActif"); 
						
						// //cas d'un clic ?
						// if (phase == "cancel" && distance<5 && nPosLeftInit!==undefined && !bDepartCoteLibelleExterneActif) 
						// { 
						// 	bascule();
						// }

						nPosLeftInit=undefined;
						//retire le flag visuel de coche
						jqRadios.removeClass("wbNotChecked").removeClass("wbChecked")/*.removeClass("wbActif")*/;	
						//raz la couleur de drag
						jqLibelles.removeClass("wbNoTransition").removeClass("wbActif");
						//jqCurseur.removeClass("wbNoTransition"); inutile car wbActif le fait aussi
						jqLibelles.css("color","");	

						//empêche l'appel au clic (tap) si le drag a été traité					
						return !bEstUnDragEtPasUnClic;
					}
					if (phase=="start") 
					{ 
						//si le départ est du côté du libellé actif il faudra éviter de basculer l'interrupteur
						var jqEvent = extendEvent(event, jQuery.event.fix(event));
						var nOffsetLibelle1 = jqLibelles.first().offset().left;
						var nOffsetLibelle2 = jqLibelles.last().offset().left;
						var nOffsetGlissiere = jqGlissiere.offset().left;
						var bLibelleExterne = nOffsetLibelle1!=nOffsetLibelle2 && nOffsetLibelle1<nOffsetGlissiere;

						//raz
						bDepartCoteLibelleExterneActif = bLibelleExterne && (nGetIndiceRadioSelectionnee()==0 ? jqEvent.pageX<nOffsetGlissiere : jqEvent.pageX>nOffsetLibelle2);
						bEstUnDragEtPasUnClic=false;
						//mémorise le début du drag
						nPosLeftInit = jqCurseur[0].offsetLeft; 
						//rend le curseur actif pour éviter les transitions et appliquer le style
                        jqCurseur[0].classList.add("wbActif");  
                        jqGlissiere[0].classList.add("wbActif");  
						jqConteneurTd[0].classList.add("wbActif");  

						//mémorise les couleurs des libellés dans leur état inverse 				
						jqLibelles.addClass("wbNoTransition").addClass("wbActif");
						//jqCurseur.addClass("wbNoTransition"); inutile car wbActif le fait aussi

						//lit la couleur initiale, à l'état actif 
						jqLibelles.each(function(){
							this.sCouleurAvantBascule = getComputedStyle(this).color;
						});

						//bascule temporairement						
						bascule(true);

						//lit la couleur finale 
						jqLibelles.each(function(){
							var sCouleurApresBascule = getComputedStyle(this).color;
							var sCouleurAvantBascule = this.sCouleurAvantBascule; this.sCouleurAvantBascule=undefined;
	                        // Convertion en RGB
	                        var tabRgbAvant = clWDUtil.tabHTML2RVBA(sCouleurAvantBascule);
	                        var tabRgbApres = clWDUtil.tabHTML2RVBA(sCouleurApresBascule);	                        
							this.fChangeCouleurSelonFacteur = function(dFacteur){
		                        var nR = (dFacteur*tabRgbApres[0] + (1-dFacteur)*tabRgbAvant[0]);
		                        var nG = (dFacteur*tabRgbApres[1] + (1-dFacteur)*tabRgbAvant[1]);
		                        var nB = (dFacteur*tabRgbApres[2] + (1-dFacteur)*tabRgbAvant[2]);		                        
		                        this.style.color = clWDUtil.sRVBA2HTML([nR,nG,nB,1]);
							};
						});

						var nPosLeftFinal = jqCurseur[0].offsetLeft;

						jqConteneurTd[0].fnGetFacteur = function (distance)
						{
							var min = Math.min(nPosLeftFinal,nPosLeftInit);
							var max = Math.max(nPosLeftFinal,nPosLeftInit);
							var pos = Math.min(max,Math.max(min,nPosLeftInit + distance));							
							return nPosLeftFinal>nPosLeftInit ? ( (pos-min) / (max-min)) : (1-((pos-min) / (max-min)));
						};

						jqCurseur[0].fDeplaceCurseurSelonFacteur = function(dFacteur)
						{
							jqCurseur[0].style.left=jqCurseur[0].fGetPositionCurseurSelonFacteur(dFacteur).toString() + "px";					
						};

                        jqCurseur[0].fGetPositionCurseurSelonFacteur = function(dFacteur)
                        {
                            return (nPosLeftInit + (dFacteur* (nPosLeftFinal-nPosLeftInit) ));
                        };
						
						var bBasculeFaitePendantDrag=false;
						jqConteneurTd[0].fDeplaceSelonDistance = function (distance)
						{							
							var dFacteur = this.fnGetFacteur(distance);

							//déplace le curseur 
							jqCurseur[0].fDeplaceCurseurSelonFacteur(dFacteur);	

							//change la couleur des libellés					
							jqLibelles.each(function(){
								this.fChangeCouleurSelonFacteur(dFacteur);
							});

							//bascule le rendu visuel à 50%
							if (dFacteur>0.5 == !bBasculeFaitePendantDrag)
							{
								bBasculeFaitePendantDrag=!bBasculeFaitePendantDrag;
								bascule(true);
							}
						};

						//remet
						bascule(true);						
					} 
						
					//déplacement au drag					
					if (nPosLeftInit!==undefined && distance && (direction == "left" || direction == "right"))//évite l'appel au moment d'un click
					{
						jqConteneurTd[0].fDeplaceSelonDistance(distance);
					}
				}

				//car le label bloque le swipe
				jqLibelles.addClass("wbInterrupteurBascule-Libelle--Draggable");

                //pour application des styles
                jqRadios
                .on("focus.wb.bascule.selection",function()
                {
                    jqCurseur[0].classList.add("wbFocus");  
                    jqGlissiere[0].classList.add("wbFocus");  
                })
                .on("blur.wb.bascule.selection",function()
                {
                    jqCurseur[0].classList.remove("wbFocus");  
                    jqGlissiere[0].classList.remove("wbFocus");  
                })
                .on("keydown.wb.bascule.change",function(e)
                {
                    if (e && e.which === 32) // Espace pour basculer
                   {
                       bascule();
                       e.preventDefault();                          
                       e.stopPropagation();                          
                   }
                })                
                ;

				//écoute
				jqConteneurTd
				//sortir du champ force la fin du drag
				.on("mouseleave.wb.bascule.swipe",function(e)
				{  
					if (!jqCurseur.hasClass("wbActif"))return;//uniquement pendant le drag
					jqConteneurTd[0].wbBasculeSortieEvent=extendEvent(e,jQuery.event.fix(e)); 
					jqConteneurTd.trigger("mouseup"); 
				})
				//drag de curseur
				.swipe({
						fingers:1
					,	allowPageScroll : "vertical"
					,   triggerOnTouchEnd: true
					,   swipeStatus: onSwipeStatus
                    ,   tap:function(event)
						{
                            if (jqRadios[0].disabled)return;//cas grisé
                            if (!bDepartCoteLibelleExterneActif && !(event.button && event.button!=0))//évite le clic droit 
                            {
                                if (jqConteneurTd[0].basculeEnCours)
                                {
                                    event.preventDefault();
                                    event.stopPropagation();
                                    return;
                                }
                                jqConteneurTd[0].basculeEnCours=true;
								bascule();
                                //évite le double tap sans pour autant différé le tap
                                setTimeout(function(){jqConteneurTd[0].basculeEnCours=false;},300);
                                //petite vibration
                                if (navigator && navigator.vibrate)
                                {
                                    navigator.vibrate([10]);
                                }
							}                           
						}
					,	swipe:function(event, direction, distance, duration, fingerCount, fingerData) 
						{
                            if (jqRadios[0].disabled)return;//cas grisé
                            if(event.button && event.button!=0)//évite le clic droit 
                                return;

							//en cas de swipe direct (pas de drag) on change la valeur 
							if (direction == "left" && nGetIndiceRadioSelectionnee()!=0)
							{
								setIndiceRadioSelectionnee(0);
							}
							if (direction == "right" && nGetIndiceRadioSelectionnee()!=1)
							{
								setIndiceRadioSelectionnee(1);
							}                          
						}
				});						
			}
			init();
		});
	}

	//cas de ZRAjoute en AJAX, changement de tranche...
	if (window.NSPCS)
	{
		// Notifie aussi de la modification du HTML de la page
		NSPCS.NSUtil.ms_oNotificationsAjoutHTML.AddNotification(initBascule);
		NSPCS.NSUtil.ms_oNotificationsFinAJAX.AddNotification(initBascule);		
		//NSPCS.NSUtil.ms_oNotificationsChangementTranche.AddNotification(initBascule);
	}
	//en cas de mise à jour de html par ajax
	if (window["clWDUtil"]!==undefined) 
	{
		if (clWDUtil.m_oNotificationsAjoutHTML)
		{
			clWDUtil.m_oNotificationsAjoutHTML.AddNotification(initBascule);
		}
		if (clWDUtil.m_oNotificationsFinAJAX)
		{
			clWDUtil.m_oNotificationsFinAJAX.AddNotification(initBascule);
		}
	}		

	//1er appel 
	initBascule();
});

/*!
 * jQuery Color Animations v2.1.2
 * https://github.com/jquery/jquery-color
 *
 * Copyright 2013 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * Date: Wed Jan 16 08:47:09 2013 -0600
 */
(function(jQuery, undefined) {

    var stepHooks = "backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor",

        // plusequals test for += 100 -= 100
        rplusequals = /^([\-+])=\s*(\d+\.?\d*)/,
        // a set of RE's that can match strings and generate color tuples.
        stringParsers = [{
            re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
            parse: function(execResult) {
                return [
                execResult[1],
                execResult[2],
                execResult[3],
                execResult[4]];
            }
        }, {
            re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
            parse: function(execResult) {
                return [
                execResult[1] * 2.55,
                execResult[2] * 2.55,
                execResult[3] * 2.55,
                execResult[4]];
            }
        }, {
            // this regex ignores A-F because it's compared against an already lowercased string
            re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,
            parse: function(execResult) {
                return [
                parseInt(execResult[1], 16),
                parseInt(execResult[2], 16),
                parseInt(execResult[3], 16)];
            }
        }, {
            // this regex ignores A-F because it's compared against an already lowercased string
            re: /#([a-f0-9])([a-f0-9])([a-f0-9])/,
            parse: function(execResult) {
                return [
                parseInt(execResult[1] + execResult[1], 16),
                parseInt(execResult[2] + execResult[2], 16),
                parseInt(execResult[3] + execResult[3], 16)];
            }
        }, {
            re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
            space: "hsla",
            parse: function(execResult) {
                return [
                execResult[1],
                execResult[2] / 100,
                execResult[3] / 100,
                execResult[4]];
            }
        }],

        // jQuery.Color( )
        color = jQuery.Color = function(color, green, blue, alpha) {
            return new jQuery.Color.fn.parse(color, green, blue, alpha);
        },
        spaces = {
            rgba: {
                props: {
                    red: {
                        idx: 0,
                        type: "byte"
                    },
                    green: {
                        idx: 1,
                        type: "byte"
                    },
                    blue: {
                        idx: 2,
                        type: "byte"
                    }
                }
            },

            hsla: {
                props: {
                    hue: {
                        idx: 0,
                        type: "degrees"
                    },
                    saturation: {
                        idx: 1,
                        type: "percent"
                    },
                    lightness: {
                        idx: 2,
                        type: "percent"
                    }
                }
            }
        },
        propTypes = {
            "byte": {
                floor: true,
                max: 255
            },
            "percent": {
                max: 1
            },
            "degrees": {
                mod: 360,
                floor: true
            }
        },
        support = color.support = {},

        // element for support tests
        supportElem = jQuery("<p>")[0],

        // colors = jQuery.Color.names
        colors,

        // local aliases of functions called often
        each = jQuery.each;

    // determine rgba support immediately
    supportElem.style.cssText = "background-color:rgba(1,1,1,.5)";
    support.rgba = supportElem.style.backgroundColor.indexOf("rgba") > -1;

    // define cache name and alpha properties
    // for rgba and hsla spaces
    each(spaces, function(spaceName, space) {
        space.cache = "_" + spaceName;
        space.props.alpha = {
            idx: 3,
            type: "percent",
            def: 1
        };
    });

    function clamp(value, prop, allowEmpty) {
        var type = propTypes[prop.type] || {};

        if (value == null) {
            return (allowEmpty || !prop.def) ? null : prop.def;
        }

        // ~~ is an short way of doing floor for positive numbers
        value = type.floor ? ~~value : parseFloat(value);

        // IE will pass in empty strings as value for alpha,
        // which will hit this case
        if (isNaN(value)) {
            return prop.def;
        }

        if (type.mod) {
            // we add mod before modding to make sure that negatives values
            // get converted properly: -10 -> 350
            return (value + type.mod) % type.mod;
        }

        // for now all property types without mod have min and max
        return 0 > value ? 0 : type.max < value ? type.max : value;
    }

    function stringParse(string) {
        var inst = color(),
            rgba = inst._rgba = [];

        string = string.toLowerCase();

        each(stringParsers, function(i, parser) {
            var parsed,
            match = parser.re.exec(string),
                values = match && parser.parse(match),
                spaceName = parser.space || "rgba";

            if (values) {
                parsed = inst[spaceName](values);

                // if this was an rgba parse the assignment might happen twice
                // oh well....
                inst[spaces[spaceName].cache] = parsed[spaces[spaceName].cache];
                rgba = inst._rgba = parsed._rgba;

                // exit each( stringParsers ) here because we matched
                return false;
            }
        });

        // Found a stringParser that handled it
        if (rgba.length) {

            // if this came from a parsed string, force "transparent" when alpha is 0
            // chrome, (and maybe others) return "transparent" as rgba(0,0,0,0)
            if (rgba.join() === "0,0,0,0") {
                jQuery.extend(rgba, colors.transparent);
            }
            return inst;
        }

        // named colors
        return colors[string];
    }

    color.fn = jQuery.extend(color.prototype, {
        parse: function(red, green, blue, alpha) {
            if (red === undefined) {
                this._rgba = [null, null, null, null];
                return this;
            }
            if (red.jquery || red.nodeType) {
                red = jQuery(red).css(green);
                green = undefined;
            }

            var inst = this,
                type = jQuery.type(red),
                rgba = this._rgba = [];

            // more than 1 argument specified - assume ( red, green, blue, alpha )
            if (green !== undefined) {
                red = [red, green, blue, alpha];
                type = "array";
            }

            if (type === "string") {
                return this.parse(stringParse(red) || colors._default);
            }

            if (type === "array") {
                each(spaces.rgba.props, function(key, prop) {
                    rgba[prop.idx] = clamp(red[prop.idx], prop);
                });
                return this;
            }

            if (type === "object") {
                if (red instanceof color) {
                    each(spaces, function(spaceName, space) {
                        if (red[space.cache]) {
                            inst[space.cache] = red[space.cache].slice();
                        }
                    });
                } else {
                    each(spaces, function(spaceName, space) {
                        var cache = space.cache;
                        each(space.props, function(key, prop) {

                            // if the cache doesn't exist, and we know how to convert
                            if (!inst[cache] && space.to) {

                                // if the value was null, we don't need to copy it
                                // if the key was alpha, we don't need to copy it either
                                if (key === "alpha" || red[key] == null) {
                                    return;
                                }
                                inst[cache] = space.to(inst._rgba);
                            }

                            // this is the only case where we allow nulls for ALL properties.
                            // call clamp with alwaysAllowEmpty
                            inst[cache][prop.idx] = clamp(red[key], prop, true);
                        });

                        // everything defined but alpha?
                        if (inst[cache] && jQuery.inArray(null, inst[cache].slice(0, 3)) < 0) {
                            // use the default of 1
                            inst[cache][3] = 1;
                            if (space.from) {
                                inst._rgba = space.from(inst[cache]);
                            }
                        }
                    });
                }
                return this;
            }
        },
        is: function(compare) {
            var is = color(compare),
                same = true,
                inst = this;

            each(spaces, function(_, space) {
                var localCache,
                isCache = is[space.cache];
                if (isCache) {
                    localCache = inst[space.cache] || space.to && space.to(inst._rgba) || [];
                    each(space.props, function(_, prop) {
                        if (isCache[prop.idx] != null) {
                            same = (isCache[prop.idx] === localCache[prop.idx]);
                            return same;
                        }
                    });
                }
                return same;
            });
            return same;
        },
        _space: function() {
            var used = [],
                inst = this;
            each(spaces, function(spaceName, space) {
                if (inst[space.cache]) {
                    used.push(spaceName);
                }
            });
            return used.pop();
        },
        transition: function(other, distance) {
            var end = color(other),
                spaceName = end._space(),
                space = spaces[spaceName],
                startColor = this.alpha() === 0 ? color("transparent") : this,
                start = startColor[space.cache] || space.to(startColor._rgba),
                result = start.slice();

            end = end[space.cache];
            each(space.props, function(key, prop) {
                var index = prop.idx,
                    startValue = start[index],
                    endValue = end[index],
                    type = propTypes[prop.type] || {};

                // if null, don't override start value
                if (endValue === null) {
                    return;
                }
                // if null - use end
                if (startValue === null) {
                    result[index] = endValue;
                } else {
                    if (type.mod) {
                        if (endValue - startValue > type.mod / 2) {
                            startValue += type.mod;
                        } else if (startValue - endValue > type.mod / 2) {
                            startValue -= type.mod;
                        }
                    }
                    result[index] = clamp((endValue - startValue) * distance + startValue, prop);
                }
            });
            return this[spaceName](result);
        },
        blend: function(opaque) {
            // if we are already opaque - return ourself
            if (this._rgba[3] === 1) {
                return this;
            }

            var rgb = this._rgba.slice(),
                a = rgb.pop(),
                blend = color(opaque)._rgba;

            return color(jQuery.map(rgb, function(v, i) {
                return (1 - a) * blend[i] + a * v;
            }));
        },
        toRgbaString: function() {
            var prefix = "rgba(",
                rgba = jQuery.map(this._rgba, function(v, i) {
                    return v == null ? (i > 2 ? 1 : 0) : v;
                });

            if (rgba[3] === 1) {
                rgba.pop();
                prefix = "rgb(";
            }

            return prefix + rgba.join() + ")";
        },
        toHslaString: function() {
            var prefix = "hsla(",
                hsla = jQuery.map(this.hsla(), function(v, i) {
                    if (v == null) {
                        v = i > 2 ? 1 : 0;
                    }

                    // catch 1 and 2
                    if (i && i < 3) {
                        v = Math.round(v * 100) + "%";
                    }
                    return v;
                });

            if (hsla[3] === 1) {
                hsla.pop();
                prefix = "hsl(";
            }
            return prefix + hsla.join() + ")";
        },
        toHexString: function(includeAlpha) {
            var rgba = this._rgba.slice(),
                alpha = rgba.pop();

            if (includeAlpha) {
                rgba.push(~~ (alpha * 255));
            }

            return "#" + jQuery.map(rgba, function(v) {

                // default to 0 when nulls exist
                v = (v || 0).toString(16);
                return v.length === 1 ? "0" + v : v;
            }).join("");
        },
        toString: function() {
            return this._rgba[3] === 0 ? "transparent" : this.toRgbaString();
        }
    });
    color.fn.parse.prototype = color.fn;

    // hsla conversions adapted from:
    // https://code.google.com/p/maashaack/source/browse/packages/graphics/trunk/src/graphics/colors/HUE2RGB.as?r=5021

    function hue2rgb(p, q, h) {
        h = (h + 1) % 1;
        if (h * 6 < 1) {
            return p + (q - p) * h * 6;
        }
        if (h * 2 < 1) {
            return q;
        }
        if (h * 3 < 2) {
            return p + (q - p) * ((2 / 3) - h) * 6;
        }
        return p;
    }

    spaces.hsla.to = function(rgba) {
        if (rgba[0] == null || rgba[1] == null || rgba[2] == null) {
            return [null, null, null, rgba[3]];
        }
        var r = rgba[0] / 255,
            g = rgba[1] / 255,
            b = rgba[2] / 255,
            a = rgba[3],
            max = Math.max(r, g, b),
            min = Math.min(r, g, b),
            diff = max - min,
            add = max + min,
            l = add * 0.5,
            h, s;

        if (min === max) {
            h = 0;
        } else if (r === max) {
            h = (60 * (g - b) / diff) + 360;
        } else if (g === max) {
            h = (60 * (b - r) / diff) + 120;
        } else {
            h = (60 * (r - g) / diff) + 240;
        }

        // chroma (diff) == 0 means greyscale which, by definition, saturation = 0%
        // otherwise, saturation is based on the ratio of chroma (diff) to lightness (add)
        if (diff === 0) {
            s = 0;
        } else if (l <= 0.5) {
            s = diff / add;
        } else {
            s = diff / (2 - add);
        }
        return [Math.round(h) % 360, s, l, a == null ? 1 : a];
    };

    spaces.hsla.from = function(hsla) {
        if (hsla[0] == null || hsla[1] == null || hsla[2] == null) {
            return [null, null, null, hsla[3]];
        }
        var h = hsla[0] / 360,
            s = hsla[1],
            l = hsla[2],
            a = hsla[3],
            q = l <= 0.5 ? l * (1 + s) : l + s - l * s,
            p = 2 * l - q;

        return [
        Math.round(hue2rgb(p, q, h + (1 / 3)) * 255),
        Math.round(hue2rgb(p, q, h) * 255),
        Math.round(hue2rgb(p, q, h - (1 / 3)) * 255),
        a];
    };


    each(spaces, function(spaceName, space) {
        var props = space.props,
            cache = space.cache,
            to = space.to,
            from = space.from;

        // makes rgba() and hsla()
        color.fn[spaceName] = function(value) {

            // generate a cache for this space if it doesn't exist
            if (to && !this[cache]) {
                this[cache] = to(this._rgba);
            }
            if (value === undefined) {
                return this[cache].slice();
            }

            var ret,
            type = jQuery.type(value),
                arr = (type === "array" || type === "object") ? value : arguments,
                local = this[cache].slice();

            each(props, function(key, prop) {
                var val = arr[type === "object" ? key : prop.idx];
                if (val == null) {
                    val = local[prop.idx];
                }
                local[prop.idx] = clamp(val, prop);
            });

            if (from) {
                ret = color(from(local));
                ret[cache] = local;
                return ret;
            } else {
                return color(local);
            }
        };

        // makes red() green() blue() alpha() hue() saturation() lightness()
        each(props, function(key, prop) {
            // alpha is included in more than one space
            if (color.fn[key]) {
                return;
            }
            color.fn[key] = function(value) {
                var vtype = jQuery.type(value),
                    fn = (key === "alpha" ? (this._hsla ? "hsla" : "rgba") : spaceName),
                    local = this[fn](),
                    cur = local[prop.idx],
                    match;

                if (vtype === "undefined") {
                    return cur;
                }

                if (vtype === "function") {
                    value = value.call(this, cur);
                    vtype = jQuery.type(value);
                }
                if (value == null && prop.empty) {
                    return this;
                }
                if (vtype === "string") {
                    match = rplusequals.exec(value);
                    if (match) {
                        value = cur + parseFloat(match[2]) * (match[1] === "+" ? 1 : -1);
                    }
                }
                local[prop.idx] = value;
                return this[fn](local);
            };
        });
    });

    // add cssHook and .fx.step function for each named hook.
    // accept a space separated string of properties
    color.hook = function(hook) {
        var hooks = hook.split(" ");
        each(hooks, function(i, hook) {
            jQuery.cssHooks[hook] = {
                set: function(elem, value) {
                    var parsed, curElem,
                    backgroundColor = "";

                    if (value !== "transparent" && (jQuery.type(value) !== "string" || (parsed = stringParse(value)))) {
                        value = color(parsed || value);
                        if (!support.rgba && value._rgba[3] !== 1) {
                            curElem = hook === "backgroundColor" ? elem.parentNode : elem;
                            while (
                            (backgroundColor === "" || backgroundColor === "transparent") && curElem && curElem.style) {
                                try {
                                    backgroundColor = jQuery.css(curElem, "backgroundColor");
                                    curElem = curElem.parentNode;
                                } catch (e) {}
                            }

                            value = value.blend(backgroundColor && backgroundColor !== "transparent" ? backgroundColor : "_default");
                        }

                        value = value.toRgbaString();
                    }
                    try {
                        elem.style[hook] = value;
                    } catch (e) {
                        // wrapped to prevent IE from throwing errors on "invalid" values like 'auto' or 'inherit'
                    }
                }
            };
            jQuery.fx.step[hook] = function(fx) {
                if (!fx.colorInit) {
                    fx.start = color(fx.elem, hook);
                    fx.end = color(fx.end);
                    fx.colorInit = true;
                }
                jQuery.cssHooks[hook].set(fx.elem, fx.start.transition(fx.end, fx.pos));
            };
        });

    };

    color.hook(stepHooks);

    jQuery.cssHooks.borderColor = {
        expand: function(value) {
            var expanded = {};

            each(["Top", "Right", "Bottom", "Left"], function(i, part) {
                expanded["border" + part + "Color"] = value;
            });
            return expanded;
        }
    };

    // Basic color names only.
    // Usage of any of the other color names requires adding yourself or including
    // jquery.color.svg-names.js.
    colors = jQuery.Color.names = {
        // 4.1. Basic color keywords
        aqua: "#00ffff",
        black: "#000000",
        blue: "#0000ff",
        fuchsia: "#ff00ff",
        gray: "#808080",
        green: "#008000",
        lime: "#00ff00",
        maroon: "#800000",
        navy: "#000080",
        olive: "#808000",
        purple: "#800080",
        red: "#ff0000",
        silver: "#c0c0c0",
        teal: "#008080",
        white: "#ffffff",
        yellow: "#ffff00",

        // 4.2.3. "transparent" color keyword
        transparent: [null, null, null, 0],

        _default: "#ffffff"
    };

})(jQuery);

//utile pour ..Bule en code navigateur
$.fn.wbGetBulle = function() {
    if (!this.length) return;
    var domBalise = this[0];
    if (!domBalise) return;

    //bulle native
    if (domBalise.title) return domBalise.title;

    //bulle jquery ui tooltip
    var sIdBulle = domBalise.getAttribute("aria-describedby");
    if (!sIdBulle) return; 
    var domBulle = document.getElementById(sIdBulle);
    if (!domBulle) return; 
    return domBulle.innerText;
};