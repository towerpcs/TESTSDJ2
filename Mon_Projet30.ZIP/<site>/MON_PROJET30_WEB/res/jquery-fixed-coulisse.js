/*! VersionVI: yyyyyyyyyyyy */
// 26.0.1.0 jquery-fixed-coulisse.js
var bAvecEffet = false;//fait bug...
(function($) 
{ 
	//Initialise les champs concernes
	$('div[id^="dww"]').filter('.fixedcoulisse').each(function()//fixedcoulisse flag le champ comme un fixed via jQuery
	{
		var jqChampFixed 		= $(this);
		var sIdentifiant		= jqChampFixed.attr('id');
		
		//precise son offset de debut naturel dans data-debut
		jqChampFixed.attr('data-debut',jqChampFixed.offset().top);
		
		//style de base avec un absolute a la place du fixed
		var sStylebase 			= jqChampFixed.attr('style').replace("fixed","absolute");//replace au lieu de css('position','absolute') pour ne pas modifier le style r�el du champ
		var nMargeAvant 		= parseFloat(jqChampFixed.attr('data-marge-avant'),10);
		var bSansLimiteFin		= jqChampFixed.attr('data-fin')=='';
		var nMargeFin 			= parseFloat(jqChampFixed.attr('data-fin'),10);
		var bVersLeBas 			= jqChampFixed.attr('data-sens') == 'bas';	//sens de coulisse
		
		var sCoordonneeDebut 	= bVersLeBas ? 'bottom' : 'top';
		var sCoordonneeFin 		= bVersLeBas ? 'top'	: 'bottom';
		//Ajout des styles
		$('html > head')
		.append($('<style>#' + sIdentifiant +'.fixed { position:fixed; margin-'+sCoordonneeDebut+':' + nMargeAvant +'px;'+sCoordonneeDebut+':0; }</style>'))
		.append($('<style>#' + sIdentifiant +'.abs { position:absolute; margin-'+sCoordonneeFin+':' + nMargeFin +'px;'+sCoordonneeFin+':0; }</style>'))
		.append($('<style>#' + sIdentifiant +' { ' + sStylebase + ' }</style>'))
		;
		
		//animation qui passe de margin 0 a la marge demandee
		if (bAvecEffet) 
		{
			var sNomAnimation = sIdentifiant +'_fixedcoulissemarge';
			var sCodeAnimation = '0% 	{ margin-' 		+ sCoordonneeDebut +':0; }' + '100% { margin-' 		+ sCoordonneeDebut +':' + nMargeAvant +'px;}';
			$('html > head')
			.append($('<style>@-ms-keyframes '		+sNomAnimation+' { ' + sCodeAnimation + ' }</style>'))
			.append($('<style>@-moz-keyframes '		+sNomAnimation+' { ' + sCodeAnimation + ' }</style>'))
			.append($('<style>@-o-keyframes '		+sNomAnimation+' { ' + sCodeAnimation + ' }</style>'))
			.append($('<style>@-webkit-keyframes '	+sNomAnimation+' { ' + sCodeAnimation + ' }</style>'))
			.append($('<style>@keyframes '			+sNomAnimation+' { ' + sCodeAnimation + ' }</style>'))
			.append($('<style>#' + sIdentifiant +'.effet.fixed { '
				+ '-ms-animation:' 		+ sNomAnimation +' 1s;'
				+ '-moz-animation:' 	+ sNomAnimation +' 1s;'
				+ '-o-animation:' 		+ sNomAnimation +' 1s;'
				+ '-webkit-animation:' 	+ sNomAnimation +' 1s;'
				+ 'animation:' 			+ sNomAnimation +' 1s;'
			+ '}</style>'))
		}
		
		//calcul son offset de fin
		if (!bSansLimiteFin) 
		{
			//positionne temporairement a son arrivee pour en calculer la position exacte (imargin 0, l ne faudra pas qu'une marge intervienne en plus)
			jqChampFixed.attr('style','margin:0;position:absolute;'+sCoordonneeFin+':' + nMargeFin +'px;');
			jqChampFixed.attr('data-fin-absolue',jqChampFixed.offset().top);
		}
		//retire tout style= dans un setTimeout pour �viter le dessin du texte � un mauvais endroit de la page
		jqChampFixed.css('display','none'); 
		setTimeout(function() { jqChampFixed.css('display','block').attr('style',''); if (AppelMethode && jqChampFixed.length==1 && window["WDChamp"] && WDChamp.prototype.ms_sOnDisplay) AppelMethode(WDChamp.prototype.ms_sOnDisplay, [jqChampFixed[0], true]); },1);
	});

	//fixed mais pas trop : traite les champs a chaque scroll ou resize de la fen�tre
	function fixedcoulisse(event)
	{
		//Optim : calculs en dehors du each
		// Niveau de la vue dans la page (<=> nombre de pixels au dessus de la partie affichee)
		var nDebutVueNavigateur = $(window).scrollTop();
		var nDecalageGaucheVueNavigateur = $(window).scrollLeft();
		if (this.nDebutVueNavigateur == nDebutVueNavigateur)
			return;//optim et �vite un bug en cas rappel avec la m�me position (vu sous IE)
		var bDescend = this.nDebutVueNavigateur < nDebutVueNavigateur;
		//m�morise le dernier d�but afin de conna�tre le sens du scroll
		this.nDebutVueNavigateur = nDebutVueNavigateur;

		//div id=dww en position:fixed sont consernes
		$('div[id^="dww"]').filter('.fixedcoulisse').each(function()//fixedcoulisse flag le champ comme un fixed via jQuery
		{
			//Informations sur le champ
			var jqChampFixed 		= $(this);
			//si l'ascenseur horizontal est utilis�, on retourne � la position de d�part
			if (nDecalageGaucheVueNavigateur>0)
			{
				jqChampFixed.removeClass('fixed');
				jqChampFixed.removeClass('abs');	
				jqChampFixed.removeClass('effet');				
				return;
			}				
			var nMargeAvant 		= parseFloat(jqChampFixed.attr('data-marge-avant'),10);
			var bSansLimiteFin		= jqChampFixed.attr('data-fin')=='';
			var nMargeFin 			= parseFloat(jqChampFixed.attr('data-fin'),10);
			var nFinFixed 			= parseFloat(jqChampFixed.attr('data-fin-absolue'),10);
			//maj l'offset en cas de parallax
			if (jqChampFixed.css("position")!="fixed" && $(".wbParallax,.wbParallaxChamp").length>0)
				 jqChampFixed.attr('data-debut',jqChampFixed.offset().top);
			var nDebutFixed 		= parseFloat(jqChampFixed.attr('data-debut'),10);
			var nHauteurChampFixed 	= jqChampFixed.outerHeight();			
			var bVersLeBas 			= jqChampFixed.attr('data-sens') == 'bas';	//sens de coulisse

			var nHauteurVueNavigateur = $(window).height();
			
			//adapte les bornes selon la presence d'effet
			if (bAvecEffet)
			{
				if (bVersLeBas)
				{
					nHauteurChampFixed+=nMargeAvant;
				}
				else
				{
					if (jqChampFixed.hasClass("fixed")) 
					{
						nDebutFixed-=nMargeAvant;
					}
					nFinFixed-=nMargeAvant;
				}
			}
			else
			{
				if (bVersLeBas)
				{
					nHauteurChampFixed+=nMargeAvant;
				}
				else
				{
					nDebutFixed-=nMargeAvant;
					nFinFixed-=nMargeAvant;
				}
			}
			//Adapte les classes selon le scroll afin d'appliquer le bon positionnement
			if( bVersLeBas ? (nDebutVueNavigateur+nHauteurVueNavigateur) <= (nDebutFixed+nHauteurChampFixed-(bAvecEffet?nMargeAvant:0)) : nDebutVueNavigateur >= nDebutFixed )
			{
				if (!bSansLimiteFin && 
					(	bVersLeBas 
						? (nDebutVueNavigateur+nHauteurVueNavigateur) <= (nFinFixed+nHauteurChampFixed)  
						: (nDebutVueNavigateur  >= nFinFixed) 
					) 
				)
				{
					jqChampFixed.removeClass('fixed');
					jqChampFixed.addClass('abs');
					//active ou desactive les effets (utile ici pour les activer/desactiver a la volee en exec a chaque scroll)
					// => effet uniquement quand on passe de normal a fixed, pas quand on revient de abs
					jqChampFixed.removeClass('effet');
				}
				else
				{
					jqChampFixed.addClass('fixed');
					jqChampFixed.removeClass('abs');
				}
			} 
			else
			{
				if (!bAvecEffet || (bVersLeBas ? (nDebutVueNavigateur+nHauteurVueNavigateur)>(nDebutFixed+nHauteurChampFixed) : nDebutVueNavigateur<nDebutFixed))
				{
					jqChampFixed.removeClass('fixed');
					jqChampFixed.removeClass('abs');
					//active ou desactive les effets (utile ici pour les activer/desactiver a la volee en exec a chaque scroll)
					// => effet uniquement quand on passe de normal a fixed, pas quand on revient de abs
					jqChampFixed.addClass('effet');
				}
			}
		

			//masque le champ en cas de scroll 
			if (jqChampFixed.hasClass('fixedcoulissemasquee') && jqChampFixed.queue().length==0)
			{
				var nDistance =  !bVersLeBas 
					? (nDebutVueNavigateur - nDebutFixed+nHauteurChampFixed)
					: (nDebutVueNavigateur+nHauteurVueNavigateur - nDebutFixed)
				;

				var bDepasseLeChamp = nDistance>0;

				if (bDepasseLeChamp && (!bVersLeBas ? bDescend : !bDescend))
				{				
					//dispara�t uniquement apr�s avoir scroll� le tiers du viewport (arbitraire)	
					if (nDistance> ((nDebutVueNavigateur+nHauteurVueNavigateur)/3))
					{
						//descend : masque
						jqChampFixed.fadeOut();
					}
				}
				else
				{
					//monte : raffiche
					jqChampFixed.fadeIn();
				}
			}

		});
	};
	//ecoute le scroll et le resize sur la fonction fixedcoulisse
	$(window).scroll(function(event)	{	fixedcoulisse(event);	});
	$(window).resize(function(event)	{	fixedcoulisse(event);	});
	// Force un permier appel pour positionner les champs selon leurs parametres de coulisse
	$(window).trigger('scroll');
})(jQuery);